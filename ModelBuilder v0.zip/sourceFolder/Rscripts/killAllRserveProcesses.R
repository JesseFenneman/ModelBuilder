# Get a list of all Rserve.exe processes running on this machine using the
# system('tasklist') function. Note that this comes in a super handy character
# string form. Before using it, use grep to extract all lines that contain
# a "RServe.exe" mention.
killAllRserveProcesses = function(){
  lines = grep("^Rserve.exe",readLines(textConnection(system('tasklist',intern=TRUE))),value=TRUE)
  for (i in 1:length(lines)){
    line = lines[i]
    #Remove the "Rserve.exe" and all leading whitespace
    s= trimws(gsub("^Rserve.exe","",line))
    
    # Extract the string of numbers that is now at the start of the string.
    # This string of numbers represents a process ID - or PID.
    pid = regmatches(s,regexpr("^[[:digit:]]+", s))
    
    # Kill the process with that PID. I am as suprised as you are that
    # R has this functionality. And how easy it is to use it.
    pskill(pid  , signal = SIGTERM)
  }
}



