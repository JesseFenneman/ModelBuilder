#<>NAME = 'Normal distribution integer only'
#<>TAG = 'DOMAINFUNCTION'
# domainFunctions are function that have to have a 'domain' argument, but this argument is hidden from the user.
# They are used for computing the probability of object values and cue emission matrices

#<>PARAMETER (NAME =  'domain'; dimension = "ARRAY"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'mean'; dimension = "SINGLE"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'sd'; dimension = "SINGLE"; validInput = 'NON_NEGATIVE_DOUBLE')
#<>RETURN (dimension = "ARRAY"; validInput = 'PROBABILITY')
normalDistributionIntegerOnly = function(domain, mean, sd)
{
  isInteger = domain %% 1 == 0
  df = data.frame(domain = domain, isInteger = isInteger)
  df$p = 0
  df$index = 1:nrow(df)
  dfIntegerOnly = subset(df, isInteger)
  
  if (sd == 0){
    dfIntegerOnly$p[which(abs(mean-dfIntegerOnly$domain)==min(abs(mean-dfIntegerOnly$domain)))]=1
    
    for (r in 1:nrow(dfIntegerOnly)){
      df$p[dfIntegerOnly$index[r]] = dfIntegerOnly$p[r]
    }
  
    return (df$p/sum(df$p))
  }
  
  options(scipen=999)
  unnormalizedProbabilities = exp((-(dfIntegerOnly$domain-mean)^2)/(2*sd^2)) 
  dfIntegerOnly$p = unnormalizedProbabilities/sum(unnormalizedProbabilities)
  
  for (r in 1:nrow(dfIntegerOnly)){
    df$p[dfIntegerOnly$index[r]] = dfIntegerOnly$p[r]
  }
  
  
  return ( df$p)
  
}
