#<>NAME = 'Unit Impulse Function'
#<>TAG = 'DOMAINFUNCTION'
# domainFunctions are function that have to have a 'domain' argument, but this argument is hidden from the user.
# They are used for computing the probability of object values and cue emission matrices
#<>PARAMETER (NAME =  'center'; dimension = "SINGLE"; validInput = 'DOUBLE'; DESCRIPTION = 'If the domain contains the center of this Unit Impulse Function then the result is a probability of 1 for the center and a probability of 0 otherwise. If the domain does not contain the center then the closest two points will be the only points with a probability larger than zero. There exact probability depends on their relative distance from the center.  ')
#<>PARAMETER (NAME =  'domain'; dimension = "ARRAY"; validInput = 'DOUBLE')
#<>RETURN (dimension = "ARRAY"; validInput = 'PROBABILITY')
unitImpulseFunction = function(center, domain)
{
  probability = domain*0
  differences = abs(domain-center)
  firstLoc = which.min(differences)
  firstDif = differences[firstLoc]
  differences[firstLoc] = max(differences)
  secondLoc = which.min(differences)
  secondDif = differences[secondLoc]
  ratioDif = 1-firstDif/(firstDif + secondDif)
  
  probability[firstLoc] = ratioDif
  probability[secondLoc] = 1- ratioDif
  
  return(probability)
}
