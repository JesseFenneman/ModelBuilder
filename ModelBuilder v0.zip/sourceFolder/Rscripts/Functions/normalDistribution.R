#<>NAME = 'Normal distribution'
#<>TAG = 'DOMAINFUNCTION'
# domainFunctions are function that have to have a 'domain' argument, but this argument is hidden from the user.
# They are used for computing the probability of object values and cue emission matrices

#<>PARAMETER (NAME =  'domain'; dimension = "ARRAY"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'mean'; dimension = "SINGLE"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'sd'; dimension = "SINGLE"; validInput = 'POSITIVE_DOUBLE')
#<>RETURN (dimension = "ARRAY"; validInput = 'PROBABILITY')
normalDistribution = function(domain, mean, sd)
{
  if (sd == 0){
    p=rep(0, length(domain))
    p[which(abs(mean-domain)==min(abs(mean-domain)))]=1
    return (p/sum(p))
  }
  
  options(scipen=999)
  unnormalizedProbabilities = exp((-(domain-mean)^2)/(2*sd^2)) 
  probabilities = unnormalizedProbabilities/sum(unnormalizedProbabilities)
  return ( probabilities)
  
}
