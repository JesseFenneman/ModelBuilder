#<>NAME = 'Linear after age 10'
#<>TAG = 'FITNESSFUNCTION'
#<>PARAMETER (NAME =  'age'; dimension = "SINGLE"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'phenotypicDimension'; dimension = "SINGLE"; validInput = 'DOUBLE')
#<>RETURN (dimension = "SINGLE")
linearAfterAge10 = function(age, phenotypicDimension)
{
  if (age < 10)
    return (0)
  return (phenotypicDimension)
}
