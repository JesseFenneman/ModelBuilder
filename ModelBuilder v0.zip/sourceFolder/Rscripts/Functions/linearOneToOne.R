#<>NAME = 'identity'
#<>TAG = 'FITNESSFUNCTION'
#<>PARAMETER (NAME =  'phenotypicDimension'; dimension = "SINGLE"; validInput = 'DOUBLE')
#<>RETURN (dimension = "SINGLE")
identity = function(phenotypicDimension)
{
 return (phenotypicDimension)
}
