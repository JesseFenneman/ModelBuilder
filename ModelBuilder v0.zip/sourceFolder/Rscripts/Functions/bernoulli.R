#<>NAME = 'Bernoulli distribution'
#<>TAG = 'DOMAINFUNCTION'
# domainFunctions are function that have to have a 'domain' argument, but this argument is hidden from the user.
# They are used for computing the probability of object values and cue emission matrices

#<>PARAMETER (NAME =  'domain'; dimension = "ARRAY"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'pr_x_equals_0'; dimension = "SINGLE"; validInput = 'PROBABILITY')
#<>RETURN (dimension = "ARRAY"; validInput = 'PROBABILITY')
bernoulli = function(domain, pr_x_equals_0)
{
  if (! (0 %in% domain))
    return(rep(1/length(domain), length(domain)))
  return ( (domain == 0) * pr_x_equals_0 + (domain != 0) * ( (1-pr_x_equals_0) / sum(domain != 0)) )
}
