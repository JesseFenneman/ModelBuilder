#<>NAME = 'High pass uniform distribution'
#<>TAG = 'DOMAINFUNCTION'
# domainFunctions are function that have to have a 'domain' argument, but this argument is hidden from the user.
# They are used for computing the probability of object values and cue emission matrices

#<>PARAMETER (NAME =  'domain'; dimension = "ARRAY"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'threshold'; dimension = "SINGLE"; validInput = 'DOUBLE')
#<>RETURN (dimension = "ARRAY"; validInput = 'PROBABILITY')
highPassUniform = function(domain, threshold)
{
  if (sum(domain>threshold) == 0)
    return (rep(1/length(domain), length(domain)))
  
  return(1/sum(domain>threshold) * (domain>threshold))
}
