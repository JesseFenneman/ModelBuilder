#<>NAME = 'Step function double resource after 10 steps'
#<>TAG = 'OBJECTMUTATION'
#<>PARAMETER (NAME =  'value'; dimension = "SINGLE"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'time'; dimension = "SINGLE"; validInput = 'POSITIVE_INTEGER')
#<>PARAMETER (NAME =  'minimumValue'; dimension = "SINGLE"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'maximumValue'; dimension = "SINGLE"; validInput = 'DOUBLE')
#<>PARAMETER (NAME =  'stepsizeValue'; dimension = "SINGLE"; validInput = 'POSITIVE_DOUBLE')

#<>RETURN (dimension = "SINGLE"; validInput = 'DOUBLE')
stepFunctionResourceDoubleAfter10 = function(value, time, minimumValue, maximumvalue, stepsizeValue)
{
  # Get new value
  result = (value)*(time<10) + (value*2)*(time>=10)
  
  # Make sure its in range
  result = min(maximumValue, result)
  result = max(minimumValue, result)
  
  # Round to nearest stepsizeValue and return
  return(round(result/stepsizeValue)*stepsizeValue)
}
