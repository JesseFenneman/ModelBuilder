#<>NAME = 'Uniform distribution'
#<>TAG = 'DOMAINFUNCTION'
# domainFunctions are function that have to have a 'domain' argument, but this argument is hidden from the user.
# They are used for computing the probability of object values and cue emission matrices
#<>PARAMETER (NAME =  'domain'; dimension = "ARRAY"; validInput = 'DOUBLE')
#<>RETURN (dimension = "ARRAY"; validInput = 'PROBABILITY')
uniform = function(domain)
{
  return(rep(1/length(domain), length(domain)))
}
