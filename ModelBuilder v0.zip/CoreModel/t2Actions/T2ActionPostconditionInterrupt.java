package t2Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectIncorrectRepresentationException;
import core.Model;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import states.EncounterStates.T2ActionStateFactory;
import states.RoamingStates.T1MutationStateFactory;

public class T2ActionPostconditionInterrupt extends T2ActionPostcondition {

	// Which interruption might we encounter?
	private final int interruptionIndex;
	
	private final Model model;

	public T2ActionPostconditionInterrupt(Model model, int interruptionIndex) {
		this.model = model;
		this.interruptionIndex = interruptionIndex;
	}

	@Override
	public String getName() {
		return "Interruption [" + interruptionIndex + "]";
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + interruptionIndex;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		T2ActionPostconditionInterrupt other = (T2ActionPostconditionInterrupt) obj;
		if (interruptionIndex != other.interruptionIndex) {
			return false;
		}
		return true;
	}

	@Override
	public Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
    			  ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates){
		if (model.performSafetyChecks)
			if (currentStates.size() == 0)
				throw new IllegalArgumentException("Calling action postcondition interrupt with an empty currentState list");
	
		// Create a new ArrayList to store all resulting State-probability Pairs in
		ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> successorT2ActionStates = new ArrayList<>(); // no interruption
		ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>> successorT1MutationStates = new ArrayList<>(); // interruption

		// For each current state s (in stateTransitions):
		for (Pair<T2ActionStateFactory, NumberObjectSingle> sucPair: currentStates) {
		
			// Two option.
			
			// First option: the agent knows that there will be an interruption or not, because the interruption type
			// is observable. 
			if (model.ledger.interruptionIsObservable[interruptionIndex]) {
		
				boolean interruptionWillOccur = sucPair.element1.willEncounteredObservableInterruptions[interruptionIndex];

				// If there will be an interruption: end the encounter (deterministic: no change in probability)
				if (interruptionWillOccur) {
					// Stop the encounter: create a deep cloned factory with the same values
					T1MutationStateFactory factory = sucPair.element1.toT1MutationStateFactory();

					// Add this factory to successorT1MutationStates
					successorT1MutationStates.add(new Pair<T1MutationStateFactory, NumberObjectSingle>(factory, sucPair.element2));
				} else {
					// If it will not occur: continue without any changes
					successorT2ActionStates.add(sucPair);
				}
				
				// Some possible checks
				if (model.performSafetyChecks) {
					// If there is an interruption for sure, there should be no T2 action states and at least one T1 state
						if (interruptionWillOccur) {
							if (successorT1MutationStates.size() == 0)
								throw new IllegalStateException("An interruption occurs for sure, yet there are no resulting T1 states");
							if (successorT2ActionStates.size() != 0)
								throw new IllegalStateException("An interruption occurs for sure, yet there are resulting T2 states");
						} else {
							// If there is no interruption for sure, there should be no T1 states and at least one T2 state
							if (successorT1MutationStates.size() != 0)
								throw new IllegalStateException("An interruption occurs for sure not, yet there are resulting T1 states");
							if (successorT2ActionStates.size() == 0)
								throw new IllegalStateException("An interruption occurs for sure not, yet there are no resulting T2 states");
						}
					}
			}

	
			
			// Option 2: the agent does not know yet whether an interruption will occur, but has some beliefs.
			// First, figure out what its posterior belief is that an interruption would happen.
			// Here we use the non-extrinsic-event-modified belief. See the next step for more info.
			else {

				NumberObjectSingle[] tempArray = model.beliefs.getBeliefInterruption(sucPair.element1, interruptionIndex);
				NumberObjectSingle posteriorProbabilityInterruption = tempArray[1];

				// Now the probability than an interruption WILL occur. This is interesting.
				// An agent sampled cues about the state of the probability of an interruption at the start of the encounter.
				// However, this probability might have changed due to extrinsic object events. These
				// changes are deterministic (at least, in this version of the ModelBuilder). For instance,
				// if interruption probabilities always increase with 10 percentage points each time step, 
				// the agent knows that if an interruption might happen at the start with a probability of
				// 50%, it will occur with a probability of 80% after 3 time steps.
				// We can find the current value by prompting the ObjectMutator (stored in the Ledger).
				NumberObjectSingle adjustedProbabilityOfInterruption = model.ledger.objectMutator.getProbabilityOfInterruptionAfterTime(interruptionIndex, posteriorProbabilityInterruption, sucPair.element1.timeInEncounter);
		
				// Now we know the extrinsic-adjusted, posterior belief about the interruption. Let's call that probability Pr(Occur)
				// Suppose that an interruption does NOT happen (p = 1-Pr(Occur): change nothing to the state, and add it to the successorStates with the new probability
				if (!adjustedProbabilityOfInterruption.equals(1)) {

					// Compute the new probability
					NumberObjectSingle newProbability = sucPair.element2.multiply(adjustedProbabilityOfInterruption.complementOfOne(), false);

					// Add result to successorStates
					// Add this factory to successorT1MutationStates
					successorT2ActionStates.add(new Pair<T2ActionStateFactory, NumberObjectSingle>(sucPair.element1, newProbability));
				}

				// If an interruption DOES happen: stop the encounter
				if (!adjustedProbabilityOfInterruption.equals(0, true )) {
					// Stop the encounter: create a deep cloned factory with the same values
					T1MutationStateFactory factory = sucPair.element1.toT1MutationStateFactory();

					// Compute the new probability
					NumberObjectSingle newProbability = sucPair.element2.multiply(adjustedProbabilityOfInterruption, false);

					// Add this factory to successorT1MutationStates
					successorT1MutationStates.add(new Pair<T1MutationStateFactory, NumberObjectSingle>(factory, newProbability));
				}
				
				// A check: if the interruption has a probability higher than 0, there should be at least 1 T1 state.
				// Similarly, if the interruption has a probability lower than 1, there should be at least 1 T2 state
				if (!adjustedProbabilityOfInterruption.equals(0, true ))
					if (successorT1MutationStates.size() == 0)
						throw new IllegalStateException("An interruption occurs might occur, yet there are no resulting T1 states");
				
				if (!adjustedProbabilityOfInterruption.equals(1, true ))
					if (successorT2ActionStates.size() == 0)
						throw new IllegalStateException("An interruption occurs might not occur, yet there are no resulting T2 states");
				

			}
		}
		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to 1
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> p: successorT2ActionStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.element2, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T2ActionState successor state after interruption has a non-positive probability.");
				else
					sum.add(p.element2, true);
			
			for (Pair<T1MutationStateFactory, NumberObjectSingle> p: successorT1MutationStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.element2, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T1MutationState successor state after interruption has a non-positive probability.");
				else
					sum.add(p.element2, true);
			
			// Figure out what it should be 
			DecimalNumber target = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> pair : currentStates)
				target.add(pair.element2, true);
			if (!sum.equals(target, true))
				throw new IllegalStateException("Transition probability distribution after interruption does not sum to starting values. Sum = " + sum.toStringWithoutTrailingZeros()+ ". Starting sum: " + target.toStringWithoutTrailingZeros());
		
		
		}
		
		// Return a pair of the successorT2ActionStates and successorT1MutationStates
		return new Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
  			  ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>>(successorT2ActionStates, successorT1MutationStates);
	}

	
	@Override
	public String toString() {
		return "Interruption [" + interruptionIndex+ "](\"" + model.ledger.interruptionNames[interruptionIndex] + "\")";
	}

}