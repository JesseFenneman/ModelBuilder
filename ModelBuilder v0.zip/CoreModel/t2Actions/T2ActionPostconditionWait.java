package t2Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.Model;
import helper.Helper.Pair;
import states.EncounterStates.T2ActionStateFactory;
import states.RoamingStates.T1MutationStateFactory;

/** Do nothing. */
public class T2ActionPostconditionWait extends T2ActionPostcondition{

	private final Model model;
	public T2ActionPostconditionWait(Model model) {
		this.model = model;
	}
	@Override
	public String getName() {
		return "Wait"; 
	}
	
	@Override
	public Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
    			  ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates){
		if (model.performSafetyChecks)
			if (currentStates.size() == 0)
				throw new IllegalArgumentException("Calling action postcondition wait with an empty currentState list");
		
		return new Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
	  			  ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>>(currentStates, new ArrayList<>());
	}

	@Override
	public String toString() {
		return "Wait";
	} 
	
}