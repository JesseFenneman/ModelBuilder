package t2Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectIncorrectRepresentationException;
import core.Model;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import states.EncounterStates.T2ActionStateFactory;
import states.RoamingStates.T1MutationStateFactory;

public class T2ActionPostconditionConsumeResource extends T2ActionPostcondition {

	// Which resource do we consume?
	private final int resourceIndex;
	
	// Which phenotypic dimension is affected? (i.e., to what dimension should we add the resource value?)
	private final int phenotypeIndex;

	private final Model model;

	public T2ActionPostconditionConsumeResource(Model model, int resourceIndex, int phenotypeIndex) {
		this.model = model;
		this.resourceIndex = resourceIndex;
		this.phenotypeIndex = phenotypeIndex;
	}

	@Override
	public String getName() {
		return "Consume resource [" + resourceIndex +"] to phenotype [" + phenotypeIndex+ "]";
	}

	
	@Override
	public Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
	ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates){
		if (model.performSafetyChecks)
			if (currentStates.size() == 0)
				throw new IllegalArgumentException("Calling action postcondition consume resource with an empty currentState list");


		// Create a new ArrayList to store all resulting State-probability Pairs in
		ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> successorStates = new ArrayList<>();

		// For each current state s (in stateTransitions):
		for (Pair<T2ActionStateFactory, NumberObjectSingle> sucPair: currentStates) {

			// First, we have to figure out if the to-be-consumed resource is observable, or not observable.
			if (model.ledger.resourceIsObservable[resourceIndex]) {
				// If the resource is observable, then this postcondition is deterministic - 
				// the agent already knows the value of the resource

				// Create a deep cloned factory with the same values
				T2ActionStateFactory factory = new T2ActionStateFactory(sucPair.element1, true);

				// The agent knows what sort of resource it encountered at the start of the encounter.
				// However, this value might have changed due to extrinsic object events. These
				// changes are deterministic (at least, in this version of the ModelBuilder). For instance,
				// if resources always decrease with -1 for each time step, the agent knows that if it
				// found a resource with value 5 at the start, it will have a value of 2 after 3 time steps.
				// We can find the current value by prompting the ObjectMutator (stored in the Ledger).
				int resourceValueIndexAfterExtrinsic = model.ledger.objectMutator.getValueOfResourceAfterTime(resourceIndex, factory.valueIndexOfEncounteredObservableResources[resourceIndex], factory.timeInEncounter);
	
				// Add the current resource value to the phenotype
				factory.phenotype[phenotypeIndex] = model.ledger.indexOfPhenotypeAfterAddingResource(phenotypeIndex, factory.phenotype[phenotypeIndex], resourceIndex, resourceValueIndexAfterExtrinsic); 

				// Add the resulting factory to the successorState array
				successorStates.add(new Pair<T2ActionStateFactory, NumberObjectSingle>(factory, sucPair.element2));

			} else {
				// If the resource is not observable, we have to figure out what the value of that resource might be for this state

				// Figure out what the posterior probability of each resource value is.
				// This probability is computed by using the set of cues that an agent
				// observed about this resource, and feeding it into a Bayesian updating scheme.
				// Luckily, we do not have to do that here. Instead, the Beliefs object stored in
				// the model holds all possible posterior probabilities.
				NumberObjectSingle[] posteriorProbabilities = model.beliefs.getBeliefResource(sucPair.element1, resourceIndex);

				// Next, for each possible resource value, we'll add the resource value to the 
				// state, using the function indexOfPhenotypeAfterAddingResource in the model's ledger.
				// We subsequently compute the probability of the agent ending up in that state by 
				// multiplying the sucPairs probability with the probability of that resource value
				for (int r= 0; r < posteriorProbabilities.length; r++) {

					// No need to do anything if this cannot happen!
					if (posteriorProbabilities[r].equals(0, true))
						continue;
				
					// Create a deep cloned factory with the same values
					T2ActionStateFactory factory = new T2ActionStateFactory(sucPair.element1, true);

					// As above: the resource value might have changed due to extrinsic object events. These
					// changes are deterministic (at least, in this version of the ModelBuilder). For instance,
					// if resources always decrease with -1 for each time step, the agent knows that if it
					// found a resource with value 5 at the start, it will have a value of 2 after 3 time steps.
					// We can find the current value by prompting the ObjectMutator (stored in the Ledger).
					int resourceValueIndexAfterExtrinsic = model.ledger.objectMutator.getValueOfResourceAfterTime(resourceIndex, r, factory.timeInEncounter);
					
					// Set the new phenotype index using indexOfPhenotypeAfterAddingResource
					factory.phenotype[phenotypeIndex] = model.ledger.indexOfPhenotypeAfterAddingResource(phenotypeIndex, factory.phenotype[phenotypeIndex], resourceIndex, resourceValueIndexAfterExtrinsic);

					// Compute the new probability
					NumberObjectSingle newProbability = sucPair.element2.multiply(posteriorProbabilities[r], false);

					// Place the resulting factory in the successorState ArrayList.
					successorStates.add(new Pair<T2ActionStateFactory, NumberObjectSingle>( factory, newProbability));

				}
			}
		}

		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to the starting probability
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> p: successorStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.element2, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to sucessor state after consuming resource has a non-positive probability.");
				else
					sum.add(p.element2, true);

			DecimalNumber target = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> pair : currentStates)
				target.add(pair.element2, true);
			if (!sum.equals(target, true))
				throw new IllegalStateException("Transition probability distribution after interruption does not sum to starting values. Sum = " + sum.toStringWithoutTrailingZeros()+ ". Starting sum: " + target.toStringWithoutTrailingZeros());
		
		}

		// Create a new Pair of ArrayLists. The first of which is the successorStates list. 
		// The second list is null - there are no possible T1MutationStates after this postcondition.
		return new Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
				ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>>(successorStates, new ArrayList<>());	
	}


	@Override
	public String toString() {
		return "Consume resource[" + resourceIndex+ "](\"" + model.ledger.resourceNames[resourceIndex] + "\"), affecting phenotype[" + phenotypeIndex +"](\"" + model.ledger.phenotypeNames[phenotypeIndex] + "\")";
	}

}