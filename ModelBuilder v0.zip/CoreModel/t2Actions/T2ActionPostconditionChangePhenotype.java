package t2Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectIncorrectRepresentationException;
import core.Model;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import states.EncounterStates.T2ActionStateFactory;
import states.RoamingStates.T1MutationStateFactory;

/** Increase or decrease the value index position of the phenotype with the prespecified amount.  
 * Note that during the action phase the age does not yet increase - this is only done during the mutation phase.
 * */
public class T2ActionPostconditionChangePhenotype extends T2ActionPostcondition{

	private final Model model;
	private final int phenotypeIndex, amountOfIndexPositionsToIncrease;
	protected T2ActionPostconditionChangePhenotype(Model model, int phenotypeIndex, int amountOfIndexPositionsToIncrease) {
		this.model = model;
		this.phenotypeIndex = phenotypeIndex; 
		this.amountOfIndexPositionsToIncrease = amountOfIndexPositionsToIncrease;
	}
	@Override
	public String getName() {
		return "Change phenotype [" + phenotypeIndex + "] with " + amountOfIndexPositionsToIncrease;
	}

	
	@Override
	public Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
    			  ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates){
		if (model.performSafetyChecks)
			if (currentStates.size() == 0)
				throw new IllegalArgumentException("Calling action postcondition change phenotype with an empty currentState list");
		
		
		// Create a new ArrayList to store all resulting State-probability Pairs in
		ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> successorStates = new ArrayList<>();

		// For each current state s (in stateTransitions):
		for (Pair<T2ActionStateFactory, NumberObjectSingle> p: currentStates) {
			
			// Create a deep cloned factory with the same values
			T2ActionStateFactory factory = new T2ActionStateFactory(p.element1, true);

			// Increase the phenotype
			factory.changePhenotypeByIndexAmounts(phenotypeIndex, amountOfIndexPositionsToIncrease);

			// Place the resulting factory in the successorState ArrayList. The probability is the same as in the stateTransitions (this is a deterministic action)
			successorStates.add(new Pair<T2ActionStateFactory, NumberObjectSingle>( factory, p.element2));
		}

		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum the same proportion as went into this 
		// function
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> p: successorStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.element2, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to sucessor state after changing the phenotype has a non-positive probability.");
				else
					sum.add(p.element2, true);

			DecimalNumber target = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> pair : currentStates)
				target.add(pair.element2, true);
			if (!sum.equals(target, true))
				throw new IllegalStateException("Transition probability distribution after interruption does not sum to starting values. Sum = " + sum.toStringWithoutTrailingZeros()+ ". Starting sum: " + target.toStringWithoutTrailingZeros());
		
			
		}
		
		// Create a new Pair of ArrayLists. The first of which is the successorStates list. 
		// The second list is null - there are no possible T1MutationStates after this postcondition.
		return new Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
  			              ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>>(successorStates, new ArrayList<>());	
		}

	@Override
	public String toString() {
		if (amountOfIndexPositionsToIncrease >0)
			return "Increase phenotype [" + phenotypeIndex + "] with " + amountOfIndexPositionsToIncrease ;
		return "Decrease phenotype [" + phenotypeIndex + "] with " + amountOfIndexPositionsToIncrease ;
	}

	


}

