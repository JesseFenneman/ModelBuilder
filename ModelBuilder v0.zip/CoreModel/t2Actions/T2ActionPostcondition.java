package t2Actions;

import java.math.RoundingMode;
import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import actionElements.ActionTemplatePostcondition;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateConsumeResource;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateDecreasePhenotype;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateIncreasePhenotype;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateInterruptEncounter;
import actionElements.ActionTemplatePostcondition.PostconditionTemplatePostponeWithInterruption;
import actionElements.ActionTemplatePostcondition.PostconditionTemplatePostponeWithoutInterruption;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateSample;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateTerminateEncounter;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateWaitDuring;
import core.LedgerFactory;
import core.Model;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import objectiveElements.CueTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import states.EncounterStates.T2ActionStateFactory;
import states.RoamingStates.T1MutationStateFactory;

/** An T2ActionPostcondition describes the consequences of an action
 * that is possible in a T2State - that is, actions that are possible
 * DURING an encounter.
 * 
 * At the time of writing, there are 9 different postconditions:
 * 
 * 1. Wait (do nothing)
 * 2. Change phenotype by amount (can be both increase or decrease)
 * 3. Sample a cue of resourceType
 * 4. Sample a cue of resourceType
 * 5. Sample a cue of resourceType
 * 6. Consume resource of resourceType
 * 7. Postpone with certain delay
 * 8. Interrupt encounter with certain interruption
 * 9. Terminate encounter. 
 * 
 * Note: although in general the ordering of postconditions does not matter, there are
 * two exceptions: the terminate encounter postcondition should be executed as the last one,
 * as it changes T2ActionStates into */
public abstract class T2ActionPostcondition {

	public abstract String getName();
	
	/** Create a postcondition based on the specified template. */
	public static T2ActionPostcondition createT2Postcondition (Model model, LedgerFactory ledgerFactory, ActionTemplatePostcondition template){
		if (!ActionTemplatePostcondition.canUseDuringEncounters(template.getClass()))
			throw new IllegalArgumentException("Trying to create a T2ActionPostcondition from a non-during-encounter template.");
		
		////////////// Increasing or decrease phenotype
		if (template.getClass() == PostconditionTemplateIncreasePhenotype.class || template.getClass() == PostconditionTemplateDecreasePhenotype.class) {
			// Figure out what the phenotype index in the Ledger is
			int phenotypeIndex = ledgerFactory.getIndexOfPhenotype( ((PhenotypeObjectTemplate) template.getSubject()).getName()  );
			
			// Figure out how many index positions the phenotype should increase or decrease
			// Number of index positions = [Value stored in template] / [step size of that phenotype]
			int indexPositionsToIncrease = ((DecimalNumber) template.getQualifier()).divide( ledgerFactory.phenotypeStepsize.get(phenotypeIndex), false).toInt(RoundingMode.UNNECESSARY);
			if (template.getClass() == PostconditionTemplateDecreasePhenotype.class)
				indexPositionsToIncrease=-1*indexPositionsToIncrease;
			
			return new T2ActionPostconditionChangePhenotype(model, phenotypeIndex, indexPositionsToIncrease);
		}
		
		
		////////////// Sampling cues
		else if (template.getClass() == PostconditionTemplateSample.class) {
			// Get the cue template from the template
			CueTemplate cueTemplate = (CueTemplate) template.getSubject();
			
			// What are we sampling? Resources, delays, or interruptions?
			
			// If we are sampling cues on a resource...
			if (cueTemplate.object instanceof ResourceObjectTemplate) {
				// Figure out the index position of the resource in question
				int resourceIndex = ledgerFactory.getIndexOfResourceType(cueTemplate.object.getName());
				
				// Create a sampling postcondition
				return new T2ActionPostconditionSampleResourceCue(model, resourceIndex);
			}

			// If we are sampling cues on a delay type...
			if (cueTemplate.object instanceof DelayObjectTemplate) {
				// Figure out the index position of the delayin question
				int delayIndex = ledgerFactory.getIndexOfDelayType(cueTemplate.object.getName());

				// Create a sampling postcondition
				return new T2ActionPostconditionSampleDelayCue(model, delayIndex);
			}

			// If we are sampling cues on an interruption type...
			if (cueTemplate.object instanceof InterruptionObjectTemplate) {
				// Figure out the index position of the resource in question
				int interruptionIndex = ledgerFactory.getIndexOfInterruptionType(cueTemplate.object.getName());

				// Create a sampling postcondition
				return new T2ActionPostconditionSampleInterruptionCue(model, interruptionIndex);
			}
		}

		////////////// Wait/ do nothing
		else if (template.getClass() == PostconditionTemplateWaitDuring.class) 
			return new T2ActionPostconditionWait(model);

		////////////// Postpone
		else if (template.getClass() == PostconditionTemplatePostponeWithoutInterruption.class) 
			return new T2ActionPostconditionPostpone(model, ledgerFactory.getIndexOfDelayType(((DelayObjectTemplate) template.getSubject()).getName()), -1);
		
		else if (template.getClass() == PostconditionTemplatePostponeWithInterruption.class) 
			return new T2ActionPostconditionPostpone(model, 
					ledgerFactory.getIndexOfDelayType(((DelayObjectTemplate) template.getSubject()).getName()), 
					ledgerFactory.getIndexOfInterruptionType(((InterruptionObjectTemplate) template.getQualifier()).getName()));
		
		
		////////////// Interrupt
		else if (template.getClass() == PostconditionTemplateInterruptEncounter.class) 
			return new T2ActionPostconditionInterrupt(model, ledgerFactory.getIndexOfInterruptionType(((InterruptionObjectTemplate) template.getSubject()).getName()));
		
		////////////// Consume
		else if (template.getClass() == PostconditionTemplateConsumeResource.class) 
			return new T2ActionPostconditionConsumeResource(model, 
					ledgerFactory.getIndexOfResourceType(((ResourceObjectTemplate) template.getSubject()).getName()),
					ledgerFactory.getIndexOfPhenotype(((PhenotypeObjectTemplate) template.getQualifier()).getName()));
		
		
		
		////////////// Terminate
		else if (template.getClass() == PostconditionTemplateTerminateEncounter.class) 
			return new T2ActionPostconditionTerminateEncounter(model);

		throw new IllegalStateException("Trying to parse a postcondition of an unknown class: " + template.getClass().getSimpleName() + " is not implemented as a T2ActionPostcondition yet");
	}


	/** 
	 * Each postcondition results in two ArrayLists: 
	 * The first ArrayList contains pairs of successor T2ActionStateFactories and the probability that
	 * an agent will end up in the state created by that factory after executing an action. These 
	 * factories represent all possible action consequences in which the encounter continues. 
	 * Note: the T2Action itself checks whether these factories give birth to dead states,
	 * and if so, turn the successor T2ActionStateFactory into a T1FitnessStateFactory. The 
	 * T2ActionPostcondition does not have to worry about this.
	 * 
	 * The second ArrayList contains pairs of successor T1MutationStateFactories and the probability that
	 * and agent will end up in the state created by that factory after executing the action. These represent
	 * all possible futures in which the encounter stops (either by termination or interruption). Just as with
	 * the other ArrayList, the T2Action will check if these T1MutationStates give birth to a dead state. The
	 * T2ActionPostcondition does not have to do this checking itself. Note that only interrupt or terminate postconditions
	 * can result in T1MutationStateFactories. Such postcondition should be executed as the LAST postconditions.
	 * 
	 * The input currentState is a list similar to the first ArrayList - an ArrayList of paired T2ActionStateFactories
	 * and the probability of that T2ActionStateFactory. Note that, by definition, an action can only be taken in an
	 * ActionState. 
	 * 
	 * You might wonder two things: first, why does the input contain an array of multiple ActionStates, 
	 * rather than a single state, as an action applies to only one state. The reason for this is that Actions 
	 * can have multiple postconditions, which all have to be applied 'at the same time'. 
	 * Suppose that there are 2 Postconditions. After taking an action, first the first postcondition
	 * is applied. This postcondition might result in more than one possible successor states. If so,
	 * the second postcondition has to be applied to all possible states that result from the first
	 * postcondition. Note, these factories have not yet turned into states, and are not registered in the 
	 * T1StateList yet!
	 * 
	 * Second, why does the return contain an arrayList of T2ActionStates, and not T2MutationStates? The answer to that
	 * is similar to the answer above: the output of one postcondition might still have to go through
	 * another postcondition. Hence, we'll leave it to the Action itself to switch an ActionState to a
	 * MutationState.
	 *  */
	public abstract Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
	                       ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates);

	public abstract String toString();

	
}
