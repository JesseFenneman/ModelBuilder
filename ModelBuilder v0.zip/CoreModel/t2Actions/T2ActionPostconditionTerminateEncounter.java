package t2Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectIncorrectRepresentationException;
import core.Model;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import states.EncounterStates.T2ActionStateFactory;
import states.RoamingStates.T1MutationStateFactory;

public class T2ActionPostconditionTerminateEncounter extends T2ActionPostcondition{
	private final Model model;
	public T2ActionPostconditionTerminateEncounter(Model model) {
		this.model = model;
	}
	
	@Override
	public String getName() {
		return "Terminate encounter"; 
	}
	@Override
	public Pair<ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, 
	            ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStates(
			    ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates) {
		if (model.performSafetyChecks)
			if (currentStates.size() == 0)
				throw new IllegalArgumentException("Calling action postcondition terminate with an empty currentState list");
		
		// Create a new ArrayList to store all resulting T1MutationState-probability Pairs in
		ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>> successorT1MutationStates = new ArrayList<>(); // interruption

		// For each current state s (in stateTransitions):
		for (Pair<T2ActionStateFactory, NumberObjectSingle> sucPair: currentStates) {

			// Create a T1MutationState (i.e., we're dropping out of the encounter here)

			// Stop the encounter: create a deep cloned factory with the same values
			T1MutationStateFactory factory = sucPair.element1.toT1MutationStateFactory();

			// Add this factory to successorT1MutationStates
			successorT1MutationStates.add(new Pair<T1MutationStateFactory, NumberObjectSingle>(factory, sucPair.element2));
	
		}

		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to the starting probability
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			
			for (Pair<T1MutationStateFactory, NumberObjectSingle> p: successorT1MutationStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.element2, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T1MutationState successor state after termination has a non-positive probability.");
				else
					sum.add(p.element2, true);
			
			DecimalNumber target = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> pair : currentStates)
				target.add(pair.element2, true);
			if (!sum.equals(target, true))
				throw new IllegalStateException("Transition probability distribution after interruption does not sum to starting values. Sum = " + sum.toStringWithoutTrailingZeros()+ ". Starting sum: " + target.toStringWithoutTrailingZeros());
		
		}
		
		// Return a pair of null and successorT1MutationStates (null as there are no possible successorT2ActionStates after a deterministic termination)
		return new Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
  			  ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>>(new ArrayList<>(), successorT1MutationStates);
	}

	@Override
	public String toString() {
		return "Terminate encounter";
	}

}
