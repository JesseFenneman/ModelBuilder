package patch;

import java.util.ArrayList;
import java.util.Arrays;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import beliefElements.AbstractBeliefTemplate;
import core.AbstractModel;
import core.LedgerFactory;
import core.RandomNumberGenerator;
import decimalNumber.DecimalNumber;
import helper.Helper;
import interfaces_abstractions.ObserverManager;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.ExtrinsicObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import rIntegration.RFunctionContainer;
import spatialAndTemporalElements.BasePatch;
import spatialAndTemporalElements.BaseState;
import spatialAndTemporalElements.BeliefOffset;
import spatialAndTemporalElements.PatchStateTemplate;
import view.Workspace;


public class PatchState {

	private final AbstractModel model;


	/** The probability of a resource value in this PatchState, if the resource is encountered.
	 * Formally: p(Resource has value X | resource has been encountered). Indexed as [resource index][value index]. */
	public final NumberObjectSingle[][] rawResourceValueProbabilities;

	/** The Frequency of a resource in this patch. Formally: P(resource | searching for resource). This
	 * is also called the instantiation probability. Indexed as [resource index]. */
	public final NumberObjectSingle[]   resourceFrequencies; 

	/** The probability of encountering a resource with a value, taking into account the frequency of
	 * that resource in this PatchState, Formally: p(Resource has value X), which is computed as
	 * p(Resource has value X | resource has been encountered ) * Frequency (= P(Resource). Note,
	 * this array sums to 1 if and only if the frequency of that resource is 1. Indexed as [resource index][value index].*/
	public final NumberObjectSingle[][] resourceValueProbability;

	/** How many values can a resource actually have, taking into account the frequency of the resource
	 * in this patch (i.e., not including the resource values with a probability of 0). Indexed as [resource index].*/
	public final int[] numberOfNonZeroProbabilityResourceValues;

	/** In some models, there are some patch states where an agent does not know the distribution of 
	 * resource values in advance. Are resource values known in this patch state? Indexed by [resourceindex]. */
	public final boolean[] resourceDistributionKnown;
	
	/** In some models, there are some patch states where an agent does not know the distribution of 
	 * resource values in advance. Rather, this distribution has to be learned from experience. It will, however,
	 * have a prior number of observations that it can use as an initial distribution. Indexed as [resource index][value index]. */
	public final int[][] resourcePriorExperiences;
	
	
	
	
	
	/** The probability of a delay duration in this PatchState, if the delay is encountered.
	 * Formally: p(Delay has duration X | delay has been encountered). Indexed as [delay index][duration index]. */
	public final NumberObjectSingle[][] rawDelayDurationProbabilities;

	/** The Frequency of a delay in this patch. Formally: P(delay | searching for delay). This
	 * is also called the instantiation probability. Indexed as [delay index]. */
	public final NumberObjectSingle[]   delayFrequencies; 

	/** The probability of encountering a delay with a duration, taking into account the frequency of
	 * that delay in this PatchState, Formally: p(Delay has duration X), which is computed as
	 * p(Delay has duration X | delay has been encountered ) * Frequency (= P(Delay). Note,
	 * this array sums to 1 if and only if the frequency of that delay is 1. Indexed as [delay index][delay index].*/
	public final NumberObjectSingle[][] delayDurationProbability;

	/** How many possible duration can a delay actually have, taking into account the frequency of the delay 
	 * in this patch (i.e., not including the delay duration with a probability of 0). Indexed as [delay index].*/
	public final int[] numberOfNonZeroProbabilityDelayDurations;

	/** In some models, there are some patch states where an agent does not know the distribution of 
	 * delay durations in advance. Are resource values known in this patch state? Indexed by [delay index]. */
	public final boolean[] delayDistributionKnown;
	
	/** In some models, there are some patch states where an agent does not know the distribution of 
	 * delay durations in advance. Rather, this distribution has to be learned from experience. It will, however,
	 * have a prior number of observations that it can use as an initial distribution. Indexed as [delay index][value index]. */
	public final int[][] delayPriorExperiences;

	
	
	
	
	
	
	/** The probability of an interruption occurring in this PatchState. Note, interruptions do not have frequencies.
	 * Rather, they only have a probability of true (interruption occurs) that this is the same
	 * as the frequency of an interruption, as an interruption either occurs or does not. Indexed as [interruption index][false, true]. */
	public final NumberObjectSingle[][] interruptionProbabilities;

	/** How many options can an interruption have in this patch. Returns 2 if interruption
	 * can, but do not have to, occur (i.e., 0 < P(Interruption) < 1). Indexed as [interruption index].*/
	public final int[] numberOfNonZeroProbabilityInterruptions;

	/** In some models, there are some patch states where an agent does not know the distribution of 
	 * the interruption probabilities in advance. Are resource values known in this patch state? Indexed by [false, true]. */
	public final boolean[] interruptionDistributionKnown;
	
	/** In some models, there are some patch states where an agent does not know the distribution of 
	 * the probability of an interruption in advance. Rather, this distribution has to be learned from experience. It will, however,
	 * have a prior number of observations that it can use as an initial distribution. Indexed as [resource index][{false, true}]. */
	public final int[][] interruptionPriorExperiences;
	
	
	
	
	/** The probability of a, extrinsic event value in this PatchState, if the extrinsic event is encountered.
	 * Formally: p(Extrinsic event has value X | extrinsic event has been encountered). Indexed as [extrinsic index][value index]. */
	public final NumberObjectSingle[][] rawExtrinsicEventValueProbabilities;

	/** The Frequency of an extrinsic event in this patch state. Formally: P(extrinsic event | checking if extrinsic event occurs). This
	 * is also called the instantiation probability. Indexed as [extrinsic index]. */
	public final NumberObjectSingle[]   extrinsicEventFrequencies; 

	/** The probability of encountering an extrinsic event with a value, taking into account the frequency of
	 * that event in this PatchState, Formally: p(Extrinsic event has value X), which is computed as
	 * p(Extrinsic event has value X | extrinsic has been encountered ) * Frequency (= P(Extrinsic event). Note,
	 * this array sums to 1 if and only if the frequency of that extrinsic is 1. Indexed as [extrinsic index][value index].*/
	public final NumberObjectSingle[][] extrinsicEventValueProbability;

	/** In some models, there are some patch states where an agent does not know the distribution of 
	 * extrinsic event values in advance. Are resource values known in this patch state? Indexed by [extrinsic index]. */
	public final boolean[] extrinsicDistributionKnown;
	
	/** In some models, there are some patch states where an agent does not know the distribution of 
	 * extrinsic event values in advance. Rather, this distribution has to be learned from experience. It will, however,
	 * have a prior number of observations that it can use as an initial distribution. Indexed as [extrinsic index][value index]. */
	public final int[][] extrinsicPriorExperiences;
	
	/** How many values can an extrinsic actually have, taking into account the frequency of the extrinsic event
	 * in this patch (i.e., not including the extrinsic event values with a probability of 0). Indexed as [extrinsic index].*/
	public final int[] numberOfNonZeroProbabilityExtrinsicEventValues;

	// The patch and patch state indices in the ledger
	public final int ledgerIndexOfPatch, ledgerIndexOfPatchState;

	/** Create a new PatchState based on the supplied PatchStateTemplate. This patch state registers itself in the
	 * ledgerFactory */
	public PatchState(int indexOfPatchInLedger, PatchStateTemplate template, AbstractModel model, LedgerFactory ledgerFactory, Workspace workspace){
		this.model = model;

		// First, the patch state registers itself in the ledgerFactory
		ledgerIndexOfPatch = indexOfPatchInLedger;

		synchronized (ledgerFactory) {
			if (ledgerFactory.patchStateNames.size() != ledgerFactory.patchStates.size())
				throw new IllegalStateException("There is an unequal number of patch states and patch state names in the factory ledger before creating a new patch state. ");

			ledgerFactory.patchStates.add(this);
			ledgerFactory.patchStateNames.add(template.getName());
			this.ledgerIndexOfPatchState = ledgerFactory.patchStateNames.size() -1;

			if (ledgerFactory.patchStateNames.size() != ledgerFactory.patchStates.size())
				throw new IllegalStateException("There is an unequal number of patch states and patch state names in the factory ledger after creating a new patch state. ");
			if (template.getPatch() == BasePatch.get() && template == BaseState.get())
				ledgerFactory.baseStateIndex = ledgerIndexOfPatchState;
		}

		// Create and populate the resource arrays 
		rawResourceValueProbabilities = new NumberObjectSingle[ledgerFactory.resourceNames.size()][];
		resourceFrequencies = new NumberObjectSingle[ledgerFactory.resourceNames.size()];
		resourceValueProbability = new NumberObjectSingle[ledgerFactory.resourceNames.size()][];
		numberOfNonZeroProbabilityResourceValues = new int[ledgerFactory.resourceNames.size()];

		for (String resourceName : ledgerFactory.resourceNames) 
			populateObjectArrays( template,  ledgerFactory,  workspace, resourceName, ledgerFactory.resourceNames, 
					rawResourceValueProbabilities, resourceFrequencies, resourceValueProbability, numberOfNonZeroProbabilityResourceValues);

		// Set the resource BELIEFS; the knownDistribution and priorExperience arrays

		this.resourceDistributionKnown = new boolean[ledgerFactory.resourceNames.size()];
		this.resourcePriorExperiences = new int[ledgerFactory.resourceNames.size()][];
		for (int r = 0; r < ledgerFactory.resourceNames.size(); r++ ) {
			String resourceName = ledgerFactory.resourceNames.get(r);
			ResourceObjectTemplate resourceTemplate = (ResourceObjectTemplate) workspace.getObject(resourceName); 
			AbstractBeliefTemplate beliefInBase = resourceTemplate.getBelief();
			BeliefOffset offset = template.getOffsettedBelief(beliefInBase);
			
			// Is the distribution in this patch known?
			boolean distributionIsKnown = beliefInBase.isKnownDistribution();
			if (offset != null)
				distributionIsKnown = offset.isKnownDistribution();
			resourceDistributionKnown[r] = distributionIsKnown;
			
			// If the distribution is not known, figure out the prior number of observations in this patch state
			// Get an array of all the resource values
			NumberObjectSingle[] resourceValues = resourceTemplate.getDomain().toArray();
			int[] priorObservations = new int[resourceValues.length];
			
			// Get the number of observations in the base patch
			for (int v = 0; v < priorObservations.length; v++) {
				priorObservations[v] = beliefInBase.getObservations().get(resourceValues[v].toDecimalNumber());
				if (offset != null)
					priorObservations[v] = priorObservations[v] + offset.getPatchSpecificObservations(resourceValues[v].toDecimalNumber());
			}
			resourcePriorExperiences[r] = priorObservations;
		}

		
		
		
		
		// Create the interruption arrays 
		interruptionProbabilities = new NumberObjectSingle[ledgerFactory.interruptionNames.size()][];
		numberOfNonZeroProbabilityInterruptions = new int[ledgerFactory.interruptionNames.size()];

		for (String interruptionName : ledgerFactory.interruptionNames) 
			populateObjectArrays( template,  ledgerFactory,  workspace, interruptionName, ledgerFactory.interruptionNames, 
					interruptionProbabilities, null, null, numberOfNonZeroProbabilityInterruptions);
		
		// Set the interruption BELIEFS; the knownDistribution and priorExperience arrays 
		this.interruptionDistributionKnown = new boolean[ledgerFactory.interruptionNames.size()];
		this.interruptionPriorExperiences = new int[ledgerFactory.interruptionNames.size()][];
		for (int i = 0; i < ledgerFactory.interruptionNames.size(); i++ ) {
			String interruptionName = ledgerFactory.resourceNames.get(i);
			InterruptionObjectTemplate interruptionTemplate = (InterruptionObjectTemplate) workspace.getObject(interruptionName); 
			AbstractBeliefTemplate beliefInBase = interruptionTemplate.getBelief();
			BeliefOffset offset = template.getOffsettedBelief(beliefInBase);

			// Is the distribution in this patch known?
			boolean distributionIsKnown = beliefInBase.isKnownDistribution();
			if (offset != null)
				distributionIsKnown = offset.isKnownDistribution();
			interruptionDistributionKnown[i] = distributionIsKnown;

			// If the distribution is not known, figure out the prior number of observations in this patch state
			// Note; interruptions are always indexed as {false, true}
			int[] priorObservations = new int[2];
			priorObservations[0] = beliefInBase.getObservations().get(DecimalNumber.ZERO);
			priorObservations[1] = beliefInBase.getObservations().get(DecimalNumber.ONE);
			if (offset != null) {
				priorObservations[0] += offset.getPatchSpecificObservations(DecimalNumber.ZERO);
				priorObservations[1] += offset.getPatchSpecificObservations(DecimalNumber.ONE);
			}
			interruptionPriorExperiences[i] = priorObservations;
		}

		// Create and populate the delay arrays 
		rawDelayDurationProbabilities = new NumberObjectSingle[ledgerFactory.delayNames.size()][];
		delayFrequencies = new NumberObjectSingle[ledgerFactory.delayNames.size()];
		delayDurationProbability = new NumberObjectSingle[ledgerFactory.delayNames.size()][];
		numberOfNonZeroProbabilityDelayDurations = new int[ledgerFactory.delayNames.size()];

		for (String delayName : ledgerFactory.delayNames) 
			populateObjectArrays( template,  ledgerFactory,  workspace, delayName, ledgerFactory.delayNames, 
					rawDelayDurationProbabilities, delayFrequencies, delayDurationProbability, numberOfNonZeroProbabilityDelayDurations);

		// Set the delay BELIEFS; the knownDistribution and priorExperience arrays
		this.delayDistributionKnown = new boolean[ledgerFactory.delayNames.size()];
		this.delayPriorExperiences = new int[ledgerFactory.delayNames.size()][];
		for (int d = 0; d < ledgerFactory.delayNames.size(); d++ ) {
			String delayName = ledgerFactory.delayNames.get(d);
			DelayObjectTemplate delayTemplate = (DelayObjectTemplate) workspace.getObject(delayName); 
			AbstractBeliefTemplate beliefInBase = delayTemplate.getBelief();
			BeliefOffset offset = template.getOffsettedBelief(beliefInBase);

			// Is the distribution in this patch known?
			boolean distributionIsKnown = beliefInBase.isKnownDistribution();
			if (offset != null)
				distributionIsKnown = offset.isKnownDistribution();
			delayDistributionKnown[d] = distributionIsKnown;

			// If the distribution is not known, figure out the prior number of observations in this patch state
			// Get an array of all the delay durations
			NumberObjectSingle[] delayDurations = delayTemplate.getDomain().toArray();
			int[] priorObservations = new int[delayDurations.length];

			// Get the number of observations in the base patch
			for (int dur = 0; dur < priorObservations.length; dur++) {
				priorObservations[dur] = beliefInBase.getObservations().get(delayDurations[d].toDecimalNumber());
				if (offset != null)
					priorObservations[dur] = priorObservations[dur] + offset.getPatchSpecificObservations(delayDurations[dur].toDecimalNumber());
			}
			delayPriorExperiences[d] = priorObservations;
		}

		// Create and populate the extrinsic event arrays 
		rawExtrinsicEventValueProbabilities = new NumberObjectSingle[ledgerFactory.extrinsicNames.size()][];
		extrinsicEventFrequencies = new NumberObjectSingle[ledgerFactory.extrinsicNames.size()];
		extrinsicEventValueProbability = new NumberObjectSingle[ledgerFactory.extrinsicNames.size()][];
		numberOfNonZeroProbabilityExtrinsicEventValues = new int[ledgerFactory.extrinsicNames.size()];

		for (String extrinsicName : ledgerFactory.extrinsicNames) 
			populateObjectArrays( template,  ledgerFactory,  workspace, extrinsicName, ledgerFactory.extrinsicNames, 
					rawExtrinsicEventValueProbabilities, extrinsicEventFrequencies, extrinsicEventValueProbability, numberOfNonZeroProbabilityExtrinsicEventValues);

		// Set the extrinsic BELIEFS; the knownDistribution and priorExperience arrays
		this.extrinsicDistributionKnown = new boolean[ledgerFactory.extrinsicNames.size()];
		this.extrinsicPriorExperiences = new int[ledgerFactory.extrinsicNames.size()][];
		for (int e = 0; e < ledgerFactory.extrinsicNames.size(); e++ ) {
			String extrinsicName = ledgerFactory.extrinsicNames.get(e);
			ExtrinsicObjectTemplate extrinsicTemplate = (ExtrinsicObjectTemplate) workspace.getObject(extrinsicName); 
			AbstractBeliefTemplate beliefInBase = extrinsicTemplate.getBelief();
			BeliefOffset offset = template.getOffsettedBelief(beliefInBase);

			// Is the distribution in this patch known?
			boolean distributionIsKnown = beliefInBase.isKnownDistribution();
			if (offset != null)
				distributionIsKnown = offset.isKnownDistribution();
			extrinsicDistributionKnown[e] = distributionIsKnown;

			// If the distribution is not known, figure out the prior number of observations in this patch state
			// Get an array of all the extrinsic event values
			NumberObjectSingle[] extrinsicEventValues= extrinsicTemplate.getDomain().toArray();
			int[] priorObservations = new int[extrinsicEventValues.length];

			// Get the number of observations in the base patch
			for (int eev = 0; eev < priorObservations.length; eev ++) {
				priorObservations[eev] = beliefInBase.getObservations().get(extrinsicEventValues[eev].toDecimalNumber());
				if (offset != null)
					priorObservations[eev] = priorObservations[eev] + offset.getPatchSpecificObservations(extrinsicEventValues[eev].toDecimalNumber());
			}
			extrinsicPriorExperiences[e] = priorObservations;
		}

	}

	/** Deep clone constructor */
	public PatchState(PatchState original) {
		this.model = original.model;
		
		// Copy resources
		rawResourceValueProbabilities	= new NumberObjectSingle[original.rawResourceValueProbabilities.length][];
		for (int i = 0; i < rawResourceValueProbabilities.length; i++) {
			if (original.rawResourceValueProbabilities[i] != null) {
				rawResourceValueProbabilities[i] = new NumberObjectSingle[original.rawResourceValueProbabilities[i].length];
				for (int j = 0; j < rawResourceValueProbabilities[i].length; j++) 
					rawResourceValueProbabilities[i][j] = original.rawResourceValueProbabilities[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone(); 
			}
		}
		numberOfNonZeroProbabilityResourceValues = new int[original.numberOfNonZeroProbabilityResourceValues.length];
		for (int i = 0; i < numberOfNonZeroProbabilityResourceValues.length; i++ )
			numberOfNonZeroProbabilityResourceValues[i] = original.numberOfNonZeroProbabilityResourceValues[i];

		resourceFrequencies = new NumberObjectSingle[original.resourceFrequencies.length];
		for (int i = 0; i < resourceFrequencies.length; i++ )
			resourceFrequencies[i] = original.resourceFrequencies[i].toNumberObjectSingle(model.howToRepresentNumbers).clone();

		resourceValueProbability	= new NumberObjectSingle[original.resourceValueProbability.length][];
		for (int i = 0; i < resourceValueProbability.length; i++) {
			if (original.resourceValueProbability[i] != null) {
				resourceValueProbability[i] = new NumberObjectSingle[original.resourceValueProbability[i].length];
				for (int j = 0; j < resourceValueProbability[i].length; j++) 
					resourceValueProbability[i][j] = original.resourceValueProbability[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone(); 
			}
		}
		
		resourceDistributionKnown = new boolean[original.resourceDistributionKnown.length];
		for (int i = 0; i < resourceDistributionKnown.length; i ++)
			resourceDistributionKnown[i] = original.resourceDistributionKnown[i];
		
		resourcePriorExperiences = new int[original.resourcePriorExperiences.length][];
		for (int i = 0; i < resourcePriorExperiences.length; i++) {
			if (original.resourcePriorExperiences[i] != null) {
				resourcePriorExperiences[i] = new int[original.resourcePriorExperiences[i].length];
				for (int j = 0; j < resourcePriorExperiences[i].length; j++) 
					resourcePriorExperiences[i][j] = original.resourcePriorExperiences[i][j]; 
			}
		}
		
		// Copy interruptions
		interruptionProbabilities	= new NumberObjectSingle[original.interruptionProbabilities.length][];
		for (int i = 0; i < interruptionProbabilities.length; i++) {
			interruptionProbabilities[i] = new NumberObjectSingle[original.interruptionProbabilities[i].length];
			for (int j = 0; j < interruptionProbabilities[i].length; j++) 
				interruptionProbabilities[i][j] = original.interruptionProbabilities[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		}
		numberOfNonZeroProbabilityInterruptions = new int[original.numberOfNonZeroProbabilityInterruptions.length];
		for (int i = 0; i < numberOfNonZeroProbabilityInterruptions.length; i++ )
			numberOfNonZeroProbabilityInterruptions[i] = original.numberOfNonZeroProbabilityInterruptions[i];
		
		interruptionDistributionKnown = new boolean[original.interruptionDistributionKnown.length];
		for (int i = 0; i < interruptionDistributionKnown.length; i ++)
			interruptionDistributionKnown[i] = original.interruptionDistributionKnown[i];
		
		interruptionPriorExperiences = new int[original.interruptionPriorExperiences.length][];
		for (int i = 0; i < interruptionPriorExperiences.length; i++) {
			if (original.interruptionPriorExperiences[i] != null) {
				interruptionPriorExperiences[i] = new int[original.interruptionPriorExperiences[i].length];
				for (int j = 0; j < interruptionPriorExperiences[i].length; j++) 
					interruptionPriorExperiences[i][j] = original.interruptionPriorExperiences[i][j]; 
			}
		}
		
		
		
		// Copy delays
		rawDelayDurationProbabilities	= new NumberObjectSingle[original.rawDelayDurationProbabilities.length][];
		for (int i = 0; i < rawDelayDurationProbabilities.length; i++) {
			rawDelayDurationProbabilities[i] = new NumberObjectSingle[original.rawDelayDurationProbabilities[i].length];
			for (int j = 0; j < rawDelayDurationProbabilities[i].length; j++) 
				rawDelayDurationProbabilities[i][j] = original.rawDelayDurationProbabilities[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		}
		numberOfNonZeroProbabilityDelayDurations = new int[original.numberOfNonZeroProbabilityDelayDurations.length];
		for (int i = 0; i < numberOfNonZeroProbabilityDelayDurations.length; i++ )
			numberOfNonZeroProbabilityDelayDurations[i] = original.numberOfNonZeroProbabilityDelayDurations[i];
		delayFrequencies = new NumberObjectSingle[original.delayFrequencies.length];
		for (int i = 0; i < delayFrequencies.length; i++ )
			delayFrequencies[i] = original.delayFrequencies[i].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		delayDurationProbability	= new NumberObjectSingle[original.delayDurationProbability.length][];
		for (int i = 0; i < delayDurationProbability.length; i++) {
			delayDurationProbability[i] = new NumberObjectSingle[original.delayDurationProbability[i].length];
			for (int j = 0; j < delayDurationProbability[i].length; j++) 
				delayDurationProbability[i][j] = original.delayDurationProbability[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		}
		delayDistributionKnown = new boolean[original.delayDistributionKnown.length];
		for (int i = 0; i < delayDistributionKnown.length; i ++)
			delayDistributionKnown[i] = original.delayDistributionKnown[i];
		
		delayPriorExperiences = new int[original.delayPriorExperiences.length][];
		for (int i = 0; i < delayPriorExperiences.length; i++) {
			if (original.delayPriorExperiences[i] != null) {
				delayPriorExperiences[i] = new int[original.delayPriorExperiences[i].length];
				for (int j = 0; j < delayPriorExperiences[i].length; j++) 
					delayPriorExperiences[i][j] = original.delayPriorExperiences[i][j]; 
			}
		}
		
		
		
		// Copy extrinsic events
		rawExtrinsicEventValueProbabilities	= new NumberObjectSingle[original.rawExtrinsicEventValueProbabilities.length][];
		for (int i = 0; i < rawExtrinsicEventValueProbabilities.length; i++) {
			rawExtrinsicEventValueProbabilities[i] = new NumberObjectSingle[original.rawExtrinsicEventValueProbabilities[i].length];
			for (int j = 0; j < rawExtrinsicEventValueProbabilities[i].length; j++) 
				rawExtrinsicEventValueProbabilities[i][j] = original.rawExtrinsicEventValueProbabilities[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		}
		numberOfNonZeroProbabilityExtrinsicEventValues = new int[original.numberOfNonZeroProbabilityExtrinsicEventValues.length];
		for (int i = 0; i < numberOfNonZeroProbabilityExtrinsicEventValues.length; i++ )
			numberOfNonZeroProbabilityExtrinsicEventValues[i] = original.numberOfNonZeroProbabilityExtrinsicEventValues[i];

		extrinsicEventFrequencies = new NumberObjectSingle[original.extrinsicEventFrequencies.length];
		for (int i = 0; i < extrinsicEventFrequencies.length; i++ )
			extrinsicEventFrequencies[i] = original.extrinsicEventFrequencies[i].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		
		extrinsicEventValueProbability	= new NumberObjectSingle[original.extrinsicEventValueProbability.length][];
		for (int i = 0; i < extrinsicEventValueProbability.length; i++) {
			extrinsicEventValueProbability[i] = new NumberObjectSingle[original.extrinsicEventValueProbability[i].length];
			for (int j = 0; j < extrinsicEventValueProbability[i].length; j++) 
				extrinsicEventValueProbability[i][j] = original.extrinsicEventValueProbability[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		}
		
		extrinsicDistributionKnown = new boolean[original.extrinsicDistributionKnown.length];
		for (int i = 0; i < extrinsicDistributionKnown.length; i ++)
			extrinsicDistributionKnown[i] = original.extrinsicDistributionKnown[i];
		
		extrinsicPriorExperiences = new int[original.extrinsicPriorExperiences.length][];
		for (int i = 0; i < extrinsicPriorExperiences.length; i++) {
			if (original.extrinsicPriorExperiences[i] != null) {
				extrinsicPriorExperiences[i] = new int[original.extrinsicPriorExperiences[i].length];
				for (int j = 0; j < extrinsicPriorExperiences[i].length; j++) 
					extrinsicPriorExperiences[i][j] = original.extrinsicPriorExperiences[i][j]; 
			}
		}
		
		
		
		this.ledgerIndexOfPatch = original.ledgerIndexOfPatch;
		this.ledgerIndexOfPatchState = original.ledgerIndexOfPatchState;

		this.makeImmutable();
	}

	/** Computes the probability of all the values of the object and that objects frequency in this patch (i.e., with the 
	 * patch specific offsets applied), and stores the results in the supplied array (and array of arrays) */
	private void populateObjectArrays(PatchStateTemplate template, 
			LedgerFactory ledgerFactory,
			Workspace workspace, 
			String objectName, 
			ArrayList<String> arrayListOfNameInLedger, 
			NumberObjectSingle[][] rawProbabilityArrayToUse, 
			NumberObjectSingle[] frequencyArrayToUse,
			NumberObjectSingle[][] probabilitiesWithFrequency,
			int[] nonZeroProbabilityCountToUse
			) {
		try {
			// Get the AbstractObjectiveTemplate from the workspace
			AbstractObjectiveTemplate objectTemplate = workspace.getObject(objectName);

			// Get the index of this object in the Ledger
			int indexOfObject = -1;
			for (int i = 0; i < arrayListOfNameInLedger.size(); i++)
				if (arrayListOfNameInLedger.get(i).equals(objectName))
					indexOfObject = i;
			if (indexOfObject == -1)
				throw new IllegalStateException("Trying to create a probability distribution for object '" + objectName + "'. However, no such object in registered in the ledger yet" );

			// Is the object constant? If so, we only have to register the frequency (if its not an interruption) and a single probability
			if (objectTemplate.isConstant()) {
				rawProbabilityArrayToUse[indexOfObject] = new NumberObjectSingle[] { NumberObject.createNumber(model.howToRepresentNumbers, 1)}; // constants have a single possible value, that occurs with probability 1.
				probabilitiesWithFrequency[indexOfObject] = new NumberObjectSingle[] { NumberObject.createNumber(model.howToRepresentNumbers, 1)}; // constants have a single possible value, that occurs with probability 1.
				nonZeroProbabilityCountToUse[indexOfObject] = 1;
				if (!(objectTemplate instanceof InterruptionObjectTemplate))
					frequencyArrayToUse[indexOfObject] = objectTemplate.getFrequency().clone();
				return;
			}


			// If the object is not constant: get the sampling distribution for this object
			RFunctionContainer samplingDistribution = objectTemplate.getAllSamplingDistributions().get(model.whichSamplingDistributionToUse(objectTemplate));
			NumberObjectSingle frequency = null;

			// Reminder: interruptions do not have frequencies!
			if (!(objectTemplate instanceof InterruptionObjectTemplate))
				frequency = objectTemplate.getFrequency().clone().toNumberObjectSingle(model.howToRepresentNumbers);

			// Is there an offset for this object?
			// If so, change the samplingDistribution and frequency accordingly
			if (!(objectTemplate instanceof InterruptionObjectTemplate))
				if (template.hasFrequencyOffsetFor(objectTemplate)) 
					frequency = template.getOffsettedObject(objectTemplate).getOffsettedFrequency().clone().toNumberObjectSingle(model.howToRepresentNumbers);
			if (template.hasValueOffsetFor(objectTemplate))
				samplingDistribution = template.getOffsettedObject(objectTemplate).getOffsettedValueDistribution(samplingDistribution);

			// Based on the sampling distribution, create the probability distribution of all values
			NumberObjectArray probabilityDistribution = ((NumberObjectArray) samplingDistribution.runInR()[0]).toNumberObjectArray(model.howToRepresentNumbers);
			if (!probabilityDistribution.isProbability())
				throw new IllegalStateException("The distribution of object '" + objectName + "' in patch state '" + template.getName() + "' is not a probability distribution: it does not sum to 1 or there is a negative entry. "
						+ "The distribution is: " + probabilityDistribution.toStringWithoutTrailingZeros() + ". Sum = " + probabilityDistribution.sum().toStringWithoutTrailingZeros() );

			// Count the number of non-zero probabilities
			NumberObjectSingle[] array = (NumberObjectSingle[]) probabilityDistribution.toArray();
			int nonZero = 0;
			for (NumberObjectSingle n:array)
				if (!n.equals(0))
					nonZero += 1;

			// Store in the supplied arrays. Note, again, that interruptions do not have frequencies!
			rawProbabilityArrayToUse[indexOfObject] = array;
			nonZeroProbabilityCountToUse[indexOfObject] = nonZero;
			if (!(objectTemplate instanceof InterruptionObjectTemplate))
				frequencyArrayToUse[indexOfObject] = frequency;

			// Now that we have the raw probabilities, and the frequency, we can compute the probabilitiesWithFrequency.
			if (!(objectTemplate instanceof InterruptionObjectTemplate)) {
			probabilitiesWithFrequency[indexOfObject] = new NumberObjectSingle[array.length];
			for (int i = 0; i < probabilitiesWithFrequency.length; i ++)
				probabilitiesWithFrequency[indexOfObject][i] = rawProbabilityArrayToUse[indexOfObject][i].multiply(frequency, false);
			}
		
		} catch (Exception e) { 
			ObserverManager.notifyObserversOfError(e);
			model.outputFileManager.writeExceptionToFile(e);
		}

	}

	/*
	/** Fills the experience and belief related ArrayLists in the LedgerFactory for all resources.  /
	private void registerResourceBeliefOffsets(PatchStateTemplate template, LedgerFactory ledgerFactory,Workspace workspace) {
		//Yes, it's a lot of copy-and-paste work. Yes, it's nasty. But it works. And I really couldn't be bothered to do this in a smart way.

		// Register beliefs for all resource objects
		for (int i = 0; i < ledgerFactory.resourceNames.size(); i ++ ) {

			//Get the name of the resource
			String resourceName = ledgerFactory.resourceNames.get(i);
			ResourceObjectTemplate resourceTemplate = (ResourceObjectTemplate) workspace.getObject(resourceName);

			// Does the agent learn by experience for this object in this patchState?
			// That is, is there A) a belief offset, and B) is this BeliefOffset learned?
			boolean learnByExperience = false;
			if (template.containsOffsetFor(resourceTemplate.getBelief()))
				learnByExperience = template.getOffsettedBelief(resourceTemplate.getBelief()).isLearned();

			// Exception: learnByExperience is true even without a belief offset if this is the BaseState 
			if (template == BaseState.get() && resourceTemplate.getBelief()!=null)
				if (!resourceTemplate.getBelief().isKnownDistribution())
					learnByExperience = true;

			// Make sure that ledgerFactory.resourceLearnByExperienceInPatchState (which is initialized already by the model)
			// has at least n indices, where n is the index of this patchState
			while (ledgerFactory.resourceLearnByExperienceInPatchState.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.resourceLearnByExperienceInPatchState.get(i).add(null);

			// At the location ledgerIndexOfPatchState: store learnByExperience
			ledgerFactory.resourceLearnByExperienceInPatchState.get(i).set(ledgerIndexOfPatchState, learnByExperience);

			//Make sure that there are enough indices in resourceStartingExperiences to add the prior experiences for this patch state
			while (ledgerFactory.resourceStartingExperiences.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.resourceStartingExperiences.get(i).add(null);

			// if we have to learn by experience, we also have to store the prior experiences in the LedgerFactory
			if (!learnByExperience)
				return;

			// Create a new ArrayList
			ledgerFactory.resourceStartingExperiences.get(i).set(ledgerIndexOfPatchState, new ArrayList<>());

			// Next, if this is the base state: just add the 'normal' (non-offsetted) prior observations
			if (template == BaseState.get()) {
				NumberObjectSingle[] resourceValues = ledgerFactory.resourceValues.get(i);
				for (int v = 0; v < resourceValues.length; v++)
					ledgerFactory.resourceStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
							resourceTemplate.getBelief().getObservedCount(ledgerFactory.resourceValues.get(i)[v].toDecimalNumber()));
				return;
			}

			// If not the base state: get the state specific offset
			BeliefOffset offset = template.getOffsettedBelief(resourceTemplate.getBelief());

			// Feed all possible object values in the LedgerFactory for this object into the offset, and store the result 
			for (int v = 0; v < ledgerFactory.resourceValues.get(i).length; v++)
				ledgerFactory.resourceStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
						offset.getPatchSpecificObservations(ledgerFactory.resourceValues.get(i)[v].toDecimalNumber()));
		}
	}

	/** Fills the experience and belief related ArrayLists in the LedgerFactory for all extrinsic events.  /
	private void registerExtrinsicBeliefOffsets(PatchStateTemplate template, LedgerFactory ledgerFactory,Workspace workspace) {
		// Register beliefs for all extrinsic objects
		for (int i = 0; i < ledgerFactory.extrinsicNames.size(); i ++ ) {

			//Get the name of the extrinsic event
			String extrinsicName = ledgerFactory.extrinsicNames.get(i);
			ExtrinsicObjectTemplate extrinsicTemplate = (ExtrinsicObjectTemplate) workspace.getObject(extrinsicName);

			// Does the agent learn by experience for this object in this patchState?
			// That is, is there A) a belief offset, and B) is this BeliefOffset learned?
			boolean learnByExperience = false;
			if (template.containsOffsetFor(extrinsicTemplate.getBelief()))
				learnByExperience = template.getOffsettedBelief(extrinsicTemplate.getBelief()).isLearned();

			// Exception: learnByExperience is true even without a belief offset if this is the BaseState 
			if (template == BaseState.get() && extrinsicTemplate.getBelief()!=null)
				if (!extrinsicTemplate.getBelief().isKnownDistribution())
					learnByExperience = true;

			// Make sure that ledgerFactory.extrinsicLearnByExperienceInPatchState (which is initialized already by the model)
			// has at least n indices, where n is the index of this patchState
			while (ledgerFactory.extrinsicLearnByExperienceInPatchState.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.extrinsicLearnByExperienceInPatchState.get(i).add(null);

			// At the location ledgerIndexOfPatchState: store learnByExperience
			ledgerFactory.extrinsicLearnByExperienceInPatchState.get(i).set(ledgerIndexOfPatchState, learnByExperience);

			// Make sure that there are enough indices in extrinsicStartingExperiences to add the prior experiences for this patch state
			while (ledgerFactory.extrinsicStartingExperiences.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.extrinsicStartingExperiences.get(i).add(null);

			// if we have to learn by experience, we also have to store the prior experiences in the LedgerFactory
			if (!learnByExperience)
				return;

			// Create a new ArrayList
			ledgerFactory.extrinsicStartingExperiences.get(i).set(ledgerIndexOfPatchState, new ArrayList<>());

			// Next, if this is the base state: just add the 'normal' (non-offsetted) prior observations
			if (template == BaseState.get()) {
				NumberObjectSingle[] extrinsicValues = ledgerFactory.extrinsicValues.get(i);
				for (int v = 0; v < extrinsicValues.length; v++)
					ledgerFactory.extrinsicStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
							extrinsicTemplate.getBelief().getObservedCount(ledgerFactory.extrinsicValues.get(i)[v].toDecimalNumber()));
				return;
			}

			// If not the base state: get the state specific offset
			BeliefOffset offset = template.getOffsettedBelief(extrinsicTemplate.getBelief());

			// Feed all possible object values in the LedgerFactory for this object into the offset, and store the result 
			for (int v = 0; v < ledgerFactory.extrinsicValues.get(i).length; v++)
				ledgerFactory.extrinsicStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
						offset.getPatchSpecificObservations(ledgerFactory.extrinsicValues.get(i)[v].toDecimalNumber()));
		}
	}

	/** Fills the experience and belief related ArrayLists in the LedgerFactory for all delays.  /
	private void registerDelayBeliefOffsets(PatchStateTemplate template, LedgerFactory ledgerFactory,Workspace workspace) {

		// Register beliefs for all delay objects
		for (int i = 0; i < ledgerFactory.delayNames.size(); i ++ ) {

			//Get the name of the delay
			String delayName = ledgerFactory.delayNames.get(i);
			DelayObjectTemplate delayTemplate = (DelayObjectTemplate) workspace.getObject(delayName);

			// Does the agent learn by experience for this object in this patchState?
			// That is, is there A) a belief offset, and B) is this BeliefOffset learned?
			boolean learnByExperience = false;
			if (template.containsOffsetFor(delayTemplate.getBelief()))
				learnByExperience = template.getOffsettedBelief(delayTemplate.getBelief()).isLearned();

			// Exception: learnByExperience is true even without a belief offset if this is the BaseState 
			if (template == BaseState.get() && delayTemplate.getBelief()!=null)
				if (!delayTemplate.getBelief().isKnownDistribution())
					learnByExperience = true;

			// Make sure that ledgerFactory.delayLearnByExperienceInPatchState (which is initialized already by the model)
			// has at least n indices, where n is the index of this patchState
			while (ledgerFactory.delayLearnByExperienceInPatchState.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.delayLearnByExperienceInPatchState.get(i).add(null);

			// At the location ledgerIndexOfPatchState: store learnByExperience
			ledgerFactory.delayLearnByExperienceInPatchState.get(i).set(ledgerIndexOfPatchState, learnByExperience);

			// Make sure that there are enough indices in delayStartingExperiences to add the prior experiences for this patch state 
			while (ledgerFactory.delayStartingExperiences.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.delayStartingExperiences.get(i).add(null);

			// if we have to learn by experience, we also have to store the prior experiences in the LedgerFactory
			if (!learnByExperience)
				return;

			// Create a new ArrayList
			ledgerFactory.delayStartingExperiences.get(i).set(ledgerIndexOfPatchState, new ArrayList<>());

			// Next, if this is the base state: just add the 'normal' (non-offsetted) prior observations
			if (template == BaseState.get()) {
				Integer[] delayValues = ledgerFactory.delayValues.get(i);
				for (int v = 0; v < delayValues.length; v++)
					ledgerFactory.delayStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
							delayTemplate.getBelief().getObservedCount( new DecimalNumber(ledgerFactory.delayValues.get(i)[v])));
				return;
			}

			// If not the base state: get the state specific offset
			BeliefOffset offset = template.getOffsettedBelief(delayTemplate.getBelief());

			// Feed all possible object values in the LedgerFactory for this object into the offset, and store the result 
			for (int v = 0; v < ledgerFactory.delayValues.get(i).length; v++)
				ledgerFactory.delayStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
						offset.getPatchSpecificObservations(new DecimalNumber(ledgerFactory.delayValues.get(i)[v])));
		}

	}

	/** Fills the experience and belief related ArrayLists in the LedgerFactory for all interruptions.  /
	private void registerInterruptionBeliefOffsets(PatchStateTemplate template, LedgerFactory ledgerFactory,Workspace workspace) {
		// Register beliefs for all interruption objects
		for (int i = 0; i < ledgerFactory.interruptionNames.size(); i ++ ) {

			//Get the name of the interruption
			String interruptionName = ledgerFactory.interruptionNames.get(i);
			InterruptionObjectTemplate interruptionTemplate = (InterruptionObjectTemplate) workspace.getObject(interruptionName);

			// Does the agent learn by experience for this object in this patchState?
			// That is, is there A) a belief offset, and B) is this BeliefOffset learned?
			boolean learnByExperience = false;
			if (template.containsOffsetFor(interruptionTemplate.getBelief()))
				learnByExperience = template.getOffsettedBelief(interruptionTemplate.getBelief()).isLearned();

			// Exception: learnByExperience is true even without a belief offset if this is the BaseState 
			if (template == BaseState.get() && interruptionTemplate.getBelief()!=null)
				if (!interruptionTemplate.getBelief().isKnownDistribution())
					learnByExperience = true;

			// Make sure that ledgerFactory.interruptionLearnByExperienceInPatchState (which is initialized already by the model)
			// has at least n indices, where n is the index of this patchState
			while (ledgerFactory.interruptionLearnByExperienceInPatchState.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.interruptionLearnByExperienceInPatchState.get(i).add(null);

			// At the location ledgerIndexOfPatchState: store learnByExperience
			ledgerFactory.interruptionLearnByExperienceInPatchState.get(i).set(ledgerIndexOfPatchState, learnByExperience);

			// Make sure that there are enough indices in interruptionStartingExperiences to add the prior experiences for this patch state
			while (ledgerFactory.interruptionStartingExperiences.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.interruptionStartingExperiences.get(i).add(null);


			// if we have to learn by experience, we also have to store the prior experiences in the LedgerFactory
			if (!learnByExperience)
				return;

			// Create a new ArrayList
			ledgerFactory.interruptionStartingExperiences.get(i).set(ledgerIndexOfPatchState, new ArrayList<>());

			// Next, if this is the base state: just add the 'normal' (non-offsetted) prior observations
			Integer[] interruptionValues = new Integer[] {0, 1};
			if (template == BaseState.get()) {
				for (int v = 0; v < interruptionValues.length; v++)
					ledgerFactory.interruptionStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
							interruptionTemplate.getBelief().getObservedCount(new DecimalNumber( interruptionValues[v])));
				return;
			}

			// If not the base state: get the state specific offset
			BeliefOffset offset = template.getOffsettedBelief(interruptionTemplate.getBelief());

			// Feed all possible object values in the LedgerFactory for this object into the offset, and store the result 
			for (int v = 0; v < interruptionValues.length; v++)
				ledgerFactory.interruptionStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
						offset.getPatchSpecificObservations(new DecimalNumber (interruptionValues[v])));
		}
	}
	*/


	///////////// Functions to extract probabilities from the patch
	/// Functions that return probabilities or probability distributions - used for models that explore the complete state-space
	/**Returns the raw resource probabilities: the probability distribution of a resource
	 * value in this patch state, ASSUMING that there is a resource that was encountered. Result
	 * is indexed by [resource value index]*/
	public NumberObjectSingle[] getResourceValueProbabilityNotFrequencyAdjusted (int resourceIndex){
		return this.rawResourceValueProbabilities[resourceIndex];
	}
	/**Returns the frequency-adjusted resource probabilities: the probability distribution of a resource
	 * value in this patch state, taking into account that a resource might not have been encountered. If
	 * and only if the frequency is not 1, this distribution does not sum to 1. Result
	 * is indexed by [resource value index]*/
	public NumberObjectSingle[] getFrequencyAdjustedResourceValueProbability (int resourceIndex){
		return this.resourceValueProbability[resourceIndex];
	}
	/**Returns the frequency of a resource in this patch state. Result
	 * is indexed by [resource value index]*/
	public NumberObjectSingle getResourceFrequency (int resourceIndex){
		return this.resourceFrequencies[resourceIndex];
	}
	
	/**Returns the probability that an interruption occurs in this patch state. Result
	 * is indexed by [true, false]*/
	public NumberObjectSingle[] getInterruptionProbability (int interruptionIndex){
		return this.interruptionProbabilities[interruptionIndex];
	}
	
	/**Returns the raw delay probabilities: the probability distribution of a delay 
	 * duration in this patch state, ASSUMING that there is a delay was encountered. Result
	 * is indexed by [delay value index]*/
	public NumberObjectSingle[] getDelayDurationProbabilityNotFrequencyAdjusted (int delayIndex){
		return this.rawDelayDurationProbabilities[delayIndex];
	}
	/**Returns the frequency-adjusted delay probabilities: the probability distribution of a delay
	 * duration in this patch state, taking into account that a delay might not have been encountered. If
	 * and only if the frequency is not 1, this distribution does not sum to 1. Result
	 * is indexed by [delay duration index]*/
	public NumberObjectSingle[] getFrequencyAdjustedDelayDurationProbability (int delayIndex){
		return this.delayDurationProbability[delayIndex];
	}
	/**Returns the frequency of a delay in this patch state. Result
	 * is indexed by [delay index]*/
	public NumberObjectSingle getDelayFrequency (int delayIndex){
		return this.delayFrequencies[delayIndex];
	}
	
	/**Returns the raw extrinsic probabilities: the probability distribution of an extrinsic event
	 * value in this patch state, ASSUMING that there is an extrinsic event was encountered. Result
	 * is indexed by [extrinsic value index]*/
	public NumberObjectSingle[] getExtrinsicEventValueProbabilityNotFrequencyAdjusted (int extrinsicIndex){
		return this.rawExtrinsicEventValueProbabilities[extrinsicIndex];
	}
	/**Returns the frequency-adjusted extrinsic probabilities: the probability distribution of an extrinsic event 
	 * value in this patch state, taking into account that an extrinsic event might not have been encountered. If
	 * and only if the frequency is not 1, this distribution does not sum to 1. Result
	 * is indexed by [extrinsic value index]*/
	public NumberObjectSingle[] getFrequencyAdjustedExtrinsicEventValueProbability (int extrinsicIndex){
		return this.extrinsicEventValueProbability[extrinsicIndex];
	}
	/**Returns the frequency of an extrinsic event in this patch state. Result
	 * is indexed by [extrinsic index]*/
	public NumberObjectSingle getExtrinsicEventFrequency (int extrinsicIndex){
		return this.extrinsicEventFrequencies[extrinsicIndex];
	}
	
	//// Functions that returns single values, durations, or booleans - used for models that simulate individual trials
	/** Sample a resource value of specified type, assuming that such a resource has been encountered. 
	 * Returns the index of the value of this resource, which is drawn from the probability distribution of this resource type in this patch state */
	public int getNextResourceValueAssumingResourceEncountered(int resourceIndex) {
		return RandomNumberGenerator.sampleFromDistribution(model.howToRepresentNumbers, this.rawResourceValueProbabilities[resourceIndex]);
	}
	
	/** Sample a resource value of specified type, WITHOUT assuming that such a resource has been encountered. 
	 * If there is no resource of that type, this function returns -1. Otherwise, returns the index of the 
	 * value of this resource, which is drawn from the probability distribution of this resource type in this patch state */
	public int getNextResourceValueWhenNotYetEncountered(int resourceIndex) {
		if (RandomNumberGenerator.sampleBernoulliTrial(this.resourceFrequencies[resourceIndex]))
			return getNextResourceValueAssumingResourceEncountered(resourceIndex);
		return -1;
	}
	
	/** Sample whether an interruption value of specified type. Whether this interruption occurs is 
	 * drawn from the probability distribution of this resource type in this patch state */
	public boolean getNextInterruption(int interruptionIndex) {
		return RandomNumberGenerator.sampleBernoulliTrial(this.interruptionProbabilities[interruptionIndex][0]);
	}
	
	/** Sample a delay duration specified delay type, assuming that such a delay has been encountered. 
	 * Returns the index of the duration of this delay, which is drawn from the probability distribution of this delay duration in this patch state */
	public int getNextDelayDurationAssumingDelayEncountered(int delayIndex) {
		return RandomNumberGenerator.sampleFromDistribution(model.howToRepresentNumbers, this.rawDelayDurationProbabilities[delayIndex]);
	}
	
	/** Sample a delay duration of specified type, WITHOUT assuming that such a delay has been encountered. 
	 * If there is no delay of that type (i.e., if the delay is not present), this function returns -1. Otherwise, returns the index of the 
	 * duration of this delay, which is drawn from the probability distribution of this delay durations type in this patch state */
	public int getNextDelayDurationWhenNotYetEncountered(int delayIndex) {
		if (RandomNumberGenerator.sampleBernoulliTrial(this.delayFrequencies[delayIndex]))
			return getNextDelayDurationAssumingDelayEncountered(delayIndex);
		return -1;
	}
	
	/** Sample an extrinsic event value of specified type, assuming that such an extrinsic has been encountered. 
	 * Returns the index of the value of this extrinsic event, which is drawn from the probability distribution of this event type in this patch state */
	public int getNextExtrinsicEventValueAssumingExtrinsicEventEncountered(int extrinsicIndex) {
		return RandomNumberGenerator.sampleFromDistribution(model.howToRepresentNumbers, this.rawExtrinsicEventValueProbabilities[extrinsicIndex]);
	}
	
	/** Sample an extrinsic event value of specified type, WITHOUT assuming that such an extrinsic event has been encountered. 
	 * If there is no extrinsic event of that type, this function returns -1. Otherwise, returns the index of the 
	 * value of this event, which is drawn from the probability distribution of this extrinsic event type in this patch state */
	public int getNextExtrinsicEventValueWhenNotYetEncountered(int extrinsicIndex) {
		if (RandomNumberGenerator.sampleBernoulliTrial(this.extrinsicEventFrequencies[extrinsicIndex]))
			return getNextExtrinsicEventValueAssumingExtrinsicEventEncountered(extrinsicIndex);
		return -1;
	}
	
	//// Other functions
	/** Set all NumberObjects's in this Patch to immutable, preventing accidental future changes*/
	public void makeImmutable() {
		// Resources
		for (int i = 0; i < rawResourceValueProbabilities.length ; i++)
			for (int j = 0; j < rawResourceValueProbabilities[i].length; j++)
				rawResourceValueProbabilities[i][j].makeImmutable();
		for (int i = 0; i < resourceFrequencies.length ; i++)
			resourceFrequencies[i].makeImmutable();
		for (int i = 0; i < resourceValueProbability.length ; i++)
			for (int j = 0; j < resourceValueProbability[i].length; j++)
				resourceValueProbability[i][j].makeImmutable();
		
		// Delays
		for (int i = 0; i < rawDelayDurationProbabilities.length ; i++)
			for (int j = 0; j < rawDelayDurationProbabilities[i].length; j++)
				rawDelayDurationProbabilities[i][j].makeImmutable();
		for (int i = 0; i < delayFrequencies.length ; i++)
			delayFrequencies[i].makeImmutable();
		for (int i = 0; i < delayDurationProbability.length ; i++)
			for (int j = 0; j < delayDurationProbability[i].length; j++)
				delayDurationProbability[i][j].makeImmutable();
		
		// Interruptions
		for (int i = 0; i < interruptionProbabilities.length ; i++)
			for (int j = 0; j < interruptionProbabilities[i].length; j++)
				interruptionProbabilities[i][j].makeImmutable();

		// Extrinsic events
		for (int i = 0; i < rawExtrinsicEventValueProbabilities.length ; i++)
			for (int j = 0; j < rawExtrinsicEventValueProbabilities[i].length; j++)
				rawExtrinsicEventValueProbabilities[i][j].makeImmutable();
		for (int i = 0; i < extrinsicEventFrequencies.length ; i++)
			extrinsicEventFrequencies[i].makeImmutable();
		for (int i = 0; i < extrinsicEventValueProbability.length ; i++)
			for (int j = 0; j < extrinsicEventValueProbability[i].length; j++)
				extrinsicEventValueProbability[i][j].makeImmutable();

	}
	
	
	public String toString() {
		StringBuilder sb = new StringBuilder("Patch [" + ledgerIndexOfPatch + "], state [" + ledgerIndexOfPatchState + "]");

		sb.append("\n-Resources \n\tRaw Probabilities:");
		for (int i = 0; i < rawResourceValueProbabilities.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(rawResourceValueProbabilities[i]));
		sb.append("\n\tFrequencies:");
		for (int i = 0; i < resourceFrequencies.length; i++)
			sb.append("\n\t["+i+"]:\t" + resourceFrequencies[i].toStringWithoutTrailingZeros());
		sb.append("\n\tFrequency adjusted probabilities:");
		for (int i = 0; i < resourceValueProbability.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(resourceValueProbability[i]));

		sb.append("\n\n-Interruptions \n\tProbabilities:");
		for (int i = 0; i < interruptionProbabilities.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(interruptionProbabilities[i]));

		sb.append("\n\n-Delays \n\tRaw Probabilities:");
		for (int i = 0; i < rawDelayDurationProbabilities.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(rawDelayDurationProbabilities[i]));
		sb.append("\n\tFrequencies:");
		for (int i = 0; i < delayFrequencies.length; i++)
			sb.append("\n\t["+i+"]:\t" + delayFrequencies[i].toStringWithoutTrailingZeros());
		sb.append("\n\tFrequency adjusted probabilities:");
		for (int i = 0; i < delayDurationProbability.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(delayDurationProbability[i]));
		

		sb.append("\n\n-Extrinsic events \n\tRaw Probabilities:");
		for (int i = 0; i < rawExtrinsicEventValueProbabilities.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(rawExtrinsicEventValueProbabilities[i]));
		sb.append("\n\tFrequencies:");
		for (int i = 0; i < extrinsicEventFrequencies.length; i++)
			sb.append("\n\t["+i+"]:\t" + extrinsicEventFrequencies[i].toStringWithoutTrailingZeros());
		sb.append("\n\tFrequency adjusted probabilities:");
		for (int i = 0; i < extrinsicEventValueProbability.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(extrinsicEventValueProbability[i]));
		return sb.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(resourceFrequencies);
		result = prime * result + Arrays.deepHashCode(rawResourceValueProbabilities);
		result = prime * result + Arrays.hashCode(delayFrequencies);
		result = prime * result + Arrays.deepHashCode(rawDelayDurationProbabilities);
		result = prime * result + Arrays.hashCode(extrinsicEventFrequencies);
		result = prime * result + Arrays.deepHashCode(rawExtrinsicEventValueProbabilities);
		result = prime * result + Arrays.deepHashCode(interruptionProbabilities);
		result = prime * result + ledgerIndexOfPatch;
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		PatchState other = (PatchState) obj;
		
		if (!Arrays.deepEquals(rawResourceValueProbabilities, other.rawResourceValueProbabilities)) {
			return false;
		}
		
		if (!Arrays.equals(resourceFrequencies, other.resourceFrequencies)) {
			return false;
		}
		
		if (!Arrays.equals(resourceValueProbability, other.resourceValueProbability)) {
			return false;
		}
		
		if (!Arrays.deepEquals(interruptionProbabilities, other.interruptionProbabilities)) {
			return false;
		}
		
		if (!Arrays.deepEquals(rawDelayDurationProbabilities, other.rawDelayDurationProbabilities)) {
			return false;
		}
		
		if (!Arrays.equals(delayFrequencies, other.delayFrequencies)) {
			return false;
		}
		if (!Arrays.deepEquals(delayDurationProbability, other.delayDurationProbability)) {
			return false;
		}
		if (!Arrays.equals(extrinsicEventFrequencies, other.extrinsicEventFrequencies)) {
			return false;
		}
		if (!Arrays.deepEquals(rawExtrinsicEventValueProbabilities, other.rawExtrinsicEventValueProbabilities)) {
			return false;
		}
		
		if (ledgerIndexOfPatch != other.ledgerIndexOfPatch) {
			return false;
		}
		
		
		return true;
	}
}
