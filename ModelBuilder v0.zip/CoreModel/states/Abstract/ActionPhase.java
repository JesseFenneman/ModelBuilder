package states.Abstract;

public interface ActionPhase extends Phase{

}
