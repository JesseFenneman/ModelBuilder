package states.Abstract;
import core.AbstractModel;
import helper.Helper;
import states.phenotypeSlot.CaptiveSlot;
import states.phenotypeSlot.DelayedSlot;
import states.phenotypeSlot.RecurringSlot;

/** States have many fields, which makes it annoying to 
 * create them via a usual constructor. Especially so if we
 * want to create a new state that is based on a previous state
 * but has one difference (e.g., if only the age increases).
 * Hence this Factory pattern; this factory can be passed to a state
 * during construction.*/
public class AbstractStateFactory {
	public final AbstractModel model;

	public int age;
	public int locationPatchState;
	public int locationPatch;
	public int[] lastVisitToPatch; // [location]
	public int[] patchStateOfLastVisit; // patch
	public int[] phenotypicDimensions;
	public CaptiveSlot[] captiveSlots;
	public DelayedSlot[] delayedSlots;
	public RecurringSlot[] recurringSlots;
	
	public int[][][] resourceExperiences; 		
	public int[][][] extrinsicExperiences; 		
	public int[][][] interruptionExperiences;   
	public int[][][] delayExperiences; 		

	
	
	/** Construct a factory with all fields null or -1.  */
	public AbstractStateFactory(AbstractModel model) {
		this.model = model;
		age = -1;
		locationPatchState = -1;
		locationPatch = -1;
		lastVisitToPatch = null;
		patchStateOfLastVisit = null;
		phenotypicDimensions= null;
		captiveSlots = null;
		delayedSlots = null;
		recurringSlots = null;
		resourceExperiences = null;
		extrinsicExperiences = null;
		delayExperiences = null;
		interruptionExperiences = null;
	}
	
	/** Clone all fields in the existing T1StateFactory to create a new T1StateFactory. 
	 * Fields can be copied by reference (deepClone == false) or by value (deepClone == true)*/
	public AbstractStateFactory (AbstractStateFactory factory, boolean deepClone) {
		model = factory.model;
		age = factory.age;
		
		// Copy primitives
		locationPatchState = factory.locationPatchState;
		locationPatch = factory.locationPatch;
		
		if (!deepClone) {
			// Copy by reference
			lastVisitToPatch = factory.lastVisitToPatch;
			patchStateOfLastVisit = factory.patchStateOfLastVisit;
			phenotypicDimensions = factory.phenotypicDimensions;
			
			captiveSlots = factory.captiveSlots;
			recurringSlots = factory.recurringSlots;
			delayedSlots = factory.delayedSlots;
			
			resourceExperiences = factory.resourceExperiences;
			extrinsicExperiences = factory.extrinsicExperiences;
			interruptionExperiences = factory.interruptionExperiences;
			delayExperiences = factory.delayExperiences;	
		} else {
			// Deepclone all arrays
			if (factory.lastVisitToPatch==null)
				lastVisitToPatch = null;
			else {
				lastVisitToPatch = new int[factory.lastVisitToPatch.length];
				System.arraycopy(factory.lastVisitToPatch, 0, lastVisitToPatch, 0, factory.lastVisitToPatch.length);
			}
			if (factory.patchStateOfLastVisit == null)
				patchStateOfLastVisit = null;
			else{
				patchStateOfLastVisit = new int[factory.patchStateOfLastVisit.length];
				System.arraycopy(factory.patchStateOfLastVisit, 0, patchStateOfLastVisit, 0, factory.patchStateOfLastVisit.length);
			}

			if (factory.phenotypicDimensions == null)
				phenotypicDimensions = null;
			else {
				phenotypicDimensions = new int[factory.phenotypicDimensions.length];
				System.arraycopy(factory.phenotypicDimensions, 0, phenotypicDimensions, 0, factory.phenotypicDimensions.length);
			}

			if (factory.captiveSlots == null)
				captiveSlots = null;
			else {
				captiveSlots = new CaptiveSlot[factory.captiveSlots.length];
				for (int i = 0; i < captiveSlots.length; i ++)
					captiveSlots[i] = (CaptiveSlot) factory.captiveSlots[i].deepClone();
			}
			
			if (factory.delayedSlots == null)
				delayedSlots = null;
			else {
				delayedSlots = new DelayedSlot[factory.delayedSlots.length];
				for (int i = 0; i < captiveSlots.length; i ++)
					delayedSlots[i] = (DelayedSlot) factory.delayedSlots[i].deepClone();
			}
			
			if (factory.recurringSlots == null)
				recurringSlots = null;
			else {
				recurringSlots = new RecurringSlot[factory.recurringSlots.length];
				for (int i = 0; i < captiveSlots.length; i ++)
					recurringSlots[i] = (RecurringSlot) factory.recurringSlots[i].deepClone();
			}
			
			// Copy experiences- NOT IMPLEMENTED YET 
			/*
			resourceExperiences = new int[factory.resourceExperiences.length][][];
			extrinsicExperiences = new int[factory.extrinsicExperiences.length][][];
			interruptionExperiences = new int[factory.interruptionExperiences.length][][];
			delayExperiences = new int[factory.delayExperiences.length][][];
			
			for (int patch = 0; patch < resourceExperiences.length; patch++) {
				
				for (int resource = 0; resource < resourceExperiences[patch].length; resource++)
					System.arraycopy(factory.resourceExperiences[patch][resource], 		0, resourceExperiences[patch][resource], 		0, factory.resourceExperiences[patch][resource].length);
				
				for (int extrinsic = 0; extrinsic < extrinsicExperiences[patch].length; extrinsic++)
					System.arraycopy(factory.extrinsicExperiences[patch][extrinsic], 	0, extrinsicExperiences[patch][extrinsic], 	0, factory.extrinsicExperiences[patch][extrinsic].length);
				
				for (int interruption = 0; interruption < interruptionExperiences[patch].length; interruption++)
					System.arraycopy(factory.interruptionExperiences[patch][interruption], 	0, interruptionExperiences[patch][interruption],	0, factory.interruptionExperiences[patch][interruption].length);
				
				for (int delay = 0; delay < delayExperiences[patch].length; delay ++)
					System.arraycopy(factory.delayExperiences[patch][delay], 		0, delayExperiences[patch][delay], 		0, factory.delayExperiences[patch][delay].length);
			}*/
		}
	}
	
	/** Set all fields in the factory to match the specified T1State (all fields are deep clones). */
	public AbstractStateFactory (AbstractState s) {
		model = s.getModel();
		age = s.age;
		locationPatchState = s.locationPatchState;
		locationPatch = s.locationPatch;
		
		lastVisitToPatch = new int[s.lastVisitToPatch.length];
		System.arraycopy(s.lastVisitToPatch, 0, lastVisitToPatch, 0, s.lastVisitToPatch.length);
		
		patchStateOfLastVisit = new int[s.patchStateOfLastVisit.length];
		System.arraycopy(s.patchStateOfLastVisit, 0, patchStateOfLastVisit, 0, s.patchStateOfLastVisit.length);
		
		phenotypicDimensions = new int[s.phenotypicDimensions.length];
		System.arraycopy(s.phenotypicDimensions, 0, phenotypicDimensions, 0, s.phenotypicDimensions.length);
		
		// Copy experiences - not implemented yet
		/*resourceExperiences = new int[s.resourceExperiences.length][][];
		extrinsicExperiences = new int[s.extrinsicExperiences.length][][];
		interruptionExperiences = new int[s.interruptionExperiences.length][][];
		delayExperiences = new int[s.delayExperiences.length][][];
		
		for (int patch = 0; patch < resourceExperiences.length; patch++) {
			
			for (int resource = 0; resource < resourceExperiences[patch].length; resource++)
				System.arraycopy(s.resourceExperiences[patch][resource], 		0, resourceExperiences[patch][resource], 		0, s.resourceExperiences[patch][resource].length);
			
			for (int extrinsic = 0; extrinsic < extrinsicExperiences[patch].length; extrinsic++)
				System.arraycopy(s.extrinsicExperiences[patch][extrinsic], 	0, extrinsicExperiences[patch][extrinsic], 	0, s.extrinsicExperiences[patch][extrinsic].length);
			
			for (int interruption = 0; interruption < interruptionExperiences[patch].length; interruption++)
				System.arraycopy(s.interruptionExperiences[patch][interruption], 	0, interruptionExperiences[patch][interruption],	0, s.interruptionExperiences[patch][interruption].length);
			
			for (int delay = 0; delay < delayExperiences[patch].length; delay ++)
				System.arraycopy(s.delayExperiences[patch][delay], 		0, delayExperiences[patch][delay], 		0, s.delayExperiences[patch][delay].length);
		}
		*/
		
	}

	/** Set the age. Returns this.*/
	public AbstractStateFactory setAge(int age) { this.age = age; return this;}
	
	/** Increments the age with one. Returns this.*/
	public AbstractStateFactory incrementAge() { this.age++; return this;}
	
	/** Set the patch state location. Returns this.*/
	public AbstractStateFactory setLocation(int locationPatch, int locationPatchState) { 
		this.locationPatch = locationPatch; this.locationPatchState = locationPatchState; return this;
		}
	
	/** Set the time steps since last visit to patchIndex. Returns this.*/
	public AbstractStateFactory setTimeSinceLastVisit(int patchIndex, int timeSteps) { lastVisitToPatch[patchIndex] = timeSteps; return this;}
	
	/** Set the time steps since last visit to patchIndex to 0. Returns this.*/
	public AbstractStateFactory resetTimeSinceLastVisit(int patchIndex) { lastVisitToPatch[patchIndex] = 0; return this;}

	/** Initialized the time steps since last visit array, and sets the value for all patches to -1. 
	 * Also initializes the last-seen state for each patches to an array of -1's.
	 * Returns this.*/
	public AbstractStateFactory initializePatchHistory() { 
		this.lastVisitToPatch = new int[model.ledger.numberOfPatches];
		this.patchStateOfLastVisit = new int[model.ledger.numberOfPatches];
		for (int patchIndex = 0; patchIndex < model.ledger.numberOfPatches; patchIndex++) {
			lastVisitToPatch[patchIndex] = -1; 
			patchStateOfLastVisit[patchIndex] = -1;
		}

		return this;
	}

	
	/** Increments the time steps since last visit to all patches an agent is currently not in with 1.
	 * Note: patches where the last time is of value -1 are never visited yet. Hence, these values are
	 * not changed. Returns this.*/
	public AbstractStateFactory incrementTimeSinceLastVisitAllPatches() { 
		for (int i = 0; i < lastVisitToPatch.length; i++)
			if (this.locationPatch != i)
				if (lastVisitToPatch[i] != -1)
					lastVisitToPatch[i]++; 
		return this;
	}

	/** Set the last observed patch state of the patchIndex to the patchStateIndex. Returns this.*/
	public AbstractStateFactory setPatchStateInLastVisit( int patchIndex, int patchStateIndex) {
		this.patchStateOfLastVisit[patchIndex] = patchStateIndex;
		return this;
	}
	
	/** Initializes all the phenotypicDimensions arrays, and set each phenotypicDimensions to the specified value. Returns this.*/
	public AbstractStateFactory initializephenotypicDimensions(int... phenotypicDimensionsIndices) {
		this.phenotypicDimensions = new int[model.ledger.numberOfNonAgePhenotypicDimensions];
		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++)
			phenotypicDimensions[i] = phenotypicDimensionsIndices[i];
		return this;
	}
	/** Change the valueIndex of the phenotypicDimensionsIndex with the specified numbers. This function
	 * makes sure that the valueIndex can never be smaller than 0 or larger than the maximum value.
	 * Returns this.*/
	public AbstractStateFactory changephenotypicDimensionsByIndexAmounts(int phenotypicDimensionsIndex, int indexAmount) {
		this.phenotypicDimensions[phenotypicDimensionsIndex] = phenotypicDimensions[phenotypicDimensionsIndex] + indexAmount;
		if (phenotypicDimensions[phenotypicDimensionsIndex] < 0)
			phenotypicDimensions[phenotypicDimensionsIndex] = 0;
		if (phenotypicDimensions[phenotypicDimensionsIndex] >= model.ledger.phenotypicDimensionValues[phenotypicDimensionsIndex].length)
			phenotypicDimensions[phenotypicDimensionsIndex] = model.ledger.phenotypicDimensionValues[phenotypicDimensionsIndex].length-1;
		return this;
	}
	
	/** Returns true if the state that comes out of the factory, with the present factory settings, matches at least one DeathCondition */
	public boolean resultsInDeadState() {
		return model.ledger.grimReaper.willBeCulled(this);
	}
	
	/** Returns true only if all fields have been initialised.*/
	public boolean isComplete() {
		if (age ==-1)						return false;
		if (locationPatchState == -1)		return false;
		if (locationPatch == -1)			return false;
		if (lastVisitToPatch==null)			return false;
		if (patchStateOfLastVisit==null)	return false;
		if (phenotypicDimensions==null)		return false;
		if (captiveSlots == null)			return false;
		if (delayedSlots == null)			return false;
		if (recurringSlots == null)			return false;
		//if (resourceExperiences==null)		return false;
		//if (extrinsicExperiences==null)		return false;
		//if (delayExperiences==null)			return false;
		//if (interruptionExperiences==null)	return false;
		return true;
	}
	
	
	public String toString(String header) {
		StringBuilder sb = new StringBuilder(header);
		sb.append("\nAge: " + this.age);
		sb.append("\nphenotypicDimensions: " + Helper.arrayToString(this.phenotypicDimensions));
		sb.append("\nLocation: [p" + this.locationPatch +",s" + this.locationPatchState + "]");
		sb.append("\nLast visits: " + Helper.arrayToString(this.lastVisitToPatch));
		sb.append("\nLast States: " + Helper.arrayToString(this.patchStateOfLastVisit));
		sb.append("\nCaptive slots: ");
		if (this.captiveSlots.length==0)
			sb.append("\n\t(None)");
		else 
			for (int i = 0; i < captiveSlots.length; i++)
				sb.append("\n\t["+i+ "]: " + captiveSlots[i]);
		if (this.delayedSlots.length==0)
			sb.append("\n\t(None)");
		else 
			for (int i = 0; i < delayedSlots.length; i++)
				sb.append("\n\t["+i+ "]: " + delayedSlots[i]);
		
		if (this.recurringSlots.length==0)
			sb.append("\n\t(None)");
		else 
			for (int i = 0; i < recurringSlots.length; i++)
				sb.append("\n\t["+i+ "]: " + recurringSlots[i]);
		return sb.toString();
	}
	
	@Override
	public int hashCode() {
		return AbstractState.generateHash(this);
	}
}
