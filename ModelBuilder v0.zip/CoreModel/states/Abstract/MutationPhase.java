package states.Abstract;


public interface MutationPhase extends Phase{

}
