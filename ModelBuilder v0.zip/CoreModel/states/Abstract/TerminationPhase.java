package states.Abstract;

public interface TerminationPhase extends Phase{

}
