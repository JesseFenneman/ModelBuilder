package states.Abstract;

import core.AbstractModel;

/** During runtime, each model needs to keep track of a
 * collection of States. As there can be many states,
 * it is better to organize this collection centrally.
 * In additional, each model has to avoid state aliassing;
 * which occurs if two states are identical, but*/
public class StateManager {

	public final AbstractModel model;
	
	
}
