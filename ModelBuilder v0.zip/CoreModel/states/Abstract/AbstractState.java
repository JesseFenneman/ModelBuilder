package states.Abstract;

import java.io.Serializable;
import java.util.Arrays;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.AbstractModel;
import decimalNumber.DecimalNumber;
import helper.Helper;
import states.EncounterStates.T2AbstractState;
import states.RoamingStates.T1AbstractState;
import states.RoamingStates.T1AbstractStateFactory;
import states.RoamingStates.T1FitnessState;
import states.RoamingStates.T1FitnessStateFactory;
import states.phenotypeSlot.CaptiveSlot;
import states.phenotypeSlot.DelayedSlot;
import states.phenotypeSlot.RecurringSlot;


public abstract class AbstractState implements Serializable {

	private static final long serialVersionUID = Helper.programmeVersion;

	///////////// Fields that are set upon the creation of a State /////////////

	// A string and name: not used during normal runtime, but super
	// useful for debugging. Hence, if the model is doing
	// safety checks (and the runtime is down the drain anyway),
	// we can use these two fields for debugging. 
	private final long ID;
	private final String name;


	// Model references
	/** A reference to the Model that created this state. As the model and state can be
	 * stored to memory, the Model is transient. To ensure that the correct model is loaded,
	 * each state keeps a final int for the model's hash
	 */
	private transient AbstractModel model;
	private final int modelHashCode; 

	// FIXED properties
	// There are some properties of a state that should always be
	// present, include the age, location, and previous locations. These
	// properties should be in a model regardless of the solver-algorithm used.
	protected final int age;
	protected final int locationPatchState;
	protected final int locationPatch;

	/** How many time steps ago did the agent last visit a patch? One entry each [patchIndex]*/	
	protected final int[] lastVisitToPatch; 

	/** What was the state of the patch during the last time the agent visited the patch? One for each [patchIndex]*/	
	protected final int[] patchStateOfLastVisit; 

	/** What level of the phenotypic dimension does the agent have in this state? One for each [phenotypicDimensionsDimensionIndex]*/	
	protected final int[] phenotypicDimensions;

	/** The phenotypicDimensionsSlots that exist in each state	 */
	protected final CaptiveSlot[] captiveSlots;
	protected final DelayedSlot[] delayedSlots;
	protected final RecurringSlot[] recurringSlots;

	// For future versions: an agent can learn from experiences
	// However, enabling this results very much in a NP hard problem
	// As such, only simulation based algorithms work, or the memory
	// of an agent has to be limited (e.g., it can only store x experiences
	// in memory). As time is limited, this functionality will be enabled in future 
	// versions of the ModelBuilder software.
	protected final int[][][] resourceExperiences; 		// [resource]    [patch state][value] -> count
	protected final int[][][] extrinsicExperiences; 	// [extrinsic]   [patch state][extrinsic][value] -> count
	protected final int[][][] interruptionExperiences;  // [interruption][patch state][value] -> count
	protected final int[][][] delayExperiences; 		// [delay]       [patch state][value] -> count


	/** Build a State based on the factory. Note, this building uses a shallow clone of all factory fields.
	 * In addition: should there be a check during runtime to make sure that the state is a valid one? */
	public AbstractState(AbstractStateFactory factory) {
		this.model = factory.model;
		this.modelHashCode = model.hashCode();
		if (model.performSafetyChecks) {
			if (!factory.isComplete())
				throw new IllegalArgumentException("Trying to build model from incomplete factory.");
			if (model.ledger.patchStateIndexToPatchIndex[factory.locationPatchState] != factory.locationPatch)
				throw new IllegalStateException("Creating state in patch state location "+ factory.locationPatchState + " in patch " + factory.locationPatch + ". However, that patch state is not in that patch!");
		}
		this.phenotypicDimensions = factory.phenotypicDimensions;


		this.age = factory.age;

		this.locationPatchState = factory.locationPatchState;
		this.locationPatch = factory.locationPatch;
		this.lastVisitToPatch = factory.lastVisitToPatch;
		this.patchStateOfLastVisit = factory.patchStateOfLastVisit;

		this.recurringSlots=factory.recurringSlots;
		this.captiveSlots=factory.captiveSlots;
		this.delayedSlots=factory.delayedSlots;

		this.resourceExperiences = factory.resourceExperiences;
		this.extrinsicExperiences = factory.extrinsicExperiences;
		this.delayExperiences = factory.delayExperiences;
		this.interruptionExperiences = factory.interruptionExperiences;

		if (model.performSafetyChecks)
			this.checkValidity();
	}

	/** Check whether all fields are valid, and throw an IllegalStateException if a field has a clearly impossible state (e.g., negative age)*/
	public void checkValidity() {
		if (this.age < 0)
			throw new IllegalStateException("Created a AbstractState with a negative age. Age = " + age);
		if (this.age > model.maximumAge)
			throw new IllegalStateException("Created a AbstractState with an age higher than the maximum age. Age = " +age + ". Maximum = " + model.maximumAge );

		if (phenotypicDimensions.length != model.ledger.numberOfNonAgePhenotypicDimensions)
			throw new IllegalStateException("Created a AbstractState that has a phenotypicDimensions with an incorrect number of dimensions. phenotypicDimensions = " + Helper.arrayToString(phenotypicDimensions) + ", expected number of dimensions = " + phenotypicDimensions.length);

		for (int p = 0; p < phenotypicDimensions.length; p++)
			if (phenotypicDimensions[p] < 0)
				throw new IllegalStateException("Created a AbstractState with a negative phenotypicDimensions index at phenotypic dimension. Dimension number = " + p + ". Index = " + phenotypicDimensions[p]);
			else if (phenotypicDimensions[p] >= model.ledger.phenotypicDimensionValues[p].length)
				throw new IllegalStateException("Created a AbstractState with an impossibly high phenotypicDimensions index at phenotypic dimension. Dimension number = " + p + ". Index = " + phenotypicDimensions[p] + ". Max = " + model.ledger.phenotypicDimensionValues[p].length);


		if (this.locationPatch < 0)
			throw new IllegalStateException("Created a AbstractState with a negative patch location. Patch = " + locationPatch);
		if (this.locationPatch >= model.ledger.patches.length)
			throw new IllegalStateException("Created a AbstractState with an impossible patch state location. Patch = " + locationPatch+ ". Maximum = " + model.ledger.patches.length);

		if (this.locationPatchState < 0)
			throw new IllegalStateException("Created a AbstractState with a negative patch state location. State = " + locationPatchState);
		if (this.locationPatchState >= model.ledger.patchStates.length)
			throw new IllegalStateException("Created a AbstractState with an impossible patch state location. State = " + locationPatchState+ ". Maximum = " + model.ledger.patchStates.length);

		if (model.ledger.patchStates[this.locationPatchState].ledgerIndexOfPatch != this.locationPatch)
			throw new IllegalStateException("Created a Abstract state where the patch state location and patch location cannot possibility be both correct. Patch: "  + this.locationPatch + ", state: " + this.locationPatchState );

		if (lastVisitToPatch.length != model.ledger.patches.length)
			throw new IllegalStateException("Created a Abstract state where the size of the last visits to patch array has an unexpected length. Length array = " + lastVisitToPatch.length + ", number of patches in model: " + model.ledger.patches.length);

		if (patchStateOfLastVisit.length != model.ledger.patches.length)
			throw new IllegalStateException("Created a Abstract state where the size of the patch state in last visit array has an unexpected length. Length array = " + patchStateOfLastVisit.length + ", number of patches in model: " + model.ledger.patches.length);


		for (int p = 0; p < model.ledger.patches.length; p++)
			if (this.lastVisitToPatch[p] < 0)
				throw new IllegalStateException("Created a AbstractState that visited a previous patch a negative number of time steps ago. Time since last visit = " + lastVisitToPatch[p]);
			else if (this.lastVisitToPatch[p] > age)
				throw new IllegalStateException("Created a AbstractState that visited a patch longer than it has been alive. Last visit = " + lastVisitToPatch[p] + ". age = " + age);
			else if (patchStateOfLastVisit[p] < 0)
				throw new IllegalStateException("Created a AbstractState that has last seen a patch be in a negative location. Patch = " + p + ", state = " + patchStateOfLastVisit[p]);
			else if (patchStateOfLastVisit[p] >= model.ledger.patchStates.length)
				throw new IllegalStateException("Created a AbstractState that has last seen a patch be in an unknown state. Patch = " + p + ", state = " + patchStateOfLastVisit[p]);
			else if (model.ledger.patchStates[patchStateOfLastVisit[p]].ledgerIndexOfPatch != p)
				throw new IllegalStateException("Created a AbstractState that has last seen a patch be in a state that is not associated with that patch. Patch = " + p + ", state = " + patchStateOfLastVisit[p]);


		//TODO: check validity of phenotype slots

	}

	public AbstractModel getModel() { return this.model; }

	/** Set the model after loading an AbstractState from disk.Throws an IllegalArgumentException
	 * if the hash code of the previous model and the argument model do not match. */
	public void setModel(AbstractModel model) {

		if (model.hashCode() != this.modelHashCode)
			throw new IllegalArgumentException("New model hash does not match previous model hash.");

		this.model = model;
	}
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////// State getters (known at construction) /////////////////////
	///////////////////////////////////////////////////////////////////////////////////

	/** A state is either in an action phase (agent is taking an action), a mutation phase (the environment
	 * is taking all of its actions), or a termination phase (a final state) */
	public abstract Phase getPhase();


	/** Returns the age of the agent in this state.*/
	public int getAge() {
		return age;
	}

	/** Get a shallow copy of the phenotypicDimensions. Watch out: changes in this array affect the state*/
	public int[] getphenotypicDimensionsArray() {return this.phenotypicDimensions;}

	/** Returns the integer stored at the i'th phenotypicDimensions. What the i'th phenotypicDimensions is,
	 * or what value the resulting integer represents can be found by using the Ledger's
	 * getNameOfphenotypicDimensionsIndex(int index). */
	public int getphenotypicDimensionsValue(int phenotypicDimensionsIndex) {
		return phenotypicDimensions[phenotypicDimensionsIndex];
	}

	/** Returns the integer representing the current location (patch state). What PatchState 
	 * this integer refers to can be found in the Ledger (by using getNameOfPatchState())*/
	public int getLocationPatchState() {
		return locationPatchState;
	}

	/** Returns the integer representing the current location (patch). What Patch 
	 * this integer refers to can be found in the Ledger (by using getNameOfPatch())*/
	public int getLocationPatch() {
		return locationPatch;
	}

	/** Returns the number of time steps that have passed since an agent in this State visited 
	 * the patch index. Which patch this index refers to is specified in the Ledger. */
	public int timeStepsSinceLastVisit(int patchIndex) {
		return this.lastVisitToPatch[patchIndex];
	}

	/** Returns the index of the state the patch was in when an agent in this State visited
	 * the specified patch Returns -1 if the agent never visited the state yet.*/
	public int patchStateDuringLastVisit(int patchIndex) {
		return this.patchStateOfLastVisit[patchIndex];
	}

	/** Get the captive slot stored at the specified location. The name of that slot
	 * can be found in the Ledger*/
	public CaptiveSlot getCaptiveSlot(int index) {
		return this.captiveSlots[index];
	}

	/** Get the delayed slot stored at the specified location. The name of that slot
	 * can be found in the Ledger*/
	public DelayedSlot getDelayedSlot(int index) {
		return this.delayedSlots[index];
	}

	/** Get the recurring slot stored at the specified location. The name of that slot
	 * can be found in the Ledger*/
	public RecurringSlot getRecurringSlot(int index) {
		return this.recurringSlots[index];
	}


	///////////////////////////////////////////////////////////////
	//////////////////////// Other functions /////////////////////
	/////////////////////////////////////////////////////////////
	/** Returns true if the fields in this state match the fields in the other state*/
	public boolean equals(AbstractState other) {
		if (this == other)
			return true;
		if (other == null)
			return false;
		if (other.getClass() != this.getClass())
			return false;

		if (other.age != age)
			return false;
		if (other.locationPatchState != locationPatchState)
			return false;

		if (!Arrays.equals(lastVisitToPatch, other.lastVisitToPatch)) {
			return false;
		}
		if (!Arrays.equals(patchStateOfLastVisit, other.patchStateOfLastVisit)) {
			return false;
		}
		if (!Arrays.equals(phenotypicDimensions, other.phenotypicDimensions)) {
			return false;
		}

		if (!Arrays.deepEquals(this.captiveSlots, other.captiveSlots))
			return false;

		if (!Arrays.deepEquals(this.delayedSlots, other.delayedSlots))
			return false;

		if (!Arrays.deepEquals(this.recurringSlots, other.recurringSlots))
			return false;
		if (!Arrays.deepEquals(resourceExperiences, other.resourceExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(delayExperiences, other.delayExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(extrinsicExperiences, other.extrinsicExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(interruptionExperiences, other.interruptionExperiences)) {
			return false;
		}

		return true;
	}

	/** Create a hash for the specified abstract state.  It is specified in this function so that in the future it is easy
	 * to change the hashes for states and state factories in similar ways*/
	public static int generateHash( AbstractState o) {
		final int prime = 31;
		int result = 1;

		result = prime * result + Arrays.hashCode(o.lastVisitToPatch);
		result = prime * result + Arrays.hashCode(o.patchStateOfLastVisit);
		result = prime * result + Arrays.hashCode(o.phenotypicDimensions);

		result = prime * result + Arrays.deepHashCode(o.captiveSlots);
		result = prime * result + Arrays.deepHashCode(o.delayedSlots);
		result = prime * result + Arrays.deepHashCode(o.captiveSlots);

		result = prime * result + Arrays.deepHashCode(o.resourceExperiences);
		result = prime * result + Arrays.deepHashCode(o.delayExperiences);
		result = prime * result + Arrays.deepHashCode(o.extrinsicExperiences);
		result = prime * result + Arrays.deepHashCode(o.interruptionExperiences);
		return result;
	}


	/** Create a hash for the specified T1ActionStateFactory or T1MutationStateFactory. It is specified in this function so that in the future it is easy
	 * to change the hashes for states and state factories in similar ways*/
	public static int generateHash( AbstractStateFactory o) {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(o.delayExperiences);
		result = prime * result + Arrays.deepHashCode(o.extrinsicExperiences);
		result = prime * result + Arrays.deepHashCode(o.interruptionExperiences);
		result = prime * result + Arrays.hashCode(o.lastVisitToPatch);
		result = prime * result + Arrays.hashCode(o.patchStateOfLastVisit);
		result = prime * result + Arrays.hashCode(o.phenotypicDimensions);
		result = prime * result + Arrays.deepHashCode(o.resourceExperiences);
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		return this.equals((AbstractState) obj);
	}

	/** Returns true if the factory's output (i.e., the state resulting from
	 * the build() function) will match the current state*/
	public boolean equals (AbstractStateFactory factory) {
		if (factory == null)
			return false;

		if (factory.age != age)
			return false;
		if (factory.locationPatchState != locationPatchState)
			return false;

		if (!Arrays.equals(lastVisitToPatch, factory.lastVisitToPatch)) {
			return false;
		}
		if (!Arrays.equals(patchStateOfLastVisit, factory.patchStateOfLastVisit)) {
			return false;
		}
		if (!Arrays.equals(phenotypicDimensions, factory.phenotypicDimensions)) {
			return false;
		}
		if (!Arrays.deepEquals(resourceExperiences, factory.resourceExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(delayExperiences, factory.delayExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(extrinsicExperiences, factory.extrinsicExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(interruptionExperiences, factory.interruptionExperiences)) {
			return false;
		}
		return true;

	}


	protected void setName(String name) { this.name = name; }
	public String getName() { return this.name;}

	protected void setID(int ID) { this.ID = ID;}
	public int getID() { return this.ID;}


	public String toString() {
		StringBuilder sb = new StringBuilder("State: " + getName());		
		sb.append("\n\tAge:\t" +age);
		sb.append("\n\tLocation:\t" +locationPatch+"/" + locationPatchState);

		sb.append("\n\tLast visit to patch:");
		for (int i = 0; i < this.lastVisitToPatch.length; i++)
			sb.append("\n\t[" + i + "]: " + lastVisitToPatch[i]);

		sb.append("\n\tState of patch in last visit:");
		for (int i = 0; i < this.patchStateOfLastVisit.length; i++)
			sb.append("\n\t[" + i + "]: " + patchStateOfLastVisit[i]);

		sb.append("\n\tphenotypicDimensions:");
		for (int i = 0; i < this.phenotypicDimensions.length; i++)
			sb.append("\n\t[" + i + "]: " + phenotypicDimensions[i]);


		sb.append("\n\tPreviously encountered resources:");
		for (int i = 0; i < this.resourceExperiences.length; i++) {
			sb.append("\n\tPatchState [" + i + "]: ");
			for (int r = 0; r < this.resourceExperiences[i].length; r++) {
				sb.append("\n\t\tResource [" + i + "]: ");
				for (int v = 0; v < this.resourceExperiences[i][r].length; v++)
					sb.append("\n\t\t[" + v+ "]: " + this.resourceExperiences[i][r][v]);
			}	
		}

		sb.append("\n\tPreviously encountered extrinsic events:");
		for (int i = 0; i < this.extrinsicExperiences.length; i++) {
			sb.append("\n\tPatchState [" + i + "]: ");
			for (int r = 0; r < this.extrinsicExperiences[i].length; r++) {
				sb.append("\n\t\tExtrinsic event[" + i + "]: ");
				for (int v = 0; v < this.extrinsicExperiences[i][r].length; v++)
					sb.append("\n\t\t[" + v+ "]: " + this.extrinsicExperiences[i][r][v]);
			}	
		}

		sb.append("\n\tPreviously encountered interruptions:");
		for (int i = 0; i < this.interruptionExperiences.length; i++) {
			sb.append("\n\tPatchState [" + i + "]: ");
			for (int r = 0; r < this.interruptionExperiences[i].length; r++) {
				sb.append("\n\t\tInterruption [" + i + "]: ");
				for (int v = 0; v < this.interruptionExperiences[i][r].length; v++)
					sb.append("\n\t\t[" + v+ "]: " + this.interruptionExperiences[i][r][v]);
			}	
		}

		sb.append("\n\tPreviously encountered delays:");
		for (int i = 0; i < this.delayExperiences.length; i++) {
			sb.append("\n\tPatchState [" + i + "]: ");
			for (int r = 0; r < this.delayExperiences[i].length; r++) {
				sb.append("\n\t\tDelay [" + i + "]: ");
				for (int v = 0; v < this.delayExperiences[i][r].length; v++)
					sb.append("\n\t\t[" + v+ "]: " + this.delayExperiences[i][r][v]);
			}	
		}

		return sb.toString();
	}

	
	
	
	//////////// Getters
	/**
	 * @return the time steps since the last visit to the specified patch.
	 */
	public int getLastVisitToPatch(int patchIndex) {
		return lastVisitToPatch[patchIndex];
	}

	/**
	 * @return the state of the specified patch during the last visit 
	 */
	public int getPatchStateOfLastVisit(int patchIndex) {
		return patchStateOfLastVisit[patchIndex];
	}

	/**
	 * @return the index value of the specified phenotypicDimensions index
	 */
	public int getPhenotypicDimensions(int phenotypeDimensionIndex) {
		return phenotypicDimensions[phenotypeDimensionIndex];
	}

	/**
	 * @return the specified captiveSlot 
	 */
	public CaptiveSlot getCaptiveSlots(int index) {
		return captiveSlots[index];
	}

	/**
	 * @return the specified delayedSlot
	 */
	public DelayedSlot getDelayedSlots(int index) {
		return delayedSlots[index];
	}

	/**
	 * @return the specified recurringSlot
	 */
	public RecurringSlot getRecurringSlots(int index) {
		return recurringSlots[index];
	}

	/**
	 * @return the number of times the agent experienced the
	 * specified value index of the specified resource in the specified
	 * patch state during the runtime of the model (i.e., excluding
	 * prior experiences that the agent started with).
	 */
	public int getResourceExperiences(int patchStateIndex, int resourceIndex, int valueIndex) {
		return resourceExperiences[patchStateIndex][resourceIndex][valueIndex];
	}
	
	/**
	 * @return the number of times the agent experienced 
	 * all value index of the specified resource in the specified
	 * patch state during the runtime of the model (i.e., excluding
	 * prior experiences that the agent started with).
	 */
	public int[] getResourceExperiences(int patchStateIndex, int resourceIndex) {
		return resourceExperiences[patchStateIndex][resourceIndex];
	}

	/**
	 * @return the number of times the agent experienced the
	 * specified duration indices of the specified delay in the specified
	 * patch state during the runtime of the model (i.e., excluding
	 * prior experiences that the agent started with).
	 */
	public int getDelayExperiences(int patchStateIndex, int delayIndex, int durationIndex) {
		return delayExperiences[patchStateIndex][delayIndex][durationIndex];
	}

	/**
	 * @return the number of times the agent experienced all
	 * duration indices of the specified delay in the specified
	 * patch state during the runtime of the model (i.e., excluding
	 * prior experiences that the agent started with).
	 */
	public int[] getDelayExperiences(int patchStateIndex, int delayIndex) {
		return delayExperiences[patchStateIndex][delayIndex];
	}
	
	/**
	 * @return the number of times the agent experienced the
	 * specified index of the specified interruption in the specified
	 * patch state during the runtime of the model (i.e., excluding
	 * prior experiences that the agent started with). Note:
	 * an hasExperienced of false returns the number of times that
	 * this interruption type did not come to pass, while a true returns
	 * the number of times an interruption of this type did come to pass. 
	 */
	public int getInterruptionExperiences(int patchStateIndex, int interruptionIndex, boolean hasExperiencedInterruption) {
		if (!hasExperiencedInterruption)
			return interruptionExperiences[patchStateIndex][interruptionIndex][0];
		return interruptionExperiences[patchStateIndex][interruptionIndex][1];
	}
	
	/**
	 * @return the number of times the agent experienced experienced
	 * that an interruption of the specified interruption type did NOT came to 
	 * pass in the specified patch state (at index 0), and the number of times
	 * it DID come to pass (at index 1), during the runtime of the model (i.e., excluding
	 * prior experiences that the agent started with). 
	 */
	public int[] getInterruptionExperiences(int patchStateIndex, int interruptionIndex) {
		return interruptionExperiences[patchStateIndex][interruptionIndex];
	}

	/**
	 * @return the number of times the agent experienced the
	 * specified extrinsic event value index of the specified extrinsic event type in the specified
	 * patch state during the runtime of the model (i.e., excluding
	 * prior experiences that the agent started with).
	 */
	public int getExtrinsicExperiences(int patchStateIndex, int extrinsicIndex, int extrinsicValueIndex) {
		return extrinsicExperiences[patchStateIndex][extrinsicIndex][extrinsicValueIndex];
	}

	/**
	 * @return the number of times the agent experienced all 
	 * extrinsic event value indices of the specified extrinsic event type in the specified
	 * patch state during the runtime of the model (i.e., excluding
	 * prior experiences that the agent started with).
	 */
	public int[] getExtrinsicExperiences(int patchStateIndex, int extrinsicIndex) {
		return extrinsicExperiences[patchStateIndex][extrinsicIndex];
	}
}


