package states.Abstract;

/** A state is either an Action state (the agent makes a move), a 
 * Mutation State (the environment makes a move), or a Terminal state
 * (the agent is dead or the algorithm otherwise stops).
 * */
public abstract interface Phase {
	
	public enum PhaseType{
	Action, Mutation, Termination;
	}
	
	/** Is this state in an Action, Mutation, or Termination phase?*/
	public abstract PhaseType getPhaseType();
}
