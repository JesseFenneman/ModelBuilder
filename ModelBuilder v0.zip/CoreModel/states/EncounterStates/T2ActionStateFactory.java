package states.EncounterStates;

import states.RoamingStates.T1MutationStateFactory;


public class T2ActionStateFactory extends T2AbstractStateFactory  {

	// Did the agent take at least one action that has a 'terminate' postcondition, or an 'interruption' postcondition
	// that passed the check?
	protected boolean encounterIsTerminated;

	/** A reference to the T2ActionState that created this factory (i.e., the T2ActionState in which we are 
	 * taking all new actions). This reference is not strictly speaking necessary. However, it is used
	 * for an optimization: rather than computing the effect of postponing (very expensive to compute!)
	 * for each possible action that has a postponing postcondition, we keep track of all possible outcomes. These
	 * outcomes can then be shared between T2ActionStateFactories. See the javadoc above the private class 
	 * SuccessorStatesAfterPostponingNTimes in the T2ActionState for more detail.*/
	public final T2ActionState origin;
	
	/** Create a StateFactory with the same fields as the State*/
	public T2ActionStateFactory(T2AbstractState s) {
		super(s);
		this.encounterIsTerminated = false;
		
		if (s instanceof T2ActionState)
			this.origin = (T2ActionState) s;
		else
			this.origin = null;
	}

	/** Clone all fields in the existing T2StateFactory to create a new T2StateFactory. 
	 * Fields can be copied by reference (deepClone == false) or by value (deepClone == true)*/
	public T2ActionStateFactory(T2AbstractStateFactory f, boolean deepClone) {
		super(f, deepClone);
		this.encounterIsTerminated = false;
		
		if (f instanceof T2ActionStateFactory)
			this.origin = ((T2ActionStateFactory) f).origin;
		else
			this.origin = null;
	}

	/** Create a ActionState based on this Factory*/
	protected T2ActionState buildT2ActionState(T2DecisionTree tree) {
		if (this.encounterIsTerminated)
			throw new IllegalStateException("Trying to create a T2ActionState from a T2ActionStateFactory that indicates that the encounter is already terminated.");
		return new T2ActionState(this, tree);
	}

	/** Create a shallow cloned MutationStateFactory with the same values as this StateFactory. */
	public T2MutationStateFactory toT2MutationStateFactory() {
		return new T2MutationStateFactory(this, false);
	}

	/** Stop the encounter: create a T1MutationStateFactory that represent the state that
	 * an agent will end up with if it stops the encounter in the state represented by the
	 * present factory. Note: this using shallow cloning*/
	public T1MutationStateFactory toT1MutationStateFactory() {
		return new T1MutationStateFactory(this, false);
	}

	/** Tells the model that after this , the agent should transfer back to the T1 space 
	 * (that is, end the encounter). There are two reasons to call this function: either this function after an agent has taken an action that has a 'terminate' postcondition, */
	public void terminateEncounter() {
		this.encounterIsTerminated = true;
	}

	@Override
	public int hashCode() {
		return T2AbstractState.generateHash(this);
	}

	public String toString() {
		return super.toString("T2ActionStateFactory");
	}


	

}
