package states.EncounterStates;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import core.Model;
import helper.Helper;

/**Similar to a CanonicalT1StateMap, but then for T2Action and T2Mutation states.
 * There are two differences. First, CanonicalT2StateMaps are keyed not for age 
 * and patchState location, but for the time spend in an encounter. 
 * And second, they need a T2DecisionTree.
 */
public class CanonicalT2StateMap implements Serializable  {
	private static final long serialVersionUID = Helper.programmeVersion;
	
		private final Map<T2ActionState, T2ActionState> actionStates;
		private final Map<T2MutationState, T2MutationState> mutationStates;

		private final T2DecisionTree tree;
		
		protected CanonicalT2StateMap (T2DecisionTree tree) {
			this.actionStates = new HashMap<>();
			this.mutationStates = new HashMap<>();
			this.tree = tree;
		}
		
		/** After loading a T2DecisionTree to disk and loading it back for the backwards pass, we
		 * need to reset the reference to the model. This function should only be called by the
		 * T2DecisionTree to which this T2StateMap (indirectly) belongs.*/
		protected void reinflate(Model model) {
			for (T2ActionState s: actionStates.keySet())
				s.reinflate(model);
			for (T2MutationState s: mutationStates.keySet())
				s.reinflate(model);
			
		}
		
		////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////// SETTERS //////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////

		/** Create a new ActionState from the factory and this T2ActionState as the canonical value.
		 * Returns the resulting state*/
		private T2ActionState addActionState(T2ActionStateFactory stateFactory) {	
			T2ActionState newState = stateFactory.buildT2ActionState(tree);
			actionStates.put(newState, newState);
			return newState;
		}
		
		/** Add this T2ActionState as the canonical value. Returns the state.*/
		private T2ActionState addActionState(T2ActionState state) {	
			actionStates.put(state, state);
			return state;
		}
		
		/** Create a new MutationState from the factory and this T2MutationState as the canonical value.
		 * Returns the resulting state. */
		private T2MutationState addMutationState(T2MutationStateFactory stateFactory) {	
			T2MutationState newState = stateFactory.buildT2MutationState(tree);
			mutationStates.put(newState, newState);
			return newState;
		}
		
		/** Add this T2MutationState as the canonical value. Returns the state.*/
		private T2MutationState addMutationState(T2MutationState state) {	
			mutationStates.put(state, state);
			return state;
		}
		

		
		/////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////// ACTION STATE GETTERS //////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		/** Get the canonical T2ActionState that has the same values as the specified state.
		 * If no such canonical value exists yet, this state is added as its own canonical state.
		 *  */
		public T2ActionState getActionState(T2ActionState state) {	
			T2ActionState result = actionStates.get(state);

			// If the result is null, add this state as its own canonical value
			if (result == null) 
				result = addActionState(state);
			
			return result;
		}


		/** Get the canonical T2ActionState that has the same values as the state that results from the
		 *  specified factory. If no such canonical value exists yet, this state is added as its own canonical state.
		 *  (Note: this works because we've overwritten the equals() in the T2AbstractState and T2AbstractStateFactory classes.)*/
		public T2ActionState getActionState(T2ActionStateFactory stateFactory) {	

			@SuppressWarnings("unlikely-arg-type")
			T2ActionState result = actionStates.get(stateFactory);

			// If the result is null, create the state from this factory add this state as its own canonical value
			if (result == null) 
				result = addActionState(stateFactory);

			return result;
		}
		
		/** Returns all T2ActionStates in this map*/
		public Set<T2ActionState> getAllActionStates() {
			return actionStates.keySet();
		}
		
		/** Returns the number of ActionStates registered in this map*/
		public int numberOfT2ActionStates() {
			return actionStates.size();
		}
		
		
		////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////// MUTATION STATES GETTERS //////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		/** Get the canonical T2MutationState that has the same values as the specified state.
		 * If no such canonical value exists yet, this state is added as its own canonical state.
		 *  */
		public T2MutationState getMutationState(T2MutationState state) {	
			T2MutationState result = mutationStates.get(state);

			// If the result is null, add this state as its own canonical value
			if (result == null) 
				result = addMutationState(state);
			
			return result;
		}


		/** Get the canonical T2MutationState that has the same values as the state that results from the
		 *  specified factory. If no such canonical value exists yet, this state is added as its own canonical state.
		 *  (Note: this works because we've overwritten the equals() in the T2AbstractState and T2AbstractStateFactory classes.)*/
		public T2MutationState getMutationState(T2MutationStateFactory stateFactory) {	

			@SuppressWarnings("unlikely-arg-type")
			T2MutationState result = mutationStates.get(stateFactory);

			// If the result is null, create the state from this factory add this state as its own canonical value
			if (result == null) 
				result = addMutationState(stateFactory);

			return result;
		}
		
		/** Returns all T2MutationStates in this map*/
		public Set<T2MutationState> getAllMutationStates() {
			return mutationStates.keySet();
		}
		
		
		/** Returns the number of MutationStates registered in this map*/
		public int numberOfT2MutationStates() {
			return mutationStates.size();
		}
		
		//////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////// OTHER //////////////////////////////////////
		////////////////////////////////////////////////////////////////////////////////
		
		/** Returns the number of States registered in this map*/
		public int numberOfT2States() {
			return this.numberOfT2ActionStates() +  this.numberOfT2MutationStates();
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((actionStates == null) ? 0 : actionStates.hashCode());
			result = prime * result + ((mutationStates == null) ? 0 : mutationStates.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			CanonicalT2StateMap other = (CanonicalT2StateMap) obj;
			if (actionStates == null) {
				if (other.actionStates != null) {
					return false;
				}
			} else if (!actionStates.equals(other.actionStates)) {
				return false;
			}
			
			if (mutationStates == null) {
				if (other.mutationStates != null) {
					return false;
				}
			} else if (!mutationStates.equals(other.mutationStates)) {
				return false;
			}
			return true;
		}
	
}