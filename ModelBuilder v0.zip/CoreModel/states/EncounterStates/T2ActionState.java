package states.EncounterStates;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.Model;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import helper.Helper;
import helper.Helper.Pair;
import helper.Helper.Triplet;
import stateInterfacesAndAbstractions.Path;
import stateInterfacesAndAbstractions.ReferencedPath;
import states.RoamingStates.T1AbstractStateFactory;
import states.RoamingStates.T1ActionStateFactory;
import states.RoamingStates.T1FitnessState;
import states.RoamingStates.T1FitnessStateReference;
import states.RoamingStates.T1MutationState;
import states.RoamingStates.T1MutationStateFactory;
import states.RoamingStates.T1MutationStateReference;
import t2Actions.T2ActionPostconditionInterrupt;


public class T2ActionState extends T2AbstractState {
	private static final long serialVersionUID = Helper.programmeVersion;
	
	public final boolean[] possibleActions; // which actions are allowed in this state? Ordered by the Ledger's array of T1Actions

	// From a T2ActionState the agent can go to either: 
	// 		a T2MutationState (if it remains within the encounter)
	//		a T1FitnessState (if it dies)
	//		a T1MutationState (if it finishes the encounter)
	public final ArrayList< ArrayList< Path<T2ActionState,   T2MutationState>>> successorT2MutationStates; // All outgoing connections that do not result in death or the end of an encounter, one for ArrayList each action
	public final ArrayList< ArrayList< Path<T2ActionState,   T1FitnessState>>> successorT1FitnessStates; // All outgoing connections that result in death, one ArrayList for each action.
	public final ArrayList< ArrayList< Path<T2ActionState,   T1MutationState>>> successorT1MutationStates; // All outgoing connections that results in the end of the encounter, with the agent still being alive. One ArrayList for each action

	/* Note that sometimes we want to store the T2DecisionTree to disk in between the forwards and backwards pass.
	 * However, in that case we need to reconnect all T2AbstractStates to the rest of the model. Specifically, we need
	 * to know what T1 successor states we need to reconnect. Rather than storing the successorT1FitnessStates and
	 * successorT1MutationStates directly after the forwards pass, we first store references to those state. Then, when
	 * reinflating the T2DecisionTree for the backwards pass, we can figure out to which T1AbstractStates these references
	 * point.*/
	public final ArrayList< ArrayList< ReferencedPath<T2ActionState,   T1FitnessStateReference>>> referencePathToSuccessorT1FitnessStates; 
	public final ArrayList< ArrayList< ReferencedPath<T2ActionState,   T1MutationStateReference>>> referencePathToSuccessorT1MutationStates; 
	
	//* Variables computed during the backwards pass*/
	/** E[Fitness|a]*/
	private NumberObjectSingle[] expectedFitnessGivenAction; 
	
	/** The probability for each action that an agent will take this T2ActionState. */
	protected NumberObjectSingle[] probabilityOfImmediateT2Action;
	
	/** Does this action maximize fitness? Note: initialized to all false.*/
	protected boolean[] isBestAction;

	

	/** Specifically added for the postponing models:
	 * How long does an agent expects to delay in this T2DecisionTree, 
	 * given that there are interruptions, and given that 
	 * it follows the optimal policy?
	 * One value for each possible action. */
	private NumberObjectSingle expectedImmediateTimestepsInDelay;
	

	public T2ActionState(T2ActionStateFactory factory, T2DecisionTree tree) {
		super(factory, tree, factory.model.performSafetyChecks);
		if (factory.encounterIsTerminated)
			throw new IllegalStateException("Trying to create a T2ActionState from a T2ActionStateFactory that indicates that the encounter is already terminated.");

		if (getModel().performSafetyChecks)
			if (factory.resultsInDeadState())
				throw new IllegalStateException("Creating a dead T2ActionState");

		// Create an array of boolean that will tell us which actions are possible in this state
		// Note: these actions are ordered by the Ledger's ordering of T2Actions
		this.possibleActions = new boolean[getModel().ledger.t2Actions.length];

		// Create the arraylists of arraylists for the successor states,
		// and create for each action an empty ArrayList that contains the Paths from this state
		// to the successor state
		this.successorT2MutationStates = new ArrayList<>();
		this.successorT1MutationStates = new ArrayList<>();
		this.successorT1FitnessStates = new ArrayList<>();

		for (int a = 0; a < possibleActions.length; a++) {
			successorT2MutationStates.add(new ArrayList<Path<T2ActionState,  T2MutationState>>());
			successorT1MutationStates.add(new ArrayList<Path<T2ActionState,  T1MutationState>>());
			successorT1FitnessStates.add(new ArrayList<Path<T2ActionState,   T1FitnessState>>());
		}
		
		// If we need to store this T2ActionState to disk in between the forwards and backwards pass:
		// also create the referencedPaths
		if (getModel().saveT2TreesToFile) {
			this.referencePathToSuccessorT1MutationStates = new ArrayList<>();
			this.referencePathToSuccessorT1FitnessStates = new ArrayList<>();
			
			for (int a = 0; a < possibleActions.length; a++) {
				referencePathToSuccessorT1MutationStates.add(new ArrayList<ReferencedPath<T2ActionState,  T1MutationStateReference>>());
				referencePathToSuccessorT1FitnessStates.add( new ArrayList<ReferencedPath<T2ActionState,  T1FitnessStateReference>>());
			}
			
		} else {
			this.referencePathToSuccessorT1MutationStates = null;
			this.referencePathToSuccessorT1FitnessStates = null;
		}
		// Set the name
		this.setID(tree.treeStateList.numberOfActionStates(timeInEncounter));
		this.setName("T2A-" +getID()+"-" + timeInEncounter+"-"+ locationPatchState);

		this.expectedFitnessGivenAction = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];

		// For optimizition: keep track of which T2ActionStateFactories and T1MutationStateFactories result
		// if an agent postpones x times in this state. Note that this optimization works, because the postponing
		// action is one of the first postconditions (second only to interruptions). As such, all actions that
		// include a postponing action will first postpone, after which some other postcondition is applied.
		successorStatesAfterPostponing = new HashMap<>();
	}

	/** Create an ActionStateFactory preset with the same values as in this ActionState*/
	public T2ActionStateFactory toT2ActionStateFactory() {return new T2ActionStateFactory(this);}


	///////////////////////////////////////////////////////////////////////
	//////////////////////// Tree building functions /////////////////////
	/////////////////////////////////////////////////////////////////////

	@Override
	public T1AbstractStateFactory toT1EquivalentFactory() {
		return new T1ActionStateFactory(this);
	}

	/** Returns an ArrayList of indices, one for each action that is possible in this state*/
	public ArrayList<Integer> getPossibleActions(){
		if (this.possibleActions == null)
			return null;

		ArrayList<Integer> actions = new ArrayList<>();
		for (int i = 0; i < possibleActions.length; i++)
			if (possibleActions[i])
				actions.add(i);
		return actions;
	}

	/** Tells this ActionState to compute, for all possible actions in this T2States, the successor
	 * states of taking that action. The resulting new T2MutationStates are already registered in the T2DecisionTree's
	 * T2StateList. This State is also added as an ancestor state in 
	 * all of its successor states */
	@Override
	public void doForwardsPass(T2DecisionTree tree) {

		if (this.wentThroughForwardsPass)
			return;

		/*Figure out which actions are possible in this state */
		for (int a = 0; a < possibleActions.length; a++)
			if (getModel().ledger.t2Actions[a].isPossibleInState(this))
				possibleActions[a] = true;
			else
				possibleActions[a] = false;
		
		// For each possible action that an agent can take in this state...
		for (int a = 0; a < possibleActions.length; a++) {
			if (!possibleActions[a])
				continue;

			// ... find what states result from taking this action.
			// As a reminder: taking an action in a T2 state can result in one of three outcomes:
			// 		1. A T2MutationState if the action does not end the encounter and the agent is still alive after this action;
			//		2. A T1MutationState if the action does end the encounter and the agent does not die
			//		3. A T1FitnessState  if the agent dies.
			Triplet < 
			ArrayList< Path<T2ActionState, T2MutationState>> ,  
			ArrayList< Path<T2ActionState, T1MutationState>>,
			ArrayList< Path<T2ActionState, T1FitnessState>>   > resultingPaths = getModel().ledger.t2Actions[a].performAction(this, tree);
			
			// If the Model wants us to, perform a safety check to make sure that the origin in all new Paths is indeed this state
			if (getModel().performSafetyChecks) {
				for (Path<T2ActionState, T2MutationState> path : resultingPaths.a)
					if (path.origin != this)
						throw new IllegalStateException("Created a successor state Path for a T2ActionState where the origin in the Path is not this state");
				for (Path<T2ActionState, T1MutationState> path : resultingPaths.b)
					if (path.origin != this)
						throw new IllegalStateException("Created a successor state Path for a T2ActionState where the origin in the Path is not this state");
				for (Path<T2ActionState, T1FitnessState> path : resultingPaths.c)
					if (path.origin != this)
						throw new IllegalStateException("Created a successor state Path for a T2ActionState where the origin in the Path is not this state");
				if (resultingPaths.a.size() + resultingPaths.b.size()+ resultingPaths.c.size() == 0)
					throw new IllegalStateException("Created a T2MutationState without any successors.");
			}
			
			// Where do we store the paths to the successor states?
			// If we do not store the T2DecisionTree to disk between the forwards and backwards pass, we can 
			// immediately set the successor states
			if (!getModel().saveT2TreesToFile) {
				this.successorT2MutationStates.set(a, resultingPaths.a);
				this.successorT1MutationStates.set(a, resultingPaths.b);
				this.successorT1FitnessStates.set(a, resultingPaths.c);
				
			} 
			// Otherwise, we'll just store a reference to the state. Later on, after we loaded the T2DecisionTree from disk and
			// are reinflating it, we'll change these referencedPaths to actual paths
			else {
				this.successorT2MutationStates.set(a, resultingPaths.a);

				// Create referencedPaths for each path to a T1MutationState
				ArrayList<ReferencedPath<T2ActionState, T1MutationStateReference>> t1MutationReferences = new ArrayList<>();
				for ( Path<T2ActionState, T1MutationState> path : resultingPaths.b)
					t1MutationReferences.add(new ReferencedPath<T2ActionState, T1MutationStateReference>(
							path.origin,
							path.destination.toT1StateReference(),
							path.weight,
							path.annotation,
							getModel()));
				this.referencePathToSuccessorT1MutationStates.set(a, t1MutationReferences);
				
				// Create referencedPaths for each path to a T1FitnessState
				ArrayList<ReferencedPath<T2ActionState, T1FitnessStateReference>> t1FitnessReferences = new ArrayList<>();
				for ( Path<T2ActionState, T1FitnessState> path : resultingPaths.c)
					t1FitnessReferences.add(new ReferencedPath<T2ActionState, T1FitnessStateReference>(
							path.origin,
							path.destination.toT1StateReference(),
							path.weight,
							path.annotation,
							getModel()));
				this.referencePathToSuccessorT1FitnessStates.set(a, t1FitnessReferences);
			
			}

			// If the Model wants us to, perform a safety check to make sure that the origin in all new Paths is indeed this state
			if (getModel().performSafetyChecks) {
				for (Path<T2ActionState, T2MutationState> path : resultingPaths.a)
					if (path.origin != this)
						throw new IllegalStateException("Created a successor state Path for a T1ActionState where the origin in the Path is not this state");
			}

		}
		// Clear the optimization that take up a lot of RAM
		this.successorStatesAfterPostponing.clear();
		
		// Check if there are successor states, or at least, references to successor states, for each action
		if (getModel().performSafetyChecks) {
			for (int a = 0; a < getModel().ledger.numberOfT2Actions; a ++)
				if (possibleActions[a])
					if (!getModel().saveT2TreesToFile) {

						// Make sure that there are successor states for each action
						if (getModel().performSafetyChecks) {
							if (successorT1FitnessStates.get(a).size() + this.successorT1MutationStates.get(a).size() + this.successorT2MutationStates.get(a).size() == 0) {
								throw new IllegalStateException("T2Action state after forwards path has no successor states for action " + a );
							}
						}
					} else {
						if (referencePathToSuccessorT1FitnessStates.get(a).size() + this.referencePathToSuccessorT1MutationStates.get(a).size() + this.successorT2MutationStates.get(a).size() == 0) {
							throw new IllegalStateException("T2Action state after forwards path has no successor states for action " + a );
						}
					}
		}
	
		this.wentThroughForwardsPass = true;

	}

	
	/** Returns all Paths between this state and a successor state after taking the action, 
	 * and the agent is still alive.
	 * 
	 * Any call to this function must be preceded by a call to findPossibleActions() and computeSuccessorStates().
	 * The action integer refers to the place of the action in the Ledger's T2Action array.*/
	public ArrayList<Path<T2ActionState, T2MutationState>> getSuccessorT2MutationPaths(int action) {return successorT2MutationStates.get(action);}

	/** Returns all Paths between this state and a T1 successor state after the current encounter is immediately
	 * terminated. 
	 * 
	 * Any call to this function must be preceded by a call to findPossibleActions() and computeSuccessorStates().
	 * The action integer refers to the place of the action in the Ledger's T2Action array. */
	public ArrayList<Path<T2ActionState, T1MutationState>> getSuccessorT1MutationPaths(int action) {return successorT1MutationStates.get(action);}

	/** Returns all Paths between this state and a successor state after taking the action, 
	 * and the agent is dead. 
	 * 
	 * Any call to this function must be preceded by a call to findPossibleActions() and computeSuccessorStates().
	 * The action integer refers to the place of the action in the Ledger's T2Action array.*/
	public ArrayList<Path<T2ActionState, T1FitnessState>> getSuccessorT1FitnessPaths(int action) {return successorT1FitnessStates.get(action);}

	/** Returns an ArrayList of all T2 Mutation states an agent can be in after executing the specified action,
	 * for all possible action that agent can take. This function is used to create the frontier in the T2DecisionTree.*/
	public ArrayList<T2MutationState> getT2AllMutationSuccessorStates(){
		ArrayList<T2MutationState> result = new ArrayList<>();
		for (int a = 0; a < this.possibleActions.length; a++)
			for (Path<T2ActionState,   T2MutationState> path : this.successorT2MutationStates.get(a))
				result.add(path.destination);
		return result;
	}

	/** Compute what action results in what fitness, what the best action is, and what the fitness of this state is.
	 * In other words: go through the backwards pass.*/
	@Override
	public void doBackwardsPass(boolean printToConsole) {

		if (!this.wentThroughForwardsPass)
			throw new IllegalStateException("Pushing a T2ActionState through a backwards pass, but this state has not been through a forwards pass yet.");

		// Step 1: compute the expected fitness for all actions
		// There will be a null value for impossible actions.
		this.expectedFitnessGivenAction = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];

		for (int action = 0; action < getModel().ledger.numberOfT2Actions; action++)
			this.expectedFitnessGivenAction[action] = computeFitnessForAction(action);

		// Step 2: make expected fitness value immutable
		for (int action = 0; action < getModel().ledger.numberOfT2Actions; action++)
			if (possibleActions[action])
				this.expectedFitnessGivenAction[action].makeImmutable();

		// Step 3: figure out which action (or actions when there are ties) has the highest fitness,
		// and what that expected fitness is
		ArrayList<Integer> bestActionsSoFar = new ArrayList<>();
		NumberObjectSingle bestFitnessSoFar = null;
		for (int action = 0; action < getModel().ledger.numberOfT2Actions; action ++)
			if (possibleActions[action] ) {

				// If there has not been an action considered yet, this action 
				// has the best fitness
				if (bestFitnessSoFar == null) {
					bestFitnessSoFar = this.expectedFitnessGivenAction[action];
					bestActionsSoFar.add(action);
				}

				// If this action has the same expected fitness as the current best action, add this action
				// to the bestActionsSoFar list
				else if (this.expectedFitnessGivenAction[action].equals(bestFitnessSoFar, true)) {
					bestActionsSoFar.add(action);	
				}

				// If this action is higher than the best fitness thus far, 
				// replace both the bestActionsSoFar and the bestFitnessSoFar
				else if (this.expectedFitnessGivenAction[action].largerThan(bestFitnessSoFar)) {
					bestFitnessSoFar = this.expectedFitnessGivenAction[action];
					bestActionsSoFar.clear();
					bestActionsSoFar.add(action);
				}
				
			}
			
		
		// Step 4: set the expectedNumberOfImmediateT1Actions. And while
		// we're at it: remove all the now-no-longer-used successor state arrays for the actions
		// that are not a best action
		this.isBestAction = new boolean[getModel().ledger.numberOfT2Actions]; 
		NumberObjectSingle[] tempProbabilityOfImmediateT2Action = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];

		if (bestActionsSoFar.size() == 0)
			throw new IllegalStateException("T2ActionState does not have a best action");
		for (int i = 0; i < bestActionsSoFar.size(); i++)
			isBestAction[bestActionsSoFar.get(i)] = true; 

		//Compute the probability of taking an action from bestActions (this is a probability
		// of 1 if there is only 1 best action, and 1/|bestActions| if there are ties)
		NumberObjectSingle probabilityOfAction = NumberObject.createNumber(getModel().howToRepresentNumbers, 1).divide(bestActionsSoFar.size());
		for (int a = 0 ; a< getModel().ledger.numberOfT2Actions; a++)
			if (!isBestAction[a]) {
				successorT1MutationStates.set(a, null);
				successorT1FitnessStates.set(a, null);
				successorT2MutationStates.set(a, null);
				tempProbabilityOfImmediateT2Action[a]  = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
			} else {
				tempProbabilityOfImmediateT2Action[a] = probabilityOfAction;	
			}
		this.setProbabilityOfImmediateT2Actions(tempProbabilityOfImmediateT2Action);

		// Step 5: Set all the 'expected...' fields
		// Except for the expectedFitness, which we already computed above
		this.setExpectedFitness(bestFitnessSoFar);
		this.setExpectedFields(isBestAction);

		this.wentThroughBackwardsPass = true;
	}

	/** Compute the expected fitness for the specified action. The expected fitness of an action is defined as:
	 * 
	 * [ SUM over all successor T1FitnessStates fs: fitness(fs) * Pr(fs|s,a) ] +
	 * [ SUM over all successor T2ActionStates  T2as: fitness(T2as) * Pr(T2as|s,a) ] +
	 * [ SUM over all successor T2ActionStates  T1as: fitness(T1as) * Pr(T1as|s,a) ] 
	 * 
	 * Where s is the current state, Pr(x|s) is the transition probability of 
	 * going to x from s, and a is the current action
	 * */
	private NumberObjectSingle computeFitnessForAction(int action) {
		if (!possibleActions[action])
			return null;
		// Keep track of both the weighted sum (which is the fitness), and, for testing purposes, the totalProbability.
		NumberObjectSingle totalProbability = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle weightedSum = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);

		for (Path<T2ActionState,   T1FitnessState> path : successorT1FitnessStates.get(action)) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);
			weightedSum.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
		}

		for (Path<T2ActionState,   T1MutationState> path : successorT1MutationStates.get(action)) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);
			try {
			weightedSum.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
			} catch (IllegalStateException e) { throw new IllegalStateException (e.getMessage() + ". Called by state: " + this.getName() );} 
		}

		for (Path<T2ActionState,   T2MutationState> path : successorT2MutationStates.get(action)) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);
			weightedSum.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
		}

		if (getModel().performSafetyChecks)
			if (!totalProbability.equals(1, true))
				throw new IllegalStateException("T2Action state after backwards pass: sum of all paths did not equal 1. "
						+ "Is possible? " + possibleActions[action]
						+ ". Total sum = " + totalProbability.toStringWithoutTrailingZeros() + 
						". Number of T1F: " + successorT1FitnessStates.get(action).size() +
						". Number of T1M: " + successorT1MutationStates.get(action).size() +
						". Number of T2M: " + successorT2MutationStates.get(action).size() +
						". This:\n" + this
						);

		return weightedSum;
	}

	/** Set the expectedAge, expectedPhenotype[], expectedFutureT1Actions[], expectedFutureT2Actions[], 
	 * and expectedImmediateT2Actions[]
	 * during the backwards pass. 
	 * Specifically:
	 *  Go over all possible successor states from taking a best action a*,
	 *		For each successor state resulting from a*:
	 *		Multiply the expected age, phenotype, and expected number of future actions from that successor state with
	 *			the probability of going to that successor given that an agent takes a*;
	 *		Multiply the result with probabilityOfAction;
	 *		Add that result to the expectedAge, expectedPhenotype, and expectedNumberOfFutureActions respectively;
	 *		
	 * (Note: we already know the expected fitness. Computing the other fields is actually
	 * really similar to when we computed the fitness) */
	private void setExpectedFields(boolean[] isBestAction) {

		// Create a temporary storage for all the expected fields, and set all values to 0
		NumberObjectSingle tempExpectedAge = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle tempExpectedImmediateTimestepsInDelay= NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle tempExpectedTotalTimestepsInDelay = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		
		NumberObjectSingle[] tempExpectedPhenotype = new NumberObjectSingle[getModel().ledger.numberOfNonAgePhenotypicDimensions];
		for (int i = 0; i < getModel().ledger.numberOfNonAgePhenotypicDimensions; i++) tempExpectedPhenotype[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT1Actions = new NumberObjectSingle[getModel().ledger.numberOfT1Actions];
		for (int i = 0; i < getModel().ledger.numberOfT1Actions; i++) tempExpectedNumberOfFutureT1Actions[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT2Actions = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];
		for (int i = 0; i < getModel().ledger.numberOfT2Actions; i++) tempExpectedNumberOfFutureT2Actions[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT2ActionsInThisTree = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];
		for (int i = 0; i < getModel().ledger.numberOfT2Actions; i++) tempExpectedNumberOfFutureT2ActionsInThisTree[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		// Keep track of both the weighted sum (which is the fitness), and, for testing purposes, the totalProbability.
		NumberObjectSingle totalProbability = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);

		// Next, for each possible action that is the best action (yes, there are maybe multiple best actions if there are ties)
		for (int a = 0; a < getModel().ledger.numberOfT2Actions; a++)
			if (isBestAction[a]) {

				// First, for each possible T1Fitness state s' that result from this mutation state:
				// multiply the expectedFitness of s' with the probability of going to s',
				// and add the result to this state's expectedFitness field.
				// Do the same for actions and phenotypes. (Don't have to do it for future actions,
				// as there never are any future actions of T1FitnessStates)
				for (Path<T2ActionState,   T1FitnessState> path : successorT1FitnessStates.get(a)) {
					NumberObjectSingle correctedWeight = path.weight.multiply(this.probabilityOfImmediateT2Action[a], false);
					if (getModel().performSafetyChecks)
						totalProbability.add(correctedWeight, true);

					tempExpectedAge.add(correctedWeight.multiply( path.destination.getExpectedAge(),     false), true);
			
					// Compute the expected immediate and future delay. 
					// The immediate delay only relevant in case this action results in delays - i.e.,
					// if it is an postponing or waiting action. In this case the immediate delay is the difference in age 
					// between this and the next state (which is 0 if the agent dies immediately). 
					// The total delay is the expected delay of all future actions, and, if applicable, the immediate delay.
					// (The future states will delay 0 for fitness states, and hence, it is omitted here)
					NumberObjectSingle weightedImmediateTimeSteps = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
					if (getModel().ledger.t2Actions[a].isDelayingAction()) {
						weightedImmediateTimeSteps = correctedWeight.multiply( path.destination.getAge() - age ,false);
						tempExpectedImmediateTimestepsInDelay.add(weightedImmediateTimeSteps, true);
					}
					tempExpectedTotalTimestepsInDelay.add(weightedImmediateTimeSteps, true);
					
					for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
						tempExpectedPhenotype[p]                 .add(correctedWeight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
					}

				// Second, so the same for all possible T1MutationStates. However, now we also have to keep track of
				// all possible future T1 and T2 actions that an agent will take in its lifetime from this moment on.
				for (Path<T2ActionState,   T1MutationState> path : successorT1MutationStates.get(a)) {
					NumberObjectSingle correctedWeight = path.weight.multiply(probabilityOfImmediateT2Action[a], false);
					if (getModel().performSafetyChecks)
						totalProbability.add(correctedWeight, true);
					tempExpectedAge.add(correctedWeight.multiply( path.destination.getExpectedAge(),     false), true);
					
					// Compute the expected immediate and future delay. 
					// The immediate delay only relevant in case this action results in delays - i.e.,
					// if it is an postponing or waiting action. In this case the immediate delay is the difference in age 
					// between this and the next state (which is 0 if the agent dies immediately). 
					// The total delay is the expected delay of all future actions, and, if applicable, the immediate delay.
					// (The future states will delay 0 for fitness states, and hence, it is omitted here)
					NumberObjectSingle weightedImmediateTimeSteps = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
					if (getModel().ledger.t2Actions[a].isDelayingAction()) {
						weightedImmediateTimeSteps = correctedWeight.multiply( path.destination.getAge() - age ,false);
						tempExpectedImmediateTimestepsInDelay.add(weightedImmediateTimeSteps, true);
					}
					tempExpectedTotalTimestepsInDelay.add(weightedImmediateTimeSteps, true);
					tempExpectedTotalTimestepsInDelay.add(correctedWeight.multiply(path.destination.getExpectedTotalTimeStepsInDelay(), false), true);
					
					
					for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
						tempExpectedPhenotype[p]                 .add(correctedWeight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
					for (int t1a = 0 ; t1a < this.getModel().ledger.numberOfT1Actions; t1a ++)
						tempExpectedNumberOfFutureT1Actions[t1a] .add(correctedWeight.multiply( path.destination.getFutureTimesItPerformsT1Action(t1a), false), true);
					for (int t2a = 0 ; t2a < this.getModel().ledger.numberOfT2Actions; t2a ++) 
						tempExpectedNumberOfFutureT2Actions[t2a] .add(correctedWeight.multiply( path.destination.getFutureTimesItPerformsT2Action(t2a), false), true);
					
				}
				
				// Third and finally, do the same for all possible T2MutationStates. This is roughly the same as for T1MutationStates,
				// with two exceptions, but now we also have to keep track of how often each T2Action is taken in the 
				// future while still in the tree (not during the rest of the lifetime)
				for (Path<T2ActionState,   T2MutationState> path : successorT2MutationStates.get(a)) {
					NumberObjectSingle correctedWeight = path.weight.multiply(probabilityOfImmediateT2Action[a], false);
					if (getModel().performSafetyChecks)
						totalProbability.add(correctedWeight, true);
					tempExpectedAge    .add(correctedWeight.multiply( path.destination.getExpectedAge(),     false), true);
					
					// Compute the expected immediate and future delay. 
					// The immediate delay only relevant in case this action results in delays - i.e.,
					// if it is an postponing or waiting action. In this case the immediate delay is the difference in age 
					// between this and the next state (which is 0 if the agent dies immediately). 
					// The total delay is the expected delay of all future actions, and, if applicable, the immediate delay.
					// (The future states will delay 0 for fitness states, and hence, it is omitted here)
					NumberObjectSingle weightedImmediateTimeSteps = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
					if (getModel().ledger.t2Actions[a].isDelayingAction()) {
						weightedImmediateTimeSteps = correctedWeight.multiply( path.destination.getAge() - age ,false);
						tempExpectedImmediateTimestepsInDelay.add(weightedImmediateTimeSteps, true);
					}
					tempExpectedTotalTimestepsInDelay.add(weightedImmediateTimeSteps, true);
					tempExpectedTotalTimestepsInDelay.add(correctedWeight.multiply(path.destination.getExpectedTotalTimeStepsInDelay(), false), true);
					
					
					for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
						tempExpectedPhenotype[p]                 .add(correctedWeight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
					for (int t1a = 0 ; t1a < this.getModel().ledger.numberOfT1Actions; t1a ++)
						tempExpectedNumberOfFutureT1Actions[t1a] .add(correctedWeight.multiply( path.destination.getFutureTimesItPerformsT1Action(t1a), false), true);
					
					for (int t2a = 0 ; t2a < this.getModel().ledger.numberOfT2Actions; t2a ++) {
						tempExpectedNumberOfFutureT2Actions[t2a] .add(correctedWeight.multiply( path.destination.getFutureTimesItPerformsT2Action(t2a), false), true);
						tempExpectedNumberOfFutureT2ActionsInThisTree[t2a] .add(correctedWeight.multiply( path.destination.getFutureTimesItPerformsT2ActionInThisTree(t2a), false), true);
					}
				}
				
				if (getModel().performSafetyChecks) {
					NumberObjectSingle probabilityThusFar = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
					for (int i = 0; i <= a; i ++)
						probabilityThusFar.add(this.probabilityOfImmediateT2Action[i], true);
				
					if (!totalProbability.equals(probabilityThusFar, true))
						throw new IllegalStateException("Total probability of all futures states does not equal expected probability. Action =  " + a
								+ "(PR = " + totalProbability.toStringWithoutTrailingZeros() 
								+ ", Expected = " + probabilityThusFar.toStringWithoutTrailingZeros() +
								". action = " + a +
								". Expected fitness = " + Helper.arrayToString(this.expectedFitnessGivenAction) +
								this.successorT1MutationStates.get(a).size() +
								this.successorT2MutationStates.get(a).size()+
								"). Best actions: " + Helper.arrayToConciseString(isBestAction)+
								". Probability immediate action: " + Helper.arrayToString(this.probabilityOfImmediateT2Action) +
								"in state " + this);
				}
				/*	if (this.phenotype[0]< 20)
				System.err.println("age: "+ this.age + ", action "+ a +" - " +getModel().ledger.t2Actions[a].isDelayingAction()+ 
						"? I:" + tempExpectedImmediateTimestepsInDelay + 
						". T:" +tempExpectedTotalTimestepsInDelay +
						". Possible: " + Helper.arrayToConciseString(possibleActions)+
						". Best:" +Helper.arrayToConciseString(isBestAction)+ 
						". Expected fitness: " + Helper.arrayToString(this.expectedFitnessGivenAction));*/
			}
		// Check if the probability is 1 - i.e., whether we have included all future states
		if (getModel().performSafetyChecks)
			if (!totalProbability.equals(1, true))
				throw new IllegalStateException("Total probability of all futures states does not equal 1 (PR = " + totalProbability.toStringWithoutTrailingZeros() +
						"). Best actions: " + Helper.arrayToConciseString(isBestAction)+
						". Probability immediate action: " + Helper.arrayToString(this.probabilityOfImmediateT2Action) +
						"in state " + this);
		

		// Set the expected fields
		this.setExpectedAge(tempExpectedAge);
		this.setExpectedTotalTimeStepsInDelay(tempExpectedTotalTimestepsInDelay);
		this.expectedImmediateTimestepsInDelay = tempExpectedImmediateTimestepsInDelay;
		this.setExpectedPhenotype(tempExpectedPhenotype);
		this.setExpectedNumberOfFutureT1Actions(tempExpectedNumberOfFutureT1Actions);
		this.setExpectedNumberOfFutureT2Actions(tempExpectedNumberOfFutureT2Actions);
		this.setExpectedNumberOfFutureT2ActionsInThisTree(tempExpectedNumberOfFutureT2ActionsInThisTree);
		

		if (getModel().performSafetyChecks)
			this.checkIfBackwardsFieldsAreValid();

	}

	
	
	////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////// Outcome setters (used during backwards pass) /////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////
	/** Set the expected number of immediate T2 Actions by cloning the input. Note that the
	 * input must be a probability distribution (i.e., all values must sum up to 1, and should all
	 * be non-negative). Also makes all expected action NumberObjectSingle objects immutable.
	 * Throws an IllegalStateException if there already is an expected number of future actions for that index.
	 * Has to be set after the expected age has been set. */
	public void setProbabilityOfImmediateT2Actions( NumberObjectSingle[] newProbabilityDistribution) {
		// If the model wants us to be careful: 
		// check if the dimension's input matches the number of T1 actions in the ledger
		if (newProbabilityDistribution.length != getModel().ledger.numberOfT2Actions)
			throw new IllegalArgumentException("Setting probability of immediate T2 Actions for T2ActionState. However, the number of action in the input ("
					+ newProbabilityDistribution.length + ") does not match the number of T2 actions in the ledger (" + getModel().ledger.numberOfT2Actions+ ").");

		// check if the sum of all probabilities for all successor states does indeed sum to 1
		if (getModel().performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (NumberObjectSingle p : newProbabilityDistribution)
				if (p.smallerThan(0, false))
					throw new IllegalStateException("Negative probability of immediate T2 action.");
				else
					sum.add(p, true);
			if (!sum.equals(1, true))
				throw new IllegalStateException("Non-sum-to-1 probability distribution immediate T2 actions. Sum = " + sum);
		}


		if (this.probabilityOfImmediateT2Action != null)
			throw new IllegalStateException("Setting a non-null expected number of immediate T2 actions ");

		this.probabilityOfImmediateT2Action = newProbabilityDistribution;
		for (int a = 0; a < probabilityOfImmediateT2Action.length; a++)
			probabilityOfImmediateT2Action[a].makeImmutable();
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////// Outcome getters (known after backwards pass) /////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////

	/** Returns a deep cloned array of booleans containing a true at each T1Action index that
	 * is a best action in this T1ActionState */
	public boolean[] getBestActions(){
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the best actions a T1 state that has not gone through the backwards pass yet.");

		boolean[] clone = new boolean[getModel().ledger.numberOfT1Actions];
		System.arraycopy(this.isBestAction, 0, clone, 0, getModel().ledger.numberOfT1Actions);

		return clone;

	}

	/** Returns a reference to probability that an agent wil take the specified action next */
	public NumberObjectSingle getProbabilityOfImmediateAction(int action){
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the probability of an action in a T2 state that has not gone through the backwards pass yet.");

		return this.probabilityOfImmediateT2Action[action];
	}

	
	/** Returns a clone of the expected fitness of taking the action when in this state. The integer
	 * for each action can be found in the Ledger. Throws an IllegalStateException if the
	 * T1AbstractState did not yet go through the backwards phase.*/
	public NumberObjectSingle getExpectedFitnessOfAction(int action) {
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the fitness of an action in a T2 state that has not gone through the backwards pass yet.");

		return this.expectedFitnessGivenAction[action].clone();
	}

	/** Returns a clone of the expected immediate number of times steps an agent will spend
	 * delaying (either by waiting or postponing), given the best action.
	 * Throws an IllegalStateException if the
	 * T1AbstractState did not yet go through the backwards phase.*/
	public NumberObjectSingle getExpectedImmediateTimestepsInDelay() {
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the immediate delaying of an action in a T2 state that has not gone through the backwards pass yet.");

		return this.expectedImmediateTimestepsInDelay.clone();
	}
	
	
	///////////////////////////////////////////////////////////////
	//////////////////////// Other functions /////////////////////
	/////////////////////////////////////////////////////////////

	@Override
	public int hashCode() {
		return T2AbstractState.generateHash(this);
	}


	public String toString() {
		return super.toString("T2ActionState");
	}

	@Override
	public void reinflate(Model model) {
		this.setModel(model);
		// After loading a T2DecisionTree from disk, we need to connect all the references to T1AbstractStates
		// to the T1AbstractStates in the model. Specifically, after the forwards pass we stored ReferencedPaths
		// to successor states, rather than actual Paths. Here we change these ReferencePaths to actual paths.

		// Make sure that all successor states are empty
		if (model.performSafetyChecks) {
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) {
				if (this.successorT1MutationStates.get(a).size() != 0)
					throw new IllegalStateException("Trying to inflate a T2MutationState that already has T1ActionState successor states");
				if (this.successorT1FitnessStates.get(a).size() != 0)
					throw new IllegalStateException("Trying to inflate a T2MutationState that already has T1FitnessState successor states");
			}
		}
		
		// Make sure that there are either referencePaths or references to T2MutationStates
		if (model.performSafetyChecks) {
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) {
				if (possibleActions[a])
					if (referencePathToSuccessorT1FitnessStates.get(a).size() + this.referencePathToSuccessorT1MutationStates.get(a).size() + this.successorT2MutationStates.get(a).size() == 0) {
						throw new IllegalStateException("Trying to reinflate a T2ActionState without any successor states for action " + a );
					}
			}
		}
		// Turn all T1FitnessStateReferences to actual references
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++) {
			for (ReferencedPath<T2ActionState,   T1FitnessStateReference> refPath : this.referencePathToSuccessorT1FitnessStates.get(a)) {
				successorT1FitnessStates.get(a).add(new Path<T2ActionState, T1FitnessState>(
						refPath.origin,
						model.getT1StateList().toT1FitnessState(refPath.destination),
						refPath.weight,
						refPath.annotation,
						model));
			}
			if (model.performSafetyChecks)
				if (referencePathToSuccessorT1FitnessStates.get(a).size() != successorT1FitnessStates.get(a).size())
					throw new IllegalStateException("When reinflating T2ActionState, the number of fitness states does not match the number of reference paths");

			// Turn all T1MutationStateReferences to actual references
			for (ReferencedPath<T2ActionState,   T1MutationStateReference> refPath : this.referencePathToSuccessorT1MutationStates.get(a)) {
				successorT1MutationStates.get(a).add(new Path<T2ActionState, T1MutationState>(
						refPath.origin,
						model.getT1StateList().toT1MutationState(refPath.destination),
						refPath.weight,
						refPath.annotation,
						model));
			}
		}
		
		this.referencePathToSuccessorT1FitnessStates.clear();
		this.referencePathToSuccessorT1MutationStates.clear();

		// Make sure that there are successor states for each action
		if (model.performSafetyChecks) {
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) {
				if (possibleActions[a])
					if (successorT1FitnessStates.get(a).size() + this.successorT1MutationStates.get(a).size() + this.successorT2MutationStates.get(a).size() == 0) {
						throw new IllegalStateException("T2Action state after reinflation has no successor states for action " + a );
					}
			}
		}
	}


////////////////////////////////////////////////////////////////////////////////
//////////////////////// Optimization fields and functions /////////////////////
////////////////////////////////////////////////////////////////////////////////
	
	/** This field exists for optimization purposes. In a model where an agent can postpone,
	 * there are a lot of redundant operations. That is, suppose that an agent can postpone
	 * either 1, 2, or 3 time steps when it is in state s. In a non-optimized way, the algorithm
	 * would first compute all successor states of 1 time step waited. Then it would compute
	 * all successor states for 2 time steps, which involves first computing what would happen
	 * if it postponed only 1 time step. Next, it would compute all successors for 3 time steps,
	 * which means it first computes the effect of 1 moment spend postponing, then 2 moments spend
	 * postponing, and finally 3 moments spend postponing. Of course, it has now computed the
	 * effect of 1 time step postponing thrice, and twice the effect of 2 time steps. In essence,
	 * it has done twice the amount of work as it should've done, if it could remember the
	 * outcomes of previous computations. This problem scales: if we can wait up to 10 time
	 * steps, the algorithm has to compute 55 times the effect of one more time step postponing. 
	 * That's not good. Hence, each T2ActionState saves an ArrayList, which stores all possible
	 * successors (T2ActionStateFactories and T1MutationStateFactories, and their probability) for each
	 * moment spend postponing. By storing it in an T2ActionState, each T2ActionStateFactory that
	 * is created when an agent takes an action in this T2ActionState can look up all possible
	 * successorStateFactories that will result when it postpones x times.
	 * 
	 * Note 1: each postponing action can (but does not have to) come with an associated InterruptionEvent.
	 * We have to store the effects of each postponing type separately.
	 * 
	 * Note 2: we only store Factories, not actual states As such, there are no T1FitnessStates.*/
	private class  SuccessorStatesAfterPostponingNTimes implements Serializable {
		
		private static final long serialVersionUID = Helper.programmeVersion;
		
		public ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> successorT2ActionStateFactories;
		public ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>> successorT1MutationStateFactories;

	}
	/** A HashMap that maps a T2ActionPostconditionPostpone to an ArrayList of successor states.
	 * The n'th position in this ArrayList contains the successor states of n times postponing. */
	private transient final HashMap<T2ActionPostconditionInterrupt, ArrayList<SuccessorStatesAfterPostponingNTimes>> successorStatesAfterPostponing;


	/** Given a number of n time steps to postpone, and an interruption event that
	 * might occur every time an agent spends postponing, returns a pair of two ArrayLists. 
	 * The first ArrayList contains pairs of T2ActionStateFactories and the 
	 * probability of ending up in the state represented by the factory, given that
	 * an agent postpones n time steps in the current T2ActionState. (Note:
	 * we do not transform the T2ActionState to a T2MutationState yet, as there
	 * might be other actions that still have to taken after this action). Similarly, the
	 * second ArrayList contains pairs of all possible T1MutationStateFactories an
	 * agent might end up in. Note that all successor states sum to 1.
	 * 
	 * If these values are already computed for this T2ActionState, this function
	 * retrieves these successor states from memory. Otherwise, they are first computed,
	 * then stored, and then returned. 
	 *  */
	public Pair<ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, 
	ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> successorStatesAfterPostponing(
			int timeStepsToPostpone, T2ActionPostconditionInterrupt interruption){

		if (timeStepsToPostpone < 0)
			throw new IllegalArgumentException("Trying to postpone a negative number of times. ");

		// Check if we already have an ArrayList for this interruption. If not, make one
		if (!successorStatesAfterPostponing.containsKey(interruption))
			successorStatesAfterPostponing.put(interruption, new ArrayList<SuccessorStatesAfterPostponingNTimes>());

		// Next, get the ArrayList of all possible SuccessorStates
		ArrayList<SuccessorStatesAfterPostponingNTimes> arrayListOfSuccessorStates = successorStatesAfterPostponing.get(interruption);

		// First, do we already know the successor states of postponing n time steps?
		// Basically, this is asking how large the size of the ArrayList for this interruption is
		// If this size is 5, we know the successor states after postponing 4 times. Hence, 
		// if we want to know the successor states of postponing 6 times, we still have to keep
		// computing one more postponing twice, until the size is 7.
		while (timeStepsToPostpone > (arrayListOfSuccessorStates.size()-1)) { 
			this.computeOneMoreTimeStepPostponing(interruption);

		}
	
		
		// Next, get the SuccessorStatesAfterPostponingNTimes for the number of time steps we have to postpone
		SuccessorStatesAfterPostponingNTimes sucStates = arrayListOfSuccessorStates.get(timeStepsToPostpone);
		
		// Bundle it up to a pair, and we are done
		return new Pair<ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, 
				ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>>(
						sucStates.successorT2ActionStateFactories, sucStates.successorT1MutationStateFactories);
	}

	/** The successorStatesAfterPostponing entry for this interruption contains n (>= 0) entries,
	 * corresponding to the successor states that an agent will find itself in if it postpones n times,
	 * given that each time there is the specified interruption probability. Based on this n'th entry,
	 * this function computes and stores in successorStatesAfterPostponing the effects of postponing
	 * n+1 times. Note that if there is no entry yet (the ArrayList at the location of the interruption
	 * has size 0), it computes not the n+1th entry, but the 0th entry instead. Regardless, this function
	 * assumes that there already is an ArrayList stored for the interruption in successorStatesAfterPostponing.
	 * 
	 * Just for clarity: the order of execution is as follows:
	 * 
	 * 1. Get the successor states from postponing n times
	 * 2. Mutate all T2ActionStates that result from postponing n times
	 * 3. Apply the possible interruption to all mutated T2ActionStates
	 * 4. Store the result into n+1.*/
	private void computeOneMoreTimeStepPostponing(T2ActionPostconditionInterrupt interruption) {

		// First, get the corresponding array list
		ArrayList<SuccessorStatesAfterPostponingNTimes> arrayListOfSuccessorStates = successorStatesAfterPostponing.get(interruption);

		// Second, create some references fields to will hold the new results 
		ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> successorT2ActionStateFactories;
		ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>> successorT1MutationStateFactories;
		
		// Third, check if there already is an entry for postponing 0 times
		// If we are asking for the successor states after 0 time steps, we have to do a simple computation:
		if (arrayListOfSuccessorStates.size() == 0) {

			// First, create a Pair of this factory resulting from this T2ActionState with a probability of 1
			Pair<T2ActionStateFactory, NumberObjectSingle> thisWithAProbabilityOf1 =
					new Pair<>(this.toT2ActionStateFactory(), NumberObject.createNumber(getModel().howToRepresentNumbers, 1));
					
			if (interruption == null) {
				// If we postpone and there is no interruption, we can only go from this T2ActionState
				//to the same T2ActionState (i.e., nothing happens during this postcondition)
				successorT2ActionStateFactories = new ArrayList<>();
				successorT2ActionStateFactories.add(thisWithAProbabilityOf1);
				successorT1MutationStateFactories = new ArrayList<>();
					
			} else {
				// If we postpone and there is an interruption, we can either go to the same T2ActionState (no interruption)
				//	or to a T1MutationState (there is an interruption)
				ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> tempArray = new ArrayList<>();
				tempArray.add(thisWithAProbabilityOf1);

				// Get all the successors after the interruption
				Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
					ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>> successorsAfterInterruption =
						interruption.getSuccessorStates(tempArray);
				successorT2ActionStateFactories = successorsAfterInterruption.element1;
				successorT1MutationStateFactories = successorsAfterInterruption.element2;
			}

		}
		
		// Fourth, if there is already at least one entry in arrayListOfSuccessorStates, we will compute
		// all possible successor states, given that we postpone one more time step. 
		else {

			// Get the results from having postponed n-1 times
			int n = arrayListOfSuccessorStates.size()-1;
			SuccessorStatesAfterPostponingNTimes previous = arrayListOfSuccessorStates.get(n);
			
			ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>   previousT2ActionStateFactories   = previous.successorT2ActionStateFactories;
			ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>> previousT1MutationStateFactories = previous.successorT1MutationStateFactories;

			// If there are no previous states, throw an error (there should always be at least one T1 mutation state!)
			if (previousT2ActionStateFactories.size() + previousT1MutationStateFactories.size() == 0)
				throw new IllegalStateException("Computing successors after n times postponing. However, at n-1 times there are no possible states.");
			
			// If there are no previous T2ActionStates, then we do not have to do anything - all outcomes have already resulted in an end to the encounter
			if (previousT2ActionStateFactories.size()==0) {

				SuccessorStatesAfterPostponingNTimes newSuccessorStates = new SuccessorStatesAfterPostponingNTimes();
				newSuccessorStates.successorT2ActionStateFactories = new ArrayList<>();
				newSuccessorStates.successorT1MutationStateFactories = previous.successorT1MutationStateFactories;
				arrayListOfSuccessorStates.add(newSuccessorStates);
				return;
				
			}
			// Make the T2ActionStates from the last step go through one more round of mutations
			Pair<	ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>,  
					ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> afterMutation 
					= getModel().ledger.stateMutator.mutateAllT2ActionFactories(previousT2ActionStateFactories);
	
			// Add the new T1 mutation states to the previousT1MutationStateFactories
			ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>> allT1AfterMutation = new ArrayList<>();
			allT1AfterMutation.addAll(previousT1MutationStateFactories);
			allT1AfterMutation.addAll(afterMutation.element2);
			
			ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> allT2AfterMutation = new ArrayList<>();
			allT2AfterMutation.addAll(afterMutation.element1);

			// Apply an interruption, if there is one (and not everyone is dead yet)
			if (interruption != null && afterMutation.element1.size() > 0) {
				Pair <  ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
				        ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>> afterMutationAndInterruption =
				interruption.getSuccessorStates(afterMutation.element1);

				allT1AfterMutation.addAll(afterMutationAndInterruption.element2);
				successorT1MutationStateFactories = allT1AfterMutation;
				
				successorT2ActionStateFactories = afterMutationAndInterruption.element1;

			} else {
				successorT1MutationStateFactories = afterMutation.element2;
				successorT2ActionStateFactories = afterMutation.element1;
			}
		}
		
		// Fifth, some T2ActionStateFactories will have gone through enough
		// mutations to end the encounter. For example, suppose you have an agent
		// that has been through 3 time steps of the encounter, which will last
		// 5 time steps at most. If it postpones, and the delay is 3 time steps,
		// then there will be (thus far at least) T2ActionStates that are at the 
		// 6th out of the 5th time steps in the cycle. Needless to say, that should
		// not happen. So, here we check if that is the case, and if it is, we terminate
		// the encounter. (Note, the same logic holds for the maximum age)
		for (Iterator<Pair<T2ActionStateFactory, NumberObjectSingle>> it = successorT2ActionStateFactories.iterator(); it.hasNext();) {
			Pair<T2ActionStateFactory, NumberObjectSingle> next = it.next();
			if (next.element1.timeInEncounter >= getModel().maximumStepsInEncounter || next.element1.age >= getModel().maximumAge) {
				it.remove();

				Pair<T1MutationStateFactory, NumberObjectSingle> newPair = new Pair<>(
						next.element1.toT1MutationStateFactory(),
						next.element2);
				successorT1MutationStateFactories.add(newPair);
			}
		}
		
		// If the model wants us too, make sure that the probability of all successor states sums to 1
		// Finally, if the model wants us to check everything: 
		// makes sure that all possible successor state probabilities sum to the NumberObjectSingle provided in currentT2ActionStateFactories
		if (getModel().performSafetyChecks) {

			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> pair: successorT2ActionStateFactories)
				if (pair.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T2ActionStateFactory after postponing " + successorStatesAfterPostponing.size() + " has a non-positive probability.");
				else 
					sum.add(pair.element2, true);
				

			for (Pair<T1MutationStateFactory, NumberObjectSingle> pair: successorT1MutationStateFactories)
				if (pair.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T1MutationStateFactory after postponing " + successorStatesAfterPostponing.size() + " has a non-positive probability.");
				else
					sum.add(pair.element2, true);

			if (!sum.equals(1, true)) 
				throw new IllegalStateException("Sum of all states after postponing " + successorStatesAfterPostponing.size() + " does not equal 1. Sum = " + sum);
			
			}

		// Finally, store the results
		SuccessorStatesAfterPostponingNTimes newSuccessorStates = new SuccessorStatesAfterPostponingNTimes();
		newSuccessorStates.successorT2ActionStateFactories = successorT2ActionStateFactories;
		newSuccessorStates.successorT1MutationStateFactories = successorT1MutationStateFactories;
		arrayListOfSuccessorStates.add(newSuccessorStates);
	}
}
