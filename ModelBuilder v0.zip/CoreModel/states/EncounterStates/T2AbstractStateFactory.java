package states.EncounterStates;

import java.util.Arrays;

import core.Model;
import helper.Helper;
import states.RoamingStates.T1AbstractStateFactory;
/** A T2AbstractStateFactory is... well... a factory for T2States (i.e., during-encounter states). 
 * T2States are essentially T1States, but with some extra variables bolted on to them.*/
public abstract class T2AbstractStateFactory extends T1AbstractStateFactory{

	// State variables.
	// These variables change over the course of a decision tree, from one state to the next.
	public int 			timeInEncounter;
	public boolean[] 	consumedResourceType;
	public int[][] 		resourceCues; 		// [resource]	 [cueLabel]
	public int[][] 		delayCues;	 		// [delay]		 [cueLabel]
	public int[][] 		interruptionCues; 	// [interruption][cueLabel]

	// Variables that are invariant in a decision tree (i.e., they are effectively constant)
	public int 					patchStateWhenStartingEncounter;
	public boolean[] 			encounteredResourceType; 			// Which resources are encountered when searching?
	public int[]				valueIndexOfEncounteredObservableResources; 	// What the the value of the encountered resource, given that the resource is directly observable?
	public int[] 				durationIndexOfEncounteredObservableDelays; 	// What the the duration of the encountered delay, given that the delay is directly observable?
	public boolean[] 			willEncounteredObservableInterruptions; 	// Will the interruption occur, given that the interruption is directly observable?
	
	/** Construct a factory with all fields null or -1.  */
	public T2AbstractStateFactory(Model model) {
		super(model);
		
		// State variables
		timeInEncounter = -1;
		consumedResourceType = null;
		resourceCues = null; 	
		delayCues = null;	 	
		interruptionCues = null;
		
		// Invariants
		patchStateWhenStartingEncounter = -1;
		encounteredResourceType = null;
		valueIndexOfEncounteredObservableResources = null;
		durationIndexOfEncounteredObservableDelays = null;
		willEncounteredObservableInterruptions = null;
	
	}

	/** Clone all fields in the existing T1StateFactory to create a new T2StateFactory. 
	 * Fields can be copied by reference (deepClone == false) or by value (deepClone == true)*/
	public T2AbstractStateFactory (T2AbstractStateFactory factory, boolean deepClone) {
		super(factory, deepClone);

		// Copy all primitives and constants
		timeInEncounter = factory.timeInEncounter;
		patchStateWhenStartingEncounter = factory.patchStateWhenStartingEncounter;

		if (!deepClone) {
			// Copy by reference
			encounteredResourceType = factory.encounteredResourceType;
			consumedResourceType = factory.consumedResourceType;
			resourceCues = factory.resourceCues;
			delayCues = factory.delayCues;
			interruptionCues = factory.interruptionCues;
			valueIndexOfEncounteredObservableResources = factory.valueIndexOfEncounteredObservableResources;
			durationIndexOfEncounteredObservableDelays = factory.durationIndexOfEncounteredObservableDelays;
			willEncounteredObservableInterruptions = factory.willEncounteredObservableInterruptions;

		} else {
			// Deepclone all arrays

			// Encountered resources
			if (factory.encounteredResourceType==null)
				encounteredResourceType = null;
			else {
				encounteredResourceType = new boolean[factory.encounteredResourceType.length];
				System.arraycopy(factory.encounteredResourceType, 0, encounteredResourceType, 0, factory.encounteredResourceType.length);
			}

			//consumedResource
			if (factory.consumedResourceType==null)
				consumedResourceType = null;
			else {
				consumedResourceType = new boolean[factory.consumedResourceType.length];
				System.arraycopy(factory.consumedResourceType, 0, consumedResourceType, 0, factory.consumedResourceType.length);
			}

			//resourceCues
			if (factory.resourceCues == null)
				resourceCues = null;
			else {
				resourceCues = new int[model.ledger.numberOfResourceTypes][];
				for (int r = 0; r < resourceCues.length; r++) {
					if (model.ledger.resourceCueLabels[r]!= null) {
						resourceCues[r] = new int[model.ledger.resourceCueLabels[r].length];
						System.arraycopy(factory.resourceCues[r], 0, resourceCues[r], 0, resourceCues[r].length);
					}
				}}

			//delayCues
			if (factory.delayCues == null)
				delayCues = null;
			else {
				delayCues = new int[model.ledger.numberOfDelayTypes][];
				for (int d = 0; d < delayCues.length; d++) {
					if (model.ledger.delayCueLabels[d]!= null) {
						delayCues[d] = new int[model.ledger.delayCueLabels[d].length];
						System.arraycopy(factory.delayCues[d], 0, delayCues[d], 0, delayCues[d].length);
					}
				}}


			//interruptionCues
			if (factory.interruptionCues == null)
				interruptionCues = null;
			else {
				interruptionCues = new int[model.ledger.numberOfInterruptionTypes][];
				for (int i = 0; i < interruptionCues.length; i++) {
					if (model.ledger.interruptionCueLabels[i]!= null) {
					interruptionCues[i] = new int[model.ledger.interruptionCueLabels[i].length];
					System.arraycopy(factory.interruptionCues[i], 0, interruptionCues[i], 0, interruptionCues[i].length);
				}}
			}
			
			// valueIndexOfEncounteredObservableResources ;
			if (factory.valueIndexOfEncounteredObservableResources == null)
				valueIndexOfEncounteredObservableResources = null;
			else {
				this.valueIndexOfEncounteredObservableResources = new int[factory.valueIndexOfEncounteredObservableResources.length];
				System.arraycopy(factory.valueIndexOfEncounteredObservableResources, 0, this.valueIndexOfEncounteredObservableResources, 0, factory.valueIndexOfEncounteredObservableResources.length);
			}

			// encounteredObservableDelays ;
			if (factory.durationIndexOfEncounteredObservableDelays == null)
				durationIndexOfEncounteredObservableDelays = null;
			else {
				this.durationIndexOfEncounteredObservableDelays = new int[factory.durationIndexOfEncounteredObservableDelays.length];
				System.arraycopy(factory.durationIndexOfEncounteredObservableDelays, 0, this.durationIndexOfEncounteredObservableDelays, 0, factory.durationIndexOfEncounteredObservableDelays.length);
			}

			// didEncounteredObservableInterruptionsOccur ;
			if (factory.willEncounteredObservableInterruptions == null)
				willEncounteredObservableInterruptions = null;
			else {
				this.willEncounteredObservableInterruptions = new boolean[factory.willEncounteredObservableInterruptions.length];
				System.arraycopy(factory.willEncounteredObservableInterruptions, 0, this.willEncounteredObservableInterruptions, 0, factory.willEncounteredObservableInterruptions.length);
			}
		}
	}

	/** Set all fields in the factory to match the specified T2State (all fields are deep clones).*/
	public T2AbstractStateFactory (T2AbstractState s) {
		super(s);
		
		// State Variables
		// These variables change over the course of a decision tree, from one state to the next.
		this.timeInEncounter = s.timeInEncounter;
		
		//consumedResource
		consumedResourceType = new boolean[s.consumedResourceType.length];
		System.arraycopy(s.consumedResourceType, 0, consumedResourceType, 0, s.consumedResourceType.length);

		
		// Deepclone all arrays
		encounteredResourceType = new boolean[s.encounteredResourceType.length];
		System.arraycopy(s.encounteredResourceType, 0, encounteredResourceType, 0, s.encounteredResourceType.length);

	

		//resourceCues
		resourceCues = new int[model.ledger.numberOfResourceTypes][];
		for (int r = 0; r < resourceCues.length; r++) {
			if (s.resourceCues[r] != null) {
				resourceCues[r] = new int[model.ledger.resourceCueLabels[r].length];
				System.arraycopy(s.resourceCues[r], 0, resourceCues[r], 0, resourceCues[r].length);
			}
		}

		//delayCues
		delayCues = new int[model.ledger.numberOfDelayTypes][];
		for (int d = 0; d < delayCues.length; d++) {
			if (s.delayCues[d] != null) {
				delayCues[d] = new int[model.ledger.delayCueLabels[d].length];
				System.arraycopy(s.delayCues[d], 0, delayCues[d], 0, delayCues[d].length);
			}
		}


		//interruptionCues
		interruptionCues = new int[model.ledger.numberOfInterruptionTypes][];
		for (int i = 0; i < interruptionCues.length; i++) {
			if (s.interruptionCues[i] != null) {
				interruptionCues[i] = new int[model.ledger.interruptionCueLabels[i].length];
				System.arraycopy(s.interruptionCues[i], 0, interruptionCues[i], 0, interruptionCues[i].length);
			}
		}
		
		
		


		// Invariants
		// Variables that are invariant in a decision tree (i.e., they are effectively constant)

		this.patchStateWhenStartingEncounter = s.patchStateWhenStartingEncounter;

		encounteredResourceType = new boolean[s.encounteredResourceType.length];
		System.arraycopy(s.encounteredResourceType, 0, encounteredResourceType, 0, s.encounteredResourceType.length);



		valueIndexOfEncounteredObservableResources = new int[s.valueIndexOfEncounteredObservableResources.length];
		System.arraycopy(s.valueIndexOfEncounteredObservableResources, 0, valueIndexOfEncounteredObservableResources, 0, s.valueIndexOfEncounteredObservableResources.length);

		durationIndexOfEncounteredObservableDelays = new int[s.durationIndexOfEncounteredObservableDelays.length];
		System.arraycopy(s.durationIndexOfEncounteredObservableDelays, 0, durationIndexOfEncounteredObservableDelays, 0, s.durationIndexOfEncounteredObservableDelays.length);

		willEncounteredObservableInterruptions = new boolean[s.willEncounteredObservableInterruptions.length];
		System.arraycopy(s.willEncounteredObservableInterruptions, 0, willEncounteredObservableInterruptions, 0, s.willEncounteredObservableInterruptions.length);

	}

	/** Returns the set of cues that an agent has observed about the specified resource type. The result is an array of integers of length |cl|,
	 * the total number of cue labels a cue for that resource type can have. */
	public int[] resourceCueSet(int resourceIndex) {
		return resourceCues[resourceIndex];
	}
	
	/** Returns the set of cues that an agent has observed about the specified delay type. The result is an array of integers of length |cl|,
	 * the total number of cue labels a cue for that delay type can have. */
	public int[] delayCueSet(int delayIndex) {
		return delayCues[delayIndex];
	}
	
	/** Returns the set of cues that an agent has observed about the specified interruption type. The result is an array of integers of length |cl|,
	 * the total number of cue labels a cue for that interruption type can have. */
	public int[] interruptionCueSet(int interruptionIndex) {
		return interruptionCues[interruptionIndex];
	}
	
	/** Increments the number of time steps in this encounter with 1*/
	public void incrementTimeStep() {
		this.timeInEncounter++;
	}
	
	@Override
	/** Returns true only if all fields have been initialized.*/
	public boolean isComplete() {
		if (!super.isComplete())
			return false;

		if (timeInEncounter == -1)
			return false;
		if (patchStateWhenStartingEncounter == -1)
			return false;
		if (consumedResourceType == null)
			return false;
		if (encounteredResourceType == null)
			return false;
		if (resourceCues == null)
			return false;
		if (delayCues == null)
			return false;
		if (interruptionCues == null)
			return false;

		return true;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) 
			return true;

		if (obj == null) 
			return false;

		if (obj instanceof T2AbstractState) 
			return this.equals((T2AbstractState) obj);

		if (obj instanceof T2AbstractStateFactory)
			return this.equals((T2AbstractStateFactory) obj);

		return false;
	}

	/** Returns true if the factory's output (i.e., the state resulting from
	 * the build() function) will match the output of this factory. NOTE: there is no
	 * check for whether this is an ActionStateFactory or a MutationStateFactory!
	 * It is possible for an ActionStateFactory to match a MutationStateFactory,
	 * as long as all STATE VARIALBES are equal. The invariants are not used,
	 * as these are invariant within a decision tree (and states from different
	 * trees should never be compared to begin with). 
	 * 		- The age
	 * 		- Phenotypic dimensions
	 * 		- Experiences (not yet implemented)
	 * 		- Time spend in this encounter
	 * 		- Sampled cues
	 * 		- Cconsumed resource*/
	public boolean equals (T2AbstractStateFactory factory) {
		if (factory == null)
			return false;
		if (factory.age != this.age)
			return false;

		if (!Arrays.equals(factory.phenotype, phenotype))
			return false;

		if (factory.timeInEncounter != timeInEncounter)
			return false;


		if (!Arrays.equals(consumedResourceType, factory.consumedResourceType)) {
			return false;
		}


		if (!Arrays.deepEquals(resourceCues, factory.resourceCues)) {
			return false;
		}

		if (!Arrays.deepEquals(delayCues, factory.delayCues)) {
			return false;
		}

		if (!Arrays.deepEquals(interruptionCues, factory.interruptionCues)) {
			return false;
		}

		if (patchStateWhenStartingEncounter != factory.patchStateWhenStartingEncounter)
			return false;
		
		if (!Arrays.equals(encounteredResourceType, factory.encounteredResourceType)) {
			return false;
		}
		if (!Arrays.equals(valueIndexOfEncounteredObservableResources, factory.valueIndexOfEncounteredObservableResources)) {
			return false;
		}
		if (!Arrays.equals(durationIndexOfEncounteredObservableDelays, factory.durationIndexOfEncounteredObservableDelays)) {
			return false;
		}
		if (!Arrays.equals(willEncounteredObservableInterruptions, factory.willEncounteredObservableInterruptions)) {
			return false;
		}
		
		return true;
	}

	/** Returns true if the other state matches the output of this factory. NOTE: there is no
	 * check for whether this is an ActionState or a MutationState!
	 * It is possible for an ActionState to match a MutationStateFactory, and vice versa.
	 * A state is equal to another state if all state variables are equal. Invariants are
	 * not compared, as these are invariant within a decision tree (and states from different
	 * trees are never compared). The state variables are:
	 * 		- The age
	 * 		- Phenotypic dimensions
	 * 		- Experiences (not yet implemented)
	 * 		- Time spend in this encounter
	 * 		- Which resources are consumed
	 * 		- Sampled cues */
	public boolean equals(T2AbstractState other) {
		if (other == null)
			return false;
		if (other.getAge() != this.age)
			return false;

		if (!Arrays.equals(other.getPhenotypeArray(), phenotype))
			return false;

		if (other.timeInEncounter != timeInEncounter)
			return false;

		if (!Arrays.equals(consumedResourceType, other.consumedResourceType)) {
			return false;
		}


		if (!Arrays.deepEquals(resourceCues, other.resourceCues)) {
			return false;
		}

		if (!Arrays.deepEquals(delayCues, other.delayCues)) {
			return false;
		}

		if (!Arrays.deepEquals(interruptionCues, other.interruptionCues)) {
			return false;
		}

		
		
		if (patchStateWhenStartingEncounter != other.patchStateWhenStartingEncounter)
			return false;
		
		if (!Arrays.equals(encounteredResourceType, other.encounteredResourceType)) {
			return false;
		}
		if (!Arrays.equals(valueIndexOfEncounteredObservableResources, other.valueIndexOfEncounteredObservableResources)) {
			return false;
		}
		if (!Arrays.equals(durationIndexOfEncounteredObservableDelays, other.durationIndexOfEncounteredObservableDelays)) {
			return false;
		}
		if (!Arrays.equals(willEncounteredObservableInterruptions, other.willEncounteredObservableInterruptions)) {
			return false;
		}
		return true;
	}

	public String toString(String header) {
		StringBuilder sb = new StringBuilder(header);
		sb.append("\n\t-------- State variables --------");
		sb.append("\n\tAge: " + this.age);
		sb.append("\n\tTime step: " + this.timeInEncounter);
		sb.append("\n\tPhenotype: " + Helper.arrayToString(this.phenotype));
		sb.append("\n\tEncountered resources: " + Helper.arrayToString(this.encounteredResourceType));
		sb.append("\n\tConsumed    resources: " + Helper.arrayToString(this.consumedResourceType));
		sb.append("\n\tSampled RESOURCE cues: " + Helper.arrayToString(this.resourceCues));
		sb.append("\n\tSampled DELAY cues: " + Helper.arrayToString(this.delayCues));
		sb.append("\n\tSampled INTERRUPTION cues: " + Helper.arrayToString(this.interruptionCues));
		sb.append("\n\n\t---------- Invariants ----------");
		sb.append("\n\tCurrent location: [p" + this.locationPatch +",s" + this.locationPatchState + "]");
		sb.append("\n\tPatch state at start encounter: " + this.patchStateWhenStartingEncounter);
		sb.append("\n\tLast visits: " + Helper.arrayToString(this.lastVisitToPatch));
		sb.append("\n\tLast States: " + Helper.arrayToString(this.patchStateOfLastVisit));
		sb.append("\n\tEncountered observable RESOURCE: " + Helper.arrayToString(this.valueIndexOfEncounteredObservableResources));
		sb.append("\n\tEncountered observable DELAY: " + Helper.arrayToString(this.durationIndexOfEncounteredObservableDelays));
		sb.append("\n\tEncountered observable INTERRUPTION: " + Helper.arrayToString(this.willEncounteredObservableInterruptions));
		
		return sb.toString();
	}
	
}
