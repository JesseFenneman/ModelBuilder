package states.RoamingStates;

import java.util.Iterator;
import java.util.concurrent.Callable;

import core.Model;
import interfaces_abstractions.ObserverManager;
import start.Console;
import states.EncounterStates.T2DecisionTree;
import states.RoamingStates.T1ActionState.StoredT2DecisionTree;

/** The T1ActionStateEvaluator is used during the BACKWARDS pass of the 
 * T1 decision tree. It takes an already expanded T1ActionState s (i.e., the
 * state 'knows' what T1 and T2 successor states are). It then asks the
 * T1ActionState to compute the expected fitness of all actions. For each search
 * action, computing the expected fitness entails a backwards pass of the T2DecisionTree
 * or T2DecisionTree's that result from that search action. After computing the
 * expected fitness of each action, the T1ActionState then determines which 
 * actions have the highest fitness (i.e., which actions should be in bestActions).
 * Finally, the expected fitness of a T1ActionState is equal to the expected fitness
 * of the best action. Note: the T1ActionState's  computeFitness() function
 * handles all these computations.
 * 
 *  Note 1: it is assumed that all possible T1 successor are already evaluated. This
 *  included all possible T1 states an agent might be in after going through a T2 Decision
 *  tree after this state. 
 * 
 * 	Note 2: this process will take some time. As such, hyper-threading is heavily advised here.
 * 
 * The call function returns a 0 if all went well, and a positive integer otherwise.
 * */
public class T1ActionStateEvaluator implements Callable<Integer> {

	private final T1ActionState state;
	private final Model model;
	private final boolean printToConsole;
	public T1ActionStateEvaluator(Model model, T1ActionState s, boolean printToConsole) {
		this.state = s;
		if (!state.wentThroughForwardsPass())
			throw new IllegalStateException("Trying to evaluate a non-expanded T1Action state");
		this.model = model;
		this.printToConsole = printToConsole;
	}
	
	
	@Override
	public Integer call() throws Exception {
		try {
			
			// Console.print("\tEvaluating T1ActionState: " + state.getName() );

			// Step 0: if we stored the T2DecisionTrees to disk after the forwards pass, 
			// the we first have to load these T2DecisionTree's from disk
			if (model.saveT2TreesToFile) {
				if (Model.printT2ProductionToConsole)
					Console.print("\tLoading T2DecisionTrees from disk...");

				for (Iterator<StoredT2DecisionTree> it = state.getAllStoredTrees().iterator(); it.hasNext();) {
					// Get the next StoredDecisionTree 
					StoredT2DecisionTree sdt = it.next();

					// Load from disk
					T2DecisionTree tree = model.outputFileManager.loadT2DecisionTree(sdt.treeName);

					// Reinflate the tree: reconnect the references in the decision tree to the rest of the model
					tree.reinflate(model, state);

					// Register the tree in the state
					state.registerT2DecisionTree(tree, sdt.actionThatResultedInTree, sdt.probabilityOfTreeGivenAction);

					// Remove the stored tree from the ArrayList
					it.remove();
				}
			}
			// Step 1: for each action, compute the expected fitness of performing that action in this state

			state.doBackwardsPass(printToConsole);
		} catch (Exception e) { 
			ObserverManager.notifyObserversOfError(e); 
			model.outputFileManager.writeExceptionToFile(e); 
			return 1;
			}


		return 0;

	}
	
	

}
