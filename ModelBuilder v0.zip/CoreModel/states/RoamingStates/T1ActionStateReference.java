package states.RoamingStates;

public class T1ActionStateReference extends T1AbstractStateReference {

	protected T1ActionStateReference(String name, int age, int patchStateLocation) {
		super(name, age, patchStateLocation);
	}

}
