package states.RoamingStates;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**In the background, the T1StateList uses a HashMap to find a canonical 
/* element of a set. Rather than having to specify this specifically, here
/* is a more intuitive wrapper. Specifically, this Map keeps track
 * of all existing T1ActionStates and T1MutationStates (T1FitnessStates have
 * there own special kind of map, as these do not depend on the location)
 * 
 */
public class CanonicalT1StateMap {
	// TODO: experiment with HashMap versus ConcurrentHashMap

	private final Map<T1ActionState, T1ActionState> actionStates;
	private final Map<T1MutationState, T1MutationState> mutationStates;

	/** If we have to reload a T2DecisionTree from disk, we need to connect
	 * the T1StateRefernces stored in that tree back to T1AbstractState. This
	 * map keeps track which string name corresponds to which T1AbstractState. */
	private final boolean keepTrackOfReferences;
	private final Map<String, T1ActionState> actionStateNameToActionState;
	private final Map<String, T1MutationState> mutationStateNameToMutationState;
	
	/** Create a new and empty CanonicalT1StateMap. If keepTrackOfReference is true, this map
	 * keeps track of which T1StateReference belongs to which T1AbstractState (only used when
	 * we have to ave parts of the model to disk)*/
	public CanonicalT1StateMap (int age, int patchStateLocation, boolean keepTrackOfReferences) {
		this.actionStates = new HashMap<>();
		this.mutationStates = new HashMap<>();

		this.keepTrackOfReferences = keepTrackOfReferences;
		if (keepTrackOfReferences) {
			actionStateNameToActionState = new HashMap<>();
			mutationStateNameToMutationState = new HashMap<>();
		} else{
			actionStateNameToActionState = null;
			mutationStateNameToMutationState = null;
		}
			
	}


	////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////// SETTERS //////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////

	/** Create a new ActionState from the factory and add this T1ActionState as the canonical value.
	 * Returns the resulting state*/
	private T1ActionState addActionState(T1ActionStateFactory stateFactory) {
		synchronized (actionStates) {
			if (stateFactory == null) 
				throw new IllegalArgumentException("Trying to add a T1ActionState with a null factory");
			
			// Check if the state has been added in the mean time
			T1ActionState stateInMap = actionStates.get(stateFactory);
			if (stateInMap != null)
				return stateInMap;
						
			// Else, create a new state and put that state in the map as its own canonical value
			T1ActionState newState = stateFactory.buildT1ActionState( actionStates.keySet().size());
			actionStates.put(newState, newState);
			
			if (keepTrackOfReferences)
				this.actionStateNameToActionState.put(newState.getName(), newState);
			
			return newState;
		}
	}

	/** Add this T1ActionState as the canonical value. Returns the state.*/
	private T1ActionState addActionState(T1ActionState state) {	
		synchronized (actionStates) {
			if (state == null)
				throw new IllegalArgumentException("Trying to add a T1ActionState with a null state");
			
			// Check if the state has been added in the mean time
			T1ActionState stateInMap = actionStates.get(state);
			if (stateInMap != null)
				return stateInMap;
			
			// Else, put the state in the map as its own canonical value
			actionStates.put(state, state);
			if (keepTrackOfReferences)
				this.actionStateNameToActionState.put(state.getName(), state);
			
			return state;
		}
	}

	/** Create a new MutationState from the factory and this T1MutationState as the canonical value.
	 * Returns the resulting state. */
	private T1MutationState addMutationState(T1MutationStateFactory stateFactory) {	
		synchronized (mutationStates) {
			if (stateFactory == null){
				throw new IllegalArgumentException("Trying to add a T1MutationState with a null factory");
			}

			// Check if the state has been added in the mean time
			T1MutationState stateInMap = mutationStates.get(stateFactory);
			if (stateInMap != null)
				return stateInMap;

			// Else, put the state in the map as its own canonical value
			T1MutationState newState = stateFactory.buildT1MutationState( mutationStates.keySet().size());
			mutationStates.put(newState, newState);
			if (keepTrackOfReferences)
				this.mutationStateNameToMutationState.put(newState.getName(), newState);
			return newState;
		}
	}

	/** Add this T1MutationState as the canonical value. Returns the state.*/
	private T1MutationState addMutationState(T1MutationState state) {	
		synchronized (mutationStates) {
			if (state== null){
				throw new IllegalArgumentException("Trying to add a T1MutationState with a null state");
			}
			// Check if the state has been added in the mean time
			T1MutationState stateInMap = mutationStates.get(state);
			if (stateInMap != null)
				return stateInMap;

			// Else, put the state in the map as its own canonical value
			mutationStates.put(state, state);
			if (keepTrackOfReferences)
				this.mutationStateNameToMutationState.put(state.getName(), state);
			return state;
		}
	}



	/////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////// ACTION STATE GETTERS //////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////

	/** Get the canonical T1ActionState that has the same values as the specified state.
	 * If no such canonical value exists yet, this state is added as its own canonical state.
	 *  */
	public T1ActionState getActionState(T1ActionState state) {	
		synchronized (actionStates) {
			T1ActionState result = actionStates.get(state);

			// If the result is null, add this state as its own canonical value
			if (result == null) 
				result = addActionState(state);

			return result;
		}
	}


	/** Get the canonical T1ActionState that has the same values as the state that results from the
	 *  specified factory. If no such canonical value exists yet, this state is added as its own canonical state.
	 *  (Note: this works because we've overwritten the equals() in the T1AbstractState and T1AbstractStateFactory classes.)*/
	public T1ActionState getActionState(T1ActionStateFactory stateFactory) {	
		synchronized (actionStates) {
			@SuppressWarnings("unlikely-arg-type")
			T1ActionState result = actionStates.get(stateFactory);

			// If the result is null, create the state from this factory add this state as its own canonical value
			if (result == null) 
				result = addActionState(stateFactory);

			return result;
		}
	}

	/** Returns all T1ActionStates in this map*/
	public Set<T1ActionState> getAllActionStates() {
		synchronized (actionStates) {
			Set<T1ActionState> set = actionStates.keySet();
			return set;
		}
	}

	/** Returns the number of ActionStates registered in this map*/
	public int numberOfT1ActionStates() {
		synchronized (actionStates) {
			return actionStates.size();
		}
	}


	////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////// MUTATION STATES GETTERS //////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////r


	/** Get the canonical T1MutationState that has the same values as the specified state.
	 * If no such canonical value exists yet, this state is added as its own canonical state.
	 *  */
	public T1MutationState getMutationState(T1MutationState state) {	
		//synchronized (mutationStates) {
			T1MutationState result = mutationStates.get(state);

			// If the result is null, add this state as its own canonical value
			if (result == null) 
				result = addMutationState(state);

			return result;
		//}
	}


	/** Get the canonical T1MutationState that has the same values as the state that results from the
	 *  specified factory. If no such canonical value exists yet, this state is added as its own canonical state.
	 *  (Note: this works because we've overwritten the equals() in the T1AbstractState and T1AbstractStateFactory classes.)*/
	public T1MutationState getMutationState(T1MutationStateFactory stateFactory) {	
		//synchronized (mutationStates) {

			@SuppressWarnings("unlikely-arg-type")
			T1MutationState result = mutationStates.get(stateFactory);

			// If the result is null, create the state from this factory add this state as its own canonical value
			if (result == null) 
				result = addMutationState(stateFactory);

			return result;
		//}
	}

	/** Returns all T1MutationStates in this map*/
	public Set<T1MutationState> getAllMutationStates() {
		//synchronized (mutationStates) {
			Set<T1MutationState> set = mutationStates.keySet();
			return set;
		//}
	}


	/** Returns the number of MutationStates registered in this map*/
	public int numberOfT1MutationStates() {
		//synchronized (mutationStates) {
			return mutationStates.size();
		//}
	}

	//////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////// OTHER //////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////

	/** Returns the T1ActionState that this reference points to. */
	public T1ActionState toActionState(T1ActionStateReference reference) {
		return this.actionStateNameToActionState.get(reference.name);
	}
	
	/** Returns the T1MutationState that this reference points to. */
	public T1MutationState toMutationState(T1MutationStateReference reference) {
		return this.mutationStateNameToMutationState.get(reference.name);
	}
	
	/** Returns the number of States registered in this map*/
	public int numberOfT1States() {
		synchronized (actionStates) {
			synchronized (mutationStates) {
				return this.numberOfT1ActionStates() +  this.numberOfT1MutationStates();
			}
		}
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actionStates == null) ? 0 : actionStates.hashCode());
		result = prime * result + ((mutationStates == null) ? 0 : mutationStates.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		synchronized (actionStates) {
			synchronized (mutationStates) {
			}
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			CanonicalT1StateMap other = (CanonicalT1StateMap) obj;
			if (actionStates == null) {
				if (other.actionStates != null) {
					return false;
				}
			} else if (!actionStates.equals(other.actionStates)) {
				return false;
			}

			if (mutationStates == null) {
				if (other.mutationStates != null) {
					return false;
				}
			} else if (!mutationStates.equals(other.mutationStates)) {
				return false;
			}
			return true;
		}
	}


}