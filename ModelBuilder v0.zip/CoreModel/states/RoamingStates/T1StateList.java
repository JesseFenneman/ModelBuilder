package states.RoamingStates;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.Model;
import helper.Helper;
import helper.Helper.Pair;
import stateInterfacesAndAbstractions.Path;
import states.EncounterStates.T2ActionState;
import states.EncounterStates.T2DecisionTree;
import states.EncounterStates.T2MutationState;

/** 
 * A StateList that can contain only T1States.
 * 
 * When running the model, the first step is to create all possible T1 states.
 * T1 states are the states an agent can be in between encounters.
 * 
 * Often, however, two actions from two separate states can result in the same successor state.
 * To prevent state aliasing, we need a central place to store which states are already 
 * computed. The T1StateList does that. 
 * 
 * Specifically, the T1StateList has a*l separate maps, one for each combination
 * of age (a) and patch STATE location (l). Each map stored all canonical states. A canonical 
 * states is the first state added that has a unique combination of phenotype and experiences. 
 * Note: canonical states do not differentiate between age or location! (This is also why the 
 * HashCode of T1 states does not rely on that state's age or location). 
 * 
 * During runtime, the T1StateList can be asked whether a state is already known using
 * getState(T1State) or getState(T1StateFactory). If a state that matches the state(factory)
 * is already computed, the T1StateList returns the already existing state. If not, it creates
 * a new state (if a stateFactory), and adds that state to the list. 
 */

// Does an agent know the state of the patch it is in?
public class T1StateList {


	// There are [age][location] separate Concurrent HashMaps to store states in.
	private final CanonicalT1StateMap[][] actionAndMutationMaps; //[age][location patch]
	private final CanonicalT1FitnessStateMap fitnessMap;
	private final int maximumAge;
	private final int maximumLocationPatchState;
	private final Model model;
	
	public final int numberOfDigits = 4;
	
	public T1StateList (Model model) {
		// figure out how many possible ages there are
		this.maximumAge = model.maximumAge+1;
		this.maximumLocationPatchState = model.ledger.patchStates.length;
		this.actionAndMutationMaps = new CanonicalT1StateMap[maximumAge][maximumLocationPatchState];
		for (int a = 0; a < maximumAge; a++)
			for (int l = 0; l < maximumLocationPatchState; l++) 
				actionAndMutationMaps[a][l] = new CanonicalT1StateMap(a,l, model.saveT2TreesToFile);

			
		this.fitnessMap = new CanonicalT1FitnessStateMap(model.saveT2TreesToFile);
		this.model = model;
	}

	
	/** If there is a T1ActionState with the same values as the argument state's values, this function
	 * returns a reference to the existing T1ActionState. Otherwise, this action state is added as its
	 * own canonical value, and is returned.*/
	public T1ActionState getActionState(T1ActionState actionState) {
		return actionAndMutationMaps[actionState.getAge()][actionState.getLocationPatchState()].getActionState(actionState);
	}

	/** If there is a T1ActionState with the same values as the argument factories values, this function
	 * returns a reference to the existing T1ActionState. Otherwise, a new action state is created from
	 * the factory, this state is added as its own canonical value, and this state returned.*/
	public T1ActionState getActionState(T1ActionStateFactory stateFactory) {
		return actionAndMutationMaps[stateFactory.age][stateFactory.locationPatch].getActionState( stateFactory);
	}

	/** Returns an unordered set of all known T1ActionStates for that age an location.*/
	public Set<T1ActionState> getAllActionStatesFor(int age, int patchStateLocation){
		return actionAndMutationMaps[age][patchStateLocation].getAllActionStates();
	}
	
	/** Returns an unordered set of all known T1ActionStates for that age in all locations.*/
	public Set<T1ActionState> getAllActionStatesFor(int age){
		Set<T1ActionState> set = new HashSet<>();
		for (int i = 0; i < this.maximumLocationPatchState; i ++)
			set.addAll( actionAndMutationMaps[age][i].getAllActionStates());
		return set;
	}
	
	
	/** If there is a T1ActionState with the same values at the argument state, this function
	 * returns a reference to the existing T1MutationState. Otherwise, this mutation state is added as its
	 * own canonical value, and is returned.*/
	public T1MutationState getMutationState(T1MutationState mutationState) {
		return actionAndMutationMaps[mutationState.getAge()][mutationState.getLocationPatchState()].getMutationState(mutationState);
	}


	/** If there is a T1MutationState with the same values at the argument state, this function
	 * returns a reference to the existing T1MutationState. Otherwise, a new mutation state is created from
	 * the factory, this state is added as its own canonical value, and this state returned.*/
	public T1MutationState getMutationState(T1MutationStateFactory stateFactory) {
		return actionAndMutationMaps[stateFactory.age][stateFactory.locationPatch].getMutationState( stateFactory);
	}

	/** Returns an unordered set of all known T1MutationStates for that age an location. */
	public Set<T1MutationState> getAllMutationStatesFor(int age, int patchStateLocation){
		return actionAndMutationMaps[age][patchStateLocation].getAllMutationStates();
	}
	
	/** Returns an unordered set of all known T1MutationStates for that age an location.*/
	public Set<T1MutationState> getAllMutationStatesFor(int age){
		Set<T1MutationState> set = new HashSet<>();
		for (int i = 0; i < this.maximumLocationPatchState; i ++)
			set.addAll( actionAndMutationMaps[age][i].getAllMutationStates());
		return set;
	}
	/** If there is already a T1FitnessState with the same values at the argument state, this function
	 * returns a reference to the existing T1FitnessState. If no such state exists yet, this function
	 * adds the argument state to the List, and returns the argument state. */
	public T1FitnessState getFitnessState(T1FitnessState fitnessState) {
		return fitnessMap.getFitnessState(fitnessState);
	}


	/** If there is already a T1FitnessState with the same values at the argument stateFactory, this function
	 * returns a reference to the existing T1FitnessState. If no such state exists yet, this function
	 * creates a new state from the factory, adds this new state to the Map, and returns the new state.
	 * */
	public T1FitnessState getFitnessState(T1FitnessStateFactory stateFactory) {
		return fitnessMap.getFitnessState( stateFactory);
	}

	/** Returns the number of action states registered for this age and location (patch state, not patch) in this 
	 * StateList thus far. This does not have to be the total, final number of states. */
	public int numberOfActionStates(int age, int patchState) {
		return actionAndMutationMaps[age][patchState].numberOfT1ActionStates();
	}

	/** Returns the number of mutation states registered for this age and location (patch state, not patch) in this 
	 * StateList thus far. This does not have to be the total, final number of states. */
	public int numberOfMutationStates(int age, int patchState) {
		return actionAndMutationMaps[age][patchState].numberOfT1MutationStates();
	}

	/** Returns the number of fitness states registered for this age and location (patch state, not patch) in this 
	 * StateList thus far. This does not have to be the total, final number of states. */
	public int numberOfFitnessStates(int age, int patchState) {
		return fitnessMap.numberOfT1FitnessStates();
	}


	///////////////////////////////////////////////////////////////////////
	//////////////////////// ToString for debugging //////////////////////
	/////////////////////////////////////////////////////////////////////
	@Override

	/** Creates a textual overview of all the states in this StateList. First
	 * a table with all states in a single line is printed. Next, each states is
	 * given a full description.*/
	public String toString() {
		StringBuilder sb = new StringBuilder("T1StateList.\nBrief description - the T1StateList contains the following states:\n\n");

		// Find the number of characters in the longest string
		int columnWidth = 20;
		for (String s : model.ledger.phenotypeNames)
			if (s.length() > columnWidth) columnWidth = s.length();

		/* Print the following column headers: 
		name, 
		type, 
		age, 
		location, 
		phenotype1, 
		..., 
		phenotypeN, 
		Last visit to patch [patch1], 
		Last seen state of patch [patch1], 
		... 
		Last visit to patch [patchN], 
		Last seen state of patch [patchN]
		Possible actions
		E[Fitness|a1]
		...
		E[Fitness|aN]
		Best actions
		E[Fitness]
		E[Age]
		E[phenotype1]
		...
		E[phenotypeN]
		E[#Immediate T1 1]
		...
		E[#Immediate T1 N]
		E[#Future T1 1]
		...
		E[#Future T1 N]
		E[#Immediate T2 1]
		...
		E[#Immediate T2 N]
		E[#Future T2 1]
		...
		E[#Future T2 N]
		Destinations

		 */

		int columns = 4 + model.ledger.numberOfNonAgePhenotypicDimensions + model.ledger.numberOfPatches*2 + 1 + model.ledger.numberOfT1Actions + 1 + 1 + 1 + model.ledger.numberOfNonAgePhenotypicDimensions+
				model.ledger.numberOfT1Actions+model.ledger.numberOfT1Actions+model.ledger.numberOfT2Actions + model.ledger.numberOfT2Actions+ 1;

		// For each age and location, print the states (ordered by current location)
		for (int a = 0; a < this.maximumAge; a++) {
			for (int loc = 0; loc < this.maximumLocationPatchState; loc ++) {
				if (this.actionAndMutationMaps[a][loc].numberOfT1States() > 0) {
					sb.append("\n\nAge " + a + ", Patch "+ loc + ", (" + actionAndMutationMaps[a][loc].numberOfT1States()+" states):\n" + createColumnHeaderStringActionAndMutation(columnWidth, columns) );
					sb.append(printActionAndMutationStates(a, loc, columnWidth, columns));
				}
			}
		}

		// Print all the fitness states
		sb.append("\n\nFitness states (" + fitnessMap.numberOfT1FitnessStates() + " states):\n" + createColumnHeaderStringFitness(columnWidth) );
		sb.append(printFitnessStates(columnWidth));
		return sb.toString();
	}

	private String createColumnHeaderStringActionAndMutation(int columnWidth, int columns) {
		StringBuilder sb = new StringBuilder();

		/* Print the following column headers: 
			name, 
			type, 
			age, 
			location, 
			phenotype1, 
			..., 
			phenotypeN, 
			Last visit to patch [patch1], 
			Last seen state of patch [patch1], 
			... 
			Last visit to patch [patchN], 
			Last seen state of patch [patchN]
			Possible actions
			E[Fitness|a1]
			...
			E[Fitness|aN]
			Best actions
			E[Fitness]
			E[Age]
			E[phenotype1]
			...
			E[phenotypeN]
			E[#Immediate T1 1]
			...
			E[#Immediate T1 N]
			E[#Future T1 1]
			...
			E[#Future T1 N]
			E[#Immediate T2 1]
			...
			E[#Immediate T2 N]
			E[#Future T2 1]
			...
			E[#Future T2 N]
			Destinations
			
		*/
		String name = "Name";
		String nameSpaced = name + Helper.repString(" ", columnWidth - name.length()) + "| ";
		sb.append(nameSpaced);

		String type= "Type";
		String typeSpaced = type + Helper.repString(" ", columnWidth - type.length()) + "| ";
		sb.append(typeSpaced);

		String age = "Age";
		String ageSpaced = age + Helper.repString(" ", columnWidth - age.length()) + "| ";
		sb.append(ageSpaced);

		String loc = "Location";
		String locSpaced = loc + Helper.repString(" ", columnWidth - loc.length()) + "| ";
		sb.append(locSpaced);

		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s = model.ledger.phenotypeNames[i];
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		for (int i = 0; i < model.ledger.numberOfPatches; i++) {
			String visit = "Last visit ["+ i + "]";
			String visitSpaced = visit + Helper.repString(" ", columnWidth - visit.length()) + "| ";
			sb.append(visitSpaced);

			String state = "Last state ["+ i + "]";
			String stateSpaced = state + Helper.repString(" ", columnWidth - state.length()) + "| ";
			sb.append(stateSpaced);
		}
	
		String action = "Possible actions";
		String actionSpaced = action + Helper.repString(" ", columnWidth - action.length()) + "| ";
		sb.append(actionSpaced);

		for (int i = 0; i < model.ledger.numberOfT1Actions; i++) {
			String s = "E[Fitness|" + model.ledger.t1ActionNames[i] + "]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
		
		String bestAction = "Best actions";
		String bestActionSpaced = bestAction + Helper.repString(" ", columnWidth - bestAction.length()) + "| ";
		sb.append(bestActionSpaced);

		String fitness = "E[Fitness]";
		String fitnessSpaced = fitness + Helper.repString(" ", columnWidth - fitness.length()) + "| ";
		sb.append(fitnessSpaced);
		
		String expectedAge = "E[Age]";
		String expectedAgeSpaced = expectedAge + Helper.repString(" ", columnWidth - expectedAge.length()) + "| ";
		sb.append(expectedAgeSpaced);
		
		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s = "E["+model.ledger.phenotypeNames[i] + "]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
		
		for (int i = 0; i < model.ledger.numberOfT1Actions; i++) {
			String s = "E[I1#" + model.ledger.t1ActionNames[i] + "]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
		
		for (int i = 0; i < model.ledger.numberOfT1Actions; i++) {
			String s = "E[F1#" + model.ledger.t1ActionNames[i] + "]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
		
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s = "E[I2#" + model.ledger.t2ActionNames[i] + "]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
		
		
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s = "E[F2#" + model.ledger.t2ActionNames[i] + "]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
		
		
		String destination = "Destination";
		sb.append(destination);

		// Print the line under the column names
		sb.append("\n");
		for (int i = 0; i < columns; i++)
			sb.append(Helper.repString("-", columnWidth)  + "| ");
		return sb.toString();
	}

	private String printActionAndMutationStates(int age, int loc, int columnWidth, int columns) {

		CanonicalT1StateMap currentMap = actionAndMutationMaps[age][loc];
		StringBuilder sb = new StringBuilder();

		// Get all the states
		ArrayList<T1ActionState> unsortedActions = new ArrayList<>();
		ArrayList<T1MutationState> unsortedMutatons = new ArrayList<>();


		unsortedActions.addAll(currentMap.getAllActionStates());
		unsortedMutatons.addAll(currentMap.getAllMutationStates());
		
		// Create a Comparator
		Comparator<T1AbstractState> comparator = new Comparator<T1AbstractState>() {

			@Override
			public int compare(T1AbstractState o1, T1AbstractState o2) {
				
				// First: sort on ID number
				if (o1.getID()< o2.getID())
					return -1;
				else if (o1.getID() > o2.getID())
					return 1;
				return 0;
			}
		};

		// Order the states by name
		Collections.sort(unsortedActions, comparator);
		Collections.sort(unsortedMutatons, comparator);


		for (T1ActionState actionState: unsortedActions)
			sb.append(printIndividualActionOrMutationState(actionState, "Action", columnWidth));

		for (T1MutationState mutationState: unsortedMutatons)
			sb.append(printIndividualActionOrMutationState(mutationState, "<<Mutation>>", columnWidth));


		return sb.toString();
	}

	private String printIndividualActionOrMutationState(T1AbstractState state, String type, int columnWidth){
		StringBuilder sb = new StringBuilder("\n");
		
		
		/* Print the following column headers: 
		name, 
		type, 
		age, 
		location, 
		phenotype1, 
		..., 
		phenotypeN, 
		Last visit to patch [patch1], 
		Last seen state of patch [patch1], 
		... 
		Last visit to patch [patchN], 
		Last seen state of patch [patchN]
		Possible actions
		E[Fitness|a1]
		...
		E[Fitness|aN]
		Best actions
		E[Fitness]
		E[Age]
		E[phenotype1]
		...
		E[phenotypeN]
		E[#Immediate T1 1]
		...
		E[#Immediate T1 N]
		E[#Future T1 1]
		...
		E[#Future T1 N]
		E[#Immediate T2 1]
		...
		E[#Immediate T2 N]
		E[#Future T2 1]
		...
		E[#Future T2 N]
		Destinations
		
	*/
		String name = state.getName();
		String nameSpaced = name + Helper.repString(" ", columnWidth - name.length()) + "| ";
		sb.append(nameSpaced);

		String typeSpaced = type + Helper.repString(" ", columnWidth - type.length()) + "| ";
		sb.append(typeSpaced);

		String age = state.age +"";
		String ageSpaced = age + Helper.repString(" ", columnWidth - age.length()) + "| ";
		sb.append(ageSpaced);

		String loc =  "["+state.locationPatch+ "/"+ state.locationPatchState+ "]";
		String locSpaced = loc + Helper.repString(" ", columnWidth - loc.length()) + "| ";
		sb.append(locSpaced);

		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s = state.phenotype[i] + "";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		for (int i = 0; i < model.ledger.numberOfPatches; i++) {
			String visit = state.lastVisitToPatch[i] +"";
			String visitSpaced = visit + Helper.repString(" ", columnWidth - visit.length()) + "| ";
			sb.append(visitSpaced);

			String s= state.patchStateOfLastVisit[i] + "";
			String stateSpaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(stateSpaced);
		}

		String possibleActions =  "";
		if (!(state instanceof T1ActionState))
			possibleActions = "-";
		else if (((T1ActionState) state).getPossibleActions() == null)
			possibleActions = "";
		else {
			ArrayList<Integer> possibleActionsList = ((T1ActionState) state).getPossibleActions();
			StringBuilder a = new StringBuilder();
			a.append("[");
			for (int i = 0; i < possibleActionsList.size(); i ++) {
				a.append(possibleActionsList.get(i));
				if (i != (possibleActionsList.size()-1) && possibleActionsList.size()>0)
					a.append(",");
			}
			a.append("]");
			possibleActions = a.toString();
		}

		String possibleActionsSpaced = possibleActions + Helper.repString(" ", columnWidth - possibleActions.length()) + "| ";
		sb.append(possibleActionsSpaced);

		// Fitness of actions. Empty for mutation states or action states that have not gone through a backwards pass yet
		for (int i = 0; i < model.ledger.numberOfT1Actions; i++) {
			String s;
			if (state instanceof T1ActionState && state.wentThroughBackwardsPass()) //if it knows it fitness, it went through the backwards pass
				s = ((T1ActionState) state).getExpectedFitnessOfAction(i).toString(numberOfDigits);
			else if (!state.wentThroughBackwardsPass())
				s = "Not backwards yet";
			else
				s = "";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		
		
		String bestAction;
		if (state instanceof T1ActionState && state.wentThroughBackwardsPass()) { //if it knows it fitness, it went through the backwards pass
			bestAction = "";
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
				if (((T1ActionState)state).isBestAction[a])
					bestAction = bestAction + a + " ";
		}
		else if (state instanceof T1ActionState)
			bestAction = "Not backwards yet";
		else
			bestAction = "";
		String bestActionSpaced = bestAction + Helper.repString(" ", columnWidth - bestAction.length()) + "| ";
		sb.append(bestActionSpaced);

		String expectedFitness;
		if (state.wentThroughBackwardsPass())
			expectedFitness = state.getExpectedFitness().toString(numberOfDigits);
		else 
			expectedFitness = "Not backwards yet";
		String fitnessSpaced = expectedFitness + Helper.repString(" ", columnWidth - expectedFitness.length()) + "| ";
		sb.append(fitnessSpaced);

				
		String expectedAge;
		if (state.wentThroughBackwardsPass())
			expectedAge = state.getExpectedAge().toString(numberOfDigits);
		else 
			expectedAge = "Not backwards yet";
		String expectedAgeSpaced = expectedAge + Helper.repString(" ", columnWidth - expectedAge.length()) + "| ";
		sb.append(expectedAgeSpaced);

		// Expected phenotypes
		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s;
			if (state.wentThroughBackwardsPass()) 
				s = state.getExpectedPhenotype(i).toString(numberOfDigits);
			else 
				s = "Not backwards yet";
			
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
		
		// Immediate T1 actions (action state only)
		for (int i = 0; i < model.ledger.numberOfT1Actions; i++) {
			String s;
			if (state instanceof T1MutationState)
				s = "";
			else if (state.wentThroughBackwardsPass()) 
				s = ((T1ActionState)state).getProbabilityOfImmediateAction(i).toString(numberOfDigits);
			else 
				s = "Not backwards yet";

			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
		
		// Future T1 actions
		for (int i = 0; i < model.ledger.numberOfT1Actions; i++) {
			String s;
			if (state.wentThroughBackwardsPass()) 
				s = state.getFutureTimesItPerformsT1Action(i).toString(numberOfDigits);
			else 
				s = "Not backwards yet";

			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		// Immediate T1 actions (action state only, and only if there is a best action that is a search action)
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s;
			if (state instanceof T1MutationState)
				s = "";
			else if (state.wentThroughBackwardsPass()) {
				NumberObjectSingle expectedImmediateT2 = ((T1ActionState) state).getExpectedNumberOfImmediateTreeT2Actions(i);
				if (expectedImmediateT2 == null)
					s = "NS";
				else
					s = expectedImmediateT2.toString(numberOfDigits);
			}
			else 
				s = "Not backwards yet";

			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
		
		// Future T2 actions
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s;
			if (state.wentThroughBackwardsPass()) 
				s = state.getFutureTimesItPerformsT2Action(i).toString(numberOfDigits);
			else 
				s = "Not backwards yet";

			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}
				
		String connections = "";
		if (state instanceof T1ActionState) {
			T1ActionState s = (T1ActionState)state;
			if (!s.wentThroughForwardsPass())
				connections = "Not expanded yet";
			else {
				StringBuilder actionBuilder = new StringBuilder();
				for (int a = 0; a < s.getPossibleActions().size(); a++) {
					if (s.getProbabilityOfImmediateAction(a).largerThan(0)) {
						actionBuilder.append("{" + model.ledger.t1ActionNames[s.getPossibleActions().get(a)] + "| ");

						if (model.ledger.t1Actions[a].isSearchAction()) {
							for (Pair<T2DecisionTree, NumberObjectSingle> p: s.resultingT2DecisionTrees.get(a)) 
								actionBuilder.append(p.element1.name+ "(" + p.element1.treeStateList.numberOfActionStates() + "A," + p.element1.treeStateList.numberOfMutationStates() + "M, p=" + p.element2.toString(numberOfDigits) + ")  ");
							actionBuilder.append("}\t");

						} else {
							for (Path<T1ActionState, T1MutationState> p : s.getSuccessorT1MutationPaths(s.getPossibleActions().get(a)))
								actionBuilder.append(p.toDestinationString() + ";");
							for (Path<T1ActionState, T1FitnessState> p : s.getSuccessorT1FitnessPaths(s.getPossibleActions().get(a)))
								actionBuilder.append(p.toDestinationString() + ";");
							actionBuilder.append("}\t");
						}
					}
				}
				connections = actionBuilder.toString();
			}
		} else if (state instanceof T1MutationState) {
			T1MutationState s = (T1MutationState) state;
			if (!s.wentThroughForwardsPass())
				connections = "Not mutated yet";
			else
			{
				StringBuilder mutationBuilder = new StringBuilder();
				for (Path<T1MutationState, T1ActionState> p : s.getSuccessorT1ActionPaths())
					mutationBuilder.append(p.toDestinationStringIncludingAnnotation() + "; \t");
				for (Path<T1MutationState, T1FitnessState> p : s.getSuccessorT1FitnessPaths())
					mutationBuilder.append(p.toDestinationStringIncludingAnnotation() + "; \t");
				connections = mutationBuilder.toString();
			}

		}
		sb.append(connections);

		return sb.toString();
	}

	private String createColumnHeaderStringFitness(int columnWidth) {
	
		StringBuilder sb = new StringBuilder();
		
		// Print the following column fields: name, type, age, phenotype1, ..., phenotypeN, Fitness, Origin
		int columns =  5 + model.ledger.numberOfNonAgePhenotypicDimensions;
		
		String name = "Name";
		String nameSpaced = name + Helper.repString(" ", columnWidth - name.length()) + "| ";
		sb.append(nameSpaced);

		String type= "Type";
		String typeSpaced = type + Helper.repString(" ", columnWidth - type.length()) + "| ";
		sb.append(typeSpaced);

		String age = "Age";
		String ageSpaced = age + Helper.repString(" ", columnWidth - age.length()) + "| ";
		sb.append(ageSpaced);

		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s = model.ledger.phenotypeNames[i];
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		

		String fitness = "Fitness";
		String fitnessSpaced = fitness+ Helper.repString(" ", columnWidth - fitness.length()) + "| ";
		sb.append(fitnessSpaced);



		String connections = "connections";
		sb.append(connections);

		// Print the line under the column names
		sb.append("\n");
		for (int i = 0; i < columns; i++)
			sb.append(Helper.repString("-", columnWidth)  + "| ");
		return sb.toString();
	}
	
	private String printFitnessStates(int columnWidth) {

		StringBuilder sb = new StringBuilder();

		// Get all the fitnes states
		ArrayList<T1FitnessState> unsortedFitness = new ArrayList<>();
		unsortedFitness.addAll(fitnessMap.getAllFitnessStates());

		// Create a Comparator
		Comparator<T1AbstractState> comparator = new Comparator<T1AbstractState>() {

			@Override
			public int compare(T1AbstractState o1, T1AbstractState o2) {
				// First: sort on age, then on phenotype
				if (o1.getAge()< o2.getAge())
					return -1;
				else if (o1.getAge() > o2.getAge())
					return 1;

				for (int p = 0; p < model.ledger.numberOfNonAgePhenotypicDimensions; p++)
					if (o1.phenotype[p]< o2.phenotype[p])
						return -1;
					else if (o1.phenotype[p]> o2.phenotype[p])
						return 1;


				return 0;
			}
		};

		// Order the states by name
		Collections.sort(unsortedFitness, comparator);

		for (T1FitnessState s: unsortedFitness)
			sb.append(printIndividualFitnessState(s, columnWidth));

		return sb.toString();
	}

	private String printIndividualFitnessState(T1FitnessState state, int columnWidth){
		StringBuilder sb = new StringBuilder("\n");

		// Print the following column fields: name, type, age, phenotype1, ..., phenotypeN, Fitness, Originss
		String name = state.getName();
		String nameSpaced = name + Helper.repString(" ", columnWidth - name.length()) + "| ";
		sb.append(nameSpaced);

		String typeSpaced = "Fitness" + Helper.repString(" ", columnWidth - "Fitness".length()) + "| ";
		sb.append(typeSpaced);

		String age = state.age +"";
		String ageSpaced = age + Helper.repString(" ", columnWidth - age.length()) + "| ";
		sb.append(ageSpaced);

		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s = state.phenotype[i] + "";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		String fitness = state.getExpectedFitness().toStringWithoutTrailingZeros();
		String fitnessSpaced = fitness + Helper.repString(" ", columnWidth - fitness.length()) + "| ";
		sb.append(fitnessSpaced);

		String origin = "";
		StringBuilder originBuilder = new StringBuilder();
	
		origin = originBuilder.toString();
		sb.append(origin);

		return sb.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(actionAndMutationMaps);
		result = prime * result + ((fitnessMap == null) ? 0 : fitnessMap.hashCode());
		result = prime * result + maximumAge;
		result = prime * result + maximumLocationPatchState;
		return result;
	}

	///////////////////////////////////////////////////////////////////////
	//////////////////////// ToString for results ////////////////////////
	/////////////////////////////////////////////////////////////////////
	/** Get a list of all variable names that are to be stored. This list
	 * is used to create the column headers, and should mirror perfectly 
	 * the order in actionOrMutationStateToEntry().*/
	private ArrayList<String> getStateSpecificVariableNames() {
		ArrayList<String> variableNames = new ArrayList<>();
		
		////// First, all state identifiers
		// 1. Name
		variableNames.add("Name");
		// 2. Type
		variableNames.add("Type");
		// 3. Age
		variableNames.add("Age");
		// 4. Location (patch)
		variableNames.add("LocationPatch");
		// 5. Location (patch state)
		variableNames.add("LocationPatchState");
		// 6. Phenotypes (in original metric)
		for (int p = 0; p < model.ledger.numberOfNonAgePhenotypicDimensions; p++)
			variableNames.add(model.ledger.phenotypeNames[p]);
		// 7. Last visit/last patch combinations
		for (int patch = 0; patch < model.ledger.numberOfPatches; patch++) {
			variableNames.add("LastVisitPatch_"+ model.ledger.patchNames[patch] );
			variableNames.add("LastStatePatch_"+ model.ledger.patchNames[patch] );
		}
		// 8. Possible action? For each T1 action: is this action possible? (TRUE/FALSE)
		// (Print 'NULL' for T1MutationStates)
		for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
			variableNames.add("T1ActionPossible_" + model.ledger.t1ActionNames[a] );
		
		
		///// Second, all the variables we computed in the backwards pass
		// 9. Expected fitness of each T1 action (print 'NULL' for T1MutationStates)
		for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
			variableNames.add("ExpectedFitnessT1Action_" + model.ledger.t1ActionNames[a] );
		
		// 10. Best action? For each T1 action: is this action a best action? (TRUE/FALSE)
		// (Print 'NULL' for T1MutationStates)
		for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
			variableNames.add("IsBestAction_" + model.ledger.t1ActionNames[a] );
		// 11. Expected fitness state
		variableNames.add("ExpectedFitnessState");
		// 12. Expected age
		variableNames.add("ExpectedAge");
		// 12a. Expected immediate time steps spend waiting/postponing
		variableNames.add("ExpectedImmediateDelay");
		// 12b. Expected future time steps waiting/postponing
		variableNames.add("ExpectedTotalDelay");
		// 13. Expected phenotypes (in original metric)
		for (int p = 0; p < model.ledger.numberOfNonAgePhenotypicDimensions; p++)
			variableNames.add("Expected" + Helper.capitalize(model.ledger.phenotypeNames[p]));
		
		// 14. Expected number of immediate T1 actions, one for each T1 action
		for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
			variableNames.add("ExpectedImmediateNumber_" + model.ledger.t1ActionNames[a] );
		
		// 15. Expected number of future T1 actions, one for each T1 action
		for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
			variableNames.add("ExpectedFutureNumber_" + model.ledger.t1ActionNames[a] );
		
		// 16. Expected number of total T1 actions (Future + immediate), one for each T1 action
		for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
			variableNames.add("ExpectedTotalNumber_" + model.ledger.t1ActionNames[a] );
		
		
		
		// 17. Expected number of immediate T2 actions, one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			variableNames.add("ExpectedImmediateNumber_" + model.ledger.t2ActionNames[a] );
		
		// 18. Expected number of future T2 actions, one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			variableNames.add("ExpectedFutureNumber_" + model.ledger.t2ActionNames[a] );
		
		// 19. Expected number of total T2 actions (Future + immediate), one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			variableNames.add("ExpectedTotalNumber_" + model.ledger.t2ActionNames[a] );
		
		return variableNames;
	}
	
	/** Takes as input a String containing all model-invariant variable names separated by
	 * the delimiter. These are the variables that are fixed within a model (i.e., the
	 * sampling distributions of all non-phenotype objects). It appends to this the variable names
	 * that are state-specific (e.g., the expected age, etc). The resulting string does 
	 * NOT end with a delimiter, but rather, with a field called "FINALENDINGFIELD" to provide
	 * a check that all fields have been written correctly.*/
	private String appendColumnHeaders(String fixedColumnHeaders, ArrayList<String> stateSpecificVariableNames, String delimiter) {
		StringBuilder sb = new StringBuilder(fixedColumnHeaders);
		for (String columnName : stateSpecificVariableNames)
			sb.append(columnName + delimiter);
		sb.append("FINALENDINGFIELD");
		return sb.toString();
	}
	
	/** Convert one T1Action or one T1MutationState to a list of Strings that
	 * represents the state. Used to create the final results file. 
	 * 
	 * The variables used should mirror the order in getStateSpecificVariableNames()! */
	private ArrayList<String> actionOrMutationStateToArrayListOfFields(T1AbstractState state){
		// Get all fields into strings, without delimiters yet
		ArrayList<String> fields = new ArrayList<>();;

		////// First, all state identifiers
		// 1. Name
		fields.add(state.getName());
		// 2. Type
		if (state instanceof T1ActionState)
			fields.add("Action");
		else if (state instanceof T1MutationState)
			fields.add("Mutation");
		else 
			throw new IllegalStateException("T1State is neither action, mutation, or fitness.");
		// 3. Age
		fields.add(""+state.getAge());
		// 4. Location (patch)
		fields.add(""+state.getLocationPatch());
		// 5. Location (patch state)
		fields.add(""+state.getLocationPatchState());
		// 6. Phenotypes (in original metric)
		for (int p = 0; p < model.ledger.numberOfNonAgePhenotypicDimensions; p++)
			fields.add(model.ledger.getValueOfPhenotype(p, state.getPhenotypeValue(p)).toPlainString());
		// 7. Last visit/last patch combinations
		for (int patch = 0; patch < model.ledger.numberOfPatches; patch++) {
			fields.add(""+state.lastVisitToPatch[patch]);
			fields.add(""+state.patchStateDuringLastVisit(patch));
		}
		// 8. Possible action? For each T1 action: is this action possible? (TRUE/FALSE)
		// (Print 'NULL' for T1MutationStates)
		if (state instanceof T1MutationState)
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++) 
				fields.add("NULL");
		else if (state instanceof T1ActionState) {
			boolean[] isPossible = ((T1ActionState)state).isPossibleAction();
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++) 
				fields.add("" + isPossible[a]);
		}
		else 
			throw new IllegalStateException("T1State is neither action, mutation, or fitness.");


		///// Second, all the variables we computed in the backwards pass
		// 9. Expected fitness of each T1 action (print 'NULL' for T1MutationStates)
		if (state instanceof T1MutationState)
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++) 
				fields.add("NULL");
		else if (state instanceof T1ActionState) {
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++) 
				fields.add("" + ((T1ActionState)state).getExpectedFitnessGivenAction(a).toPlainString());
		}
		else 
			throw new IllegalStateException("T1State is neither action, mutation, or fitness.");

		// 10. Best action? For each T1 action: is this action a best action? (TRUE/FALSE)
		// (Print 'NULL' for T1MutationStates)
		if (state instanceof T1MutationState)
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++) 
				fields.add("NULL");
		else if (state instanceof T1ActionState) {
			boolean[] isBest = ((T1ActionState)state).isBestAction;
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++) 
				fields.add("" + isBest[a]);
		}
		else 
			throw new IllegalStateException("T1State is neither action, mutation, or fitness.");

		// 11. Expected fitness state
		fields.add(state.getExpectedFitness().toPlainString());
		// 12. Expected age
		fields.add(state.getExpectedAge().toPlainString());
		
		// 12a. Expected immediate time steps spend waiting/postponing
		if (state instanceof T1MutationState)
			fields.add("NULL");
		else if (state instanceof T1ActionState) {
			fields.add(""+((T1ActionState)state).getExpectedImmediateTimestepsInDelay());
		}
		else 
			throw new IllegalStateException("T1State is neither action, mutation, or fitness."); 
			
		// 12b. Expected future time steps waiting/postponing
		fields.add("" + state.getExpectedTotalTimeStepsInDelay());
		
		
		// 13. Expected phenotypes (in original metric)
		for (int p = 0; p < model.ledger.numberOfNonAgePhenotypicDimensions; p++)
			fields.add(model.ledger.phenotypeExpectedLedgerIndexToOriginalMetric(p, state.getExpectedPhenotype(p)).toPlainString());

		// 14. Expected number of immediate T1 actions, one for each T1 action
		if (state instanceof T1MutationState)
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++) 
				fields.add("NULL");
		else if (state instanceof T1ActionState) {
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++) 
				fields.add("" + ((T1ActionState)state).probabilityOfImmediateT1Action[a].toPlainString());
		}
		else 
			throw new IllegalStateException("T1State is neither action, mutation, or fitness.");

		// 15. Expected number of future T1 actions, one for each T1 action
		for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
			fields.add(state.getFutureTimesItPerformsT1Action(a).toPlainString());

		// 16. Expected number of total T1 actions (Future + immediate), one for each T1 action
		if (state instanceof T1MutationState)
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
				fields.add(state.getFutureTimesItPerformsT1Action(a).toPlainString());
		else if (state instanceof T1ActionState) 
			for (int a = 0; a < model.ledger.numberOfT1Actions; a++) {
				// Add future and immediate
				NumberObjectSingle immediate = ((T1ActionState)state).probabilityOfImmediateT1Action[a];
				NumberObjectSingle future = state.getFutureTimesItPerformsT1Action(a);
				fields.add(immediate.add(future, false).toPlainString());
			}


		// 17. Expected number of immediate T2 actions, one for each T2 action
		if (state instanceof T1MutationState)
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("NULL");
		else if (state instanceof T1ActionState) {
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("" + ((T1ActionState)state).expectedNumberOfImmediateTreeT2Actions[a].toPlainString());
		}
		else 
			throw new IllegalStateException("T1State is neither action, mutation, or fitness.");


		// 18. Expected number of future T2 actions, one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			fields.add(state.getFutureTimesItPerformsT2Action(a).toPlainString());

		// 19. Expected number of total T2 actions (Future + immediate), one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			fields.add(state.getFutureTimesItPerformsT2Action(a).toPlainString());

		return fields;
	}

	/** Writes one T1ActionState or one T1MutationState as an entry in the final 
	 * results file. Specifically, it appends all the requires fields of the T1State
	 * to the fixedVariables (which contain all model-invariant values), which are
	 * separated by the delimiter. The fixedVariables should already end with a delimiter.
	 * Each entry ends with a 'FULLSTOP' to make sure that all fields are written.
	 */
	private String actionOrMutationStateToEntry (T1AbstractState state, String fixedVariables, String delimiter, ArrayList<String> columnHeaders) {
		if (state instanceof T1FitnessState) 
			throw new IllegalArgumentException("Cannot use stateToEntry to print T1FitnessStates. Use fitnessStateToEntry() instead.");
		if (!state.wentThroughBackwardsPass()) 
			throw new IllegalArgumentException("Cannot write results for a state that has not gone through the backwards pass yet.");
		
		// Create an ArrayList of Strings based on this state
		ArrayList<String> fieldStrings = this.actionOrMutationStateToArrayListOfFields(state);
		
		// Check if the number of fields in the state matches the number of column headers 
		if (fieldStrings.size() != columnHeaders.size()) {
			StringBuilder headers = new StringBuilder();
			for (String s: columnHeaders)
				headers.append(s + "\n");
			StringBuilder fields = new StringBuilder();
			for (String s: fieldStrings)
				fields.append(s + "\n");
			throw new IllegalArgumentException("Fields size does not match column header size. Number of fields: " + fieldStrings.size() + ", number of column headers: "+ columnHeaders.size()
			+ ". Headers:\n" + headers + "\n\n\nFields:\n" + fields.toString() );
		}

		// Append each field to fixedVariables, using a delimiter in between (fixedVariables already ends with one, so we do not 
		// have to append a delimiter here first)
		StringBuilder sb = new StringBuilder(fixedVariables);
		for (String field : fieldStrings)
			sb.append(field + delimiter);
		
		// End with a FULLSTOP
		sb.append("FULLSTOP");
		return sb.toString();
	}

	/** Creates a String that represents the results for that age. The model invariant
	 * variables are used as prefixes for the column names and the entries.*/
	public String toResultsStringForAge(String modelInvariantColumnNames, 
			String modelInvariantValues,
			String delimiter,
			int age) {
		StringBuilder results = new StringBuilder();
		// First, get a list of all variables names (i.e., state specific variables)
		// that we have to append to the model invariants
		ArrayList<String> stateSpecificVariableNames = this.getStateSpecificVariableNames();
		
		// Append the state specific variable names to the model invariant variable names
		String header = this.appendColumnHeaders(modelInvariantColumnNames, stateSpecificVariableNames, delimiter);
		
		// Add the header to the results, and include a newLine at the end
		results.append(header + "\n");
		
		// Next for each T1ActionState with this age, append it to the results, and add a newline at the end
		for (T1ActionState as : this.getAllActionStatesFor(age)) {
			results.append(this.actionOrMutationStateToEntry(as, modelInvariantValues, delimiter, stateSpecificVariableNames));
			results.append("\n");
		}
		
		// Do the same for the T1MutationStates
		for (T1MutationState ms : this.getAllMutationStatesFor(age)) {
			results.append(this.actionOrMutationStateToEntry(ms, modelInvariantValues, delimiter, stateSpecificVariableNames));
			results.append("\n");
		}
		
		// Return the results
		return results.toString();
	}
	
	/** Creates a String that represents the results for all ages. The model invariant
	 * variables are used as prefixes for the column names and the entries.*/
	public String toResultsStringForAllAges(String modelInvariantColumnNames, 
			String modelInvariantValues,
			String delimiter) {
		StringBuilder results = new StringBuilder();
		// First, get a list of all variables names (i.e., state specific variables)
		// that we have to append to the model invariants
		ArrayList<String> stateSpecificVariableNames = this.getStateSpecificVariableNames();

		// Append the state specific variable names to the model invariant variable names
		String header = this.appendColumnHeaders(modelInvariantColumnNames, stateSpecificVariableNames, delimiter);

		// Add the header to the results, and include a newLine at the end
		results.append(header + "\n");

		// Next for each T1ActionState with this age, append it to the results, and add a newline at the end
		for (int age = 0; age < model.maximumAge; age++) {
			for (T1ActionState as : this.getAllActionStatesFor(age)) {
				results.append(this.actionOrMutationStateToEntry(as, modelInvariantValues, delimiter, stateSpecificVariableNames));
				results.append("\n");
			}

			// Do the same for the T1MutationStates
			for (T1MutationState ms : this.getAllMutationStatesFor(age)) {
				results.append(this.actionOrMutationStateToEntry(ms, modelInvariantValues, delimiter, stateSpecificVariableNames));
				results.append("\n");
			}
		}
		
		// Return the results
		return results.toString();
	}
	
	/** Returns the T1ActionState with the same name, age, and location as specified in the reference*/
	public T1ActionState toT1ActionState(T1ActionStateReference reference) {
		return this.actionAndMutationMaps[reference.age][reference.patchStateLocation].toActionState(reference);
	}
	/** Returns the T1MutationState with the same name, age, and location as specified in the reference*/
	public T1MutationState toT1MutationState(T1MutationStateReference reference) {
		return this.actionAndMutationMaps[reference.age][reference.patchStateLocation].toMutationState(reference);
	}
	
	/** Returns the T1ActionState with the same name, age, and location as specified in the reference*/
	public T1FitnessState toT1FitnessState(T1FitnessStateReference reference) {
		return this.fitnessMap.toFitnessState(reference);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		T1StateList other = (T1StateList) obj;
		if (!Arrays.deepEquals(actionAndMutationMaps, other.actionAndMutationMaps)) {
			return false;
		}
		if (fitnessMap == null) {
			if (other.fitnessMap != null) {
				return false;
			}
		} else if (!fitnessMap.equals(other.fitnessMap)) {
			return false;
		}
		
		if (maximumAge != other.maximumAge) {
			return false;
		}
		if (maximumLocationPatchState != other.maximumLocationPatchState) {
			return false;
		}
		return true;
	}
}
