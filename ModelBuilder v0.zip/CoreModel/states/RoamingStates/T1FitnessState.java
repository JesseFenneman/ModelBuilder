package states.RoamingStates;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper;

/** Represents the end of an agent's life, either because it reaches its maximum age, 
 * or because it died. FitnessStates are used by multiple T1States and T2States. We do not
 * store in the T1FitnessState which other states can result in that particular fitnessState 
 * (i.e., the T1FitnessState does not have ancestors), as in practice, we do not use
 * backwards induction on the T1FitnessStates. */
public class T1FitnessState extends T1AbstractState {
	
	private static final long serialVersionUID = Helper.programmeVersion;
	
	protected T1FitnessState(T1AbstractStateFactory factory, int stateNumber) {
		super(factory, factory.model.performSafetyChecks);
		if (getModel().performSafetyChecks)
			if (!factory.resultsInDeadState())
				throw new IllegalStateException("Creating an alive T1FitnessState");

		this.setID(stateNumber);
		this.setName("T1F-" + this.getID());
		
		// Set the fields that are usually known after the backwards induction phase. In 
		// contrast to all other States in the game, the T1FitnessState already knows these values
		this.setExpectedFitness(getModel().fitnessFunction.getFitnessFor(this));
		this.setExpectedAge(NumberObject.createNumber(getModel().howToRepresentNumbers, this.age));
		
		NumberObjectSingle[] tempExpectedPhenotype = new NumberObjectSingle[getModel().ledger.numberOfNonAgePhenotypicDimensions];
		for (int p = 0; p < getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++) 
			tempExpectedPhenotype[p] = NumberObject.createNumber(getModel().howToRepresentNumbers, this.phenotype[p]);
		this.setExpectedPhenotype(tempExpectedPhenotype);
		
		NumberObjectSingle[] tempExpectedNumberOfFutureT1Actions = new NumberObjectSingle[getModel().ledger.numberOfT1Actions];
		for (int a = 0; a < getModel().ledger.numberOfT1Actions; a ++) 
			tempExpectedNumberOfFutureT1Actions[a] = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		this.setExpectedNumberOfFutureT1Actions(tempExpectedNumberOfFutureT1Actions);
		
		NumberObjectSingle[] tempExpectedNumberOfFutureT2Actions = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];
		for (int a = 0; a < getModel().ledger.numberOfT2Actions; a ++) 
			tempExpectedNumberOfFutureT2Actions[a] = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		this.setExpectedNumberOfFutureT2Actions(tempExpectedNumberOfFutureT2Actions);
		
		this.setExpectedTotalTimeStepsInDelay(NumberObject.createNumber(getModel().howToRepresentNumbers, 0));
		if (getModel().performSafetyChecks)
			this.checkIfBackwardsFieldsAreValid();
		this.wentThroughBackwardsPass = true;
	}
	
	///////////////////////////////////////////////////////////////////////
	//////////////////////// Tree building functions /////////////////////
	/////////////////////////////////////////////////////////////////////

	@Override
	public void doForwardsPass() {
		throw new IllegalStateException("Asking to compute the successsors of a T1FitnessState");
		
	}

	@Override
	public void doBackwardsPass(boolean printToConsole) {
		throw new IllegalStateException("Asking to compute the fitness of a T1FitnessState");
		
	}

	///////////////////////////////////////////////////////////////
	//////////////////////// Other functions /////////////////////
	/////////////////////////////////////////////////////////////
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		sb.append(this.getName() + ", age=" + age + ", ");
		for (int p = 0; p < getModel().ledger.numberOfNonAgePhenotypicDimensions; p++)
			sb.append(getModel().ledger.phenotypeNames[p]+"="+ phenotype[p] + ", ");
		sb.append(", fitness=NIY");
		return sb.toString();
	}
	
	/** Two T1FitnessStates are equal if they have the same phenotype - the rest doesn't matter after they die*/
	public boolean equals(T1FitnessState other) {
		if (this == other) {
			return true;
		}
		if (other == null) {
			return false;
		}

		if (other.age != this.age)
			return false;

		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p])
				return false;
		return true;

	}
	
	@Override
	public int hashCode() {
		return T1AbstractState.generateHash(this);
	}
	
	/** A T1FitnessStateFactory and T1FitnessStates are equal if they have the same phenotype - the rest doesn't matter after they die*/
	public boolean equals(T1FitnessStateFactory other) {
		if (other == null)	return false;
		
		if (other.age != this.age) return false;
		

		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p]) 
				return false;
		
		return true;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (obj.getClass() == T1FitnessStateFactory.class)
			return equals((T1FitnessStateFactory) obj);
		
		if (getClass() != obj.getClass()) {
			return false;
		}
		T1FitnessState other = (T1FitnessState) obj;
		if (this.getID() != other.getID()) {
			return false;
		}
		
		if (this.getName() == null) {
			if (other.getName() != null) {
				return false;
			}
		} else if (!this.getName().equals(other.getName())) {
			return false;
		}
		return true;
	}

	/** When loading T2DecisionTrees to disk, we need to connect the decision tree back 
	 * to the rest of the model. To make this process easier, each T1AbstractState can be transformed to a
	 * T1StateReference, which can be stored in dependently from this T1AbstractState. The
	 * T1StateList can then use this reference to retrieve this T1AbstractState. */
	public T1FitnessStateReference toT1StateReference() {
		return new T1FitnessStateReference (this.getName(), this.age);
	}
	

}
