package states.RoamingStates;

/** All fields in a State are final. This makes it annoying to
 * create a state s' that is almost identical to a state s. To 
 * make such almost-cloning easier, a StateFactory has the same
 * fields as the corresponding State type, but all fields are 
 * non-final. After changing this Factory, a new State can be 
 * easily constructed using build().*/
public class T1MutationStateFactory extends T1AbstractStateFactory{

	public T1MutationStateFactory(T1AbstractState s) {
		super(s);
	}
	
	/** Clone all fields in the existing T1StateFactory to create a new T1StateFactory. 
	 * Fields can be copied by reference (deepClone == false) or by value (deepClone == true)*/
	public T1MutationStateFactory(T1AbstractStateFactory f, boolean deepClone) {
		super(f, deepClone);
	}

	/** Create a MutationState based on this Factory*/
	protected T1MutationState buildT1MutationState(int stateNumber) {
		return new T1MutationState(this, stateNumber);
	}

	/** Create an shallow clone ActionStateFactory with the same values as this StateFactory*/
	public T1ActionStateFactory toT1ActionStateFactory() {
		return new T1ActionStateFactory(this, false);
	}

	@Override
	public int hashCode() {
		return T1AbstractState.generateHash(this);
	}
	
	/** A T1MutationStateFactory and T1MutationStates are equal if they have the same phenotype, and past experiences with the patch. The
	 * age and current location do not matter - we will states in separate hashmaps for each age and location. */
	public boolean equals(T1MutationStateFactory other) {
		if (other == null)	return false;
		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p]) 
				return false;
		
		for (int s = 0; s < this.lastVisitToPatch.length; s++)
			if (other.lastVisitToPatch[s] != this.lastVisitToPatch[s]) 
				return false;
			else if (other.patchStateOfLastVisit[s] != this.patchStateOfLastVisit[s])
				return false;
		
		return true;
	}
	
	/** A T1MutationStateFactory and T1MutationStates are equal if they have the same phenotype, and past experiences with the patch. The
	 * age and current location do not matter - we will states in separate hashmaps for each age and location. */
	public boolean equals(T1MutationState other) {
		if (other == null)	return false;
		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p]) 
				return false;
		
		for (int s = 0; s < this.lastVisitToPatch.length; s++)
			if (other.lastVisitToPatch[s] != this.lastVisitToPatch[s]) 
				return false;
			else if (other.patchStateOfLastVisit[s] != this.patchStateOfLastVisit[s])
				return false;
		
		return true;
	}
	
	@Override 
	public boolean equals(Object o) {
		if (o == null)
			return false;
		
		if (o.getClass() == T1MutationState.class)
			return (equals((T1MutationState) o));
		if (o.getClass() == T1MutationStateFactory.class)
			return (equals((T1MutationStateFactory) o));
		return false;
	}
	
	public String toString() {
		return super.toString("T1MutationStateFactory");
	}
}
