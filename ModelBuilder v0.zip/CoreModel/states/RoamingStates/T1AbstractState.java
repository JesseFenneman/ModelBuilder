package states.RoamingStates;

import java.io.Serializable;
import java.util.Arrays;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.Model;
import decimalNumber.DecimalNumber;
import helper.Helper;
import stateInterfacesAndAbstractions.State;
import states.EncounterStates.T2AbstractState;
import states.EncounterStates.T2MutationState;

/** A T1State represents an agent's state BETWEEN encounters, and comes in three flavors:
 * - T1ActionStates represent the moment that an agent makes a decision; 
 * - T1MutationStates represent the moment after an action, before all mutations (including aging) take place.
 * - T1FitnessStates represent the state at the agent's final age
 * 
 * A T1State has the following fields, all of which are final:
 * - Age, 
 * - A Location, consisting of 
 * 		- its current patch 
 * 		- its current patch state
 * 		- lastVisitToPatch (how long ago was an agent in a patch)
 * 		- patchStateOfLastVisit (at the last time an agent visited a patch, what was the state of that patch?)
 * - A Phenotype (an integer value for all non-age phenotyic dimensions)
 * - Experiences, consisting of 
 * 		- resource experiences (how often has it seen in patch p, a resource r, that has a value v?)
 * 		- extrinsic experiences (how often has it seen in patch p, an extrinsic event e, that has a value v?)
 * 		- interruption experiences (how often has it seen in patch p, an interruption type, that has a value v? (v is either 0 or 1))
 * 		- delay experiences (how often has it seen in patch p, a delay d, that was of duration v?)
 * 
 * The first thing the model does is to compute all possible T1 (between encounter) states, which are stored in a T1StateList. This
 * T1StateList stores T1States in multiple HashMaps, one for each unique combination of location and age. As such, the HashCode for
 * T1States do not include its location or age. 
 * 
 * Finally, building a T1State is tedious at best (as all fields are final). To construct a T1State, use a T1StateFactory.
 * */
public abstract class T1AbstractState implements AbstractState, Serializable {
	
	private static final long serialVersionUID = Helper.programmeVersion;
	
	// Fields that are set upon creation
	private String name;
	private int ID;
	private transient Model model;
	private final int modelHashCode;
	protected final int age;
	protected final int locationPatchState;
	protected final int locationPatch;
	
	/** One for each [patchIndex]*/	
	protected final int[] lastVisitToPatch; 
	/** One for each [patchIndex]*/	
	protected final int[] patchStateOfLastVisit; 
	/** One for each [phenotypeIndex]*/	
	protected final int[] phenotype;
	
	/* Some boolean to keep track of the state of this state. Sounds complex, but
	 * this just means whether it has already been expanded, has fitness, etc.*/
	// Forwards pass
	protected final boolean isDead;
	protected boolean wentThroughForwardsPass; // Does this state already know its T1 successors?
	protected boolean wentThroughBackwardsPass; // i.e., computed expected outcomes
	
	// Fields created during the backwards pass (effectively, these are the outputs of the model)
	// The fields below are not set upon construction of this, but rather,
	// are set during the backwards pass 
	private NumberObjectSingle expectedFitness;
	private NumberObjectSingle expectedAge;
	private NumberObjectSingle[] expectedPhenotype;
	private NumberObjectSingle[] expectedNumberOfFutureT1Actions;
	private NumberObjectSingle[] expectedNumberOfFutureT2Actions;
	
	
	/** Specifically added for the postponing models:
	 * How long does an agent expects to delay, from this state
	 * until the end of its life, given that there are interruptions,
	 * and given that the agent follows the optimal policy? */
	private NumberObjectSingle expectedTotalTimestepsInDelay;
	
	// For future versions: an agent can learn from experiences
	// However, enabling this results very much in a NP hard problem
	// As such, only simulation based algorithms work, or the memory
	// of an agent has to be limited (e.g., it can only store x experiences
	// in memory). As time is limited, this functionality will be enabled in future 
	// versions of the ModelBuilder software.
	protected final int[][][] resourceExperiences; 		// [resource]    [patch state][value] -> count
	protected final int[][][] extrinsicExperiences; 	// [extrinsic]   [patch state][extrinsic][value] -> count
	protected final int[][][] interruptionExperiences;  // [interruption][patch state][value] -> count
	protected final int[][][] delayExperiences; 		// [delay]       [patch state][value] -> count
	

	
	/** Build a T1AbstractState based on the factory. Note, this building uses a shallow clone of all factory fields*/
 	public T1AbstractState(T1AbstractStateFactory factory, boolean checkValidity) {
 		this.model = factory.model;
 		this.modelHashCode = model.hashCode();
 		if (model.performSafetyChecks) {
			if (!factory.isComplete())
				throw new IllegalArgumentException("Trying to build model from incomplete factory.");
			if (model.ledger.patchStateIndexToPatchIndex[factory.locationPatchState] != factory.locationPatch)
				throw new IllegalStateException("Creating state in patch state location "+ factory.locationPatchState + " in patch " + factory.locationPatch + ". However, that patch state is not in that patch!");
 		}
 		this.phenotype = factory.phenotype;
 		this.isDead = factory.resultsInDeadState();
		
		this.age = factory.age;
		if (factory instanceof T1FitnessStateFactory) {
			// Dead states don't have a place
			this.locationPatchState = -1;
			this.locationPatch = -1;
			this.lastVisitToPatch = new int[model.ledger.numberOfPatches];
			this.patchStateOfLastVisit = new int[model.ledger.numberOfPatches];
			for (int i = 0; i < model.ledger.numberOfPatches; i++) {
				lastVisitToPatch[i] = -1;
				patchStateOfLastVisit[i] = -1;
			}
			
		} else {
			this.locationPatchState = factory.locationPatchState;
			this.locationPatch = factory.locationPatch;
			this.lastVisitToPatch = factory.lastVisitToPatch;
			this.patchStateOfLastVisit = factory.patchStateOfLastVisit;
		}
		
		this.resourceExperiences = factory.resourceExperiences;
		this.extrinsicExperiences = factory.extrinsicExperiences;
		this.delayExperiences = factory.delayExperiences;
		this.interruptionExperiences = factory.interruptionExperiences;
	
		if (checkValidity)
			this.checkValidity();
		
		this.wentThroughForwardsPass = false;
		this.wentThroughBackwardsPass = false; 
		
	
	}
	
	/** Check whether all fields are valid, and throw an IllegalStateException if a field has a clearly impossible state (e.g., negative age)*/
 	public void checkValidity() {
 		if (this.age < 0)
 			throw new IllegalStateException("Created a T1AbstractState with a negative age. Age = " + age);
 		if (this.age > model.maximumAge)
 			throw new IllegalStateException("Created a T1AbstractState with an age higher than the maximum age. Age = " +age + ". Maximum = " + model.maximumAge );

 		if (phenotype.length != model.ledger.numberOfNonAgePhenotypicDimensions)
 			throw new IllegalStateException("Created a T1AbstractState that has a phenotype with an incorrect number of dimensions. Phenotype = " + Helper.arrayToString(phenotype) + ", expected number of dimensions = " + phenotype.length);

 		for (int p = 0; p < phenotype.length; p++)
 			if (phenotype[p] < 0)
 				throw new IllegalStateException("Created a T1AbstractState with a negative phenotype index at phenotypic dimension. Dimension number = " + p + ". Index = " + phenotype[p]);
 			else if (phenotype[p] >= model.ledger.phenotypeValues[p].length)
 				throw new IllegalStateException("Created a T1AbstractState with an impossibly high phenotype index at phenotypic dimension. Dimension number = " + p + ". Index = " + phenotype[p] + ". Max = " + model.ledger.phenotypeValues[p].length);

 		if (this.getClass() == T1FitnessState.class)
 			return;

 		if (this.locationPatch < 0)
 			throw new IllegalStateException("Created a T1AbstractState with a negative patch location. Patch = " + locationPatch);
 		if (this.locationPatch >= model.ledger.patches.length)
 			throw new IllegalStateException("Created a T1AbstractState with an impossible patch state locatoin. Patch = " + locationPatch+ ". Maximum = " + model.ledger.patches.length);

 		if (this.locationPatchState < 0)
 			throw new IllegalStateException("Created a T1AbstractState with a negative patch state location. State = " + locationPatchState);
 		if (this.locationPatchState >= model.ledger.patchStates.length)
 			throw new IllegalStateException("Created a T1AbstractState with an impossible patch state location. State = " + locationPatchState+ ". Maximum = " + model.ledger.patchStates.length);

 		if (model.ledger.patchStates[this.locationPatchState].ledgerIndexOfPatch != this.locationPatch)
 			throw new IllegalStateException("Created a T1Abstract state where the patch state location and patch location cannot possibility be both correct. Patch: "  + this.locationPatch + ", state: " + this.locationPatchState );

 		if (lastVisitToPatch.length != model.ledger.patches.length)
 			throw new IllegalStateException("Created a T1Abstract state where the size of the last visits to patch array has an unexpected length. Length array = " + lastVisitToPatch.length + ", number of patches in model: " + model.ledger.patches.length);

 		if (patchStateOfLastVisit.length != model.ledger.patches.length)
 			throw new IllegalStateException("Created a T1Abstract state where the size of the patch state in last visit array has an unexpected length. Length array = " + patchStateOfLastVisit.length + ", number of patches in model: " + model.ledger.patches.length);


 		for (int p = 0; p < model.ledger.patches.length; p++)
 			if (this.lastVisitToPatch[p] < 0)
 				throw new IllegalStateException("Created a T1AbstractState that visited a previous patch a negative number of time steps ago. Time since last visit = " + lastVisitToPatch[p]);
 			else if (this.lastVisitToPatch[p] > age)
 				throw new IllegalStateException("Created a T1AbstractState that visited a patch longer than it has been alive. Last visit = " + lastVisitToPatch[p] + ". age = " + age);
 			else if (patchStateOfLastVisit[p] < 0)
 				throw new IllegalStateException("Created a T1AbstractState that has last seen a patch be in a negative location. Patch = " + p + ", state = " + patchStateOfLastVisit[p]);
 			else if (patchStateOfLastVisit[p] >= model.ledger.patchStates.length)
 				throw new IllegalStateException("Created a T1AbstractState that has last seen a patch be in an unknown state. Patch = " + p + ", state = " + patchStateOfLastVisit[p]);
 			else if (model.ledger.patchStates[patchStateOfLastVisit[p]].ledgerIndexOfPatch != p)
 				throw new IllegalStateException("Created a T1AbstractState that has last seen a patch be in a state that is not associated with that patch. Patch = " + p + ", state = " + patchStateOfLastVisit[p]);


 	}

 	public Model getModel() { return this.model; }
 	
 	/** Set the model after loading a T2AbstractState from disk. Throws an IllegalStateException
 	 * if this T1AbstractState is not an instance of T2AbstractState. Throws an IllegalArgumentException
 	 * if the hash code of the previous model and the argument model do not match. */
 	public void setModel(Model model) {
 		if (!(this instanceof T2AbstractState))
 			throw new IllegalStateException("Trying to set a model for a non-T2AbstractState.");
 		if (model.hashCode() != this.modelHashCode)
 			throw new IllegalArgumentException("New model hash does not match previous model hash.");
 		
 		this.model = model;
 	}
 	/////////////////////////////////////////////////////////////////////////////////////
 	//////////////////////// State getters (known at construction) /////////////////////
 	///////////////////////////////////////////////////////////////////////////////////

 	/** Returns the age of the agent in this state.*/
 	public int getAge() {
 		return age;
 	}

	/** Get a shallow copy of the phenotype. Watch out: changes in this array affect the state*/
	public int[] getPhenotypeArray() {return this.phenotype;}
	
	/** Returns the integer stored at the i'th phenotype. What the i'th phenotype is,
	 * or what value the resulting integer represents can be found by using the Ledger's
	 * getNameOfPhenotypeIndex(int index). */
	public int getPhenotypeValue(int phenotypeIndex) {
		return phenotype[phenotypeIndex];
	}

	/** Returns the integer representing the current location (patch state). What PatchState 
	 * this integer refers to can be found in the Ledger (by using getNameOfPatchState())*/
	public int getLocationPatchState() {
		return locationPatchState;
	}

	/** Returns the integer representing the current location (patch). What Patch 
	 * this integer refers to can be found in the Ledger (by using getNameOfPatch())*/
	public int getLocationPatch() {
		return locationPatch;
	}

	/** Returns the number of time steps that have passed since an agent in this State visited 
	 * the patch index. Which patch this index refers to is specified in the Ledger. */
	public int timeStepsSinceLastVisit(int patchIndex) {
		return this.lastVisitToPatch[patchIndex];
	}

	/** Returns the index of the state the patch was in when an agent in this State visited
	 * the specified patch Returns -1 if the agent never visited the state yet.*/
	public int patchStateDuringLastVisit(int patchIndex) {
		return this.patchStateOfLastVisit[patchIndex];
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////// Outcome setters (used during backwards pass) /////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////
	/** Set the expected fitness by cloning the input. Also makes the expected fitness NumberObjectSingle immutable.
	 * Throws an IllegalStateException if there already is an expected fitness. */
	public void setExpectedFitness(NumberObjectSingle newExpectedFitness) {
		if (this.expectedFitness != null)
			throw new IllegalStateException("Setting a non-null expected fitness.");
		
		this.expectedFitness = newExpectedFitness.clone();
		this.expectedFitness.makeImmutable();
	}
	
	/** Set the expected age by cloning the input. Also makes the expected age NumberObjectSingle immutable.
	 * Throws an IllegalStateException if there already is an expected age. */
	public void setExpectedAge(NumberObjectSingle newExpectedAge) {
		if (this.expectedAge != null)
			throw new IllegalStateException("Setting a non-null expected age.");
		
		this.expectedAge = newExpectedAge.clone();
		this.expectedAge.makeImmutable();
	}

	/** Set the expected number of time steps an agent will spend
	 * postponing and/or waiting, from this moment until the end of its life,
	 *  by cloning the input. Also makes the NumberObjectSingle immutable.
	 * Throws an IllegalStateException if there already is an expected time steps. */
	public void setExpectedTotalTimeStepsInDelay(NumberObjectSingle newExpectedTimeSteps) {
		if (this.expectedTotalTimestepsInDelay != null)
			throw new IllegalStateException("Setting a non-null expected time steps spend delaying.");
		
		this.expectedTotalTimestepsInDelay = newExpectedTimeSteps.clone();
		this.expectedTotalTimestepsInDelay.makeImmutable();
	}
	/** Set the expected phenotype by cloning the input. The input must have exactly one value
	 * for all non-age phenotypic dimensions. Also makes all expected phenotype NumberObjectSingle objects immutable.
	 * Throws an IllegalStateException if there already is an expected phenotype. */
	public void setExpectedPhenotype(NumberObjectSingle[] newExpectedPhenotype) {
		if (this.expectedPhenotype != null)
			throw new IllegalStateException("Setting a non-null expected phenotype");
		
		this.expectedPhenotype = newExpectedPhenotype;
		for (int p = 0; p < expectedPhenotype.length; p++)
			expectedPhenotype[p].makeImmutable();
	}
	
	/** Set the expected number of future T1 Actions by cloning the input.
	 * The length of the input must match the number of T1 actions in the Ledger. This
	 * function also makes all expected action NumberObjectSingle objects immutable.
	 * Throws an IllegalStateException if there already is an expected number of future actions for that index. 
	 * Has to be set after the expected age has been set. */
	public void setExpectedNumberOfFutureT1Actions(NumberObjectSingle[] newExpectedTimes) {
		if (this.expectedNumberOfFutureT1Actions != null)
			throw new IllegalStateException("Setting a non-null expected number of future T1 actions ");
		
		this.expectedNumberOfFutureT1Actions = newExpectedTimes;
		for (int a = 0; a < expectedNumberOfFutureT1Actions.length; a++)
			expectedNumberOfFutureT1Actions[a].makeImmutable();
	}
	
	/** Set the expected number of future T2 Actions by cloning the input.
	 * The length of the input must match the number of T2 actions in the Ledger. This
	 * function also makes all expected action NumberObjectSingle objects immutable.
	 * Throws an IllegalStateException if there already is an expected number of future actions for that index. 
	 * Has to be set after the expected age has been set. */
	public void setExpectedNumberOfFutureT2Actions(NumberObjectSingle[] newExpectedTimes) {
		if (this.expectedNumberOfFutureT2Actions != null)
			throw new IllegalStateException("Setting a non-null expected number of future T2 actions");
		
		this.expectedNumberOfFutureT2Actions = newExpectedTimes;
		for (int a = 0; a < expectedNumberOfFutureT2Actions.length; a++)
			expectedNumberOfFutureT2Actions[a].makeImmutable();
	}

	/** Check if the expectedAge, expectedPhenotype, expectedNumberOfFutureT1Actions, and expctedNumberOfFutureT2Actions are
	 * all valid after the backwards pass.*/
	protected void checkIfBackwardsFieldsAreValid() {

		// Check expectedAge:
		if (expectedAge.largerThan(model.maximumAge, true))
			throw new IllegalArgumentException("Setting expected age above maximum age: " + expectedAge.toStringWithoutTrailingZeros());
		else if (expectedAge.smallerThan(0, true))
			throw new IllegalArgumentException("Setting expected age below 0: " + expectedAge.toStringWithoutTrailingZeros());
		else if (expectedAge.smallerThan(this.age, true))
			throw new IllegalArgumentException("Life expectancy is lower than current age: Expected age: " + expectedAge.toStringWithoutTrailingZeros() + ". Current age: " + this.age + ".");

		// Check expectedTime; should not be larger than expectedAge
		if (this.expectedTotalTimestepsInDelay.largerThan(expectedAge, true))
			throw new IllegalArgumentException("Setting expected time step in delay ("+
					expectedTotalTimestepsInDelay.toStringWithoutTrailingZeros() +
					") that is larger than the expected age (" + 
					expectedAge.toStringWithoutTrailingZeros() + ")");
		
		// Check if the expectedPhenotype has exactly one entry for all phenotypic dimensions
		if (expectedPhenotype.length != model.ledger.numberOfNonAgePhenotypicDimensions)
			throw new IllegalArgumentException("Setting expected phenotype for T1AbstractState. However, the number of non-age phenotypic dimensions of the argument ("
					+ expectedPhenotype.length + ") does not match the expected number (" + model.ledger.numberOfNonAgePhenotypicDimensions+ ").");

		// Check if all the values in the newExpectedPhenotype are permissible
		for (int p =0; p < expectedPhenotype.length; p++)
			if (expectedPhenotype[p].largerThan(model.ledger.phenotypeValues[p].length, true))
				throw new IllegalArgumentException("Setting expected phenotype above maximum phenotype index. Expected: " + expectedPhenotype[p].toStringWithoutTrailingZeros());
			else if (expectedPhenotype[p].smallerThan(0, true))
				throw new IllegalArgumentException("Setting expected phenotype index below 0. Expected: " + expectedPhenotype[p].toStringWithoutTrailingZeros());

		// Check if the expectedNumberOfFutureT1Actions has exactly one entry for each possible action
		if (expectedNumberOfFutureT1Actions.length != model.ledger.numberOfT1Actions)
			throw new IllegalArgumentException("Setting expected number of future T1 Actions. However, the number of action in the input ("
					+ expectedNumberOfFutureT1Actions.length + ") does not match the number of T1 actions in the ledger (" + model.ledger.numberOfT1Actions+ ").");

		// Check if the expectedNumberOfFutureT2Actions has exactly one entry for each possible action
		if (expectedNumberOfFutureT2Actions.length != model.ledger.numberOfT2Actions)
			throw new IllegalArgumentException("Setting expected number of future T2 Actions. However, the number of action in the input ("
					+ expectedNumberOfFutureT2Actions.length + ") does not match the number of T2 actions in the ledger (" + model.ledger.numberOfT1Actions+ ").");
	
		// Check if all the values in the expectedNumberOfFutureT1Actions and expectedNumberOfFutureT2Actions are permissible
		DecimalNumber sumT1Actions = new DecimalNumber(0);
		for (int a = 0; a < expectedNumberOfFutureT1Actions.length; a++)
			if (expectedNumberOfFutureT1Actions[a].largerThan(model.maximumAge, true))
				throw new IllegalArgumentException("Setting expected number of future T1 actions above maximum age. Expected: " + expectedNumberOfFutureT1Actions[a].toStringWithoutTrailingZeros());
			else if (expectedNumberOfFutureT1Actions[a].smallerThan(0, true))
				throw new IllegalArgumentException("Setting expected number of future T1 actions below 0. Expected: " + expectedNumberOfFutureT1Actions[a].toStringWithoutTrailingZeros());
			else
				sumT1Actions.add(expectedNumberOfFutureT1Actions[a], true);

		
		// Check if all the values in the expectedNumberOfFutureT2Actions are permissible
		DecimalNumber sumT2Actions = new DecimalNumber(0);
		for (int a = 0; a < expectedNumberOfFutureT2Actions.length; a++)
			if (expectedNumberOfFutureT2Actions[a].largerThan(model.maximumAge, true))
				throw new IllegalArgumentException("Setting expected number of future T2 actions above maximum age. Expected: " + expectedNumberOfFutureT2Actions[a].toStringWithoutTrailingZeros());
			else if (expectedNumberOfFutureT2Actions[a].smallerThan(0, true))
				throw new IllegalArgumentException("Setting expected number of future T2 actions below 0. Expected: " + expectedNumberOfFutureT2Actions[a].toStringWithoutTrailingZeros());
			else
				sumT2Actions.add(expectedNumberOfFutureT2Actions[a], true);

		
		DecimalNumber totalExpectedFutureActions = sumT1Actions.add(sumT2Actions);

		// Finally, check if the expectedAge matches the number of future actions an agent will take.
		// If the agent is in a T1FitnessState, there should never be a future action (after all, it is dead).
		// If the agent is in a MutationState or a ActionState, and the agent expects to live more than 1 moment 
		// of time
// TODO; figure this one out
	/*	if (this instanceof T1FitnessState) {
			if (!totalExpectedFutureActions.equals(0))
				throw new IllegalStateException("A T1Fitness state believes it will do something in the future. But we all know that zombies don't exist...");
		} else if (!totalExpectedFutureActions.equals(this.expectedAge.subtract(this.age+1, false), true)) // The -1 is because the last state is always a fitness state
			throw new IllegalStateException("In the future an agent expects to take " + sumT1Actions.toStringWithoutTrailingZeros() + " T1 actions. However, it only expects to live for another " +
					this.expectedAge.subtract(this.age+1, false).toStringWithoutTrailingZeros() + " number of time steps (current age = "
					+ this.age + ", expected age = " + this.expectedAge.toStringWithoutTrailingZeros() + ", and there is one final FitnessState)");

*/

	}

	////////////////////////////////////////////////////////////////////////////////////////////
 	//////////////////////// Outcome getters (known after backwards pass) /////////////////////
 	//////////////////////////////////////////////////////////////////////////////////////////

	/** Returns a reference to the expected fitness of being in this state. Throws an IllegalStateException
	 * if this function is called before the state has gone through a backwards pass. */
	public NumberObjectSingle getExpectedFitness() {
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for expected fitness for a state that has not gone through the backwards pass yet. This name = " + name);
		return this.expectedFitness;
	}
	
	/** Returns a reference to of the expected age an agent will die at, given it is in this state. 
	 * Throws an IllegalStateException if this function is called before the state has gone 
	 * through a backwards pass. */
	public NumberObjectSingle getExpectedTotalTimeStepsInDelay() {
		//if (this instanceof T2MutationState)
			//System.err.println(this.getClass().getSimpleName()  + ". TOTAL: " + expectedTotalTimestepsInDelay);
		if (this.expectedTotalTimestepsInDelay == null)
			throw new IllegalStateException("Asking for expected time steps delaying for a state that has not gone through the backwards pass yet. Name = " + name );
		return this.expectedTotalTimestepsInDelay;
	}
	
	/** Returns a reference to of the expected age an agent will die at, given it is in this state. 
	 * Throws an IllegalStateException if this function is called before the state has gone 
	 * through a backwards pass. */
	public NumberObjectSingle getExpectedAge() {
		if (this.expectedAge == null)
			throw new IllegalStateException("Asking for expected age for a state that has not gone through the backwards pass yet. Name = " + name );
		return this.expectedAge;
	}
	
	/** Returns a reference to of expected phenotype index position of the phenotypeIndex's dimensions at 
	 * the end of life, given that the agent is currently in this state.  
	 * Throws an IllegalStateException if this function is called before the state has gone 
	 * through a backwards pass. */
	public NumberObjectSingle getExpectedPhenotype(int phenotypeIndex) {
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for expected phenotype for a state that has not gone through the backwards pass yet. Name = " + name);
		return this.expectedPhenotype[phenotypeIndex];
	}
	
	/** Returns a reference to of expected number of times an agent will still perform the specified
	 * T1 action until it dies.  
	 * Throws an IllegalStateException if this function is called before the state has gone 
	 * through a backwards pass. */
	public NumberObjectSingle getFutureTimesItPerformsT1Action(int t1ActionIndex) {
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the expected number of T1 actions for a state that has not gone through the backwards pass yet. State name = " + name);
		return this.expectedNumberOfFutureT1Actions[t1ActionIndex];
	}
	
	/** Returns a reference to of expected number of times an agent will still perform the specified
	 * T2 action until it dies.  
	 * Throws an IllegalStateException if this function is called before the state has gone 
	 * through a backwards pass. */
	public NumberObjectSingle getFutureTimesItPerformsT2Action(int t2ActionIndex) {
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the expected number of T2 actions for a state that has not gone through the backwards pass yet. State name = " + name);
		return this.expectedNumberOfFutureT2Actions[t2ActionIndex];
	}
	
	///////////////////////////////////////////////////////////////////////
	//////////////////////// Tree building functions /////////////////////
	/////////////////////////////////////////////////////////////////////
	/** Returns true if at least one DeathCondition is met*/
	public boolean isDead() {
		return isDead;
	}

	/** Returns true if this node has gone through a forward pass. That is, 
	 * whether the computeSuccessorStates function has been called at least once.*/
	public boolean wentThroughForwardsPass () {return wentThroughForwardsPass;}
	
	/** Returns true if this node has gone through a backward pass. That is, 
	 * whether the computeBestActionsAndFitness function has been called at least once.
	 * */
	public boolean wentThroughBackwardsPass () {return wentThroughBackwardsPass;}
	
	/** Go through the forwards pass. That is, compute all possible successor states.*/
	public abstract void doForwardsPass();
	
	/** Go through the backwards pass. That is, compute the expected fitness in of going into this state.
	 * If printToConsole is true, some debug script is printed to the console letting 
	 * the user know what's going on.*/
	public abstract void doBackwardsPass(boolean printToConsole);
	
	
	///////////////////////////////////////////////////////////////
	//////////////////////// Other functions /////////////////////
	/////////////////////////////////////////////////////////////
	/** Returns true if the fields in this state match the fields in the other state*/
	public boolean equals(T1AbstractState other) {
		if (this == other)
			return true;
		if (other == null)
			return false;
		if (other.getClass() != this.getClass())
			return false;
	
		if (other.age != age)
			return false;
		if (other.locationPatchState != locationPatchState)
			return false;
		
		if (!Arrays.equals(lastVisitToPatch, other.lastVisitToPatch)) {
			return false;
		}
		if (!Arrays.equals(patchStateOfLastVisit, other.patchStateOfLastVisit)) {
			return false;
		}
		if (!Arrays.equals(phenotype, other.phenotype)) {
			return false;
		}
		if (!Arrays.deepEquals(resourceExperiences, other.resourceExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(delayExperiences, other.delayExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(extrinsicExperiences, other.extrinsicExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(interruptionExperiences, other.interruptionExperiences)) {
			return false;
		}
	
		return true;
	}

	/** Create a hash for the specified T1ActionState or T1MutationState. It is specified in this function so that in the future it is easy
	 * to change the hashes for states and state factories in similar ways*/
	public static int generateHash( T1AbstractState o) {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(o.delayExperiences);
		result = prime * result + Arrays.deepHashCode(o.extrinsicExperiences);
		result = prime * result + Arrays.deepHashCode(o.interruptionExperiences);
		result = prime * result + Arrays.hashCode(o.lastVisitToPatch);
		result = prime * result + Arrays.hashCode(o.patchStateOfLastVisit);
		result = prime * result + Arrays.hashCode(o.phenotype);
		result = prime * result + Arrays.deepHashCode(o.resourceExperiences);
		return result;
	}
	
	/** Create a hash for the specified T1FitnessState. It is specified in this function so that in the future it is easy
	 * to change the hashes for states and state factories in similar ways*/
	public static int generateHash( T1FitnessState o) {
		final int prime = 31;
		int result = 1;
		result = prime * o.age;
		result = prime * result + Arrays.hashCode(o.phenotype);
		return result;
	}
	
	/** Create a hash for the specified T1ActionStateFactory or T1MutationStateFactory. It is specified in this function so that in the future it is easy
	 * to change the hashes for states and state factories in similar ways*/
	public static int generateHash( T1AbstractStateFactory o) {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(o.delayExperiences);
		result = prime * result + Arrays.deepHashCode(o.extrinsicExperiences);
		result = prime * result + Arrays.deepHashCode(o.interruptionExperiences);
		result = prime * result + Arrays.hashCode(o.lastVisitToPatch);
		result = prime * result + Arrays.hashCode(o.patchStateOfLastVisit);
		result = prime * result + Arrays.hashCode(o.phenotype);
		result = prime * result + Arrays.deepHashCode(o.resourceExperiences);
		return result;
	}
	
	/** Create a hash for the specified T1FitnessStateFactory. It is specified in this function so that in the future it is easy
	 * to change the hashes for states and state factories in similar ways*/
	public static int generateHash( T1FitnessStateFactory o) {
		final int prime = 31;
		int result = 1;
		result = prime * o.age;
		result = prime * result + Arrays.hashCode(o.phenotype);
		return result;
	}
	
	public int hashCode() {
		return T1AbstractState.generateHash(this);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		return this.equals((T1AbstractState) obj);
	}

	/** Returns true if the factory's output (i.e., the state resulting from
	 * the build() function) will match the current state*/
	public boolean equals (T1AbstractStateFactory factory) {
		if (factory == null)
			return false;
		
		if (factory.age != age)
			return false;
		if (factory.locationPatchState != locationPatchState)
			return false;
		
		if (!Arrays.equals(lastVisitToPatch, factory.lastVisitToPatch)) {
			return false;
		}
		if (!Arrays.equals(patchStateOfLastVisit, factory.patchStateOfLastVisit)) {
			return false;
		}
		if (!Arrays.equals(phenotype, factory.phenotype)) {
			return false;
		}
		if (!Arrays.deepEquals(resourceExperiences, factory.resourceExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(delayExperiences, factory.delayExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(extrinsicExperiences, factory.extrinsicExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(interruptionExperiences, factory.interruptionExperiences)) {
			return false;
		}
		return true;
		
	}
	
	
	protected void setName(String name) { this.name = name; }
	public String getName() { return this.name;}
	
	protected void setID(int ID) { this.ID = ID;}
	public int getID() { return this.ID;}
	

	public String toString() {
		StringBuilder sb = new StringBuilder("State: " + getName());		
		sb.append("\n\tAge:\t" +age);
		sb.append("\n\tLocation:\t" +locationPatch+"/" + locationPatchState);

		sb.append("\n\tLast visit to patch:");
		for (int i = 0; i < this.lastVisitToPatch.length; i++)
			sb.append("\n\t[" + i + "]: " + lastVisitToPatch[i]);

		sb.append("\n\tState of patch in last visit:");
		for (int i = 0; i < this.patchStateOfLastVisit.length; i++)
			sb.append("\n\t[" + i + "]: " + patchStateOfLastVisit[i]);

		sb.append("\n\tPhenotype:");
		for (int i = 0; i < this.phenotype.length; i++)
			sb.append("\n\t[" + i + "]: " + phenotype[i]);

		/* FOR FUTURE UPDATES OF THE MODELBUILDER SOFTWARE:
		 * AN AGENT SHOULD BE ABLE TO LEARN FROM EXPERIENCE.
		sb.append("\n\tPreviously encountered resources:");
		for (int i = 0; i < this.resourceExperiences.length; i++) {
			sb.append("\n\tPatchState [" + i + "]: ");
			for (int r = 0; r < this.resourceExperiences[i].length; r++) {
				sb.append("\n\t\tResource [" + i + "]: ");
				for (int v = 0; v < this.resourceExperiences[i][r].length; v++)
					sb.append("\n\t\t[" + v+ "]: " + this.resourceExperiences[i][r][v]);
			}	
		}

		sb.append("\n\tPreviously encountered extrinsic events:");
		for (int i = 0; i < this.extrinsicExperiences.length; i++) {
			sb.append("\n\tPatchState [" + i + "]: ");
			for (int r = 0; r < this.extrinsicExperiences[i].length; r++) {
				sb.append("\n\t\tExtrinsic event[" + i + "]: ");
				for (int v = 0; v < this.extrinsicExperiences[i][r].length; v++)
					sb.append("\n\t\t[" + v+ "]: " + this.extrinsicExperiences[i][r][v]);
			}	
		}

		sb.append("\n\tPreviously encountered interruptions:");
		for (int i = 0; i < this.interruptionExperiences.length; i++) {
			sb.append("\n\tPatchState [" + i + "]: ");
			for (int r = 0; r < this.interruptionExperiences[i].length; r++) {
				sb.append("\n\t\tInterruption [" + i + "]: ");
				for (int v = 0; v < this.interruptionExperiences[i][r].length; v++)
					sb.append("\n\t\t[" + v+ "]: " + this.interruptionExperiences[i][r][v]);
			}	
		}

		sb.append("\n\tPreviously encountered delays:");
		for (int i = 0; i < this.delayExperiences.length; i++) {
			sb.append("\n\tPatchState [" + i + "]: ");
			for (int r = 0; r < this.delayExperiences[i].length; r++) {
				sb.append("\n\t\tDelay [" + i + "]: ");
				for (int v = 0; v < this.delayExperiences[i][r].length; v++)
					sb.append("\n\t\t[" + v+ "]: " + this.delayExperiences[i][r][v]);
			}	
		}
		 */
		return sb.toString();
	}


}
