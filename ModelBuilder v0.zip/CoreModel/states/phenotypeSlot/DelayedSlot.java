package states.phenotypeSlot;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.AbstractModel;
import core.LedgerFactory;
import helper.Helper;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeSlotTemplateDelayedResource;
import view.View;

/** A delayed slot stores a resource type and resource value
 * (in the form of ledger indices), together with a delay type
 * and delayed value (also in the form in ledger indices),
 * and an optional interruption (either -1 for empty or
 * a ledger index) that will automatically be consumed after
 * the time steps run out. Note: the model should check at 
 * the start of each action phase whether a delayed resource will 
 * be consumed.
 * by an agent. */
public class DelayedSlot extends PhenotypeSlot {
	private static final long serialVersionUID = Helper.programmeVersion;

	/** The type of delays that can be used in this slot. If the
	 * delay type is changed, and the user has requested that the validity
	 * should be checked during runtime, there will be a check whether the index
	 * of the newly stored delay (from the Ledger) is in the array of permissible
	 * delays. If not, an IncompatibleDelayException will be thrown. If there are
	 * validity checks, this array is null.*/
	private final int[] permissibleDelays;

	/** The type of the delay currently stored in the slot. */
	private int currentDelayType;

	/** The initial duration of the delay*/
	private int originalDelayDuration;

	/** The value (i.e., duration) of the delay currently stored in the slot*/
	private int currentDelayValue;

	/** The type of interruptions that can be used in this slot. If the
	 * interruption type is changed, and the user has requested that the validity
	 * should be checked during runtime, there will be a check whether the index
	 * of the newly stored interruption (from the Ledger) is in the array of permissible
	 * interruption. If not, an IncompatibleInterruptionException will be thrown. 
	 * If there are no validity checks, this array is null. */
	private final int[] permissibleInterruptions;

	/** The type of the interruption currently stored in the slot. Can be -1 (if no interruption is used)*/
	private int currentInterruptionType;

	/** The value of the interruption currently stored in the slot. Can be -1 (if no interruption is stored).
	 * Importantly, this is always an probability, stored in the current PatchState*/
	private NumberObjectSingle currentInterruptionProbability;

	/** At what time step was the resource stored in this slot - used to 
	 * determine whether the delay has passed. */
	private int timeStepLastStored;

	public DelayedSlot(AbstractModel model, AbstractPhenotypeSlotTemplate slotTemplate, LedgerFactory ledgerFactory) {
		super(model, slotTemplate, ledgerFactory);

		if (!(slotTemplate instanceof PhenotypeSlotTemplateDelayedResource ))
			throw new IllegalArgumentException("Cannot use a slot template of type " + slotTemplate.getClass().getSimpleName() + " to create a delayed slot." );

		if (!checkValidity) {
			permissibleDelays = null;
			permissibleInterruptions = null;
		} else {
			PhenotypeSlotTemplateDelayedResource delayedTemplate = (PhenotypeSlotTemplateDelayedResource) slotTemplate;

			// Figure out the indices of all permissible delays
			ArrayList<Integer> permissibleDelaysArrayList = new ArrayList<>();
			for (int d = 0; d < ledgerFactory.delayNames.size(); d++) {
				String delayName = ledgerFactory.delayNames.get(d);
				DelayObjectTemplate delayTemplate = (DelayObjectTemplate) View.getView().workspace.getObject(delayName);
				if (delayedTemplate.canUseDelay(delayTemplate))
					permissibleDelaysArrayList.add(d);
			}
			this.permissibleDelays = new int[permissibleDelaysArrayList.size()];
			for (int i = 0; i < permissibleDelays.length; i++)
				permissibleDelays[i] = permissibleDelaysArrayList.get(i);

			// Figure out the indices of all permissible interruptions
			ArrayList<Integer> permissibleInterruptionsArrayList = new ArrayList<>();
			for (int i = 0; i < ledgerFactory.interruptionNames.size(); i++) {
				String interruptionName = ledgerFactory.interruptionNames.get(i);
				InterruptionObjectTemplate interruptionTemplate = (InterruptionObjectTemplate) View.getView().workspace.getObject(interruptionName);
				if (delayedTemplate.canUseInterruption(interruptionTemplate))
					permissibleInterruptionsArrayList.add(i);
			}
			this.permissibleInterruptions = new int[permissibleInterruptionsArrayList.size()];
			for (int i = 0; i < permissibleInterruptions.length; i++)
				permissibleInterruptions[i] = permissibleInterruptionsArrayList.get(i);
		}
	}

	/** Copy constructor*/
	private DelayedSlot(DelayedSlot original) {
		super(original);
		this.permissibleInterruptions = original.permissibleInterruptions;
		this.permissibleDelays=original.permissibleDelays;
		this.currentDelayType=original.currentDelayType;
		this.currentDelayValue=original.currentDelayValue;
		this.currentInterruptionType=original.currentInterruptionType;
		this.currentInterruptionProbability=original.currentInterruptionProbability.clone();
	}
	
	@Override
	protected SlotType getSlotType() {
		return SlotType.DELAYED;
	}


	/** Set the delay used in this slot. Throws an IncompatibleDelayException if the
	 * delay is not permissible and checkValidity is true.*/
	private void setDelay(int delayType, int delayValue) {
		// If we have to check validity: check if the new phenotypic dimension is listed in the permissibleDelays array
		if (checkValidity) {
			boolean isPermissible = false;
			for (int d : this.permissibleDelays)
				if (permissibleDelays[d] == delayType) {
					isPermissible = true;
					break;
				}
			if (!isPermissible)
				throw new IncompatibleDelayException("Cannot use delay of type " + delayType + " in slot. Permissible delays : " + Helper.arrayToString(this.permissibleDelays));
		}

		this.currentDelayType=delayType;
		this.currentDelayValue=delayValue;
		this.originalDelayDuration=model.ledger.delayValues[delayType][delayValue];
	}

	/** Set the interruption used in this slot. Throws an IncompatibleInterruptionException if the
	 * interruption is not permissible and checkValidity is true. Interruption type can be set to
	 * null to denote that there is no interruption. Note that the interruptionProbability is the
	 * frequency of an interruption class, which depends on the PatchState*/
	private void setInterruption(int interruptionType, NumberObjectSingle interruptionProbability) {
		// If we have to check validity: check if the new interruption is listed in the permissibleInterruptions array
		if (checkValidity && interruptionType != -1) {
			boolean isPermissible = false;
			for (int i : this.permissibleInterruptions)
				if (permissibleInterruptions[i] == interruptionType) {
					isPermissible = true;
					break;
				}
			if (!isPermissible)
				throw new IncompatibleInterruptionException("Cannot use interruption of type " + interruptionType + " in slot. Permissible interruptions: " + Helper.arrayToString(this.permissibleInterruptions));
		}

		this.currentInterruptionType=interruptionType;
		this.currentInterruptionProbability=interruptionProbability;
	}

	/** Returns the ledger index of the type of the interruption type currently stored in the slot. 
	 * Returns -1 if slot is empty or if there is no interruption stored. (Interruptions are
	 * optional)*/
	public int getInterruptionType() {
		if (this.isEmpty())
			return -1;
		return this.currentInterruptionType;
	}

	/** Returns the type of the delay currently stored in this delayed slot. Returns -1
	 * if this slot is empty.*/
	public int getDelayType() {
		if (this.isEmpty())
			return -1;
		return this.currentDelayType;
	}

	/** Returns true if and only if there is an interruption stored in this slot. Note:
	 * interruptions are optional*/
	public boolean containsInterruption() {
		return this.currentInterruptionType != -1;
	}

	/** Returns the probability of an interruption stored in this slot will or will not
	 * occur. If there is nothing stored in the slot, or if there is no interruption, 
	 * throws an IllegalStateException.*/
	public NumberObjectSingle getInterruptionProbability() {
		if (this.isEmpty() || this.currentInterruptionType==-1)
			throw new IllegalArgumentException("Asking for an interruption in a delayed slot that is either empty or does not contain an interruption. Current interruption: " + this.currentInterruptionType);
		return this.currentInterruptionProbability;
	}

	/** Returns the index of the delay value at the time
	 * that the current resource in this slot was stored. Does
	 * NOT provide the remaining delay time. Throws an IllegalStateException
	 * if this slot is empty*/
	public int getDelayValue() {
		if (this.isEmpty() )
			throw new IllegalArgumentException("Asking for a delay in a delayed slot that is empty. ");
		return this.currentDelayValue;
	}

	/** Returns the number of time steps remaining until 
	 * the resource stored in this slot should be consumed.
	 * If this number is 0, the resource should be consumed in 
	 * that time step's mutation phase. Returns -1 if the
	 * slot is empty, or the delay should have already been
	 * consumed.*/
	public int getRemainingDelay(int currentTimeStep) {
		if (isEmpty())
			return -1;

		int timeToConsumption = this.timeStepLastStored + this.originalDelayDuration;
		return timeToConsumption-currentTimeStep;
	}

	/** Returns true if the delay is finished at the current time step -
	 * that is, if the stored resource has to be consumed now. Throws an 
	 * IllegalStateException if this slot is empty.*/
	public boolean shouldBeConsumedNow(int currentTimeStep) {
		if (isEmpty())
			throw new IllegalStateException("Cannot ask for whether a delay is over for an empty delayed slot");
		return (this.getRemainingDelay(currentTimeStep)==0);
	}




	/** Store the resource in the slot. After the specified delay is over,
	 * the resource will be automatically consumed during the mutation phase,
	 * and upon the moment of consumption there will be the specified interruption (boolean). 
	 * The timestep should be the current time step in the agent's lifetime.*/
	public void store(int resourceType, int resourceValue, int affectedPhenotypicDimension, int delayType, int delayValue, int interruptionType, NumberObjectSingle interruptionProbability, int currentTime) {
		// Can we store a new resource to begin with?
		if (this.isFilled() && !this.isOverwritable())
			throw new IllegalOverwriteException();

		this.timeStepLastStored=currentTime;
		this.setResource(resourceType, resourceValue);
		this.setAffectedPhenotypicDimension(affectedPhenotypicDimension);
		this.setDelay(delayType, delayValue);
		this.setInterruption(interruptionType, interruptionProbability);
	}

	/** Store the resource in the slot. After the specified delay is over,
	 * the resource will be automatically consumed during the mutation phase,
	 * and there will not be an interruption. The timestep should be the current 
	 * time step in the agent's lifetime.*/
	public void store(int resourceType, int resourceValue, int affectedPhenotypicDimension, int delayType, int delayValue, int currentTime) {
		this.store(resourceType, resourceValue, affectedPhenotypicDimension, delayType, delayValue, currentTime);
	}

	@Override
	public PhenotypeSlot deepClone() {
		return new DelayedSlot(this);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + currentDelayType;
		result = prime * result + currentDelayValue;
		result = prime * result
				+ ((currentInterruptionProbability == null) ? 0 : currentInterruptionProbability.hashCode());
		result = prime * result + currentInterruptionType;
		result = prime * result + originalDelayDuration;
		result = prime * result + timeStepLastStored;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DelayedSlot other = (DelayedSlot) obj;
		if (currentDelayType != other.currentDelayType) {
			return false;
		}
		if (currentDelayValue != other.currentDelayValue) {
			return false;
		}
		if (currentInterruptionProbability == null) {
			if (other.currentInterruptionProbability != null) {
				return false;
			}
		} else if (!currentInterruptionProbability.equals(other.currentInterruptionProbability)) {
			return false;
		}
		if (currentInterruptionType != other.currentInterruptionType) {
			return false;
		}
		if (originalDelayDuration != other.originalDelayDuration) {
			return false;
		}
		if (timeStepLastStored != other.timeStepLastStored) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder(this.getString());
		sb.append(", delay type ["+this.currentDelayType+ "], delay value ["+this.currentDelayValue+ "], stored at time " + this.timeStepLastStored);
		if (this.containsInterruption())
			sb.append(", interruption type ["+ this.currentInterruptionType+ "], interruption probability ["+ this.currentInterruptionProbability.toStringWithoutTrailingZeros()+ "].");
		else
			sb.append(", no interruption.");
		return sb.toString();
	}
	
	
}
