package states.phenotypeSlot;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.AbstractModel;
import core.LedgerFactory;
import helper.Helper;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeSlotTemplateRecurringResource;
import view.View;

/** A delayed slot stores a resource type and resource value
 * (in the form of ledger indices), together with a delay type
 * and delayed value (also in the form in ledger indices),
 * and an optional interruption (either -1 for empty or
 * a ledger index) that will automatically be consumed after
 * the time steps run out. Note: the model should check at 
 * the start of each action phase whether a delayed resource will 
 * be consumed.*/
public class RecurringSlot extends PhenotypeSlot {

	private static final long serialVersionUID = Helper.programmeVersion;

	/** The type of interruptions that can be used in this slot. If the
	 * interruption type is changed, and the user has requested that the validity
	 * should be checked during runtime, there will be a check whether the index
	 * of the newly stored interruption (from the Ledger) is in the array of permissible
	 * interruption. If not, an IncompatibleInterruptionException will be thrown. */
	private final int[] permissibleInterruptions;

	/** The type of the interruption currently stored in the slot. Can be -1 (if no interruption is used)*/
	private int currentInterruptionType;

	/** The value of the interruption currently stored in the slot. Can be -1 (if no interruption is stored).
	 * Importantly, this is always an probability, stored in the current PatchState*/
	private NumberObjectSingle currentInterruptionProbability;

	private int currentPeriodicity;

	/** At what time step was the resource stored in this slot - used to 
	 * determine whether the resource should be consumed again. */
	private int timeStepLastStored;

	public RecurringSlot(AbstractModel model, AbstractPhenotypeSlotTemplate slotTemplate, LedgerFactory ledgerFactory) {
		super(model, slotTemplate, ledgerFactory);

		if (!(slotTemplate instanceof PhenotypeSlotTemplateRecurringResource ))
			throw new IllegalArgumentException("Cannot use a slot template of type " + slotTemplate.getClass().getSimpleName() + " to create a recurring slot." );

		if (!this.checkValidity) {
			this.permissibleInterruptions=null;
		} else {
			PhenotypeSlotTemplateRecurringResource recurringTemplate = (PhenotypeSlotTemplateRecurringResource) slotTemplate;

			// Figure out the indices of all permissible interruptions
			ArrayList<Integer> permissibleInterruptionsArrayList = new ArrayList<>();
			for (int i = 0; i < ledgerFactory.interruptionNames.size(); i++) {
				String interruptionName = ledgerFactory.interruptionNames.get(i);
				InterruptionObjectTemplate interruptionTemplate = (InterruptionObjectTemplate) View.getView().workspace.getObject(interruptionName);
				if (recurringTemplate.canUseInterruption(interruptionTemplate))
					permissibleInterruptionsArrayList.add(i);
			}
			this.permissibleInterruptions = new int[permissibleInterruptionsArrayList.size()];
			for (int i = 0; i < permissibleInterruptions.length; i++)
				permissibleInterruptions[i] = permissibleInterruptionsArrayList.get(i);
		}
	}

	/** Copy constructor*/
	public RecurringSlot (RecurringSlot original) {
		super(original);
		this.permissibleInterruptions=original.permissibleInterruptions;
		this.currentInterruptionProbability=original.currentInterruptionProbability.clone();
		this.currentInterruptionType=original.currentInterruptionType;
		this.currentPeriodicity=original.currentPeriodicity;
		this.timeStepLastStored=original.timeStepLastStored;
	}
	@Override
	protected SlotType getSlotType() {
		return SlotType.RECURRING;
	}


	/** Set the interruption used in this slot. Throws an IncompatibleInterruptionException if the
	 * interruption is not permissible and checkValidity is true. Interruption type can be set to
	 * null to signal that there is no interruption. */
	private void setInterruption(int interruptionType, NumberObjectSingle interruptionProbability) {
		// If we have to check validity: check if the new interruption is listed in the permissibleInterruptions array
		if (checkValidity && interruptionType != -1) {
			boolean isPermissible = false;
			for (int i : this.permissibleInterruptions)
				if (permissibleInterruptions[i] == interruptionType) {
					isPermissible = true;
					break;
				}
			if (!isPermissible)
				throw new IncompatibleInterruptionException("Cannot use interruption of type " + interruptionType + " in slot. Permissible interruptions: " + Helper.arrayToString(this.permissibleInterruptions));
		}

		this.currentInterruptionType=interruptionType;
		this.currentInterruptionProbability=interruptionProbability;
	}


	/** Returns the ledger index of the type of the interruption type currently stored in the slot. 
	 * Returns -1 if slot is empty or if there is no interruption stored. (Interruptions are
	 * optional)*/
	public int getInterruptionType() {
		if (this.isEmpty())
			return -1;
		return this.currentInterruptionType;
	}

	/** Returns true if and only if there is an interruption stored in this slot. Note:
	 * interruptions are optional*/
	public boolean containsInterruption() {
		return this.currentInterruptionType != -1;
	}

	/** Returns whether the interruption stored in this slot will or will not
	 * occur. If there is nothing stored in the slot, or if there is no interruption, 
	 * throws an IllegalStateException.*/
	public NumberObjectSingle getInterruptionProbability() {
		if (this.isEmpty() || this.currentInterruptionType==-1)
			throw new IllegalArgumentException("Asking for an interruption probability in a delayed slot that is either empty or does not contain an interruption. Current interruption: " + this.currentInterruptionType);
		return this.currentInterruptionProbability;
	}

	/** Returns the number of time steps until the next time that the slot's stored resource
	 * should be consumed. Returns -1 if the slot is empty*/
	public int getRemainingTimeStepsUntilNextConsumption(int currentTimeStep) {
		if (this.isEmpty())
			return -1;

		int timePassed = currentTimeStep - this.timeStepLastStored;

		return (timePassed % currentPeriodicity);

	}


	/** Returns true if the resource stored in this recurring slot
	 * should be consumed during the mutation phase of this time step. 
	 * Throws an IllegalStateException if there is no resource stored 
	 * in this slot.*/
	public boolean shouldBeConsumedNow(int currentTimeStep) {
		if (isEmpty())
			throw new IllegalStateException("Cannot ask for whether a resource should be consumed for an empty recurring slot.");
		return (this.getRemainingTimeStepsUntilNextConsumption(currentTimeStep) == 0);
	}




	/** Store the resource in the slot. From now, until the end of the run or 
	 * until this slot is emptied, the resource will be automatically consumed during the mutation phase
	 * after each periodicity time step. When there is a consumption, there will the specified interruption (boolean). 
	 * The timestep should be the current time step in the agent's lifetime.*/
	public void store(int resourceType, int resourceValue, int affectedPhenotypicDimension, int interruptionType, NumberObjectSingle interruptionProbability, int periodicity, int currentTime) {
		// Can we store a new resource to begin with?
		if (this.isFilled() && !this.isOverwritable())
			throw new IllegalOverwriteException();

		this.timeStepLastStored=currentTime;
		this.setResource(resourceType, resourceValue);
		this.setAffectedPhenotypicDimension(affectedPhenotypicDimension);
		this.currentPeriodicity=periodicity;
		this.setInterruption(interruptionType, currentInterruptionProbability);
	}

	/** Store the resource in the slot. After the specified delay is over,
	 * the resource will be automatically consumed during the mutation phase,
	 * and there will not be an interruption. The timestep should be the current 
	 * time step in the agent's lifetime.*/
	public void store(int resourceType, int resourceValue, int affectedPhenotypicDimension, int delayType, int delayValue, int currentTime) {
		this.store(resourceType, resourceValue, affectedPhenotypicDimension, delayType, delayValue, currentTime);
	}

	@Override
	public PhenotypeSlot deepClone() {
		return new RecurringSlot(this);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((currentInterruptionProbability == null) ? 0 : currentInterruptionProbability.hashCode());
		result = prime * result + currentInterruptionType;
		result = prime * result + currentPeriodicity;
		result = prime * result + timeStepLastStored;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		RecurringSlot other = (RecurringSlot) obj;
		if (currentInterruptionProbability == null) {
			if (other.currentInterruptionProbability != null) {
				return false;
			}
		} else if (!currentInterruptionProbability.equals(other.currentInterruptionProbability)) {
			return false;
		}
		if (currentInterruptionType != other.currentInterruptionType) {
			return false;
		}
		if (currentPeriodicity != other.currentPeriodicity) {
			return false;
		}
		if (timeStepLastStored != other.timeStepLastStored) {
			return false;
		}
		return true;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder(this.getString());
		sb.append(", periodicity "+ this.currentPeriodicity+", stored at time " + this.timeStepLastStored);
		if (this.containsInterruption())
			sb.append(", interruption type ["+ this.currentInterruptionType+ "], interruption probability ["+ this.currentInterruptionProbability.toStringWithoutTrailingZeros()+ "]");
		else
			sb.append(", no interruption");
		return sb.toString();
	}
	
}
