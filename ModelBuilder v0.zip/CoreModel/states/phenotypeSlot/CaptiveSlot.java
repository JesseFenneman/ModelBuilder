package states.phenotypeSlot;

import core.AbstractModel;
import core.LedgerFactory;
import helper.Helper;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.PhenotypeSlotTemplateCaptiveResource;

/** A captive slot stores a resource type and resource value
 * (in the form of ledger indices), that can be used later
 * by an agent. */
public class CaptiveSlot extends PhenotypeSlot {
	private static final long serialVersionUID = Helper.programmeVersion;
	public CaptiveSlot(AbstractModel model, AbstractPhenotypeSlotTemplate slotTemplate, LedgerFactory ledgerFactory) {
		super(model, slotTemplate, ledgerFactory);
		
		if (!(slotTemplate instanceof PhenotypeSlotTemplateCaptiveResource ))
			throw new IllegalArgumentException("Cannot use a slot template of type " + slotTemplate.getClass().getSimpleName() + " to create a captive slot." );
	}

	/** Copy constructor */
	private CaptiveSlot(CaptiveSlot original) {
		super(original);
	}
	@Override
	protected SlotType getSlotType() {
		return SlotType.CAPTIVE;
	}

	@Override
	public void emptySlot() {
		this.removeResource();
	}
	
	/** Store a resource in this captive slot. Throws an IllegalOverwriteException if 
	 * this slot is filled (i.e., not empty) and this slot cannot be overwritten.*/
	public void store(int resourceType, int resourceValue, int affectedPhenotypicDimension) {
		// Can we store a new resource to begin with?
		if (this.isFilled() && !this.isOverwritable())
			throw new IllegalOverwriteException();
		
		this.setResource(resourceType, resourceValue);
		this.setAffectedPhenotypicDimension(affectedPhenotypicDimension);
	}

	@Override
	public PhenotypeSlot deepClone() {
		return new CaptiveSlot(this);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return this.getString()+ ".";
	}
	
}
