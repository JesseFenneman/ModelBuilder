package states.phenotypeSlot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

import core.AbstractModel;
import core.LedgerFactory;
import helper.Helper;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import view.View;

public abstract class PhenotypeSlot implements Serializable{
	private static final long serialVersionUID = Helper.programmeVersion;

	/** Occurs if the model tries to store a resource in a slot that cannot accept such resources */
	@SuppressWarnings("serial")
	public static class IncompatibleResourceException extends RuntimeException { public IncompatibleResourceException(String s) {     super(s);  }}

	/** Occurs if the model tries to affect a phenotypic dimensions in a slot that cannot accept such dimensions */
	@SuppressWarnings("serial")
	public static class IncompatiblePhenotypicDimension extends RuntimeException { public IncompatiblePhenotypicDimension(String s) {     super(s);  }}


	/** Occurs if the model tries to store an interruption in a slot that cannot accept such interrruptions */
	@SuppressWarnings("serial")
	public static class IncompatibleInterruptionException extends RuntimeException { public IncompatibleInterruptionException(String s) {     super(s);  }}

	/** Occurs if the model tries to store a delay in a slot that cannot accept such delays */
	@SuppressWarnings("serial")
	public static class IncompatibleDelayException extends RuntimeException { public IncompatibleDelayException(String s) {     super(s);  }}

	/** Occurs if the model tries to store resource in a slot that is already full, and that cannot be overwritten */
	@SuppressWarnings("serial")
	public static class IllegalOverwriteException extends RuntimeException { public IllegalOverwriteException() {     super();  }}


	/** At the time of writing there are three different slots: 
	 * 
	 * Captive slot - holds a resource, but does nothing else
	 * Delayed slot - holds a resource, will which be consumed automatically after a delay has passed. 
	 * 					There may or may not be an interruption.
	 * Recurring slot - holds a resource, which will be consumed (without exhausting the resource)
	 * 					every t times steps. There may or may not be an interruption.*/
	public enum SlotType{
		CAPTIVE, DELAYED, RECURRING;
	}


	///////// FIELDS
	/** There is the option of checking the validity of all steps. For 
	 * example, the program can check during runtime if a resource stored
	 *  in this slot is indeed of a type that is permissible to be stored
	 *  in this slot. Now, under normal situations, it should not be possible
	 *  to (try) to store a non-permissible slot. However, it can sometimes
	 *  be better to be save rather than sorry. Then again, having to check
	 *  every time a change occurs can be a big hit to performance. The solution:
	 *  there is a final boolean that determines whether there should be a
	 *  validity check every time that there is a change. */
	protected final boolean checkValidity;

	protected final AbstractModel model;

	/** The type of resources that can be stored in this slot. If there is a new 
	 * resource stored in this slot, and the user has requested that the validity
	 * should be checked during runtime, there will be a check whether the index
	 * of the newly stored resource (from the Ledger) is in the array of permissible
	 * resources. If not, an IncompatibleResourceException will be thrown. If no checks
	 * will be done, this array is null.*/
	private final int[] permissibleResources;

	/** The type (index in Ledger) of the resource currently stored in the Slot. -1 if slot empty.*/
	private int currentResourceType;

	/** The value (index in Ledger) of the resource currently stored in the slot. -1 if slot is empty*/
	private int currentResourceValue;

	/** Does this slot currently contain a resource? */
	private boolean isEmpty;

	/** The type of phenotypic dimensions that can be affected by resources stored in this slot. If the
	 * affected phenotypic dimension is changed, and the user has requested that the validity
	 * should be checked during runtime, there will be a check whether the index
	 * of the newly stored affected phenotypic dimensions (from the Ledger) is in the array of permissible
	 * dimensions. If not, an IncompatibleResourceException will be thrown. If no checks
	 * will be done, this array is null.*/
	private final int[] permissiblePhenotypicDimensions;

	/** The phenotypic dimension affected by the currently stored resource. */
	private int currentAffectedPhenotypicDimension;

	/** Can resources in this slot be overwritten? */
	private final boolean isOverwritable;


	/// FUNCTIONS
	protected abstract SlotType getSlotType();


	/** Use a PhenotypeSlotTemplate to create a new phenotype slot.
	 * This function assumes that all resources, delays, interruptions, and phenotypic dimensions
	 * are already added to the ledger. If check validity is true, additional checks 
	 * will be performed whenever a new resource is stored in the slot.
	 * 
	 * The name of this slot has to be registered separately in the LedgerFactory.*/
	protected PhenotypeSlot(AbstractModel model, AbstractPhenotypeSlotTemplate slotTemplate, LedgerFactory ledgerFactory) {
		this.model = model;
		this.checkValidity = model.performSafetyChecks;
		
		if (!checkValidity) {
			this.permissibleResources=null;
			this.permissiblePhenotypicDimensions=null;
		} else {
			// Figure out the indices of all permissible resources
			ArrayList<Integer> permissibleResourcesArrayList = new ArrayList<>();
			for (int r = 0; r < ledgerFactory.resourceNames.size(); r++) {
				String resourceName = ledgerFactory.resourceNames.get(r);
				ResourceObjectTemplate resourceTemplate = (ResourceObjectTemplate) View.getView().workspace.getObject(resourceName);
				if (slotTemplate.canUseResource(resourceTemplate))
					permissibleResourcesArrayList.add(r);
			}
			this.permissibleResources = new int[permissibleResourcesArrayList.size()];
			for (int i = 0; i < permissibleResources.length; i++)
				permissibleResources[i] = permissibleResourcesArrayList.get(i);


			// Figure out the indices of all permissible phenotypic dimensions that can be affected by resources in this slot
			ArrayList<Integer> permissiblePhenotypicDimensionsArrayList = new ArrayList<>();
			for (int p = 0; p < ledgerFactory.phenotypicDimensionNames.size(); p++) {
				String phenotypeName = ledgerFactory.phenotypicDimensionNames.get(p);
				PhenotypeObjectTemplate phenotypeTemplate = (PhenotypeObjectTemplate) View.getView().workspace.getObject(phenotypeName);
				if (slotTemplate.canUsePhenotype(phenotypeTemplate))
					permissiblePhenotypicDimensionsArrayList.add(p);
			}
			this.permissiblePhenotypicDimensions= new int[permissiblePhenotypicDimensionsArrayList.size()];
			for (int i = 0; i < permissiblePhenotypicDimensions.length; i++)
				permissiblePhenotypicDimensions[i] = permissiblePhenotypicDimensionsArrayList.get(i);
		}
		this.isOverwritable=slotTemplate.isOverwritable();
		this.isEmpty=true;
	}

	/** Copy constructor*/
	protected PhenotypeSlot(PhenotypeSlot original) {
		this.model=original.model;
		this.checkValidity=model.performSafetyChecks;
		this.permissibleResources=original.permissibleResources;
		this.permissiblePhenotypicDimensions=original.permissiblePhenotypicDimensions;
		this.currentAffectedPhenotypicDimension=original.currentAffectedPhenotypicDimension;
		this.currentResourceType=original.currentResourceType;
		this.currentResourceValue=original.currentResourceValue;
		this.isOverwritable=original.isOverwritable;
		
	}
	/** Returns a deep copy of this PhenotypeSlot*/
	public abstract PhenotypeSlot deepClone();
	
	/** Returns true if there is no resource currently in the slot.*/
	public boolean isEmpty() {return this.isEmpty;}

	/** Returns false if there is no resource currently in the slot. Returns true if there is a resource currently in the slot.*/
	public boolean isFilled() {return !this.isEmpty; }

	/** Can this slot be overwritten - that is, can the agent store a resource in this slot if there already is another
	 * resource in this slot?*/
	public boolean isOverwritable() {
		return this.isOverwritable;
	}

	/** Set the resource stored in this Slot. Note: this function assumes that there
	 * already was a check whether a new resource could be placed (i.e., whether this
	 * slot is overwritable or empty). Throws an IncompatibleResourceException if the
	 * resource is not permissible and checkValidity is true.*/
	protected void setResource (int resourceType, int resourceValue) {	
		// If we have to check validity: check if the resourceType is listed in the permissibleResource array
		if (checkValidity) {
			boolean isPermissible = false;
			for (int i : this.permissibleResources)
				if (permissibleResources[i] == resourceType) {
					isPermissible = true;
					break;
				}
			if (!isPermissible)
				throw new IncompatibleResourceException("Cannot store resource type " + resourceType + " in slot. Permissible resources: " + Helper.arrayToString(this.permissibleResources));
		}

		this.currentResourceType = resourceType;
		this.currentResourceValue= resourceValue;
		this.isEmpty=false;
	}

	/** Remove resource stored in this slot. Does not affect phenotypic dimension. */
	protected void removeResource() {
		this.isEmpty=true;
	}

	/** Returns the type (but not the value) of resource current stored in the slot. Specifically,
	 * returns the resource's type index in the ledger. Returns -1 if slot is empty*/
	public int getResourceType() {
		if (this.isEmpty)
			return -1;
		return this.currentResourceType;
	}

	/** Returns the value (but not the type) of resource current stored in the slot. Specifically,
	 * returns the resource's value index in the ledger. Returns -1 if slot is empty*/
	public int getResourceValue() {
		if (this.isEmpty)
			return -1;
		return this.currentResourceValue;
	}

	/** Set the affected phenotypic dimension for the resource  stored in this Slot. Throws an IncompatiblePhenotypeException if the
	 * resource is not permissible and checkValidity is true.*/
	protected void setAffectedPhenotypicDimension(int phenotypicDimension) {
		// If we have to check validity: check if the new phenotypic dimension is listed in the permissiblePhenotypic Dimension array
		if (checkValidity) {
			boolean isPermissible = false;
			for (int i : this.permissiblePhenotypicDimensions)
				if (permissiblePhenotypicDimensions[i] == phenotypicDimension) {
					isPermissible = true;
					break;
				}
			if (!isPermissible)
				throw new IncompatibleResourceException("Cannot affect phenotypic dimension " + phenotypicDimension + " in slot. Permissible phenotypic dimensions: " + Helper.arrayToString(this.permissiblePhenotypicDimensions));
		}

		this.currentAffectedPhenotypicDimension=phenotypicDimension;
	}

	/** Returns the index of the phenotypic dimension influenced by the resource currently stored in the slot. 
	 * Returns -1 if slot is empty*/
	public int getAffectedPhenotypicDimension() {
		if (this.isEmpty)
			return -1;
		return this.currentAffectedPhenotypicDimension;
	}

	/** Signifies that this slot should be considered to be empty. Does not overwrite the previously stored
	 * values.*/
	public void emptySlot() {
		this.isEmpty = true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + currentAffectedPhenotypicDimension;
		result = prime * result + currentResourceType;
		result = prime * result + currentResourceValue;
		result = prime * result + (isEmpty ? 1231 : 1237);
		result = prime * result + (isOverwritable ? 1231 : 1237);
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		PhenotypeSlot other = (PhenotypeSlot) obj;
		if (currentAffectedPhenotypicDimension != other.currentAffectedPhenotypicDimension) {
			return false;
		}
		if (currentResourceType != other.currentResourceType) {
			return false;
		}
		if (currentResourceValue != other.currentResourceValue) {
			return false;
		}
		if (isEmpty != other.isEmpty) {
			return false;
		}
		if (isOverwritable != other.isOverwritable) {
			return false;
		}
		
		return true;
	}

	
	public abstract String toString ();
	
	/** Returns a string detailing the current affected phenotypic dimension, the current resource type, and the current resource value,
	 * and overwritability */
	protected String getString() {
		if (this.isEmpty)
			return "[empty]";
	
		return "Resource type ["+this.currentResourceType+ "], value ["+this.currentResourceValue+ "], phenotypic dimension ["+this.currentAffectedPhenotypicDimension+ "], overwritable " + this.isOverwritable;
	}

}
