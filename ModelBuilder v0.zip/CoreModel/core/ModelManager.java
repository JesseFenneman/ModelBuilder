package core;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

import helper.Helper;
import interfaces_abstractions.ObserverManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import start.Console;
import view.View;
/** A manager that manages all processes relating to which
 * model should run at which time. Importantly, the currently
 * active model can be accessed via a static call. */
public class ModelManager {


	// Singleton pattern to make sure that there always is exactly one ModelManager
	private static ModelManager instance;
	public static ModelManager getModelManager() {
		if (instance == null)
			instance = new ModelManager();
		return instance;
	}


	// A class to store the references to created models 
	// and their current status. Note, delete the reference
	// to the model after it is done; we want the garbage 
	// collector to pick it up 
	public enum ModelStatus {
		WAITING_TO_START,
		RUNNING, 
		COMPLETED, 
		INTERRUPTED}

	/** A class that keeps track of each model's current name,
	 * description, current status, and percent complete*/
	public class ModelRecord {
		public final String modelName, modelDescription;
		public int percentageComplete;
		public ModelStatus status;

		public ModelRecord(Model model) {
			this.modelName = model.name;
			this.modelDescription = model.description;
			this.percentageComplete = 0;
			this.status= ModelStatus.WAITING_TO_START;
		}
	}


	/** There can only be one active model at a time. This active model runs on the ModelThread*/
	private final Thread modelThread;
	private final ModelThreadRunnable modelThreadRunnable;

	// Private constructor
	private ModelManager() {
		this.modelThreadRunnable = new ModelThreadRunnable();
		this.modelThread = new Thread(modelThreadRunnable);
		this.modelThread.setName("Model execution thread");
		this.modelThread.start();
	}

	/** Add the specified models to the to-be-run list.*/
	private void addModelsToQueueInstance(ArrayList<Model> models) {
		this.modelThreadRunnable.addModelsToQueue(models);
	}
	/** Add the specified models to the to-be-run list.*/
	public static void addModelsToQueue(ArrayList<Model> models) {
		ModelManager.getModelManager().addModelsToQueueInstance(models);
	}
	
	/** Returns a reference to all the ModelRecords*/
	private ObservableList<ModelRecord> getAllRecordsInstance() {
		return modelThreadRunnable.getAllRecords();
	}
	/** Returns a reference to all the ModelRecords*/
	public static ObservableList<ModelRecord> getAllRecords() {
		return ModelManager.getModelManager().getAllRecordsInstance();
	}
	
	/** Called by a Model to update the ModelManager about the progress of that model */
	private void reportProgressInstance(Model model, ModelStatus status, int percentComplete) {
		this.modelThreadRunnable.reportProgress(model, status, percentComplete);
	}
	/** Called by a Model to update the ModelManager about the progress of that model */
	public static void reportProgress(Model model, ModelStatus status, int percentComplete) {
		ModelManager.getModelManager().reportProgressInstance(model, status, percentComplete);
	}


	/** Tells the active model to stop and erases the queue. Cannot be undone*/
	private void stopAllModelsInstance() {
		this.modelThreadRunnable.stopAllModels();
	}
	/** Tells the active model to stop and erases the queue. Cannot be undone*/
	public static void stopAllModels() {
		ModelManager.getModelManager().stopAllModelsInstance();
	}

	/** Returns true if there is at least one Model that is neither done nor interrupted */
	private boolean isThereAnActiveModelInstance() {
		return this.modelThreadRunnable.isThereAnActiveModel();
	}
	/** Returns true if there is at least one Model that is neither done nor interrupted */
	public static boolean isThereAnActiveModel() {
		return ModelManager.getModelManager().isThereAnActiveModelInstance();
	}
	
	/** Returns the currently active model, or null if there is no currently active model*/
	private Model getActiveModelInstance() {
		return this.modelThreadRunnable.getActiveModel();
	}
	/** Returns the currently active model, or null if there is no currently active model*/
	public static Model getActiveModel() {
		return ModelManager.getModelManager().getActiveModelInstance();
	}
	
	/** The Runnable that runs on the modelThread*/
	private class ModelThreadRunnable implements Runnable{

		/** A record of a model that is either to be run, is running, or has finished. Should
		 * not contain a reference to the actual Model, as we don't want to prevent the 
		 * garbage collector to remove completed models.*/
		private final ObservableList<ModelRecord> modelRecords;

		/** A queue for models that are waiting to have their turn in the sun*/
		private final Queue<Model> modelsToRun;

		/** A reference to the currently active model.  */
		private Model currentlyActiveModel;


		public ModelThreadRunnable() {
			this.modelRecords = FXCollections.observableArrayList();
			this.modelsToRun = new LinkedList<>();
			this.currentlyActiveModel = null;
		}

		@Override
		public void run() {
			while (true) {
				try {
					/* If there are no models to run yet, sleep for a moment*/
					if (this.modelsToRun.size() == 0)
						Thread.sleep(100);
					else {
						// If there is a model, take it from the queue...
						Model m = this.modelsToRun.poll();

						// Create an ModelRecord for this model
						ModelRecord newRecord = new ModelRecord(m);
						this.addRecord(newRecord);

						// Set currentlyActiveModel
						this.currentlyActiveModel = m;

						// Run the model
						m.run();

						// Remove currentlyActiveModel
						this.currentlyActiveModel = null;

						// After the model is done, wait for a bit for the garbage collector to catch up
						//Sleep for a moment
						Console.print("Model completed. Starting again with a new model in a moment...");
						for (int i = 10; i > 0; i--) {
							System.gc();
							Thread.sleep(100);
							System.err.println("Sleeping: " + i + " (models in queue: " + this.modelsToRun.size() + ")");
						}

						if (this.modelsToRun.size() == 0)
							System.err.println("Finished on: " + Helper.timestamp());

					}
				} catch (Exception e) { ObserverManager.notifyObserversOfError(e);}
			}
		}

		/** Add the ModelRecord to the list of all modelRecords. Throws an IllegalArgumentException if there already is a model
		 * with the same name in the books. */
		private void addRecord(ModelRecord newRecord) {
			// Check if there is a model with the same name
			for (ModelRecord mr: modelRecords)
				if (mr.modelName.equals(newRecord.modelName))
					throw new IllegalStateException("Model name already exists in the records.");
			this.modelRecords.add(newRecord);
		}

		private ModelRecord getRecordFor(Model m) {
			for (ModelRecord mr: modelRecords)
				if (mr.modelName.equals(m.name))
					return mr;
			throw new IllegalArgumentException("Asking for a ModelRecord for a non-recorded model. Odd.");
		}
		/** Returns a reference to all the ModelRecords*/
		public ObservableList<ModelRecord> getAllRecords() {
			return this.modelRecords;
		}
		/** Add the specified models to the to-be-run list.*/
		public synchronized void addModelsToQueue(ArrayList<Model> models) {
			this.modelsToRun.addAll(models);
		}

		/** Called by a Model to update the ModelManager about the progress of that model */
		public void reportProgress(Model model, ModelStatus currentStatus, int percentComplete) {

			// Find the ModelRecord corresponding to this model
			ModelRecord record = getRecordFor(model);

			// Set the status
			record.status=currentStatus;
			
			// Update the percentage complete if the model is running
			if (currentStatus == ModelStatus.RUNNING) 
				record.percentageComplete= percentComplete;
			
			// Set the status to 0 if the model has not yet started
			if (currentStatus == ModelStatus.WAITING_TO_START)
				record.percentageComplete = 0;
			
			if (currentStatus == ModelStatus.INTERRUPTED)
				record.percentageComplete=-1;
			
			if (currentStatus == ModelStatus.COMPLETED)
				record.percentageComplete=100;
			
			StringBuilder sb = new StringBuilder();
			sb.append("Reporting progress on " + 
					model.name + ": " + 
					currentStatus);
			if (currentStatus == ModelStatus.RUNNING)
				sb.append(", " + percentComplete + "% complete");
			Console.print(sb.toString() );

			// Tell the view to update the model progress
			View.getView().updateModelProgress();

		}

		public void stopAllModels() {
			this.modelsToRun.clear();
			if (this.currentlyActiveModel != null)
				currentlyActiveModel.interruptModel();
		}

		/** Returns true if there is at least one Model that is neither done nor interrupted */
		public boolean isThereAnActiveModel() {
			return this.currentlyActiveModel != null;
		}

		/** Returns the currently active model. Returns null if there is no model active*/
		public Model getActiveModel() {
			return this.currentlyActiveModel;
		}

	}


}
