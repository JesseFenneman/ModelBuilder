package core;

import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;

import FitnessElement.FitnessFunctionTemplate;
import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import attributes.AttributeField.IncompatibleNumberObjectTypeException;
import decimalNumber.DecimalNumber;
import interfaces_abstractions.ObserverManager;
import rIntegration.RFunction;
import start.Console;
import states.RoamingStates.T1FitnessState;

/** A class that computes the actual fitness of a FitnessState.
 * There are two user specified modes: either to use a fixed
 * fitness for a not-yet-end-of-run dead state, or evaluate 
 * the dead state fitness by using its phenotype. States that
 * died because the have reached the maximum time are always
 * evaluated by their phenotype*/
public class FitnessFunction {

	private final AbstractModel model;
	private final boolean useFitnessFunctionBeforeMaximumAge;
	private final NumberObjectSingle fixedDeathFitness;
	private final RFunction fitnessFunction;
	
	// The fitness function takes as input a set of phenotypic dimensions. 
	// Which dimensions are used in what order is given by indexPhenotypes.
	// We'll use -2 to denote age (as age is not a phenotype in the ledger,
	// but we already return -1 for entries that do not exist)
	private final int[] indexPhenotypes;
	
	public FitnessFunction(FitnessFunctionTemplate template, boolean useFitnessFunctionBeforeMaximumAge, NumberObjectSingle fixedDeathFitness, AbstractModel model) {
		if (fixedDeathFitness != null)
			this.fixedDeathFitness = NumberObject.createNumber(model.howToRepresentNumbers, fixedDeathFitness);
		else
			this.fixedDeathFitness = null;
		
		this.model = model;
		this.useFitnessFunctionBeforeMaximumAge = useFitnessFunctionBeforeMaximumAge;
		this.fitnessFunction = template.fitnessFunction;
		
		// Figure out which phenotype indices go into which argument of the function
		indexPhenotypes = new int[template.args.length];
		for (int p = 0; p < template.args.length; p ++) 
			if (template.args[p].getName().equals("Age"))
				indexPhenotypes[p] = -2;
			else
				indexPhenotypes[p] = model.ledger.getIndexOfPhenotype(template.args[p].getName());
			
	}
	
	public NumberObjectSingle getFitnessFor(T1FitnessState state) {
		if (!useFitnessFunctionBeforeMaximumAge)
			if (state.getAge() < model.ledger.model.maximumAge)
				return fixedDeathFitness.clone();
		return applyFitnessFunctionTo(state);
	}
	
	/** Computes the fitness for the provided T1FitnessState*/
	private NumberObjectSingle applyFitnessFunctionTo(T1FitnessState state) {
		// Create a NumberObject for all arguments (i.e., phenotypic dimension values) that go into the fitness function
		// Note, if an indexPhenotype is -2 that means that we need to use an agent's age 
		NumberObjectSingle[] args = new NumberObjectSingle[indexPhenotypes.length];
		for (int i = 0; i < args.length; i++) {
			if (indexPhenotypes[i] == -2) // age
				args[i] = new DecimalNumber(state.getAge());
			else {
				int valueOfPhenotypicDimensionInLedger = state.getPhenotypeValue(indexPhenotypes[i] );
				args[i] = model.ledger.getValueOfPhenotype(indexPhenotypes[i], valueOfPhenotypicDimensionInLedger);
			}
		}
		try {
			return NumberObject.createNumber(model.howToRepresentNumbers, (NumberObjectSingle) fitnessFunction.runInR(args)[0]);
		} catch (IncompatibleNumberObjectTypeException | REngineException | REXPMismatchException
				| RestrictionViolationException e) {
			ObserverManager.notifyObserversOfError(e);
			model.outputFileManager.writeExceptionToFile(e);;
		}
		return null;
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder("Fitness function: '" + fitnessFunction.getName() +"', with arguments: {");
		if (indexPhenotypes.length == 0)
			sb.append("null");
		else
			for (int i = 0; i < indexPhenotypes.length; i++) {
				if (indexPhenotypes[i] != -2)
					sb.append(" ([" + indexPhenotypes[i] + "] " + model.ledger.phenotypicDimensionNames[indexPhenotypes[i]] + ")");
				else
					sb.append(" (age)");
				if (!(i == indexPhenotypes.length-1) && indexPhenotypes.length > 1)
					sb.append(", ");
			}
		sb.append("}");		
		
		if (!useFitnessFunctionBeforeMaximumAge)
			sb.append(". Agents who die before the final cycle have a fitness of " + fixedDeathFitness.toStringWithoutTrailingZeros());
		else
			sb.append(". This fitness function applies to all fitness states");
		return sb.toString();
	}
}
