package core;

import java.math.RoundingMode;
import java.util.Arrays;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import belief.Cue;
import deathConditions.DeathCondition;
import deathConditions.GrimReaper;
import helper.Helper;
import mutations.Mutation;
import mutations.ObjectMutator;
import mutations.StateMutator;
import patch.Patch;
import patch.PatchState;
import rIntegration.RFunctionContainer;
import states.phenotypeSlot.CaptiveSlot;
import states.phenotypeSlot.DelayedSlot;
import states.phenotypeSlot.RecurringSlot;
import t1Actions.T1Action;
import t2Actions.T2Action;

/** 
 * All objects in a model have discrete values that are multiples of some value x. 
 * During runtime, we can use these values directly. However, we run into some issues.
 * The first is that due to floating point imprecision, its difficult to directly compare
 * values, and using the same value many times over might result in incorrect values. This
 * is an issue especially because we often create many states, and need to figure out if
 * that state already exists. If this comparison does not go correct, we get state alliasing
 * problem where multiple existing states are actually just one state.
 * 
 * One way to deal with this is to use the DecimalNumber class, which I created specifically
 * to deal with floating point imprecision. Although this comparison is correct, it is also
 * quite slow. 
 * 
 * One other approach is to turn all values into an integer value. Specifically, we can rewrite
 * all values as an integer multiple of the step size. Because the stepsizes are always the same,
 * this transformation is a linear one. That's good, because that means we can use those integer
 * values for addition and subtraction. However, we can go even one step further, and assign the
 * value 0 for the lowest possible value. An example might clear this up.
 * 
 * Suppose we have a resource with values {-2, -1, 0, 1, 2}. Rather than using these numbers directly,
 * we can assign the following integer values:
 * -2 = 0
 * -1 = 1
 *  0 = 2
 *  1 = 3
 *  2 = 4 
 *  
 *  Now we only have to use integer values when computing states, which is both fast and precise. However,
 *  afterwards we have to back-translate the integers to the DecimalNumber values. For this backtranslation
 *  we need to know A) the step size, or slope; and B) the intercept (what value does the integer value 0
 *  translate to?). Keeping track of these translations is what the Ledger does.
 *  
 *  Similarly, rather than referring to objects and by their name, we can refer to them by an integer value. 
 *  For instance, rather than referring to the base state in the base patch by a string value, we can call
 *  this patch state '0'. The nice thing about that is that we can store patches and patch states in a single
 *  array. Because retrieving objects from an array by directly accessing their index location is fast (big-Oh 
 *  is constant), we can increase runtime significantly this way.
 *  
 *  Note that after construction the ledger cannot be changed - once an integer value points to an object, that
 *  integer value should always point to that object (or otherwise: you can read from the ledger, but never write!).
 *  As such, the Ledger class is thread-safe.  */
public class Ledger {

	public final AbstractModel model;

	// Phenotype arrays
	public final int			numberOfNonAgePhenotypicDimensions;
	public final String[] 		phenotypicDimensionNames;			// All phenotype names, stored [phenotypeIndex]
	public final NumberObjectSingle[][] phenotypicDimensionValues;	// All phenotype values, stored [phenotypeIndex][valueIndex]
	public final NumberObjectSingle[]   phenotypicDimensionStepsize;
	public final int[] 			phenotypicDimensionZeroPoints;		// The index where the phenotype has a value of 0, stored [phenotypeIndex]
	
	// Resource related arrays
	public final int			numberOfResourceTypes;
	public final String[] 		resourceNames;						// All resource names, stored [resourceIndex]
	public final NumberObjectSingle[][] resourceValues;				// All resource values, stored [resourceIndex][valueIndex]
	public final boolean[]		resourceIsConstant;					// True if there is a single possible value. Stored as [resourceIndex]
	public final NumberObjectSingle[]   resourceStepsize;
	public final int[][] 		conversionResourceToPhenotype; 		// How many units does the phenotype increase when consuming a resource with a value equal to the stepsize of that resource?. Stored [resourceIndex][phenotypeIndex]
	public final int[] 			resourceZeroPoints;					// At what index value in resourceValues corresponds to 0?, stored [resourceIndex]
	public final Cue[] 			resourceCues;						// All cues emittable by a resource, stored [resourceIndex]
	public final String[][] 	resourceCueLabels;					// All labels that a cue might have, stored [resourceIndex][cueIndex]

	// Extrinsic related arrays
	public final int			numberOfExtrinsicTypes;
	public final String[] 		extrinsicNames;						// All extrinsic names, stored [extrinsicIndex]
	public final NumberObjectSingle[][] extrinsicValues;			// All extrinsic values, stored [extrinsicIndex][valueIndex]
	public final boolean[]		extrinsicIsConstant;					// True if there is a single possible value. Stored as [extrinsicIndex]
	public final NumberObjectSingle[]   extrinsicStepsize;
	public final int[] 			extrinsicZeroPoints;				// At what index value in extrinsicValues corresponds to 0?, stored [extrinsicIndex]
	public final int[][] 		conversionExtrinsicToPhenotype; 	// How many units does the phenotype increase when encountering a extrinsic with a value equal to the stepsize of that resource?. Stored [resourceIndex][phenotypeIndex]

	// Interruption related arrays
	public final int			numberOfInterruptionTypes;
	public final String[] 		interruptionNames;
	public final NumberObjectSingle[] interruptionValues; 			// Always 0/false and 1/true, in that order. But construction depends on whether the model wants to use DecimalNumbers or DoubleNumbers
	public final Cue[] 			interruptionCues;
	public final String[][] 	interruptionCueLabels;

	// Delay related arrays
	public final int 			numberOfDelayTypes;
	public final String[] 		delayNames;
	public final int[][] 		delayValues;
	public final boolean[]		delayIsConstant;					// True if there is a single possible value. Stored as [delayIndex]
	public final Cue[] 			delayCues;
	public final String[][] 	delayCueLabels;

	public final int			totalNumberOfObservableObjects;

	// Phenotype slot related arrays
	public final String[]		captiveSlotNames;					
	public final CaptiveSlot[] 	captiveSlots;
	public final String[]		delayedSlotNames;
	public final DelayedSlot[]	delayedSlots;
	public final String[]		recurringSlotNames;
	public final RecurringSlot	recurringSlots;
	
	// Patch related arrays
	public final int 			numberOfPatches;
	public final int			numberOfPatchStates;
	public final Patch[] 		patches;
	public final String[] 		patchNames;
	public final boolean[][] 	canMoveFromPatchToPatch;
	public final boolean[][] 	patchIsAccessibleFrom;
	public final PatchState[] 	patchStates;
	public final String[] 		patchStateNames;
	public final int[] 			patchStateIndexToPatchIndex;
	public final int			baseStateIndex;
	public final int			basePatchIndex;


	// Action related arrays
	// Note that there are four types of actions. Two
	// types can be taken by the agent during an action phase,
	// either when it is roaming (between encounters) or 
	// during an encounter (encounter actions). The third
	// type are the actions an environment 'takes' during the
	// mutation phase. Finally, a fourth set of action are
	// 'taken' by the environment during the first mutation
	// phase of an encounter (the setup rules)
	public final int 			numberOfRoamingActions,
								numberOfEncounterActions,
								numberOfMutationActions,
								numberOfSetupRules;
	public final Action[]		roamingAction;

	// Mutation related arrays
	public final StateMutator	stateMutator; // the class that handles all the mutations that affect the agent
	public final ObjectMutator	objectMutator; // the class that handles all the mutations that affect resources, delays, and extrinsic events
	public final Mutation[] mutations;
	
	// Death conditions
	public final GrimReaper grimReaper;
	public final DeathCondition[] deathConditions;
	
	// Experience related arrays
	public  boolean[]     	resourceIsObservable; // [resourceIndex]
	public  boolean[]     	resourceAtLeastOnePatchStateWhereLearnByExperience; // [resourceIndex]
	public  boolean[][]   	resourceLearnByExperienceInPatchState; // [resourceIndex][patchStateIndex]
	public  int[][][] 		resourceStartingExperiences; // [resourceIndex][patchStateIndex][resource value] -> prior count

	public  boolean[]    	extrinsicIsObservable; // [resourceIndex]
	public  boolean[]     	extrinsicAtLeastOnePatchStateWhereLearnByExperience; // [resourceIndex]
	public  boolean[][]   	extrinsicLearnByExperienceInPatchState; // [resourceIndex][patchStateIndex]
	public  int[][][] 		extrinsicStartingExperiences; // [resourceIndex][patchStateIndex][resource value] -> prior count

	public  boolean[]     	interruptionIsObservable; // [resourceIndex]
	public  boolean[]     	interruptionAtLeastOnePatchStateWhereLearnByExperience; // [resourceIndex]
	public  boolean[][]   	interruptionLearnByExperienceInPatchState; // [resourceIndex][patchStateIndex]
	public  int[][][] 		interruptionStartingExperiences; // [resourceIndex][patchStateIndex][resource value] -> prior count

	public  boolean[]     	delayIsObservable; // [resourceIndex]
	public  boolean[]     	delayAtLeastOnePatchStateWhereLearnByExperience; // [resourceIndex]
	public  boolean[][]   	delayLearnByExperienceInPatchState; // [resourceIndex][patchStateIndex]
	public  int[][][]		delayStartingExperiences; // [resourceIndex][patchStateIndex][resource value] -> prior count

	
	// Fields we use for writing the results to disk
	public final RFunctionContainer[] resourceFunctionContainers;
	public final RFunctionContainer[] delayFunctionContainers;
	public final RFunctionContainer[] interruptionFunctionContainers;
	public final RFunctionContainer[] extrinsicFunctionContainers;
	
	
	/** Create a Ledger based on the LedgerFactory. All fields in the Ledger are final. However,
	 * that does not mean that nothing can change (although it should not). Specifically, entries
	 * in the arrays can still be changed. Making everything private and adding getters makes the
	 * code quite unreadable at other places. So, after creation, the user is recommended to 
	 * create another Ledger based on the same factory, and compare the two ledgers from time to
	 * time to check if anything changed. */
	public Ledger (LedgerFactory f, AbstractModel model) {
		this.model = model;


		/////////////////////////////////////
		////////////// Objects /////////////
		///////////////////////////////////
		//** Instantiate all phenotype arrays, and make all cloned NumberObjectSingle fields immutable
		numberOfNonAgePhenotypicDimensions = f.phenotypicDimensionNames.size();
		phenotypicDimensionNames 		= f.phenotypicDimensionNames.toArray(new String[f.phenotypicDimensionNames.size()]);
		phenotypicDimensionValues 	= new NumberObjectSingle[f.phenotypicDimensionValues.size()][];
		for (int i = 0; i < phenotypicDimensionValues.length; i++) {
			phenotypicDimensionValues[i] = new NumberObjectSingle[f.phenotypicDimensionValues.get(i).length];
			for (int j = 0; j < phenotypicDimensionValues[i].length; j++) {
				phenotypicDimensionValues[i][j] = f.phenotypicDimensionValues.get(i)[j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
				phenotypicDimensionValues[i][j].makeImmutable();
			}
		}
		phenotypicDimensionStepsize	= new NumberObjectSingle[numberOfNonAgePhenotypicDimensions];
		for (int i = 0; i < numberOfNonAgePhenotypicDimensions; i ++) {
			phenotypicDimensionStepsize[i] = f.phenotypicDimensionStepsize.get(i).toNumberObjectSingle(model.howToRepresentNumbers).clone();
			phenotypicDimensionStepsize[i].makeImmutable();
		}
		

		//Figure out where the 0's are. If there is no 0 for a phenotype:
		//  	- if all values are positive, register an Integer.MIN_VALUE
		// 		- if all values are negative, register an Integer.MAX_VALUE
		phenotypicDimensionZeroPoints = new int[numberOfNonAgePhenotypicDimensions];
		for (int p = 0; p < phenotypicDimensionZeroPoints.length; p++)
			if (phenotypicDimensionValues[p][0].largerThan(0))
				phenotypicDimensionZeroPoints[p] = Integer.MIN_VALUE;
			else if (phenotypicDimensionValues[p][phenotypicDimensionValues[p].length -1].smallerThan(0))
				phenotypicDimensionZeroPoints[p] = Integer.MAX_VALUE;
			else
				for (int v = 0; v < phenotypicDimensionValues[p].length; v++)
					if (phenotypicDimensionValues[p][v].equals(0))
						phenotypicDimensionZeroPoints[p] = v;


		//** Instantiate all resource arrays, and make all cloned NumberObjectSingle fields immutable, and tell the Cue's to become immutable too
		numberOfResourceTypes = f.resourceNames.size();
		resourceNames 		= f.resourceNames.toArray(new String[numberOfResourceTypes]);
		resourceValues 	= new NumberObjectSingle[f.resourceValues.size()][];
		for (int i = 0; i < resourceValues.length; i++) {
			resourceValues[i] = new NumberObjectSingle[f.resourceValues.get(i).length];
			for (int j = 0; j < resourceValues[i].length; j++) {
				resourceValues[i][j] = f.resourceValues.get(i)[j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
				resourceValues[i][j].makeImmutable();
			}
		}
		resourceStepsize	= new NumberObjectSingle[numberOfResourceTypes];
		for (int i = 0; i < numberOfResourceTypes; i ++) {
			resourceStepsize[i] = f.resourceStepsize.get(i).toNumberObjectSingle(model.howToRepresentNumbers).clone();
			resourceStepsize[i].makeImmutable();
		}
		
		//Figure out where the 0's are. If there is no 0 for a resource:
		//  	- if all values are positive, register an Integer.MIN_VALUE
		// 		- if all values are negative, register an Integer.MAX_VALUE
		resourceZeroPoints = new int[numberOfResourceTypes];
		for (int p = 0; p < resourceZeroPoints.length; p++) 
			if (resourceValues[p][0].largerThan(0))
				resourceZeroPoints[p] = Integer.MIN_VALUE;
			else if (resourceValues[p][resourceValues[p].length -1].smallerThan(0))
				resourceZeroPoints[p] = Integer.MAX_VALUE;
			else
				for (int v = 0; v < resourceValues[p].length; v++)
					if (resourceValues[p][v].equals(0))
						resourceZeroPoints[p] = v;
		// Figure out the conversion rates: how many units of phenotype to one unit of resource?
		conversionResourceToPhenotype = new int[numberOfResourceTypes][numberOfNonAgePhenotypicDimensions];
		for (int r = 0; r < numberOfResourceTypes; r++)
			for (int p = 0; p < numberOfNonAgePhenotypicDimensions; p++) {
				if (phenotypicDimensionStepsize[p].abs().largerThan(resourceStepsize[r].abs()))
					if (this.resourceValues[r].length > 1 ) // i.e., the resource is not constant
						throw new IllegalStateException("Phenotype step size of phenotype [" + p + "] (SS=" + phenotypicDimensionStepsize[p].toStringWithoutTrailingZeros()+ ") is larger than the resource step size of resource [" + r+ "] (SS=" + resourceStepsize[r].toStringWithoutTrailingZeros() + ")");
				conversionResourceToPhenotype[r][p] = resourceStepsize[r].divide(phenotypicDimensionStepsize[p], false).toInt(RoundingMode.HALF_EVEN); // = STEPSIZEresource / STEPSIZEphenotype
			}
		
		// Set the cues, and make them immutable (note: we use deep clones to make sure that the ledger and cold storage ledger are independent)
		resourceCues = new Cue[numberOfResourceTypes];
		for (int i = 0; i < resourceCues.length; i++)
			if (f.resourceCues.get(i) != null) {
				resourceCues[i] = new Cue(f.resourceCues.get(i));
				resourceCues[i].makeImmutable();
			} 
		resourceCueLabels = new String[numberOfResourceTypes][];
		for (int i = 0; i < numberOfResourceTypes; i++)
			resourceCueLabels[i] = f.resourceCueLabels.get(i);


		//** Instantiate all extrinsic arrays, and make all cloned NumberObjectSingle fields immutable
		numberOfExtrinsicTypes = f.extrinsicNames.size();
		extrinsicNames 		= f.extrinsicNames.toArray(new String[numberOfExtrinsicTypes]);
		extrinsicValues 	= new NumberObjectSingle[f.extrinsicValues.size()][];
		for (int i = 0; i < extrinsicValues.length; i++) {
			extrinsicValues[i] = new NumberObjectSingle[f.extrinsicValues.get(i).length];
			for (int j = 0; j < extrinsicValues[i].length; j++) {
				extrinsicValues[i][j] = f.extrinsicValues.get(i)[j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
				extrinsicValues[i][j].makeImmutable();
			}
		}
		extrinsicStepsize	= new NumberObjectSingle[numberOfExtrinsicTypes];
		for (int i = 0; i < numberOfExtrinsicTypes; i ++) {
			extrinsicStepsize[i] = f.extrinsicStepsize.get(i).toNumberObjectSingle(model.howToRepresentNumbers).clone();
			extrinsicStepsize[i].makeImmutable();
		}
		
		//Figure out at what (hypothetical) index position the 0's are - or should be, if we continue the sequence.
		extrinsicZeroPoints = new int[numberOfExtrinsicTypes];
		for (int e = 0; e < extrinsicZeroPoints.length; e++) 
			// Is 0 in the existing sequence?
			
			// If the lowest extrinsic value is higher than 0, we have an all-positive
			// sequence, with no 0. If so, figure out how many step sizes are in the
			// lowest positive value. The 0 is then at the [-number of stepsize] index.
			if (extrinsicValues[e][0].largerThan(0)) {
				// How many times to we have to multiple the stepsize to get to the smallest value in the array?
				NumberObjectSingle ss = this.extrinsicStepsize[e];
				int times = 0;
				while (ss.multiply(times, false).equals(extrinsicValues[e][0], true))
					times++;
				
				// The zero point is now the negative of times
				extrinsicZeroPoints[e] = -1*times;			
			}
		
			// Similarly, if the largest extrinsic value is smaller than 0, we have an all-negative
			// sequence. Now the question is: how often do we have to add the step size to the largest
			// value before we reach 0?
			else if (extrinsicValues[e][extrinsicValues[e].length -1].smallerThan(0)) {
				NumberObjectSingle largestValue = extrinsicValues[e][extrinsicValues[e].length -1];
				NumberObjectSingle ss = this.extrinsicStepsize[e];
				int times = 0;
				while (!largestValue.add( ss.multiply(times, false)   , false).equals(0, true)) 
					times ++;
					
				
				// The zero point is now the index position of the largest value plus the number of times we have to multiple the stepsize
				extrinsicZeroPoints[e] = extrinsicValues[e].length -1 + times;
			}
		
			// Finally, if the 0 is in the range of the values, then figure out the exact index posiiton
			else
				for (int v = 0; v < extrinsicValues[e].length; v++)
					if (extrinsicValues[e][v].equals(0))
						extrinsicZeroPoints[e] = v;
		
		// Figure out the conversion rates: how many units of phenotype to one unit of resource?
		conversionExtrinsicToPhenotype = new int[numberOfExtrinsicTypes][numberOfNonAgePhenotypicDimensions];
		for (int e = 0; e < numberOfExtrinsicTypes; e++)
			for (int p = 0; p < numberOfNonAgePhenotypicDimensions; p++) {
				if (phenotypicDimensionStepsize[p].abs().largerThan(extrinsicStepsize[e].abs()))
					if (this.extrinsicValues[e].length > 1 ) // i.e., the extrinsic is not constant
						throw new IllegalStateException("Phenotype step size of phenotype [" + p + "] (SS=" + phenotypicDimensionStepsize[p].toStringWithoutTrailingZeros()+ ") is larger than the step size of extrinsic [" + e+ "] (SS=" + extrinsicStepsize[e].toStringWithoutTrailingZeros() + ")");
				conversionExtrinsicToPhenotype[e][p] = extrinsicStepsize[e].divide(phenotypicDimensionStepsize[p], false).toInt(RoundingMode.HALF_EVEN) ; // = STEPSIZEextrinsic / STEPSIZEphenotype
			}
		
		
		
		//** Instantiate all interruption arrays, and make all cloned NumberObjectSingle fields immutable
		numberOfInterruptionTypes= f.interruptionNames.size();
		interruptionNames 		= f.interruptionNames.toArray(new String[f.interruptionNames.size()]);
		interruptionValues = new NumberObjectSingle[] {NumberObject.createNumber(model.howToRepresentNumbers, 0), NumberObject.createNumber(model.howToRepresentNumbers, 1)};
		for (NumberObjectSingle n : interruptionValues)
			n.makeImmutable();
		
		// Set the cues, and make them immutable (note: we use deep clones to make sure that the ledger and cold storage ledger are independent)
		interruptionCues = new Cue[numberOfInterruptionTypes];
		for (int i = 0; i < interruptionCues.length; i++)
			if (f.interruptionCues.get(i) != null) {
				interruptionCues[i] = new Cue(f.interruptionCues.get(i));
				interruptionCues[i].makeImmutable();
			} 
		interruptionCueLabels = new String[numberOfInterruptionTypes][];
		for (int i = 0; i < numberOfInterruptionTypes; i++)
			interruptionCueLabels[i] = f.interruptionCueLabels.get(i);
		
		
		
		//** Instantiate all delay arrays, and make all cloned NumberObjectSingle fields immutable
		numberOfDelayTypes= f.delayNames.size();
		delayNames 		= f.delayNames.toArray(new String[f.delayNames.size()]);
		delayValues 	= new int[numberOfDelayTypes][];
		for (int i = 0; i < delayValues.length; i++) {
			delayValues[i] = new int[f.delayValues.get(i).length];
			for (int j = 0; j < delayValues[i].length; j++) 
				delayValues[i][j] = f.delayValues.get(i)[j].intValue();
		}
		// Set the cues, and make them immutable (note: we use deep clones to make sure that the ledger and cold storage ledger are independent)
		delayCues = new Cue[numberOfDelayTypes];
		for (int i = 0; i < delayCues.length; i++)
			if (f.delayCues.get(i) != null) {
				delayCues[i] = new Cue(f.delayCues.get(i));
				delayCues[i].makeImmutable();
			} 
		delayCueLabels = new String[numberOfDelayTypes][];
		for (int i = 0; i < numberOfDelayTypes; i++)
			delayCueLabels[i] = f.delayCueLabels.get(i);

		/////////////////////////////////////
		////////////// Patches /////////////
		///////////////////////////////////
		numberOfPatches = f.patches.size();
		numberOfPatchStates = f.patchStateNames.size();
		patches = new Patch[numberOfPatches];
		for (int i = 0; i < patches.length; i++)
			patches[i] = new Patch(f.patches.get(i));

		patchNames = f.patchNames.toArray(new String[numberOfPatches]);
		canMoveFromPatchToPatch 	= new boolean[numberOfPatches][numberOfPatches];
		patchIsAccessibleFrom 		= new boolean[numberOfPatches][numberOfPatches];
		for (int r = 0; r < numberOfPatches; r++)
			for (int c = 0; c < numberOfPatches; c++) {
				boolean travel = f.canMoveFromPatchToPatch[r][c].booleanValue();
				canMoveFromPatchToPatch[r][c] = travel;
				patchIsAccessibleFrom[c][r] = travel;
			}
		patchStates = new PatchState[numberOfPatchStates];
		for (int i = 0; i < patchStates.length; i++)
			patchStates[i] = new PatchState(f.patchStates.get(i));
		patchStateNames = f.patchStateNames.toArray(new String[numberOfPatchStates]);
		patchStateIndexToPatchIndex = new int[numberOfPatchStates];
		
		for (int i = 0; i < numberOfPatchStates; i++)
			patchStateIndexToPatchIndex[i] = patchStates[i].ledgerIndexOfPatch;
		this.baseStateIndex = f.baseStateIndex;
		this.basePatchIndex = f.basePatchIndex;
		
		/////////////////////////////////////
		////////////// Actions /////////////
		///////////////////////////////////
		// Note: actions only have final fields (except for the isComplete). All objects within an action
		// (preconditions and postconditions) likewise only have final fields. Hence, no need to clone actions
		numberOfT1Actions = f.t1Actions.size();
		t1Actions = f.t1Actions.toArray( new T1Action[numberOfT1Actions]);
		t1ActionNames = f.t1ActionNames.toArray(new String[numberOfT1Actions]);
		for (T1Action action: t1Actions)
			action.setPostconditions(this);
		
		numberOfT2Actions = f.t2Actions.size();
		t2Actions = f.t2Actions.toArray( new T2Action[numberOfT2Actions]);
		t2ActionNames = f.t2ActionNames.toArray(new String[numberOfT2Actions]);
		
		
		/////////////////////////////////////////////
		////////////// Mutations/Death /////////////
		///////////////////////////////////////////
		// Note: as with actions, mutations and death conditions only have final fields . All objects within. No need to clone them
		this.mutations = f.mutations.toArray( new Mutation[f.mutations.size()]);
		this.stateMutator = new StateMutator(model, this);
		this.objectMutator = f.objectMutator;
		
		this.deathConditions = f.deathConditions.toArray( new DeathCondition[f.deathConditions.size()]);
		this.grimReaper = new GrimReaper(this);
		
		///////////////////////////////////////////////
		////////////// Prior experiences /////////////
		/////////////////////////////////////////////
		resourceIsObservable = new boolean[numberOfResourceTypes];
		resourceAtLeastOnePatchStateWhereLearnByExperience = new boolean[numberOfResourceTypes];
		for (int i = 0; i < numberOfResourceTypes; i ++) {
			resourceIsObservable[i] = f.resourceIsObservable.get(i).booleanValue();
			resourceAtLeastOnePatchStateWhereLearnByExperience[i] = f.resourceAtLeastOnePatchStateWhereLearnByExperience.get(i).booleanValue();
		}
		resourceLearnByExperienceInPatchState = new boolean[numberOfResourceTypes][];
		for (int i = 0; i < numberOfResourceTypes; i ++) {
			resourceLearnByExperienceInPatchState[i] = new boolean[f.resourceLearnByExperienceInPatchState.get(i).size()];
			for (int j = 0; j < f.resourceLearnByExperienceInPatchState.get(i).size(); j++)
				resourceLearnByExperienceInPatchState[i][j] = f.resourceLearnByExperienceInPatchState.get(i).get(j).booleanValue();
		}
		resourceStartingExperiences = new int[numberOfResourceTypes][][];
		for (int i = 0; i < numberOfResourceTypes; i ++) {
			if (resourceAtLeastOnePatchStateWhereLearnByExperience[i]) {
				resourceStartingExperiences[i] = new int[numberOfPatchStates][];
				for (int j = 0; j < numberOfPatchStates; j++) {
					resourceStartingExperiences[i][j] = new int[resourceValues[i].length];
					if (resourceLearnByExperienceInPatchState[i][j])
						for (int k = 0; k < resourceValues[i].length; k++) 
							resourceStartingExperiences[i][j][k] = f.resourceStartingExperiences.get(i).get(j).get(k).intValue();
				}	
			}
		}

		
		interruptionIsObservable = new boolean[numberOfInterruptionTypes];
		interruptionAtLeastOnePatchStateWhereLearnByExperience = new boolean[numberOfInterruptionTypes];
		for (int i = 0; i < numberOfInterruptionTypes; i ++) {
			interruptionIsObservable[i] = f.interruptionIsObservable.get(i).booleanValue();
			interruptionAtLeastOnePatchStateWhereLearnByExperience[i] = f.interruptionAtLeastOnePatchStateWhereLearnByExperience.get(i).booleanValue();
		}
		interruptionLearnByExperienceInPatchState = new boolean[numberOfInterruptionTypes][];
		for (int i = 0; i < numberOfInterruptionTypes; i ++) {
			interruptionLearnByExperienceInPatchState[i] = new boolean[f.interruptionLearnByExperienceInPatchState.get(i).size()];
			for (int j = 0; j < f.interruptionLearnByExperienceInPatchState.get(i).size(); j++)
				interruptionLearnByExperienceInPatchState[i][j] = f.interruptionLearnByExperienceInPatchState.get(i).get(j).booleanValue();
		}
		interruptionStartingExperiences = new int[numberOfInterruptionTypes][][];
		for (int i = 0; i < numberOfInterruptionTypes; i ++) {
			if (interruptionAtLeastOnePatchStateWhereLearnByExperience[i]) {
				interruptionStartingExperiences[i] = new int[numberOfPatchStates][];
				for (int j = 0; j < numberOfPatchStates; j++) {
					interruptionStartingExperiences[i][j] = new int[2];
					if (interruptionLearnByExperienceInPatchState[i][j])
						for (int k = 0; k < 2; k++) 
							interruptionStartingExperiences[i][j][k] = f.interruptionStartingExperiences.get(i).get(j).get(k).intValue();
				}	
			}
		}
		
		
		delayIsObservable = new boolean[numberOfDelayTypes];
		delayAtLeastOnePatchStateWhereLearnByExperience = new boolean[numberOfDelayTypes];
		for (int i = 0; i < numberOfDelayTypes; i ++) {
			delayIsObservable[i] = f.delayIsObservable.get(i).booleanValue();
			delayAtLeastOnePatchStateWhereLearnByExperience[i] = f.delayAtLeastOnePatchStateWhereLearnByExperience.get(i).booleanValue();
		}
		delayLearnByExperienceInPatchState = new boolean[numberOfDelayTypes][];
		for (int i = 0; i < numberOfDelayTypes; i ++) {
			delayLearnByExperienceInPatchState[i] = new boolean[f.delayLearnByExperienceInPatchState.get(i).size()];
			for (int j = 0; j < f.delayLearnByExperienceInPatchState.get(i).size(); j++)
				delayLearnByExperienceInPatchState[i][j] = f.delayLearnByExperienceInPatchState.get(i).get(j).booleanValue();
		}
		delayStartingExperiences = new int[numberOfDelayTypes][][];
		for (int i = 0; i < numberOfDelayTypes; i ++) {
			if (delayAtLeastOnePatchStateWhereLearnByExperience[i]) {
				delayStartingExperiences[i] = new int[numberOfPatchStates][];
				for (int j = 0; j < numberOfPatchStates; j++) {
					delayStartingExperiences[i][j] = new int[delayValues[i].length];
					if (delayLearnByExperienceInPatchState[i][j])
						for (int k = 0; k < delayValues[i].length; k++) 
							delayStartingExperiences[i][j][k] = f.delayStartingExperiences.get(i).get(j).get(k).intValue();
				}	
			}
		}
		
		extrinsicIsObservable = new boolean[numberOfExtrinsicTypes];
		extrinsicAtLeastOnePatchStateWhereLearnByExperience = new boolean[numberOfExtrinsicTypes];
		for (int i = 0; i < numberOfExtrinsicTypes; i ++) {
			extrinsicIsObservable[i] = f.extrinsicIsObservable.get(i).booleanValue();
			extrinsicAtLeastOnePatchStateWhereLearnByExperience[i] = f.extrinsicAtLeastOnePatchStateWhereLearnByExperience.get(i).booleanValue();
		}
		extrinsicLearnByExperienceInPatchState = new boolean[numberOfExtrinsicTypes][];
		for (int i = 0; i < numberOfExtrinsicTypes; i ++) {
			extrinsicLearnByExperienceInPatchState[i] = new boolean[f.extrinsicLearnByExperienceInPatchState.get(i).size()];
			for (int j = 0; j < f.extrinsicLearnByExperienceInPatchState.get(i).size(); j++)
				extrinsicLearnByExperienceInPatchState[i][j] = f.extrinsicLearnByExperienceInPatchState.get(i).get(j).booleanValue();
		}
		extrinsicStartingExperiences = new int[numberOfExtrinsicTypes][][];
		for (int i = 0; i < numberOfExtrinsicTypes; i ++) {
			if (extrinsicAtLeastOnePatchStateWhereLearnByExperience[i]) {
				extrinsicStartingExperiences[i] = new int[numberOfPatchStates][];
				for (int j = 0; j < numberOfPatchStates; j++) {
					extrinsicStartingExperiences[i][j] = new int[extrinsicValues[i].length];
					if (extrinsicLearnByExperienceInPatchState[i][j])
						for (int k = 0; k < extrinsicValues[i].length; k++) 
							extrinsicStartingExperiences[i][j][k] = f.extrinsicStartingExperiences.get(i).get(j).get(k).intValue();
				}	
			}
		}
		
		
		// Count the total number of observable resources
		int temp = 0;
		for (int r = 0; r < this.resourceIsObservable.length; r++)
			if (resourceIsObservable[r])
				temp++;
		for (int d = 0; d < this.delayIsObservable.length; d++)
			if (delayIsObservable[d])
				temp++;
		for (int i = 0; i < this.interruptionIsObservable.length; i++)
			if (interruptionIsObservable[i])
				temp++;
		totalNumberOfObservableObjects = temp;
		
		
		
		// Fields we use for writing the results to disk
		resourceFunctionContainers = new RFunctionContainer[numberOfResourceTypes];
		delayFunctionContainers = new RFunctionContainer[numberOfDelayTypes];
		interruptionFunctionContainers = new RFunctionContainer[numberOfInterruptionTypes];
		extrinsicFunctionContainers = new RFunctionContainer[numberOfExtrinsicTypes];
		
		for (int i = 0; i < numberOfResourceTypes; i++) resourceFunctionContainers[i] = f.resourceFunctionContainers.get(i);
		for (int i = 0; i < numberOfDelayTypes; i++) delayFunctionContainers[i] = f.delayFunctionContainers.get(i);
		for (int i = 0; i < numberOfInterruptionTypes; i++) interruptionFunctionContainers[i] = f.interruptionFunctionContainers.get(i);
		for (int i = 0; i < numberOfExtrinsicTypes; i++) extrinsicFunctionContainers[i] = f.extrinsicFunctionContainers.get(i);
		
	}


	/** <pre> Returns the index position of the named non-age phenotype. During runtime, we do not 
	 * use the name of a phenotype. Rather, we use integer values that represents each 
	 * phenotype. An agent's phenotype is represented with an n dimensional array,
	 * where n is the number of non-age phenotypic dimensions in this model. This array 
	 * contains integer values, which represent the 'integerized' values of these dimensions. 
	 * 
	 * An example might be useful. Suppose that in our model there are two non-age 
	 * phenotypic dimensions, 'health' and 'number of children'. The 'health' dimension 
	 * has values that are multiples of 0.5, running from -1 to 5. The 'number of 
	 * children' dimension has integer values, from 0 to 7. In this model we represent 
	 * an agent's phenotypic state with two integer values, corresponding to 'health' 
	 * and 'number of children', respectively. For instance, an agent might have a 
	 * phenotype of [2,5]. This means that an agent's health is the second value in 
	 * the range of possible health values. In this case a health of index 0=-1; 
	 * index 1=-0.5; index 2=0, so a health of 0. Similarly, its number of children 
	 * is the 5th possible value of all possible number of children. In this case 
	 * index 0=0 children; index 1=1 child; ..., index 5 = 5 children.
	 * 
	 * Using this manner of storing values speeds ups performance, and increases
	 * accuracy (always nice if we can eat our cake and have it too). However, 
	 * it does mean we need to figure out which phenotype is at which index position. 
	 * That's what this function does: given a name, it returns the index position in 
	 * the n dimensional array of integers.
	 * 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfPhenotype(String phenotypeName){
		for (int i = 0; i < phenotypicDimensionNames.length; i++)
			if (phenotypicDimensionNames[i].equals(phenotypeName))
				return i;
		throw new IllegalArgumentException("Phenotype of name \"" + phenotypeName + "\" is not registered in this ledger.");
	}
	
	/** <pre> Returns the index position of the named resource type. During runtime, we do not 
	 * use the name of a resource type. Rather, we use integer values that represents each 
	 * resource type. 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfResourceType(String resourceName){
		for (int i = 0; i < resourceNames.length; i++)
			if (resourceNames[i].equals(resourceName))
				return i;
		throw new IllegalArgumentException("Resource type \"" + resourceName + "\" is not registered in this ledger.");
	}
	

	/** <pre> Returns the index position of the named delay type. During runtime, we do not 
	 * use the name of a delay type. Rather, we use integer values that represents each 
	 * delay type. 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfDelayType(String delayName){
		for (int i = 0; i < delayNames.length; i++)
			if (delayNames[i].equals(delayName))
				return i;
		throw new IllegalArgumentException("Delay type \"" + delayName + "\" is not registered in this ledger.");
	}

	/** <pre> Returns the index position of the named interruption type. During runtime, we do not 
	 * use the name of a interruption type. Rather, we use integer values that represents each 
	 * interruption type. 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfInterruptionType(String interruptionName){
		for (int i = 0; i < interruptionNames.length; i++)
			if (interruptionNames[i].equals(interruptionName))
				return i;
		throw new IllegalArgumentException("Interruption type \"" + interruptionName + "\" is not registered in this ledger.");
	}
	
	/** <pre> Returns the index position of the named extrinsic event type. During runtime, we do not 
	 * use the name of a extrinsic event type. Rather, we use integer values that represents each 
	 * extrinsic event type. 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfExtrinsicType(String extrinsicName){
		for (int i = 0; i < extrinsicNames.length; i++)
			if (extrinsicNames[i].equals(extrinsicName))
				return i;
		throw new IllegalArgumentException("Extrinsic event type \"" + extrinsicName + "\" is not registered in this ledger.");
	}
	
	
	/** <pre> Returns the name associated with the phenotype at the index location.
	 * For instance, suppose a model has two phenotype dimensions: 'health' and 
	 * 'number of children'. If these are stored in the same order, then
	 * getNameOfPhenotypeIndex(0) returns 'health', 
	 * getNameOfPhenotypeIndex(1) returns 'numberOfChidren' (or something, no whitespace is allowed in the name)
	 * 
	 * All other values return null;
	 * */
	public String getNameOfPhenotypeIndex(int index){
		return phenotypicDimensionNames[index];
	}

	/** Returns the actual (user-provided) value of the phenotype at the specified index. */
	public NumberObjectSingle getValueOfPhenotype(int phenotypeIndex, int valueIndex) {
		return this.phenotypicDimensionValues[phenotypeIndex][valueIndex];
	}

	/** Returns the actual (user-provided) value of the resource at the specified index. */
	public NumberObjectSingle getValueOfResource(int resourceIndex, int valueIndex) {
		return this.resourceValues[resourceIndex][valueIndex];
	}

	
	/** Returns the actual (user-provided) value of the delay at the specified index. */
	public int getValueOfDelay(int delayIndex, int valueIndex) {
		return this.delayValues[delayIndex][valueIndex];
	}

	/** Returns the index position of the phenotype's value in the array that stores all phenotype values.
	 * Returns -1 if no such value exists.*/
	public int getIndexOfPhenotypeValue(int phenotypeIndex, NumberObjectSingle value) {
		for (int i = 0; i < phenotypicDimensionValues[phenotypeIndex].length; i++)
			if (value.equals(phenotypicDimensionValues[phenotypeIndex][i]))
				return i;
		return -1;
	}


	/** Can an agent move directly between the patch with index1 and the patch with index2?*/
	public boolean canTravelBetween(int patchIndex1, int patchIndex2) {
		return canMoveFromPatchToPatch[patchIndex1][patchIndex2];
	}


	/** <pre > Returns the index position of the PatchState with that name. During runtime we
	 * do not use patches, states in a patch, or names directly. Rather, we only care about
	 * PatchStates (each state in each patch is its own patch states). Rather than using the
	 * name of that PatchState, we only use integer values to represent the patch state. An
	 * example might help. Suppose that there are 2 patches ('Base patch' and 'Nice patch'),
	 * each having two states ('Base state' and 'Unknown state'). Rather than using PatchStates
	 * nested in States (as in the View), we create four different PatchStates:
	 * 
	 * 0. Base patch - base state
	 * 1. Base patch - unknown state
	 * 2. Nice patch - base state
	 * 3. Nice patch - unknown state
	 * 
	 * Rather than keep having to refer to these PatchStates by name, we use their integer number.
	 * However, we use integer values at two different places. First, when we have to figure out
	 * which state belongs to which patch (local indexing). Second, when we need to figure out 
	 * to which PatchState we might go to when moving (global indexing). For the former we need 
	 * to count each patch state per patch, starting at 0. However, in the latter case we have to
	 * know which state we can go to directly. Here we need to keep track of a single integer value
	 * that can point to all possible states (i.e., all states are in a single array). To keep 
	 * things 'easy', we'll keep track of both local and global indexing separately. 
	 * 
	 * The Ledger keeps track of which index belongs to which PatchState. This function returns 
	 * the GLOBAL index (i.e., all PatchStates are in 1 array). The local index is stored within 
	 * each patch separately. 
	 * */
	public int getIndexOfPatchState(String patchName, String patchStateName){
		return 0;
	}

	/** <pre > Returns the name of the PatchState stored at the GLOBAL index position. During runtime we
	 * do not use patches, states in a patch, or names directly. Rather, we only care about
	 * PatchStates (each state in each patch is its own patch states). Rather than using the
	 * name of that PatchState, we only use integer values to represent the patch state. An
	 * example might help. Suppose that there are 2 patches ('Base patch' and 'Nice patch'),
	 * each having two states ('Base state' and 'Unknown state'). Rather than using PatchStates
	 * nested in States (as in the View), we create four different PatchStates:
	 * 
	 * 0. Base patch - base state
	 * 1. Base patch - unknown state
	 * 2. Nice patch - base state
	 * 3. Nice patch - unknown state
	 * 
	 * Rather than keep having to refer to these PatchStates by name, we use their integer number.
	 * However, we use integer values at two different places. First, when we have to figure out
	 * which state belongs to which patch (local indexing). Second, when we need to figure out 
	 * to which PatchState we might go to when moving (global indexing). For the former we need 
	 * to count each patch state per patch, starting at 0. However, in the latter case we have to
	 * know which state we can go to directly. Here we need to keep track of a single integer value
	 * that can point to all possible states (i.e., all states are in a single array). To keep 
	 * things 'easy', we'll keep track of both local and global indexing separately. 
	 * 
	 * The Ledger keeps track of which index belongs to which PatchState. This function returns
	 * the name of the patch state at the GLOBAL index (i.e., where all PatchStates of all patches
	 * are in 1 array). The local index is stored in each patch separately. 
	 * */
	public String getGlobalNameOfPatchState(int patchStateIndex){
		return null;
	}

	/** Returns the index position of the resource's value in the array that stores all resource values.
	 * Returns -1 if no such value exists.*/
	public int getIndexOfResourceValue(int resourceIndex, NumberObjectSingle value) {
		for (int i = 0; i < resourceValues[resourceIndex].length; i++)
			if (value.equals(resourceValues[resourceIndex][i]))
				return i;
		return -1;
	}

	/** If we were to use 'normal' numbers, adding a resource's value to a phenotype is easy. However,
	 * we don't work with normal values. Instead, everything is listed as indices in arrays. The naive 
	 * ways to now add a resource to a phenotype is to A) retrieve the value of the resource,
	 * B) retrieve the value of the phenotype, C) add the former to the latter, and D) find the index 
	 * of the new value in the array. This is a long, and rather convoluted process. 
	 * 
	 * But we can go an easier route! After construction, the ledger already knows how many index values 
	 * of a phenotype dimension a resource is worth (i.e., adding a single stepsize of the resource to a phenotype increases 
	 * the phenotype with x stepsizes of that phenotype). Hence, we only need to now how many units (i.e.,
	 * stepsizes the resource's value is (which can be negative), convert that to the number of index positions
	 * that the phenotype has to shift, and apply that shift to the phenotype (making sure that the phenotype
	 * never goes out of bounds)*/
	public int indexOfPhenotypeAfterAddingResource(int phenotypeIndex, int phenotypeCurrentValueIndex, int resourceIndex, int resourceValueIndex){
		// Figure out how many stepsizes this resource is. That is, how often do have to multiply the resource stepsizes
		// to get to this resource value? For this we can use the 0 point that we have stored for that resource
		int zeroPoint = this.resourceZeroPoints[resourceIndex];
		int resourceStepsizes = resourceValueIndex - zeroPoint;
		
		// Compute how many units of the phenotype this resource amounts too
		int shiftInPhenotype = this.conversionResourceToPhenotype[resourceIndex][phenotypeIndex] * resourceStepsizes;
		
		// Add this to the phenotypeCurrentValueIndex
		int shiftedPhenotypeValueIndex = phenotypeCurrentValueIndex + shiftInPhenotype;
		
		// Make sure that the new value is in bounds - neither negative, nor larger than the length of the phenotype values
		if (shiftedPhenotypeValueIndex < 0)
			shiftedPhenotypeValueIndex = 0;
		else if (shiftedPhenotypeValueIndex >= this.phenotypicDimensionValues[phenotypeIndex].length)
			shiftedPhenotypeValueIndex = (phenotypicDimensionValues[phenotypeIndex].length-1);		
		return shiftedPhenotypeValueIndex;
	}

	/** If we were to use 'normal' numbers, adding an extrinsic event's value to a phenotype is easy. However,
	 * we don't work with normal values. Instead, everything is listed as indices in arrays. The naive 
	 * ways to now add an extrinsic event's to a phenotype is to A) retrieve the value of the extrinsic event,
	 * B) retrieve the value of the phenotype, C) add the former to the latter, and D) find the index 
	 * of the new value in the array. This is a long, and rather convoluted process. 
	 * 
	 * But we can go an easier route! After construction, the ledger already knows how many index values 
	 * of a phenotype dimension an extrinsic event is worth (i.e., adding an extrinsic event value of 1 stepsize to a phenotype increases 
	 * the phenotype with x stepsizes of that phenotype). Hence, we only need to now how many units (i.e.,
	 * stepsizes the extrinsic event's value is (which can be negative), convert that to the number of index positions
	 * that the phenotype has to shift, and apply that shift to the phenotype (making sure that the phenotype
	 * never goes out of bounds)*/
	public int indexOfPhenotypeAfterAddingExtrinsic(int phenotypeIndex, int phenotypeCurrentValueIndex, int extrinsicIndex, int extrinsicValueIndex){
		// Figure out how many stepsizes this extrinsic event's value is. That is, how often do have to multiply the extrinsic stepsizes
		// to get to this extrinsic value? For this we can use the 0 point that we have stored for that extrinsic event
	
		// If the extrinsicStepsizes[extrinsicIndex] == -1, the extrinsic has a fixed value. 
		int zeroPoint = this.extrinsicZeroPoints[extrinsicIndex];
		int extrinsicStepsizes = extrinsicValueIndex - zeroPoint;
		
		// Compute how many units of the phenotype this extrinsic amounts too
		int shiftInPhenotype = this.conversionExtrinsicToPhenotype[extrinsicIndex][phenotypeIndex] * extrinsicStepsizes;
		
		// Add this to the phenotypeCurrentValueIndex
		int shiftedPhenotypeValueIndex = phenotypeCurrentValueIndex + shiftInPhenotype;
		
		// Make sure that the new value is in bounds - neither negative, nor larger than the length of the phenotype values
		if (shiftedPhenotypeValueIndex < 0)
			shiftedPhenotypeValueIndex = 0;
		else if (shiftedPhenotypeValueIndex >= this.phenotypicDimensionValues[phenotypeIndex].length)
			shiftedPhenotypeValueIndex = phenotypicDimensionValues[phenotypeIndex].length-1;

		return shiftedPhenotypeValueIndex;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("----------------------------------------------");
		sb.append("\n------------------ Objects -------------------");
		sb.append("\n----------------------------------------------");

		sb.append("\n\n---------- Non-age phenotypes ----------");
		sb.append("\nThere are " + numberOfNonAgePhenotypicDimensions + " non-age phenotypic dimensions in this model.");
		sb.append("\nNames:   \n\t" + Helper.arrayToString(phenotypicDimensionNames));
		sb.append("\nValues:");
		if (phenotypicDimensionValues.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < phenotypicDimensionValues.length; i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayToString(phenotypicDimensionValues[i]));

		sb.append("\nStep size:" );
		if (phenotypicDimensionStepsize.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < phenotypicDimensionStepsize.length; i++)
			sb.append("\n\t[" + i + "]: " + phenotypicDimensionStepsize[i].toStringWithoutTrailingZeros());

	

		sb.append("\n\n\n\n---------- Resources ----------");
		sb.append("\nThere are " + numberOfResourceTypes + " resource types in this model.");
		sb.append("\nNames:  \n\t" + Helper.arrayToString(resourceNames));

		sb.append("\nValues:");
		if (resourceValues.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceValues.length; i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayToString(resourceValues[i]));

		sb.append("\nStep size:" );
		if (resourceStepsize.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceStepsize.length; i++)
			sb.append("\n\t[" + i + "]: " + resourceStepsize[i].toStringWithoutTrailingZeros());

		sb.append("\nZero points:");
		if (resourceZeroPoints.length == 0 ) sb.append("\n\t[]");
		for (int i = 0; i < resourceZeroPoints.length; i++)
			sb.append("\n\t[" + i + "]: " + resourceZeroPoints[i]);

		sb.append("\nResource to phenotype conversion rates (i.e., every 1 unit of a resource results in x increases in phenotype)");
		if (conversionResourceToPhenotype.length == 0) sb.append("\n\t[]");
		for (int r = 0; r < numberOfResourceTypes; r ++)
			for (int p = 0; p < this.numberOfNonAgePhenotypicDimensions; p++)
				sb.append("\n\tResource type [" + r + "] to phenotype ["+ p +"]: " +conversionResourceToPhenotype[r][p]);
		
		sb.append("\nResource observability:");
		if (resourceIsObservable.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceIsObservable.length; i ++)
			sb.append("\n\t[" + i + "]: " + resourceIsObservable[i]);
			
		sb.append("\nResource cue labels:");
		if (resourceValues.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceValues.length; i ++)
			if (resourceCueLabels[i] != null)
				sb.append("\n\t[" + i + "]: " + Helper.arrayToString(resourceCueLabels[i]));
			else 
				sb.append("\n\t[" + i + "]: null" );

		sb.append("\nResource cues:");
		for (int i = 0; i < resourceNames.length; i++)
			sb.append("\n\t[" + i + "]: " + resourceCues[i]);


		
		sb.append("\n\n\n\n---------- Interruptions ----------");
		sb.append("\nThere are " + numberOfInterruptionTypes + " interruption types in this model.");
		sb.append("\nNames:  \n\t" + Helper.arrayToString(interruptionNames));

		sb.append("\nInterruption observability:");
		if (interruptionIsObservable.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < interruptionIsObservable.length; i ++)
			sb.append("\n\t[" + i + "]: " + interruptionIsObservable[i]);
		
		sb.append("\nInterruption cue labels:");
		if (interruptionNames.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < interruptionNames.length; i ++)
			if (interruptionCueLabels[i] != null)
				sb.append("\n\t[" + i + "]: " + Helper.arrayToString(interruptionCueLabels[i]));
			else 
				sb.append("\n\t[" + i + "]: null" );

		sb.append("\nInterruption cues:");
		for (int i = 0; i < interruptionNames.length; i++)
			sb.append("\n\t[" + i + "]: " + interruptionCues[i]);




		sb.append("\n\n\n\n---------- Delays ----------");
		sb.append("\nThere are " + numberOfDelayTypes + " delay types in this model.");
		sb.append("\nNames:  \n\t" + Helper.arrayToString(delayNames));
		
		sb.append("\nValues:");
		if (delayValues.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < delayValues.length; i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayToString(delayValues[i]));

		sb.append("\nDelay observability:");
		if (delayIsObservable.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < delayIsObservable.length; i ++)
			sb.append("\n\t[" + i + "]: " + delayIsObservable[i]);
		
		sb.append("\nDelay cue labels:");
		if (delayNames.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < delayNames.length; i ++)
			if (delayCueLabels[i] != null)
				sb.append("\n\t[" + i + "]: " + Helper.arrayToString(delayCueLabels[i]));
			else 
				sb.append("\n\t[" + i + "]: null" );

		sb.append("\nDelay cues:");
		for (int i = 0; i < delayNames.length; i++)
			sb.append("\n\t[" + i + "]: " + delayCues[i]);

		
		
		sb.append("\n\n\n\n---------- Objects: other ----------");
		sb.append("\nIn total, there are "+totalNumberOfObservableObjects + " directly observable objects");

		
		
		sb.append("\n\n\n\n---------- Extrinsic events----------");
		sb.append("\nThere are " + numberOfExtrinsicTypes + " extrinsic event types in this model.");
		sb.append("\nNames:   \n\t" + Helper.arrayToString(extrinsicNames));
		
		sb.append("\nValues:");
		if (extrinsicValues.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < extrinsicValues.length; i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayToString(extrinsicValues[i]));

		sb.append("\nStep size:" );
		if (extrinsicStepsize.length == 0) sb.append("\n\t[]");
		for (int i = 0; i < extrinsicStepsize.length; i++)
			sb.append("\n\t[" + i + "]: " + extrinsicStepsize[i].toStringWithoutTrailingZeros());
		
		sb.append("\nZero points:");
		if (extrinsicZeroPoints.length == 0 ) sb.append("\n\t[]");
		for (int i = 0; i < extrinsicZeroPoints.length; i++)
			sb.append("\n\t[" + i + "]: " + extrinsicZeroPoints[i]);

		
		sb.append("\nExtrinsic to phenotype conversion rates (i.e., every 1 unit of an extrinsic event results in x increases in phenotype)");
		if (conversionExtrinsicToPhenotype.length == 0) sb.append("\n\t[]");
		for (int e = 0; e < numberOfExtrinsicTypes; e ++)
			for (int p = 0; p < this.numberOfNonAgePhenotypicDimensions; p++)
				sb.append("\n\tExtrinsic [" + e + "] to phenotype ["+ p +"]: " +conversionExtrinsicToPhenotype[e][p]);
		
		
		sb.append("\n\n\n\n\n\n\n\n\n\n----------------------------------------------");
		sb.append("\n---------- Patches and patch states ----------");
		sb.append("\n----------------------------------------------");
		sb.append("\nThis model contains " + patches.length + " patch(es):");
		for (int i = 0; i < patchNames.length; i++)
			sb.append("\n\t[" + i + "]: " + patchNames[i]);

		sb.append("\n\nTraversability matrix: is it possible to go from [row] to [column]?\n" + Helper.matrix2DToString(this.canMoveFromPatchToPatch));
		sb.append("\n\nAccessibility matrix:  can you reach [row] from [column] (inverse of above)?\n" + Helper.matrix2DToString(this.patchIsAccessibleFrom));
		
		sb.append("\nCombined over these patches, there are " + patchStates.length + " state(s):");
		for (int i = 0; i < patchStateNames.length; i++)
			sb.append("\n\t[" + i + "]: " + patchStateNames[i] + "  (in patch [" + patchStateIndexToPatchIndex[i] + "])");

		sb.append("\n\nPatches and patch states have the following order and offsets:");
		for (int i = 0; i < patches.length; i++)
			sb.append("\n\n\n\n+++" + patches[i].toString(this));
		sb.append("\nAgents start in patch [" + this.basePatchIndex + "] and patch state [" + this.baseStateIndex + "]");
		
		
		
		sb.append("\n\n\n\n\n\n\n\n\n\n\n----------------------------------------------");
		sb.append("\n---------- Actions and mutations ------------");
		sb.append("\n----------------------------------------------");
		sb.append("\n---------- T1 Actions (between encounters) ----------");
		for (int i = 0; i < this.t1Actions.length; i++)
			sb.append("\n\t["+i+"] \t'" + this.t1ActionNames[i] +"': \t"+ t1Actions[i]);
		
		sb.append("\n\n---------- T2 Actions (during encounters) ----------");
		for (int i = 0; i < this.t2Actions.length; i++)
			sb.append("\n\t["+i+"] \t'" + this.t2ActionNames[i] +"': \t"+ t2Actions[i]);
		
		sb.append("\n\n---------- Phenotype Mutations ----------");
		for (int i = 0; i < this.mutations.length; i++)
			sb.append("\n\t["+i+"] \t" + this.mutations[i]);
		
		sb.append("\n\n---------- Object Mutatior  ----------");
		sb.append(this.objectMutator);
		
		
		sb.append("\n\n---------- Death conditions ----------");
		for (int i = 0; i < this.deathConditions.length; i++)
			sb.append("\n\t["+i+"] \t" + this.deathConditions[i]);
		
		
		
		sb.append("\n\n\n\n\n\n\n\n\n\n\n----------------------------------------------");
		sb.append("\n------------ Prior experiences --------------");
		sb.append("\n----------------------------------------------");
		sb.append("\n NOT IMPLEMENTED IN THIS VERSION");/*
		sb.append("\n---------- Resources ----------");
		for (int r = 0; r < this.numberOfResourceTypes; r++) {
			sb.append("\nResource ["+r+"] '" + resourceNames[r] + "':");
			sb.append("'\n\tObservable?               " + resourceIsObservable[r]);
			sb.append("\n\t>1 patch from experience? " + resourceAtLeastOnePatchStateWhereLearnByExperience[r]);
			if (resourceAtLeastOnePatchStateWhereLearnByExperience[r]) {
				sb.append("\n\tHas prior experiences in patch:");
				for (int p = 0; p < this.patchStates.length;p++) {
					sb.append("\n\t\t[" + p + "]: " + resourceLearnByExperienceInPatchState[r][p]);
					if (resourceLearnByExperienceInPatchState[r][p]) {
						sb.append(", namely: " );
						for (int v = 0; v < resourceStartingExperiences[r][p].length; v++)
							sb.append("\n\t\t\t["+v+"] ->"+resourceStartingExperiences[r][p][v]);
					}
				}
			}
		}
		
	
		sb.append("\n\n---------- Interruption ----------");
		for (int i = 0; i < this.numberOfInterruptionTypes; i++) {
			sb.append("\nInterruption ["+i+"] '" + interruptionNames[i] + "':");
			sb.append("'\n\tObservable?               " + interruptionIsObservable[i]);
			sb.append("\n\t>1 patch from experience? " + interruptionAtLeastOnePatchStateWhereLearnByExperience[i]);
			if (interruptionAtLeastOnePatchStateWhereLearnByExperience[i]) {
				sb.append("\n\tHas prior experiences in patch:");
				for (int p = 0; p < this.patchStates.length;p++) {
					sb.append("\n\t\t[" + p + "]: " + interruptionLearnByExperienceInPatchState[i][p]);
					if (interruptionLearnByExperienceInPatchState[i][p]) {
						sb.append(", namely: " );
						for (int v = 0; v < interruptionStartingExperiences[i][p].length; v++)
							sb.append("\n\t\t\t["+v+"] ->"+interruptionStartingExperiences[i][p][v]);
					}
				}
			}
		}
		
		sb.append("\n\n---------- Delay ----------");
		for (int i = 0; i < this.numberOfDelayTypes; i++) {
			sb.append("\nInterruption ["+i+"] '" + delayNames[i] + "':");
			sb.append("'\n\tObservable?               " + delayIsObservable[i]);
			sb.append("\n\t>1 patch from experience? " + delayAtLeastOnePatchStateWhereLearnByExperience[i]);
			if (delayAtLeastOnePatchStateWhereLearnByExperience[i]) {
				sb.append("\n\tHas prior experiences in patch:");
				for (int p = 0; p < this.patchStates.length;p++) {
					sb.append("\n\t\t[" + p + "]: " + delayLearnByExperienceInPatchState[i][p]);
					if (delayLearnByExperienceInPatchState[i][p]) {
						sb.append(", namely: " );
						for (int v = 0; v < delayStartingExperiences[i][p].length; v++)
							sb.append("\n\t\t\t["+v+"] ->"+delayStartingExperiences[i][p][v]);
					}
				}
			}
		}
		
		sb.append("\n\n---------- Extrinsic ----------");
		for (int i = 0; i < this.numberOfExtrinsicTypes; i++) {
			sb.append("\nInterruption ["+i+"] '" + extrinsicNames[i] + "':");
			sb.append("'\n\tObservable?               " + extrinsicIsObservable[i]);
			sb.append("\n\t>1 patch from experience? " + extrinsicAtLeastOnePatchStateWhereLearnByExperience[i]);
			if (extrinsicAtLeastOnePatchStateWhereLearnByExperience[i]) {
				sb.append("\n\tHas prior experiences in patch:");
				for (int p = 0; p < this.patchStates.length;p++) {
					sb.append("\n\t\t[" + p + "]: " + extrinsicLearnByExperienceInPatchState[i][p]);
					if (extrinsicLearnByExperienceInPatchState[i][p]) {
						sb.append(", namely: " );
						for (int v = 0; v < extrinsicStartingExperiences[i][p].length; v++)
							sb.append("\n\t\t\t["+v+"] ->"+extrinsicStartingExperiences[i][p][v]);
					}
				}
			}
		}
		
		*/
		return sb.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(canMoveFromPatchToPatch);
		result = prime * result + Arrays.deepHashCode(conversionExtrinsicToPhenotype);
		result = prime * result + Arrays.deepHashCode(conversionResourceToPhenotype);
		result = prime * result + Arrays.hashCode(deathConditions);
		result = prime * result + Arrays.hashCode(delayAtLeastOnePatchStateWhereLearnByExperience);
		result = prime * result + Arrays.deepHashCode(delayCueLabels);
		result = prime * result + Arrays.hashCode(delayCues);
		result = prime * result + Arrays.hashCode(delayIsObservable);
		result = prime * result + Arrays.deepHashCode(delayLearnByExperienceInPatchState);
		result = prime * result + Arrays.hashCode(delayNames);
		result = prime * result + Arrays.deepHashCode(delayStartingExperiences);
		result = prime * result + Arrays.deepHashCode(delayValues);
		result = prime * result + Arrays.hashCode(extrinsicAtLeastOnePatchStateWhereLearnByExperience);
		result = prime * result + Arrays.hashCode(extrinsicIsObservable);
		result = prime * result + Arrays.deepHashCode(extrinsicLearnByExperienceInPatchState);
		result = prime * result + Arrays.hashCode(extrinsicNames);
		result = prime * result + Arrays.deepHashCode(extrinsicStartingExperiences);
		result = prime * result + Arrays.hashCode(extrinsicStepsize);
		result = prime * result + Arrays.deepHashCode(extrinsicValues);
		result = prime * result + Arrays.hashCode(extrinsicZeroPoints);
		result = prime * result + Arrays.hashCode(interruptionAtLeastOnePatchStateWhereLearnByExperience);
		result = prime * result + Arrays.deepHashCode(interruptionCueLabels);
		result = prime * result + Arrays.hashCode(interruptionCues);
		result = prime * result + Arrays.hashCode(interruptionIsObservable);
		result = prime * result + Arrays.deepHashCode(interruptionLearnByExperienceInPatchState);
		result = prime * result + Arrays.hashCode(interruptionNames);
		result = prime * result + Arrays.deepHashCode(interruptionStartingExperiences);
		result = prime * result + Arrays.hashCode(interruptionValues);
		result = prime * result + Arrays.hashCode(mutations);
		result = prime * result + numberOfDelayTypes;
		result = prime * result + numberOfExtrinsicTypes;
		result = prime * result + numberOfInterruptionTypes;
		result = prime * result + numberOfNonAgePhenotypicDimensions;
		result = prime * result + numberOfPatchStates;
		result = prime * result + numberOfPatches;
		result = prime * result + numberOfResourceTypes;
		result = prime * result + numberOfT1Actions;
		result = prime * result + numberOfT2Actions;
		result = prime * result + Arrays.deepHashCode(patchIsAccessibleFrom);
		result = prime * result + Arrays.hashCode(patchNames);
		result = prime * result + Arrays.hashCode(patchStateIndexToPatchIndex);
		result = prime * result + Arrays.hashCode(patchStateNames);
		result = prime * result + Arrays.hashCode(patchStates);
		result = prime * result + Arrays.hashCode(patches);
		result = prime * result + Arrays.hashCode(phenotypicDimensionNames);
		result = prime * result + Arrays.hashCode(phenotypicDimensionStepsize);
		result = prime * result + Arrays.deepHashCode(phenotypicDimensionValues);
		result = prime * result + Arrays.hashCode(phenotypicDimensionZeroPoints);
		result = prime * result + Arrays.hashCode(resourceAtLeastOnePatchStateWhereLearnByExperience);
		result = prime * result + Arrays.deepHashCode(resourceCueLabels);
		result = prime * result + Arrays.hashCode(resourceCues);
		result = prime * result + Arrays.hashCode(resourceIsObservable);
		result = prime * result + Arrays.deepHashCode(resourceLearnByExperienceInPatchState);
		result = prime * result + Arrays.hashCode(resourceNames);
		result = prime * result + Arrays.deepHashCode(resourceStartingExperiences);
		result = prime * result + Arrays.hashCode(resourceStepsize);
		result = prime * result + Arrays.deepHashCode(resourceValues);
		result = prime * result + Arrays.hashCode(resourceZeroPoints);
		result = prime * result + Arrays.hashCode(t1ActionNames);
		result = prime * result + Arrays.hashCode(t1Actions);
		result = prime * result + Arrays.hashCode(t2ActionNames);
		result = prime * result + Arrays.hashCode(t2Actions);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Ledger other = (Ledger) obj;

		if (!Arrays.deepEquals(canMoveFromPatchToPatch, other.canMoveFromPatchToPatch)) {
			return false;
		}

		if (!Arrays.deepEquals(conversionExtrinsicToPhenotype, other.conversionExtrinsicToPhenotype)) {
			return false;
		}

		if (!Arrays.deepEquals(conversionResourceToPhenotype, other.conversionResourceToPhenotype)) {
			return false;
		}

		if (!Arrays.equals(deathConditions, other.deathConditions)) {
			return false;
		}

		if (!Arrays.equals(delayAtLeastOnePatchStateWhereLearnByExperience,
				other.delayAtLeastOnePatchStateWhereLearnByExperience)) {
			return false;
		}

		if (!Arrays.deepEquals(delayCueLabels, other.delayCueLabels)) {
			return false;
		}

		if (!Arrays.equals(delayCues, other.delayCues)) {
			return false;
		}

		if (!Arrays.equals(delayIsObservable, other.delayIsObservable)) {
			return false;
		}

		if (!Arrays.deepEquals(delayLearnByExperienceInPatchState, other.delayLearnByExperienceInPatchState)) {
			return false;
		}
		if (!Arrays.equals(delayNames, other.delayNames)) {
			return false;
		}
		if (!Arrays.deepEquals(delayStartingExperiences, other.delayStartingExperiences)) {
			return false;
		}
		if (!Arrays.deepEquals(delayValues, other.delayValues)) {
			return false;
		}
		if (!Arrays.equals(extrinsicAtLeastOnePatchStateWhereLearnByExperience,
				other.extrinsicAtLeastOnePatchStateWhereLearnByExperience)) {
			return false;
		}
		if (!Arrays.equals(extrinsicIsObservable, other.extrinsicIsObservable)) {
			return false;
		}
		if (!Arrays.deepEquals(extrinsicLearnByExperienceInPatchState, other.extrinsicLearnByExperienceInPatchState)) {
			return false;
		}

		if (!Arrays.equals(extrinsicNames, other.extrinsicNames)) {
			return false;
		}

		if (!Arrays.deepEquals(extrinsicStartingExperiences, other.extrinsicStartingExperiences)) {
			return false;
		}

		if (!Arrays.equals(extrinsicStepsize, other.extrinsicStepsize)) {
			return false;
		}

		if (!Arrays.deepEquals(extrinsicValues, other.extrinsicValues)) {
			return false;
		}

		if (!Arrays.equals(extrinsicZeroPoints, other.extrinsicZeroPoints)) {
			return false;
		}
		if (!Arrays.equals(interruptionAtLeastOnePatchStateWhereLearnByExperience,
				other.interruptionAtLeastOnePatchStateWhereLearnByExperience)) {
			return false;
		}

		if (!Arrays.deepEquals(interruptionCueLabels, other.interruptionCueLabels)) {
			return false;
		}
		if (!Arrays.equals(interruptionCues, other.interruptionCues)) {
			return false;
		}
		if (!Arrays.equals(interruptionIsObservable, other.interruptionIsObservable)) {
			return false;
		}
		if (!Arrays.deepEquals(interruptionLearnByExperienceInPatchState,
				other.interruptionLearnByExperienceInPatchState)) {
			return false;
		}
		if (!Arrays.equals(interruptionNames, other.interruptionNames)) {
			return false;
		}
		if (!Arrays.deepEquals(interruptionStartingExperiences, other.interruptionStartingExperiences)) {
			return false;
		}
		if (!Arrays.equals(interruptionValues, other.interruptionValues)) {
			return false;
		}
		if (!Arrays.equals(mutations, other.mutations)) {
			return false;
		}
		if (numberOfDelayTypes != other.numberOfDelayTypes) {
			return false;
		}
		if (numberOfExtrinsicTypes != other.numberOfExtrinsicTypes) {
			return false;
		}
		if (numberOfInterruptionTypes != other.numberOfInterruptionTypes) {
			return false;
		}
		if (numberOfNonAgePhenotypicDimensions != other.numberOfNonAgePhenotypicDimensions) {
			return false;
		}
		if (numberOfPatchStates != other.numberOfPatchStates) {
			return false;
		}
		if (numberOfPatches != other.numberOfPatches) {
			return false;
		}
		if (numberOfResourceTypes != other.numberOfResourceTypes) {
			return false;
		}
		if (numberOfT1Actions != other.numberOfT1Actions) {
			return false;
		}
		if (numberOfT2Actions != other.numberOfT2Actions) {
			return false;
		}
		if (!Arrays.deepEquals(patchIsAccessibleFrom, other.patchIsAccessibleFrom)) {
			return false;
		}
		if (!Arrays.equals(patchNames, other.patchNames)) {
			return false;
		}
		if (!Arrays.equals(patchStateIndexToPatchIndex, other.patchStateIndexToPatchIndex)) {
			return false;
		}
		if (!Arrays.equals(patchStateNames, other.patchStateNames)) {
			return false;
		}
		if (!Arrays.equals(patchStates, other.patchStates)) {
			return false;
		}
		if (!Arrays.equals(patches, other.patches)) {
			return false;
		}
		if (!Arrays.equals(phenotypicDimensionNames, other.phenotypicDimensionNames)) {
			return false;
		}
		if (!Arrays.equals(phenotypicDimensionStepsize, other.phenotypicDimensionStepsize)) {
			return false;
		}
		if (!Arrays.deepEquals(phenotypicDimensionValues, other.phenotypicDimensionValues)) {
			return false;
		}
		if (!Arrays.equals(phenotypicDimensionZeroPoints, other.phenotypicDimensionZeroPoints)) {
			return false;
		}
		if (!Arrays.equals(resourceAtLeastOnePatchStateWhereLearnByExperience,
				other.resourceAtLeastOnePatchStateWhereLearnByExperience)) {
			return false;
		}
		if (!Arrays.deepEquals(resourceCueLabels, other.resourceCueLabels)) {
			return false;
		}
		if (!Arrays.equals(resourceCues, other.resourceCues)) {
			return false;
		}
		if (!Arrays.equals(resourceIsObservable, other.resourceIsObservable)) {
			return false;
		}
		if (!Arrays.deepEquals(resourceLearnByExperienceInPatchState, other.resourceLearnByExperienceInPatchState)) {
			return false;
		}
		if (!Arrays.equals(resourceNames, other.resourceNames)) {
			return false;
		}
		if (!Arrays.deepEquals(resourceStartingExperiences, other.resourceStartingExperiences)) {
			return false;
		}
		if (!Arrays.equals(resourceStepsize, other.resourceStepsize)) {
			return false;
		}
		if (!Arrays.deepEquals(resourceValues, other.resourceValues)) {
			return false;
		}
		if (!Arrays.equals(resourceZeroPoints, other.resourceZeroPoints)) {
			return false;
		}
		if (!Arrays.equals(t1ActionNames, other.t1ActionNames)) {
			return false;
		}
		if (!Arrays.equals(t1Actions, other.t1Actions)) {
			return false;
		}
		
		if (!Arrays.equals(t2ActionNames, other.t2ActionNames)) {
			return false;
		}
		if (!Arrays.equals(t2Actions, other.t2Actions)) {
			return false;
		}
		return true;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////// Function used to convert ledger arrays to actual values ////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	/** Converts the expected phenotype index to the metric specified by the user*/
	public NumberObjectSingle phenotypeExpectedLedgerIndexToOriginalMetric(int phenotypeIndex, NumberObjectSingle expectedIndex) {
		// Figure out where the 0 point is
		NumberObjectSingle zeroPoint = NumberObject.createNumber(model.howToRepresentNumbers, 
				this.phenotypicDimensionZeroPoints[phenotypeIndex]);
		
		// Next, figure out how many units we are above or below the zero point:
		// [units from 0] = expectedIndex - zeroPoint
		NumberObjectSingle unitsFromZero = expectedIndex.subtract(zeroPoint, false);
		
		// Multiply the units with the step size to get the expected value
		NumberObjectSingle expectedValue = unitsFromZero.multiply(this.phenotypicDimensionStepsize[phenotypeIndex], true);
		
		// Do some checks if we need to
		if (model.performSafetyChecks) {
			// check if the expectedValue is higher than the lowest possible value
			if (expectedValue.smallerThan(this.phenotypicDimensionValues[phenotypeIndex][0], true))
				throw new IllegalStateException("Expected index of phenotype [" + 
						phenotypeIndex  + "] is " + expectedIndex + 
						", which corresponds to a value of " + expectedValue.toStringWithoutTrailingZeros() + 
						", which is lower than the lowest possible " + this.phenotypicDimensionValues[phenotypeIndex][0].toStringWithoutTrailingZeros());
		
			// Similarly, it should not be larger than the largest vale
			// check if the expectedValue is higher than the lowest possible value
			if (expectedValue.largerThan(this.phenotypicDimensionValues[phenotypeIndex][this.phenotypicDimensionValues[phenotypeIndex].length-1], true))
				throw new IllegalStateException("Expected index of phenotype [" + 
						phenotypeIndex  + "] is " + expectedIndex + 
						", which corresponds to a value of " + expectedValue.toStringWithoutTrailingZeros() + 
						", which is higher than the higest possible " + this.phenotypicDimensionValues[phenotypeIndex][0].toStringWithoutTrailingZeros());
		}
		return expectedValue;
	}
	
	
}
