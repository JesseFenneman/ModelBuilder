package core;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectRepresentation;
import belief.Belief;
import helper.Helper;
import interfaces_abstractions.ObserverManager;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import patch.Patch;
import rIntegration.RFunctionContainer;
import spatialAndTemporalElements.PatchTemplate;
import start.Console;
import states.RoamingStates.T1AbstractStateFactory;
import states.RoamingStates.T1ActionState;
import states.RoamingStates.T1ActionStateEvaluator;
import states.RoamingStates.T1ActionStateExpander;
import states.RoamingStates.T1ActionStateFactory;
import states.RoamingStates.T1MutationState;
import states.RoamingStates.T1MutationStateEvaluator;
import states.RoamingStates.T1MutationStateExpander;
import states.RoamingStates.T1StateList;
import staticManagers.OutputFileManager;
import view.ModelManagerOld.ModelStage;
import view.View;
import view.View.SaveEncounterStateMode;
import view.View.SaveT2Mode;
import view.Workspace;

public class AbstractModel  {

	/** Instantiated objects can be one of four
	 * main types: resources, interruptions, delays, 
	 * or extrinsic events.*/
	public enum InstantiatedObjectClass{
		RESOURCE,
		INTERRUPTION,
		DELAY,
		EXTRINSIC
	}
	
	/** Instantiated objects that can are used during
	 * encounters can be resources, interruptions, or 
	 * delays*/
	public enum EncounteredInstantiatedObjectClass{
		RESOURCE,
		INTERRUPTION,
		DELAY
	}
	
	/** This exception is thrown when the model is interrupted by the View.*/
	@SuppressWarnings("serial")
	public static class ModelInterruptedException extends RuntimeException { public ModelInterruptedException() {     super("Model has been interrupted by View.");  }}


	// If true, many checks are done during runtime to ensure quality - for instance, by checking if probability
	// distributions sum to 1 at all moments in time. If set to false, these checks are not done. Disabling 
	// checks decreases the time required to run, but might result in incorrect output. It is advised to 
	// set this boolean to false only for large scale runs that have been piloted on smaller runs beforehand. 
	public final boolean performSafetyChecks;

	// For debugging: should the model print all steps to the console?
	public static boolean debugMode;

	// A manager to manage all the disk IO
	public final OutputFileManager outputFileManager;
	private final HashMap<AbstractObjectiveTemplate, Integer> whichSamplingDistributionToUse; // If there are multiple sampling distributions for an object, this hashmap tells the model which one to use. 

	// The view to report progress to
	public final View view;
	private boolean isInterrupted;

	// Fields we use for writing the results to disk
	public final String name;
	public final String description;
	public final String modelStartTime;

	/** Save all the computed states as files after the model is done?*/
	public final boolean saveRoamingStatesAsOutput;

	/** Save the output for all T2DecisionTrees, similar to how we
	 * save the result for the T1 tree? Or only for the first time step?
	 * Or not at all?*/
	public final SaveT2Mode saveEncouterStatesAsOutput;

	/** During runtime, some models might contain many different, or
	 * very complex, decision trees. Rather than bottling up the RAM
	 * with these large trees, we can temporarily store them to disk.
	 * This increases the runtime due to costly IO operations, but
	 * allows FMB to run on systems that do not have insane RAM specs.*/
	public final boolean saveEncounterTreesToFile;


	// RUNTIME PARAMETERS set by the user
	public final FitnessFunction fitnessFunction;
	public final int maximumAge, maximumStepsInEncounter;
	public final NumberObjectRepresentation howToRepresentNumbers;
	public final int nThreads;					// What is the maximum number of additional threads is the model allowed to use (excluding the main thread)?
	public final boolean saveResultPerAge;

	///////   ALL OBJECTS THAT CARRY RUNTIME SPECIFIC INFORMATION //////
	public final Ledger ledger;					// Contains all representation of numbers, in a large set of arrays
	public final Belief beliefs;				// Contains all prior and posterior beliefs, and all posterior cue emissions
	private final T1StateList t1StateList;		// CT1 State - i.e., the between encounter states. Private because its use must be synchronized

	////// Validation
	// The ledger stores all array values. For more information, see Ledger javadoc
	private final ColdStorageLedger coldStorageLedger;


	/** Create a model from the workspace. If an object has multiple sampling distributions, the whichSamplingDistributionToUse should
	 * have an entry that links that object to the index of the sampling distribution to use in this model. The model will use up to
	 * nThreads number of threads during the runtime. */
	public AbstractModel(	Workspace workspace, 
			View view,
			int uniqueModelIdentifier,
			HashMap<AbstractObjectiveTemplate, Integer> whichSamplingDistributionToUse, 
			int nProcessingThreads,
			File userSpecifiedOutputDirectory,
			boolean saveT1StatesAsOutput,
			SaveEncounterStateMode saveT2Mode,
			boolean saveT2TreesToFile,
			boolean saveResultsPerAge,
			boolean performSafetyTests,
			NumberObjectRepresentation numberRepresentation){

		this.view = view;
		this.isInterrupted = false;

		// Set all the user-specified runtime parameters
		this.whichSamplingDistributionToUse =  whichSamplingDistributionToUse;
		this.howToRepresentNumbers = numberRepresentation;
		this.maximumAge = workspace.getMaximumLifeTime();
		this.maximumStepsInEncounter = workspace.getMaximumCycleTime()+1; // +1 because the first time step (0) in the encounter is only a mutation step
		this.nThreads = nProcessingThreads;
		this.modelStartTime = Helper.timestamp();
		this.saveResultPerAge = saveResultsPerAge;
		this.performSafetyChecks = performSafetyTests;

		// Create the model name and description
		this.name = "Model " + uniqueModelIdentifier;

		StringBuilder sb = new StringBuilder();
		ArrayList<AbstractObjectiveTemplate> objects = new ArrayList<>();
		objects.addAll(whichSamplingDistributionToUse.keySet());
		for (int i = 0; i < objects.size(); i ++){
			ArrayList<RFunctionContainer> rfcList = objects.get(i).getAllSamplingDistributions();
			if (rfcList == null)
				continue;
			RFunctionContainer rfc= rfcList.get(whichSamplingDistributionToUse.get(objects.get(i)));
			sb.append(objects.get(i).getName() + " = " + rfc.toStringOmitting("domain"));		
			if (i != objects.size()-1)
				sb.append(", ");
		}

		this.description = sb.toString();

		// Create the folder structure to store results and, if necessary, temporary T2DecisionTree's
		Console.print("Creating folder structure for model at: '" + userSpecifiedOutputDirectory.getAbsolutePath() + "'...");
		this.outputFileManager = new OutputFileManager(this, userSpecifiedOutputDirectory);

		// Build all objects (non-age phenotypes, resources, delays, interruptions, and extrinsic events) in the workspace
		// Rather than refer to objects, patches, and states by name, we 'integerize' this value.
		// That is, rather than refer to actual objects, we'll keep a store of integers that
		// points to objects, and another store of integers that points to values of those object.
		// This helps with both speed and (floating point) accuracy. This store is the Ledger. However,
		// to avoid any mishaps, we'll make all fields in the Ledger final. 
		LedgerFactory ledgerFactory = buildObjectsFromWorkspace(workspace);

		// Now that we have all objects, patches, actions, mutations, and death conditions we can turn the LedgerFactory into a permanent Ledger
		this.ledger = new Ledger(ledgerFactory, this);

		// We will also create another ledger, to be used as a validation later on (to see if the ledger has changed)
		this.coldStorageLedger = new ColdStorageLedger(ledgerFactory, this);
		this.coldStorageLedger.validateVersions(ledger);

		// Some feedback to the user
		Console.print("Created all objects in workspace, created ledger, and created cold storage for ledger. Ledger: \n" + ledger);		

		// Save ledger to 'ledger.txt'
		outputFileManager.writeLedgerToFile();
		Console.print("Written ledger to 'ledger.txt'");


		// Set the fitness function
		this.fitnessFunction = new FitnessFunction
				(workspace.getFitnessFunction(), 
						workspace.getUseFitnessFunctionBeforeMaximumAge(), 
						workspace.getFitnessDeath(),
						this);
		Console.print("Set fitness function: " + fitnessFunction);

		// Create the T1StateList (which will be empty until the model starts to run)
		//this.t1StateList = new T1StateList(this); 

		// Create the Belief object (which will be empty until the model starts to run)
		this.beliefs = new Belief(this);


	}

	/** Set up the model. For efficiency reasons, we can precompute quite a few elements. For instance,
	 * rather than having to keep repeating the same computations to calculate beliefs, we just compute
	 * all possible beliefs an agent can hold, and store these beliefs in a somewhat intelligent manner.
	 * As a result, we don't have to continuously reinvent the wheel. 
	 * 
	 * As always, there is a tradeoff here: we're trading off a faster computation speed for more required 
	 * memory space. However, I assume that somebody running the model will have sufficient RAM in their
	 *  system (16 gigs should be OK, but even 32 gigs doesn't sound that unreasonable nowadays. */
	private void setup() {
		Console.print("Precomputational step: setting up some things before we start the model...");

		// Compute all possible beliefs
		beliefs.computeAllPosteriors();

		Console.print("Done setting up the model. ");


	}

	/** Returns the T1StateList.  */
	public T1StateList getT1StateList() {
		return this.t1StateList;
	}
	/** Executes the model. This is the meat of the algorithm, and will take by far the most time.
	 * The model uses the following algorithm:
	 * 
	 * Step 0. Initialize the Model
	 * 		- Compute all possible posterior beliefs
	 * 		- Provide some feedback to the user.
	 * 
	 * Step 1. Compute all possible starting states
	 * 		- There is a starting state for each possible combination of non-age phenotypic dimensions
	 * 		- These states are 'automatically' registered in the T1StateList
	 * 
	 * Step 2. The forwards pass: create the decision tree. The algorithm for this forward pass is:
	 *		2.1. For each age a from 0 to maximumAge:
	 * 		2.2. 		Get all action states with age a in all patches. Call this collection AS
	 * 		2.3.		For each action state as in AS:
	 * 		2.4.			Expand as: compute all consequences of all possible actions.
	 * 						After this step, all possible mutation states at this age are accounted for
	 * 						IMPORANT: this also includes all search actions, which might result in multiple T2DecisionTrees.
	 * 						These tree's are also created with a forward pass. As such, this step has to be multi-threaded.
	 * 		2.5. 		Get all mutation states with age a in all patches. Call this collection MS
	 * 		2.6.		For each mutation state ms in MS:
	 * 		2.7. 		Expand ms: compute the effect of all mutations.
	 * 						After this step, all possible action states at the next age are accounted for
	 * 
	 * Step 3. The backwards pass: compute the expected fitness of all nodes in the tree. The algorithm for this backwards pass is:
	 * 		3.1. For each age a from maximumAge to 0:
	 * 		3.2.	Get all the T1 mutation states with age a in all patches. Call this collection MST1
	 * 		3.2.	For each T1 mutation state mst1 in MST1:
	 * 		3.3.		Compute the expected fitness of entering this mutation state. This expected fitness is the
	 * 					weighted sum over all possible T1ActionStates or T1FitnessStates an agent might end up in
	 * 					after going through all the mutations, weighted for the probability of ending up in that state.
	 * 		3.4. 	Get all the T1 action state with age a in all patches. Call this collection AST1
	 * 		3.5.	For each T1 action state ast1 in AST1: 
	 * 		3.6. 		For each action act1 possible in ast1:
	 * 		3.7.			Compute the expected fitness of action act1: 
	 * 		3.7.1.			If act1 is not a search action, the expected fitness of act1 in ast1 is the weighted sum of 
	 * 						the fitness in all possible T1Fitness and T1Mutation states the agent might end up in 
	 * 						after performing act1 in ast1, weighted for the probability of ending up in this state.
	 * 		3.7.2.			If act1 is a search action, then:
	 * 		3.7.3				Perform a backwards pass on the all T2DecisionTree's that might result from taking ac in ast1
	 * 							Specifically: (Note: this is the backward pass of the T2DecisionTree)
	 * 		3.7.4				For each time from maximumTimeInEncounter to 0:
	 * 		3.7.5					Get all the T2 Mutation states at the time'th time step in the T2DecisionTree. Call this collection MST2
	 * 		3.7.6.					For each T2 mutation state mst2 in MST2:
	 * 		3.7.7.						Compute the expected fitness of entering mst2. The expected fitness is the weighted sum
	 * 									over all possible T1ActionStates, T2ActionStates, and T1Fitness states that an agent might
	 * 									end up in after going through all mutations in mst2, weighted for the probability of ending up in that state.
	 * 		3.7.8					Get all the T2 actions states at the time'th step in the T2DecisionTree. Call this collection AST2
	 * 		3.7.9					For each T2 action state ast2 in AST2:
	 * 		3.7.10						For each action act2 possible in AST2:	
	 * 		3.7.11							Compute the expected fitness of doing act2 in ast2. This is the weighted sum of the expected fitness
	 * 										of all possible successor states, weighted for the probability of ending up in that state.
	 * 		3.7.12				The T2DecisionTree's root node expected fitness is the expected fitness of action performing act1 in ast1
	 * 		3.7.13		Take the action (or actions in case of ties) that maximize the expected fitness in ast1. Call this collection ac*t1.
	 * 		3.7.14		The probability of taking each action act1 in ast1 is now {0|ac not in ac*t1} /\ {1/|ac*t1| | ac in ac*t1}, where |x| is the size of collection x
	 * 		3.7.15		Based on the best action, also compute some additional variables (expectedAge, expectedPhenotype, expectedFutureActions
	 * 
	 * Step 4. Data storage.
	 * 
	 * */
	public void run(){
		try {
			// Set up the model: perform all the necessary pre-computations
			this.setup();

			// Provide some details about this model:
			Console.print("\n\n\n\n\n\n\n\n"+ Helper.repString("=", 50) + " START OF MODEL " + Helper.repString("=", 50) + "\n\n\n");
			Console.print("Starting a model run with the following parameters: ");
			for (AbstractObjectiveTemplate obj : this.whichSamplingDistributionToUse.keySet()) 
				if (!(obj instanceof PhenotypeObjectTemplate )) 
					if (!obj.isConstant())
						Console.print("\t- For object '" + obj.getName() + "': using the " + whichSamplingDistributionToUse(obj) + "th sampling distribution (" + obj.getAllSamplingDistributions().get(whichSamplingDistributionToUse(obj)) + ")");
					else
						Console.print("\t- For object '" + obj.getName() + "': this object is constant");


			Console.print("\t- Fitness function: " + this.fitnessFunction);
			Console.print("\t- Maximum age: " + this.maximumAge);
			Console.print("\t- Maximum time steps during encounter: " + this.maximumStepsInEncounter);
			Console.print("\t- Using number format: " + howToRepresentNumbers);
			Console.print("\t- Maximum number of concurrent processing threads: " + this.nThreads);

			// Start...
			Console.print("Starting the actual model run of the model...");

			// Step 1: Compute all starting states
			setStartingStates();

			// Step 2: forwards pass
			forwardsPass();
			System.err.println(Helper.timestamp() + "\t"+"Done forwards pass");
			Thread.sleep(1000);
			// Step 3: backwards pass
			backwardsPass();

			// Check ledger integrity
			this.coldStorageLedger.validateVersions(ledger);

			// Save the results to disk
			this.outputFileManager.writeResults(";", saveResultPerAge);

			// Finally, print a copy of the console to the consoleLog.txt file
			outputFileManager.writeConsoleToFile();
		} catch (Exception e) {
			ObserverManager.notifyObserversOfError(e);
			outputFileManager.writeExceptionToFile(e);
		}

		// Report to the View that this model is done
		ModelManager.get().reportProgress(this, -1, ModelStage.COMPLETED);

	}

	/** Implements Step 1 of the run() function: computing all starting states. 
	 * The set of starting states are all possible phenotypic states, given that the 
	 * agent starts in the base patch in the base state. After this function, the T1StateList will have all action
	 * states stored for the first age and the starting patch/state.  */
	private void setStartingStates() {
		Console.print("Computing all starting states...");

		// Compute all possible permutations of all phenotypic dimensions
		ArrayList< Integer[] > possibleValues = new ArrayList<>();
		for (int phenotypicDimension = 0; phenotypicDimension < ledger.numberOfNonAgePhenotypicDimensions; phenotypicDimension ++) {
			possibleValues.add(Helper.sequence(0, ledger.phenotypeValues[phenotypicDimension].length, 1));
		}

		// Using recursion, find all permutations of these indices
		ArrayList<int[]> permutations = new ArrayList<>();
		getAllPermutations(possibleValues, permutations, 0, new int[possibleValues.size()]);

		// Print to the console how many unique phenotype states there are in this age/location
		Console.print("\tThere are " + permutations.size() + " unique starting states. ");

		// Create a template factory - from this factory we will clone all other factories.
		// The cloned factories differ only in their phenotypic state
		int patchLocation = ledger.patchStates[ledger.basePatchIndex].ledgerIndexOfPatch;
		T1AbstractStateFactory templateFactory = new T1AbstractStateFactory(this)
				.setAge(0)
				.setLocation(ledger.basePatchIndex, ledger.baseStateIndex)
				.initializePatchHistory()
				.resetTimeSinceLastVisit(patchLocation)
				.setPatchStateInLastVisit(patchLocation, ledger.baseStateIndex);

		// Use the template to create a clone for each possible starting 
		for (int[] phenotype : permutations) {
			T1ActionStateFactory actionFactory = new T1ActionStateFactory(templateFactory, true);
			actionFactory.initializePhenotype(phenotype);
			if(!actionFactory.resultsInDeadState()) {
				t1StateList.getActionState(actionFactory);
			}
		}

	}

	/** Implements the forward pass (step 2 of the run() function). Specifically:
	 * 	 * Step 2. The forwards pass: create the decision tree. The algorithm for this forward pass is:
	 *		2.1. For each age a from 0 to maximumAge:
	 * 		2.2. 		Get all action states with age a in all patches. Call this collection AS
	 * 		2.3.		For each action state as in AS:
	 * 		2.4.			Expand as: compute all consequences of all possible actions.
	 * 						After this step, all possible mutation states at this age are accounted for
	 * 						IMPORANT: this also includes all search actions, which might result in multiple T2DecisionTrees.
	 * 						These tree's are also created with a forward pass. As such, this step has to be multi-threaded.
	 * 		2.5. 		Get all mutation states with age a in all patches. Call this collection MS
	 * 		2.6.		For each mutation state ms in MS:
	 * 		2.7. 		Expand ms: compute the effect of all mutations.
	 * 						After this step, all possible action states at the next age are accounted for
	 * @throws InterruptedException 
	 * */
	private void forwardsPass() throws InterruptedException {
		Console.print("\n" + Helper.repString("=", 50) + "\nStarting forwards pass..." +"\n" + Helper.repString("=", 50) );

		// Step 2: forward pass
		for (int a = 0; a <= maximumAge; a++) {
			if (isInterrupted) {
				ModelManager.get().reportProgress(this, a, ModelStage.INTERRUPTED);
				throw new ModelInterruptedException();
			}

			// Let the thread sleep just a little bit for the update to register on the view
			Console.print("Waiting here.");
			Thread.sleep(10);
			Console.print("\n\nForwards pass: starting age " + a + "...");

			// Step 2.2: Get all action states
			Set<T1ActionState> actionStateSet = t1StateList.getAllActionStatesFor(a);
			System.err.println(Helper.timestamp() + "\tAge " + a + " has " + actionStateSet.size() + " action states.");
			// Steps 2.3 & 2.4. Expand all action states, using hyper-threading
			// Create the executor service: a fixed thread pool with nProcessingThreads threads
			ExecutorService esAction = Executors.newFixedThreadPool(this.nThreads);

			// Create an ArrayList of Future's that we will use to check if all went well.
			ArrayList<Future<Integer>> futureAction = new ArrayList<>();

			// Create a T1ActionStateExpander for all states in the set, and add that expander to the executor service's queue
			for (T1ActionState s: actionStateSet)
				futureAction.add(esAction.submit( new T1ActionStateExpander(this, s, printT2ProductionToConsole)));

			// Wait for all threads to be done...
			esAction.shutdown();
			Console.print("\tExpanding all action states for age " + a +"..." );
			try {			esAction.awaitTermination(1, TimeUnit.DAYS);	} catch (InterruptedException e) { ObserverManager.notifyObserversOfError(e);			}
			Console.print("\tDone expanding all action states for age " + a + "." );

			// Check if all exit codes are 0. 
			for (Future<Integer> f : futureAction)
				try {
					if (f.get()!= 0)
						throw new IllegalStateException("Something went wrong - exit code after T1 action expansion is not 0. Exit code: "+ f.get());
				} catch (Exception e1) { ObserverManager.notifyObserversOfError(e1);}
			Console.print("\tAll exit sums are 0 for all action states after forwards pass");

			// Step 2.5. Get all mutation states
			Set<T1MutationState> mutationStateSet = t1StateList.getAllMutationStatesFor(a);

			// Step 2.6 & 2.7. Expand all mutation states.
			// Although we probably don't need to use multi-threading here, we might just as well use it
			// Step 2.3. Expand all action states, using hyper-threading
			// Create the executor service: a fixed thread pool with nProcessingThreads threads
			ExecutorService esMutation = Executors.newFixedThreadPool(this.nThreads);

			// Create a T1MutationStateExpander for all mutation states, and submit to esMutation
			for (T1MutationState s: mutationStateSet)
				esMutation.submit( new T1MutationStateExpander( s));

			// Wait for all threads to be done...
			esMutation.shutdown();
			Console.print("\tExpanding all mutation states for age " + a +"..." );
			try {			esMutation.awaitTermination(1, TimeUnit.DAYS);	} catch (InterruptedException e) { ObserverManager.notifyObserversOfError(e);			}
			Console.print("\tDone expanding all mutation states for age " + a + "." );

			// Report to the View
			ModelManager.get().reportProgress(this, a, ModelStage.BUSY_WITH_FORWARDS_PASS);

			// Store the T2DecisionTrees to disk, if applicable
			if (this.saveT2TreesToFile)
				this.outputFileManager.writeAllTrees(a);

		}
		Console.print("Finished forward pass");
	}

	/** Implements the backwards pass (step 3 of the run() function). Specifically:
	 * 	 * Step 3. The backwards pass: compute the expected fitness of all nodes in the tree. The algorithm for this backwards pass is:
	 * 		3.1. For each age a from maximumAge to 0:
	 * 		3.2.	Get all the mutation states with age a in all patches. Call this collection MS
	 * 		3.3.	For each mutation state ms in MS:
	 * 		3.4.		Compute the expected fitness of entering this mutation state. This expected fitness is the
	 * 					weighted sum over all possible T1ActionStates or T1FitnessStates an agent might end up in
	 * 					after going through all the mutations, weighted for the probability of ending up in that state.
	 * 		3.5. 	Get all the action state with age a in all patches. Call this collection AS
	 * 		3.6.	For each action state as in AS: 
	 * 		3.7. 		For each action ac possible in as:
	 * 		3.8.			Compute the expected fitness of action ac. 
	 * 		3.8.1.			If ac is not a search action, the expected fitness of ac in as is the weighted sum of 
	 * 						the fitness in all possible T1Fitness and T1Mutation states the agent might end up in 
	 * 						after performing ac in as, weighted for the probability of ending up in this state.
	 * 		3.8.2.			If ac is a search action, the expected fitness of ac in as is the weighted sum of the
	 * 						fitness of all possible future T1MutationStates and T1FitnessStates, as well as the expected
	 * 						fitness of the root nodes (a T2MutationState) for all T2DecisionTrees that might result
	 * 						from taking ac in as. To compute the expected fitness of a T2DecisionTree's root node, the
	 * 						T2DecisionTree also has to go through a backwards pass.
	 * 		3.9			Figure out what actions ac in as result in the highest fitness, and store the indices of those
	 * 					actions in as's bestActions.
	 * 		3.10.		Set the expected fitness of as to the fitness of the bestActions expected fitness.
	 * 
	 * 		3.11.		Now we know what the expected fitness of each state is. However, we also want to know (in step 4)
	 * 					what expected number of times an agent performs each action during its lifetime. We 
	 * 					will compute the expected number of actions for all T2DecisionTree in this step. The reason why
	 * 					we do it here is that after we computed these actions, we no longer have to store the actual T2DecisionTree.
	 * 					As such, doing this step now makes the rest of the program a lot more memory efficient.*/
	private void backwardsPass() {
		Console.print("\n" + Helper.repString("=", 50) + "\nStarting backwards pass..." +"\n" + Helper.repString("=", 50) );

		// Step 3.1: for all possible ages
		for (int a = maximumAge; a >= 0; a--) {

			Console.print("\n\nBackwards pass: starting age " + a + "...");
			if (isInterrupted) {
				ModelManager.get().reportProgress(this, a, ModelStage.INTERRUPTED);
				throw new ModelInterruptedException();
			}
			System.err.println("\nBackwards age " + a );		

			// If necessary, read all T2DecisionTree's from disk
			if (this.saveT2TreesToFile)
				try {
					this.outputFileManager.readAllTrees(a);
				} catch (InterruptedException e2) {
					ObserverManager.notifyObserversOfError(e2);
				}

			// Step 3.2. create the MS collection
			Set<T1MutationState> MS = t1StateList.getAllMutationStatesFor(a);

			// Steps 3.3 & 3.4. For each ms in MS: compute 
			// Create the executor service: a fixed thread pool with nProcessingThreads threads
			ExecutorService esMutation = Executors.newFixedThreadPool(this.nThreads);

			// Create a T1MutationStateExpander for all mutation states, and submit to esMutation
			for (T1MutationState s: MS)
				esMutation.submit( new T1MutationStateEvaluator(s, printStateEvalutionToConsole));

			// Wait for all threads to be done...
			esMutation.shutdown();
			if (Model.printStateEvalutionToConsole)
				Console.print("\tEvaluating fitness for all mutation states for age " + a +"..." );
			try {			esMutation.awaitTermination(1, TimeUnit.DAYS);	} catch (InterruptedException e) { ObserverManager.notifyObserversOfError(e);			}
			if (Model.printStateEvalutionToConsole)
				Console.print("\tDone evaluating fitness for all mutation states for age " + a + "." );


			// Steps 3.5: Get all action states
			Set<T1ActionState> AS = t1StateList.getAllActionStatesFor(a);

			// Steps 3.6: for all action states:...

			// 3.7 - 3.11: compute expected fitness of action state (using multi-threading)
			// Note: the implementation steps are implemented by a T1ActionStateEvaluator - including both the
			// backwards pass and the prune-to-policy pass for the T2DecisionTree's (to compute which actions it will take 
			// from here to the end of its life)
			// Create the executor service: a fixed thread pool with nProcessingThreads threads
			ExecutorService esAction = Executors.newFixedThreadPool(this.nThreads);

			// Create an ArrayList of Future's that we will use to check if all went well.
			ArrayList<Future<Integer>> futureAction = new ArrayList<>();

			// Create a T1ActionStateExpander for all states in the set, and add that expander to the executor service's queue
			for (T1ActionState s: AS)
				futureAction.add(esAction.submit( new T1ActionStateEvaluator(this, s, printStateEvalutionToConsole)));

			// Wait for all threads to be done...
			esAction.shutdown();
			if (Model.printStateEvalutionToConsole)
				Console.print("\tEvaluating fitness for all action states for age " + a +"..." );
			try {			esAction.awaitTermination(1, TimeUnit.DAYS);	} catch (InterruptedException e) { ObserverManager.notifyObserversOfError(e);			}
			if (Model.printStateEvalutionToConsole)
				Console.print("\tDone evaluating fitness for all action states for age " + a + "." );

			// Check if all exit codes are 0. 
			for (Future<Integer> f : futureAction)
				try {
					if (f.get()!= 0)
						throw new IllegalStateException("Something went wrong - exit code after T1 action expansion is not 0. Exit code: "+ f.get());
				} catch (Exception e1) { ObserverManager.notifyObserversOfError(e1);}
			Console.print("\tAll exit sums are 0 for all action states after backwards pass");

			// Report to the View
			ModelManager.get().reportProgress(this, a, ModelStage.BUSY_WITH_BACKWARDS_PASS);
		}

		Console.print("Finished backwards pass");
	}

	/** Sometimes a workspace can specify that an object can have multiple sampling distributions. If that is the case,
	 * we need to make a model for each possible combination of sampling distributions between objects. To keep track of 
	 * which sampling distribution this model uses, the Model stores a HashMap called whichSamplingDistributionToUse, 
	 * which takes an object and returns the index of the sampling distribution to use. If the object has no entry
	 * in this HashMap (i.e., there is only a single samplingDistribution for this object) this function returns 0. */
	public int whichSamplingDistributionToUse(AbstractObjectiveTemplate objectTemplate) {
		if (this.whichSamplingDistributionToUse.containsKey(objectTemplate))
			return this.whichSamplingDistributionToUse.get(objectTemplate);
		return 0;			
	}

	/** Build the Ledger based on the workspace*/
	private synchronized LedgerFactory buildObjectsFromWorkspace(Workspace workspace) {
		LedgerFactory ledgerFactory = new LedgerFactory(this);

		// Build all objective elements 
		this.buildObjectiveElements(workspace, ledgerFactory);

		// Build the patches and patch states. Create them in the same order as they are listed in
		// the transition matrix (that makes the next step a bit easier
		for (PatchTemplate pt : workspace.getPatchTransitions().getOrderedPatches())
			new Patch(pt, this, ledgerFactory, workspace);

		// Set the canMoveFromPatchToPatch
		ledgerFactory.canMoveFromPatchToPatch = workspace.getPatchTransitions().toBooleanMatrix();

		// Set patchIsAccessibleFrom, which is the transpose of canMoveFromPatchToPatch
		ledgerFactory.patchIsAccessibleFrom = new Boolean[ledgerFactory.patches.size()][ledgerFactory.patches.size()];
		for (int r = 0; r < ledgerFactory.patches.size(); r++)
			for (int c = 0; c < ledgerFactory.patches.size(); c++)
				ledgerFactory.patchIsAccessibleFrom[r][c] = ledgerFactory.canMoveFromPatchToPatch[c][r];

		/

	}


	/** Returns the Belief object of this Model. The Belief deals with all (prior and posterior) beliefs*/
	public Belief getBeliefs () {return beliefs;}

	/** Get all permutations by recursively adding the n'th value to current. The results are stored in permutations*/
	private void getAllPermutations(ArrayList< Integer[]> possibleValues,
			ArrayList<int[]> permutations,
			int currentPhenotypicDimension,
			int[] current) {

		// base case: if depth is the same as the number of phenotypic dimensions, we have
		// a value for all possible dimensions stored in current, and we are done with this 
		// sequence
		if (currentPhenotypicDimension == (current.length)) {
			int[] newPermutation = new int[current.length];
			for (int i = 0; i < current.length; i++)
				newPermutation[i] = current[i];
			permutations.add(newPermutation);
			return;
		}

		// Otherwise, add another set of values to the current set
		for (int i = 0; i < (possibleValues.get(currentPhenotypicDimension).length-1); i++) {
			current[currentPhenotypicDimension] = i;
			getAllPermutations(possibleValues, permutations, currentPhenotypicDimension +1, current);
		}

	}

	/** Inform this Model that it is to stop immediately */
	public void interruptModel() {
		this.isInterrupted = true;
	}
}
