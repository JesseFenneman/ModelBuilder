package core;

import java.util.Random;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectRepresentation;
import helper.Helper;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import start.Console;

/** A class that creates random numbers. Currently, it is a simple wrapper
 * for Java's Math.random. However, perhaps in later versions I would
 * like to use another class or RNG. By creating this wrapper class,
 * this change can be made more easily.*/
public class RandomNumberGenerator {

	private static Random generator = new Random();
	
	/** Set the seed for the random number generator.*/
	public static void setSeed(long seed) {
		generator.setSeed(seed);
		Console.print("Set the random seed to " + seed);
	}
	
	/** Get a random integer between 0 and 2^32. All values 
	 * are sampled from a uniform distribution.*/
	public static int getRandomInt() {
		return generator.nextInt();
	}
	
	/** Get a random integer between minimum and maximum, inclusive.
	 * Values are sampled from a uniform distribution.*/
	public static int getRandomInt(int minimum, int maximum) {
		return generator.nextInt((maximum - minimum) + 1) + minimum;
	}
	
	/** Get a random double between minimum and maximum, inclusive.
	 * Note: NumberObjectSingles are conceptually similar to doubles, not to integer.
	 * Values are sampled from a uniform distribution.*/
	public static double getRandomDouble( NumberObjectSingle minimum, NumberObjectSingle maximum) {
		double d = generator.nextDouble();
		return minimum.toDouble() + (maximum.toDouble()- minimum.toDouble()) * d;
	}
	
	/** Get a random NumberObjectSingle of the specified representation between minimum and maximum, inclusive.
	 * Note: NumberObjectSingles are conceptually similar to doubles, not to integer.
	 * Values are sampled from a uniform distribution.*/
	public static NumberObjectSingle getRandomNumberObjectSingle (NumberObjectSingle minimum, NumberObjectSingle maximum, NumberObjectRepresentation representation) {
		NumberObjectSingle random = NumberObject.createNumber(representation, generator.nextDouble());
		NumberObjectSingle range = maximum.subtract(minimum, false);
		NumberObjectSingle rangePlusMinimum = minimum.add(range, true);
		return rangePlusMinimum.multiply(random, true);
	}
	
	/** Given the probability of success (should be between 0 and 1, inclusive), return
	 * a boolean indicating whether this Bernoulli trial was a success or failure*/
	public static boolean sampleBernoulliTrial(double probability) {
		if (probability>1)
			throw new IllegalArgumentException("Probability larger than 1: " + probability);
		if (probability<0)
			throw new IllegalArgumentException("Probability smaller than 1: " + probability);
		
		Double random = generator.nextDouble();
		if (random > probability)
			return false;
		return true;
	}
	
	/** Given the probability of success (should be between 0 and 1, inclusive), return
	 * a boolean indicating whether this Bernoulli trial was a success or failure*/
	public static boolean sampleBernoulliTrial(NumberObjectSingle probability) {
		if (probability.largerThan(1))
			throw new IllegalArgumentException("Probability larger than 1: " + probability);
		if (probability.smallerThan(0))
			throw new IllegalArgumentException("Probability smaller than 1: " + probability);
		
		double random = generator.nextDouble();
		if (probability.smallerThanOrEqualTo(random))
			return true;
		return false;
	}
	
	/** Assumes that probabilities is an array of NumberObjectSingle values that each are a probability (i.e.,
	 * each individual value is in the range [0,1] and that span the probability space
	 * (i.e., all values together sum to 1). Samples a random value from this array, and 
	 * returns the index position of the chosen probability.
	 * */
	public static int sampleFromDistribution(NumberObjectRepresentation representation, NumberObjectSingle... probabilities) {
		NumberObjectSingle random = getRandomNumberObjectSingle(
				NumberObject.createNumber(representation, 0), 
				NumberObject.createNumber(representation, 1), 
				representation);
		
		for (int i = 0; i < probabilities.length; i ++) {
			if (random.smallerThan(probabilities[i]))
				return i;
			else
				random.subtract(probabilities[i], true);
		}
		
		throw new IllegalStateException("There are not enough probability values in specified array: " + NumberObject.createArray(representation, probabilities));
	}
}
