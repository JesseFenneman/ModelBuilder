package deathConditions;

import core.Model;
import states.RoamingStates.T1AbstractStateFactory;

/** An agent dies if it reaches the maximum age*/
public class DeathConditionAge extends DeathCondition{


	private final int maximumAge;
	protected DeathConditionAge(Model model) {
		this.maximumAge = model.maximumAge;
	}
	
	@Override
	public boolean applies(T1AbstractStateFactory stateFactory) {
		return stateFactory.age >= maximumAge;
	}

	@Override
	public String toString() {
		return "Death condition: an agent dies when its age is at least " + maximumAge;
	}


	@Override
	public int hashCode() {
		return maximumAge;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DeathConditionAge other = (DeathConditionAge) obj;
		if (maximumAge != other.maximumAge) {
			return false;
		}
		return true;
	}
	
}
