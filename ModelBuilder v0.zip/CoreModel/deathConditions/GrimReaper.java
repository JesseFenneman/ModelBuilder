package deathConditions;

import core.Ledger;
import states.Abstract.AbstractStateFactory;
import states.RoamingStates.T1AbstractStateFactory;

/** The GrimReaper class has one static function, doesKill, which returns
 * true if a State matches at least 1 death condition.*/
public class GrimReaper {
	private final Ledger ledger;
	
	/** Create the GrimReaper, a class that kills states*/
	public GrimReaper (Ledger ledger) {
		this.ledger = ledger;
	}
	

	/** Returns true if at least one DeathCondition applies to the state that will result from this factory*/
	public boolean willBeCulled(AbstractStateFactory abstractStateFactory) {
		for (DeathCondition dc: ledger.deathConditions)
			if (dc.applies(abstractStateFactory)) {
				return true;
			}
		return false;	
	}

}
