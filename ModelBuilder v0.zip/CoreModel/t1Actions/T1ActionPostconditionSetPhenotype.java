package t1Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.Ledger;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import states.EncounterStates.T2MutationStateFactory;
import states.RoamingStates.T1ActionStateFactory;

/** Set the phenotype to a specific value. Note that during the action
 * phase the age does not yet increase - this is only done during the mutation phase.*/
public class T1ActionPostconditionSetPhenotype extends T1ActionPostcondition{
	private final Ledger ledger;
	private final int phenotypeIndex, valueIndex;
	protected T1ActionPostconditionSetPhenotype(Ledger ledger, int phenotypeIndex, int valueIndex) {
		this.ledger = ledger;
		this.phenotypeIndex = phenotypeIndex; 
		this.valueIndex = valueIndex;
	}

	@Override
	public Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
    			  ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> currentStates){
		// Create a new ArrayList to store all resulting State-probability Pairs in
		ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> successorStates = new ArrayList<>();

		// For each current state s (in stateTransitions):
		for (Pair<T1ActionStateFactory, NumberObjectSingle> pair : currentStates) {
			// Create a deep cloned factory with the same values
			T1ActionStateFactory factory = new T1ActionStateFactory(pair.element1, true);

			// Set the phenotype
			factory.phenotype[phenotypeIndex] = valueIndex;

			// Place sprime in the successorState hashmap. The probability is the same as in the stateTransitions (this is a deterministic action)
			successorStates.add(new Pair<T1ActionStateFactory, NumberObjectSingle>(factory, pair.element2));
		}

		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to 1
		if (ledger.model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T1ActionStateFactory, NumberObjectSingle> pair : successorStates)
				if (pair.element2.smallerThan(0))
					throw new IllegalStateException("Transition to sucessor state after moving has a non-positive probability.");
				else
					sum.add(pair.element2, true);
			if (!sum.equals(1))
				throw new IllegalStateException("Transition probability distribution does not sum to 1.");
		}
		
		// Create a new Pair of ArrayLists. The first of which is the successorStates list. 
		// The second list is null - there are no possible T2MutationStates after this postcondition.
		return new Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
  			  ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>>(successorStates, null);

	}

	@Override
	public String toString() {
		return "Set phenotype [" + phenotypeIndex + "] to [" + valueIndex +"] (i.e., to a value of " + ledger.phenotypeValues[phenotypeIndex][valueIndex].toStringWithoutTrailingZeros() + ")";
	}

	@Override
	public boolean canResultInT2States() {	return false;}


}

