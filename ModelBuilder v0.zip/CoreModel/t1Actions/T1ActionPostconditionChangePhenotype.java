package t1Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.Model;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import states.EncounterStates.T2MutationStateFactory;
import states.RoamingStates.T1ActionStateFactory;

/** Increase or decrease the value index position of the phenotype with the prespecified amount.  
 * Note that during the action phase the age does not yet increase - this is only done during the mutation phase.
 * */
public class T1ActionPostconditionChangePhenotype extends T1ActionPostcondition{

	private final int phenotypeIndex, amountOfIndexPositionsToIncrease;
	private final Model model;
	protected T1ActionPostconditionChangePhenotype(Model model, int phenotypeIndex, int amountOfIndexPositionsToIncrease) {
		this.phenotypeIndex = phenotypeIndex; 
		this.amountOfIndexPositionsToIncrease = amountOfIndexPositionsToIncrease;
		this.model = model;
	}

	public Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
    			  ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> currentStates){
		// Create a new ArrayList to store all resulting State-probability Pairs in
		ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> successorStates = new ArrayList<>();

		// For each current state s (in stateTransitions):
		for (Pair<T1ActionStateFactory, NumberObjectSingle> p: currentStates) {
			// Create a deep cloned factory with the same values
			T1ActionStateFactory factory = new T1ActionStateFactory(p.element1, true);

			// Increase the phenotype
			factory.changePhenotypeByIndexAmounts(phenotypeIndex, amountOfIndexPositionsToIncrease);

			// Place sprime in the successorState ArrayList. The probability is the same as in the stateTransitions (this is a deterministic action)
			successorStates.add(new Pair<T1ActionStateFactory, NumberObjectSingle>( factory, p.element2));
		}

		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to 1
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T1ActionStateFactory, NumberObjectSingle> p: successorStates)
				if (p.element2.smallerThan(0))
					throw new IllegalStateException("Transition to sucessor state after changing the phenotype has a non-positive probability.");
				else
					sum.add(p.element2, true);
			if (!sum.equals(1))
				throw new IllegalStateException("Transition probability distribution does not sum to 1.");
		}
		// Create a new Pair of ArrayLists. The first of which is the successorStates list. 
		// The second list is null - there are no possible T2MutationStates after this postcondition.
		return new Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
  			  ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>>(successorStates, null);

	}

	@Override
	public String toString() {
		if (amountOfIndexPositionsToIncrease >0)
			return "Increase phenotype [" + phenotypeIndex + "] with " + amountOfIndexPositionsToIncrease ;
		return "Decrease phenotype [" + phenotypeIndex + "] with " + amountOfIndexPositionsToIncrease ;
	}

	@Override
	public boolean canResultInT2States() {
		return false;
	}


}

