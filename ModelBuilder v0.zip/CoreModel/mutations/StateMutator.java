package mutations;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectIncorrectRepresentationException;
import core.Ledger;
import core.Model;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import helper.Helper.Triplet;
import stateInterfacesAndAbstractions.Path;
import states.EncounterStates.T2ActionState;
import states.EncounterStates.T2ActionStateFactory;
import states.EncounterStates.T2DecisionTree;
import states.EncounterStates.T2MutationState;
import states.EncounterStates.T2MutationStateFactory;
import states.RoamingStates.T1ActionState;
import states.RoamingStates.T1ActionStateFactory;
import states.RoamingStates.T1FitnessState;
import states.RoamingStates.T1FitnessStateFactory;
import states.RoamingStates.T1MutationState;
import states.RoamingStates.T1MutationStateFactory;

/** The StateMutator is a class that has one static function, which applies 
 * all the extrinsic events that affect an agent's phenotype or location to a 
 * set of MutationStates. */
public class StateMutator {

	public final Model model;
	public final Ledger ledger;
	
	/** Create the StateMutator. The StateMutator is responsible for applying all mutations to an ActionState to make it go to a MutationState. */
	public StateMutator(Model model, Ledger ledger) {
		this.model = model; this.ledger = ledger;
		
		// Set the ledger for the state change mutation
		for (Mutation m : ledger.mutations)
			if (m instanceof MutationPatchStateChange)
				((MutationPatchStateChange) m).setLedger(ledger);
		
	}

	/** Execute all mutations in this state. Returns a pair of two ArrayLists containing:  
	 * 
	 * Paths from this state to all T1ActionStates an agent will be in if it survives this mutation.
	 * Paths from this state to all T1FitnessStates an agent will be in if it does not. 
	 * 
	 * Note: the MutationPatchStateChange is the last mutation to happen, as the extrinsic event mutation depends
	 * on the current patch of an agent
	 * (Also, does this function win a prize for having such a beautiful return object type?)*/
	public Pair < 
	ArrayList< Path<T1MutationState, T1ActionState>>,  
	ArrayList< Path<T1MutationState, T1FitnessState>>> mutateT1State (T1MutationState state){

		// Create an array list where we will store all temporary T1MutationFactory successor states
		// Note that a mutation both takes and results in MutationStateFactories - that way, mutations can 
		// be stacked together. At the end we will have to change these MutationStateFactories to either T1MutationStates or T1FitnessStates (depending on who died)
		ArrayList< Triplet<T1MutationStateFactory, NumberObjectSingle, String>>  t1SuccessorMutationStates = new ArrayList<>();

		// Add the current state as a SuccessorState with probability 1
		t1SuccessorMutationStates.add(new Triplet<>(state.toT1MutationStateFactory(), NumberObject.createNumber(model.howToRepresentNumbers, 1), ""));

		// Execute all mutations. 
		// First, execute all extrinsicEvent and age mutations
		for (Mutation m : ledger.mutations) 
			if (!(m instanceof MutationPatchStateChange)) 
				t1SuccessorMutationStates = m.getT1SuccessorStates(t1SuccessorMutationStates);	
				

		// Next, execute all patch state change mutation events
		// For optimization purposes: this does not have to be done if there is only one patch state
		if (model.ledger.numberOfPatchStates != 1)
			for (Mutation m: ledger.mutations)
				if (m instanceof MutationPatchStateChange) 
					t1SuccessorMutationStates = m.getT1SuccessorStates(t1SuccessorMutationStates);

		// If the model wants us to check everything: makes sure that all possible successor state probabilities sum to 1.
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Triplet<T1MutationStateFactory, NumberObjectSingle, String> triplet: t1SuccessorMutationStates)
				if (triplet.b.smallerThan(0, true))
					throw new IllegalStateException("Transition to T1 sucessor state after mutating has a non-positive probability.");
				else
					sum.add(triplet.b, true);

			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability after mutating does not sum to 1.");
		}

		// At the point, all of the postconditions are applied. Some of the resulting ActionStates are no longer alive.
		// We have to sort out which states are dead and which are alive, and register them at the T1StateList
		ArrayList< Path<T1MutationState, T1ActionState>>  	t1SuccessorActionStates = new ArrayList<>();
		ArrayList< Path<T1MutationState, T1FitnessState>>  	t1SuccessorFitnessStates = new ArrayList<>(); // FitnessState is a nice word for saying dead.

		// First, let's create all results from the T1SuccessorStates, and sort them in dead and alive. 
		// We'll also create some paths that link the original state to the new state
		for (Triplet<T1MutationStateFactory, NumberObjectSingle, String> triplet: t1SuccessorMutationStates) {
			if (triplet.a.resultsInDeadState()) {
				// Create a shallow cloned fitness factory
				T1FitnessStateFactory newFitnessStateFactory = new T1FitnessStateFactory(triplet.a, false);

				// Register (if necessary) that fitness factory at the T1StateList, which will turn it into a T1FitnessState
				T1FitnessState newFitnessState = model.getT1StateList().getFitnessState(newFitnessStateFactory );

				// Add to results
				t1SuccessorFitnessStates.add( new Path<T1MutationState, T1FitnessState> (state, newFitnessState, triplet.b, triplet.c, model));
			} else {
				// Create a shallow cloned mutation factory
				T1ActionStateFactory newActionStateFactory = new T1ActionStateFactory(triplet.a, false);

				// Register (if necessary) that action state factory at the T1StateList, which will turn it into a T1MutationState
				T1ActionState newActionState = model.getT1StateList().getActionState(newActionStateFactory);

				// Add to results
				t1SuccessorActionStates.add(new Path<T1MutationState, T1ActionState> ( state, newActionState, triplet.b, triplet.c, model));
			}
		}

		// If the model is strict again, do a test to see if all successor state probabilities sum to 1.
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber (0);
			for (Path<T1MutationState, T1ActionState> p : t1SuccessorActionStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.weight, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.weight.smallerThan(0, true))
					throw new IllegalStateException("After mutating: Transition to T1 action sucessor state after mutation has a non-positive probability.");
				else
					sum.add(p.weight, true);


			for (Path<T1MutationState, T1FitnessState> p : t1SuccessorFitnessStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.weight, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.weight.smallerThan(0, true))
					throw new IllegalStateException("After mutating: Transition to T1 fitness sucessor state after mutation has a non-positive probability.");
				else
					sum.add(p.weight, true);

			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability after mutating binning does not sum to 1.");
		}

		// Put all the ArrayLists of Paths into an Triplet 
		Pair < 
		ArrayList< Path<T1MutationState, T1ActionState>> ,  
		ArrayList< Path<T1MutationState, T1FitnessState>>   > result = new Pair<>(t1SuccessorActionStates,t1SuccessorFitnessStates );

		// Return result
		return result;
	}
	
	/** Execute all mutations in this state. Returns a triplet of ArrayLists containing:  
	 * 
	 * Paths from this state to all T2ActionStates an agent will be in if it survives this mutation.
	 * Paths from this state to all T1FitnessStates an agent will be in if it does not. 
	 * Paths from this state to all T1ActionStates an agent will be in if it survives, but the
	 * 		encounter is terminated (only occurs when the maximum time in the encounter is reached)
	 * 
	 * All extrinsic events are applied once. There is a mortality and interruption check afterwards.
	 * */
	public Triplet < 
	ArrayList< Path<T2MutationState, T2ActionState>>,  
	ArrayList< Path<T2MutationState, T1FitnessState>>,
	ArrayList< Path<T2MutationState, T1ActionState>>> mutateT2MutationState (T2MutationState state, T2DecisionTree tree){

		
		// Create an array list where we will store all temporary T1MutationFactory successor states
		// Note that a mutation both takes and results in MutationStateFactories - that way, mutations can 
		// be stacked together. At the end we will have to change these MutationStateFactories to either T1MutationStates or T1FitnessStates (depending on who died)
		ArrayList< Triplet<T2MutationStateFactory, NumberObjectSingle, String>>  t2SuccessorMutationStateFactories = new ArrayList<>();

		// Add the current state as a SuccessorState with probability 1
		t2SuccessorMutationStateFactories.add(new Triplet<>(state.toT2MutationStateFactory(), NumberObject.createNumber(model.howToRepresentNumbers, 1), ""));

		// Execute all mutations. 
		// First, execute all extrinsicEvent and age mutations
		for (Mutation m : ledger.mutations) 
			if (!(m instanceof MutationPatchStateChange)) 
				t2SuccessorMutationStateFactories = m.getT2SuccessorStates(t2SuccessorMutationStateFactories);	


		// Next, execute all patch state change mutation events
		// For optimization purposes: this does not have to be done if there is only one patch state
		if (model.ledger.numberOfPatchStates != 1)
			for (Mutation m: ledger.mutations)
				if (m instanceof MutationPatchStateChange) 
					t2SuccessorMutationStateFactories = m.getT2SuccessorStates(t2SuccessorMutationStateFactories);

		// If the model wants us to check everything: makes sure that all possible successor state probabilities sum to 1.
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> triplet: t2SuccessorMutationStateFactories)
				if (triplet.b.smallerThan(0, true))
					throw new IllegalStateException("Transition to T2 sucessor state after mutating has a non-positive probability.");
				else
					sum.add(triplet.b, true);

			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability after mutating does not sum to 1.");
		}
		
		
		
		// At the point, all of the postconditions are applied. Some of the resulting ActionStates are no longer alive.
		// We have to sort out which states are dead and which are alive, and register them at the T1StateList
		ArrayList< Path<T2MutationState, T2ActionState>>  	t2SuccessorActionStatePaths = new ArrayList<>();
		ArrayList< Path<T2MutationState, T1FitnessState>>  	t1SuccessorFitnessStatePaths = new ArrayList<>(); // FitnessState is a nice word for saying dead.
		ArrayList< Path<T2MutationState, T1ActionState>>  	t1SuccessorActionStatePaths = new ArrayList<>(); // when reaching the final time step in the encounter
		
		
		// Next, check if the agent has reached the maximum time step of the encounter. 
		// If so, turn the T2MutationState into a T1ActionState, which will be the first
		// state the agent will be in after the encounter.
		if (state.timeInEncounter  >= (model.maximumStepsInEncounter-1)) {// (remember, we incremented the timeInEncounter for the factories already. Hence the -1)

			for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> triplet : t2SuccessorMutationStateFactories) {
				
				// Check if the T2MutationStateFactory is alive. If not, create a T1FitnessState
				if (triplet.a.resultsInDeadState()) {

					// Create a shallow cloned fitness factory
					T1FitnessStateFactory newFitnessStateFactory = new T1FitnessStateFactory(triplet.a, false);

					// Register (if necessary) that fitness factory at the T1StateList, which will turn it into a T1FitnessState
					T1FitnessState newFitnessState = model.getT1StateList().getFitnessState(newFitnessStateFactory );

					// Add to results
					t1SuccessorFitnessStatePaths.add( new Path<T2MutationState, T1FitnessState> (state, newFitnessState, triplet.b, triplet.c, model));
				} else {
					// Create a shallow cloned T1 Action state factory
					T1ActionStateFactory newActionStateFactory = triplet.a.toT1ActionStateFactory();

					// Register (if necessary) that action state factory at the Model's T1StateList, which will turn it into a T1ActionState
					T1ActionState newActionState = model.getT1StateList().getActionState(newActionStateFactory);

					// Add to results
					t1SuccessorActionStatePaths.add(new Path<T2MutationState, T1ActionState> ( state, newActionState, triplet.b, triplet.c, model));
				}
			}
		}
		
		// If its not the final time step...
		else {

			// First, let's create all results from the T1SuccessorStates, and sort them in dead and alive. 
			// We'll also create some paths that link the original state to the new state
			for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> triplet: t2SuccessorMutationStateFactories) {
				if (triplet.a.resultsInDeadState()) {
					// Create a shallow cloned fitness factory
					T1FitnessStateFactory newFitnessStateFactory = new T1FitnessStateFactory(triplet.a, false);

					// Register (if necessary) that fitness factory at the T1StateList, which will turn it into a T1FitnessState
					T1FitnessState newFitnessState = model.getT1StateList().getFitnessState(newFitnessStateFactory );

					// Add to results
					t1SuccessorFitnessStatePaths.add( new Path<T2MutationState, T1FitnessState> (state, newFitnessState, triplet.b, triplet.c, model));
				} else {
					// Create a shallow cloned mutation factory
					T2ActionStateFactory newActionStateFactory = new T2ActionStateFactory(triplet.a, false);

					// Register (if necessary) that action state factory at the Decision Tree's T2StateList, which will turn it into a T1ActionState
					T2ActionState newActionState = tree.treeStateList.getActionState(newActionStateFactory);

					// Add to results
					t2SuccessorActionStatePaths.add(new Path<T2MutationState, T2ActionState> ( state, newActionState, triplet.b, triplet.c, model));
				}
			}
		}
		
		// If the model is strict again, do a test to see if all successor state probabilities sum to 1.
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber (0);
			
			for (Path<T2MutationState, T2ActionState> p : t2SuccessorActionStatePaths)
				if (p.weight.smallerThan(0, true))
					throw new IllegalStateException("After mutating: Transition to T2 action sucessor state after mutation has a non-positive probability.");
				else
					sum.add(p.weight, true);


			for (Path<T2MutationState, T1FitnessState> p : t1SuccessorFitnessStatePaths)
				if (p.weight.smallerThan(0, true))
					throw new IllegalStateException("After mutating: Transition to T1 fitness sucessor state after T2 mutation has a non-positive probability.");
				else
					sum.add(p.weight, true);

			for (Path<T2MutationState, T1ActionState> p : t1SuccessorActionStatePaths)
				if (p.weight.smallerThan(0, true))
					throw new IllegalStateException("After mutating: Transition to T1 action sucessor state after T2 mutation has a non-positive probability.");
				else
					sum.add(p.weight, true);

			
			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability after mutating binning does not sum to 1. Sum = " + sum.toStringWithoutTrailingZeros());
		}

		// Put all the ArrayLists of Paths into an Triplet 
		return new Triplet < 
				ArrayList< Path<T2MutationState, T2ActionState>>,  
				ArrayList< Path<T2MutationState, T1FitnessState>>,
				ArrayList< Path<T2MutationState, T1ActionState>>> (t2SuccessorActionStatePaths, t1SuccessorFitnessStatePaths, t1SuccessorActionStatePaths);
		
		
	}
	
	
	/** Execute all mutations in this T2ActionStateFactory. Should only be used for the T2ActionPostconditionPostpone classes.
	 * This function should only be used when postponing. Note, there is no check whether resulting factories result in dead
	 * states. */
	private ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> mutateT2ActionStateFactory (Triplet<T2ActionStateFactory, NumberObjectSingle, String> currentT2ActionStateFactory){
		
		// Create an array list where we will store all temporary Triplets.
		ArrayList< Triplet<T2ActionStateFactory, NumberObjectSingle, String>>  resultingT2ActionStateFactories = new ArrayList<>();

		// Add the currentT2ActionStateFactory to resultingT2ActionStateFactories
		resultingT2ActionStateFactories.add(currentT2ActionStateFactory);
		
		// Execute all mutations. 
		// First, execute all extrinsicEvent and age mutations
		for (Mutation m : ledger.mutations) 
			if (!(m instanceof MutationPatchStateChange)) 
				resultingT2ActionStateFactories = m.getT2SuccessorStatesForActionStateFactory(resultingT2ActionStateFactories);

		// Next, execute all patch state change mutation events
		// For optimization purposes: this does not have to be done if there is only one patch state
		if (model.ledger.numberOfPatchStates != 1)
			for (Mutation m: ledger.mutations)
				if (m instanceof MutationPatchStateChange) 
					resultingT2ActionStateFactories = m.getT2SuccessorStatesForActionStateFactory(resultingT2ActionStateFactories);

		// If the model wants us to check everything: make sure that all possible successor state probabilities sum to the NumberObjectSingle supplied in currentT2ActionStateFactory.
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Triplet<T2ActionStateFactory, NumberObjectSingle, String> triplet: resultingT2ActionStateFactories)
				if (triplet.b.smallerThan(0, true))
					throw new IllegalStateException("Transition to T2ActionStateFactory after mutating has a non-positive probability.");
				else
					sum.add(triplet.b, true);

			if (!sum.equals(currentT2ActionStateFactory.b, true))
				throw new IllegalStateException("Transition probability after mutating T2ActionStateFactory does not sum to supplied probability.");
		}

		return resultingT2ActionStateFactories;
		
	}
	
	
	/** Applies all possible mutations to 1 T2ActionFactory 1 time. Essentially, the agent goes
	 * through n mutation states without going through any action states. This function should be used
	 * only for when an agent postpones n times. Note that all extrinsic events are applied in batches. For 
	 * instance, suppose that n = 2, and there are three types of extrinsic events (not counting extrinsic events
	 * that influence the resource, delay, or interruption): A, B, and C. If so, the follow order of extrinsic
	 * events is applied:
	 * 
	 * A, B, C, A, B, C.
	 * 
	 *  Note that the resulting triplet does not contain States yet - it only returns StateFactories. These factories are
	 *  not necessarily 'alive'; rather, some of them might result in dead states. This is because this function should only
	 *  be used by the Postponing postcondition. And action postconditions do not return full states, only factories. */
	private Pair<	ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, 
					ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> mutateSingleT2ActionFactory(
									Pair<T2ActionStateFactory, NumberObjectSingle> currentT2ActionStateFactory) {

		// Create two ArrayLists to store the final results in
		ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> t2ActionStateFactories = new ArrayList<>();
		ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>> resultingT1MutationStateFactories = new ArrayList<>();
		
		// Add the currentT2ActionStateFactories to resultingT2ActionStateFactories
		t2ActionStateFactories.add(currentT2ActionStateFactory);

		// Next, apply all mutations to the not-interrupted T2ActionStateFactories 
		// Ok, what we could do - and what I started with - was to implement all mutations in a way that they can also handle T2ActionStateFactories.
		// However, there is an easier workaround: rather than implementing the same stuff for T2ActionStateFactoriess, let's just
		// create a T2MutationStateFactory for each T2ActionStateFactory, apply the Mutation to that new Factory, and
		// afterwards transform it back again! So, that's why the Mutation class has a getT2SuccessorStatesForActionStateFactory
		// function.
		// First, let's create, for each T2ActionStateFactory in afterInterruption, a new triplet, consisting of:
		// 		A. The T2ActionStateFactory,
		//		B. The probability that an agent will go be in a state represented by the T2ActionStateFactory, and finally,
		//		C. An empty string that will be filled up with some annotations (used for debugging purposes)
		ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> currentActionStatesInTripletForm = new ArrayList<>();
		for ( Pair<T2ActionStateFactory, NumberObjectSingle> pair : t2ActionStateFactories) {
			Triplet<T2ActionStateFactory, NumberObjectSingle, String> entry = new Triplet<T2ActionStateFactory, NumberObjectSingle, String>(
					pair.element1,
					pair.element2,
					"");
			currentActionStatesInTripletForm.add(entry);
		}

		// Next, create a storage to contain all new T2ActionStateFactories that will have gone through the Mutation
		ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> resultingT2ActionStateFactories = new ArrayList<>();

		// Next, we feed each Triplet into mutateT2ActionStateFactory().
		// This function executes the Mutations to the T2ActionStateFactory, and returns
		// an arraylist of Triplets that contain the resulting T2ActionStateFactory, the probability 
		// that an agent ends up there, and some annotations again. We can store the first two in 
		// a Pair, and add that pair to resultingT2ActionStateFactories
		for (Triplet<T2ActionStateFactory, NumberObjectSingle, String> entry : currentActionStatesInTripletForm) {
			// Apply the mutations
			ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> factoriesAfterMutation = mutateT2ActionStateFactory (entry);

			// Put each result in a Pair and add the pair to resultingT2ActionStateFactories
			for (Triplet<T2ActionStateFactory, NumberObjectSingle, String> facTriplet : factoriesAfterMutation)
				resultingT2ActionStateFactories.add(new Pair<T2ActionStateFactory, NumberObjectSingle>(facTriplet.a, facTriplet.b));
		}

		// Finally, if the model wants us to check everything: 
		// makes sure that all possible successor state probabilities sum to the NumberObjectSingle provided in currentT2ActionStateFactories
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> pair: resultingT2ActionStateFactories)
				if (pair.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T2ActionStateFactory after mutating has a non-positive probability.");
				else
					sum.add(pair.element2, true);
			
			for (Pair<T1MutationStateFactory, NumberObjectSingle> pair: resultingT1MutationStateFactories)
				if (pair.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T1MutationStateFactory after mutating has a non-positive probability.");
				else
					sum.add(pair.element2, true);

			if (!sum.equals(currentT2ActionStateFactory.element2, true))
				throw new IllegalStateException("Transition probability after mutating T2ActionStateFactory does not sum to supplied probability.");
		}
		
		// After we're done with this loop, we can return a pair containing resultingT2ActionStateFactories and resultingT2ActionStateFactories
		return new  Pair<	ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, 
				ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>>(resultingT2ActionStateFactories, resultingT1MutationStateFactories);
	
	}
	
	
	/** Applies all possible mutations to n T2ActionFactory 1 time. Returns all possible T1MutationStateFactories and T2ActionStateFactories. See javadoc above for more information.  */
	public Pair<	ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, 
					ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> mutateAllT2ActionFactories(ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> 
					currentT2ActionStateFactories) {

		// First, create a storage for all T1MutationStateFactories
		ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>> allT1States = new ArrayList<>();
		
		// Second, a storage for all T2ActionStateFactories 
		ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> allT2States = new ArrayList<>();
		
		// Apply mutateSingleT2ActionFactory to each Pair of <T2ActionStateFactory, NumberObjectSingle>, and store the results in the two arrayLists
		for (Pair<T2ActionStateFactory, NumberObjectSingle> p : currentT2ActionStateFactories) {
			 Pair<	ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, 
				ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> results = mutateSingleT2ActionFactory(p);
			 // Save to the two arrayLists
			 allT2States.addAll(results.element1);
			 allT1States.addAll(results.element2);
		}
		
		// Return the two arrayLists
		return new  Pair<	ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, 
				ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>>(allT2States, allT1States);
	}
	

}
