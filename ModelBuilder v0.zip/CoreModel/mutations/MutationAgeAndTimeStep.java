package mutations;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper.Triplet;
import states.EncounterStates.T2ActionStateFactory;
import states.EncounterStates.T2MutationStateFactory;
import states.RoamingStates.T1MutationStateFactory;

/** Increases the age by 1*/
public class MutationAgeAndTimeStep extends Mutation {

	protected MutationAgeAndTimeStep() {}
	@Override
	public ArrayList<Triplet<T1MutationStateFactory, NumberObjectSingle, String>> getT1SuccessorStates(
		   ArrayList<Triplet<T1MutationStateFactory, NumberObjectSingle, String>> currentStates) {
		for (Triplet<T1MutationStateFactory, NumberObjectSingle, String> triplet : currentStates)
			triplet.a.incrementAge();
		return currentStates;
	}

	@Override
	public ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> getT2SuccessorStates(
		   ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> currentStates) {
		for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> triplet: currentStates) {
			triplet.a.incrementAge();
			triplet.a.incrementTimeStep();
		}
		return currentStates;
	}
	
	
	@Override
	public ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> getT2SuccessorStatesForActionStateFactory(
		   ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> currentStates) {
		for (Triplet<T2ActionStateFactory, NumberObjectSingle, String> triplet: currentStates) {
			triplet.a.incrementAge();
			triplet.a.incrementTimeStep();
		}
		return currentStates;
	}
	
	
	@Override
	public String toString() {
		return "Agents age";
	}
	@Override
	public int hashCode() {
		return 1;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		return true;
	}

}
