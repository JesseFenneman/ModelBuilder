package mutations;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.Model;
import helper.Helper.Triplet;
import states.EncounterStates.T2ActionStateFactory;
import states.EncounterStates.T2MutationStateFactory;
import states.RoamingStates.T1MutationStateFactory;

/** Changes an Agent's phenotype based on the extrinsic event it encounters.
 * Which extrinsic event it encounters depends on the patch state it is currently in. */
public class MutationExtrinsicEvent extends Mutation {
	
	
	private final Model model;
	private final int extrinsicIndex, phenotypeIndex;
	
	
	/** Create a new Mutation where the extrinsic events affects the phenotype*/
	protected MutationExtrinsicEvent(Model model, int extrinsicIndex, int phenotypeIndex) {
		this.model = model;
		this.extrinsicIndex = extrinsicIndex; this.phenotypeIndex = phenotypeIndex;
	}

	@Override
	public ArrayList<Triplet<T1MutationStateFactory, NumberObjectSingle, String>> getT1SuccessorStates(
		   ArrayList<Triplet<T1MutationStateFactory, NumberObjectSingle, String>> currentStates) {
	
		// Create a new ArrayList to store all resulting states in
		ArrayList< Triplet<T1MutationStateFactory, NumberObjectSingle, String> > successorStates = new ArrayList<>();

		// For each current state s:
		for (Triplet<T1MutationStateFactory, NumberObjectSingle, String> originalTriplet: currentStates) {
			T1MutationStateFactory factoryOriginal = originalTriplet.a;
			
			// First, figure out the probability that an extrinsic event occurs at all
			NumberObjectSingle probabilityOfExtrinsicOccuring = model.ledger.patchStates[factoryOriginal.locationPatchState].extrinsicFrequencies[extrinsicIndex];
		
			// Second, retrieve the probability distribution for extrinsic events in this patch (Note, we do not need to know the value of
			// the extrinsic event - the index position in the Ledger's extrinsic event value array is sufficient)
			NumberObjectSingle[] probabilityDistribution = model.ledger.patchStates[factoryOriginal.locationPatchState].extrinsicValueProbabilities[extrinsicIndex];
			
			// Third, in case the extrinsic did not happen, nothing in the state changes. 
			// (Ignore if extrinsics have a frequency of 0)
			// Hence, create a clone of the factory, and add it to the results. The probability of this
			// new factory is (probabilityOldFactory) * probabilityOfExtrnsicNotOccuring
			if (!probabilityOfExtrinsicOccuring.equals(1)) {
				T1MutationStateFactory factoryNoExtrinsic = new T1MutationStateFactory(factoryOriginal, true);
				NumberObjectSingle probabilityOfExtrnsicNotOccuring = probabilityOfExtrinsicOccuring.complementOfOne(false);
				
				// Create the annotation
				String annotation = originalTriplet.c;
				if (annotation.isEmpty())
					annotation = annotation + " + ";
				annotation = annotation + "No " + model.ledger.extrinsicNames[extrinsicIndex];
				
				// Create the successor state in case that there is no extrinsic event
				successorStates.add(new Triplet<>(
						factoryNoExtrinsic, 
						probabilityOfExtrnsicNotOccuring.multiply(originalTriplet.b, true),
						annotation
						));
			}
			
			// Fourth, for each possible extrinsic event value:
			//		Clone the original factory
			//		Change the phenotype based on the extrinsic event value
			//		store in successorStates, where probability = (probabilityOldFactory) * probabilityOfExtrinsicOccuring * probabilityDistribution[extrinsic event value]
			// (Ignore if the extrinsic event has a frequency of 0)
			if (!probabilityOfExtrinsicOccuring.equals(0)) {
				for (int e = 0; e < probabilityDistribution.length; e++) {
					T1MutationStateFactory factoryNew = new T1MutationStateFactory(factoryOriginal, true);

					// Set the phenotype
					int phenotypeCurrentValueIndex= factoryNew.phenotype[phenotypeIndex];
					factoryNew.phenotype[phenotypeIndex] = model.ledger.indexOfPhenotypeAfterAddingExtrinsic(phenotypeIndex, phenotypeCurrentValueIndex, extrinsicIndex, e);

					// Figure out the probability of the agent being in this successor state
					NumberObjectSingle newProbability = originalTriplet.b.multiply(probabilityOfExtrinsicOccuring, false).multiply(probabilityDistribution[e], false);

					// Create annotation
					String annotation = originalTriplet.c;
					if (!annotation.isEmpty())
						annotation = annotation + " + ";
					annotation = annotation + model.ledger.extrinsicNames[extrinsicIndex]+"=["+ e+"]";
					
					// Do some checks
					if (model.performSafetyChecks)
						if (newProbability.equals(0))
							throw new IllegalStateException("Created path with 0 probability after extrinsic event mutation. ");
					
					// Save successor state
					successorStates.add(new Triplet<>(factoryNew, newProbability, annotation));
				}
			}
		}
		
		return successorStates;

	}

	@Override
	public ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> getT2SuccessorStates(
		   ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> currentStates) {
		
		// Create a new ArrayList to store all resulting states in
		ArrayList< Triplet<T2MutationStateFactory, NumberObjectSingle, String> > successorStates = new ArrayList<>();

		// For each current state s:
		for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> originalTriplet: currentStates) {
			T2MutationStateFactory factoryOriginal = originalTriplet.a;

			// First, figure out the probability that an extrinsic event occurs at all
			NumberObjectSingle probabilityOfExtrinsicOccuring = model.ledger.patchStates[factoryOriginal.locationPatchState].extrinsicFrequencies[extrinsicIndex];
		
			// Second, retrieve the probability distribution for extrinsic events in this patch (Note, we do not need to know the value of
			// the extrinsic event - the index position in the Ledger's extrinsic event value array is sufficient)
			NumberObjectSingle[] probabilityDistribution = model.ledger.patchStates[factoryOriginal.locationPatchState].extrinsicValueProbabilities[extrinsicIndex];
			
			// Third, in case the extrinsic did not happen, nothing in the state changes. 
			// (Ignore if extrinsics have a frequency of 0)
			// Hence, create a clone of the factory, and add it to the results. The probability of this
			// new factory is (probabilityOldFactory) * probabilityOfExtrnsicNotOccuring
			if (!probabilityOfExtrinsicOccuring.equals(1)) {
				T2MutationStateFactory factoryNoExtrinsic = new T2MutationStateFactory(factoryOriginal, true);
				NumberObjectSingle probabilityOfExtrnsicNotOccuring = probabilityOfExtrinsicOccuring.complementOfOne(false);
				
				// Create the annotation
				String annotation = originalTriplet.c;
				if (annotation.isEmpty())
					annotation = annotation + " + ";
				annotation = annotation + "No " + model.ledger.extrinsicNames[extrinsicIndex];
				
				// Create the successor state in case that there is no extrinsic event
				successorStates.add(new Triplet<>(
						factoryNoExtrinsic, 
						probabilityOfExtrnsicNotOccuring.multiply(originalTriplet.b, true),
						annotation
						));
			}
			
			// Fourth, for each possible extrinsic event value:
			//		Clone the original factory
			//		Change the phenotype based on the extrinsic event value
			//		store in successorStates, where probability = (probabilityOldFactory) * probabilityOfExtrinsicOccuring * probabilityDistribution[extrinsic event value]
			// (Ignore if the extrinsic event has a frequency of 0)
			if (!probabilityOfExtrinsicOccuring.equals(0)) {
				for (int e = 0; e < probabilityDistribution.length; e++) {
					T2MutationStateFactory factoryNew = new T2MutationStateFactory(factoryOriginal, true);

					// Set the phenotype
					int phenotypeCurrentValueIndex= factoryNew.phenotype[phenotypeIndex];
					factoryNew.phenotype[phenotypeIndex] = model.ledger.indexOfPhenotypeAfterAddingExtrinsic(phenotypeIndex, phenotypeCurrentValueIndex, extrinsicIndex, e);

					// Figure out the probability of the agent being in this successor state
					NumberObjectSingle newProbability = originalTriplet.b.multiply(probabilityOfExtrinsicOccuring, false).multiply(probabilityDistribution[e], false);

					// Create annotation
					String annotation = originalTriplet.c;
					if (!annotation.isEmpty())
						annotation = annotation + " + ";
					annotation = annotation + model.ledger.extrinsicNames[extrinsicIndex]+"=["+ e+"]";
					
					// Do some checks
					if (model.performSafetyChecks)
						if (newProbability.equals(0))
							throw new IllegalStateException("Created path with 0 probability after extrinsic event mutation. ");
					
					// Save successor state
					successorStates.add(new Triplet<>(factoryNew, newProbability, annotation));
				}
			}
		}
		
		return successorStates;
	}
	
	@Override
	public ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> getT2SuccessorStatesForActionStateFactory(
		   ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> currentStates) {
		
		// Here's a hacky workaround: rather than implementing the same stuff for T2ActionStateFactoriess, let's just
		// create a T2MutationStateFactory for each T2ActionStateFactory, apply the Mutation to that new Factory, and
		// afterwards transform it back again!
		
		// Transform: Action -> Mutation
		ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> currentStatesInMutationForm = new ArrayList<>();
		for (Triplet<T2ActionStateFactory, NumberObjectSingle, String> actionFactoryEntry : currentStates) 
			currentStatesInMutationForm.add(new Triplet<T2MutationStateFactory, NumberObjectSingle, String>(
					actionFactoryEntry.a.toT2MutationStateFactory(),
					actionFactoryEntry.b,
					actionFactoryEntry.c));
		
		// Apply mutation
		ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> afterMutations = this.getT2SuccessorStates(currentStatesInMutationForm);
		
		// Transform Mutation -> Action
		ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> nextStatesInActionForm = new ArrayList<>();
		for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> mutationFactoryEntry : afterMutations) 
			nextStatesInActionForm.add(new Triplet<T2ActionStateFactory, NumberObjectSingle, String>(
					mutationFactoryEntry.a.toT2ActionStateFactory(),
					mutationFactoryEntry.b,
					mutationFactoryEntry.c));
		
		// Return!
		return nextStatesInActionForm;
		
	}
	
	

	@Override
	public String toString() {
		return "Extrinsic event [" + this.extrinsicIndex + "] affects an agent's phenotype ["+ this.phenotypeIndex+ "] ";
	}

	@Override
	public int hashCode() {
		int result = 1;
		result = result + extrinsicIndex*10;
		result = result + phenotypeIndex*100;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		MutationExtrinsicEvent other = (MutationExtrinsicEvent) obj;
		if (extrinsicIndex != other.extrinsicIndex) {
			return false;
		}
		if (phenotypeIndex != other.phenotypeIndex) {
			return false;
		}
		return true;
	}
}
