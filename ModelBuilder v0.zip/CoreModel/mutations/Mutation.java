package mutations;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.LedgerFactory;
import core.Model;
import helper.Helper.Triplet;
import mutationElements.PhenotypeMutationTemplate;
import states.EncounterStates.T2ActionStateFactory;
import states.EncounterStates.T2MutationStateFactory;
import states.RoamingStates.T1MutationStateFactory;

/** A mutation is a change in the environment that an agent 
 * cannot control. There are four separate types of Mutations:
 * 
 * 1. Aging. After each action the agent ages by 1 unit of time. Aging is deterministic; it always happens. 
 * 2. Extrinsic events  that affect phenotypes - at every moment, an extrinsic event can probablistically change an agent's sate
 * 3. Patch State mutations, where a patch can change between states;
 * 4. Non-phenotype object mutations. During an encounter the resource, delay, or interruption can change 
 * 		deterministically over time. Note: in future versions this might become stochastic rather than
 * 		deterministic..
 * 
 * The first three are handled by the StateMutator, that changes MutationStates to ActionStates. The fourth
 * is handled by the ObjectMutator, that stores all possible resource values/delay durations/interruption probabilities
 * after t times steps in an encounter, given a starting value/duration/probability. (IMPORTANT: resources, delays,
 * and interruptions do not actually change in value during the encounter. Instead, when we have to use these values,
 * we take the mutation into account. See the ObjectMutator class javadoc for more information). 
 * */
public abstract class Mutation {
	
	/** Create a Mutation where an extrinsic event influences a phenotypic state*/
	public static MutationExtrinsicEvent createMutationExtrinsicEvent (Model model, PhenotypeMutationTemplate template, LedgerFactory ledgerFactory) {

		// Find the phenotypeIndex
		int phenotypeIndex = -1;
		for (int i =0; i < ledgerFactory.phenotypeNames.size(); i ++)
			if (ledgerFactory.phenotypeNames.get(i).equals(template.phenotype.getName()))
				phenotypeIndex = i;
		if (phenotypeIndex == -1)
			throw new IllegalStateException("Trying to create an extrinsic-phenotype mutation for a phenotype that is not registered (yet). Looking for name " + template.phenotype.getName());

		// Find the extrinsicIndex
		int extrinsicIndex = -1;
		for (int i =0; i < ledgerFactory.extrinsicNames.size(); i ++)
			if (ledgerFactory.extrinsicNames.get(i).equals(template.extrinsic.getName()))
				extrinsicIndex = i;
		if (extrinsicIndex == -1)
			throw new IllegalStateException("Trying to create an extrinsic-phenotype mutation for an extrinsic event that is not registered (yet). Looking for name " + template.extrinsic.getName());
		
		return new MutationExtrinsicEvent(model, extrinsicIndex,phenotypeIndex);
	}
	
	/** Create a Mutation that increases an agent's age*/
	public static MutationAgeAndTimeStep createMutationAge() {
		return new MutationAgeAndTimeStep();
	}
	
	/** Create a Mutation that increases an last-time-since-patch-visit*/
	public static MutationPatchStateChange createMutationPatchStateChange(Model model) {
		return new MutationPatchStateChange(model);
	}
	
	 /** Takes as input an ArrayList of Triplets that combine a T1 currentState (in factory form), a probability of an agent
	  * being in that current state, and a String that contains optional annotations. This function 
	  * returns an ArrayList of Triplets that combine successor states (in factory forms) that
	  * an agent will be in if it started in the currentStates and went through this mutation.
	  * Patch state change mutations and extrinsic event mutations should add some annotation to make it easier
	  * to understand what the decision tree is 'doing'. 
	  * 
	 * The input currentState is a list of triplets. Note that, by definition, a mutation only occurs in a MutationState. 
	 * You might wonder two things: first, why is the input an array of multiple MutationStates rather than a single state, a
	 * only one state mutates at a time. The reason for this is that there might be multiple Mutations, which all have to be applied. 
	 * Note, these factories have not yet turned into states, and are not registered in the 
	 * T1StateList yet!
	 * 
	 * Second, why is the return an arrayList of MutationStates, and not ActionStates? The answer to that
	 * is similar to the answer above: the output of one postcondition might still have to go through
	 * another postcondition. Hence, we'll leave it to the StateMutator to switch a MutationState to an
	 * ActionState
	 * */
	public abstract ArrayList< Triplet<T1MutationStateFactory, NumberObjectSingle, String>> getT1SuccessorStates( 
					ArrayList< Triplet<T1MutationStateFactory, NumberObjectSingle, String>> currentStates);

	/** Takes as input an ArrayList of Triplets that combine a T2 current MutationState (in factory form), a probability of an agent
	  * being in that current mutation state, and a String that contains options annotations. This function 
	  * returns an ArrayList of Triplets that combine successor states (in factory forms) that
	  * an agent will be in if it started in the currentStates and went through this mutation.
	  * Patch state change mutations and extrinsic event mutations should add some annotation to make it easier
	  * to understand what the decision tree is 'doing'. 
	  * 
	 * The input currentState is a list of triplets. Note that, by definition, a mutation only occurs in a MutationState. 
	 * You might wonder two things: first, why is the input an array of multiple MutationStates rather than a single state, a
	 * only one state mutates at a time. The reason for this is that there might be multiple Mutations, which all have to be applied. 
	 * Note, these factories have not yet turned into states, and are not registered in any T2StateList yet!
	 * 
	 * Second, why is the return an arrayList of MutationStates, and not ActionStates? The answer to that
	 * is similar to the answer above: the output of one postcondition might still have to go through
	 * another postcondition. Hence, we'll leave it to the StateMutator to switch a MutationState to an
	 * ActionState
	 * */
	public abstract ArrayList< Triplet<T2MutationStateFactory, NumberObjectSingle, String>> getT2SuccessorStates( 
					ArrayList< Triplet<T2MutationStateFactory, NumberObjectSingle, String>> currentStates);

	/** Takes as input an ArrayList of Triplets that combine a T2ActionState (in factory form), a probability of an agent
	  * being in that action state, and a String that contains optional annotations. THIS FUNCTION SHOULD 
	  * BE USED ONLY FOR POSTPONING POSTCONDITIONS. It works the same way as the getT2SuccessorStates() function above.
	  * In principle, this function is used to put the ActionState through one round of mutations. Note, this is a workaround:
	  * it transforms the T2ActionStateFactory into a T2MutationStateFactory, then applies the transformations, and finally,
	  * transforms the T2MutationStateFactories back into T2ActionStateFactories.
	 * */
	public ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> getT2SuccessorStatesForActionStateFactory(
		   ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> currentStates) {
		
		// Here's a hacky workaround: rather than implementing the same stuff for T2ActionStateFactoriess, let's just
		// create a T2MutationStateFactory for each T2ActionStateFactory, apply the Mutation to that new Factory, and
		// afterwards transform it back again!
		
		// Transform: Action -> Mutation
		ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> currentStatesInMutationForm = new ArrayList<>();
		for (Triplet<T2ActionStateFactory, NumberObjectSingle, String> actionFactoryEntry : currentStates) 
			currentStatesInMutationForm.add(new Triplet<T2MutationStateFactory, NumberObjectSingle, String>(
					actionFactoryEntry.a.toT2MutationStateFactory(),
					actionFactoryEntry.b,
					actionFactoryEntry.c));
		
		// Apply mutation
		ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> afterMutations = this.getT2SuccessorStates(currentStatesInMutationForm);
		
		// Transform Mutation -> Action
		ArrayList<Triplet<T2ActionStateFactory, NumberObjectSingle, String>> nextStatesInActionForm = new ArrayList<>();
		for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> mutationFactoryEntry : afterMutations) 
			nextStatesInActionForm.add(new Triplet<T2ActionStateFactory, NumberObjectSingle, String>(
					mutationFactoryEntry.a.toT2ActionStateFactory(),
					mutationFactoryEntry.b,
					mutationFactoryEntry.c));
		
		// Return!
		return nextStatesInActionForm;
		
	}
	@Override
	public abstract String toString() ;
	
	@Override
	public abstract int hashCode();

	@Override
	public abstract boolean equals(Object obj) ;
	
}
