package actions.Preconditions;

import core.AbstractModel;
import states.Abstract.AbstractState;

/** A precondition is a requirement that must be true
 * before an action can be taking in a state.*/
public abstract class ActionPrecondition {

	/** The model where this Precondition takes place in*/
	public final AbstractModel model;

	
	protected ActionPrecondition(AbstractModel model) {
		this.model=model;
	}
	
	/** Returns true if the state fulfills this precondition*/
	public abstract boolean isMet(AbstractState s);
	
	public abstract String toString();
	
}
