package belief;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.AbstractModel;
import core.AbstractModel.EncounteredInstantiatedObjectClass;
import patch.PatchState;

/** During runtime, an agent repeatedly comes across objects
 * that can have some values. These objects include resources,
 * interruptions, delays, and extrinsic events. When encountering
 * an object, a single object is drawn from the distribution of 
 * objects in the environment. This drawn object is called an 
 * instantiated object. 
 * 
 * The actual probability distribution of an object depends
 * on the PatchState than an agent is in. However, an agent
 * often has a 'subjective' belief about what the probability
 * distribution of these values is. This belief is called a
 * prior belief. 
 * 
 * If an agent already knows the distribution of objects in 
 * a given patch state, the prior belief is the same as the
 * probability distribution in the PatchState - although
 * an agent might encounter an object of value X, this experience
 * does not change it's belief about the probability distribution
 * of objects in that patch state.
 * 
 * If an agent does NOT know the distribution of objects in 
 * a given patch state - that is, it has to learn this distribution
 * via experience - an agent can use new experiences to update
 * its prior belief. Note that it is still called an updated prior
 * belief (rather than a posterior belief), as this is the updated
 * prior belief for the next time the agent encounters an object
 * of the specified type in the patch state.*/
public class PriorBelief {

	private final AbstractModel model;
	
	/** Beliefs depend on the PatchState*/
	private final PatchState patchState;
	
	/** Each belief refers to a specific object that is encountered. Is this object a resource, delay, or interruption?*/
	private final EncounteredInstantiatedObjectClass objectClass;
	
	/** Each belief refers to a specific object that is encountered. What is the index position of this object in the ledger?*/
	private final  int objectIndex;
	
	/** An object is constant if there is only a single
	 * possible value for that object.*/
	private final boolean objectIsConstant;
	
	/** Is the distribution of this resource known? If so,
	 * the subjective probability of an object's value is the same as 
	 * the actual probability distribution of that object in the patch state*/
	private final boolean knownDistribution;
	
	/** The current belief about the distribution of objects in the 
	 * PatchState. This object is only used for objects that are
	 * neither constant (i.e., have only one value) nor which
	 * distribution is known (in which case the prior is the same as the 
	 * PatchState objective distribution).*/
	private final NumberObjectSingle[] belief;
	
	public PriorBelief (AbstractModel model, int patchStateIndex, EncounteredInstantiatedObjectClass objectClass, int objectIndex ) {
		this.model = model;
		this.patchState = model.ledger.patchStates[patchStateIndex];
		this.objectClass = objectClass;
		this.objectIndex=objectIndex;
		
		// What to do if this belief is about an instantiated resource
		if (objectClass == EncounteredInstantiatedObjectClass.RESOURCE) {
			
			// If the resource is constant, there is only one belief: the only value has a probability of 1.
			if (model.ledger.resourceIsConstant[objectIndex]) {
				this.objectIsConstant=true;
				this.knownDistribution=false;
				this.belief = new NumberObjectSingle[] {NumberObject.createNumber(model.howToRepresentNumbers, 1)};
				this.belief[0].makeImmutable();
			}
			
			// If the resource is NOT constant but the distribution is known, the prior belief is the same as the 
			// probability in the patch state
			else if (patchState.resourceDistributionKnown[objectIndex]) {
				this.objectIsConstant= false;
				this.knownDistribution=true;
				this.belief = model.ledger.patchStates[patchState].resourceValueProbability[objectIndex];
			}
			
			// Finally, if the resource is NOT constant and the distribution is NOT known
		
		}
	}
}
