package belief;

import java.util.Arrays;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import attributes.AttributeField;
import core.AbstractModel;
import core.AbstractModel.InstantiatedObjectClass;
import core.LedgerFactory;
import helper.Helper;
import interfaces_abstractions.ObserverManager;
import objectiveElements.CueLabel;
import objectiveElements.CueTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.ResourceObjectTemplate;

/** A cue provides stochastic information on the value of an 
 * instantiated delay, or interruption. To be clear, only
 * instantiated objects can emit a Cue, and each instance
 * of the Cue class is attached to a single instantiated object.
 * In this class, the object that a Cue is attached to is called
 * the parent of the Cue.*/
public class Cue {
	
	/** Cues are emitted by instantiated objects. What kind of 
	 * object is emitting this cue type? Your options are:
	 * resources, delays, or interruptions. Extrinsic events
	 * occur regardless of an agent's actions, and cannot be sampled.*/
	public final InstantiatedObjectClass parentObjectClass;
	
	
	/** What is the probability of emitting a Cue with a specified
	 * cue label, conditional on the value of the parent? Formally:
	 * P(Cue = Cue Label | Parent = parent value). This 2D array
	 * is organized as [object value][cue label].*/
	public final NumberObjectSingle[][] emissionProbabilities; // [object value][cue label]
	
	/** What is the maximum number of times an agent can sample this cue?*/
	public final int maximumNumberOfTimesAnAgentCanSampleThisCue;
	
	/** The model that uses this Cue.*/
	private final AbstractModel model;
	
	/** Create a new Cue. Note that the object that emits this cue should already be registered in the LedgerFactory */
	public Cue (CueTemplate template, LedgerFactory ledgerFactory, AbstractModel model) {
		String[] orderOfCueLabels = null;
		this.model = model;
		
		// Set the parentObjectClass
		if (template.object instanceof ResourceObjectTemplate)
			this.parentObjectClass= InstantiatedObjectClass.RESOURCE;
		else if (template.object instanceof DelayObjectTemplate)
			this.parentObjectClass = InstantiatedObjectClass.DELAY;
		else if (template.object instanceof InterruptionObjectTemplate)
			this.parentObjectClass = InstantiatedObjectClass.INTERRUPTION;
		else
			throw new IllegalStateException("Objects of type '" + template.object + "' cannot emit cues.");
		

		// First, the cue registers itself in the ledgerFactory 
		synchronized (ledgerFactory) {
			
			// Before anything, check if the number of cues and cue labels in the ledger factory matches
			if (ledgerFactory.resourceCues.size() != ledgerFactory.resourceCueLabels.size())
				throw new IllegalStateException("There is an unequal number of resource cues and resource cue labels in the factory ledger before creating a new cue. ");
			if (ledgerFactory.delayCues.size() != ledgerFactory.delayCueLabels.size())
				throw new IllegalStateException("There is an unequal number of delay cues and delay cue labels in the factory ledger before creating a new cue. ");
			if (ledgerFactory.interruptionCues.size() != ledgerFactory.interruptionCueLabels.size())
				throw new IllegalStateException("There is an unequal number of interruption cues and interruption cue labels in the factory ledger before creating a new cue. ");

			// Register the cue - that is, do all the work required to place this cue in the LedgerFactory.
			// The function register...Cue performs this action, and returns the order of the cue labels in 
			// the LedgerFactory. We will use this order below.
			if (this.parentObjectClass == InstantiatedObjectClass.RESOURCE)
				orderOfCueLabels = registerResourceCue(template, ledgerFactory);
			else if (this.parentObjectClass == InstantiatedObjectClass.DELAY)
				orderOfCueLabels = registerDelayCue(template, ledgerFactory);
			else if (this.parentObjectClass == InstantiatedObjectClass.INTERRUPTION)
				orderOfCueLabels = registerInterruptionCue(template, ledgerFactory);
	
			// After registration, check if the number of cues and cue names still matches
			if (ledgerFactory.resourceCues.size() != ledgerFactory.resourceCueLabels.size())
				throw new IllegalStateException("There is an unequal number of resource cues and resource cue labels in the factory ledger after creating a new cue. ");
			if (ledgerFactory.delayCues.size() != ledgerFactory.delayCueLabels.size())
				throw new IllegalStateException("There is an unequal number of delay cues and delay cue labels in the factory ledger after creating a new cue. ");
			if (ledgerFactory.interruptionCues.size() != ledgerFactory.interruptionCueLabels.size())
				throw new IllegalStateException("There is an unequal number of interruption cues and interruption cue labels in the factory ledger after creating a new cue. ");

		}
		// Computation: create the emission probabilities
		this.emissionProbabilities = getEmissionProbabilities(template, ledgerFactory, orderOfCueLabels);
		
		// Set maximumNumberOfTimesAnAgentCanSampleThisCue
		maximumNumberOfTimesAnAgentCanSampleThisCue = template.maximumNumberOfCuesAnAgentCanSample;
		
	}

	/** Copy constructor */
	/** Deep clone constructor */
	public Cue (Cue original) {
		
		this.parentObjectClass = original.parentObjectClass;
		this.emissionProbabilities = new NumberObjectSingle[original.emissionProbabilities.length][];
		for (int i = 0; i < emissionProbabilities.length; i++) {
			emissionProbabilities[i] = new NumberObjectSingle[original.emissionProbabilities[i].length];
			for (int j = 0; j < emissionProbabilities[i].length; j++)
				emissionProbabilities[i][j] = original.emissionProbabilities[i][j].clone();
		}
		maximumNumberOfTimesAnAgentCanSampleThisCue= original.maximumNumberOfTimesAnAgentCanSampleThisCue;
		model = original.model;
	}
	
	/** Register the cue for the specified resource. Returns the ledgerfactory's cueLabel array for this cue*/
	private String[] registerResourceCue(CueTemplate template, LedgerFactory ledgerFactory) {
		// First, figure out the index of the object in correct LedgerFactory
		int indexInResourceArrayList = -1;
		for (int i = 0; i < ledgerFactory.resourceNames.size(); i ++)
			if (ledgerFactory.resourceNames.get(i).equals(template.object.getName()))
				indexInResourceArrayList = i;
		
		if (indexInResourceArrayList == -1)
			throw new IllegalStateException("Trying to register a cue for a resource object that is not registered in the ledger factory (yet).");
		
		// Second, register this cue
		//		check if there already is a cue at the index
		// 		First, if the ledgerFactory's resourceCues arraylist is smaller than the index: 
		//			there is no entry yet, keep adding nulls until we are at the correct length
		while (ledgerFactory.resourceCues.size() <= indexInResourceArrayList)
			ledgerFactory.resourceCues.add(null);
		
		if (ledgerFactory.resourceCues.get(indexInResourceArrayList) != null)
			throw new IllegalStateException("Trying to register a cue for resource object " + indexInResourceArrayList + ". However, there already seems to be a cue for this object.");
		
		ledgerFactory.resourceCues.set(indexInResourceArrayList, this);
		
		// Third, register the labels of this cue, using the same method
		// Make an array of String for the cue labels
		String[] labels = new String[template.cueLabels.size()];
		for (int i = 0 ; i < template.cueLabels.size(); i ++)
			labels[i] = template.cueLabels.get(i).name;
			
		while (ledgerFactory.resourceCueLabels.size() <= indexInResourceArrayList)
			ledgerFactory.resourceCueLabels.add(null);
		
		if (ledgerFactory.resourceCueLabels.get(indexInResourceArrayList) != null)
			throw new IllegalStateException("Trying to register labels for the cue for resource object " + indexInResourceArrayList + ". However, there already seems to be labels for the cue for this object.");
		
		ledgerFactory.resourceCueLabels.set(indexInResourceArrayList, labels);
		
		// Return the cue labels - having this String[] is useful so that we know how to create the cue labels in the computation step
		return ledgerFactory.resourceCueLabels.get(indexInResourceArrayList);
	}
	
	/** Register the cue for the specified resource. Returns the ledgerfactory's cueLabel array for this cue*/
	private String[] registerDelayCue(CueTemplate template, LedgerFactory ledgerFactory) {
		// First, figure out the index of the object in correct LedgerFactory
		int indexInDelayArrayList = -1;
		for (int i = 0; i < ledgerFactory.delayNames.size(); i ++)
			if (ledgerFactory.delayNames.get(i).equals(template.object.getName()))
				indexInDelayArrayList = i;
		
		if (indexInDelayArrayList == -1)
			throw new IllegalStateException("Trying to register a cue for a delay object that is not registered in the ledger factory (yet).");
		
		// Second, register this cue
		//		check if there already is a cue at the index
		// 		First, if the ledgerFactory's delayCues arraylist is smaller than the index: 
		//			there is no entry yet, keep adding nulls until we are at the correct length
		while (ledgerFactory.delayCues.size() <= indexInDelayArrayList )
			ledgerFactory.delayCues.add(null);
		
		if (ledgerFactory.delayCues.get(indexInDelayArrayList ) != null)
			throw new IllegalStateException("Trying to register a cue for delay object " + indexInDelayArrayList  + ". However, there already seems to be a cue for this object.");
		
		ledgerFactory.delayCues.set(indexInDelayArrayList , this);
		
		// Third, register the labels of this cue, using the same method
		// Make an array of String for the cue labels
		String[] labels = new String[template.cueLabels.size()];
		for (int i = 0 ; i < template.cueLabels.size(); i ++)
			labels[i] = template.cueLabels.get(i).name;
			
		while (ledgerFactory.delayCueLabels.size() <= indexInDelayArrayList )
			ledgerFactory.delayCueLabels.add(null);
		
		if (ledgerFactory.delayCueLabels.get(indexInDelayArrayList ) != null)
			throw new IllegalStateException("Trying to register labels for the cue for delay object " + indexInDelayArrayList  + ". However, there already seems to be labels for the cue for this object.");
		
		ledgerFactory.delayCueLabels.set(indexInDelayArrayList , labels);
		
		// Return the cue labels - having this String[] is useful so that we know how to create the cue labels in the computation step
		return ledgerFactory.delayCueLabels.get(indexInDelayArrayList);
	}
	
	/** Register the cue for the specified resource. Returns the ledgerfactory's cueLabel array for this cue*/
	private String[] registerInterruptionCue(CueTemplate template, LedgerFactory ledgerFactory) {
		// First, figure out the index of the object in correct LedgerFactory
		int indexInInterruptionArrayList = -1;
		for (int i = 0; i < ledgerFactory.interruptionNames.size(); i ++)
			if (ledgerFactory.interruptionNames.get(i).equals(template.object.getName()))
				indexInInterruptionArrayList= i;
		
		if (indexInInterruptionArrayList == -1)
			throw new IllegalStateException("Trying to register a cue for an interruption object that is not registered in the ledger factory (yet).");
		
		// Second, register this cue
		//		check if there already is a cue at the index
		// 		First, if the ledgerFactory's interruptionCues arraylist is smaller than the index: 
		//			there is no entry yet, keep adding nulls until we are at the correct length
		while (ledgerFactory.interruptionCues.size() <= indexInInterruptionArrayList )
			ledgerFactory.interruptionCues.add(null);
		
		if (ledgerFactory.interruptionCues.get(indexInInterruptionArrayList) != null)
			throw new IllegalStateException("Trying to register a cue for interruption object " + indexInInterruptionArrayList  + ". However, there already seems to be a cue for this object.");
		
		ledgerFactory.interruptionCues.set(indexInInterruptionArrayList , this);
		
		// Third, register the labels of this cue, using the same method
		// Make an array of String for the cue labels
		String[] labels = new String[template.cueLabels.size()];
		for (int i = 0 ; i < template.cueLabels.size(); i ++)
			labels[i] = template.cueLabels.get(i).name;
			
		while (ledgerFactory.interruptionCueLabels.size() <= indexInInterruptionArrayList )
			ledgerFactory.interruptionCueLabels.add(null);
		
		if (ledgerFactory.interruptionCueLabels.get(indexInInterruptionArrayList ) != null)
			throw new IllegalStateException("Trying to register labels for the cue for interruption object " + indexInInterruptionArrayList  + ". However, there already seems to be labels for the cue for this object.");
		
		ledgerFactory.interruptionCueLabels.set(indexInInterruptionArrayList , labels);
		
		// Return the cue labels - having this String[] is useful so that we know how to create the cue labels in the computation step
		return ledgerFactory.interruptionCueLabels.get(indexInInterruptionArrayList);
	}


	private final NumberObjectSingle[][] getEmissionProbabilities(CueTemplate template, LedgerFactory ledgerFactory, String[] orderOfLabels) {
		
		// Step 0: create an array of DecimalNumberArrays to temporarily store the non-normalized probabilities in
		NumberObjectArray[] tempNonNormalized = new NumberObjectArray[orderOfLabels.length];
		
		// Step 1: create all the non-normalized emission probabilities.
		// These are the probabilities for each value, as specified by the user. These probabilities
		// sum to 1 over all values. However, the sum of all cue labels for one value does not equal 1 (yet).
		try {
			for (CueLabel cl: template.cueLabels) {
				
				// First, get the index of this label in orderOfLabels
				int indexOfLabel = -1;
				for (int i = 0; i < orderOfLabels.length; i++)
					if (orderOfLabels[i].equals(cl.name))
						indexOfLabel = i;
				if (indexOfLabel == -1)
					throw new IllegalStateException("Cue label not (yet) registered. This cue label is: " + cl.name + ", registered thus far: " + Helper.arrayToString(orderOfLabels) );
				
				// Set the domain of the RFunctionContainer stored in the cueLabel
				cl.functionContainer.addArgument(new AttributeField("domain", template.object.getDomain()));

				// Run in R: we want to get the non-normalized probabilities of this cue label for each value of the object
				// the call to runInR() returns an array of NumberObjects. In this case there is only one NumberObject, at place 0.
				// This is a DecimalNumberArray. Hence the cast here.
				NumberObjectArray nonNormalized =   ( (NumberObjectArray) cl.functionContainer.runInR()[0] ).toNumberObjectArray(model.howToRepresentNumbers);
				
				// Check if the length of the results matches the length of the domain
				if (nonNormalized.size() != template.object.getDomain().size())
					throw new IllegalStateException("A function call to R's '" + cl.functionContainer.getRFunction().getNameInR() + "' function returned " + nonNormalized.size() + " values, but the object '" + template.object.getName()+ "' has a domain of size " + template.object.getDomain().size() + ".");
				
				// Check if the result is a normal distribution: only non-negative values and a total sum of 1
				if (!nonNormalized.isProbability())
					if (!nonNormalized.sum().equals(1, true))
						throw new IllegalStateException("A function call to R's '" + cl.functionContainer.getRFunction().getNameInR() + "' function did not return a probability distribution: The 'probabilities' sum to " + nonNormalized.sum() + ".");
					else 
						throw new IllegalStateException("A function call to R's '" + cl.functionContainer.getRFunction().getNameInR() + "' function did not return a probability distribution: There is at least one negative value: " + nonNormalized.toStringWithoutTrailingZeros() + ".");

				// Save non-Normalized in tempNonNormalized
				tempNonNormalized[indexOfLabel] = nonNormalized;
			}
		} catch (Exception e) { 
			ObserverManager.notifyObserversOfError(e);
			model.outputFileManager.writeExceptionToFile(e);
		}
		
		// Step 2: normalize the cues. Specifically, for each value of the object the probability of all labels should sum to 1.
		NumberObjectSingle[][] returnEmissionProbabilities = new NumberObjectSingle[template.object.getDomain().size()][orderOfLabels.length];
		for (int resourceValueIndex = 0; resourceValueIndex < returnEmissionProbabilities.length; resourceValueIndex++) {
			// Step 2a. For each resource value, get non-normalized probabilities of all labels
			NumberObjectSingle[] temp = new NumberObjectSingle[orderOfLabels.length];
			for (int i = 0; i < orderOfLabels.length; i++)
				temp[i] = tempNonNormalized[i].get(resourceValueIndex);
			
			// Step 2b: make sure that the sum is not 0 (i.e., there should be at least one cue that is possible)
			NumberObjectSingle sum = NumberObject.createNumber(model.howToRepresentNumbers, 0);
			for (NumberObjectSingle n: temp)
				sum.add(n, true);
			if (sum.equals(0))
				throw new IllegalStateException("There is no possible cue when object '" + template.object.getName()+ "' has a value of " + template.object.getDomain().get(resourceValueIndex).toStringWithoutTrailingZeros());
			
			// Step 2c. Normalize the probabilites For each resource value
			// DecimalNumberArray already has a function for this, so we'll use that one
			NumberObjectArray tempArray = NumberObject.createArray(model.howToRepresentNumbers, temp);
			tempArray.scaleToSumToOne();
			
			// Step 2d. Store in emissionProbabilities
			returnEmissionProbabilities[resourceValueIndex] = tempArray.toArray();
		}
		
		return returnEmissionProbabilities;
	
	}
	
	/** Make all NumberObjectSingle values in this cue immutable, preventing any future changes to these values*/
	public void makeImmutable() {
		for (int i = 0; i < emissionProbabilities.length; i++)
			for (int j = 0; j < emissionProbabilities[i].length; j++)
				emissionProbabilities[i][j].makeImmutable();
	}
	
	
	public String toString() {
		StringBuilder sb = new StringBuilder("Cue that can be sampled " + maximumNumberOfTimesAnAgentCanSampleThisCue + " times. Has following emission probabilities: \n" + 
				NumberObject.createMatrix(model.howToRepresentNumbers, this.emissionProbabilities));
		return sb.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(emissionProbabilities);
		result = prime * result + maximumNumberOfTimesAnAgentCanSampleThisCue;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Cue other = (Cue) obj;
	
		if (other.emissionProbabilities.length != this.emissionProbabilities.length)
			return false;
		
		for (int i = 0; i < emissionProbabilities.length; i++) {
			if (emissionProbabilities[i].length != other.emissionProbabilities[i].length)
				return false;
			
			for (int j = 0; j < emissionProbabilities[i].length; j++)
				if (!emissionProbabilities[i][j].equals(emissionProbabilities[i][j]))
					return false;
		}
			

		if (maximumNumberOfTimesAnAgentCanSampleThisCue != other.maximumNumberOfTimesAnAgentCanSampleThisCue) {
			return false;
		}
		return true;
	}
}
