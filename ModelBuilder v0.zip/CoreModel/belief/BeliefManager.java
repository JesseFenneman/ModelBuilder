package belief;

import java.util.HashMap;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.AbstractModel;
import core.AbstractModel.InstantiatedObjectClass;
import states.Abstract.AbstractState;

/** In some model, an agent does not for sure what the value of an
 * encountered instance (resource, interruption, delay) is
 * or might be. Rather, they might only have a subjective belief. 
 * 
 * There are two types of beliefs. First, an agent sometimes has to keep
 * track of the probability of object values in the population. For example,
 * the distribution of 'job quality' if jobs can have multiple values in the
 * current patch. This belief about the distribution of object values, without
 * having encountered a specific object, is called the prior distribution. The
 * prior distribution depends two parts: the current patch state where the object
 * will be found, and the previous experiences that an agent has. Note that 
 * if the agent knows the distribution of objects in a patch, the subjective
 * prior belief is equal to the true distribution. All states can have a prior 
 * distribution.
 * 
 * The second way to learn is by sampling cues about the value of a specific
 * encountered objects. The belief an agent has about the value of a specific
 * object after observing some cues is called that posterior. That is, whereas 
 * priors are about the distribution of all possible instances of a class, a 
 * posterior is about the specific value of an encountered instance. As the
 * posterior requires there to be an encountered instance, only encounter states
 * can have prior beliefs. 
 * 
 * Belief updating - both via experiences and cues - is computationally expensive.
 * Moreover, there are states with the same prior/posterior beliefs. Recomputing
 * the same equations over and over is not the smartest way to go about it. Rather, 
 * we can use a manager that does the computation for us, and stores the results 
 * in a global library. The second time we have to compute it, we can then take
 * a shortcut by reading out this library. 
 * */
public class BeliefManager {
	
	/** Stores the previously computed priors, based on the specified
	 * previous observations. Here is a fun fact: we do not have to keep
	 * track of the type of object. Suppose that there are two objects
	 * that we need to compute a prior for: a delay, which can be 1 to 5, or 
	 * a resource, which can have values 6 to 10. Note that both have
	 * five possible values. If we compute the prior given the previous
	 * experiences of {0,10, 0, 1, 0} (that is, we have seen 10 times the second
	 * value, 1 times the fourth value, and nothing else), we can compute 
	 * the posterior. It does not matter whether we are computing it for a
	 * resource or delay; given the counted previous experience, the prior
	 * is the same. */
	private final HashMap<int[], NumberObjectSingle[]> computedPriors;
	
	private final AbstractModel model;
	
	/** To compute priors from the number of previous observations, the
	 * BeliefManager uses Laplace smoothing (https://en.wikipedia.org/wiki/Additive_smoothing), with
	 * the specified alpha. If the alpha is set to one, this boils down to add-one smoothing. The 
	 * value for alpha is set in the constructor*/
	private final NumberObjectSingle alpha;
	
	/** A manager that takes care of efficiently computing all
	 * beliefs - both of prior distribution of objects that are learned by experience
	 * (resources, interruptions, delay, or extrinsic), as well as posterior
	 * beliefs about specifically encountered objects which can be 
	 * sampled for cues (resources, interruptions, and delays).*/
	public BeliefManager(AbstractModel model) {
		this.model= model;
		this.alpha=NumberObject.createNumber(model.howToRepresentNumbers, 1); // 1 represent add-one smoothing
		this.computedPriors=new HashMap<>();
	}
	
	
	/** Returns the prior for the specified experiences (including
	 * experiences during the runtime and the experiences that the agent
	 * stated the model with). This distribution is either retrieved from
	 * computedPriors, or if no such entry exists, is computed and subsequently
	 * stored in computedPriors. This function uses Laplace smoothing to 
	 * compute priors.*/
	private NumberObjectSingle[] computePrior(int[] totalObservations) {
		// See if there already is an entry for this total number of observations
		NumberObjectSingle[] prior = computedPriors.get(totalObservations);
		
		// if yes: return
		if (prior != null)
			return prior;
		
		// Otherwise, apply the laplace smoothing
		int totalNumberOfObservations = 0;
		for (int x : totalObservations)
			totalNumberOfObservations+=x;
		
		NumberObjectSingle denominatorConstant = alpha.multiply(totalObservations.length, false);
		prior = new NumberObjectSingle[totalObservations.length];
		
		for (int i = 0; i < totalObservations.length; i++) {
			NumberObjectSingle numerator = NumberObject.createNumber(model.howToRepresentNumbers, totalObservations[i]).add(alpha, true);
			NumberObjectSingle denominator = NumberObject.createNumber(model.howToRepresentNumbers, totalNumberOfObservations).add(denominatorConstant, true);
			prior[i] = numerator.divide(denominator, true);
		}
		
		// Store the computed prior in computedPriors
		computedPriors.put(totalObservations, prior);
		
		// Return the computed prior
		return prior;
	}
	
	/** Returns the stored prior for the specified resource object index,
	 * and patch state. This distribution is either retrieved from computedPriors,
	 * or, if no such entry exists yet, is computed and subsequently stored
	 * for later use. This function uses laplacian smoothing to compute
	 * priors from observations.*/
	private NumberObjectSingle[] computeResourcePrior(AbstractState state, int resourceIndex, int patchStateIndex) {
		// Figure out how many experiences the agent has started with
		int[] observationsAtStartOfModel = model.ledger.patchStates[patchStateIndex].resourcePriorExperiences[resourceIndex];
		
		// What did the agent in the specified state experience during runtime?
		int[] observationsDuringRuntime = state.getResourceExperiences(patchStateIndex, resourceIndex);
		
		// Combine the two
		int[] totalObservations = new int[observationsAtStartOfModel.length];
		for (int i = 0; i < totalObservations.length; i ++)
			totalObservations[i] = observationsAtStartOfModel[i]+observationsDuringRuntime[i];
		
		return computePrior(totalObservations);
	}
	
	/** Returns the stored prior for the specified delay object index,
	 * and patch state. This distribution is either retrieved from computedPriors,
	 * or, if no such entry exists yet, is computed and subsequently stored
	 * for later use. This function uses laplacian smoothing to compute
	 * priors from observations.*/
	private NumberObjectSingle[] computeDelayPrior(AbstractState state, int delayIndex, int patchStateIndex) {
		// Figure out how many experiences the agent has started with
		int[] observationsAtStartOfModel = model.ledger.patchStates[patchStateIndex].delayPriorExperiences[delayIndex];
		
		// What did the agent in the specified state experience during runtime?
		int[] observationsDuringRuntime = state.getDelayExperiences(patchStateIndex, delayIndex);
		
		// Combine the two
		int[] totalObservations = new int[observationsAtStartOfModel.length];
		for (int i = 0; i < totalObservations.length; i ++)
			totalObservations[i] = observationsAtStartOfModel[i]+observationsDuringRuntime[i];
		
		return computePrior(totalObservations);
	}
	
	/** Returns the stored prior for the specified interruption object index,
	 * and patch state. This distribution is either retrieved from computedPriors,
	 * or, if no such entry exists yet, is computed and subsequently stored
	 * for later use. This function uses laplacian smoothing to compute
	 * priors from observations. Note: the first index position
	 * represents the probability that this interruption will NOT take place,
	 * the second entry represents the probability that this interruption WILL
	 * take place.*/
	private NumberObjectSingle[] computeInterruptionPrior(AbstractState state, int interruptionIndex, int patchStateIndex) {
		// Figure out how many experiences the agent has started with
		int[] observationsAtStartOfModel = model.ledger.patchStates[patchStateIndex].interruptionPriorExperiences[interruptionIndex];
		
		// What did the agent in the specified state experience during runtime?
		int[] observationsDuringRuntime = state.getInterruptionExperiences(patchStateIndex, interruptionIndex);
		
		// Combine the two
		int[] totalObservations = new int[observationsAtStartOfModel.length];
		for (int i = 0; i < totalObservations.length; i ++)
			totalObservations[i] = observationsAtStartOfModel[i]+observationsDuringRuntime[i];
		
		return computePrior(totalObservations);
	}
	
	/** Returns the stored prior for the specified extrinsic event object index,
	 * and patch state. This distribution is either retrieved from computedPriors,
	 * or, if no such entry exists yet, is computed and subsequently stored
	 * for later use. This function uses laplacian smoothing to compute
	 * priors from observations.*/
	private NumberObjectSingle[] computeExtrinsicPrior(AbstractState state, int extrinsicIndex, int patchStateIndex) {
		// Figure out how many experiences the agent has started with
		int[] observationsAtStartOfModel = model.ledger.patchStates[patchStateIndex].extrinsicPriorExperiences[extrinsicIndex];
		
		// What did the agent in the specified state experience during runtime?
		int[] observationsDuringRuntime = state.getExtrinsicExperiences(patchStateIndex, extrinsicIndex);
		
		// Combine the two
		int[] totalObservations = new int[observationsAtStartOfModel.length];
		for (int i = 0; i < totalObservations.length; i ++)
			totalObservations[i] = observationsAtStartOfModel[i]+observationsDuringRuntime[i];
		
		return computePrior(totalObservations);
	}

	
	/** Returns the prior distribution of the given object in the given state and patch state. See javadoc 
	 * for getPriorAssumingEncountered() and getPriorConsideringFrequency(). If useFrequency is false, 
	 * returns getPriorAssumingEncountered(). Else, returns getPriorConsideringFrequency()*/
	private NumberObjectSingle[] getPrior(AbstractState state, InstantiatedObjectClass objectClass, int objectIndex, int patchStateIndex, boolean useFrequency) {
		switch (objectClass) {
		
		case RESOURCE: 
			// Constant: return a probability of 1
			if (model.ledger.resourceIsConstant[objectIndex])
				return new NumberObjectSingle[] {NumberObject.createNumber(model.howToRepresentNumbers, 1)};
			
			// Known distribution: get the objective probability distribution
			if (model.ledger.patchStates[patchStateIndex].resourceDistributionKnown[objectIndex]) {
				if (!useFrequency)
					return (model.ledger.patchStates[patchStateIndex].rawResourceValueProbabilities[objectIndex]);
				return model.ledger.patchStates[patchStateIndex].resourceValueProbability[objectIndex];
			}
			
			// Not known: compute a prior based on the agent's experiences 
			if (!useFrequency)
				return computeResourcePrior(state, objectIndex, patchStateIndex);
			return priorAssumingEncounterToPriorConsideringFrequency(computeResourcePrior(state, objectIndex, patchStateIndex), model.ledger.patchStates[patchStateIndex].getResourceFrequency(objectIndex));

			
		case DELAY:
			// Constant: return a probability of 1
			if (model.ledger.delayIsConstant[objectIndex])
				return new NumberObjectSingle[] {NumberObject.createNumber(model.howToRepresentNumbers, 1)};

			// Known distribution: get the objective probability distribution
			if (model.ledger.patchStates[patchStateIndex].delayDistributionKnown[objectIndex]) {
				if (!useFrequency)
					return (model.ledger.patchStates[patchStateIndex].rawDelayDurationProbabilities[objectIndex]);
				return model.ledger.patchStates[patchStateIndex].delayDurationProbability[objectIndex];
			}

			// Not known: compute a prior based on the agent's experiences 
			if (!useFrequency)
				return computeDelayPrior(state, objectIndex, patchStateIndex);
			return priorAssumingEncounterToPriorConsideringFrequency(computeDelayPrior(state, objectIndex, patchStateIndex), model.ledger.patchStates[patchStateIndex].getDelayFrequency(objectIndex));
			
		case INTERRUPTION:
			// Interruptions cannot be constant
			// interruptions always have a frequency of 1.
			// Known distribution: get the objective probability distribution
			if (model.ledger.patchStates[patchStateIndex].interruptionDistributionKnown[objectIndex])
				return (model.ledger.patchStates[patchStateIndex].interruptionProbabilities[objectIndex]);
			
			// Not known: compute a prior based on the agent's experiences 
			return computeInterruptionPrior(state, objectIndex, patchStateIndex);

		case EXTRINSIC:
			// Constant: return a probability of 1
			if (model.ledger.extrinsicIsConstant[objectIndex])
				return new NumberObjectSingle[] {NumberObject.createNumber(model.howToRepresentNumbers, 1)};

			// Known distribution: get the objective probability distribution
			if (model.ledger.patchStates[patchStateIndex].extrinsicDistributionKnown[objectIndex]) {
				if (!useFrequency)
					return (model.ledger.patchStates[patchStateIndex].rawExtrinsicEventValueProbabilities[objectIndex]);
				return model.ledger.patchStates[patchStateIndex].extrinsicEventValueProbability[objectIndex];
			}

			// Not known: compute a prior based on the agent's experiences 
			if (!useFrequency)
				return computeExtrinsicPrior(state, objectIndex, patchStateIndex);
			return priorAssumingEncounterToPriorConsideringFrequency(computeExtrinsicPrior(state, objectIndex, patchStateIndex), model.ledger.patchStates[patchStateIndex].getExtrinsicEventFrequency(objectIndex));

			default: throw new IllegalStateException("Unknown object class: " + objectClass);
		}
		
	}
	
	/** Takes a prior probability distribution of a object value conditional
	 * that the object WILL be encoutnered (i.e., P(object | object is encountered), 
	 * and returns the prior probability distribution given that the object might NOT
	 * be distributed. Formally, returns P(object | might not be encountered), which is:
	 * P(object | object is encountered) * Frequency(object). Note, this means that 
	 * the resulting prior probability distribution does not sum to 1. 
	*/
	private NumberObjectSingle[] priorAssumingEncounterToPriorConsideringFrequency (NumberObjectSingle[] prior, NumberObjectSingle frequency) {
		NumberObjectSingle[] priorFreq = new NumberObjectSingle[prior.length];
		for (int i = 0; i < priorFreq.length; i ++)
			priorFreq[i] = prior[i].multiply(frequency, false);
		return priorFreq;
	}
	/** Get the prior for the specified object type in the specified state and location. 
	 * The prior is an array of probabilities. The corresponding values
	 * for each probability can be found in the Ledger. The specified location
	 * need not be the current location. If the distributions of the specified object is known
	 * in the specified patch state, this function returns the true distribution. The returned
	 * array does NOT take into account the frequency - that is, the probability that this 
	 * object will not be encountered. Rather, it gives the prior distribution of values given that 
	 * the object WILL be encountered. As such, this array sums to 1.
	 * 
	 * If the object is an interruption, the returned array has length 2. The first entry
	 * corresponds to the probability that the interruption does NOT occur. The second
	 * entry gives the probability that an interruption WILL occur.
	 * 
	 * If the object is a resource, delay, or extrinsic event, the returned array
	 * either has size 1 (if the object has a constant value), or a size equal to 
	 * the number of values that this object can have (see Ledger for the specific values)*/
	public NumberObjectSingle[] getPriorAssumingEncountered(AbstractState state, InstantiatedObjectClass objectClass, int objectIndex, int patchStateIndex) {
		return getPrior(state, objectClass, objectIndex, patchStateIndex, false);
	}
	
	
	/** Get the prior for the specified object type in the specified state. 
	 * The prior is an array of probabilities. The corresponding values
	 * for each probability can be found in the Ledger. To compute the prior, the 
	 * current location is used. If the distributions of the specified object is known
	 * in the current patch state, this function returns the */
	public NumberObjectSingle[] getPriorAssumingEncountered(AbstractState state, InstantiatedObjectClass objectClass, int objectIndex) {
		return getPrior(state, objectClass, objectIndex, state.getLocationPatchState(), false);
	}


	
	/** Get the prior for the specified object type in the specified state and the specified location. 
	 * The prior is an array of probabilities. The corresponding values
	 * for each probability can be found in the Ledger. The specified location
	 * need not be the current location. If the distributions of the specified object is known
	 * in the specified patch state, this function returns the true distribution. 
	 * 
	 * The returned array DOES take into account the frequency - that is, the probability that this 
	 * object will not be encountered. As such, it returns the prior probability distribution of values, which
	 * does not sum to 1. 
	 * 
	 * If the object is an interruption, the returned array has length 2. The first entry
	 * corresponds to the probability that the interruption does NOT occur. The second
	 * entry gives the probability that an interruption WILL occur. Note: 
	 * interruptions are ALWAYS encountered - hence, this function returns the same
	 * as priorAssumingEncounterToPriorConsideringFrequency() if the objectClass is INTERRUPTION.
	 *
	 * 
	 * If the object is a resource, delay, or extrinsic event, the returned array
	 * either has size 1 (if the object has a constant value), or a size equal to 
	 * the number of values that this object can have (see Ledger for the specific values)*/
	public NumberObjectSingle[] getPriorConsideringFrequency(AbstractState state, InstantiatedObjectClass objectClass, int objectIndex, int patchStateIndex) {
		return getPrior(state, objectClass, objectIndex, patchStateIndex, true);
	}
	
	/** Get the prior for the specified object type in the specified state and that state's location. 
	 * The prior is an array of probabilities. The corresponding values
	 * for each probability can be found in the Ledger. The specified location
	 * need not be the current location. If the distributions of the specified object is known
	 * in the specified patch state, this function returns the true distribution. 
	 * 
	 * The returned array DOES take into account the frequency - that is, the probability that this 
	 * object will not be encountered. As such, it returns the prior probability distribution of values, which
	 * does not sum to 1. 
	 * 
	 * If the object is an interruption, the returned array has length 2. The first entry
	 * corresponds to the probability that the interruption does NOT occur. The second
	 * entry gives the probability that an interruption WILL occur. Note: 
	 * interruptions are ALWAYS encountered - hence, this function returns the same
	 * as priorAssumingEncounterToPriorConsideringFrequency() if the objectClass is INTERRUPTION.
	 *
	 * 
	 * If the object is a resource, delay, or extrinsic event, the returned array
	 * either has size 1 (if the object has a constant value), or a size equal to 
	 * the number of values that this object can have (see Ledger for the specific values)*/
	public NumberObjectSingle[] getPriorConsideringFrequencyo(AbstractState state, InstantiatedObjectClass objectClass, int objectIndex) {
		return getPrior(state, objectClass, objectIndex, state.getLocationPatchState(), false);
	}

}
