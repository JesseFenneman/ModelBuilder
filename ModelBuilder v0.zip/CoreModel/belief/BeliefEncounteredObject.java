package belief;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import core.AbstractModel.EncounteredInstantiatedObjectClass;

/** At any moment, an agent has a belief about an encountered 
 * object. These objects can be resources, delays, or interruptions.
 * 
 * If the encountered object is of a class of objects that are
 * directly observable, there is only one possible value that
 * the agent believes that the encounter can have. 
 * 
 * If the encountered object is of a class of objects that are
 * NOT directly observable, and that CANNOT be sampled for cues,
 * an agent's belief about the value of that object are the
 * same as it's prior belief about the value of an object, conditional
 * on the current patch state it is in. This prior distribution is
 * the agent's PriorBelief. 
 * 
 * If the encountered object is of a class of objects that are
 * NOT directly observable, but that CAN be sampled for cues, this
 * class can be called to 
 */
public class BeliefEncounteredObject {

	/** Each belief refers to a specific object that is encountered. Is this object a resource, delay, or interruption?*/
	private final EncounteredInstantiatedObjectClass objectClass;
	
	/** Each belief refers to a specific object that is encountered. What is the index position of this object in the ledger?*/
	private final  int objectIndex;
	
	/** Each belief refers to a specific object that is encountered. What are the values of this object?
	 * Note: this array is a reference to the ledger's array. Do not change.*/
	private final NumberObjectSingle[] objectValues;
	
	/** The prior belief of this object - that is, the probability distribution of 
	 * the object's class values, without knowing anything else about the value of the particularly
	 * instantiated object.*/
	private final PriorBelief prior;
	
	public NumberObjectSingle getPrior
}
