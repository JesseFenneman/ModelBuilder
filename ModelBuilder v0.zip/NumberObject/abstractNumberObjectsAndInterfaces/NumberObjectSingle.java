package abstractNumberObjectsAndInterfaces;


import java.math.BigDecimal;
import java.math.RoundingMode;

import abstractNumberObjectsAndInterfaces.NumberObject.UnknownNumberObjectException;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle.VALUE_FLAG;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import doubleNumber.DoubleNumber;
import doubleNumber.DoubleNumberArray;
//TODO: each subclass should implement static computation methods
/** A NumberObjectSingle is an object that contains a value (the numeric value of this object) and implements some often used
 * computations and manipulations. There are two known implementations: DecimalNumber (which is very precise, but also
 * quite slow) and DoubleNumber (which is super fast, but has floating-point inaccuracies).
 *
 */
public interface NumberObjectSingle extends NumberObject {

	
	

	/** Some NumberObjectSingles are not really numbers. Instead, they are concepts. For instance, a NumberObjectSingle might
	 * refer a NULL, NaN, POSITIVE_INFINITE, or NEGATIVE_INFINITY. Such NumberObjectSingles are marked with a VALUE_FLAG. Trying
	 * to perform operations with or on a NumberObjectSingle object that has a non-NORMAL flag will result in an exception.*/
	public enum VALUE_FLAG { NULL, NaN, POSITIVE_INFINITY, NEGATIVE_INFINITY, NORMAL }

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Validity checks 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	/**This function has to be called prior to any and all operations on this NumberObjectSingle.
	 *
	 *  It checks whether this NumberObjectSingle objects has a NORMAL flag. All other flags will result either a
	 * NumberObjectNULLException (if this NumberObjectSingle object has a NULL flag), a NumberObjectException
	 * (if this NumberObjectSingle object has a NaN flag), a NumberObjectPositiveInfinityException (if this
	 * NumberObjectSingle object has a POSITIVE_INFINITY flag), or a NumberObjectNegativeInfinityException (if this
	 * NumberObjectSingle object has a NEGATIVE_INFINITY flag). Finally, if changingObject is true, it returns a
	 * UnsupportedOperationException if this NumberObjectSingle object is set to immutable.*/
	public void checkPreconditions(boolean changingObject);

	/** This function has to be called after every operation.
	 * Tests whether the NumberObjectSingle has a valid value (e.g., within the specified range, if a range is specified).
	 */
	public void checkPostconditions() ;

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Type checks 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	/** Check if this NumberObjectSingle object is, or contains, one or more NumberObjectSingle objects that have a VALUE_FLAG.NULL flag*/
	public boolean isNull();

	/** Check if this NumberObjectSingle object is, or contains, one or more NumberObjectSingle objects that have a VALUE_FLAG.NaN flag*/
	public boolean isNaN();

	/** Check if this NumberObjectSingle object is, or contains, one or more NumberObjectSingle objects that have a VALUE_FLAG.POSITIVE_INFINITY flag*/
	public boolean isPositiveInfinity();

	/** Check if this NumberObjectSingle object is, or contains, one or more NumberObjectSingle objects that have a VALUE_FLAG.NEGATIVE_INFINITY flag*/
	public boolean isNegativeInfinity();

	/** Returns true if this NumberObjectSingle is null, NaN, positive infinity, or negative infinity*/
	public boolean hasNonNormalFlag();
	
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	SETTERS 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	/** Set all attributes in this NumberField to match the attributes of the original NumberField. Returns this.
	 * Throws an NumberFieldNullException is the flag on either this or the original NumberField object has a VALUE_FLAG.NULL flag.
	 * Throws an NumberFieldNaNException is the flag on either this or the original NumberField object has a VALUE_FLAG.NaN flag.
	 * Throws an NumberFieldPositiveInfinityException is the flag on either this or the original NumberField object has a VALUE_FLAG.PositiveInfinity flag.
	 * Throws an NumberFieldNegativeInfinityException is the flag on either this or the original NumberField object has a VALUE_FLAG.NegativeInfinity flag.
	 * */
	public void mimic(NumberObjectSingle original) ;

	/**
	 * Sets the NumberObject's value to the argument.
	 * If this NumberObjectSingle is immutable, a UnsupportedOperationException is thrown.
	 * If the new value is not in the range of permissible values, a IllegalRangeException is thrown.
	 * Returns this.
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle set(Number argument);

	/**
	 * Sets the NumberObject's value to the argument.
	 * If this NumberObjectSingle is immutable, a UnsupportedOperationException is thrown.
	 * If the new value is not in the range of permissible values, a IllegalRangeException is thrown.
	 * Returns this.
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle set(String argument) ;

	/**
	 * Sets the NumberObject's value to the argument.
	 * If this NumberObjectSingle is immutable, a UnsupportedOperationException is thrown.
	 * If the new value is not in the range of permissible values, a IllegalRangeException is thrown.
	 * Returns this.
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle set(NumberObjectSingle argument)  ;

	/** Sets the mutability. Returns this. ATTENTION: THIS FUNCTION SHOULD BE USED WITH CAUTION.
	 * There is probably a good reason why something is marked as immutable.
	 * If the goal is to make this object immutable, consider using makeImmutable() */
	public NumberObjectSingle setImmutable(boolean immutability) ;

	/** Removes the range restriction of this NumberObject. Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle removeRangeRestrictions() ;

	/** Sets the range of this NumberObjectSingle and returns this.
	 * If the range is violated at any moment, an IllegalRangeException will be thrown.	Throws a UnsupportedOperationException is this object is set to immutable.*/
	public NumberObjectSingle setRange(Number minimum, Number maximum) ;

	/** Sets the range of this NumberObjectSingle and returns this.
	 * If the range is violated at any moment, an IllegalRangeException will be thrown.	Throws a UnsupportedOperationException is this object is set to immutable.*/
	public NumberObjectSingle setRange(NumberObjectSingle minimum, NumberObjectSingle maximum) ;

	/** Sets the minimum value of the range restriction of this NumberObjectSingle and returns this.
	 *  Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle setRangeMinimum	(Number minimum);

	/** Sets the minimum value of the range restriction of this NumberObjectSingle and returns this.
	 *  Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle setRangeMinimum	(NumberObjectSingle minimum);

	/** Sets the minimum value of the range restriction of this NumberObjectSingle and returns this.
	 * Does not perform any validation; after this operation the NumberObjectSingle is not guaranteed to fall within the specified range
	 *  Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle setRangeMinimumWithoutValidation	(Number minimum);

	/** Sets the minimum value of the range restriction of this NumberObjectSingle and returns this.
	 * Does not perform any validation; after this operation the NumberObjectSingle is not guaranteed to fall within the specified range
	 *  Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle setRangeMinimumWithoutValidation	(NumberObjectSingle minimum);

	/** Sets the maximum value of the range restriction of this NumberObjectSingle and returns this.
	 *  Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle setRangeMaximum (Number maximum);

	/** Sets the maximum value of the range restriction of this NumberObjectSingle and returns this.
	 *  Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle setRangeMaximum (NumberObjectSingle maximum);

	/** Sets the maximum value of the range restriction of this NumberObjectSingle and returns this.
	 * Does not perform any validation; after this operation the NumberObjectSingle is not guaranteed to fall within the specified range
	 *  Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle setRangeMaximumWithoutValidation	(Number minimum);

	/** Sets the maximum value of the range restriction of this NumberObjectSingle and returns this.
	 * Does not perform any validation; after this operation the NumberObjectSingle is not guaranteed to fall within the specified range
	 *  Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle setRangeMaximumWithoutValidation	(NumberObjectSingle minimum);

	/** Should the range be used for this NumberObject? Returns this.
	 *  Throws a UnsupportedOperationException is this object is set to immutable. */
	public NumberObjectSingle useRange(boolean hasRangeSpecified) ;

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	GETTERS 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	public VALUE_FLAG getFlag();

	public boolean isImmutable() ;

	/** Returns true if this NumberObjectSingle has a restricted range. Going outside of this range will result in an IllegalRangeException. */
	public boolean hasRangeRestriction() ;

	/** Get the number of significant digits of this number */
	public int getSignificantDigits() ;

	/** Returns a mutable copy with the same range limitation (if applicable)*/
	public NumberObjectSingle clone() ;

	/** returns the minimum value of the range. If this range is not set, returns -infinity. */
	public NumberObjectSingle getMinimum() ;

	/** returns the maximum value of the range. If this range is not set, returns +infinity. */
	public NumberObjectSingle getMaximum() ;

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Comparisons 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	/** Returns true if this is larger than o */
	public boolean largerThan(NumberObjectSingle o) ;
	/** Returns true if this is larger than o */
	public boolean largerThan(Number o);

	/** Returns true if this is larger than or equal to o */
	public boolean largerThanOrEqualTo(NumberObjectSingle o);
	/** Returns true if this is larger than o */
	public boolean largerThanOrEqualTo(Number o);

	/** Returns true if this is smaller than o */
	public boolean smallerThan(NumberObjectSingle o) ;
	/** Returns true if this is smaller than o */
	public boolean smallerThan(Number o);

	/** Returns true if this is smaller than or equal to o */
	public boolean smallerThanOrEqualTo(NumberObjectSingle o);
	/** Returns true if this is smaller than o */
	public boolean smallerThanOrEqualTo(Number o) ;



	
	
	/** Returns true if this is larger than o (taking the bounds of approximation into account) */
	public boolean largerThan(NumberObjectSingle o, boolean approximately) ;
	/** Returns true if this is larger than o (taking the bounds of approximation into account)*/
	public boolean largerThan(Number o, boolean approximately);

	/** Returns true if this is larger than or equal to o (taking the bounds of approximation into account)*/
	public boolean largerThanOrEqualTo(NumberObjectSingle o, boolean approximately);
	/** Returns true if this is larger than o (taking the bounds of approximation into account)*/
	public boolean largerThanOrEqualTo(Number o, boolean approximately);

	/** Returns true if this is smaller than o (taking the bounds of approximation into account)*/
	public boolean smallerThan(NumberObjectSingle o, boolean approximately) ;
	/** Returns true if this is smaller than o (taking the bounds of approximation into account)*/
	public boolean smallerThan(Number o, boolean approximately);

	/** Returns true if this is smaller than or equal to o (taking the bounds of approximation into account)*/
	public boolean smallerThanOrEqualTo(NumberObjectSingle o, boolean approximately);
	/** Returns true if this is smaller than o (taking the bounds of approximation into account)*/
	public boolean smallerThanOrEqualTo(Number o, boolean approximately) ;

	
	/** Returns -1 if this is smaller than o. Returns +1 is this is larger than o. Returns 0 if this has the same value as o. */
	public int compareTo(NumberObjectSingle o) ;

	/** Returns -1 if this is smaller than o. Returns +1 is this is larger than o. Returns 0 if this has the same value as o. */
	public int compareTo(Number d);

	/**
	 * Compares the values of this and o, independent of scale.
	 *
	 * If approximately is true, values close to (within a margin of 0.00000001) are
	 * considered equal. This function is useful with values might have rounding issues
	 * (e.g., when the values are derived from R), or when there are (possible) floating
	 * point issues.
	 * @param o
	 * @return
	 */
	public boolean equals(NumberObjectSingle o, boolean approximately) ;

	/**
	 * Compares the values of this and o, independent of scale.
	 *
	 * If approximately is true, values close to (within a margin of 0.00000001) are
	 * considered equal. This function is useful with values might have rounding issues
	 * (e.g., when the values are derived from R), or when there are (possible) floating
	 * point issues.
	 * @param o
	 * @return
	 */
	public boolean equals(BigDecimal o, boolean approximately) ;


	/**
	 * Compares the values of this and o, independent of scale.
	 *
	 * If approximately is true, values close to (within a margin of 0.00000001) are
	 * considered equal. This function is useful with values might have rounding issues
	 * (e.g., when the values are derived from R), or when there are (possible) floating
	 * point issues.
	 * @param o
	 * @return
	 */
	public boolean equals(double o, boolean approximately) ;

	public boolean equals(double o) ;

	public boolean equals(String s) ;

	public boolean equals(BigDecimal o) ;
	
	public boolean equals(NumberObjectSingle o);

	@Override
	public boolean equals(Object o) ;

	/** Returns true if the NumberObject's value is in the range [lowerBound, upperBound] (both inclusive) */
	public boolean inRange(double lowerBound, double upperBound) ;

	/** Returns true if the NumberObject's value is in the range [lowerBound, upperBound] (both inclusive)  */
	public boolean inRange(NumberObjectSingle lowerBound, NumberObjectSingle upperBound) ;

	/** Returns true if the current value is a whole number*/
	public boolean isInteger();

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	TRANSFORMERS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** Returns a DoubleNumber with a value, range, mutability, and flags equal to this */
	public DoubleNumber toDoubleNumber();

	/** Returns a DecimalNumber with a value, range, mutability, and flags equal to this */
	public DecimalNumber toDecimalNumber();

	/** Returns a NumberObjectSingle with the same dimension and values as this. The value
	 * is converted to the specified format (DoubleNumber or DecimalNumber). The return value is a deep clone. */
	public abstract NumberObjectSingle toNumberObjectSingle(NumberObject.NumberObjectRepresentation formatToUse);

	/** Returns a BigDecimal with a value equal to this NumberObjectSingle value */
	public BigDecimal toBigDecimal();

	/** Returns a integer with a value equal to this NumberObjectSingle value. Uses the specified roundingMode */
	public int toInt(RoundingMode roundingMode);

	/** Returns a double with a value equal to this NumberObjectSingle value */
	public double toDouble();


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	ADDITION 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/**
	 * If the NumberObjectSingle is mutable, adds the argument to the NumberObject.
	 * Returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle + argument). In this case the number contained within this NumberObjectSingle is NOT changed.
	 * The new NumberObjectSingle is always mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle add(NumberObjectSingle argument) ;

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function adds the argument to the NumberObject.
	 * Returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle + argument). In this case the number contained within this NumberObjectSingle is NOT changed.
	 * The new NumberObjectSingle is always mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle add(NumberObjectSingle argument, boolean changeOriginal) ;

	/**
	 * If the NumberObjectSingle is mutable, adds the argument to the NumberObject.
	 * Returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle + argument). In this case the number contained within this NumberObjectSingle is NOT changed.
	 * The new NumberObjectSingle is always mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle add(Number argument);

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function adds the argument to the NumberObject.
	 * Returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle + argument). In this case the number contained within this NumberObjectSingle is NOT changed.
	 * The new NumberObjectSingle is always mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle add(Number argument, boolean changeOriginal) ;

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	SUBTRACTION 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/**
	 * If the NumberObjectSingle is mutable, this function subtracts the argument to the NumberObject.
	 * Returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle - argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is always mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle subtract(NumberObjectSingle argument)  ;

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function subtracts the argument to the NumberObject.
	 * Returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle - argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is always mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle subtract(NumberObjectSingle argument, boolean changeOriginal) ;

	/**
	 * If the NumberObjectSingle is mutable, this function subtracts the argument to the NumberObject.
	 * Returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle - argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is always mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle subtract(Number argument)  ;

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function subtracts the argument to the NumberObject.
	 * Returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle - argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is always mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 * @param argument
	 * @return
	 */
	public NumberObjectSingle subtract(Number argument, boolean changeOriginal) ;

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	MULTIPLICATION 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	/**
	 * If the NumberObjectSingle is mutable, multiplies the NumberObjectSingle with the argument, and returns this.
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle * argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle multiply(NumberObjectSingle argument) ;

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function multiplies the NumberObjectSingle
	 * with the argument, and returns this.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle * argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle multiply(NumberObjectSingle argument, boolean changeOriginal) ;

	/**
	 * If the NumberObjectSingle is mutable, multiplies the NumberObjectSingle with the argument, and returns this.
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle * argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle multiply(Number argument) ;

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function multiplies the NumberObjectSingle
	 * with the argument, and returns this.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle * argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle multiply(Number argument, boolean changeOriginal) ;

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	DIVISION 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/**
	 * If the NumberObjectSingle is mutable, divides the NumberObjectSingle contained within the NumberObjectSingle by the argument, and returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle / argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle divide(NumberObjectSingle argument) ;

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function divides the NumberObject
	 * contained within the NumberObjectSingle by the argument, and returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle / argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle divide(NumberObjectSingle argument, boolean changeOriginal)   ;
	/**
	 * If the NumberObjectSingle is mutable, divides the NumberObjectSingle contained within the NumberObjectSingle by the argument, and returns this NumberObject.
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle / argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle divide(Number argument)   ;
	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function divides the NumberObject
	 * contained within the NumberObjectSingle by the argument, and returns this DecimalNumber.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle / argument). In this case the number contained within this NumberObjectSingle is not changed.
	 * Note that the new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle divide(Number argument, boolean changeOriginal)   ;


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	POWER 	/////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/**
	 * If the NumberOject is mutable and changeOrginal is true, this function exponentiates the NumberOject, and returns this NumberObject.
	 *
	 * If the NumberOject is immutable or changeOriginal is false, a new NumberOject is created. This new NumberOject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle ^ argument). In this case the number contained within this NumberOject is not changed.
	 * Note that the new NumberOject is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 */
	public NumberObjectSingle pow(int n, boolean changeOriginal)   ;

	/**
	 * If the NumberOject is mutable, exponentiate the NumberOject, and returns this NumberObject.
	 *
	 * If the NumberOject is immutable, a new NumberOject is created. This new NumberOject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle ^ argument). In this case the number contained within this NumberOject is not changed.
	 * Note that the new NumberOject is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle pow(int n)  ;

	/**
	 * If the NumberOject is mutable and changeOrginal is true, this function exponentiates the NumberOject, and returns this NumberObject.
	 *
	 * If the NumberOject is immutable or changeOriginal is false, a new NumberOject is created. This new NumberOject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle ^ argument). In this case the number contained within this NumberOject is not changed.
	 * Note that the new NumberOject is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle pow(double exponent, boolean changeOriginal)  ;

	/**
	 * If the NumberOject is mutable, exponentiate the NumberOject, and returns this NumberObject.
	 *
	 * If the NumberOject is immutable, a new NumberOject is created. This new NumberOject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (old NumberObjectSingle ^ argument). In this case the number contained within this NumberOject is not changed.
	 * Note that the new NumberOject is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle pow(double exponent)  ;

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Other 	/////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function negates (i.e., -1*value) and returns this NumberObjectSingle
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (-1*value). The new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle negate(boolean changeOriginal)  ;

	/**
	 * If the NumberObjectSingle is mutable, this function negates (i.e., -1*value) and returns this NumberObjectSingle
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * (-1*value). The new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle negate() ;

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, sets the value of this NumberObjectSingle to the complement of 1 (i.e., 1-value), and returns this.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same range (if specified) as the original, and a value equal to
	 * (1-value). The new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle complementOfOne(boolean changeOriginal)   ;

	/**
	 * If the NumberObjectSingle is mutable, sets the value of this NumberObjectSingle to the complement of 1 (i.e., 1-value), and returns this.
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same range (if specified) as the original, and a value equal to
	 * (1-value). The new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle complementOfOne()   ;

	/** If the NumberObjectSingle is mutable and changeOrginal is true, sets the value to its absolute value and returns this NumberObjectSingle
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectis created. This new NumberObject
	 * has the same range (if specified) as the original, and a value equal to
	 * (abs(value)). The new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle abs(boolean changeOriginal)  ;

	/** If the NumberObjectSingle is mutable, sets the value to its absolute value and returns this NumberObjectSingle
	 *
	 * If the NumberObjectSingle is immutable, a new NumberObjectis created. This new NumberObject
	 * has the same range (if specified) as the original, and a value equal to
	 * (abs(value)). The new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle abs()  ;

	/** Returns a new NumberObjectSingle with value (this.number.remainder(other.number)) -- that is, returns a sort-of-modulo that can be negative */
	public NumberObjectSingle remainder(NumberObjectSingle other) ;

	public boolean isDivisibleBy(NumberObjectSingle other) ;

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function winsorizes this NumberObject, and returns this.
	 *
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same value range (if specified) as the original.
	 * Note that the new NumberObjectSingle is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle winsorize(NumberObjectSingle lowerBound, NumberObjectSingle upperBound, boolean changeOriginal)  ;

	/**
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function rounds this NumberObject, and returns this NumberObject.
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same rounded value, class, and same range (if specified) as the original. The new NumberObjectSingle is mutable.
	 *
	 * The scale of the new value is given by digit. Uses the specified RoundingMode.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 */
	public NumberObjectSingle round(int digits, RoundingMode roundingMode, boolean changeOriginal)  	;

	/**
	 * If the NumberObjectSingle is mutable, this function rounds this NumberObject, and returns this NumberObject.
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same rounded value, class, and same range (if specified) as the original. The new NumberObjectSingle is mutable.
	 *
	 * The scale of the new value is given by digit. Uses the specified RoundingMode.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 */
	public NumberObjectSingle round(int digits, RoundingMode roundingMode)  	;

	/**Round the value to the nearest multiple of value. That is, the nearest k*value, where k is any
	 * integer value.
	 * If the NumberObjectSingle is mutable and changeOrginal is true, this function rounds this NumberObject, and returns this NumberObject.
	 * If the NumberObjectSingle is immutable or changeOriginal is false, a new NumberObjectSingle is created. This new NumberObject
	 * has the same rounded value, class, and same range (if specified) as the original. The new NumberObjectSingle is mutable.
	 *
	 * The scale of the new value is given by digit. Uses the specified RoundingMode.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 */
	public NumberObjectSingle roundToNearest(NumberObjectSingle value, RoundingMode roundingMode, boolean changeOriginal)  	;

	
	/** Round the value to the nearest multiple of value. That is, the nearest k*value, where k is any
	 * integer value.
	 * If the NumberObjectSingle is immutable, a new NumberObjectSingle is created. This new NumberObject
	 * has the same rounded value, class, and same range (if specified) as the original. The new NumberObjectSingle is mutable.
	 *
	 * The scale of the new value is given by digit. Uses the specified RoundingMode.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.*/
	public NumberObjectSingle roundToNearest(NumberObjectSingle value, RoundingMode roundingMode);
	

	/**
	 * If the NumberOject is mutable and changeOrginal is true, this function sets this to
	 * modulo(this, other), and returns this NumberObject.
	 *
	 * If the NumberOject is immutable or changeOriginal is false, a new NumberOject is created. This new NumberOject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * ( modulo(this,other) ). In this case the number contained within this NumberOject is not changed.
	 * Note that the new NumberOject is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 *
	 */
	public NumberObjectSingle mod(NumberObjectSingle other, boolean changeOriginal)   ;

	/**
	 * If the NumberOject is mutable, set this value to modulo(this, other), and returns this NumberObject.
	 *
	 * If the NumberOject is immutable, a new NumberOject is created. This new NumberOject
	 * has the same class and range (if specified) as the original, and a value equal to
	 * ( modulo(this, other) ). In this case the number contained within this NumberOject is not changed.
	 * Note that the new NumberOject is mutable.
	 *
	 * In both cases, if the result is not within the range (if specified) a
	 * IllegalRangeException is thrown.
	 */
	public NumberObjectSingle mod(NumberObjectSingle other)  ;


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	toString 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	public String toString() ;

	/** Rounds to significant digits and returns corresponding string. Does not influence value of NumberObjectSingle object. Does not show affixes. */
	public String toString(int significantDigits) ;

	/**Rounds to significant digits and returns corresponding string that reserves a white space for positive values. Does not influence value of NumberObjectSingle object. Does not show affixes.  */
	public String toSignSpacedString(int significantDigits)	;

	/** Returns a string with the value of this NumberObject. Does not display '*' for immutable values or "'" for values with a specified range */
	public String toPlainString() ;

	/** Prints this NumberObjectSingle without any trailing zeros */
	public String toStringWithoutTrailingZeros ();

}
