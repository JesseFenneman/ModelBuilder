package abstractNumberObjectsAndInterfaces;

public interface NamedNumberObjectArray  extends NamedNumberObject {

}
