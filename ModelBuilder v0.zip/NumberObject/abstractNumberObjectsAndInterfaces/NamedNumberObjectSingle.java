package abstractNumberObjectsAndInterfaces;

public interface NamedNumberObjectSingle extends NamedNumberObject {

}
