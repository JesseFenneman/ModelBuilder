package abstractNumberObjectsAndInterfaces;

import java.math.RoundingMode;

import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import doubleNumber.DoubleNumber;
import doubleNumber.DoubleNumberArray;

/** An interface for all single valued NumberFieldArrays. These are DecimalNumberArray or DoubleNumberArray objects - one dimensional vectors */
public interface NumberObjectArray extends NumberObject {

	
	/////////////////////////////////////////////////////////////////////////////
	/////////////////////////// 	Transformations /////////////////////////////
	/////////////////////////////////////////////////////////////////////////////
	/** Returns an array of doubles with the same dimension and values as the NumberObjectArray.*/
	public abstract double[] toDoubleArray() ;

	/** Returns an array of doubles with the same dimension and values as the NumberObjectArray. If required, used RoundingMode to round.*/
	public abstract Integer[] toIntegerArray(RoundingMode roundingMode) ;

	/** Returns a DecimalNumberArray with the same dimension and values as the NumberObjectArray. The result is a deep clone.*/
	public abstract DecimalNumberArray toDecimalNumberArray() ;

	/** Returns a DoubleNumberArray with the same dimension and values as the NumberObjectArray. The result is a deep clone.*/
	public abstract DoubleNumberArray toDoubleNumberArray() ;

	/** Returns a NumberObjectArray of the specified type with the same dimension and values as the NumberObjectArray. */
	public abstract NumberObjectArray toNumberObjectArray(NumberObject.NumberObjectRepresentation formatToUse) ;

	
	/** Returns an array of NumberObjects with the same dimension and values as this. Note: these values are passed by reference
	 * (i.e., they are not clones)*/
	public abstract NumberObjectSingle[] toArray();

	/** Returns an array of NumberObjects with the same dimension and values as this. The values
	 * are converted to the specified format (DoubleNumber or DecimalNumber). The returned NumberObjects are all clones.*/
	public abstract NumberObjectSingle[] toArray(NumberObject.NumberObjectRepresentation formatToUse);



	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////// 	Elementary operations - setters, getters, checks 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/** Returns true if this array is set to immutable. Immutable arrays, and all NumberObjects in this array, cannot be changed. Each attempt at change will result in a UnsupportedException. */
	public abstract boolean isImmutable() ;

	/** Returns the size of the array. */
	public abstract int size() ;

	/** Returns the NumberObject at the specified location. */
	public abstract NumberObjectSingle get(int index) ;

	/** Set the element at the index position of the array. 
	 * If required, creates a new element that matches the class of this NumberObjectArray. 
	 * Throws an UnsupportedOperationException if this NumberObjectArray is immutable. 
	 * Throws an ArrayIndexOutOfBoundsException if the index is out of bounds. */
	public abstract void set(int index, NumberObjectSingle element) 	;

	/** Set the element at the index position of the array. 
	 * Creates a new element that matches the class of this NumberObjectArray. 
	 * Throws an UnsupportedOperationException if this NumberObjectArray is immutable. 
	 * Throws an ArrayIndexOutOfBoundsException if the index is out of bounds. */
	public abstract void set (int index, double element) 	;

	/** Set all NumberObject in the array to the specified value. If this NumberObjectArray ir any NumberObjects within this array are immutable, an UnsupportedException is thrown. All objects in this 
	 * array are replaced with new objects with the specified value.
	 */
	public abstract void setAll(double newValue);

	/** Replaces the values of the NumberObject contained in this array, without
	 * changing the references. Returns false if the length of the newValues does
	 * not match the length of the array.
	 * Throws an ArrayIndexOutOfBoundsException if the index is out of bounds. 
	 * @param newValues
	 * @return
	 */
	public abstract void setAll(NumberObjectArray newValues)  ;

	/** Inserts a NumberObject into the array at the specified position. Returns false if the index is not in the array. This function returns false if the array is immutable (default is that it is not, but immutability can be set by setImmutable()).*/
	public abstract void insert(int index, NumberObjectSingle number);

	/** Removes the NumberObject at the index position. Since this operation involves copying an array of DecimalNumberArrays, it might be an inefficient operation. 
	 * Throws an UnsupportedOperationException if this NumberObjectArray is immutable. 
	 * Throws an ArrayIndexOutOfBoundsException if the index is out of bounds. */
	public abstract void remove(int index) ;

	/** Sets the immutability of the array and all NumberObject in this array. returns this. ATTENTION: THIS FUNCTION SHOULD BE USED WITH CAUTION. There is probably a good reason why something is marked as immutable. 
	 * If the goal is to make this object immutable, consider using makeImmutable() */
	public abstract NumberObjectArray setImmutable(boolean immutability) ;

	/** Sets the immutability of the array and all NumberObject in this array. */
	public abstract void makeImmutable() ;

	/** Sets the immutability of this array only. The NumberObject objects contained within are not changed. */
	public abstract void setImmutableArrayOnly(boolean immutability) ;

	/** Set this array to the array specified.  */
	public abstract void replaceAll(NumberObjectArray newArray) ;

	/** Set the range of all mutable NumberObject objects in this array to the specified range.
	 * Returns true if at least one immutable NumberObject is encountered (note, execution
	 * does not stop after hitting upon an immutable NumberObject - all mutable NumberObject
	 * in this array are changed).
	 * @param minium
	 * @param maximum
	 * @return
	 */
	public abstract void setAllRanges(double minimum, double maximum) ;

	/**
	 * Returns the index of the element in the array. If the element is not in the array, a -1 is returned.
	 * If the element is at multiple positions, the first position is returned.
	 * @param element
	 * @return
	 */
	public abstract int indexOf(NumberObjectSingle element);

	/** Returns the index of the element in the array with a value equal to the element specified. If the element is not in the array, a -1 is returned.
	 * If the element is at multiple positions, the first position is returned.
	 * @param element
	 * @return
	 */
	public abstract int indexOf(double element);

	/** Two arrays are equivalent if and only if each index position houses DecimalNumbers with the same vale.
	 * 
	 * @param other
	 * @return
	 */
	public abstract boolean equals(NumberObjectArray other) ;


	////////////////////////////////////////////////////////////////////////////
	/////////////////// 	toString variants 	////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	/** Returns a string of this array. This string starts with [, and ends with ]. Values are delimited with a tab.
	 * Note that DecimalNumbers that are immutable have a "*" placed at the end (e.g., an immutable 3 is "3.0000*").
	 * DecimalNumbers with a specified range are affixed with a "'". To prevent these affixes, use toPlainString().
	 */
	@Override
	public abstract String toString();

	/** Returns a string of this array. This string starts with [, and ends with ]. Values are delimited with a tab.
	 * Does not show "*" for immutable DecimalNumbers, nor does it show "'" for DecimalNumbers with a specified range.
	 */
	public abstract String toPlainString();

	/** Returns a string of this array. This string starts with [, and ends with ]. Values are delimited with a tab.
	 * All values are rounded to have significantDigits significant digits.
	 * Does not show "*" for immutable DecimalNumbers, nor does it show "'" for DecimalNumbers with a specified range.
	 */
	public abstract String toPlainString(int significantDigits);

	/** Displays the array without any rounding. */
	public abstract String toExactString();

	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////// 	Boolean properties of array ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** Returns true if, and only if, all values in the array are non-negative and sum to 1 (or sum to 1 approximately). */
	public abstract boolean isProbability() ;

	/** Returns true if at least one NumberObject is NULL*/
	public abstract boolean containsNull() ;

	/** Returns true if at least one NumberObject is NaN*/
	public abstract boolean containsNaN() ;

	/** Returns true if at least one NumberObject is positively infinite*/
	public abstract boolean containsPositiveInfinity() ;

	/** Returns true if at least one NumberObject is negatively infinite*/
	public abstract boolean containsNegativeInfinity() ;

	/** Returns true if there is at least one NumberObject object in this array with the same value (not reference)*/
	public abstract boolean contains(NumberObjectSingle element, boolean approximately) ;

	/** Returns true if there is at least one NumberObject object in this array with the same value*/
	public abstract boolean contains(double element, boolean approximately) ;

	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////// 	Operations on this array 	////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** Transform the array such that it sums to one, while retaining the relative proportions of each element to each other element.
	 * Specifically, this function divides each element by the sum of all elements. If the sum is zero, a uniform distribution is set.
	 * 
	 * If the array contains negative values, an UnsupportedOperation exception is thrown.
	 * 
	 * If the underlying decimal number array is contains DecimalNumbers that are immutable, these DecimalNumbers are replaced. 
	 * If the new values of the DecimalNumbers are not in the range specified
	 * for those DecimalNumbers, an IllegalRangeException is thrown. If the values are of an incorrect scale, an IllegalScaleException is returned.
	 * 
	 * If the total sum is zero, a uniform distribution with values of 1/n is set, where n is the number of DecimalNumbers in the array.
	 * 
	 * This function does not do anything is the array is immutable (default is that it is not, but immutability can be set by setImmutable()).
	 */
	public abstract void toProbability()   ;

	/** multiply all values in this array with the scalar. This function does not do anything if the array is immutable (default is that it is not, but immutability can be set by setImmutable()). Returns this*/
	public abstract NumberObjectArray scale(NumberObjectSingle scalar)   ;

	/** multiply all values in this array with the scalar. This function does not do anything if the array is immutable (default is that it is not, but immutability can be set by setImmutable()). Returns this.*/
	public abstract NumberObjectArray scale(double scalar)   ;

	/** Transforms the array sum that all values sum to one, while maintaining the proportions. This function does nothing is the array is set to immutable. If the array sums to zero, a uniform distribution is set. 
	 * returns this.
	 */
	public abstract NumberObjectArray scaleToSumToOne()   ;

	public abstract NumberObjectSingle max();

	public abstract  NumberObjectSingle min();

	/** Determine sum of array. Infinite, NaN and Null values are ignored */
	public abstract NumberObjectSingle sum()	;

	/** Determine number of valid numbers in array. Infinite, NaN and Null values are ignored */
	public abstract int validN() ;

	/** Determine mean of array. Infinite, NaN and Null values are ignored */
	public abstract NumberObjectSingle mean() ;

	/** Determine variance of array. Infinite, NaN and Null values are ignored */
	public abstract NumberObjectSingle variance()  ;

	/** Determine standard deviation of array. Infinite, NaN and Null values are ignored */
	public abstract NumberObjectSingle standardDeviation()  ;


	/////////////////////////////////////////////////////////////////////////////////////
	///////////////////////		Vector multiplication	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	/** Returns the dot product of both arrays. 
	 * Specifically, returns sum( this[i] * otherArray[i] ) for all i in [0, this.length]. 
	 * Returns UnsupportedOperationException if arrays are of unequal length 
	 */ 
	public abstract NumberObjectSingle dotProduct(NumberObjectArray otherArray)  ;

	/////////////////////////////////////////////////////////////////////////////////////
	////////////// 	Other operations resulting in a new array 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	@Override
	public abstract NumberObject clone();

	/** Returns a shallow clone of the original. That is, all
	 * objects in the clone reference the same objects in the 
	 * original - changes in one lead to changes in the other.
	 * 
	 * Note that the new array is mutable, even if the original is
	 * not. This does not hold for the NumberObjects contained within:
	 * because the copy references the same objects, they might still
	 * be immutable.
	 * @return
	 */
	public abstract NumberObjectArray shallowClone();


	/**
	 * Given an array, returns a subset of that array starting from start (inclusive) to stop (exclusive).
	 * Note that this is just a cheap wrapper function of Arrays.copyOfRange, created to increase code
	 * readability
	 * @return
	 */
	public abstract NumberObjectArray subset(int from, int to)	;

	/** Returns a new DecimalNumberArray that is the product of this array and the other array. That is, returns
	 * a new array with values result[i] = this[i] * other[i], for all i.  If the arrays
	 * are of unequal length, a null is returned.
	 * @param other
	 * @return
	 */
	public abstract NumberObjectArray multiply(NumberObjectArray other)  ;

	/**
	 * Returns a new DecimalNumberArray with the concatenated elements of both arrays.
	 * @param array1
	 * @param array2
	 * @return
	 */
	public abstract NumberObjectArray concatenate(NumberObjectArray otherArray);


}
