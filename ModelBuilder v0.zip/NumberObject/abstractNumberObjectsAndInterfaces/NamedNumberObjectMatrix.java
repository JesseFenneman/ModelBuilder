package abstractNumberObjectsAndInterfaces;

public interface NamedNumberObjectMatrix extends NamedNumberObject {

}
