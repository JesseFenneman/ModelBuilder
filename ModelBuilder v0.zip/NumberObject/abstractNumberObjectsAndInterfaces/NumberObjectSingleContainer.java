package abstractNumberObjectsAndInterfaces;

/** A SingleValueContainer Object contains exactly one principal NumberObjectSingle object.
 * Note that there may be other NumberObjects contained within this object. However, one 
 * should be the focal Object. An example might make this clear: a VariableRestrictedRange 
 * contains 3 NumberObjectSingle fields - a value, a minimum, and a maximum. However, one value
 * is clearly more important (value) than the other two (minimum, maximum). As such, this is
 * a SingleValueContainer. This value can be requested using getValue() function. */
public interface NumberObjectSingleContainer {

	public NumberObjectSingle getValue();
}
