package abstractNumberObjectsAndInterfaces;

import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import decimalNumber.NamedDecimalNumber;
import decimalNumber.NamedDecimalNumberArray;
import decimalNumber.NamedDecimalNumberMatrix;
import doubleNumber.DoubleNumber;
import doubleNumber.DoubleNumberArray;
import doubleNumber.DoubleNumberMatrix;

/** An interface that is implemented by NamedDecimalNumber, NamedDecimalNumberArray, and NamedDecimalNumberMatrix. This interface
 * is almost completely blank - it only contains a getName() method. It is used to refer to the group of these three
 * objects.
 * @author Jesse Fenneman
 *
 */
public  interface NamedNumberObject extends NumberObject  {

	public String getName();

	/** Wrap a NumberObject into a NamedDecimalNumber version of that NumberObject*/
	public static NamedNumberObject wrap(String name, NumberObject o) {
		if (o.getClass() == DecimalNumber.class)
			return new NamedDecimalNumber (name, (DecimalNumber) o);
		if (o.getClass() == DecimalNumberArray.class)
			return new NamedDecimalNumberArray(name, (DecimalNumberArray) o);
		if (o.getClass() == DecimalNumberMatrix.class)
			return new NamedDecimalNumberMatrix(name, (DecimalNumberMatrix) o);
		
		if (o.getClass() == DoubleNumber.class)
			throw new UnsupportedOperationException("DoubleNumber class not instantiated yet");
		if (o.getClass() == DoubleNumberArray.class)
			throw new UnsupportedOperationException("DoubleNumber class not instantiated yet");
		if (o.getClass() == DoubleNumberMatrix.class)
			throw new UnsupportedOperationException("DoubleNumber class not instantiated yet");
		
		throw new IllegalArgumentException("Trying to wrap unknown class");
	}

	public NumberObject toNumberObject();

}
