package abstractNumberObjectsAndInterfaces;

/** A NumberObjectArrayContainer contains at least one NumberObjectArray, which can be
 * requested via the getArray function. If that object contains multiple 
 * NumberObjectArrays, the most important one is returned. */
public interface NumberObjectArrayContainer {
	
	public NumberObjectArray getArray();

}
