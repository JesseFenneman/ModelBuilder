package abstractNumberObjectsAndInterfaces;

/** A NumberObjectMatrixContainer contains at least one NumberObjectMatrix, which can be
 * requested via the getMatrix function. If that object contains multiple 
 * NumberObjectMatrices, the most important one is returned. */
public interface NumberObjectMatrixContainer {

	public NumberObjectMatrix getMatrix();
}
