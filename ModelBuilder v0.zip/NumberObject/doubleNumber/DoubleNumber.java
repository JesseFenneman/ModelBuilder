package doubleNumber;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import decimalNumber.DecimalNumber;
import helper.Helper;

public class DoubleNumber implements  Comparable<DoubleNumber>, Serializable, NumberObjectSingle {
	
	private static final long serialVersionUID = -7217636323301617235L;
	
	public static final RoundingMode 	ROUNDING_MODE 	= RoundingMode.HALF_EVEN;
	public static final int				PRECISION 		= 12;		// The total number of digits (using scientific notation) of the DecimalNumber
	public static final int				SCALE			= 12;		// The total number of digits after the decimal point.
	public static final MathContext MC = new MathContext(PRECISION, ROUNDING_MODE);

	public static final boolean 		CHECK_VALIDITY 		= true;
	public static final boolean			useApproximateValuesWhenCheckingValidity = true;
	public static final DoubleNumber 	boundsOfApproximation = new DoubleNumber("0." + Helper.repString("0", 12) + "1"); // 12 seems to be a good number - The results from R are usually accurate until 16 digits

	public static boolean isDouble (String s)	{
		if (s.length() == 0) return false;
		String doubleRegex = "(-?\\d*)|(-?\\d*\\.\\d+)";
		return (s.matches(doubleRegex));
	}
	
	
	
	/////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	FIELDS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////

	private 		double 		number;
	private  		double 		minimum;
	private		 	double		maximum;
	private  		boolean			immutable;
	private  		boolean			rangeSpecified;
	private final 	VALUE_FLAG 		flag;

	
	
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	CONSTRUCTORS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** The main constructor. Most, if not all, other constructors refer back to this one. It is private because in theory you can make a ranged DoubleNumber that never checks its range. */
	public DoubleNumber(BigDecimal value, BigDecimal minimum, BigDecimal maximum, boolean rangeSpecified, boolean immutable) {
		this.number = value.doubleValue();
		this.minimum = minimum.doubleValue();
		this.maximum = maximum.doubleValue();
		this.rangeSpecified = rangeSpecified;
		this.immutable = immutable;
		this.flag = VALUE_FLAG.NORMAL;
		checkPostconditions();
	}

	/** The main constructor. Most, if not all, other constructors refer back to this one. It is private because in theory you can make a ranged DoubleNumber that never checks its range. */
	public DoubleNumber(double value, double minimum, double maximum, boolean rangeSpecified, boolean immutable) {
		this.number = value;
		this.minimum = minimum;
		this.maximum = maximum;
		this.rangeSpecified = rangeSpecified;
		this.immutable = immutable;
		this.flag = VALUE_FLAG.NORMAL;
		checkPostconditions();
	}

	/** Creates a new mutable DoubleNumber without a specified range
	 *
	 * @param value
	 * @return
	 */
	public DoubleNumber (Number value)  {
		this(value.doubleValue(), 0, 0, false, false);
	}

	/** Creates a new mutable DoubleNumber without a specified range
	 *
	 * @param value
	 * @return
	 */
	public DoubleNumber(String value)  {
		this (Double.parseDouble(value), 0, 0, false, false);
	}

	/** Creates a new mutable DoubleNumber without a specified range
	 *
	 * @param value
	 * @return
	 */
	public  DoubleNumber (BigDecimal value)  {
		this (value.doubleValue(), 0, 0, false, false);
	}

	/** Copy constructor. Returns a shallow clone (the objects in this number point to the original objects).
	 * For a deep clone, use the clone() function */
	public DoubleNumber (NumberObjectSingle value)  {
		number = value.toDouble();
		rangeSpecified = value.hasRangeRestriction();
		if (rangeSpecified) {
			minimum = value.getMinimum().toDouble();
			maximum = value.getMaximum().toDouble();
		}
		immutable = false;
		
		this.flag = value.getFlag();
		checkPostconditions();
	}

	/** Creates a new DoubleNumber without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public DoubleNumber (Number value, boolean immutable)  {
		this (value.doubleValue(), 0, 0, false, immutable);
	}

	/** Creates a new DoubleNumber without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public  DoubleNumber (String value, boolean immutable)  {
		this (Double.parseDouble(value), 0, 0, false, immutable);
	}

	/** Creates a new DoubleNumber without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public DoubleNumber (BigDecimal value, boolean immutable)  {
		this (value.doubleValue(), 0, 0, false, immutable);
	}

	/** Creates a new DoubleNumber without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public DoubleNumber (NumberObjectSingle value, boolean immutable)  {
		this (value.toDouble(), 0, 0, false, immutable);
	}

	/** Creates a DoubleNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DoubleNumber(Number value, Number minimum, Number maximum, boolean immutable) {
		this (value.doubleValue(), minimum.doubleValue(), maximum.doubleValue(), true, immutable);
	}

	/** Creates a DoubleNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DoubleNumber(Number value, NumberObjectSingle minimum, NumberObjectSingle maximum, boolean immutable) {
		this (value.doubleValue(), minimum.toDouble(), maximum.toDouble(), true, immutable);
	}

	/** Creates a DoubleNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DoubleNumber (String value, String minimum, String maximum, boolean immutable) {
		this (Double.parseDouble(value), Double.parseDouble(minimum), Double.parseDouble(minimum), true, immutable);
	}

	/** Creates a DoubleNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DoubleNumber (BigDecimal value, BigDecimal minimum, BigDecimal maximum, boolean immutable) {
		this (value.doubleValue(), minimum.doubleValue(), maximum.doubleValue(), true, immutable);
	}

	/** Creates a DoubleNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DoubleNumber (NumberObjectSingle value, NumberObjectSingle minimum, NumberObjectSingle maximum, boolean immutable) {
		this (value.toDouble(), minimum.toDouble(), maximum.toDouble(), true, immutable);

	}

	/** Compute n! in a very non-optimized manner */
	public static DoubleNumber factorial(int n) {

		if(n < 0){  throw new IllegalArgumentException("Using negative value in factorial.");  }

		DoubleNumber factorial = new DoubleNumber(1);

		for (int i = 1; i <= n; i++) {
			factorial = factorial.multiply(i,true);
		}
		return factorial;
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Constants 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** Constructor used to create the NULL, NaN, POSITIVE_INFINITY, and NEGATVE_INFINITY objects. Will throw an IllegalStateException if the flag is NORMAL*/
	private DoubleNumber(VALUE_FLAG flag ) {
		if (flag == VALUE_FLAG.NORMAL)
			throw new IllegalStateException("Trying to use the constructor reserved for the special flag objects to create a normal DecimalNumber");
		this.number= 0;
		this.minimum = 0;
		this.maximum = 0;
		this.rangeSpecified = false;
		this.immutable = true;
		this.flag = flag;
	}

	/**
	 * Creates an immutable DoubleNumber with value 0 and without a specified range.
	 * @return
	 */
	private static DoubleNumber ZERO() {
		try {
			return new DoubleNumber(BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, false, true);
		} catch (IllegalRangeException e) {
			e.printStackTrace();
			return null;
		}
	}
	public static final DoubleNumber ZERO = ZERO();

	/**
	 * Creates a immutable DoubleNumber with value 1 and without a specified range.
	 * @return
	 */
	private static DoubleNumber ONE() {
		try {
			return new DoubleNumber(BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ONE, false, true);
		} catch (IllegalRangeException e) {
			e.printStackTrace();
			return null;
		}
	}
	public static final DoubleNumber ONE = ONE();

	/** Creates a immutable DoubleNumber with a NULL flag. This object cannot be changed, and cannot be used in any further computation.
	 * @return
	 */
	private static DoubleNumber NULL() {return new DoubleNumber(VALUE_FLAG.NULL);	}
	public static final DoubleNumber NULL = NULL();

	/** Creates a immutable DoubleNumber with a NULL flag. This object cannot be changed, and cannot be used in any further computation.
	 * @return
	 */
	private static DoubleNumber NaN() {return new DoubleNumber(VALUE_FLAG.NaN);	}
	public static final DoubleNumber NaN = NaN();

	/** Creates a immutable DoubleNumber with a NULL flag. This object cannot be changed, and cannot be used in any further computation.
	 * @return
	 */
	private static DoubleNumber POSITIVE_INFINITY() {return new DoubleNumber(VALUE_FLAG.POSITIVE_INFINITY);	}
	public static final DoubleNumber POSITIVE_INFINITY = POSITIVE_INFINITY();

	/** Creates a immutable DoubleNumber with a NULL flag. This object cannot be changed, and cannot be used in any further computation.
	 * @return
	 */
	private static DoubleNumber NEGATIVE_INFINITY() {return new DoubleNumber(VALUE_FLAG.NEGATIVE_INFINITY);	}
	public static final DoubleNumber NEGATIVE_INFINITY = NEGATIVE_INFINITY();
	
	@Override
	public boolean hasNonNormalFlag() {
		if (this.flag == null)
			return false;
		if (this.flag == VALUE_FLAG.NORMAL)
			return false;
		return true;
	}
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Validity checks 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////	
	@Override
	public void checkPreconditions(boolean changingObject) {
		if (this.flag== VALUE_FLAG.NULL)
			throw new NumberObjectNULLException("Trying to perform a mathematical operation on a NULL DecimalNumber.");
		if (this.flag== VALUE_FLAG.NaN)
			throw new NumberObjectNaNException("Trying to perform a mathematical operation on a NaN DecimalNumber.");
		if (this.flag== VALUE_FLAG.POSITIVE_INFINITY)
			throw new NumberObjectPositiveInfinityException("Trying to perform a mathematical operation on a positive infinity DecimalNumber.");
		if (this.flag== VALUE_FLAG.NEGATIVE_INFINITY)
			throw new NumberObjectNegativeInfinityException("Trying to perform a mathematical operation on a negative infinity DecimalNumber.");

		if (immutable && changingObject)
			throw new UnsupportedOperationException("Exception in DecimalNumber: trying to set an immutable DecimalNumber.");
	}
	@Override
	public void checkPostconditions() {
		if (!CHECK_VALIDITY ) return;

		// check the scale
		if (flag == VALUE_FLAG.NORMAL) {
			
			// check to see if the new value is still in range
			if (rangeSpecified && (number < minimum|| number > maximum)) {
				if (!useApproximateValuesWhenCheckingValidity)
					throw new IllegalRangeException("Check failed: ended up with a DoubleNumber with a value of " + number+ ", although the minimum and maximum are " + minimum+ " and " + maximum+ ", respectively.");
				else if (!this.equals(minimum, true) && !this.equals(maximum, true) )
					throw new IllegalRangeException("Check failed: ended up with a DecimalNumber with a value of " + number+ ", although the minimum and maximum are " + minimum+ " and " + maximum + ", respectively.");
			}
		}

	}
	@Override
	public void makeImmutable() {
		this.immutable = true;
	}
	@Override
	public boolean matchesFieldRestriction(FieldRestriction ft) {
		return (FieldRestriction.isValid(this.toPlainString(), ft));
	}

	@Override
	public String toRParsableString() {
		return this.toPlainString();
	}


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Type checks 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	@Override
	public boolean isNull() { return this.flag == VALUE_FLAG.NULL;}

	@Override
	public boolean isNaN() { return this.flag == VALUE_FLAG.NaN;}

	@Override
	public boolean isPositiveInfinity() { return this.flag == VALUE_FLAG.POSITIVE_INFINITY;}

	@Override
	public boolean isNegativeInfinity() {return this.flag == VALUE_FLAG.NEGATIVE_INFINITY;}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Setters 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void mimic(NumberObjectSingle n) {
		checkPreconditions(true);

		if (n.getFlag()== VALUE_FLAG.NULL)
			throw new NumberObjectNULLException("Trying to mimic a NULL DoubleNumber.");
		if (n.getFlag()== VALUE_FLAG.NaN)
			throw new NumberObjectNaNException("Trying to mimic a NaN DoubleNumber.");
		if (n.getFlag()== VALUE_FLAG.POSITIVE_INFINITY)
			throw new NumberObjectPositiveInfinityException("Trying to mimic a positive infinity DecimalNumber.");
		if (n.getFlag()== VALUE_FLAG.NEGATIVE_INFINITY)
			throw new NumberObjectNegativeInfinityException("Trying to mimic a negative infinity DecimalNumber.");


		this.number=n.toDouble();
		this.minimum=n.getMinimum().toDouble();
		this.maximum=n.getMaximum().toDouble();
		this.rangeSpecified=n.hasRangeRestriction();
		this.immutable=n.isImmutable();
		checkPostconditions();
	}

	@Override
	public DoubleNumber set(Number argument) {
		checkPreconditions(true);
		number  = argument.doubleValue();
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber set(String argument) {
		checkPreconditions(true);
		number  = Double.parseDouble(argument);
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber set(NumberObjectSingle argument) {
		checkPreconditions(true);
		number  = argument.toDouble();
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber setImmutable(boolean immutability) {
		this.immutable = immutability;
		return this;
	}

	@Override
	public DoubleNumber removeRangeRestrictions() {
		checkPreconditions(true);
		rangeSpecified = false;
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber setRange(Number minimum, Number maximum) {
		checkPreconditions(true);
		rangeSpecified = true;
		setRangeMinimumWithoutValidation(minimum);
		setRangeMaximumWithoutValidation(maximum);
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber setRange(NumberObjectSingle minimum, NumberObjectSingle maximum) {
		checkPreconditions(true);
		rangeSpecified = true;
		setRangeMinimumWithoutValidation(maximum);
		setRangeMaximumWithoutValidation(minimum);
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber setRangeMinimum(Number minimum) {
		checkPreconditions(true);
		this.minimum = minimum.doubleValue();
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber setRangeMinimum(NumberObjectSingle minimum) {
		checkPreconditions(true);
		this.minimum = minimum.toDouble();
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber setRangeMinimumWithoutValidation(Number minimum) {
		checkPreconditions(true);
		this.minimum = minimum.doubleValue();
		return this;
	}

	@Override
	public DoubleNumber setRangeMinimumWithoutValidation(NumberObjectSingle minimum) {
		checkPreconditions(true);
		this.minimum = minimum.toDouble();
		return this;
	}

	@Override
	public DoubleNumber setRangeMaximum(Number maximum) {
		checkPreconditions(true);
		this.maximum = maximum.doubleValue();
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber setRangeMaximum(NumberObjectSingle maximum) {
		checkPreconditions(true);
		this.maximum = maximum.toDouble();
		checkPostconditions();
		return this;
	}

	@Override
	public DoubleNumber setRangeMaximumWithoutValidation(Number maximum) {
		checkPreconditions(true);
		this.maximum = maximum.doubleValue();
		return this;
	}

	@Override
	public DoubleNumber setRangeMaximumWithoutValidation(NumberObjectSingle maximum) {
		checkPreconditions(true);
		this.maximum = maximum.toDouble();
		return this;
	}

	@Override
	public DoubleNumber useRange(boolean hasRangeSpecified) {
		this.rangeSpecified = hasRangeSpecified;
		return this;
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Getters 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public VALUE_FLAG getFlag() {
		return this.flag;
	}

	@Override
	public boolean isImmutable() {
		return this.immutable;
	}

	@Override
	public boolean hasRangeRestriction() {
		return this.rangeSpecified;
	}

	@Override
	public int getSignificantDigits() {
		DecimalNumber clone = new DecimalNumber(number);
		return clone.getSignificantDigits();
	}

	@Override
	public DoubleNumber clone() {
		if (flag == VALUE_FLAG.NaN)
			return DoubleNumber.NaN;
		if (flag == VALUE_FLAG.NULL)
			return DoubleNumber.NULL;
		if (flag == VALUE_FLAG.NEGATIVE_INFINITY)
			return DoubleNumber.NEGATIVE_INFINITY;
		if (flag == VALUE_FLAG.POSITIVE_INFINITY)
			return  DoubleNumber.POSITIVE_INFINITY;

		try {return new DoubleNumber(number, minimum, maximum, rangeSpecified, false);		} catch (IllegalRangeException e) {	e.printStackTrace();	}
		return null;
	}

	@Override
	public DoubleNumber getMinimum() {
		if (this.rangeSpecified)
			return new DoubleNumber(this.minimum);
		else
			return DoubleNumber.NEGATIVE_INFINITY;
	}

	@Override
	public DoubleNumber getMaximum() {
		if (this.rangeSpecified)
			return new DoubleNumber(this.maximum);
		else
			return DoubleNumber.POSITIVE_INFINITY;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Comparisons 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** Used when there is at least one non-null flag involved in a comparison*/
	private void checkIfThereAreFlagsInThisComparison(NumberObjectSingle o) {
		VALUE_FLAG thisFlag = this.getFlag();
		VALUE_FLAG otherFlag = o.getFlag();

		if ((thisFlag == VALUE_FLAG.NORMAL || thisFlag == null) && (otherFlag == VALUE_FLAG.NORMAL || otherFlag == null) )
			return;
		
		if (thisFlag== VALUE_FLAG.POSITIVE_INFINITY || otherFlag  == VALUE_FLAG.POSITIVE_INFINITY)
			throw new NumberObjectPositiveInfinityException("");
		
		if (thisFlag == VALUE_FLAG.NEGATIVE_INFINITY || otherFlag == VALUE_FLAG.NEGATIVE_INFINITY)
			throw new NumberObjectNegativeInfinityException("");
		
		if (thisFlag == VALUE_FLAG.NULL || otherFlag == VALUE_FLAG.NULL )
			throw new NumberObjectNULLException("");
		
		if (thisFlag == VALUE_FLAG.NaN|| otherFlag == VALUE_FLAG.NaN )
			throw new NumberObjectNaNException("");
		
		throw new IllegalStateException("Unknown flag found");
	}
	
	/** Used when there is at least one non-null flag involved in a comparison*/
	private void checkIfThereAreFlagsInThisComparison(Number o) {
		VALUE_FLAG thisFlag = this.getFlag();
	
		if ((thisFlag == VALUE_FLAG.NORMAL || thisFlag == null)  )
			return;
		
		if (thisFlag== VALUE_FLAG.POSITIVE_INFINITY )
			throw new NumberObjectPositiveInfinityException("");
		
		if (thisFlag == VALUE_FLAG.NEGATIVE_INFINITY)
			throw new NumberObjectNegativeInfinityException("");
		
		if (thisFlag == VALUE_FLAG.NULL)
			throw new NumberObjectNULLException("");
		
		if (thisFlag == VALUE_FLAG.NaN)
			throw new NumberObjectNaNException("");
		
		throw new IllegalStateException("Unknown flag found");
	}
	
	@Override
	public boolean largerThan(NumberObjectSingle o) {
		checkIfThereAreFlagsInThisComparison(o);
		return (this.compareTo(o) > 0); 
	}

	@Override
	public boolean largerThan(Number o) {
		checkIfThereAreFlagsInThisComparison(o);
		return this.number > o.doubleValue();
	}

	@Override
	public boolean largerThanOrEqualTo(NumberObjectSingle o) {
		checkIfThereAreFlagsInThisComparison(o);
		return (this.compareTo(o) >= 0); 
	}

	@Override
	public boolean largerThanOrEqualTo(Number o) {
		checkIfThereAreFlagsInThisComparison(o);
		return this.number >= o.doubleValue();
	}

	@Override
	public boolean smallerThan(NumberObjectSingle o) {
		checkIfThereAreFlagsInThisComparison(o);
		return (this.compareTo(o) < 0); 	
	}

	@Override
	public boolean smallerThan(Number o) {
		checkIfThereAreFlagsInThisComparison(o);
		return this.number < o.doubleValue();
	}

	@Override
	public boolean smallerThanOrEqualTo(NumberObjectSingle o) {
		checkIfThereAreFlagsInThisComparison(o);
		return (this.compareTo(o) <= 0); 	
	}

	@Override
	public boolean smallerThanOrEqualTo(Number o) {
		checkIfThereAreFlagsInThisComparison(o); 
		return this.number <= o.doubleValue();
	}



	
	@Override
	public boolean largerThan(NumberObjectSingle o, boolean approximately) {
		checkIfThereAreFlagsInThisComparison(o);
		if (!approximately)
			return this.largerThan(o);
		return (this.compareTo(o.add(boundsOfApproximation)) > 0); 
	}

	@Override
	public boolean largerThan(Number o, boolean approximately) {
		checkIfThereAreFlagsInThisComparison(o);
		
		if (!approximately)
			return this.largerThan(o);
		return this.number > o.doubleValue() + boundsOfApproximation.toDouble();
	}

	@Override
	public boolean largerThanOrEqualTo(NumberObjectSingle o, boolean approximately) {
		checkIfThereAreFlagsInThisComparison(o);
		if (!approximately)
			return this.largerThanOrEqualTo(o);
		return (this.compareTo(o.add(boundsOfApproximation)) >= 0); 
	}

	@Override
	public boolean largerThanOrEqualTo(Number o, boolean approximately) {
		checkIfThereAreFlagsInThisComparison(o);
		if (!approximately)
			return this.largerThanOrEqualTo(o);
		return this.number >= o.doubleValue() + boundsOfApproximation.toDouble();
	}

	@Override
	public boolean smallerThan(NumberObjectSingle o, boolean approximately) {
		checkIfThereAreFlagsInThisComparison(o);
		if (!approximately)
			return this.smallerThan(o);
		return (this.compareTo(o.subtract(boundsOfApproximation)) < 0); 	
	}

	@Override
	public boolean smallerThan(Number o, boolean approximately) {
		checkIfThereAreFlagsInThisComparison(o);
		if (!approximately)
			return this.smallerThan(o);
		return this.number < o.doubleValue() - boundsOfApproximation.toDouble();
	}

	@Override
	public boolean smallerThanOrEqualTo(NumberObjectSingle o, boolean approximately) {
		checkIfThereAreFlagsInThisComparison(o);
		if (!approximately)
			return this.smallerThanOrEqualTo(o);
		return (this.compareTo(o.subtract(boundsOfApproximation)) <= 0); 	
	}

	@Override
	public boolean smallerThanOrEqualTo(Number o, boolean approximately) {
		checkIfThereAreFlagsInThisComparison(o);
		if (!approximately)
			return this.smallerThanOrEqualTo(o);
		return this.number <= o.doubleValue() - boundsOfApproximation.toDouble();
	}

	@Override
	public int compareTo(NumberObjectSingle o) {
		checkIfThereAreFlagsInThisComparison(o);
		if (number < o.toDouble())
			return -1;
		if (number > o.toDouble())
			return 1;
		return 0;
	}

	@Override
	public int compareTo(Number o) {
		checkIfThereAreFlagsInThisComparison(o);
		if (number < o.doubleValue())
			return -1;
		if (number > o.doubleValue())
			return 1;
		return 0;
	}
	
	@Override
	public int compareTo(DoubleNumber o) {
		return this.compareTo(o.toDouble());
	}


	@Override
	public boolean equals(NumberObjectSingle o, boolean approximately) {
		return this.equals(o.toDouble(), approximately);
	}

	@Override
	public boolean equals(BigDecimal o, boolean approximately) {
		return this.equals(o.doubleValue(), approximately);
	}

	@Override
	public boolean equals(double o, boolean approximately) {
		checkIfThereAreFlagsInThisComparison(o);
		if (!approximately)
			return number == o;

		NumberObjectSingle referencePoint = new DoubleNumber(o);
		//referencePoint.useRange(false);
		if (inRange(referencePoint.subtract(boundsOfApproximation, false), referencePoint.add(boundsOfApproximation, false)))
			return true;
		return false;
	}

	@Override
	public boolean equals(double o) {
		return number == o;
	}

	@Override
	public boolean equals(String s) {
		return number == Double.parseDouble(s);
	}

	@Override
	public boolean equals(BigDecimal o) {
		return this.number == o.doubleValue();
	}

	@Override
	public boolean equals(NumberObjectSingle o) {
		return this.number == o.toDouble();
	}
	@Override
	public boolean equals(Object o) {

		if (o instanceof NumberObjectSingle)
			return this.equals((NumberObjectSingle) o, false);
		return false;

	}
	@Override
	public boolean inRange(double lowerBound, double upperBound) {
		checkIfThereAreFlagsInThisComparison(lowerBound);
		return number >= lowerBound && number <= upperBound;
	}

	@Override
	public boolean inRange(NumberObjectSingle lowerBound, NumberObjectSingle upperBound) {
		checkIfThereAreFlagsInThisComparison(lowerBound);
		return number >= lowerBound.toDouble() && number <= upperBound.toDouble();
	}

	@Override
	public boolean isInteger() {
		return (number % 1) == 0;
	}

	@Override
	public DoubleNumber toDoubleNumber() {
		return this;
	}

	@Override
	public DecimalNumber toDecimalNumber() {
		return new DecimalNumber(this.toDouble());
	}

	@Override
	public NumberObjectSingle toNumberObjectSingle(NumberObjectRepresentation formatToUse) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return this.toDecimalNumber();
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return  this.toDoubleNumber();
		throw new UnknownNumberObjectException();
	}

	@Override
	public BigDecimal toBigDecimal() {
		//throw new IllegalStateException("Test");
		return new BigDecimal(""+this.number);
	}

	@Override
	public int toInt(RoundingMode roundingMode) {
		return this.round(0, roundingMode, false).toBigDecimal().intValue();
	}

	@Override
	public double toDouble() {
		return number;
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	ADDITION 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	private DoubleNumber add(double argument, boolean changeOriginal)  {
		this.checkPreconditions(changeOriginal);
		double newNumber = number + argument;

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal ) {
			this.number = newNumber;
			this.checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}
	
	@Override
	public DoubleNumber add(NumberObjectSingle argument) {
		if (argument.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + argument.getFlag() +" flag.");
		return add(argument.toDouble(), false);
	}

	@Override
	public DoubleNumber add(NumberObjectSingle argument, boolean changeOriginal) {
		if (argument.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + argument.getFlag() +" flag.");
		return add(argument.toDouble(), changeOriginal);
	}

	@Override
	public DoubleNumber add(Number argument) {
		return add(argument.doubleValue(), false);
	}

	@Override
	public DoubleNumber add(Number argument, boolean changeOriginal) {
		return add(argument.doubleValue(), changeOriginal);
	}
	/**
	 * Adds the value of the two DoubleNumbers and returns a new mutable DoubleNumber. The range of
	 * the resulting DoubleNumber is unspecified.
	 * @param dn1
	 * @param dn2
	 * @return
	 */
	public static DoubleNumber add(DoubleNumber dn1, DoubleNumber dn2){
		if (dn1.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + dn1.getFlag() +" flag.");
		if (dn2.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + dn2.getFlag() +" flag.");
		return new DoubleNumber(dn1.add(dn2));
	}

	/**
	 * Adds the two double values and returns a DecimalNumber with that value. The DecimalNumber
	 * has a fixed scale and precision.
	 * @param d1
	 * @param d2
	 * @return
	 */
	public static DoubleNumber add(double d1, double d2)  {
		return new DoubleNumber(d1+d2);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	SUBTRACTION 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	private DoubleNumber subtract(double argument, boolean changeOriginal)  {
		this.checkPreconditions(changeOriginal);
		double newNumber = number - argument;

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal ) {
			this.number = newNumber;
			this.checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}
	@Override
	public DoubleNumber subtract(NumberObjectSingle argument) {
		if (argument.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + argument.getFlag() +" flag.");
		return subtract(argument.toDouble(), false);
	}

	@Override
	public DoubleNumber subtract(NumberObjectSingle argument, boolean changeOriginal) {
		if (argument.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + argument.getFlag() +" flag.");
		return subtract(argument.toDouble(), changeOriginal);
	}

	@Override
	public DoubleNumber subtract(Number argument) {
		return subtract(argument.doubleValue(), false);
	}

	@Override
	public DoubleNumber subtract(Number argument, boolean changeOriginal) {
		return subtract(argument.doubleValue(), changeOriginal);
	}
	/**
	 * Subtracts the value of the two DecimalNumbers and returns a new mutable DecimalNumber. The range of
	 * the resulting DecimalNumber is unspecified.
	 * @param dn1
	 * @param dn2
	 * @return
	 */
	public static DoubleNumber subtract(DoubleNumber dn1, DoubleNumber dn2) {
		if (dn1.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + dn1.getFlag() +" flag.");
		if (dn2.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + dn2.getFlag() +" flag.");
		return dn1.subtract(dn2, false);
	}

	/**
	 * Subtracts the two double values and returns a DecimalNumber with that value. The DecimalNumber
	 * has a fixed scale and precision.
	 * @param d1
	 * @param d2
	 * @return
	 */
	public static DoubleNumber subtract(double d1, double d2)  {
		return new DoubleNumber(d1-d2);
	}


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	MULTIPLICATION 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	private DoubleNumber multiply(double argument, boolean changeOriginal)  {
		this.checkPreconditions(changeOriginal);
		double newNumber = number * argument;

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal ) {
			this.number = newNumber;
			this.checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}
	@Override
	public DoubleNumber multiply(NumberObjectSingle argument) {
		if (argument.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + argument.getFlag() +" flag.");
		return multiply(argument.toDouble(), false);
	}

	@Override
	public DoubleNumber multiply(NumberObjectSingle argument, boolean changeOriginal) {
		if (argument.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + argument.getFlag() +" flag.");
		return multiply(argument.toDouble(), changeOriginal);
	}

	@Override
	public DoubleNumber multiply(Number argument) {
		return this.multiply(argument.doubleValue(), false);
	}

	@Override
	public DoubleNumber multiply(Number argument, boolean changeOriginal) {
		return this.multiply(argument.doubleValue(), changeOriginal);
	}
	/**
	 * Multiplies the value of the two DoubleNumber and returns a new mutable DoubleNumber. The range of
	 * the resulting DoubleNumber is unspecified.
	 * @param dn1
	 * @param dn2
	 * @return
	 */
	public static DoubleNumber multiply(DoubleNumber dn1, DoubleNumber dn2)  {
		if (dn1.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + dn1.getFlag() +" flag.");
		if (dn2.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + dn2.getFlag() +" flag.");
		return dn1.multiply(dn2, false);
	}

	/**
	 * Multiplies the two double values and returns a DoubleNumber with that value. The DoubleNumber
	 * has a fixed scale and precision.
	 * @param d1
	 * @param d2
	 * @return
	 */
	public static DoubleNumber multiply(double d1, double d2)  {
		return new DoubleNumber(d1*d2);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	DIVISION 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	private DoubleNumber divide(double argument, boolean changeOriginal)  {
		this.checkPreconditions(changeOriginal);
		double newNumber =  number / argument;

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal ) {
			this.number = newNumber;
			this.checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}
	@Override
	public DoubleNumber divide(NumberObjectSingle argument) {
		if (argument.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + argument.getFlag() +" flag.");
		return divide(argument.toDouble(), false);
	}

	@Override
	public DoubleNumber divide(NumberObjectSingle argument, boolean changeOriginal) {
		if (argument.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + argument.getFlag() +" flag.");
		return divide(argument.toDouble(), changeOriginal);
	}

	@Override
	public DoubleNumber divide(Number argument) {
		return divide(argument.doubleValue(), false);
	}

	@Override
	public DoubleNumber divide(Number argument, boolean changeOriginal) {
		return divide(argument.doubleValue(), changeOriginal);
	}
	/**
	 * Divides the value of the two DoubleNumber and returns a new mutable DoubleNumber. The range of
	 * the resulting DoubleNumber is unspecified.
	 * @param dn1
	 * @param dn2
	 * @return
	 */
	public static DoubleNumber divide(DoubleNumber dn1, DoubleNumber dn2)  {
		if (dn1.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + dn1.getFlag() +" flag.");
		if (dn2.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + dn2.getFlag() +" flag.");
		return dn1.divide(dn2, false);
	}

	/**
	 * Divides the two double values and returns a DoubleNumber with that value. The DoubleNumber
	 * has a fixed scale and precision.
	 * @param d1
	 * @param d2
	 * @return
	 */
	public static DoubleNumber divide(double d1, double d2)  {
		return new DoubleNumber(d1/d2);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	POWER 	/////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DoubleNumber pow(int n, boolean changeOriginal) {
		checkPreconditions(changeOriginal);
		double newNumber = Math.pow(number, n);

		// If the DoubleNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	
	}

	@Override
	public DoubleNumber pow(int n) {
		return pow(n, false);
	}

	@Override
	public DoubleNumber pow(double exponent, boolean changeOriginal) {
		return pow(exponent, changeOriginal);
	}

	@Override
	public DoubleNumber pow(double exponent) {
		return pow(exponent, false);
	}
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Other 	/////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DoubleNumber negate(boolean changeOriginal) {
		checkPreconditions(changeOriginal);
		double newNumber = -1*number;

		// If the DoubleNumber is mutable, and we want to change the DoubleNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	
	}

	@Override
	public DoubleNumber negate() {
		return this.negate(false);
	}

	@Override
	public DoubleNumber complementOfOne(boolean changeOriginal) {
		checkPreconditions(changeOriginal);
		double newNumber =1-this.number;

		// If the DoubleNumber is mutable, and we want to change the DoubleNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	
	}

	@Override
	public DoubleNumber complementOfOne() {
		return this.complementOfOne(false);
	}

	@Override
	public DoubleNumber abs(boolean changeOriginal) {
		checkPreconditions(changeOriginal);
		double  newNumber = Math.abs(number);

		// If the DoubleNumber is mutable, and we want to change the DoubleNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);

	}

	@Override
	public DoubleNumber abs() {
		return this.abs(false);
	}

	@Override
	public DoubleNumber remainder(NumberObjectSingle other) {
		if (other.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + other.getFlag() +" flag.");
		return new DoubleNumber(new BigDecimal(""+number).remainder(other.toBigDecimal()));
	}

	@Override
	public boolean isDivisibleBy(NumberObjectSingle other) {
		if (other.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + other.getFlag() +" flag.");
		return this.number % other.toDouble() == 0;
	}

	@Override
	public DoubleNumber winsorize(NumberObjectSingle lowerBound, NumberObjectSingle upperBound,
			boolean changeOriginal) {
		if (lowerBound.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + lowerBound.getFlag() +" flag.");
		if (upperBound.hasNonNormalFlag())
			throw new IllegalArgumentException("Cannot perform operation using a NumberObjectSingle with a " + upperBound.getFlag() +" flag.");
		
		checkPreconditions(changeOriginal);
		double newNumber;
		if (number < lowerBound.toDouble())
			newNumber = lowerBound.toDouble();
		else if (number > upperBound.toDouble())
			newNumber = upperBound.toDouble();
		else
			newNumber = number;
	
		// If the DoubleNumber is mutable, and we want to change the DoubleNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	
	}

	@Override
	public DoubleNumber round(int digits, RoundingMode roundingMode, boolean changeOriginal) {
		checkPreconditions(changeOriginal);
		
		DecimalFormat f = new DecimalFormat("##." + Helper.repString("0", digits));
	    double newNumber = Double.parseDouble(f.format(number));
		
		// If the DoubleNumber is mutable, and we want to change the DoubleNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DoubleNumber round(int digits, RoundingMode roundingMode) {
		return this.round(digits, roundingMode, false);
	}

	@Override
	public DoubleNumber roundToNearest(NumberObjectSingle value, RoundingMode roundingMode,
			boolean changeOriginal) {
		double currentValue = this.number;
		double increment = value.toDouble();

		double divided = currentValue / increment;
		double newNumber = divided *  increment;

		// If the DoubleNumber is mutable, and we want to change the DoubleNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DoubleNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);

	}

	@Override
	public DoubleNumber roundToNearest(NumberObjectSingle value, RoundingMode roundingMode) {
		return this.roundToNearest(value, roundingMode, false);
	}

	@Override
	public DoubleNumber mod(NumberObjectSingle other, boolean changeOriginal) {
		checkPreconditions(changeOriginal);

		double newNumber = number % other.toDouble();

		// If the DoubleNumber is mutable, and we want to change the DoubleNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DoubleNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DoubleNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DoubleNumber mod(NumberObjectSingle other) {
		return this.mod(other, false);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	toString 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	public String toString() {
		return this.toString(SCALE);
	}
	
	@Override
	public String toString(int significantDigits) {
		if (significantDigits == -1)
			return toString();
		if (this.getFlag() == VALUE_FLAG.NaN)
			return "NaN";
		if (this.getFlag() == VALUE_FLAG.NULL)
			return "NULL";
		if (this.getFlag() == VALUE_FLAG.NEGATIVE_INFINITY)
			return "-Infinity";
		if (this.getFlag() == VALUE_FLAG.POSITIVE_INFINITY)
			return "Infinity";

		DecimalFormat df;
		if (significantDigits>0) df = new DecimalFormat("0." + Helper.repString("0", significantDigits));
		else df = new DecimalFormat();
		String s = df.format(number);

		if (rangeSpecified) s = s + "'";
		if (immutable) s = s + "*";
		return s;
	}

	@Override
	public String toSignSpacedString(int significantDigits) {
		String s = this.toString(significantDigits);
		if (this.compareTo(0) != -1) s = " " + s;
		return s;
	}

	@Override
	public String toPlainString() {
		if (this.getFlag() == VALUE_FLAG.NaN)
			return "NaN";
		if (this.getFlag() == VALUE_FLAG.NULL)
			return "NULL";
		if (this.getFlag() == VALUE_FLAG.NEGATIVE_INFINITY)
			return "-Infinity";
		if (this.getFlag() == VALUE_FLAG.POSITIVE_INFINITY)
			return "Infinity";

		return this.number+ "";
	}

	@Override
	public String toStringWithoutTrailingZeros() {
		return this.toPlainString();
	}

	

}
