package tests;

import org.junit.Test;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import abstractNumberObjectsAndInterfaces.NumberObject;
import attributes.AttributeField;
import attributes.AttributeField.IncompatibleNumberObjectTypeException;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import helper.Helper;
import legacyAttributes.ArrayAttribute;
import legacyAttributes.Constant;

public class testAttributes {

	@Test
	public void testAttributeField() {
		try {
			System.out.println("\n\n"+Helper.repString("-", 50)+ "\tTesting: AttributeField \t" + Helper.repString("-", 50));
			
			// No restrictions
			AttributeField noRes = new AttributeField("NoRes", new DecimalNumber(1), FieldRestriction.NO_RESTRICTIONS , NumberObject.class);
			System.out.println("NoRes after constructor: " + noRes);
			noRes.setValue(new DecimalNumber(2));
			System.out.println("NoRes after setting value to 2: " + noRes);
			noRes.setValue(new DecimalNumberArray(3,4));
			System.out.println("NoRes after setting value to array [3,4]: " + noRes);
			
			//Class restrictions: single
			System.out.println("\n\n Single field restriction");
			AttributeField singleRes = new AttributeField("singleRes", new DecimalNumber(1), FieldRestriction.NO_RESTRICTIONS);
			singleRes.setValue(new DecimalNumber(2));
			System.out.println("singleRes after setting value to 2: " + singleRes);
			try {singleRes.setValue(new DecimalNumberArray(3,4)); } catch (IncompatibleNumberObjectTypeException e) { System.out.println("Expected and encountered IncompatibleNumberObjectTypeException");}
			System.out.println("Done. 1 exception expected.");
			
			// FieldRestriction: single positive double
			System.out.println("\n\n");
			AttributeField singlePD;
			try { singlePD = new AttributeField("singlePD", new DecimalNumber(1), FieldRestriction.NON_POSITIVE_DOUBLE);} catch (RestrictionViolationException e) {System.out.println("Expected and encountered RestrictionViolationException 1 ");}
			try { singlePD = new AttributeField("singlePD", new DecimalNumber(-1), FieldRestriction.POSITIVE_DOUBLE);} catch (RestrictionViolationException e) {System.out.println("Expected and encountered RestrictionViolationException 2 ");}
			singlePD = new AttributeField("singlePD", new DecimalNumber(1), FieldRestriction.POSITIVE_DOUBLE);
			System.out.println("singlePD after constructor: " + singlePD);
			try {singlePD.setValue(new DecimalNumber(-2));} catch (RestrictionViolationException e) {System.out.println("Expected and encountered RestrictionViolationException 3 "); }
			singlePD.setValue(new DecimalNumber(2));
			System.out.println("singlePD after setting value to 2: " + singleRes);
			System.out.println("Done. 3 Exceptions expected.");
			
			// FieldRestriction: single positive double
			System.out.println("\n\n Array field restriction");
			AttributeField arrayPD;
			try { arrayPD = new AttributeField("arrayPD", new DecimalNumberArray(1,2,4), FieldRestriction.NON_POSITIVE_DOUBLE);} catch (RestrictionViolationException e) {System.out.println("Expected and encountered RestrictionViolationException 1 ");}
			try { arrayPD = new AttributeField("arrayPD", new DecimalNumberArray(-1, 2, -4), FieldRestriction.POSITIVE_DOUBLE);} catch (RestrictionViolationException e) {System.out.println("Expected and encountered RestrictionViolationException 2 ");}
			arrayPD = new AttributeField("arrayPD", new DecimalNumberArray(1,2,4), FieldRestriction.POSITIVE_DOUBLE);
			System.out.println("arrayPD after constructor: " + arrayPD);
			try {arrayPD.setValue(new DecimalNumberArray(-8, - 16, -32));} catch (RestrictionViolationException e) {System.out.println("Expected and encountered RestrictionViolationException 3 "); }
			arrayPD.setValue(new DecimalNumberArray(8, 16, 32));
			System.out.println("arrayPD after setting value to 8, 16, 32: " + arrayPD);
			System.out.println("Done. 3 Exceptions expected.");
			
		} catch (Exception e) {e.printStackTrace();}
	}
	
	@Test
	public void testConstant() {
		try {
			System.out.println("\n\n"+Helper.repString("-", 50)+ "\tTesting: constant attribute \t" + Helper.repString("-", 50));
			Constant c = new Constant("A test constant", new DecimalNumber(-1));
			System.out.println("Created the following constant: " + c.getDescription());
			c.change("Value", new DecimalNumber(3));
			System.out.println("After changing the new value is: " + c.getDescription());
			System.out.println("Is this attribute a constant? " + c.isConstant());
			assert(c.isConstant());
			
			c.makeVariable();
			System.out.println("After invoking makeVariable, is this still a constant? " + c.isConstant());
			assert(c.isConstant());

			try {
				c.makeImmutable();
				c.change("Value", new DecimalNumber(1));
			} catch (UnsupportedOperationException uoe) {System.out.println("Expected and encountered an exception after making this object immutable and trying to change it. ");}
			c.iAmReallySureIWantToMakeThisAttributeMutableAgain();
			
			try {
				c.change("Value", new DecimalNumberArray(1,2,3));
			} catch (IncompatibleNumberObjectTypeException e) { System.out.println("Expected and encountered an exception after trying to change the constant value into an array");}
			try {
				c.change("Value", new DecimalNumberMatrix(2,2, true, 1,2,3,4));
			} catch (IncompatibleNumberObjectTypeException e) { System.out.println("Expected and encountered an exception after trying to change the constant value into a matrix");}

			System.out.println("The constant still has a value: " + c.getDescription());
		} catch (Exception e) {e.printStackTrace();}
	}
	
	@Test
	public void testArrayAttribute() {
		try {
			System.out.println("\n\n"+Helper.repString("-", 50)+ "\tTesting: array attribute \t" + Helper.repString("-", 50));
			DecimalNumberArray dna = new DecimalNumberArray(1,2,3,4,6);
			ArrayAttribute aa = new ArrayAttribute("A test ArrayAttribute", dna);
			System.out.println(aa);
			//try {aa.setValueAt(5, newValue);} catch (Exception e) {System.out.println(e);}
		} catch (Exception e) { e.printStackTrace();}
	}
}
