package attributes;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;

/**
 * An AttributeFieldSpecification is a specification what a AttributeField has to 'look like'.
 * This specification is used to specify at compile-time what the requirements for a NamedDecimalNumberObject are. 
 * This is useful because sometimes a name and type have be known before an object can be instantiated.
 * This requirements consist of:
 * (required) A name (String)
 * (required) A class (NumberObjectSingle, NumberObjectArray, or NumberObjectMatrix - note: the unnamed versions!)
 * (optional) A FieldRestriction (i.e., a positive integer, a negative double, no restrictions... etc...)
 * 
 * Note that the last requirement, the FieldRestriction, can be overwritten when instantiating this object. However,
 * this should be done with care - in some cases the restriction is there for a reason (for instance, to insure that
 * probabilities and probability distributions are not lower than 0, or higher than 1.
 * @author Jesse Fenneman
 *
 */
public class AttributeFieldSpecification {
	
	@SuppressWarnings("serial")
	public static class MisspecificationException extends RuntimeException { public MisspecificationException(String message) {     super(message);  }};
	
	public final String name;
	public final Class<? extends NumberObject> classs;
	public final FieldRestriction fieldRestriction;
	
	public AttributeFieldSpecification(String name, Class<? extends NumberObject> classs) {
		this.name=name;
		this.classs = classs;
		this.fieldRestriction = FieldRestriction.NO_RESTRICTIONS;
	}
	
	
	public AttributeFieldSpecification(String name, Class<? extends NumberObject> classs, FieldRestriction fieldType) {
		this.name=name;
		this.classs = classs;
		this.fieldRestriction = fieldType;
	}
	
	/** Checks if the NumberObject is of the correct class (i.e., whether the object matches the class specification of the FieldSpecification), 
	 * and wraps the object in a name;
	 * 
	 * If the class does match specification, a MisspecificationException is thrown.
	 * @param object
	 * @throws RestrictionViolationException 
	 */
	public AttributeField buildToSpecification(NumberObject object) throws RestrictionViolationException {
		if (object != null) {
			if (!classs.isAssignableFrom(object.getClass()) )
				throw new MisspecificationException("Trying to instantiate a field. However, the class of the specified object does not match the class in the FieldSpecification. Expected class: " + classs.getSimpleName() + ". Supplied class: " + object.getClass().getSimpleName());

			//Wrap the NumberObject with a name
			return new AttributeField(name, object, fieldRestriction);
			
		} 
		return null;
	}
	
	/** Checks if the NumberObject is of the correct class (i.e., whether the object matches the class specification of the FieldSpecification), 
	 * and wraps the object in a name;
	 * 
	 * Overrides the FieldRestriction. After construction, this object will not have the same restriction of values (e.g., only positive doubles)
	 * as the class requires. This should be used with care!. 
	 * @param object
	 * @throws RestrictionViolationException 
	 */
	public AttributeField buildToSpecification(NumberObject object, FieldRestriction newRestriction) throws RestrictionViolationException {
		if (object != null) {
			if (!classs.isAssignableFrom(object.getClass()) )
				throw new MisspecificationException("Trying to instantiate a field. However, the class of the specified object does not match the class in the FieldSpecification. Expected class: " + classs.getSimpleName() + ". Supplied class: " + object.getClass().getSimpleName());

			//Wrap the NumberObject with a name
			return new AttributeField(name, object, newRestriction);
			
		} 
		return null;
	}
	

}
