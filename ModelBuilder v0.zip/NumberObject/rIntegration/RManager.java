package rIntegration;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPGenericVector;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.RList;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import helper.Helper;
import helper.Helper.NoRInstalledException;
import interfaces_abstractions.ObserverManager;
import start.Console;

/** The RManager class handles all R related functionality.
 * It uses the RServe package to connect to R
 * @author Jesse Fenneman
 *
 */
public final class RManager {
	
	// If DEBUG_MODE is true, show all steps.
	private final static boolean DEBUG_MODE=false;
	private static final String HOST = "localhost";
	private static int START_PORT = 6310;
	private static String sourceFolderDirectoryPath;

	private static RConnection connection;
	private static RFunction[] rFunctions;
	
	
	/** Attempts to make a connection to R via RServe. If the connections cannot
	 * be made automatically via the command line, this function prompts the user
	 * to manually start the connection and restart the program. Returns true if there
	 * is a connection to R after this function is completed.
	 * 
	 * Note, this function can take some time. It is not advised to run it on 
	 * an IO or JAVAFX event thread.
	 * @throws REngineException 
	 * @throws NoRInstalledException 
	 * @throws REXPMismatchException 
	 * @throws IOException */
	public static boolean establishConnectionToR() 
	{
		// Check if the boot sequence has already been completed. If so, no need to do anything here
		if (connection != null) {
			ObserverManager.makeToast("Connection to R has already been established. To restart the connection, please close it using closeConnection()");
			return true;
		}
		ObserverManager.makeToast("Attempting to start R via command line...");

		// Get the required directories
		sourceFolderDirectoryPath 	= System.getProperty("user.dir")+"\\sourceFolder\\";

		try {
			// Figure out where R is hiding on this machine
			String rscriptLocation = findRLocation();

			// Start R from via a Runtime process
			startR(rscriptLocation);

			// Initialise R - source all .R files. Returns a list of .R files that have to parsed into RFunction objects
			ArrayList<File> dotRFilesToBeParsed = initR();

			// Parse all the RFunctions
			rFunctions= parseRFunctions(dotRFilesToBeParsed);

			ObserverManager.makeToast("Connection to RServe package in R established.");
			return true;
		} catch (Exception e) {
			ObserverManager.notifyObserversOfError(e);
			return false;
		}
	}
	/**
	 * Find and return the absolute path pointing to Rscript.exe. If multiple Rscript.exe's exist, the first one found is returned.
	 * 
	 * Due to multithreading, if more than one Rscript.exe exists on the computer, this function might return with different paths, 
	 * even if the underlying file system does not change. No guarantee can be made which Rscript.exe file is found first.
	 * @return
	 * @throws IOException
	 * @throws NoRInstalledException
	 */
	private static String findRLocation() throws NoRInstalledException 
	{
		if (DEBUG_MODE) 	Console.print(" Searching for Rscript.exe...");
		// Check if there is a file called "RLocation.txt" in the source folder - if so, read the location from that file
		File RLocationtxt = new File(sourceFolderDirectoryPath + "\\RLocation.txt");
		if (RLocationtxt.exists())		{
			try {
				// Read the file
				BufferedReader br = new BufferedReader(new FileReader(RLocationtxt));

				// Check if the text, which should be of the form /location/to/path/bin/Rscript.exe, actually exists
				String nextLine = br.readLine();
				while (nextLine != null) {
					if (DEBUG_MODE) Console.print("\t-R was previously found at: " + nextLine + ". Checking to see if it is still there..." );
					if (new File(nextLine).exists()) {
						if (DEBUG_MODE) Console.print("\t-Succes: found Rscript.exe at " + nextLine );
						br.close();
						return nextLine;
					}
					else {Console.print("\t-Failure: previously known location " + nextLine + " does not exist or is not accessible.");}
					nextLine = br.readLine();
				}
				br.close();
			} catch (IOException e) { ObserverManager.notifyObserversOfError(e);}

		}

		// If the file in RLocation.txt does not exist, or there is no RLocation file yet, find R.exe by searching through all
		// possible files and directories on the computer
		Console.print("\t-No Rscript.exe location known yet. Searching all drives for R.exe");

		File rexe = null;
		for (File root: File.listRoots()){
			Console.print("\t\t-Searching drive: " + root.getAbsolutePath()+ "...");
			try { rexe = Helper.findFile("Rscript.exe", root);} catch (InterruptedException e) {e.printStackTrace();	}
			if (rexe != null) break;
		}
		if (rexe == null)
			throw new NoRInstalledException("Could not find an instance of Rscript.exe on the computer. Please make sure that R is installed on this computer.");

		// From this point onward we know that we either found R.exe (if it does not exist, this code is never reached).
		// Before returning the rexe path, store this path to a file that can be read in on the next occasion. 
		try {
			RLocationtxt.createNewFile();
			BufferedWriter bw = new BufferedWriter(new FileWriter(RLocationtxt));
			bw.append("\n" +rexe.getAbsolutePath());
			bw.close();
		} catch (IOException e) {
			ObserverManager.notifyObserversOfError(e);
		}
		
		// Finally, return the file path.
		return rexe.getAbsolutePath();
	}
	
	/** A class that implements a listener on a separate thread. These listeners monitor the output of the process used to start R with */
	public static class RServeListener implements Runnable {

		public final InputStream is;
		public final boolean isErrorStream;
		
		public RServeListener(InputStream is, boolean isErrorStream) {
			this.is = is;
			this.isErrorStream=isErrorStream;
		}
		@Override
		public void run() {
			try
			{
				InputStreamReader isr = new InputStreamReader(is);
				BufferedReader br = new BufferedReader(isr);
				String line=null;
				while ( (line = br.readLine()) != null)
					if (isErrorStream)
						Console.print(" R process error: " + line); // this used to be an error print, but then R 4. used warnings as errors...
					else
						Console.print(" R process message: " + line);
			} catch (IOException e)			{
				e.printStackTrace();  
			}
		}

	}

	
	/** Attempts to start R from the command line. Returns false if no connection could be made. 
	 * @throws NoRInstalledException 
	 * @throws REngineException */
	private static boolean startR(String rscriptLocation) throws IOException, REXPMismatchException, NoRInstalledException, REngineException {
		if (DEBUG_MODE) 	Console.print( " Starting the connection to R...");
		// Make a connection to Rserve. Note that on windows only a single connection can be made on the same port.
		// Starting multiple instance on the same port will cause RConnection to hang. As a result, we sometimes have
		// to try multiple different ports. To prevent the whole thread from hanging up on us, the connection is made in a separate
		// thread
		Process proc = null;
		while (connection == null ) {
			START_PORT++;
			
			// Start Rserve externally with Runtime
			if (DEBUG_MODE) 	Console.print("\t-Attempting to make a connection to RServe on port: " + START_PORT + "...");
			
			proc = new ProcessBuilder(rscriptLocation,"-e","library(Rserve);Rserve(port = " + START_PORT+ ");").start();
	
			// Start a new Thread that will attempt to make a connection to RServe
			Callable<RConnection> call = new Callable<RConnection>() {
		        public RConnection call() throws Exception {
		            RConnection r2= new RConnection(HOST, START_PORT);
		            return r2;
		        }
		    };
		    ExecutorService es = Executors.newSingleThreadExecutor();
		    Future<RConnection> f = es.submit(call);
		    es.shutdown();
		    
		   // runtimeProcessUsedToStartRWith.destroyForcibly();
		    // Wait for a short while (starting RServe should really not take long at all), and try to get the result from the call thread
		    try {
				connection = f.get(2000, TimeUnit.MILLISECONDS);
				if (connection.isConnected())
					Console.print( "\t-Succes: connected to to RServe on port: " + START_PORT);
				else {
					connection.serverShutdown();
					Console.print( "\t-Failure: connected to to RServe on port: " + START_PORT + " because RConnection did not acknowledge connection");
				}
					
			} catch (InterruptedException | ExecutionException | TimeoutException e) {
				Console.print("\t-Failure: could not connect to RServe on port: " + START_PORT + ". Reason: " + e.toString());
			}
		}
		
		// If we are in DEBUG_MODE, add some listeners to figure out what the commandline is doing
		if (DEBUG_MODE) {
			RServeListener errorListener = new RServeListener(proc.getErrorStream(), true);
			RServeListener inputListener = new RServeListener(proc.getInputStream(), true);
			new Thread(errorListener).start();
			new Thread(inputListener).start();
		}
		// Do a simple test
		if (DEBUG_MODE) 	Console.print("\t-Testing the JAVA-R pipeline: 1 + 1 should be 2.");
		REXP testResult = connection.parseAndEval("x <- 1; x+x"); 
		if (testResult.asDouble() == 2.0) {
			if (DEBUG_MODE) 	Console.print( "\t-Succes. R connection is made.");
			return true;
		} else {
			if (DEBUG_MODE) 	Console.print( "\t-Test failed.");
			return false;
		}
	
		
	}

	/**
	 * Load all files in the Rscripts folder into R. Returns an array of Files that are in the sourceFolder//Rscripts//Functions folder. These
	 * .R files have to be parsed into RFunction objects later on.
	 * @throws RserveException
	 * @throws REXPMismatchException
	 */
	private static ArrayList<File> initR() throws RserveException, REXPMismatchException
	{
		// Find and load all .r files in sourceFolder and all subfolders
		ArrayList<File> allDotRFiles = new ArrayList<>();
		ArrayList<File> dotRFuctionsToBeParsed = new ArrayList<>();
		
		
		// Find all .R files
		if (DEBUG_MODE) 	Console.print(" Indexing all .R files in the sourceFolder...");
		try (Stream<Path> walk = Files.walk(Paths.get(sourceFolderDirectoryPath))) {

			List<String> result = walk.map(x -> x.toString())
					.filter(f -> f.endsWith(".R")).collect(Collectors.toList());
			
			for (String path: result) {
				if (DEBUG_MODE) 	Console.print( " \t-Found: " + path);
				allDotRFiles.add(new File(path));
			}
		} catch (IOException e) {
			ObserverManager.notifyObserversOfError(e);
		}
		
		// Find all .R files that have to be parsed to RFunction objects
		if (DEBUG_MODE) 	Console.print( " Indexing all .R files that have to be parsed into RFunction objects...");
		try (Stream<Path> walk = Files.walk(Paths.get(sourceFolderDirectoryPath+"\\Rscripts\\Functions\\"))) {

			List<String> result = walk.map(x -> x.toString())
					.filter(f -> f.endsWith(".R")).collect(Collectors.toList());
			
			for (String path: result) {
				if (DEBUG_MODE) 	Console.print( " \t-Found: " + path);
				dotRFuctionsToBeParsed.add(new File(path));
			}
		} catch (IOException e) {
			ObserverManager.notifyObserversOfError(e);
		}

		// Source all .R files in dotRFiles. 
		if (DEBUG_MODE) 	Console.print( " Sourcing all previously found .R files (" + allDotRFiles.size() + " .R files in total)");
		for (File r: allDotRFiles)
		{
			String filename = r.getAbsolutePath().replaceAll(".*\\\\", "") ;
			Console.print(" \t Sourcing file \"" + filename + "\" to Rserve");
			try {
				connection.eval(("source(\"" + r + "\")").replace("\\", "/"));
			} catch (RserveException e) {
				Console.print("\t Unable to source file " + r.getAbsolutePath() + ": " + e.getLocalizedMessage());
				throw e;
			}
			Console.print(" \t Succesfully sourced file \"" + filename + "\" to Rserve");
		}
		
		// Return the list of Files that contain all functions that have to be parsed
		return dotRFuctionsToBeParsed;
	}

	/** Close the connection to R. Unfortunately, I found no way to kill the actual RServe.exe process via JAVA. 
	 * I did, however, figure out how to kill ALL RServe.exe processes via R. I have no idea why this is even
	 * remotely a good idea for a R implementation. It becomes considerably worse when you realize I had to 
	 * do quite some regex work to make sure this functionality kills ONLY RServe.exe processes - and not, you 
	 * know, everything running on this machine. What a weird functionality for R to have. Ah well, it works.*/
	public static void closeConnection () throws SocketException {
		if (connection == null) {
			if (DEBUG_MODE) 	Console.print(" Attempting to close R. However, there is no active connection (yet)");
			return;
		}
			

		try {
			if (DEBUG_MODE) 	Console.print( " Closing connection to RServe...");
			try { connection.parseAndEval("killAllRserveProcesses()"); } catch (Exception e) {} // We expect an exception - after all, we are closing the connection by a command. R will not have time to relay a success back to java
	        connection = null;
	        if (DEBUG_MODE) 	Console.print("\t-Connection closed.");
        } catch (Exception e) {ObserverManager.notifyObserversOfError(e);}
		
	}
	
	/** Some function - specifically the one in the //sourceFolder//RScripts//Functions can be used by the user. 
	 * Before this can happen, we have to parse them - that is, we have to create specific RFunction objects
	 * for each .R file
	 */
	private static RFunction[] parseRFunctions(ArrayList<File> dotRFilesToBeParsed) {
		RFunction[] functions = new RFunction[dotRFilesToBeParsed.size()];
		for (int i = 0; i < functions.length; i++)
			try {
				functions[i] = new RFunction(dotRFilesToBeParsed.get(i).getAbsolutePath());
			} catch (IOException e) {
				ObserverManager.notifyObserversOfError("Error starting R", "Could not parse a .R function.", e);
			}
		return functions;
	}
	
	/** Returns the RFunction with the specified name. If no such name exists, returns null.*/
	public static RFunction getFunction(String functionName) {
		for (RFunction rf: rFunctions)
			if (rf.getName().equals(functionName))
				return rf;
		return null;
	}
	/**
	 * Evaluate a string in R, and return the result in a REXP object. This function prints the error messages generated in 
	 * R. Additionally:
	 * - multiple statements can be parsed at the same time - use ';' as a divider of statements. However, only the output of the
	 * 		last statement is returned.
	 * - This function uses R's try() functionality, which requires '<-' rather than '=' as the assignment operator. Therefore,
	 * all single occurrences of '=' in all command statements are replaced by '<-' (excluding '==' operators).
	 *  
	 *  
	 * @param command
	 * @return
	 * @throws REngineException 
	 * @throws REXPMismatchException 
	 */
	public static synchronized REXP evaluate(String command) throws REngineException, REXPMismatchException
	{
		// If there is a R error, we want to know this error. For this, we can use R's try(..., silent=TRUE).
		// This function returns a string value in case of an error, and a correct value otherwise
		// However, try cannot deal with ";" characters - we have to put each statement into its own try function first.
		String[] subCommands = command.split(";");
		
		for (int i = 0; i < subCommands.length; i ++)
		{
			subCommands[i] = subCommands[i].replaceAll("\t"," ");
			subCommands[i] = subCommands[i].replaceAll("\n"," ");
		}

		// Make sure that there are no empty commands
		for (int i = 0; i < subCommands.length; i ++)
		{
			int emptySpaces = 0;
			for(char c : subCommands[i].toCharArray()){
			   if(c == ' ' ){
				   emptySpaces++;
			   }}
			if (subCommands[i].length() == emptySpaces)
				subCommands[i] = "0";
		}
			

		// Likewise, R's try does not like '=' characters - replace them with '<-'
		for (int i = 0; i < subCommands.length; i++)
			if (subCommands[i].contains("="))
			{
				StringBuilder sb = new StringBuilder();
				for (int c = 0; c < subCommands[i].length(); c++)
					if (subCommands[i].charAt(c) == '=' && c != subCommands[i].length())
					{
						if (subCommands[i].charAt(c+1) == '=')
						{ sb.append("=="); c++; }		
						else 
						{ sb.append("<-"); }
					}
					else
						sb.append(subCommands[i].charAt(c));
				subCommands[i] = sb.toString();
			}


		for (int i = 0; i < subCommands.length; i ++)
			subCommands[i] = "try(" + subCommands[i] + ", silent=TRUE)";
		
		// Send it off to R, and check whether there are errors from R
		REXP result=null;
		for (String s: subCommands)	{
			try {
				if (DEBUG_MODE)Console.print( " Sending command to R: " + s);
				result = connection.parseAndEval(s);
				if (result.inherits("try-error")) ObserverManager.notifyObserversOfError("Error", result.asString());
			} catch (REngineException e) { 
				throw new REngineException(connection, "Could not parse statement: " + s + "\nThis error most likely originated from JAVA sending invalid requests to R.\n Message: " + connection.getLastError());
			} catch (REXPMismatchException e) {
				throw new REXPMismatchException (result, "Mismatch between R's object and Java's interpretation of this object. Somewhere a cast has gone wrong.\n"); }
			
		}
	
		if (DEBUG_MODE) Console.print( " Succesfully received response from R: " + result.toDebugString());
		return result;
	}

	/** Returns an arraylist containing all function. This array list is a copy, but it is a shallow copy. */
	public static ArrayList<RFunction> getAllRFunctions(){
		ArrayList<RFunction> copyArrayList = new ArrayList<>();
		for (RFunction rf: rFunctions)
			copyArrayList.add(rf);
		return copyArrayList;
	}
	
	/** Returns an arraylist containing all function that are tagged with this tag.
	 *  This array list is a copy, but it is a shallow copy. */
	public static ArrayList<RFunction> getAllRFunctionsWithTag(String tag){
		ArrayList<RFunction> copyArrayList = new ArrayList<>();
		for (RFunction rf: rFunctions)
			for (String s: rf.getTagsCopy())
				if (s.equalsIgnoreCase(tag))
					copyArrayList.add(rf);
		return copyArrayList;
	}
	
	/** Interprets a given RList as list of double vectors, uses this to create a DecimalNumberMatrix, and returns the result. 
	 * @throws REXPMismatchException */
	public static DecimalNumberMatrix RListToDecimalNumberMatrix(RList list) throws REXPMismatchException {
		// Figure out the dimensions
		int ncol = list.capacity();
		int nrow = 0;
		for (int column = 0; column < list.capacity(); column++)
			if (list.at(column).asDoubles().length > nrow) nrow = list.at(column).asDoubles().length;

		// Create double[nrow][ncol] matrix to place the values in
		double[][] matrix = new double[nrow][ncol];
		for (int column = 0; column < list.capacity(); column++) {
			double[] columnValues = list.at(column).asDoubles();
			for (int row = 0; row< columnValues.length; row++)
				matrix[row][column] = columnValues[row];
		}

		// Extract the column names
		String[] colNames = new String[ncol];
		for (int i = 0; i < ncol; i++)
			colNames[i] = (String) list.names.get(i);

		DecimalNumberMatrix dnm = new DecimalNumberMatrix(matrix);
		dnm.setColumnNames(colNames);
		return (dnm);
	}

	/** Interprets a given REXP as a list of double vectors, uses this to create a DecimalNumberMatrix, and returns the result. 
	 * @throws REXPMismatchException */
	public static DecimalNumberMatrix REXPtoDecimalNumberMatrix(REXP rexp) throws REXPMismatchException {
		return (RListToDecimalNumberMatrix(rexp.asList()));
		
	}
	
	/** Interprets a given REXPGenericVector as a list of double vectors, uses this to create a DecimalNumberMatrix, and returns the result. 
	 * @throws REXPMismatchException */
	public static DecimalNumberMatrix GenericVectorToDecimalNumberMatrix(REXPGenericVector rgv) throws REXPMismatchException {
		return (RListToDecimalNumberMatrix(rgv.asList()));
	}
	
	/**
	 * Evaluate a string in R, returns the resulting REXP object. This function prints the error messages generated in 
	 * R. Additionally:
	 * - multiple statements can be parsed at the same time - use ';' as a divider of statements. However, only the output of the
	 * 		last statement is returned.
	 * - This function uses R's try() functionality, which requires '<-' rather than '=' as the assignment operator. Therefore,
	 * all single occurrences of '=' in all command statements are replaced by '<-' (excluding '==' operators).
	 *  
	 *  This function automatically parses the output from R to a double. Returns null if the result could not be parsed as a double.
	 *  
	 * @param command
	 * @return
	 * @throws REngineException 
	 * @throws REXPMismatchException 
	 */
	public static synchronized Double evaluateAndReturnDouble(String command) throws REngineException, REXPMismatchException {
		REXP result = evaluate(command);
		if (result.isNumeric())
			return result.asDouble();
		else
			throw new REXPMismatchException(result, "Trying to parse result from R into a double. However, the result is not a double");
		
	}
	
	/**
	 * Evaluate a string in R, returns the resulting REXP object. This function prints the error messages generated in 
	 * R. Additionally:
	 * - multiple statements can be parsed at the same time - use ';' as a divider of statements. However, only the output of the
	 * 		last statement is returned.
	 * - This function uses R's try() functionality, which requires '<-' rather than '=' as the assignment operator. Therefore,
	 * all single occurrences of '=' in all command statements are replaced by '<-' (excluding '==' operators).
	 *  
	 *  This function automatically parses the output from R to an integer. 
	 * @param command
	 * @return
	 * @throws REngineException 
	 * @throws REXPMismatchException 
	 */
	public static synchronized Integer evaluateAndReturnInteger(String command) throws REngineException, REXPMismatchException {
		REXP result = evaluate(command);
		if (result.isInteger())
			return result.asInteger();
		else
			throw new REXPMismatchException(result, "Trying to parse result from R into an integer. However, the result is a not an integer.");
		
	}
	
	/**
	 * Evaluate a string in R, returns the resulting REXP object. This function prints the error messages generated in 
	 * R. Additionally:
	 * - multiple statements can be parsed at the same time - use ';' as a divider of statements. However, only the output of the
	 * 		last statement is returned.
	 * - This function uses R's try() functionality, which requires '<-' rather than '=' as the assignment operator. Therefore,
	 * all single occurrences of '=' in all command statements are replaced by '<-' (excluding '==' operators).
	 *  
	 *  This function automatically parses the output from R to a String. 
	 * @param command
	 * @return
	 * @throws REngineException 
	 * @throws REXPMismatchException 
	 */
	public static synchronized String evaluateAndReturnString(String command) throws REngineException, REXPMismatchException {
		REXP result = evaluate(command);
		if (result.isString())
			return result.asString();
		else
			throw new REXPMismatchException(result, "Trying to parse result from R into a String. However, the result is a String.");
		
	}
	
	/**
	 * Evaluate a string in R, returns the resulting REXP object. This function prints the error messages generated in 
	 * R. Additionally:
	 * - multiple statements can be parsed at the same time - use ';' as a divider of statements. However, only the output of the
	 * 		last statement is returned.
	 * - This function uses R's try() functionality, which requires '<-' rather than '=' as the assignment operator. Therefore,
	 * all single occurrences of '=' in all command statements are replaced by '<-' (excluding '==' operators).
	 *  
	 *  This function automatically parses the output from R to a RList. 
	 * @param command
	 * @return
	 * @throws REngineException 
	 * @throws REXPMismatchException 
	 */
	public static synchronized RList evaluateAndReturnRList(String command) throws REngineException, REXPMismatchException {
		REXP result = evaluate(command);
		if (result.isList()) 
			return result.asList();
		else
			throw new REXPMismatchException(result, "Trying to parse result from R into an RList. However, the result is a not an RList");
		
	}
	
	/**
	 * Evaluate a string in R, returns the resulting REXP object. This function prints the error messages generated in 
	 * R. Additionally:
	 * - multiple statements can be parsed at the same time - use ';' as a divider of statements. However, only the output of the
	 * 		last statement is returned.
	 * - This function uses R's try() functionality, which requires '<-' rather than '=' as the assignment operator. Therefore,
	 * all single occurrences of '=' in all command statements are replaced by '<-' (excluding '==' operators).
	 *  
	 *  This function automatically parses the output from R to a DecimalNumberArray. 
	 * @param command
	 * @return
	 * @throws REngineException 
	 * @throws REXPMismatchException 
	 */
	public static synchronized DecimalNumberArray evaluateAndReturnDecimalNumberArray(String command) throws REngineException, REXPMismatchException {
		REXP result = evaluate(command);
		if (result.isNumeric()) {
			// REXP uses a [row][col] format for matrices
			double[][] matrix = result.asDoubleMatrix();
			
			// If matrix.length>1: this is a column vector
			if (matrix.length>1) {
				double[] array = new double[matrix.length];
				
				// Check if all rows have size one
				for (int i = 0; i < matrix.length; i++)
					if (matrix[i].length != 1)
						throw new REXPMismatchException(result, "Trying to parse result from R into a DecimalNumberArray. However, the result is a NxM matrix where both N and M are larger that 1.");
					else
						array[i] = matrix[i][0];
				
				// Parse into a new DecimalNumberArray and return
				return new DecimalNumberArray(array);
				
			}
			
			else if (matrix.length == 1){ // Otherwise it has to be a row vector
				return new DecimalNumberArray(matrix[0]);
			} else {
				throw new REXPMismatchException(result, "Trying to parse result from R into a DecimalNumberArray. However, the result is a NxM matrix where both N and M are larger that 1.");
				
			}
		} else {
			throw new REXPMismatchException(result, "Trying to parse result from R into a DecimalNumberArray. However, the result is not numeric.");
			
		}
	}
	
}
