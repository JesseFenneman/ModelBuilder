package decimalNumber;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle.VALUE_FLAG;
import doubleNumber.DoubleNumber;
import helper.Helper;

//TODO: check @param
/**
 * DecimalNumber is a class that wraps a single BigDecimal object, and contains some constants.
 * The DecimalNumbers can have a maximum and minimum value attached to them. If a range is specified,
 * the static boolean 'checkValidity' is set to true, and the value of the DecimalNumber
 * is not between the minimum and maximum, an 'IllegalRangeException is thrown'.
 *
 * DecimalNumbers are used as a wrapper to combat floating point issues, that kept persisting even after I used
 * BigDecimal objects for computation. Using this wrapper ensures that all BigDecimal values
 * used in the model have the same (limited) scale and rounding mode. In addition, the use
 * of the BigDecimal double constructor (new BigDecimal(double) ) and the BigDecimal double
 * factory (BigDecimal.valueOf(double)) are NO LONGER ALLOWED.
 *
 * In addition, this class defines the precision (the number of digits in scientific
 * notation) and the scale (the number of decimal values) separately.
 *
 * By default, DecimalNumbers are mutable - it is allowed to change values. If, however,
 * the constructor is called with immutable = false or setImmutable(true) is called,
 * the BigDecimal value contained within the DecimalNumber is not allowed to change - attempting
 * to force a change using set() will result in an "OperationNotSupportedException".
 *
 * This class specifies the most common operations (addition, division, multiplication, subtraction,
 * exponentiation and negation). Each of these operations returns a DecimalNumber with the
 * new value, making it possible to chain operations. Each operation can be called with
 * operation(Number argument) or with operation(Number argument, boolean changeOriginal). A call
 * to the first function, operation(Number argument), results in a call to the second, with
 * changeOriginal set to true. That is, the function operation(Number argument) does nothing
 * else then call operation(Number argument, true).
 *
 * What exact object is returned after each operation depends on whether the DecimalNumber
 * upon which an operation is called is mutable or immutable, and whether changeOrginal is
 * true or false. Three options are possible.
 *
 *  1) DecimalNumber is mutable, changeOrginal is true.
 *  	In this case an operation changes the value of the DecimalNumber upon which the operation
 *  	is called, and the object returned is the same DecimalNumber.
 *  2) DecimalNumber is mutable, changeOrignal is false.
 *  	In this case the operation results in a new DecimalNumber, which is a copy (in terms of
 *  	range restrictions and mutability) of DecimalNumber upon which the operation is called,
 *  	of course with a different value.
 *  3) DecimalNumber is immutable (regardless of changeOriginal).
 *  	In this case the operation will NOT change the DecimalNumber itself. Instead,
 *  	it returns a new MUTABLE DecimalNumber with the same range restrictions as the original.
 *
 *  As an example, here are the three different cases for addition:
 *
 *  Case 1: mutable and changeOrginal is true:
 *  a = new DecimalNumber(3);
 * 	b = a.multiply(3); 					// implicitly calls a.multiply(3, true)
 * 	System.out.println(a); 				// Will result in "9"
 *  System.out.println(b); 				// Will result in "9"
 *  System.out.println(a == b); 		// Will result in "true"
 *
 *  Case 2: mutable and changeOrginal is false:
 *  a = new DecimalNumber(3);
 * 	b = a.multiply(3, false);
 * 	System.out.println(a); 				// Will result in "3"
 *  System.out.println(b); 				// Will result in "9"
 *  System.out.println(a == b); 		// Will result in "false"
 *
 *  Case 3: immutable
 *  a = new DecimalNumber(3, true);
 * 	b = a.multiply(3); 					// implicitly calls a.multiply(3, true)
 * 	System.out.println(a); 				// Will result in "3"
 *  System.out.println(b); 				// Will result in "9"
 *  System.out.println(a == b); 		// Will result in "false"
 *  System.out.println(b.isImmutable())	// Will result in "false"
 *
 * Some notes on implementation:
 * 1) DecimalNumbers should be considered as OBJECTS containing a value, not as values per se.
 * Hence, typically the constructor of an object using DecimalNumbers should clone parameters,
 * or calls to the constructor of an object should only use cloned instances (or
 * risk having a field that is shared with other objects).
 *
 * 2) To safeguard that values are not changed inadvertently by other objects, a DecimalNumber, a DecimalNumberArray
 * or a DecimalNumberMatrix can be declared immutable by the owning object. The same object can
 * be given a setDecimalNumber() function, which changes the mutability of the DecimalNumber to
 * mutable, changes the value, and resets the mutability to immutable. Although this does not
 * provide complete protection (other objects might change the mutability as well), it at least
 * ensures that changes do not happen by accident.
 *
 */
public class DecimalNumber implements Comparable<DecimalNumber>, Serializable, NumberObjectSingle
{
	private static final long serialVersionUID = Helper.programmeVersion;

	public static final RoundingMode 	ROUNDING_MODE 	= RoundingMode.HALF_EVEN;
	public static final int				PRECISION 		= 64;		// The total number of digits (using scientific notation) of the DecimalNumber
	public static final int				SCALE			= 64;		// The total number of digits after the decimal point.
	public static final MathContext MC = new MathContext(PRECISION, ROUNDING_MODE);

	public static final boolean 		CHECK_VALIDITY 		= true;
	public static final boolean			useApproximateValuesWhenCheckingValidity = true;
	public static final DecimalNumber 	boundsOfApproximation = new DecimalNumber("0." + Helper.repString("0", 10) + "1"); // 15 seems to be a good number - The results from R are usually accurate until 16 digits

	public static boolean isDouble (String s)	{
		if (s.length() == 0) return false;
		String doubleRegex = "(-?\\d*)|(-?\\d*\\.\\d+)";
		return (s.matches(doubleRegex));
	}

	public static BigDecimal parseStringToBigDecimal(String doubleString){
		if (!isDouble(doubleString))
			throw new IllegalArgumentException("Trying to parse the string \"" + doubleString + "\" to a double.");
		return new BigDecimal(doubleString, MC).setScale(SCALE, ROUNDING_MODE);
	}

	public static BigDecimal parseNumberToBigDecimal(Number value){
		return new BigDecimal("" + value.doubleValue(), MC).setScale(SCALE, ROUNDING_MODE);
	}

	/////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	FIELDS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////

	private 		BigDecimal 		number;
	private  		BigDecimal		minimum;
	private		 	BigDecimal		maximum;
	private  		boolean			immutable;
	private  		boolean			rangeSpecified;
	private final 	VALUE_FLAG 		flag;

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	CONSTRUCTORS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** The main constructor. Most, if not all, other constructors refer back to this one. It is private because in theory you can make a ranged DecimalNumber that never checks its range. */
	public DecimalNumber(BigDecimal value, BigDecimal minimum, BigDecimal maximum, boolean rangeSpecified, boolean immutable) {
		this.number = value.setScale(SCALE, ROUNDING_MODE);
		//this.number= value;
		this.minimum = minimum;
		this.maximum = maximum;
		this.rangeSpecified = rangeSpecified;
		this.immutable = immutable;
		this.flag = VALUE_FLAG.NORMAL;
		checkPostconditions();
	}

	/** Creates a new mutable DecimalNumber without a specified range
	 *
	 * @param value
	 * @return
	 */
	public DecimalNumber (Number value)  {
		this( parseNumberToBigDecimal(value), BigDecimal.ZERO, BigDecimal.ZERO, false, false);
	}

	/** Creates a new mutable DecimalNumber without a specified range
	 *
	 * @param value
	 * @return
	 */
	public DecimalNumber(String value)  {
		this( parseStringToBigDecimal(value), BigDecimal.ZERO, BigDecimal.ZERO, false, false);
	}

	/** Creates a new mutable DecimalNumber without a specified range
	 *
	 * @param value
	 * @return
	 */
	public  DecimalNumber (BigDecimal value)  {
		this( value, BigDecimal.ZERO, BigDecimal.ZERO, false, false);
	}

	/** Copy constructor. Returns a shallow clone (the objects in this number point to the original objects).
	 * For a deep clone, use the clone() function */
	public DecimalNumber (NumberObjectSingle value)  {
		number  =value.toBigDecimal();
		minimum = value.getMinimum().toBigDecimal();
		maximum = value.getMaximum().toBigDecimal();
		immutable = false;
		rangeSpecified = false;
		this.flag = value.getFlag();
		checkPostconditions();
	}

	/** Creates a new DecimalNumber without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public DecimalNumber (Number value, boolean immutable)  {
		this( parseNumberToBigDecimal(value), BigDecimal.ZERO, BigDecimal.ZERO, false, immutable);
	}

	/** Creates a new DecimalNumber without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public  DecimalNumber (String value, boolean immutable)  {
		this( parseStringToBigDecimal(value), BigDecimal.ZERO, BigDecimal.ZERO, false, immutable);
	}

	/** Creates a new DecimalNumber without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public DecimalNumber (BigDecimal value, boolean immutable)  {
		this( value, BigDecimal.ZERO, BigDecimal.ZERO, false, immutable);
	}

	/** Creates a new DecimalNumber without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public DecimalNumber (NumberObjectSingle value, boolean immutable)  {
		this.number = value.toBigDecimal();
		this.minimum = BigDecimal.ZERO;
		this.maximum = BigDecimal.ZERO;
		this.immutable = immutable;
		this.rangeSpecified = false;
		this.flag = value.getFlag();
		checkPostconditions();
	}

	/** Creates a DecimalNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DecimalNumber(Number value, Number minimum, Number maximum, boolean immutable) {
		this( parseNumberToBigDecimal(value), parseNumberToBigDecimal(minimum),parseNumberToBigDecimal(maximum), true, immutable);
	}

	/** Creates a DecimalNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DecimalNumber(Number value, NumberObjectSingle minimum, NumberObjectSingle maximum, boolean immutable) {
		this( parseNumberToBigDecimal(value), minimum.toBigDecimal(), maximum.toBigDecimal(), true, immutable);
	}

	/** Creates a DecimalNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DecimalNumber (String value, String minimum, String maximum, boolean immutable) {
		this( parseStringToBigDecimal(value), parseStringToBigDecimal(minimum), parseStringToBigDecimal(maximum), true, immutable);
	}

	/** Creates a DecimalNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DecimalNumber (BigDecimal value, BigDecimal minimum, BigDecimal maximum, boolean immutable) {
		this(value,minimum, maximum, true, immutable);
	}

	/** Creates a DecimalNumber with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public DecimalNumber (NumberObjectSingle value, NumberObjectSingle minimum, NumberObjectSingle maximum, boolean immutable) {
		this(value.toBigDecimal(),minimum.toBigDecimal(), maximum.toBigDecimal(), true, immutable);
	}

	
	/** Compute n! in a very non-optimized manner */
	public static DecimalNumber factorial(int n) {
		
		if(n < 0){  throw new IllegalArgumentException("Using negative value in factorial.");  }

		DecimalNumber factorial = new DecimalNumber(1);

	    for (int i = 1; i <= n; i++) {
	        factorial = factorial.multiply(i,true);
	    }
	    return factorial;
	    
		
	}
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Constants 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** Constructor used to create the NULL, NaN, POSITIVE_INFINITY, and NEGATVE_INFINITY objects. Will throw an IllegalStateException if the flag is NORMAL*/
	private DecimalNumber(VALUE_FLAG flag ) {
		if (flag == VALUE_FLAG.NORMAL)
			throw new IllegalStateException("Trying to use the constructor reserved for the special flag objects to create a normal DecimalNumber");
		this.number= null;
		this.minimum = null;
		this.maximum = null;
		this.rangeSpecified = false;
		this.immutable = true;
		this.flag = flag;
	}

	/**
	 * Creates an immutable DecimalNumber with value 0 and without a specified range.
	 * @return
	 */
	private static DecimalNumber ZERO() {
		try {
			return new DecimalNumber(BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, false, true);
		} catch (IllegalRangeException e) {
			e.printStackTrace();
			return null;
		}
	}
	public static final DecimalNumber ZERO = ZERO();

	/**
	 * Creates a immutable DecimalNumber with value 1 and without a specified range.
	 * @return
	 */
	private static DecimalNumber ONE() {
		try {
			return new DecimalNumber(BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ONE, false, true);
		} catch (IllegalRangeException e) {
			e.printStackTrace();
			return null;
		}
	}
	public static final DecimalNumber ONE = ONE();

	 /** Creates a immutable DecimalNumber with a NULL flag. This object cannot be changed, and cannot be used in any further computation.
	 * @return
	 */
	private static DecimalNumber NULL() {return new DecimalNumber(VALUE_FLAG.NULL);	}
	public static final DecimalNumber NULL = NULL();

	 /** Creates a immutable DecimalNumber with a NULL flag. This object cannot be changed, and cannot be used in any further computation.
	 * @return
	 */
	private static DecimalNumber NaN() {return new DecimalNumber(VALUE_FLAG.NaN);	}
	public static final DecimalNumber NaN = NaN();

	 /** Creates a immutable DecimalNumber with a NULL flag. This object cannot be changed, and cannot be used in any further computation.
	 * @return
	 */
	private static DecimalNumber POSITIVE_INFINITY() {return new DecimalNumber(VALUE_FLAG.POSITIVE_INFINITY);	}
	public static final DecimalNumber POSITIVE_INFINITY = POSITIVE_INFINITY();

	 /** Creates a immutable DecimalNumber with a NULL flag. This object cannot be changed, and cannot be used in any further computation.
	 * @return
	 */
	private static DecimalNumber NEGATIVE_INFINITY() {return new DecimalNumber(VALUE_FLAG.NEGATIVE_INFINITY);	}
	public static final DecimalNumber NEGATIVE_INFINITY = NEGATIVE_INFINITY();

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Validity checks 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void checkPreconditions(boolean changingObject) {
		if (this.flag== VALUE_FLAG.NULL)
			throw new NumberObjectNULLException("Trying to perform a mathematical operation on a NULL DecimalNumber.");
		if (this.flag== VALUE_FLAG.NaN)
			throw new NumberObjectNaNException("Trying to perform a mathematical operation on a NaN DecimalNumber.");
		if (this.flag== VALUE_FLAG.POSITIVE_INFINITY)
			throw new NumberObjectPositiveInfinityException("Trying to perform a mathematical operation on a positive infinity DecimalNumber.");
		if (this.flag== VALUE_FLAG.NEGATIVE_INFINITY)
			throw new NumberObjectNegativeInfinityException("Trying to perform a mathematical operation on a negative infinity DecimalNumber.");

		if (immutable && changingObject)
			throw new UnsupportedOperationException("Exception in DecimalNumber: trying to set an immutable DecimalNumber.");
	}
	@Override
	public void checkPostconditions() {
		if (!CHECK_VALIDITY ) return;

		// check the scale
		if (flag == VALUE_FLAG.NORMAL) {
			if (number.scale() > SCALE)
				throw new IllegalScaleException("Check failed: the scale of a Decimal exceeded the scale specified. The scale was " + number.scale() + ", while the maximum was " + SCALE);

			// check to see if the new value is still in range
			if (rangeSpecified && (number.compareTo(minimum)==-1 || number.compareTo(maximum)==1)) {
				if (!useApproximateValuesWhenCheckingValidity)
					throw new IllegalRangeException("Check failed: ended up with a DecimalNumber with a value of " + number.toPlainString() + ", although the minimum and maximum are " + minimum.toPlainString() + " and " + maximum.toPlainString() + ", respectively.");
				else if (!this.equals(minimum, true) && !this.equals(maximum, true) )
					throw new IllegalRangeException("Check failed: ended up with a DecimalNumber with a value of " + number.toPlainString() + ", although the minimum and maximum are " + minimum.toPlainString() + " and " + maximum.toPlainString() + ", respectively.");
			}
		}

	}
	@Override
	public void makeImmutable() {
		this.immutable = true;
	}
	@Override
	public boolean matchesFieldRestriction(FieldRestriction ft) {
		return (FieldRestriction.isValid(this.toPlainString(), ft));
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Type checks 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	@Override
	public boolean isNull() { return this.flag == VALUE_FLAG.NULL;}

	@Override
	public boolean isNaN() { return this.flag == VALUE_FLAG.NaN;}

	@Override
	public boolean isPositiveInfinity() { return this.flag == VALUE_FLAG.POSITIVE_INFINITY;}

	@Override
	public boolean isNegativeInfinity() {return this.flag == VALUE_FLAG.NEGATIVE_INFINITY;}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Setters 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void mimic(NumberObjectSingle n) {
		checkPreconditions(true);

		if (n.getFlag()== VALUE_FLAG.NULL)
			throw new NumberObjectNULLException("Trying to mimic a NULL DecimalNumber.");
		if (n.getFlag()== VALUE_FLAG.NaN)
			throw new NumberObjectNaNException("Trying to mimic a NaN DecimalNumber.");
		if (n.getFlag()== VALUE_FLAG.POSITIVE_INFINITY)
			throw new NumberObjectPositiveInfinityException("Trying to mimic a positive infinity DecimalNumber.");
		if (n.getFlag()== VALUE_FLAG.NEGATIVE_INFINITY)
			throw new NumberObjectNegativeInfinityException("Trying to mimic a negative infinity DecimalNumber.");


		this.number=n.toBigDecimal();
		this.minimum=n.getMinimum().toBigDecimal();
		this.maximum=n.getMaximum().toBigDecimal();
		this.rangeSpecified=n.hasRangeRestriction();
		this.immutable=n.isImmutable();
		checkPostconditions();
	}

	@Override
	public DecimalNumber set(Number argument) {
		checkPreconditions(true);
		number  = parseNumberToBigDecimal(argument);
		checkPostconditions();
		return this;
	}

	@Override
	public DecimalNumber set(String argument) {
		checkPreconditions(true);
		number  = parseStringToBigDecimal(argument);
		checkPostconditions();
		return this;
	}

	@Override
	public DecimalNumber set(NumberObjectSingle argument)  {
		if (immutable)
			throw new UnsupportedOperationException("Exception in DecimalNumber.set(): trying to set an immutable DecimalNumber.");
		number  =argument.toBigDecimal();
		checkPostconditions();
		return this;

	}

	@Override
	public DecimalNumber setImmutable(boolean immutability) {
		this.immutable = immutability;
		return this;
	}

	@Override
	public DecimalNumber removeRangeRestrictions() {
		checkPreconditions(true);
		rangeSpecified = false;
		checkPostconditions();
		return this;
	}

	@Override
	public DecimalNumber setRange(Number minimum, Number maximum) {
		checkPreconditions(true);
		rangeSpecified = true;
		setRangeMinimumWithoutValidation(minimum);
		setRangeMaximumWithoutValidation(maximum);
		checkPostconditions();
		return this;
	}

	@Override
	public DecimalNumber setRange(NumberObjectSingle minimum, NumberObjectSingle maximum) {
		checkPreconditions(true);
		rangeSpecified = true;
		setRangeMinimumWithoutValidation(maximum);
		setRangeMaximumWithoutValidation(minimum);
		checkPostconditions();
		return this;
	}

	@Override
	public DecimalNumber setRangeMinimum	(Number minimum){
		checkPreconditions(true);
		this.minimum = parseNumberToBigDecimal(minimum);
		checkPostconditions();
		return this;
	}

	@Override
	public DecimalNumber setRangeMinimum	(NumberObjectSingle minimum){
		checkPreconditions(true);
		this.minimum = minimum.toBigDecimal();
		checkPostconditions();
		return this;
	}

	@Override
	public DecimalNumber setRangeMinimumWithoutValidation	(NumberObjectSingle minimum){
		checkPreconditions(true);
		this.minimum = minimum.toBigDecimal();
		return this;
	}

	@Override
	public DecimalNumber setRangeMinimumWithoutValidation	(Number minimum){
		checkPreconditions(true);
		this.minimum = parseNumberToBigDecimal(minimum);
		return this;
	}

	@Override
	public DecimalNumber setRangeMaximum (Number maximum){
		checkPreconditions(true);
		this.maximum = parseNumberToBigDecimal(maximum);
		checkPostconditions();
		return this;
	}

	@Override
	public DecimalNumber setRangeMaximum (NumberObjectSingle maximum){
		checkPreconditions(true);
		this.maximum = maximum.toBigDecimal();
		checkPostconditions();
		return this;
	}

	@Override
	public DecimalNumber setRangeMaximumWithoutValidation	(NumberObjectSingle maximum){
		checkPreconditions(true);
		this.maximum = maximum.toBigDecimal();
		return this;
	}

	@Override
	public DecimalNumber setRangeMaximumWithoutValidation	(Number maximum){
		checkPreconditions(true);
		this.maximum = parseNumberToBigDecimal(maximum);
		return this;
	}



	@Override
	public DecimalNumber useRange(boolean hasRangeSpecified) {
		this.rangeSpecified = hasRangeSpecified;
		return this;
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Getters 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public VALUE_FLAG getFlag() {return this.flag;}
	@Override
	public boolean isImmutable() { return this.immutable; }
	@Override
	public boolean hasRangeRestriction() { return this.rangeSpecified; }
	@Override
	public int getSignificantDigits() {
		DecimalNumber clone = this.clone();

		String s = clone.number.stripTrailingZeros().toPlainString();
		int i = s.indexOf(".");

		if (i < 0) i = 0;
		else i = s.length() - i - 1;

		return i;
	}
	@Override
	public DecimalNumber clone() {
		if (flag == VALUE_FLAG.NaN)
			return DecimalNumber.NaN;
		if (flag == VALUE_FLAG.NULL)
			return DecimalNumber.NULL;
		if (flag == VALUE_FLAG.NEGATIVE_INFINITY)
			return DecimalNumber.NEGATIVE_INFINITY;
		if (flag == VALUE_FLAG.POSITIVE_INFINITY)
			return  DecimalNumber.POSITIVE_INFINITY;

		try {return new DecimalNumber(number, minimum, maximum, rangeSpecified, false);		} catch (IllegalRangeException e) {	e.printStackTrace();	}
		return null;
	}

	@Override
	public DecimalNumber getMinimum() {
		if (this.rangeSpecified)
			return new DecimalNumber(this.minimum);
		else
			return DecimalNumber.NEGATIVE_INFINITY;
	}
	@Override
	public DecimalNumber getMaximum() {
		if (this.rangeSpecified)
			return new DecimalNumber(this.maximum);
		else
			return DecimalNumber.POSITIVE_INFINITY;
	}
	
	@Override
	public boolean hasNonNormalFlag() {
		if (this.flag == null)
			return false;
		if (this.flag == VALUE_FLAG.NORMAL)
			return false;
		return true;
	}
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Comparisons 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	@Override
	public boolean largerThan(NumberObjectSingle o) { 	
		if (o.getFlag() == VALUE_FLAG.POSITIVE_INFINITY) 
			return false; 
		return (this.compareTo(o) > 0); 	
		}
	@Override
	public boolean largerThan(Number o)        { 	return (this.compareTo(o) > 0); 	}

	@Override
	public boolean largerThanOrEqualTo(NumberObjectSingle o) { 	if (o.getFlag() == VALUE_FLAG.POSITIVE_INFINITY) return false; return (this.compareTo(o) >= 0); 	}
	@Override
	public boolean largerThanOrEqualTo(Number o)        { 	return (this.compareTo(o) >= 0); 	}
	@Override
	public boolean smallerThan(NumberObjectSingle o) { 	if (o.getFlag() == VALUE_FLAG.NEGATIVE_INFINITY) return false; return (this.compareTo(o) < 0); 	}
	@Override
	public boolean smallerThan(Number o)        { 	return (this.compareTo(o) < 0); 	}
	@Override
	public boolean smallerThanOrEqualTo(NumberObjectSingle o) { 	if (o.getFlag() == VALUE_FLAG.NEGATIVE_INFINITY) return false; return (this.compareTo(o) <= 0); 	}
	@Override
	public boolean smallerThanOrEqualTo(Number o)        { 	return (this.compareTo(o) <= 0); 	}


	@Override
	public boolean largerThan(NumberObjectSingle o, boolean approximately) { 	
		if (o.getFlag() == VALUE_FLAG.POSITIVE_INFINITY) 
			return false; 
		if (!approximately)
			return this.largerThan(o);
		return (this.compareTo(o.add(boundsOfApproximation)) > 0); 	
	}
	@Override
	public boolean largerThan(Number o, boolean approximately)    { 	
		if (!approximately)
			return this.largerThan(o);
		return (this.compareTo(o.doubleValue() + boundsOfApproximation.toDouble()) > 0); 	}

	@Override
	public boolean largerThanOrEqualTo(NumberObjectSingle o, boolean approximately) { 
		if (o.getFlag() == VALUE_FLAG.POSITIVE_INFINITY) return false; 
		if (!approximately)
			return this.largerThanOrEqualTo(o);
		return (this.compareTo(o.add(boundsOfApproximation)) >= 0); 	
		}
	
	@Override
	public boolean largerThanOrEqualTo(Number o, boolean approximately)        { 	
		if (!approximately)
			return this.largerThanOrEqualTo(o);
		return (this.compareTo(o.doubleValue() + boundsOfApproximation.toDouble() ) >= 0); 	}
	
	@Override
	public boolean smallerThan(NumberObjectSingle o, boolean approximately) { 	
		if (o.getFlag() == VALUE_FLAG.NEGATIVE_INFINITY) return false; 
		if (!approximately)
			return this.smallerThan(o);
		return (this.compareTo(o.subtract(boundsOfApproximation)) < 0); 	}
	
	@Override
	public boolean smallerThan(Number o, boolean approximately)        { 	
		if (!approximately)
			return this.smallerThan(o);
		return (this.compareTo(o.doubleValue() - boundsOfApproximation.toDouble()) < 0); 	}
	
	@Override
	public boolean smallerThanOrEqualTo(NumberObjectSingle o, boolean approximately) { 	
		if (o.getFlag() == VALUE_FLAG.NEGATIVE_INFINITY) return false; 
		if (!approximately)
			return this.smallerThanOrEqualTo(o);
		return (this.compareTo(o.subtract(boundsOfApproximation)) <= 0); 	}
	
	@Override
	public boolean smallerThanOrEqualTo(Number o, boolean approximately)        { 	
		if (!approximately)
			return this.smallerThanOrEqualTo(o);
		return (this.compareTo(o.doubleValue() - boundsOfApproximation.toDouble()) <= 0); 	}

	
	@Override
	public int compareTo(DecimalNumber o) {
		if (this.flag == VALUE_FLAG.NEGATIVE_INFINITY || o.getFlag() == VALUE_FLAG.POSITIVE_INFINITY)
			return -1;
		if (this.flag == VALUE_FLAG.POSITIVE_INFINITY || o.getFlag()== VALUE_FLAG.NEGATIVE_INFINITY)
			return 1;

		return number.compareTo(o.toBigDecimal());
	}

	@Override
	public int compareTo(NumberObjectSingle o) {
		if (this.flag == VALUE_FLAG.NEGATIVE_INFINITY || o.getFlag() == VALUE_FLAG.POSITIVE_INFINITY)
			return -1;
		if (this.flag == VALUE_FLAG.POSITIVE_INFINITY || o.getFlag()== VALUE_FLAG.NEGATIVE_INFINITY)
			return 1;

		return number.compareTo(o.toBigDecimal());
	}
	@Override
	public int compareTo(Number d) {
		if (this.flag == VALUE_FLAG.NEGATIVE_INFINITY )
			return -1;
		if (this.flag == VALUE_FLAG.POSITIVE_INFINITY )
			return 1;

		if (number.doubleValue()>d.doubleValue()) return 1;
		if (number.doubleValue()<d.doubleValue()) return -1;
		return 0;
	}
	@Override
	public boolean equals(NumberObjectSingle o, boolean approximately) {
		if (o.getFlag() != this.flag)
			return false;

		if (this.getFlag() != VALUE_FLAG.NORMAL && this.getFlag() == o.getFlag())
			return true;

		if (!approximately)
			return number.compareTo(o.toBigDecimal())==0;

		NumberObjectSingle referencePoint = o.clone();
		referencePoint.useRange(false);
		if (inRange(referencePoint.subtract(boundsOfApproximation, false), referencePoint.add(boundsOfApproximation, false)))
			return true;
		return false;

	}

	@Override
	public boolean equals(double o, boolean approximately) {
		return equals(new DecimalNumber(o), approximately);
	}

	@Override
	public boolean equals(BigDecimal o, boolean approximately) {
		return equals(new DecimalNumber(o), approximately);
	}

	@Override
	public boolean equals(double o) {
		return equals(o, false);
	}

	@Override
	public boolean equals(BigDecimal o) {
		return equals(o, false);
	}


	@Override
	public boolean equals(String s) {
		return this.equals(new DecimalNumber(s), false);
	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof NumberObjectSingle)
			return this.equals((NumberObjectSingle) o, false);
		return false;

	}

	@Override
	public boolean equals(NumberObjectSingle o) {
		return this.equals(o, false);
	}
	
	@Override
	public boolean inRange(double lowerBound, double upperBound) {
		checkPreconditions(false);
		return (number.doubleValue()>=lowerBound && number.doubleValue() <= upperBound);
	}

	@Override
	public boolean inRange(NumberObjectSingle lowerBound, NumberObjectSingle upperBound) {
		checkPreconditions(false);
		return (this.compareTo(lowerBound)>=0 && this.compareTo(upperBound)<=0);
	}

	/** Returns true if the current value is a whole number*/
	public boolean isInteger(){
		return number.stripTrailingZeros().scale() <= 0;
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	TRANSFORMERS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DoubleNumber toDoubleNumber() {return new DoubleNumber(this);} 

	@Override
	public DecimalNumber toDecimalNumber() {return this;}

	@Override
	public NumberObjectSingle toNumberObjectSingle(NumberObjectRepresentation formatToUse) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return this.toDecimalNumber();
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return  this.toDoubleNumber();
		throw new UnknownNumberObjectException();
	}
	
	@Override
	public BigDecimal toBigDecimal() {return this.number;}

	@Override
	public int toInt(RoundingMode roundingMode) {return this.round(0, roundingMode, false).toBigDecimal().intValue();}

	@Override
	public double toDouble() {return number.doubleValue();}


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	ADDITION 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	private DecimalNumber add(BigDecimal argument, boolean changeOriginal)  {
		this.checkPreconditions(changeOriginal);
		BigDecimal newNumber =  number.add(argument, MC).setScale(SCALE, ROUNDING_MODE);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal ) {
			this.number = newNumber;
			this.checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber add(NumberObjectSingle argument) {
		return add(argument.toBigDecimal(), false);
	}

	@Override
	public DecimalNumber add(NumberObjectSingle argument, boolean changeOriginal) {
		return add(argument.toBigDecimal(), changeOriginal);
	}

	@Override
	public DecimalNumber add(Number argument) {
		return add(parseNumberToBigDecimal(argument), false);
	}

	@Override
	public DecimalNumber add(Number argument, boolean changeOriginal)  {
		return add(parseNumberToBigDecimal(argument), changeOriginal);
	}


	/**
	 * Adds the value of the two DecimalNumbers and returns a new mutable DecimalNumber. The range of
	 * the resulting DecimalNumber is unspecified.
	 * @param dn1
	 * @param dn2
	 * @return
	 */
	public static DecimalNumber add(DecimalNumber dn1, DecimalNumber dn2){
		return new DecimalNumber(dn1.add(dn2, false));
	}

	/**
	 * Adds the two double values and returns a DecimalNumber with that value. The DecimalNumber
	 * has a fixed scale and precision.
	 * @param d1
	 * @param d2
	 * @return
	 */
	public static DecimalNumber add(double d1, double d2)  {
		DecimalNumber dn1 = new DecimalNumber(d1);
		DecimalNumber dn2 = new DecimalNumber(d2);
		return dn1.add(dn2);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	SUBTRACTION 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	private DecimalNumber subtract(BigDecimal argument, boolean changeOriginal)  {
		this.checkPreconditions(changeOriginal);
		BigDecimal newNumber =  number.subtract(argument, MC).setScale(SCALE, ROUNDING_MODE);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal ) {
			this.number = newNumber;
			this.checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber subtract(NumberObjectSingle argument)  {
		return subtract(argument.toBigDecimal(), false);
	}

	@Override
	public DecimalNumber subtract(NumberObjectSingle argument, boolean changeOriginal)  {
		return subtract(argument.toBigDecimal(), changeOriginal);
	}

	@Override
	public DecimalNumber subtract(Number argument)  {
		return subtract(parseNumberToBigDecimal(argument), false);
	}

	@Override
	public DecimalNumber subtract(Number argument, boolean changeOriginal)  {
		return subtract(parseNumberToBigDecimal(argument), changeOriginal);
	}

	/**
	 * Subtracts the value of the two DecimalNumbers and returns a new mutable DecimalNumber. The range of
	 * the resulting DecimalNumber is unspecified.
	 * @param dn1
	 * @param dn2
	 * @return
	 */
	public static DecimalNumber subtract(DecimalNumber dn1, DecimalNumber dn2) {
		return dn1.subtract(dn2, false);
	}

	/**
	 * Subtracts the two double values and returns a DecimalNumber with that value. The DecimalNumber
	 * has a fixed scale and precision.
	 * @param d1
	 * @param d2
	 * @return
	 */
	public static DecimalNumber subtract(double d1, double d2)  {
		DecimalNumber dn1 = new DecimalNumber(d1);
		DecimalNumber dn2 = new DecimalNumber(d2);
		return dn1.subtract(dn2);
	}


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	MULTIPLICATION 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	private DecimalNumber multiply(BigDecimal argument, boolean changeOriginal)  {
		this.checkPreconditions(changeOriginal);
		BigDecimal newNumber =  number.multiply(argument, MC).setScale(SCALE, ROUNDING_MODE);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal ) {
			this.number = newNumber;
			this.checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber multiply(NumberObjectSingle argument) {
		return multiply(argument.toBigDecimal(), false);
	}

	@Override
	public DecimalNumber multiply(NumberObjectSingle argument, boolean changeOriginal) {
		return multiply(argument.toBigDecimal(), changeOriginal);
	}

	@Override
	public DecimalNumber multiply(Number argument) {
		return multiply(parseNumberToBigDecimal(argument), false);
	}

	@Override
	public DecimalNumber multiply(Number argument, boolean changeOriginal) {
		return multiply(parseNumberToBigDecimal(argument), changeOriginal);
	}

	/**
	 * Multiplies the value of the two DecimalNumbers and returns a new mutable DecimalNumber. The range of
	 * the resulting DecimalNumber is unspecified.
	 * @param dn1
	 * @param dn2
	 * @return
	 */
	public static DecimalNumber multiply(DecimalNumber dn1, DecimalNumber dn2)  {
		return dn1.multiply(dn2, false);
	}

	/**
	 * Multiplies the two double values and returns a DecimalNumber with that value. The DecimalNumber
	 * has a fixed scale and precision.
	 * @param d1
	 * @param d2
	 * @return
	 */
	public static DecimalNumber multiply(double d1, double d2)  {
		DecimalNumber dn1 = new DecimalNumber(d1);
		DecimalNumber dn2 = new DecimalNumber(d2);
		return dn1.multiply(dn2);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	DIVISION 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	private DecimalNumber divide(BigDecimal argument, boolean changeOriginal)  {
		this.checkPreconditions(changeOriginal);
		BigDecimal newNumber =  number.divide(argument, MC).setScale(SCALE, ROUNDING_MODE);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal ) {
			this.number = newNumber;
			this.checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber divide(NumberObjectSingle argument) {
		return divide(argument.toBigDecimal(), false);
	}

	@Override
	public DecimalNumber divide(NumberObjectSingle argument, boolean changeOriginal)   {
		return divide(argument.toBigDecimal(), changeOriginal);
	}

	@Override
	public DecimalNumber divide(Number argument)   {
		return divide(argument, false);
	}

	@Override
	public DecimalNumber divide(Number argument, boolean changeOriginal)   {
		return divide(parseNumberToBigDecimal(argument), changeOriginal);
	}

	/**
	 * Divides the value of the two DecimalNumbers and returns a new mutable DecimalNumber. The range of
	 * the resulting DecimalNumber is unspecified.
	 * @param dn1
	 * @param dn2
	 * @return
	 */
	public static DecimalNumber divide(DecimalNumber dn1, DecimalNumber dn2)  {
		return dn1.divide(dn2, false);
	}

	/**
	 * Divides the two double values and returns a DecimalNumber with that value. The DecimalNumber
	 * has a fixed scale and precision.
	 * @param d1
	 * @param d2
	 * @return
	 */
	public static DecimalNumber divide(double d1, double d2)  {
		DecimalNumber dn1 = new DecimalNumber(d1);
		DecimalNumber dn2 = new DecimalNumber(d2);
		return dn1.divide(dn2);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	POWER 	/////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DecimalNumber pow(int n, boolean changeOriginal)   {
		checkPreconditions(changeOriginal);
		BigDecimal newNumber = number.pow(n, MC).setScale(SCALE, ROUNDING_MODE);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber pow(int n)   {
		return pow(n, false);
	}

	@Override
	public DecimalNumber pow(double exponent, boolean changeOriginal)   {
		checkPreconditions(changeOriginal);
		double newValue = Math.pow(number.doubleValue(), exponent);
		BigDecimal newNumber = new BigDecimal(newValue, MC).setScale(SCALE, ROUNDING_MODE);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber pow(double exponent)   {
		return pow(exponent, false);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Other 	/////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DecimalNumber negate(boolean changeOriginal)   {
		checkPreconditions(changeOriginal);
		BigDecimal newNumber = number.negate(MC).setScale(SCALE, ROUNDING_MODE);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber negate()   {
		return this.negate(false);
	}

	@Override
	public DecimalNumber complementOfOne(boolean changeOriginal)   {
		checkPreconditions(changeOriginal);
		BigDecimal newNumber = BigDecimal.ONE.subtract(number, MC).setScale(SCALE, ROUNDING_MODE);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber complementOfOne()   {
		return this.complementOfOne(false);
	}

	@Override
	public DecimalNumber abs(boolean changeOriginal)   {
		checkPreconditions(changeOriginal);
		BigDecimal newNumber = number.abs();

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber remainder(NumberObjectSingle other) {
		return new DecimalNumber(this.number.remainder(other.toBigDecimal()));
	}

	@Override
	public boolean isDivisibleBy(NumberObjectSingle other) {
		DecimalNumber remainder = this.remainder(other);
		if (remainder.compareTo(0)==0)
			return true;
		return false;
	}

	@Override
	public DecimalNumber abs()   {
		return this.abs(false);
	}

	@Override
	public DecimalNumber winsorize(NumberObjectSingle lowerBound, NumberObjectSingle upperBound, boolean changeOriginal)  	{
		checkPreconditions(changeOriginal);
		BigDecimal newNumber;
		if 			(number.compareTo(lowerBound.toBigDecimal())==-1) 	newNumber = lowerBound.toBigDecimal();
		else if 	(number.compareTo(upperBound.toBigDecimal())==1)  	newNumber = upperBound.toBigDecimal();
		else 														newNumber = number;

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber round(int digits, RoundingMode roundingMode, boolean changeOriginal)  	{
		checkPreconditions(changeOriginal);
		BigDecimal newNumber = number.setScale(digits, roundingMode);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public DecimalNumber round(int digits, RoundingMode roundingMode)  	{
		return this.round(digits, roundingMode, false);
	}

	@Override
	public NumberObjectSingle roundToNearest(NumberObjectSingle value, RoundingMode roundingMode, boolean changeOriginal)  	{
		BigDecimal currentValue = this.number;
		BigDecimal increment = value.toBigDecimal();

		BigDecimal divided = currentValue.divide(increment, 0, roundingMode);
		BigDecimal newNumber = divided.multiply(increment);

		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);

	}


	@Override
	public NumberObjectSingle roundToNearest(NumberObjectSingle value, RoundingMode roundingMode) {
		return this.roundToNearest(value, roundingMode, false);
	}
	
	@Override
	public NumberObjectSingle mod(NumberObjectSingle other, boolean changeOriginal) {
		checkPreconditions(changeOriginal);

		BigDecimal newNumber = number.remainder(other.toBigDecimal(), MC).setScale(SCALE, ROUNDING_MODE);

		// Remainder != mod, as remainder can result in negative values. If there is a negative value, add one unit 
		// of other to the mix
		if (newNumber.compareTo(new BigDecimal("0")) == -1)
			newNumber = newNumber.add(other.toBigDecimal(), MC).setScale(SCALE, ROUNDING_MODE);
		
		// If the DecimalNumber is mutable, and we want to change the DecimalNumber itself:
		if (changeOriginal && !immutable) {
			number = newNumber;
			checkPostconditions();
			return this;
		}

		// If the DecimalNumber is immutable or if we do not want to change the DecimalNumber itself:
		return new DecimalNumber(newNumber, minimum, maximum, rangeSpecified, false);
	}

	@Override
	public NumberObjectSingle mod(NumberObjectSingle other) {
		return this.mod(other, false);
	}


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	toString 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	public String toString() {
		if (this.flag == VALUE_FLAG.NaN)
			return "NaN";
		if (this.flag == VALUE_FLAG.NULL)
			return "NULL";
		if (this.flag == VALUE_FLAG.NEGATIVE_INFINITY)
			return "-Infinity";
		if (this.flag == VALUE_FLAG.POSITIVE_INFINITY)
			return "Infinity";

		String s = number.toPlainString();
		if (rangeSpecified) s = s + "'";
		if (immutable) s = s + "*";
		return s;
	}

	/** Rounds to significant digits and returns corresponding string. Does not influence value of DecimalNumber object. Does not show affixes. */
	public String toString(int significantDigits) {
		if (significantDigits == -1)
			return toString();
		if (this == DecimalNumber.NaN)
			return "NaN";
		if (this == DecimalNumber.NULL)
			return "NULL";
		if (this == DecimalNumber.NEGATIVE_INFINITY)
			return "-Infinity";
		if (this == DecimalNumber.POSITIVE_INFINITY)
			return "Infinity";

		DecimalFormat df;
		if (significantDigits>0) df = new DecimalFormat("0." + Helper.repString("0", significantDigits));
		else df = new DecimalFormat();
		String s = df.format(number);

		if (rangeSpecified) s = s + "'";
		if (immutable) s = s + "*";
		return s;
	}


	/**Rounds to significant digits and returns corresponding string that reserves a white space for positive values. Does not influence value of DecimalNumber object. Does not show affixes.  */
	public String toSignSpacedString(int significantDigits)
	{
		String s = this.toString(significantDigits);
		if (this.compareTo(0) != -1) s = " " + s;
		return s;
	}

	/** Returns a string with the value of this decimal number. Does not display '*' for immutable values or "'" for values with a specified range */
	public String toPlainString() {
		if (this == DecimalNumber.NaN)
			return "NaN";
		if (this == DecimalNumber.NULL)
			return "NULL";
		if (this == DecimalNumber.NEGATIVE_INFINITY)
			return "-Infinity";
		if (this == DecimalNumber.POSITIVE_INFINITY)
			return "Infinity";

		return number.toPlainString();
	}

	@Override
	public String toStringWithoutTrailingZeros () {
		return this.toString(this.getSignificantDigits());
	}
	/////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Hash 	/////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		//result = prime * result + (immutable ? 1231 : 1237);
		//result = prime * result + ((maximum == null) ? 0 : maximum.hashCode());
		//result = prime * result + ((minimum == null) ? 0 : minimum.hashCode());
		result = prime * result + ((number == null) ? 0 : number.hashCode());
		//result = prime * result + (rangeSpecified ? 1231 : 1237);
		return result;
	}

	@Override
	public String toRParsableString() {
		return this.toString();
	}

	



}
