package staticManagers;

import java.io.File;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

import attributes.AttributeField;
import core.AbstractModel;
import core.Model;
import helper.Helper;
import helper.Helper.Pair;
import rIntegration.RFunctionContainer;
import start.Console;
import states.EncounterStates.T2ActionState;
import states.EncounterStates.T2DecisionTree;
import states.EncounterStates.T2MutationState;
import view.View.SaveT2Mode;

/**
 * This manager handles all input from files, and output to files.
 * Specifically, it:
 * 
 * 1. Manages the writing and reading of T2DecisionTree's to the disk (if necessary);
 * 2. Manages the writing of all results to disk, including creating subfolders.
 * 
 * Note that an OutputFileManager is model specific; each Model should have one.
 */
public class OutputFileManager {

	public final File modelFolder;
	public final File t1StateDirectory;
	public final File temporaryT2DecisionTreeDirectory;
	public final File t2ResultsFolder;
	public final ConcurrentHashMap<Integer, File> t2ResultSubfolders;
	public final TreeOutputManager treeOutputManager;
	public final File exceptionFolder;
	public final AbstractModel model;
	
	/** Maps a T2DecisionTree's name to a safety number. Used only when
	 * the model stores the T2DecisionTree's to disk*/
	private final HashMap<String, File> t2DecisionTreeNameToStoredLocation;
	
	/** Maps a T2DecisionTree's name to a safety number. The same (random) number should
	 * be stored in the Tree. Used only when the model stores the T2DecisionTree's to disk*/
	private final HashMap<String, Integer> t2DecisionTreeNameToSafetyNumber;
	
	/** The outputDirectory should be the folder where the user wants the output. The OutputFileManager
	 * will create subfolders here if necessary. */
	public OutputFileManager(AbstractModel model, File userSpecifiedDirectory)	{
		this.model = model;
		// check if the output file exists
		if (!userSpecifiedDirectory.exists() || !userSpecifiedDirectory.isDirectory())
			throw new IllegalArgumentException("Specified output folder does not exist. File "+ userSpecifiedDirectory.getAbsolutePath());

		// Create a new folder that has as name the unique model identifier
		// add (x) suffix if the folder already exists, with x increasing from 1
		boolean createdFolder = false;
		int attempt = 0;
		File f = null;
		while (!createdFolder) { 
			attempt ++;
			String suffix = "";
			if (attempt > 1)
				suffix = " (" + attempt + ")";
			f = new File(userSpecifiedDirectory.getAbsolutePath() + "\\" + model.name + suffix );
			createdFolder = f.mkdir();
		}
		modelFolder = f;

		// If the user wants to store all T1 States, create new subfolder called 'T1 states'
		if (model.saveT1StatesAsOutput) {
			this.t1StateDirectory = new File (modelFolder.getAbsoluteFile() + "\\T1 states\\");
			t1StateDirectory.mkdir();
		} else
			this.t1StateDirectory = null;
		
		// If the user wants to store all T2 results, create a folder for that, and, if the user
		// also wants to store results per age, create all subfolders
		if (model.saveT2OutputMode == SaveT2Mode.ALL || model.saveT2OutputMode == SaveT2Mode.T0_ONLY) {
			this.t2ResultsFolder = new File (modelFolder.getAbsoluteFile() + "\\T2 results\\");
			this.t2ResultsFolder.mkdir();

			this.treeOutputManager = new TreeOutputManager(this);
			
			int maxAge = 0;
			if (model.saveT2OutputMode == SaveT2Mode.ALL)
				maxAge = model.maximumAge;

			this.t2ResultSubfolders = new ConcurrentHashMap<>();
			for (int age = 0; age <= maxAge; age++) {
				File sub = new File (modelFolder.getAbsoluteFile() + "\\T2 results\\Age " + age );
				sub.mkdir();
				this.t2ResultSubfolders.put(age, sub);
			}

		} else {
			this.t2ResultsFolder = null;
			this.t2ResultSubfolders = null;
			this.treeOutputManager = null;
		}
		
		// If the user wants to store the intermediate T2 states, create a new subfolder called 'Temporary T2 decision trees'
		// In addition, initialize t2DecisionTreeNameToStoredLocation
		if (model.saveT2TreesToFile) {
			this.temporaryT2DecisionTreeDirectory =  new File (modelFolder.getAbsoluteFile() + "\\Temporary T2 decision trees\\");
			this.temporaryT2DecisionTreeDirectory.mkdir();
			t2DecisionTreeNameToStoredLocation = new HashMap<>();
			t2DecisionTreeNameToSafetyNumber = new HashMap<>();
		} else {
			this.temporaryT2DecisionTreeDirectory = null;
			t2DecisionTreeNameToStoredLocation = null;
			t2DecisionTreeNameToSafetyNumber = null;
		}
		
		// Create a folder to store all exceptions in
		this.exceptionFolder = new File(modelFolder.getAbsoluteFile() + "\\Exceptions");
		exceptionFolder.mkdir();
	}
	
	/** Writes a .txt file containing all the information in the ledger*/
	public void writeLedgerToFile() {
		Console.print("Writing ledger to file...");
		ExternalFileManager.writeToTextFile(modelFolder, "ledger", model.ledger.toString());
		Console.print("Done writing ledger to file.");
	}
	
	/** Writes everything that was printed to the console to the file*/
	public void writeConsoleToFile() {
		Console.print("Writing console to file...");
		ExternalFileManager.writeToTextFile(modelFolder, "consoleLog", Console.getConsole().getCopy());
		Console.print("Done writing console to file.");
	}
	
	/** Writes a caught exception to a .txt file in the exceptionFolder*/
	public void writeExceptionToFile(Exception e) {
		Console.print("Writing exception to exception folder...");
		
		String filename;
		synchronized(this) {
			filename = "Exception " + (this.exceptionFolder.listFiles().length+1);
		}
		StringBuilder sb = new StringBuilder(Helper.timestamp() + "\nException encountered in thread " + Thread.currentThread().getName());
		sb.append("\nException message: " + e.getMessage() + "\n\n\nStack trace: ");
		for (StackTraceElement ste : e.getStackTrace())
			sb.append("\n" + ste.toString());
		
		ExternalFileManager.writeToTextFile(exceptionFolder, filename,sb.toString());
	}
	
	/** Returns a pair of two StringBuilder, containing the columns headers for all the model-invariant
	 * (fixed within model) variable names, and the values of those variables, respectively
	 */
	public Pair<StringBuilder, StringBuilder> getModelInvariantVariableNamesAndValues(String delimiter){
		// Each entry contains two types of fields. First are the 'fixed' modeling effects, or the variables
		// that do not change during the run of the model. For example, the specific sampling distributions 
		// used for all non-phenotype dimensions. Second, each entry will have T1State specific fields. For example,
		// the age, phenotype, and expected fitness. The second part will be added by the T1StateList. However, the T1StateList
		// needs to know what the model-invariant fields are. Hence, we first make two Strings. The first is the
		// column names (separated by the delimiter), to be used as the column header. The second are the values for all
		// column names (again, separated by the delimiter)
		StringBuilder modelInvariantVariableNames = new StringBuilder();
		StringBuilder modelInvariantVariableValues = new StringBuilder();

		// Record the model name
		modelInvariantVariableNames.append("ModelName" + delimiter);
		modelInvariantVariableValues.append(model.name + delimiter);

		// For each resource type: record the sampling distribution type, and all possible arguments for that sampling distribution
		// (excluding domain)
		if (model.ledger.numberOfResourceTypes>0)
			for (int r = 0; r < model.ledger.numberOfResourceTypes; r++) {
				RFunctionContainer rfc = model.ledger.resourceFunctionContainers[r];
				modelInvariantVariableNames.append(model.ledger.resourceNames[r] + "_distribution_type" + delimiter);
				if (rfc != null)
					modelInvariantVariableValues.append(rfc.getRFunction().getName() + delimiter);
				else
					modelInvariantVariableValues.append("CONSTANT_"+ model.ledger.resourceValues[r][0].toStringWithoutTrailingZeros() + delimiter);

				if (rfc!=null)
					for (int arg = 0; arg < rfc.getLoadedArguments().size(); arg++) {
						AttributeField af = rfc.getLoadedArguments().get(arg);
						if (!af.getName().equalsIgnoreCase("domain")) {
							modelInvariantVariableNames.append(model.ledger.resourceNames[r] + "_distribution_" + af.getName() + delimiter);
							modelInvariantVariableValues.append(af.getValueStringWithoutTrailingZeros()+ delimiter);
						}
					}
			}

		// For each delay type: record the sampling distribution type, and all possible arguments for that sampling distribution
		// (excluding domain)
		if (model.ledger.numberOfDelayTypes>0)
			for (int d = 0; d < model.ledger.numberOfDelayTypes; d++) {
				RFunctionContainer rfc = model.ledger.delayFunctionContainers[d];
			
				// Note: constants do not have a name.
				modelInvariantVariableNames.append(model.ledger.delayNames[d] + "_distribution_type" + delimiter);
				if (rfc != null)
					modelInvariantVariableValues.append(rfc.getRFunction().getName() + delimiter);
				else 
					modelInvariantVariableValues.append("CONSTANT_" + model.ledger.delayValues[d][0] + delimiter);
				
				if (rfc != null)
					for (int arg = 0; arg < rfc.getLoadedArguments().size(); arg++) {
						AttributeField af = rfc.getLoadedArguments().get(arg);
						if (!af.getName().equalsIgnoreCase("domain")) {
							modelInvariantVariableNames.append(model.ledger.delayNames[d] + "_distribution_" + af.getName() + delimiter);
							modelInvariantVariableValues.append(af.getValueStringWithoutTrailingZeros()+ delimiter);
						}
					}
			}


		// For each interruption type: record the sampling distribution type, and all possible arguments for that sampling distribution
		// (excluding domain)
		if (model.ledger.numberOfInterruptionTypes>0)
			for (int i = 0; i < model.ledger.numberOfInterruptionTypes; i++) {
				RFunctionContainer rfc = model.ledger.interruptionFunctionContainers[i];
				modelInvariantVariableNames.append(model.ledger.interruptionNames[i] + "_distribution_type" + delimiter);
				if (rfc != null)
					modelInvariantVariableValues.append(rfc.getRFunction().getName() + delimiter);
				else 
					modelInvariantVariableValues.append("CONSTANT_" + model.ledger.interruptionValues[i].toStringWithoutTrailingZeros() + delimiter);
				
				if (rfc != null)
				for (int arg = 0; arg < rfc.getLoadedArguments().size(); arg++) {
					AttributeField af = rfc.getLoadedArguments().get(arg);
					if (!af.getName().equalsIgnoreCase("domain")) {
						modelInvariantVariableNames.append(model.ledger.interruptionNames[i] + "_distribution_" + af.getName() + delimiter);
						modelInvariantVariableValues.append(af.getValueStringWithoutTrailingZeros()+ delimiter);
					}
				}
			}


		// For each extrinsic event type: record the sampling distribution type, and all possible arguments for that sampling distribution
		// (excluding domain)
		if (model.ledger.numberOfExtrinsicTypes>0)
			for (int e = 0; e < model.ledger.numberOfExtrinsicTypes; e++) {
				RFunctionContainer rfc = model.ledger.extrinsicFunctionContainers[e];
				modelInvariantVariableNames.append(model.ledger.extrinsicNames[e] + "_distribution_type" + delimiter);
				if (rfc != null)
					modelInvariantVariableValues.append(rfc.getRFunction().getName() + delimiter);
				else 
					modelInvariantVariableValues.append("CONSTANT_" + model.ledger.extrinsicValues[e][0].toStringWithoutTrailingZeros() + delimiter);
				
				if (rfc != null)
					for (int arg = 0; arg < rfc.getLoadedArguments().size(); arg++) {
						AttributeField af = rfc.getLoadedArguments().get(arg);
						if (!af.getName().equalsIgnoreCase("domain")) {
							modelInvariantVariableNames.append(model.ledger.extrinsicNames[e] + "_distribution_" + af.getName() + delimiter);
							modelInvariantVariableValues.append(af.getValueStringWithoutTrailingZeros()+ delimiter);
						}
					}
			}
		return new Pair<StringBuilder, StringBuilder>(modelInvariantVariableNames, modelInvariantVariableValues);
	}
	/** Writes the model's T1StateList to a CSV file, using the specified delimiter. Each entry in the
	 * CSV file contains the model's fixed fields (i.e., environmental settings), as well as exactly
	 * one T1MutationState or T1ActionState. T1Fitness states are written to a separate file, as they 
	 * are used only for checking, and do not count as modeling results. The resulting string
	 * ENDS WITH A DELIMITER. 
	 * 
	 * If separateFilesPerAge is true, this function writes a new csv file for each possible age. Otherwise
	 * all ages are added in one big file.*/
	public void writeResults (String delimiter, boolean separateFilesPerAge) {
		Console.print("Writing results to file...");
		
		// Get the fixed variable names
		Pair<StringBuilder, StringBuilder> invariants = this.getModelInvariantVariableNamesAndValues(delimiter);
		StringBuilder modelInvariantVariableNames = invariants.element1;
		StringBuilder modelInvariantVariableValues = invariants.element2;
		
		// Next, ask the T1StateList to create the rest of the results file or files
		// If we need only one file for all ages: get that, and write immediately
		if (!separateFilesPerAge) {
			String results = model.getT1StateList().toResultsStringForAllAges(modelInvariantVariableNames.toString(), modelInvariantVariableValues.toString(), delimiter);
			ExternalFileManager.writeToCSVFile(modelFolder, "Results", results);
		} else {
			for (int age = 0; age < model.maximumAge; age++) {
				String results = model.getT1StateList().toResultsStringForAge(modelInvariantVariableNames.toString(), modelInvariantVariableValues.toString(), delimiter, age);
				ExternalFileManager.writeToCSVFile(modelFolder, "Results for age " + age, results);
			}
		}
		Console.print("Done writing results to file.");
	}
	
	/** Writes the T2DecisionTree to a CSV file, using the specified delimiter. Each entry in the
	 * CSV file contains the model's fixed fields (i.e., environmental settings), as well as exactly
	 * one T2MutationState or T2ActionState. T1Fitness states are written to a separate file, as they 
	 * are used only for checking, and do not count as modeling results. The resulting string
	 * ENDS WITH A DELIMITER. 
	 * 
	 * If separateFilesPerAge is true, this function writes a new csv file for each possible age. Otherwise
	 * all ages are added in one big file.*/
	public void writeResults (T2DecisionTree tree, String delimiter, boolean separateFilesPerAge) {
		Console.print("Writing T2 Decision tree to file...");
		
		// Get the fixed variable names
		Pair<StringBuilder, StringBuilder> invariants = this.getModelInvariantVariableNamesAndValues(delimiter);
		StringBuilder modelInvariantVariableNames = invariants.element1;
		StringBuilder modelInvariantVariableValues = invariants.element2;
		
		// Next, ask the T2StateList of this T2DecisionTree to create the rest of the results file or files
		// If we need only one file for all ages: get that, and write immediately
		String results = tree.treeStateList.toResultsStringForAllTimeSteps(modelInvariantVariableNames.toString(), modelInvariantVariableValues.toString(), delimiter);
		if (!model.saveResultPerAge) {
			ExternalFileManager.writeToCSVFile(this.t2ResultsFolder, tree.name, results);
		} else {
			ExternalFileManager.writeToCSVFile(this.t2ResultSubfolders.get(tree.root.getAge()), tree.name, results);
		}
		Console.print("Done writing T2 Decision tree results to file.");
	}
	
	/** Creates a new file in the temporaryT2DecisionTreeDirectory for the specified T2DecisionTree.
	 * The name of the file will be the '[name of T2DecisionTree].ttt'. Throws an IllegalStateException
	 * if such a file already exists (note: T2DecisionTree's should have unique names. As such, duplicate
	 * names should never occur!)*/
	public void storeT2DecisionTree(T2DecisionTree tree) {
		// If we want to be sure, check if we are writing a correct tree to disk
		if (model.performSafetyChecks) {
			
			// Check if all states in this tree have at least one successor
			for (T2MutationState m : tree.treeStateList.getAllMutationStates())
				if (m.referencePathToSuccessorT1FitnessStates.size() + 
						m.referencePathToSuccessorT1ActionStates.size() +
						m.getSuccessorT2ActionPaths().size() == 0)
					throw new IllegalStateException("Trying to write tree '" + tree.name + "' to disk. However, in this tree"
							+ " state " + m.getName() + " has no successors. Tree: ");
			
			for (T2ActionState m : tree.treeStateList.getAllActionStates()) {
				boolean atLeastOnePossibleAction = false;
				for (int a = 0; a < m.possibleActions.length; a++)
					if (m.possibleActions[a]) {
						atLeastOnePossibleAction = true;
						if (m.referencePathToSuccessorT1FitnessStates.get(a).size() + 
								m.referencePathToSuccessorT1MutationStates.get(a).size() +
								m.getSuccessorT2MutationPaths(a).size() == 0)
							throw new IllegalStateException("Trying to write tree '" + tree.name + "' to disk. However, in this tree"
									+ " state " + m.getName() + " has no successors for action " + a );
					}
				if (! atLeastOnePossibleAction)
					throw new IllegalStateException("Trying to write tree '" + tree.name + "' to disk. However, in this tree"
							+ " state " + m.getName() + " has no possible actions. ");
			}
		}
		if (!model.saveT2TreesToFile)
			throw new IllegalStateException("Trying to store a T2DecisionTree to file without the model having willed it so.");
		/*File resultingFile = ExternalFileManager.writeObjectWithAssociatedFileExtention(tree, this.temporaryT2DecisionTreeDirectory, tree.name, model.performSafetyChecks);
		if (resultingFile == null)
			throw new IllegalStateException("Written T2DecisionTree to a null file.");
		synchronized (t2DecisionTreeNameToStoredLocation) {
			if (t2DecisionTreeNameToStoredLocation.get(tree.name) != null)
				throw new IllegalStateException("There is already a file for a T2DecisionTree with name '" + tree.name + ".");
			this.t2DecisionTreeNameToStoredLocation.put(tree.name, resultingFile);

			// Store the safety number for future checking
			this.t2DecisionTreeNameToSafetyNumber.put(tree.name, tree.randomCheckNumber);
		}*/
		this.treeOutputManager.submitTreeToWrite(tree);
	}
	
	/** Loads a T2DecisionTree from the file with the specified filename.*/
	public T2DecisionTree loadT2DecisionTree(String treeName) {
		/*File location = t2DecisionTreeNameToStoredLocation.get(treeName);
		
		if (location == null) {
			// There is no mapping from this tree name to a file... but is there a file with the correct name in the folder?
			System.err.println("WARNING: could not find file for T2Tree " + treeName);
			location = new File(this.temporaryT2DecisionTreeDirectory+ "\\" + treeName + ".ttt");
		}
			
		if (location == null)
			throw new IllegalArgumentException("Tree with name '" + treeName + "' does not have a file associated with it...");
			
		
		if (!location.exists()) 
			throw new IllegalArgumentException("Cannot load tree with name '" + treeName + "': no file exists (" + location.getAbsolutePath() + ")");
		
		// Load the tree
		T2DecisionTree loadedTree = ExternalFileManager.loadObjectWithAssociatedFileExtention(location, T2DecisionTree.class);
		
		// See if the security numbers check out
		if (loadedTree.randomCheckNumber != this.t2DecisionTreeNameToSafetyNumber.get(treeName))
			throw new IllegalStateException("Security number of loaded tree does not match security number on file!");
		
		// Remove the file - they can be quite large, and we do not want to use up hundreds of GBs for no reason at all
		location.delete();
		
		return loadedTree;*/
		return this.treeOutputManager.getT2DecisionTree(treeName);
	}
	
	/** Should be called by the Model after all T2DecisionTrees for this age have been computed in the forwards pass. Until this function
	 * is called, these T2DecisionTrees have not yet been written to file. Instead, this exist in a buffer, managed
	 * by a TreeOutputManager. This function forces the TreeOutputManager to write all buffered T2DecisionTrees to a file
	 * @throws InterruptedException */
	public void writeAllTrees(int age) throws InterruptedException {
		this.treeOutputManager.writeAllTreesInBuffer(age);
	}
	
	/** Should be called by the Model before the T2DecisionTrees for this age are required for the Backwards pass. This function
	 * reads all the T2DecisionTree's for this age from disk to memory, which can then be accessed via loadT2DecisionTree.
	 * @throws InterruptedException */
	public void readAllTrees(int age) throws InterruptedException {
		this.treeOutputManager.loadAllTreesToBuffer(age);
	}
	

}
