package staticManagers;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import interfaces_abstractions.ObserverManager;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/** The ExternalFileManager handles all saving of objects to specific fileExtension 
 * files via FileChooser and the loading of these file to the application. */
public class ExternalFileManager {

	/** The most recently opened directory*/
	private static File lastUsedDirectory = new File (System.getProperty("user.home")); 
	
	/** The path to this projects OUTPUT folder*/
	private static File projectFolderDirectory = new File (""); 
	public static File outputFolderDirectory = new File (projectFolderDirectory.getAbsolutePath()+"\\Output"); 
	
	/** The view. Set by the view */
	private static Stage currentStage;	

	/** This enum houses all file types used by the program for saving/loading to external files. */
	public enum FILE_TYPE {
		
		T2_DECISION_TREE("ttt"),
		WORKSPACE("wksp");
		
		private String fileExtention;
		FILE_TYPE(String fileExtention){ this.fileExtention = fileExtention; }
		public String getFileExtention() { return this.fileExtention; }
	}
	
	/** A class that implements this interface must implement a standard file type to store/load objects of this class in. */
	public interface AssociatedFileExtention extends Serializable {
		
		/** What file type should this object be stored in? */
		public FILE_TYPE getFileType();
	}
	
	/** Set a stage where the FileChooser objects will be stored in*/
	public static void setStage(Stage newStage) {
		currentStage = newStage;
	}
	
	/** Provides a pop-up FileChooser for the user the save a file in. Only files with the specified extension are shown. 
	 * This function then saves the specified object to that file.  */
	public static void saveObjectToFileUsingFileChooser(FILE_TYPE fileType, Serializable content) {
		// Check if there is a currentStage:
		if (currentStage == null)
			throw new IllegalStateException("Trying to use ExternalFileManager without providing it with a stage first");
		
		FileChooser fileChooser = new FileChooser();
		 
        // Set extension filters
        FileChooser.ExtensionFilter extFilter = new ExtensionFilter(fileType.fileExtention + " files (*." + fileType.fileExtention + ")", "*." + fileType.fileExtention);
        fileChooser.getExtensionFilters().add(extFilter);
        fileChooser.setInitialDirectory(lastUsedDirectory);
        fileChooser.setTitle("Save object as a " + fileType.toString() + " type file");
        
        // Show save file dialog
        File file = fileChooser.showSaveDialog(currentStage);

        // Check if the user selected a file
        if (file == null)
        	return;
        
        // Set the lastUsedDirectory
        lastUsedDirectory = file.getParentFile();

        // save this to file
        FileOutputStream fileStream = null;
        try {
        	fileStream = new FileOutputStream(file);
        	ObjectOutputStream objectStream = new ObjectOutputStream(new BufferedOutputStream(fileStream));
        	objectStream.writeObject(content);
        	objectStream.close();
        	fileStream.close();
        } catch (IOException e) {ObserverManager.notifyObserversOfError(e);        
        }  finally { 
        	if (fileStream != null)
        		try {
        			fileStream.close();
        		} catch (IOException e) {ObserverManager.notifyObserversOfError(e); }}



	}
	
	/** Saves the object with an AssociatedFileExtention using the filename registered to that file type*/
	public static void saveObjectToFileUsingFileChooser(AssociatedFileExtention content){
		saveObjectToFileUsingFileChooser(content.getFileType(), content);
	}

	/** Create a file containing the String s. This file has the specified extension and it placed
	 * at the specified location. 
	 * The extension should include the dot (e.g., '.txt' or '.csv'). 
	 * If there already is a file with that name, a (x) is added at the end
	 * of the file name.*/
	public static void writeStringToFile(File directory, String filename, String extension, String s) {
		// Make sure that the filename does not already have an extention
		filename = filename.split("\\.")[0];
		if (filename.length()==0)
			throw new IllegalArgumentException("Writing text to file: filename should have at least one character before a '.'");
		
		// Create a new file
		// add (x) suffix if the folder already exists, with x increasing from 1
		File file = new File( directory.getAbsolutePath() + "\\" + filename + extension);
		if (file.exists()) {
			boolean createdFile = false;
			int attempt = 0;
			while (!createdFile) { 
				file = new File(directory.getAbsolutePath() + "\\" + filename +  " (" + attempt + ")"+ extension );
			}
		}
		
		// Write the string
		try {
			FileWriter writer = new FileWriter(file);
			writer.write(s);
			writer.close();
		} catch (IOException e) {
			ObserverManager.notifyObserversOfError(e);
		}
	}
	
	/** Creates a text file (.txt) at the location containing the specified String. 
	 * If there already is a file with that name, a (x) is added at the end. */
	public static void writeToTextFile(File directory, String filename, String s) {
		writeStringToFile(directory, filename, ".txt", s);
	}
	
	/** Creates a text file (.csv) at the location containing the specified String.
	 * If there already is a file with that name, a (x) is added at the end. */
	public static void writeToCSVFile(File directory, String filename, String s) {
		writeStringToFile(directory, filename, ".txt", s);
	}
	
	/** Opens a FileChooser and lets the user open a file. The file is then parsed to a 
	 * Serializable object. Note that this means that the file houses a class - it should
	 * not be a .txt file with parameter input. The fileType specifies which files can
	 * be selected. If null, all types are allowed (but will result in an exception if
	 * a file is selected that is not a serialised object!)*/
	public static Serializable loadObjectFromFileUsingFileChooser (FILE_TYPE fileType) {
		// Check if there is a currentStage:
		if (currentStage == null)
			throw new IllegalStateException("Trying to use ExternalFileManager without providing it with a stage first");

		FileChooser fileChooser = new FileChooser();

		// Set extension filters
		if (fileType != null) {
			FileChooser.ExtensionFilter extFilter = new ExtensionFilter(fileType.fileExtention + " files (*." + fileType.fileExtention + ")", "*." + fileType.fileExtention);
			fileChooser.getExtensionFilters().add(extFilter);
		}
		fileChooser.setInitialDirectory(lastUsedDirectory);
		fileChooser.setTitle("Load a " + fileType.toString() + " type object");

		// Show save file dialog
		File file = fileChooser.showOpenDialog(currentStage);

		// Check if the user selected a file
		if (file == null)
			return null;

		// Set the lastUsedDirectory
		lastUsedDirectory = file.getParentFile();
		
		// Load the file
		ObjectInputStream streamIn = null;
		Serializable returnObject = null;
		try {
			streamIn = new ObjectInputStream(new FileInputStream(file));
        	returnObject = (Serializable) streamIn.readObject();
        	
        } catch (IOException | ClassNotFoundException e) {ObserverManager.notifyObserversOfError(e);        
        } finally { 
        	if (streamIn != null)
			try {
				streamIn.close();
			} catch (IOException e) {ObserverManager.notifyObserversOfError(e); }}
        
		return returnObject;
	}

	/** Opens a FileChooser and lets the user open a directory. Optional initial directory.*/
	public static File selectDirectory (File initialDirectory, String chooserTitle) {
		// Check if there is a currentStage:
		if (currentStage == null)
			throw new IllegalStateException("Trying to use ExternalFileManager without providing it with a stage first");

		DirectoryChooser directoryChooser = new DirectoryChooser();
		directoryChooser.setTitle(chooserTitle);
		
		if (initialDirectory == null || !initialDirectory.exists())
			directoryChooser.setInitialDirectory(lastUsedDirectory);
		else
			directoryChooser.setInitialDirectory(initialDirectory);
	
		// Show the dialog
		File selectedDirectory = directoryChooser.showDialog(currentStage);

		// Check if the user selected a directory
		if (selectedDirectory == null)
			return null;

		// Set the lastUsedDirectory
		lastUsedDirectory = selectedDirectory.getParentFile();
		return selectedDirectory;
	}
	
	/** Opens a FileChooser and lets the user open a file. The file is then parsed to a 
	 * object of the specified class. 
	 * 
	 * Note: this file has to house a Serializable class - it should
	 * not be a .txt file with parameter input. The fileType specifies which files can
	 * be selected. If null, all types are allowed (but will result in an exception if
	 * a file is selected that is not a serialised object!)
	 * @return */
	public static <T extends Serializable> T loadAndCastObjectFromFile(FILE_TYPE fileType, Class<T> type){
		 return type.cast(loadObjectFromFileUsingFileChooser(fileType));
	}
	
	/** Writes an object from a class that implements AssociatedFileExtention to the specified
	 * folder. The new File containing the object has the specified name. Returns the File to 
	 * which the object was written. 
	 * 
	 * Throws an IllegalArgumentException if the folder is not a folder, or does not exist, and if the
	 * new file already exists.*/
	public static File writeObjectWithAssociatedFileExtention (AssociatedFileExtention object, File folder, String filename, boolean performSafetyChecks) {
		// check if the folder exists
		if (performSafetyChecks)
			if (!folder.exists() || !folder.isDirectory())
				throw new IllegalArgumentException("Cannot write object to folder '"+ folder.getAbsolutePath() + "' as that folder is either not a directory or does not exist");

		// Check if there already is a file with the specified filename in the folder
		File fileToStoreObjectIn = new File(folder.getAbsolutePath() + "\\" + filename + "."+ object.getFileType().fileExtention);
		if (performSafetyChecks)
			if (fileToStoreObjectIn.exists())
				throw new IllegalArgumentException("Cannot create file '"+ fileToStoreObjectIn.getAbsolutePath() + "': file already exists!");

		// Save the object to file
		FileOutputStream fileStream = null;
		BufferedOutputStream buffer = null;
		ObjectOutputStream objectStream = null;
		try {
			fileStream = new FileOutputStream(fileToStoreObjectIn);
			buffer = new BufferedOutputStream(fileStream);
			objectStream = new ObjectOutputStream(buffer);
			objectStream.writeObject(object);
			objectStream.close();
			fileStream.close();
		} catch (IOException e) {ObserverManager.notifyObserversOfError(e);        
		}  finally { 
			try {
				if (fileStream != null)
					fileStream.close();
				if (buffer != null)
					buffer.close();
				if (objectStream != null)
					objectStream.close();
			} catch (IOException e) {ObserverManager.notifyObserversOfError(e); }}

		return fileToStoreObjectIn;

	}

	/** Writes the object to the specified folder. The new File containing the object has the specified name. Returns the File to 
	 * which the object was written. Note the filename should not contain an extension (e.g., ".txt"). Rather, this is added by this function
	 * 
	 * Throws an IllegalArgumentException if the folder is not a folder, or does not exist, and if the
	 * new file already exists.*/
	public static File writeObjectToDisk (Object object, File folder, String filename, String fileExtension, boolean performSafetyChecks) {
		// check if the folder exists
		if (performSafetyChecks)
			if (!folder.exists() || !folder.isDirectory())
				throw new IllegalArgumentException("Cannot write object to folder '"+ folder.getAbsolutePath() + "' as that folder is either not a directory or does not exist");

		// Check if there already is a file with the specified filename in the folder
		File fileToStoreObjectIn = new File(folder.getAbsolutePath() + "\\" + filename + "."+ fileExtension);
		if (performSafetyChecks)
			if (fileToStoreObjectIn.exists())
				throw new IllegalArgumentException("Cannot create file '"+ fileToStoreObjectIn.getAbsolutePath() + "': file already exists!");

		// Save the object to file
		FileOutputStream fileStream = null;
		BufferedOutputStream buffer = null;
		ObjectOutputStream objectStream = null;
		try {
			fileStream = new FileOutputStream(fileToStoreObjectIn);
			buffer = new BufferedOutputStream(fileStream);
			objectStream = new ObjectOutputStream(buffer);
			objectStream.writeObject(object);
			objectStream.close();
			fileStream.close();
		} catch (IOException e) {ObserverManager.notifyObserversOfError(e);        
		}  finally { 
			try {
				if (fileStream != null)
					fileStream.close();
				if (buffer != null)
					buffer.close();
				if (objectStream != null)
					objectStream.close();
			} catch (IOException e) {ObserverManager.notifyObserversOfError(e); }}

		return fileToStoreObjectIn;

	}


	/** Loads an object from the specified file, and returns the loaded (and casted) object.
	 * Throws an IllegalArgumentException if the file does not exist. Throws an IllegalStateException
	 * if the loaded object is not of the specified type.*/
	public static <T extends Serializable> T loadObject(File file, Class<T> type){
		// Check if the file exists
		if (file == null)
			throw new IllegalArgumentException("Cannot load object from null file." );
		if (file.isDirectory() || !file.exists())
			throw new IllegalArgumentException("Cannot load object from file: '" + file.getAbsolutePath() + "': file does not exist or is a directory." );
		
		// Load the file
		FileInputStream fileStream = null;
		BufferedInputStream buffer = null;
		ObjectInputStream objectStream = null;
		
		try {
			fileStream = new FileInputStream(file);
			buffer = new BufferedInputStream(fileStream);
			objectStream = new ObjectInputStream(buffer);
			
			Object loadedObject = objectStream.readObject();
			if (!type.isAssignableFrom(loadedObject.getClass()))
				throw new IllegalArgumentException("Object in file does not match expected object class");
			return type.cast(loadedObject);

		} catch (IOException | ClassNotFoundException e) {
			ObserverManager.notifyObserversOfError(e);  
			
		} finally { 
			try {
			if (fileStream != null)
				fileStream.close();
			if (buffer != null)
				buffer.close();
			if (objectStream != null)
				objectStream.close();
			} catch (Exception e) { ObserverManager.notifyObserversOfError(e);}
		}

		return null;
	}
	
	
	
	/** Loads an object from the specified file, and returns the loaded (and uncasted) object.
	 * Throws an IllegalArgumentException if the file does not exist. Throws an IllegalStateException
	 * if the loaded object is not of the specified type.*/
	public static Object loadObject(File file){
		// Check if the file exists
		if (file == null)
			throw new IllegalArgumentException("Cannot load object from null file." );
		if (file.isDirectory() || !file.exists())
			throw new IllegalArgumentException("Cannot load object from file: '" + file.getAbsolutePath() + "': file does not exist or is a directory." );
		
		// Load the file
		FileInputStream fileStream = null;
		BufferedInputStream buffer = null;
		ObjectInputStream objectStream = null;
		
		try {
			fileStream = new FileInputStream(file);
			buffer = new BufferedInputStream(fileStream);
			objectStream = new ObjectInputStream(buffer);
			
			Object loadedObject = objectStream.readObject();
			return loadedObject;

		} catch (IOException | ClassNotFoundException e) {
			ObserverManager.notifyObserversOfError(e);  
			
		} finally { 
			try {
			if (fileStream != null)
				fileStream.close();
			if (buffer != null)
				buffer.close();
			if (objectStream != null)
				objectStream.close();
			} catch (Exception e) { ObserverManager.notifyObserversOfError(e);}
		}

		return null;
	}
}
