package staticManagers;

import java.io.File;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

import helper.Helper;
import start.Console;
import states.EncounterStates.T2DecisionTree;

/** Manages the saving to and loading from disk for the
 * temporary T2 Decision tree. I noticed that there substantial
 * lag when creating new files. Rather than having all T2Tree's
 * saving and loading themselves, this manager saves and load whole
 * ages at the same time*/
public class TreeOutputManager {

	/** Stores all T2DecisionTree's from one age. After calling writeAllTreesInBuffer,
	 * the TreeOutputManager writes all T2DecisionTrees to one file.*/
	private ConcurrentHashMap<String, T2DecisionTree> writingBuffer;
	private boolean busyWithWriting;

	/** Stores all T2DecisionTree's loaded for one age. After calling writeAllTreesInBuffer,
	 * the TreeOutputManager writes all T2DecisionTrees to one file.*/
	private ConcurrentHashMap<String, T2DecisionTree> readingBuffer;
	private boolean busyWithReading;
	
	/** Maps an age to the file where T2DecisionTree's for that age are stored*/
	private final HashMap<Integer, File> ageToFileMap;
	
	private final OutputFileManager outputFileManager;
	
	protected TreeOutputManager(OutputFileManager outputFileManager) {
		this.outputFileManager= outputFileManager;
		ageToFileMap = new HashMap<>();
		this.readingBuffer=new ConcurrentHashMap<>();
		this.writingBuffer=new ConcurrentHashMap<>();
		this.busyWithReading = false;
		this.busyWithWriting = false;
	}
	
	/** Places the T2DecisionTree in the to-be-written-to-file list.*/
	protected void submitTreeToWrite(T2DecisionTree tree) {
		this.writingBuffer.put(tree.name, tree);
	}
	
	/** Write all trees stores in the buffer under the specified age name. This function blocks
	 * if the OutputTreeManager is busy with either reading or writing, until it finished its previous job.
	 * This function should only be called by the model. 
	 * @throws InterruptedException */
	protected void writeAllTreesInBuffer(int age) throws InterruptedException {
		this.waitUntilNotBusy();
		Console.print("Writing all buffered T2DecisionTrees for age " + age + " to disk.");
System.err.println(Helper.timestamp()+"\tWriting all buffered T2DecisionTrees for age " + age + " to disk. Buffer size: " + this.writingBuffer.size());
		if (outputFileManager.model.performSafetyChecks)
			for (T2DecisionTree tree: writingBuffer.values())
				if (tree.root.getAge() != age)
					throw new IllegalStateException("Trying to write all trees for age " + age+ ". However, at least one tree has a root node with age " + tree.root.getAge());
		
		// Write the full writingBuffer to disk
		this.busyWithWriting = true;
		File resultingFile = ExternalFileManager.writeObjectToDisk(this.writingBuffer,  
				outputFileManager.temporaryT2DecisionTreeDirectory, 
				("TreesForAge" + age), 
				"att",
				outputFileManager.model.performSafetyChecks);

		// Store the file
		ageToFileMap.put(age, resultingFile);
		
		// Clear the writing buffer
		this.writingBuffer.clear();
		
		// And we are done...
		this.busyWithWriting = false;
		Console.print("Done writing all trees for age " + age);
		
	}

	private void waitUntilNotBusy() throws InterruptedException {
		while (this.busyWithReading || this.busyWithWriting) {
			Console.print("TreeOutputManager is currently busy. Trying again in a second...");
			Thread.sleep(1000);
		}
	}
	/** Get a tree with the specified name from the readingBuffer. Note that the OutputFileManager has to be told
	 * to load all files first.
	 * @return */
	protected T2DecisionTree getT2DecisionTree(String treeName) {
		T2DecisionTree result = this.readingBuffer.get(treeName);
		if (result == null)
			throw new IllegalStateException("Trying to read a tree with name '" + treeName + "' from the reading buffer, but no should tree exists.");
		return result;
	}

	
	/** Loads all Trees for this age to the buffer. Discards all previously loaded
	 * T2DecisionTree's. This function blocks if the OutputTreeManager is busy with 
	 * either reading or writing, until it finished its previous job.
	 * This function should only be called by the model. 
	 * @throws InterruptedException */
	@SuppressWarnings("unchecked")
	protected void loadAllTreesToBuffer(int age) throws InterruptedException {
		this.waitUntilNotBusy();
		Console.print("Reading all T2DecisionTrees for age " + age + " from disk.");

		// Get the file
		this.busyWithReading = true;
		File file = ageToFileMap.get(age);
		if (file == null)
			throw new IllegalStateException("Trying to read all trees of age " + age + " from the reading buffer. However, this age has not been written before.");
		
		// Read the file
		this.readingBuffer = (ConcurrentHashMap<String, T2DecisionTree>) ExternalFileManager.loadObject(file);
System.err.println(Helper.timestamp()+"\tReading all buffered T2DecisionTrees for age " + age + " to disk. Buffer size: " + this.readingBuffer.size());		
		// If necessary, check the results
		if (outputFileManager.model.performSafetyChecks)
			for (T2DecisionTree tree: readingBuffer.values())
				if (tree.root.getAge() != age)
					throw new IllegalStateException("Trying to read all trees for age " + age+ ". However, at least one tree has a root node with age " + tree.root.getAge());
	
		// And we are done
		this.busyWithReading = false;
		Console.print("Done reading all trees for age " + age);
	}


}
