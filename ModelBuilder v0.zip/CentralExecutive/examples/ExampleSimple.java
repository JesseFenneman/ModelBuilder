package examples;

import java.util.ArrayList;

import actionElements.ActionTemplate.ActionType;
import actionElements.ActionTemplateFactory;
import actionElements.ActionTemplatePostconditionChangeReference;
import actionElements.ActionTemplatePrecondition.Operator;
import actionElements.ActionTemplatePreconditionResourceValue;
import attributes.AttributeField;
import deathConditionElements.DeathConditionTemplate;
import decimalNumber.DecimalNumber;
import objectiveElements.AbstractObjectiveTemplateFactory;
import objectiveElements.CueLabel;
import objectiveElements.CueTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.ExtrinsicObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.PhenotypeSlotTemplateDelayedResource;
import objectiveElements.ResourceObjectTemplate;
import rIntegration.RFunction;
import rIntegration.RFunctionContainer;
import rIntegration.RManager;
import view.View;

/** Example 1; a rather weird model for testing purposes*/
public class ExampleSimple extends Example{

	public ExampleSimple() {
		this.fillWorkspace();
	}

	@Override
	public void fillWorkspace(){
		try{
			// Create all the distributions that we'll use in this example
			RFunction normal = null;
			RFunction uniform = null;
			RFunction bernoulli = null;
			RFunction highPass = null;
			for (RFunction rf: RManager.getAllRFunctionsWithTag("DOMAINFUNCTION"))
				if (rf.getName().equalsIgnoreCase("Normal distribution"))
					normal = rf;
				else if (rf.getName().equals("Uniform distribution"))
					uniform = rf;
				else if (rf.getName().equals("Bernoulli distribution"))
					bernoulli = rf;
				else if (rf.getName().equals("High pass uniform distribution"))
					highPass = rf;

			// Create the cue templates
			CueTemplate cue = new CueTemplate();
			cue.cueLabels = new ArrayList<>();
			cue.cueLabels.add( new CueLabel("label0", new RFunctionContainer(normal, new AttributeField[]{ new AttributeField("mean", new DecimalNumber( 0)), new AttributeField("sd", new DecimalNumber(.1))})));
			cue.cueLabels.add( new CueLabel("label3", new RFunctionContainer(normal, new AttributeField[]{ new AttributeField("mean", new DecimalNumber( 3)), new AttributeField("sd", new DecimalNumber(.1))})));
			cue.cueLabels.add( new CueLabel("label6", new RFunctionContainer(normal, new AttributeField[]{ new AttributeField("mean", new DecimalNumber( 6)), new AttributeField("sd", new DecimalNumber(.1))})));
			cue.maximumNumberOfCuesAnAgentCanSample = 1;

			// Set maximum life time
			View.getView().workspace.setMaximumLifeTime(10);

			// Maximum cycle time
			View.getView().workspace.setMaximumCycleTime(5);

			// PHENOTYPE
			AbstractObjectiveTemplateFactory factoryPHN = new AbstractObjectiveTemplateFactory();
			factoryPHN.setName("PHNTP")
			.setType(PhenotypeObjectTemplate.class)
			.setRange(new DecimalNumber(0), new DecimalNumber(10), new DecimalNumber(1));
			View.getView().addObject(factoryPHN.build());


			// RESOURCES: SS and LL
			AbstractObjectiveTemplateFactory factorySS = new AbstractObjectiveTemplateFactory();
			factorySS.setName("RSC")
			.setType(ResourceObjectTemplate.class)
			.setFrequency(new DecimalNumber(1))
			.setRange(new DecimalNumber(0), new DecimalNumber(6), new DecimalNumber(3))
			.setObservability(false)
			//.setCueTemplate(cue)
			.setSingleSamplingDistribution(new RFunctionContainer(uniform));
			View.getView().addObject(factorySS.build());


			// INTERRUPTION
			AbstractObjectiveTemplateFactory factoryINT = new AbstractObjectiveTemplateFactory();
			factoryINT.setName("INTRPT")
			.setType(InterruptionObjectTemplate.class)
			.setSingleSamplingDistribution(new RFunctionContainer(bernoulli, new AttributeField[] { new AttributeField("pr_x_equals_0", new DecimalNumber(0.9))}))
			.setObservability(false);
			View.getView().addObject(factoryINT.build());

			// DELAY
			AbstractObjectiveTemplateFactory factoryDLY = new AbstractObjectiveTemplateFactory();
			factoryDLY.setName("DLY")
			.setType(DelayObjectTemplate.class)
			.setRange(new DecimalNumber(1), new DecimalNumber(3), new DecimalNumber(1))
			.setObservability(true)
			.setFrequency(new DecimalNumber(1))
			.setSingleSamplingDistribution(new RFunctionContainer(uniform));
			View.getView().addObject(factoryDLY.build());

			// EXTRINSIC
			AbstractObjectiveTemplateFactory factoryEX = new AbstractObjectiveTemplateFactory();
			factoryEX.setName("XTRNSC")
			.setType(ExtrinsicObjectTemplate.class)
			.setRange(new DecimalNumber(-1), new DecimalNumber(1), new DecimalNumber(1))
			.setObservability(false)
			.setSingleSamplingDistribution(new RFunctionContainer(uniform))
			.setFrequency(new DecimalNumber(1));
			View.getView().addObject(factoryEX.build());

			// Update View
			View.getView().update();

			// Add a phenotype slot for a delayed resource
			View.getView().workspace.addPhenotypeSlot(new PhenotypeSlotTemplateDelayedResource("SlotDelayed", false));

			// Setup rules
			// Instantiate a the RSC instances rsc1 and rsc2 and delay dly
			{
				ActionTemplateFactory factory = new ActionTemplateFactory()
						.setActionType(ActionType.SETUP_ENCOUNTER)
						.setName("Initialize instances")
						.addPostconditionInstantiateObject("RSC", "rsc1")
						.addPostconditionInstantiateObject("RSC", "rsc2")
						.addPostconditionInstantiateObject("DLY", "dly");
				View.getView().workspace.addAction(factory.build());
			}

			// Create the instance references SS and LL
			{
				ActionTemplateFactory factory = new ActionTemplateFactory()
						.setActionType(ActionType.SETUP_ENCOUNTER)
						.setName("Initialize references")
						.addPostconditionCreateReference("rsc1", "ss")
						.addPostconditionCreateReference("rsc2", "ll");
				View.getView().workspace.addAction(factory.build());
			}

			// Create the instance reference 'intrpt'
			{
				ActionTemplateFactory factory = new ActionTemplateFactory()
						.setActionType(ActionType.SETUP_ENCOUNTER)
						.setName("Initialize interruption")
						.addPostconditionInstantiateObject("INTRPT", "interuptionInst");
				View.getView().workspace.addAction(factory.build());
			}
			// Reset SS and LL based on largest value
			{
				ActionTemplateFactory factory = new ActionTemplateFactory()
						.setActionType(ActionType.SETUP_ENCOUNTER)
						.setName("Allocate references")
						.addPrecondition(ActionTemplatePreconditionResourceValue.class, 
								View.getView().workspace.getInstance("rsc2"), 
								Operator.SMALLER_OR_EQUAL_THAN, 
								View.getView().workspace.getInstance("rsc1"))
						.addPostcondition(ActionTemplatePostconditionChangeReference.class, 
								View.getView().workspace.getInstanceAlias("SS"), 
								View.getView().workspace.getInstanceOrAlias("rsc2"))
						.addPostcondition(ActionTemplatePostconditionChangeReference.class, 
								View.getView().workspace.getInstanceAlias("LL"), 
								View.getView().workspace.getInstanceOrAlias("rsc1"));
				View.getView().workspace.addAction(factory.build());
			}



			// Mutations
			PhenotypeObjectTemplate p = (PhenotypeObjectTemplate) View.getView().workspace.getObject("PHNTP");
			ExtrinsicObjectTemplate e = (ExtrinsicObjectTemplate) View.getView().workspace.getObject("XTRNSC");

			DeathConditionTemplate deathTemplate = new DeathConditionTemplate((PhenotypeObjectTemplate) View.getView().workspace.getObject("PHNTP"), DeathConditionTemplate.Operator.SMALLER_OR_EQUAL_THAN, new DecimalNumber(0));
			View.getView().workspace.addDeathCondition(deathTemplate);


			RFunction fitnessFunction = null;
			for (RFunction rf: RManager.getAllRFunctionsWithTag("FITNESSFUNCTION"))
				if (rf.getName().equals("Linear after age 10"))
					fitnessFunction = rf;
			PhenotypeObjectTemplate age = (PhenotypeObjectTemplate) View.getView().workspace.getObject("Age");
			PhenotypeObjectTemplate[] args = new PhenotypeObjectTemplate[]{age, p};
			View.getView().workspace.setUseFitnessFunctionBeforeMaximumAge(true);
			View.getView().workspace.setFitnessFunction(fitnessFunction, args);
			View.getView().workspace.setFitnessDeath(new DecimalNumber(0));

			//View.getView().workspace.setFitnessFunction(fitnessFunction, args);


		} catch (Exception e) {e.printStackTrace();}

	}

}
