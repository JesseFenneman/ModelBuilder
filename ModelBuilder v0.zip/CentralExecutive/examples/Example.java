package examples;

public abstract class Example {

	/** Fills the View's workspace.*/
	public abstract void fillWorkspace();
}
