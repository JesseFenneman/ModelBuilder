package start;

import java.io.IOException;
import java.net.SocketException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import examples.ExampleSimple;
import helper.Helper;
import interfaces_abstractions.ObserverManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import rIntegration.RManager;
import view.View;

/** The console shows the user what the program is doing (for debug purposes),
 * and handles the bootup sequence*/
public class Console{
	public final boolean showLoggedWarnings = true;

	public Stage stage;
	public Scene scene;
	@FXML public TextArea textArea;




	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////////// 	Constructor and initialization 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	// Use a SingletonPattern
	private static Console instance;

	/** Start the Console if there is no Console yet. Does nothing if the Console is already started. */
	public static void startConsole(){
		if (instance == null){
			System.out.println(Helper.timestamp()+" \t Starting Console....");
			try {
				instance = new Console();
			} catch (IOException e) {}
		}

	}

	/**
	 * Start the Window.
	 * @throws IOException
	 */
	private Console () throws IOException
	{
		// Start the stage
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("console.fxml"));
		loader.setController(this);
		Parent root = (Parent) loader.load();

		scene = new Scene(root);
		stage = new Stage();
		stage.setTitle("Console");
		stage.setScene(scene);

		// If the main window stage closes, all opened substages should likewise close
		stage.setOnCloseRequest(e -> System.exit(0));
		stage.show();

		textArea.appendText("Starting bootup sequence....");
	}

	/** Starts all other parts of the program, including the
	 * RManager, and the View*/
	protected static void bootupSequence(CentralExecutive ce){

		// The connection to R can take some time, so we will do that on another thread,
		// as to not block the JAVAFX application thread. However, we do have to wait -
		// we can only start the View after RManager is done.
		// So, even waiting on another thread would block the JAVAFX thread. Not good.
		// Here is the solution: this function creates a new Thread, which creates a
		// Callable. The Callable starts R, and reports back to the Thread. The Thread
		// waits until the Callable returns, and then starts the View.
		new Thread(() -> {
			// Create the new thread for the Callable
			ExecutorService es  = Executors.newSingleThreadExecutor();

			// Create the callable
			Callable<Boolean> call = new Callable<Boolean>(){

				@Override
				public Boolean call() throws Exception {
					return RManager.establishConnectionToR();
				}
			};

			Future<Boolean> future = es.submit(call);

			while(!future.isDone()) {
				Console.print("(Console is waiting on R to start...)");
				try {	Thread.sleep(1000);} catch (InterruptedException e) {e.printStackTrace();}
			}

			// After this point the RManager has made a connection to R. 
			// That means that the coast is clear to start the View.
			// Of course, the View really wants to live on the JAVAFX thread
			Console.print("Connection to R established, time to load the View...");
			Platform.runLater(() -> View.startView(ce));

			try {	Thread.sleep(1500);} catch (InterruptedException e) {e.printStackTrace();}
			Platform.runLater(() -> new ExampleSimple());

		}).start();


	}


	/** This exception is thrown when trying to access the view, but the view has not been started yet.*/
	@SuppressWarnings("serial")
	public static class ViewNotStartedException extends RuntimeException { public ViewNotStartedException() {     super("Trying to access view, but the view has not yet been started!");  }}

	/** Returns the singleton View. The View has to be started by calling startView(). If View is not started, throws an ViewNotStartedException*/
	public static Console getConsole(){
		if (instance == null)
			throw new ViewNotStartedException();
		return instance;
	}


	/** Performs all steps necessary to safely shut down.*/
	public static void shutdownSequence(){
		Console.print(" RECEIVED SHUTDOWN REQUEST. Terminating program.");
		// Close the connection to RManager
		try {
			RManager.closeConnection();
		} catch (SocketException e) { ObserverManager.notifyObserversOfError(e);	}

		System.exit(0);
	}

	/** Print to the console. Automatically adds a timestamp.*/
	private void writeNormal(String s){
		String text = "\n"+Helper.timestamp() + "\t " + s;
		textArea.appendText(text);
		System.out.print(text);
	}

	/** Log a warning. Automatically adds a timestamp. Might not be shown. */
	private void warning(String s){
		if (!showLoggedWarnings)
			return ;

		String text = "\n"+Helper.timestamp() + "\t " + s;
		//textArea.appendText(text);
		System.out.print(text);
	}

	/** Print to the console. Automatically adds a timestamp.*/
	private void writeError(String s){
		textArea.appendText("\n\n\n");
		textArea.appendText(Helper.timestamp() + Helper.repString("-", 25) + " ERROR " + Helper.repString("-", 25) + "\n") ;
		textArea.appendText(s);
		System.err.println(Helper.timestamp() + " \t -"+s);
	}

	/** Print exception stacktrace to the console. Also stores a copy of the exception in the Exceptions folder*/
	private void writeException(Exception e){
		writeError(e.getLocalizedMessage());
		e.printStackTrace();
	}

	/** Returns a copy of all text printed on the console*/
	public String getCopy() {
		return textArea.getText();
	}

	/** Print to the console. Automatically adds a timestamp.*/
	public static synchronized void print(String s){
		Platform.runLater(() -> getConsole().writeNormal(s));
	}

	/** Log a warning. Used during algorithm runtime only.
	 * Depending on the console settings, this might not show up. Automatically adds a timestamp.*/
	public static synchronized void logWarning(String s){
		Platform.runLater(() -> getConsole().warning(s));
	}


	/** Print to the console. Automatically adds a timestamp.*/
	public static synchronized void printError(String s){
		Platform.runLater(() -> getConsole().writeError(s));
	}

	/** Print exception stacktrace to the console*/
	public static synchronized void print(Exception e){
		Platform.runLater(() -> getConsole().writeException(e));
	}

}
