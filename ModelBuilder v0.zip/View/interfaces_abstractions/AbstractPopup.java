package interfaces_abstractions;

import java.io.IOException;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import view.View;

/** A popup stage is a small stage that provides some functionality. This stage has a build-in toaster.
 * Note that you need to provide a .fxml file for the popup. This .fxml file has to have the following restrictions:
 * 1. The root pane (first pane) is an AnchorPane with the ID: rootPane
 * 2. If this popup should be closeable, a buttonClose has to be present. 
 */
public abstract class AbstractPopup  implements EventHandler<MouseEvent> {

	private double x,y; // The location on the frame's scrollPanel
	@FXML public AnchorPane rootPane; // The frame in the popup frame
	@FXML public Button buttonClose; //an optional close button 
	final boolean isCloseable;

	/**
	 * Create a popup at the given x,y location that has the layout specified in the fxmlName file. If requiresValidation is set to true,
	 * the popup cannot by the frame. If so, make sure that the close() function is called somewhere.
	 * @param fc
	 * @param fxmlName
	 * @param startX
	 * @param startY
	 * @param requiresValidation
	 */
	public AbstractPopup(String fxmlName, double startX, double startY, boolean isCloseable) {
		this.x = startX;
		this.y = startY;
		this.isCloseable=isCloseable;

		// Load the fxml file supplied
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource(fxmlName));
		loader.setController(this);
		try {
			loader.load();
		} catch (IOException e) {
			ObserverManager.notifyObserversOfError("Error creating popup stage", "Unable to start secondary stage. See details.", e);		}

		// Add the frame pane to the View's scrollPane
		View.getView().anchorPaneScrollPane.getChildren().add(rootPane);
		AnchorPane.setLeftAnchor(rootPane,x);
		AnchorPane.setTopAnchor(rootPane, y);

		// Set the mouse listener
		rootPane.setOnMouseClicked(this);
		rootPane.setOnMousePressed(this);
		rootPane.setOnMouseDragged(this);
		
		// Set the optional close button
		if (isCloseable)
			buttonClose.setOnMouseClicked(event -> {this.close();});
		
		// Register this popup at the View
		View.getView().registerPopup(this);
		
	}

	/**
	 * Create a popup that has the layout specified in the fxmlName file at the current mouse location If requiresValidation is set to true,
	 * the popup cannot be closed by the View. If so, make sure that the close() function is called somewhere.
	 * @param fc
	 * @param fxmlName
	 * @param startX
	 * @param startY
	 * @param requiresValidation
	 */
	public AbstractPopup(String fxmlName, MouseEvent e, boolean requiresValidation) {
		this( fxmlName, View.getView().sceneXtoPaneX(e.getSceneX()), View.getView().sceneYtoPaneY(e.getSceneY()), requiresValidation);
	}

	double startX;
	double xPressedOnScene;
	double startY;
	double yPressedOnScene;

	@Override
	public void handle(MouseEvent event) {
		// Set the ability to drag the frame

		// Record starting position
		if (event.getEventType() == MouseEvent.MOUSE_PRESSED &&  event.getButton() == MouseButton.PRIMARY) {
			startX			    = x;
			xPressedOnScene 	= event.getSceneX();
			startY			    = y;
			yPressedOnScene 	= event.getSceneY();
		}

		if (event.getEventType() == MouseEvent.MOUSE_DRAGGED){

			x = startX + (event.getSceneX()-xPressedOnScene);
			y = startY + (event.getSceneY()-yPressedOnScene);
			// Make sure that the pane never is outside of the scrollPane
			if (x > View.getView().anchorPaneScrollPane.getWidth() - this.rootPane.getWidth())
				x = View.getView().anchorPaneScrollPane.getWidth() - this.rootPane.getWidth();

			AnchorPane.setLeftAnchor(rootPane, x);
			AnchorPane.setTopAnchor(rootPane, y);
		}
	}

	/** Closes the popup */
	public void close() {
		View.getView().anchorPaneScrollPane.getChildren().remove(rootPane);
	}

	/** Initialise the nodes (handlers and such). Should not set values of nodes (this is done with update) */
	public abstract void setNodes();

	/** Update the nodes on the stage. Nodes should be initialized beforehand */
	public abstract void update();



}
