package interfaces_abstractions;

import java.util.Collections;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import decimalNumber.DecimalNumber;
import helper.Helper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.TextField;
/** <pre>
 * A node can have three types of layouts:
 * 
 * - Normal: 		when the node displays a value that is valid and has already been processed
 * - Changed:		when the node displays a value that is valid, but this change has not yet been processed
 * - Invalid:		when the node displays an invalid value. By definition, this value has not been processed, and will not be processed.
 *
 */
public abstract class LayoutManager {

	public enum State{
		Normal, Changed, Invalid;
	}


	/** 
	 * Set the layout of the TextField such that:
	 * 
	 * - it will have a normal layout when the TextField contains a valid value, and this
	 * 		value has already been processed (i.e., does not update);
	 * - it will have a 'changed' layout when the TextField contains a valid value, but 
	 * 		this value has not been passed on to other objects yet;
	 * - it will have a 'invalid' layout when the TextField does not contain a valid value.
	 * 
	 * What a valid value is, is determined by the TextFieldValidInput type. Note that layout
	 * changes only trigger when the text is changed AND the textfield is in focus.
	 */
	public static void setLayoutHandler(TextField tf, final FieldRestriction criterium) {
		// Set the listeners that govern the validity (and layout)
		tf.textProperty().addListener(new ChangeListener<String>(){	
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				//if (!tf.isFocused()) 
				//return;

				if (FieldRestriction.isValid(newValue, criterium))
					setChangedLayout(tf);
				else
					setInvalidLayout(tf);
			}
		});	

		// make the focus listener fire after enter has been pressed
		tf.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				tf.getParent().requestFocus();
			}
		});

		// Update whenever the focus is lost: make the layout invalid if the value is invalid
		tf.focusedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if (!newValue && !FieldRestriction.isValid(tf.getText(), criterium)) 
					setInvalidLayout(tf);

			}

		});

		// Test whether the starting value is correct. If not, mark the field as incorrect. If yes, mark it as normal (not as changed)
		if (!FieldRestriction.isValid(tf.getText(), criterium)) 
			setInvalidLayout(tf);
		else 
			setNormalLayout(tf);
	}

	/** Set the layout of the TextField such that:
	 * 
	 * - it will have a normal layout when the TextField contains a valid value, and this
	 * 		value has already been processed (i.e., does not update);
	 * - it will have a normal layout when the TextField does not contain any text
	 * - it will have a 'changed' layout when the TextField contains a valid value, but 
	 * 		this value has not been passed on to other objects yet;
	 * - it will have a 'invalid' layout when the TextField does not contain a valid value.
	 * 
	 * What a valid value is, is determined by the TextFieldValidInput type. Note that layout
	 * changes only trigger when the text is changed AND the textfield is in focus.
	 */
	public static void setLayoutHandlerAllowingEmpty(TextField tf, final FieldRestriction criterium) {
		// Set the listeners that govern the validity (and layout)
		tf.textProperty().addListener(new ChangeListener<String>(){	
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (!tf.isFocused()) 
					return;

				if (FieldRestriction.isValid(newValue, criterium) || tf.getText().length() == 0)
					setChangedLayout(tf);
				else
					setInvalidLayout(tf);
			}
		});	

		// make the focus listener fire after enter has been pressed
		tf.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				tf.getParent().requestFocus();
			}
		});

		// Update whenever the focus is lost: make the layout invalid if the value is invalid
		tf.focusedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if (!newValue && !FieldRestriction.isValid(tf.getText(), criterium) && tf.getText().length() > 0) 
					setInvalidLayout(tf);

			}

		});
	}




	/** Set the layout of the TextField such that:
	 * 
	 * - it will have a normal layout when the TextField contains an IN RANGE value, and this
	 * 		value has already been processed (i.e., does not update);
	 * - it will have a 'changed' layout when the TextField contains an IN RANGE value, but 
	 * 		this value has not been passed on to other objects yet;
	 * - it will have a 'invalid' layout when the TextField does not contain an IN RANGE value.
	 * 
	 * (A number is IN RANGE if and only if it has a value between [minimum,maximum])
	 */
	public static void setLayoutHandlerInRangeIntegerOnly(TextField tf, int minimum, int maximum) {
		// Set the listeners that govern the validity (and layout)
		tf.textProperty().addListener(new ChangeListener<String>(){	
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (!tf.isFocused())
					return;
				if (Helper.isInteger(newValue)){
					if (Integer.parseInt(newValue) >= minimum && Integer.parseInt(newValue) <= maximum )
						setChangedLayout(tf);
				}else
					setInvalidLayout(tf);
			}
		});	

		// make the focus listener fire after enter has been pressed
		tf.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				tf.getParent().requestFocus();
			}
		});
	}

	/** Set the layout of the TextField such that:
	 * 
	 * - it will have a normal layout when the TextField contains an IN RANGE value, and this
	 * 		value has already been processed (i.e., does not update);
	 * - it will have a 'changed' layout when the TextField contains an IN RANGE value, but 
	 * 		this value has not been passed on to other objects yet;
	 * - it will have a 'invalid' layout when the TextField does not contain an IN RANGE value.
	 * 
	 * (A number is IN RANGE if and only if it has a value between [minimum,maximum])
	 */
	public static void setLayoutHandlerInRange(TextField tf, double minimum, double maximum) {
		// Set the listeners that govern the validity (and layout)
		tf.textProperty().addListener(new ChangeListener<String>(){	
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (!tf.isFocused())
					return;
				if (Helper.isDouble(newValue)){
					if (Double.parseDouble(newValue) >= minimum && Double.parseDouble(newValue) <= maximum )
						setChangedLayout(tf);
				}else
					setInvalidLayout(tf);
			}
		});	

		// make the focus listener fire after enter has been pressed
		tf.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				tf.getParent().requestFocus();
			}
		});
	}


	/** Set the layout of the TextField such that:
	 * 
	 * - it will have a normal layout when the TextField contains an IN RANGE value, and this
	 * 		value has already been processed (i.e., does not update);
	 * - it will have a 'changed' layout when the TextField contains an IN RANGE value, but 
	 * 		this value has not been passed on to other objects yet;
	 * - it will have a 'invalid' layout when the TextField does not contain an IN RANGE value.
	 * 
	 * (A number is IN RANGE if and only if it has a value between [minimum,maximum])
	 */
	public static void setLayoutHandlerInRange(TextField tf, DecimalNumber minimum, DecimalNumber maximum) {
		// Set the listeners that govern the validity (and layout)
		tf.textProperty().addListener(new ChangeListener<String>(){	
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (!tf.isFocused())
					return;
				if (Helper.isDouble(newValue)){
					if (new DecimalNumber(newValue).largerThanOrEqualTo(minimum) && new DecimalNumber(newValue).smallerThanOrEqualTo(maximum))
						setChangedLayout(tf);
					else
						setInvalidLayout(tf);
				}else
					setInvalidLayout(tf);
			}
		});	

		// make the focus listener fire after enter has been pressed
		tf.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				tf.getParent().requestFocus();
			}
		});
	}
	/** Changes the layout of the node to normal.
	 * @param tf
	 * @param invalid
	 */
	private static void setNormalLayout(Node n) {
		n.getStyleClass().removeAll(Collections.singleton("invalid"));
		n.getStyleClass().removeAll(Collections.singleton("changed"));
	}

	/** 
	 * Set the layout of the node to invalid
	 * 
	 * @param n
	 * @param validInput
	 */
	private static void setInvalidLayout(Node n) {
		setNormalLayout(n);				// make sure no other states are present
		n.getStyleClass().add("invalid");
	}

	/** 
	 * Set the layout of the node to changed.
	 * 
	 * @param n
	 * @param validInput
	 */
	private static void setChangedLayout(Node n) {
		setNormalLayout(n);				// make sure no other states are present
		n.getStyleClass().add("changed");
	}

	/**
	 * After an event has been processed, the layout
	 * of the node should be set to normal. That is
	 * what this function does. Returns true if
	 * there was indeed an unprocessed change. Returns
	 * false if this function was called on a node
	 * that did not have an unprocessed value.
	 * @param n
	 * @return
	 */
	public static boolean setProcessed(Node n) {
		if (isChanged(n)) {
			setNormalLayout(n);
			return true;
		}
		return false;
	}

	/** Returns true if the Node has a 'invalid' layout 
	 * (i.e., the node contains an invalid value)
	 * @param tf
	 * @return
	 */
	public static boolean isInvalid (Node n) {
		return n.getStyleClass().contains("invalid");
	}

	/** Returns true if the Node has a 'changed' layout 
	 * (i.e., the node contains a value that is valid, but
	 * not yet processed)
	 * @param tf
	 * @return
	 */
	public static boolean isChanged (Node n) {
		return n.getStyleClass().contains("changed");
	}

	/** Returns true if the Node has a 'normal' layout 
	 * (i.e., the node contains a value that is valid and
	 * this valid has not been changed)
	 * @param tf
	 * @return
	 */
	public static boolean isNormal (Node n) {
		if (n.getStyleClass().contains("changed"))
			return false;
		if (n.getStyleClass().contains("invalid"))
			return false;
		return true;
	}

	/** 
	 * Returns one of three states:
	 * - Normal: 		when the node displays a value that is valid and has already been processed
	 * - Changed:		when the node displays a value that is valid, but this change has not yet been processed
	 * - Invalid:		when the node displays an invalid value. By definition, this value has not been processed, and will not be processed.
	 * @return
	 */
	public static State getState(Node n) {
		if (isInvalid(n))
			return State.Invalid;
		if (isChanged(n))
			return State.Changed;
		return State.Normal;
	}

	/** 
	 * Set the layout of the node to one of three states.
	 * - Normal: 		when the node displays a value that is valid and has already been processed
	 * - Changed:		when the node displays a value that is valid, but this change has not yet been processed
	 * - Invalid:		when the node displays an invalid value. By definition, this value has not been processed, and will not be processed.
	 * @param n
	 * @param s
	 */
	public static void setState(Node n, State s) {
		if (s == State.Normal)
			setNormalLayout(n);
		else if (s== State.Changed)
			setChangedLayout(n);
		else
			setInvalidLayout(n);
	}
}
