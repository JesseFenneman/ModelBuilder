package actionElements;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import objectiveElements.ResourceObjectTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionAtLeastOneResourcePresent implements ActionTemplatePrecondition, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	private ResourceObjectTemplate subject;
	private ResourceObjectTemplate[] possibleSubjects;
	private Operator operator;
	
	public ActionTemplatePreconditionAtLeastOneResourcePresent (){
		this.possibleSubjects = View.getView().workspace.getAllResourceObjects().toArray(new ResourceObjectTemplate[0]);
	}
	
	//// SUBJECT
	@Override
	public AbstractObjectiveTemplate getSubject() {
		return subject;
	}

	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) {
		if (!(newSubject instanceof ResourceObjectTemplate))
			throw new IllegalArgumentException("Illegal subject: cannot use a " + newSubject.getClass() + " in resource encountered precondition.");
		
		List<ResourceObjectTemplate> permissibleSubjects = View.getView().workspace.getAllResourceObjects();
		if (permissibleSubjects.contains(newSubject))
			this.subject = (ResourceObjectTemplate) newSubject;
		else 
			throw new IllegalArgumentException("Illegal subject: " + newSubject + " does not exist in view.");
		return this;
	}

	@Override
	public AbstractObjectiveTemplate[] getPossibleSubjects() {
		return possibleSubjects;
	}

	@Override
	public boolean subjectEquals (Object otherSubject){
		return this.subject == otherSubject;
	}
	
	
	//// OPERATOR
	@Override
	public Operator getOperator() {
		return operator;
	}
	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in resource encountered precondition.");
		return this;
	}
	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{Operator.TRUE, Operator.FALSE};
	}

	
	
	
	//// TARGET: NULL FOR RESOURCE ACCEPTED
	@Override
	public Object getTarget() {
		return null;
	}
	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		return this;
	}
	@Override
	public Object[] getPossibleTargets() {
		return null;
	}

	
	
	//// COMPLETE
	@Override
	public boolean isComplete() {
		return (subject != null && operator != null);
	}

	@Override
	public String toString(){
		if (operator == Operator.TRUE)
			return("A " + subject.getName().toLowerCase() + " is present in this encounter");
		return("A " + subject.getName().toLowerCase() + " is NOT present in this encounter");
	}
	@Override
	public String toSuperShortString() {
		if (operator == Operator.TRUE)
			return "Encountered " + subject.getName().toLowerCase();
		return "Not encountered " + subject.getName().toLowerCase();
	}

	public boolean containsInstanceReference(InstanceReference ref) {return false;}
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}
}
