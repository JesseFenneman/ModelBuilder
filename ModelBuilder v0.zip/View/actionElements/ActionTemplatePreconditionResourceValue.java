package actionElements;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.Instance;
import objectiveElements.InstanceAlias;
import objectiveElements.InstanceReference;
import objectiveElements.ResourceObjectTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionResourceValue  implements ActionTemplatePrecondition, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;

	private InstanceReference subject;
	private InstanceReference[] possibleSubjects;
	private Operator operator;
	private Object[] possibleTargets;
	private Object target;
	
	public ActionTemplatePreconditionResourceValue () { 
		this.possibleSubjects = View.getView().workspace.getAllResourceInstanceReferences().toArray(new InstanceReference[0]);
		}
	
	@Override
	public Object getSubject() {
		return subject;
	}

	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) {
		if (!(newSubject instanceof InstanceReference))
			throw new IllegalArgumentException("Illegal subject: cannot use a " + newSubject.getClass() + " as an instance pointer.");
		
		List<InstanceReference> permissibleSubjects = View.getView().workspace.getAllInstanceReferences();
		if (!permissibleSubjects.contains(newSubject))
			throw new IllegalArgumentException("Illegal subject: " + newSubject + " does not exist in view.");
		else
			this.subject = (InstanceReference) newSubject; 
			

		ArrayList<Object> possibleTargetsList = new ArrayList<>();
		
		if (subject instanceof Instance) {
			Instance instance = (Instance)subject;
			ResourceObjectTemplate res = (ResourceObjectTemplate) instance.getAbstractObjectiveTemplate();
			for (NumberObjectSingle dn: res.getDomain().toArray())
				possibleTargetsList.add(dn);
		}

		if (subject instanceof InstanceAlias) {
			InstanceAlias alias = (InstanceAlias)subject;
			ResourceObjectTemplate res = (ResourceObjectTemplate) alias.getInitialInstance().getAbstractObjectiveTemplate();
			for (NumberObjectSingle dn: res.getDomain().toArray())
				possibleTargetsList.add(dn);
		}
		
		// Add all other resources
		for (InstanceReference other : View.getView().workspace.getAllResourceInstanceReferences())
			if (other != newSubject)
				possibleTargetsList.add(other);
		this.possibleTargets = possibleTargetsList.toArray(new Object[0]);
		return this;
	}

	@Override
	public Object[] getPossibleSubjects() {
		return this.possibleSubjects;
	}

	@Override
	public Operator getOperator() {
		return operator;
	}

	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in resource encountered precondition.");
		return this;
	}

	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{Operator.EQUALS, Operator.DOES_NOT_EQUAL, Operator.SMALLER_THAN, Operator.SMALLER_OR_EQUAL_THAN, Operator.GREATER_OR_EQUAL_THAN, Operator.GREATER_THAN};		
	}

	@Override
	public Object getTarget() {
		return target;
	}

	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		if (possibleTargets == null)
			throw new IllegalStateException("Have to set a resource pointer subject before setting the target");
		
		if (!(newTarget instanceof NumberObjectSingle || newTarget instanceof InstanceReference))
			throw new IllegalArgumentException("Illegal target: cannot set a " + newTarget.getClass() + " as a resource target.");
		this.target = newTarget;
		return this;
	}

	@Override
	public Object[] getPossibleTargets() {
		return possibleTargets;
	}

	@Override
	public boolean subjectEquals(Object otherSubject) {
		return this.subject== otherSubject;
	}
	@Override
	public boolean isComplete() {
		return (subject != null && operator != null && target != null);
	}


	@Override
	public String toString(){
		if (target instanceof NumberObjectSingle)
			return ((InstanceReference)subject).getName() +  operator + " " + ((NumberObjectSingle)target).toStringWithoutTrailingZeros();
		else
			return ((InstanceReference)subject).getName() + operator + " '" + ((InstanceReference)target).getName() + "'";
	}

	@Override
	public String toSuperShortString() {
		if (target instanceof NumberObjectSingle)
			return ((InstanceReference)subject).getName() +operator+" "+((NumberObjectSingle)target).toStringWithoutTrailingZeros();
		else
			return ((InstanceReference)subject).getName() +operator+" "+((InstanceReference)target).getName();
	}

	public boolean containsInstanceReference(InstanceReference ref)  {
		if (subject == ref)
			return true;
		if (target == ref)
			return true;
		return false;
		}
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	
	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}
}
