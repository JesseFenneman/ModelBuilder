package actionElements;

import java.util.ArrayList;
import java.util.Arrays;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.AgeTemplate;
import objectiveElements.InstanceReference;
import objectiveElements.PhenotypeObjectTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionIncreasePhenotype  extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	
	public ActionTemplatePostconditionIncreasePhenotype () {
		this.possibleSubjects = View.getView().workspace.getAllPhenotypeObjectsExcludingAge().toArray(new PhenotypeObjectTemplate[0]);
	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		if (!(newSubject instanceof AbstractObjectiveTemplate))
			throw new IllegalArgumentException("Cannot use " + newSubject.getClass() + " as AbstractObjectiveTemplateOrCueTemplate");

		if (!(newSubject instanceof PhenotypeObjectTemplate))
			throw new IllegalArgumentException("An increase phenotype post condition cannot have a subject of type " + newSubject.getClass());

		if (newSubject instanceof AgeTemplate)
			throw new IllegalArgumentException("Cannot increase age via an action");

		this.subject = newSubject;
		this.possibleQualifiers = ((PhenotypeObjectTemplate) subject).getDomain().toArray();
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {
		if (!(newQualifier instanceof NumberObjectSingle))
			throw new IllegalArgumentException("An increase phenotype post condition increase with a value of " + newQualifier.getClass());
		if (possibleQualifiers == null)
			return this;
		if (!Arrays.asList(possibleQualifiers).contains(newQualifier))
			throw new IllegalArgumentException("Illegal qualifier: new qualifier is not listed in possible qualifiers");

		// Create an empty qualifier to store the match
		Object tempQualifier = null;

		// Find the matching qualifier
		for (NumberObjectSingle n : (NumberObjectSingle[]) possibleQualifiers)
			if (n.equals((NumberObjectSingle) newQualifier, true))
				tempQualifier = n;

		// If there wasn't one found: throw an exception
		if (tempQualifier  == null)
			throw new IllegalArgumentException("An increase phenotype post condition must have a value that is in the phenotype domain. "
					+ "Domain is: " + ((PhenotypeObjectTemplate) subject ).getDomain() +
					". New qualifier is: " + ((NumberObjectSingle) newQualifier).toStringWithoutTrailingZeros());

		// Set this qualifier
		this.qualifier = tempQualifier;
		return this;
	}

	@Override
	public boolean isComplete() {
		return (subject != null && qualifier != null);
	}

	@Override
	public String toString() { return "Increase " + ((AbstractObjectiveTemplate)subject).getName() + " with " + ((NumberObjectSingle)qualifier).toStringWithoutTrailingZeros();}

	@Override
	public String toSuperShortString() { return ((AbstractObjectiveTemplate)subject).getName()+" += " + ((NumberObjectSingle)qualifier).toStringWithoutTrailingZeros();}

	@Override
	public boolean containsInstanceReference(InstanceReference ip) {return false;}
	
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		return true;
	}

	
	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
	}

}