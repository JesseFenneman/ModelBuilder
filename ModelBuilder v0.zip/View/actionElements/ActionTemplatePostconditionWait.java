package actionElements;

import java.util.ArrayList;

import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import start.CentralExecutive;

public class ActionTemplatePostconditionWait extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	
	public ActionTemplatePostconditionWait () {}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) { return this;}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) { return this;}

	@Override
	public boolean isComplete() {
		return true;
	}

	@Override
	public String toString() { return "Wait 1 time step";}
	@Override
	public String toSuperShortString() { return "Wait";}

	@Override
	public boolean containsInstanceReference(InstanceReference ip){return false;}
	
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		return true;
	}
	
	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
	}
	
}