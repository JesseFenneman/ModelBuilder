package actionElements;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import objectiveElements.PhenotypeObjectTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionPhenotype implements ActionTemplatePrecondition, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	private PhenotypeObjectTemplate subject;
	private PhenotypeObjectTemplate[] possibleSubjects;
	private Operator operator;
	private NumberObjectSingle[] possibleTargets;
	private NumberObjectSingle target;
	
	public ActionTemplatePreconditionPhenotype (){	
		possibleSubjects = View.getView().workspace.getAllPhenotypeObjects().toArray(new PhenotypeObjectTemplate[0]);
	}
	
	
	
	//// SUBJECTS
	@Override
	public AbstractObjectiveTemplate getSubject() {
		return this.subject;
	}

	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) {
		if (!(newSubject instanceof PhenotypeObjectTemplate))
			throw new IllegalArgumentException("Illegal subject: cannot use a " + newSubject.getClass() + " in phenotype precondition.");
		
		List<PhenotypeObjectTemplate> permissibleSubjects = View.getView().workspace.getAllPhenotypeObjects();
		if (permissibleSubjects.contains(newSubject))
			this.subject = (PhenotypeObjectTemplate) newSubject;
		else 
			throw new IllegalArgumentException("Illegal subject: " + newSubject + " does not exist in view.");
		this.possibleTargets = subject.getDomain().toArray();
		return this;
	}

	@Override
	public AbstractObjectiveTemplate[] getPossibleSubjects() {
		return possibleSubjects;
	}

	@Override
	public boolean subjectEquals (Object otherSubject){
		return this.subject == otherSubject;
	}
	
	//// OPERATORS
	@Override
	public Operator getOperator() {
		return operator;
	}
	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in phenotype precondition.");
		return this;
	}
	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{Operator.EQUALS, Operator.DOES_NOT_EQUAL, Operator.SMALLER_THAN, Operator.SMALLER_OR_EQUAL_THAN, Operator.GREATER_OR_EQUAL_THAN, Operator.GREATER_THAN};		
	}



	//// TARGETS
	@Override
	public Object getTarget() {
		return target;
	}
	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		if (possibleTargets == null)
			throw new IllegalStateException("Have to set a phenotype subject before setting the target");
		
		if (!(newTarget instanceof NumberObjectSingle))
			throw new IllegalArgumentException("Illegal target: cannot set a " + newTarget.getClass() + " as a phenotype target.");
		
		List<NumberObjectSingle> permissibleValues = Arrays.asList(possibleTargets);
		if (permissibleValues.contains(newTarget))
			this.target = (NumberObjectSingle) newTarget;
		else
			throw new IllegalArgumentException("Illegal target:  " +  (NumberObjectSingle) newTarget + " is not a permissible target");
		return this;
		
	}
	@Override
	public Object[] getPossibleTargets() {
		return possibleTargets;
		
	}

	//// COMPLETE
	@Override
	public boolean isComplete() {
		return (subject != null && operator != null && target != null);
	}


	@Override
	public String toString(){
		return("The phenotypic dimension " + subject.getName().toLowerCase() + operator + " " + target.toStringWithoutTrailingZeros());
	}



	@Override
	public String toSuperShortString() {
		return subject.getName()+" "+operator+" "+target.toStringWithoutTrailingZeros();
	}

	public boolean containsInstanceReference(InstanceReference ref)  {return false;}
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	
	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}
}
