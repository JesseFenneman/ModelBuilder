package actionElements;

import java.util.ArrayList;

import actionElements.ActionTemplatePrecondition.Operator;
import helper.Helper;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceAlias;
import objectiveElements.InstanceReference;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionCreateReference  extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	
	public ActionTemplatePostconditionCreateReference () {
		this.possibleSubjects = View.getView().workspace.getAllInstanceReferences().toArray(new Object[0]);
	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		if (!(newSubject instanceof InstanceReference))
			throw new IllegalArgumentException("A create reference post condition cannot have a subject of type " + newSubject.getClass());
		this.subject = newSubject;
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {
		if (!(newQualifier instanceof String))
			throw new IllegalArgumentException("An instantiated object must have a String as a qualifier." + newQualifier.getClass());

		if (!Helper.isVariableName((String)newQualifier))
			throw new IllegalArgumentException("The name '" + newQualifier + "' is not a valid variable name.");

		// Set this qualifier
		this.qualifier = newQualifier;
		return this;
	}

	@Override
	public boolean isComplete() {return subject != null;}

	@Override
	public String toString() { return "Create reference with name '" + referenceAfterCreation.getName()+ "' to refer to '" + ((InstanceReference) subject).getName() + "'";}

	@Override
	public String toSuperShortString() { return referenceAfterCreation.getName() + "=" + ((InstanceReference) subject).getName();}

	protected InstanceReference referenceAfterCreation; 
	
	
	public void setReferenceAfterCreation(InstanceReference ref) {
		if (!(ref instanceof InstanceAlias))
			throw new IllegalArgumentException("Cannot use an Instance when creating an InstanceAlias");
		
		// Does the instance-pointed-at match the subject's class?
		if (ref.getClassType() == ((InstanceReference)subject).getClassType())
			referenceAfterCreation = ref;
		else
			throw new IllegalArgumentException("Postcondition mismatch. Tried to ask for a postcondition with subject '" + subject + "' but received '" + ref + "'");
	
	}
	public InstanceReference getReferenceAfterCreation() {
		return this.referenceAfterCreation;
	}

	@Override
	public boolean containsInstanceReference(InstanceReference ref) { return referenceAfterCreation == ref | this.subject==ref; }
	
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		ActionTemplatePreconditionSuccessfulInstantiation pre = new ActionTemplatePreconditionSuccessfulInstantiation ();
		pre.setSubject(this.subject);
		pre.setOperator(Operator.TRUE);
		preconditions.add(pre);
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();
		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : preconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;
					break;
				}
			if (!includedInPreconditions)
				return false;
		}
		return true;
	}


	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();

		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : existingPreconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;

					break;
				}
			if (!includedInPreconditions)
				existingPreconditions.add(np);
		}
	}

	
}