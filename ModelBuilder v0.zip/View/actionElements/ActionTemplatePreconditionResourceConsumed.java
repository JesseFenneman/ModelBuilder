package actionElements;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionResourceConsumed implements ActionTemplatePrecondition, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	private InstanceReference subject;
	private InstanceReference[] possibleSubjects;
	private Operator operator;
	
	public ActionTemplatePreconditionResourceConsumed (){
		this.possibleSubjects = View.getView().workspace.getAllResourceInstanceReferences().toArray(new InstanceReference[0]);
	}
	
	//// SUBJECT
	@Override
	public Object getSubject() {
		return subject;
	}

	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) {
		if (!(newSubject instanceof InstanceReference))
			throw new IllegalArgumentException("Illegal subject: cannot use a " + newSubject.getClass() + " as an instance pointer.");
		
		List<InstanceReference> permissibleSubjects = View.getView().workspace.getAllInstanceReferences();
		if (!permissibleSubjects.contains(newSubject))
			throw new IllegalArgumentException("Illegal subject: " + newSubject + " does not exist in view.");
		else
			this.subject = (InstanceReference) newSubject; 
		return this;
			

	}

	@Override
	public InstanceReference[] getPossibleSubjects() {
		return possibleSubjects;
	}

	@Override
	public boolean subjectEquals (Object otherSubject){
		return subject == otherSubject;
			
	}
	
	//// OPERATOR
	@Override
	public Operator getOperator() {
		return operator;
	}
	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in resource accepted precondition.");
		return this;
	}
	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{Operator.TRUE, Operator.FALSE};
	}

	
	
	
	//// TARGET: NULL FOR RESOURCE ACCEPTED
	@Override
	public Object getTarget() {
		return null;
	}
	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		return this;
	}
	@Override
	public Object[] getPossibleTargets() {
		return null;
	}

	
	
	//// COMPLETE
	@Override
	public boolean isComplete() {
		return (subject != null && operator != null);
	}
	
	@Override
	public String toString(){
		if (operator == Operator.TRUE)
			return("Has consumed " + subject.getName() );
		return("Has NOT consumed " + subject.getName() );
		}

	@Override
	public String toSuperShortString() {
		if (operator == Operator.TRUE)
			return "Consumed " + subject.getName();
		return "Not consumed " + subject.getName();
	}


	public boolean containsInstanceReference(InstanceReference ref) {return this.subject == ref;}
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}
}
