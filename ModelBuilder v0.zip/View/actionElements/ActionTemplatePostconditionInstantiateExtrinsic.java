package actionElements;

import java.util.ArrayList;

import helper.Helper;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.Instance;
import objectiveElements.InstanceReference;
import objectiveElements.PhenotypeObjectTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionInstantiateExtrinsic extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	

	public ActionTemplatePostconditionInstantiateExtrinsic () {
		ArrayList<AbstractObjectiveTemplate> possible = new ArrayList<>();
		possible.addAll(View.getView().workspace.getAllExtrinsicObjects());
		this.possibleSubjects = possible.toArray(new AbstractObjectiveTemplate[0]);
	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		if (!(newSubject instanceof AbstractObjectiveTemplate))
			throw new IllegalArgumentException("Cannot instantiate type " + newSubject.getClass());

		if (newSubject instanceof PhenotypeObjectTemplate)
			throw new IllegalArgumentException("Cannot instantiate phenotype type " + newSubject.getClass());

		this.subject = newSubject;
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {
		if (!(newQualifier instanceof String))
			throw new IllegalArgumentException("An instantiated extrinsic event must have a String as a qualifier." + newQualifier.getClass());

		if (!Helper.isVariableName(newQualifier.toString()))
			throw new IllegalArgumentException("The name '" + newQualifier + "' is not a valid variable name.");

		// Set this qualifier
		this.qualifier = newQualifier;
		return this;
	}
	@Override
	public boolean isComplete() {
		return true;
	}
	@Override
	public String toString() { return "Instantiate '" + this.referenceAfterCreation.getName() + "' (Class: " +((AbstractObjectiveTemplate)subject).getName() + ")";}

	@Override
	public String toSuperShortString()  { 
		return "Instantiate '" + this.referenceAfterCreation.getName() + "'";}

	protected InstanceReference referenceAfterCreation; 
	
	public void setReferenceAfterCreation(InstanceReference ref) {
		if (ref == null)
			throw new IllegalArgumentException("Cannot use an null InstanceReference when instantiating an Instance");
		if (!(ref instanceof Instance))
			throw new IllegalArgumentException("Cannot use an InstanceAlias when instantiating an Instance");
		// Does the instance-pointed-at match the subject's class?
		if (ref.getAbstractObjectiveTemplate() == this.subject)
			referenceAfterCreation = ref;
		else
			throw new IllegalArgumentException("Postcondition mismatch. Tried to ask for a postcondition with subject '" + ((AbstractObjectiveTemplate)subject).getName() + "' but received '" + ref + "'");

	}
	public InstanceReference getReferenceAfterCreation() {
		return this.referenceAfterCreation;
	}

	@Override
	public boolean containsInstanceReference(InstanceReference ref) {return this.referenceAfterCreation == ref;}
	
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		return true;
	}

	
	
	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
	}

}

