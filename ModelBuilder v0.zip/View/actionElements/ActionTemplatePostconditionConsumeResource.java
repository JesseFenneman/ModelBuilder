package actionElements;

import java.util.ArrayList;

import actionElements.ActionTemplatePrecondition.Operator;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionConsumeResource extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	
	public ActionTemplatePostconditionConsumeResource () {
		this.possibleSubjects = View.getView().workspace.getAllResourceInstanceReferences().toArray(new InstanceReference[0]);
		this.possibleQualifiers = View.getView().workspace.getAllPhenotypeObjectsExcludingAge().toArray(
				new PhenotypeObjectTemplate[0]);
	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		if (!(newSubject instanceof InstanceReference))
			throw new IllegalArgumentException("Cannot use " + newSubject.getClass() + " as AbstractObjectiveTemplateOrCueTemplate");

		InstanceReference ref = (InstanceReference) newSubject;
		
		if (!(ref.getAbstractObjectiveTemplate() instanceof ResourceObjectTemplate))
			throw new IllegalArgumentException("A consume resource post condition cannot have a subject of type " + newSubject.getClass());
		this.subject = newSubject;
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {
		if (!(newQualifier instanceof PhenotypeObjectTemplate))
			throw new IllegalArgumentException("A consume postcondition cannot add a resource value to " + newQualifier.getClass());
		if (possibleQualifiers == null)
			return this;
		this.qualifier = newQualifier;
		return this;
	}
	@Override
	public boolean isComplete() {
		return (subject != null );
	}
	@Override
	public String toString() { 
		if (qualifier != null)
			return "Consume " + ((InstanceReference)subject).getName() + " (affects: " + ((PhenotypeObjectTemplate)qualifier).getName() + ")";
		else 
			return "Consume " + ((InstanceReference)subject).getName() ;
	}
	@Override
	public String toSuperShortString() { 
		if (qualifier != null)
			return "Consume " + ((InstanceReference)subject).getName() + " (affects: " + ((PhenotypeObjectTemplate)qualifier).getName() + ")";
		else 
			return "Consume " + ((InstanceReference)subject).getName() ;}
	
	@Override
	public boolean containsInstanceReference(InstanceReference ref) {return subject == ref;}
	
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		ActionTemplatePreconditionSuccessfulInstantiation pre = new ActionTemplatePreconditionSuccessfulInstantiation ();
		pre.setSubject(this.subject);
		pre.setOperator(Operator.TRUE);
		preconditions.add(pre);
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();
		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : preconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;
					break;
				}
			if (!includedInPreconditions)
				return false;
		}
		return true;
	}

	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();
		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : existingPreconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;
					break;
				}
			if (!includedInPreconditions)
				existingPreconditions.add(np);
		}
	}
	
	
}