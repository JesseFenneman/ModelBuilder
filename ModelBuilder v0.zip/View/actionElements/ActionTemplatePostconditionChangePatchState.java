package actionElements;

public class ActionTemplatePostconditionChangePatchState extends ActionTemplatePostcondition{

}
