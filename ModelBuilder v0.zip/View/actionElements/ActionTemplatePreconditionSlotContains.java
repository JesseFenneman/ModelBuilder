package actionElements;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionSlotContains  implements ActionTemplatePrecondition, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;

	
	private AbstractPhenotypeSlotTemplate subject;
	private AbstractPhenotypeSlotTemplate[] possibleSubjects;
	private Operator operator;
	private InstanceReference[] possibleTargets;
	private InstanceReference target;
	
	public ActionTemplatePreconditionSlotContains (){
		this.possibleSubjects = View.getView().workspace.getAllPhenotypeSlots().toArray(new AbstractPhenotypeSlotTemplate[0]);
	}
	
	@Override
	public Object getSubject() {
		return subject;
	}

	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) {
		if (!(newSubject instanceof AbstractPhenotypeSlotTemplate))
			throw new IllegalArgumentException("Cannot use an object of type " + newSubject.getClass().getSimpleName() + " as a phenotype slot template as a subject.");
		
		AbstractPhenotypeSlotTemplate slot = (AbstractPhenotypeSlotTemplate) newSubject;

		if (!View.getView().workspace.getAllPhenotypeSlots().contains(slot))
			throw new IllegalArgumentException("Illegal subject: " + slot + " does not exist in view.");
		
		this.subject = slot;
		
		ArrayList<InstanceReference> permissibleReference = new ArrayList<>();
		for (InstanceReference ref : View.getView().workspace.getAllResourceInstanceReferences())
			if (slot.canUseAsResource(ref))
				permissibleReference.add(ref);
		this.possibleTargets=permissibleReference.toArray(new InstanceReference[0]);
			
		return this;
	}

	@Override
	public AbstractPhenotypeSlotTemplate[] getPossibleSubjects() {
		return this.possibleSubjects;
	}

	@Override
	public Operator getOperator() {
		return this.operator;
	}

	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in a slot contains precondition as an operator.");
		return this;
	}

	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{Operator.CONTAINS_SPECIFIC, Operator.DOES_NOT_CONTAIN};
	}

	@Override
	public InstanceReference getTarget() {
		return this.target;
	}

	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		if (!(newTarget instanceof InstanceReference))
			throw new IllegalArgumentException("Illegal operator: cannot use an object of class " + newTarget.getClass().getSimpleName() + " in a slot contains precondition as a target.");
		
		InstanceReference newRef = (InstanceReference) newTarget;
		
		if (!View.getView().workspace.getAllResourceInstanceReferences().contains(newTarget))
			throw new IllegalArgumentException("Illegal subject: " + newTarget + " does not exist in view.");
		
		 
		if (!Arrays.asList(possibleTargets).contains(newRef))
			throw new IllegalArgumentException("Illegal target:  " +  (NumberObjectSingle) newTarget + " is not a permissible target");
		
		this.target=newRef;
		
		return this;
	}

	@Override
	public Object[] getPossibleTargets() {
		return this.possibleTargets;
	}

	@Override
	public boolean containsInstanceReference(InstanceReference ref) {
		return (this.target==ref);
	}

	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {
		return this.subject == slot;
	}

	@Override
	public boolean subjectEquals(Object otherSubject) {
		return this.subject == otherSubject;
	}

	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}

	@Override
	public boolean isComplete() {
		if (subject == null)
			return false;
		if (operator == null)
			return false;
		if (target == null)
			return false;
		return true;
	}

	@Override 
	public String toString() {
		if (operator == Operator.CONTAINS_SPECIFIC)
			return("Slot '" + subject.getName() + "' contains resource '" + target.getName() + "'");
		if (operator == Operator.DOES_NOT_CONTAIN)
			return("Slot '" + subject.getName() + "' does not contains resource '" + target.getName() + "'");
		throw new IllegalStateException("Illegal operator: " + operator);
	}
	@Override
	public String toSuperShortString() {
		if (operator == Operator.CONTAINS_SPECIFIC)
			return("No '"+  target.getName() +  "' in '" + subject.getName() + "'");
		if (operator == Operator.DOES_NOT_CONTAIN)
			return("'"+  target.getName() +  "' in '" + subject.getName() + "'");
		throw new IllegalStateException("Illegal operator: " + operator);
	}
}