package actionElements;

import java.util.ArrayList;

import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.PhenotypeSlotTemplateCaptiveResource;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionUseCaptiveSlot extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;

	public ActionTemplatePostconditionUseCaptiveSlot () {
		ArrayList<AbstractPhenotypeSlotTemplate> captiveSlots = new ArrayList<>();
		for (AbstractPhenotypeSlotTemplate s: View.getView().workspace.getAllPhenotypeSlots())
			if (s instanceof PhenotypeSlotTemplateCaptiveResource)
				captiveSlots.add(s);
		
		this.possibleSubjects = captiveSlots.toArray(new AbstractPhenotypeSlotTemplate[0]);
	}

	@Override
	public boolean containsInstanceReference(InstanceReference ref) {
		return false;
	}

	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {
		return (subject==slot);
	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		if (!(newSubject instanceof AbstractPhenotypeSlotTemplate))
			throw new IllegalArgumentException("Cannot use " + newSubject.getClass() + " as a slot subject");

		this.subject = newSubject;
		AbstractPhenotypeSlotTemplate slot = (AbstractPhenotypeSlotTemplate)subject;

		ArrayList<PhenotypeObjectTemplate> list = new ArrayList<>();
		for (PhenotypeObjectTemplate p : View.getView().workspace.getAllPhenotypeObjects())
			if (slot.canUsePhenotype(p))
				list.add(p);

		this.possibleQualifiers = list.toArray( new PhenotypeObjectTemplate[0]);
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {
		if (!(newQualifier instanceof PhenotypeObjectTemplate))
			throw new IllegalArgumentException("Cannot use " + newQualifier.getClass() + " as a phenotypic dimension qualifier");

		AbstractPhenotypeSlotTemplate slot = (AbstractPhenotypeSlotTemplate)subject;
		PhenotypeObjectTemplate phen = (PhenotypeObjectTemplate) newQualifier;

		if (!slot.canUsePhenotype(phen))
			throw new IllegalArgumentException("Cannot use " + phen.getName() + " as a phenotypic dimension qualifier in a " + slot.getName() + " slot type.");

		this.qualifier=phen;
		return this;
	}

	@Override
	public boolean isComplete() {
		return (subject != null && qualifier != null);
	}

	@Override
	public String toSuperShortString() {
		AbstractPhenotypeSlotTemplate slot = (AbstractPhenotypeSlotTemplate)subject;
		PhenotypeObjectTemplate phen = (PhenotypeObjectTemplate) qualifier;


		return "Use resource in '" + slot.getName()+ "', affecting " + phen.getName();
	}

	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		return true;
	}

	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
	}

}
