package actionElements;

import java.util.ArrayList;

import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionEmptySlot extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public ActionTemplatePostconditionEmptySlot () {
		this.possibleSubjects = View.getView().workspace.getAllPhenotypeSlots().toArray(new Object[0]);
	}
	@Override
	public boolean containsInstanceReference(InstanceReference ref) {
		return false;
	}

	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {
		return subject == slot;
	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		if (!(newSubject instanceof AbstractPhenotypeSlotTemplate))
			throw new IllegalArgumentException("Cannot use " + newSubject.getClass() + " as a slot subject");

		this.subject = newSubject;
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {
		return this;
	}

	@Override
	public boolean isComplete() {
		return (subject != null);
	}
	
	@Override
	public String toString() {
		return "Empty '" + ((AbstractPhenotypeSlotTemplate)subject).getName() + "'";
	}


	@Override
	public String toSuperShortString() {
		return "Empty '" + ((AbstractPhenotypeSlotTemplate)subject).getName() + "'";
	}

	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		return true;
	}

	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
	}

}
