package actionElements;

import java.util.ArrayList;

import helper.Helper;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import start.CentralExecutive;

public class ActionTemplatePostconditionSetGameMode  extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	
	public ActionTemplatePostconditionSetGameMode () {}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {
		if (!(newQualifier instanceof String))
			throw new IllegalArgumentException("An game mode must have a String as a qualifier." + newQualifier.getClass());

		if (!Helper.isVariableName((String)newQualifier))
			throw new IllegalArgumentException("The name '" + newQualifier + "' is not a valid variable name.");

		// Set this qualifier
		this.qualifier = newQualifier;
		return this;
	}

	@Override
	public boolean isComplete() {
		return  ( qualifier != null);
	}

	@Override
	public String toString() { return "Set game mode to " + (String) qualifier;}

	@Override
	public String toSuperShortString() { return "Game mode = " + (String) qualifier;}

	@Override
	public boolean containsInstanceReference(InstanceReference ref) {return false;}
	
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	protected String stringAfterCreation; 
	public void setStringAfterCreation(String str) {				qualifier = str; }

	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		return true;
	}

	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
	}
	
}