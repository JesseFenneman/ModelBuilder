package actionElements;

import java.io.Serializable;
import java.util.ArrayList;

import actionElements.ActionTemplatePrecondition.Operator;
import interfaces_abstractions.ObserverManager;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.CueTemplate;
import objectiveElements.InstanceReference;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.PhenotypeSlotTemplateCaptiveResource;
import objectiveElements.PhenotypeSlotTemplateDelayedResource;
import objectiveElements.PhenotypeSlotTemplateRecurringResource;
import start.CentralExecutive;
import view.View;

/** Represents the template for the action that an agent can take in the model. 
 * An action contains 0 or more ActionTemplatePreconditions, which much be true
 * before an action can be done. 
 * 
 * An action usually has exactly 1 postcondition, which represents its consequences.
 * For instance, an action cannot result in both sampling and waiting (as waiting here means
 * doing nothing - and it's just impossible to do nothing and sampling)
 * However, there are two exceptions.
 * 
 *  First, there might be any number of set, decrease, and increase phenotype postconditions, 
 *  even in conjunction with at most one other postcondition. For instance, sampling might 
 *  have a cost (i.e., decrease the phenotype). Similarly, changing two or more phenotypic 
 *  states is allowed (e.g., trading energy to give birth). 
 *  
 *  Second, during an encounter, the postconditions 'terminate' and 'interrupt' can always be added.
 * */
public class ActionTemplate implements Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;

	/** This exception is thrown when an incomplete precondition or postcondition is added*/
	@SuppressWarnings("serial")
	public static class IncompleteConditionException extends RuntimeException { public IncompleteConditionException (String message) {     super(message);  }}
	
	/** What type of action - an action that can be performed between encounters, during encounters, or both? */
	public enum ActionType {BETWEEN_ENCOUNTERS, DURING_ENCOUNTER, SETUP_ENCOUNTER, MUTATION}
	
	private String name;
	private final ActionType actionType;
	private final ArrayList<ActionTemplatePrecondition> preconditions;
	private final ArrayList<ActionTemplatePostcondition> postconditions;
	
	/** Create an ActionTemplate that has no preconditions or postconditions yet. The name should be longer than 0 characters, and
	 * contain only numbers, letters, and whitespace. There cannot be any existing actions  with the same name yet. Throws
	 * an IllegalArgumentException if the name does not adhere to these requirements.
	 * The ActionType signals whether an agent can use this action between or during encounters.*/
	public ActionTemplate (ActionType type, String name){
		if (!View.getView().workspace.isActionNamePermissible(name))
			throw new IllegalArgumentException("Cannot instantiate ActionTemplate: invalid name.");
		this.name = name;
		this.actionType = type;
		this.preconditions = new ArrayList<>();
		this.postconditions = new ArrayList<>();
	}
	
	/** Get the name of the action*/
	public String getName () {return this.name;}
	
	/** Set the name of the action. Provides a warning toast (and does not set the name) if the 
	 * name is not permissible. Permissible names are unique (there is no other 
	 * action template with that name, capitalisation ignored) and consists of
	 * only numbers, letters, and whitespace.*/
	public void setName(String newName){
		if (View.getView().workspace.isActionNamePermissible(newName))
			this.name = newName;
		ObserverManager.makeWarningToast("Cannot set action name: name already exists or contains illegal characters.");
	}
	
	public ActionType getType() { return this.actionType;}
	
	/** Adds a precondition of the specified class, that has the specified subject, operator, and target
	 * (note: each action can have any number of preconditions).
	 * Throws an IllegalArgumentException if the precondition type does not match the type of the actionTemplate 
	 * (that is, if the precondition is allowed only during encounters, and this actionTemplate represents a 
	 * between encounter action, an IllegalArgumentException is thrown).
	 * Throws an IncompleteConditionException if the precondition is not fully specified (i.e., requires but misses a 
	 * subject, operator, or target).
	 * Returns the newly created Preconditon.*/
	public ActionTemplatePrecondition  addPrecondition(
			Class<? extends ActionTemplatePrecondition> clazz, 
			Object subject,
			Operator operator,
			Object target){
	
		// Check if the class matches the action type - that is, that we are not using preconditions that 
		// are not allowed 
		// First, if this action is to be between encounters, make sure tha the precondition can be used between encounters
		if (actionType == ActionType.BETWEEN_ENCOUNTERS)
			if (!ActionTemplatePrecondition.canUseBetweenEncounters(clazz))
				throw new IllegalArgumentException("Trying to add a precondition for an action that can be performed between encounters. However, the precondition class cannot be used between encounters");
		if (actionType == ActionType.DURING_ENCOUNTER)
			if (!ActionTemplatePrecondition.canUseDuringEncounters(clazz))
				throw new IllegalArgumentException("Trying to add a precondition for an action that can be performed during an encounter. However, the precondition class cannot be used during an encounter");
		
		// Create a new PreconditionTemplate based on the specified class
		ActionTemplatePrecondition newPrecondition = ActionTemplatePrecondition.createPreconditionTemplate(clazz);
		
		// Populate this precondition with the specified subject, operator, and target
		if (subject != null)
			newPrecondition.setSubject(subject);
		if (operator != null)
			newPrecondition.setOperator(operator);
		if (target != null)
			newPrecondition.setTarget(target);
		
		// Check if the precondition is complete
		if (newPrecondition.isComplete())
			preconditions.add(newPrecondition);
		else
			throw new IncompleteConditionException ("Trying to instantiate an incomplete precondition");
		
		return newPrecondition;
	}
	
	/** Adds a precondition of the specified class, that has a specified subject and operator, but no target
	 * (note: each action can have any number of preconditions).
	 * Throws an IllegalArgumentException if the precondition type does not match the type of the actionTemplate 
	 * (that is, if the precondition is allowed only during encounters, and this actionTemplate represents a 
	 * between encounter action, an IllegalArgumentException is thrown).
	 * Throws an IncompleteConditionException if the precondition is not fully specified (i.e., requires but misses a 
	 * subject, operator, or target).
	 * Returns the newly created Precondition.*/
	public ActionTemplatePrecondition  addPrecondition(
			Class<? extends ActionTemplatePrecondition> clazz, 
			AbstractObjectiveTemplate subject,
			Operator operator){
		return addPrecondition( clazz, subject, operator, null);
	}
	 
	
	/** Adds a precondition of the specified class, that has a specified operator and target, but no subject
	 * (note: each action can have any number of preconditions).
	 * 
	 * Throws an IllegalArgumentException if the precondition type does not match the type of the actionTemplate 
	 * (that is, if the precondition is allowed only during encounters, and this actionTemplate represents a 
	 * between encounter action, an IllegalArgumentException is thrown).
	 * Throws an IncompleteConditionException if the precondition is not fully specified (i.e., requires but misses a 
	 * subject, operator, or target).
	 * Returns the newly created Preconditon.*/
	public ActionTemplatePrecondition addPrecondition(
			Class<? extends ActionTemplatePrecondition> clazz,
			Operator operator,
			Object target){
		return addPrecondition( clazz, null, operator, target);
	}
	
	/** Create and add a precondition with the same values as the supplied precondition*/
	public ActionTemplatePrecondition addPrecondition(ActionTemplatePrecondition precondition){
		return addPrecondition(precondition.getClass(), precondition.getSubject(), precondition.getOperator(), precondition.getTarget());
	}
	
	/** Returns a shallow clone of the array list containing all preconditions.*/
	@SuppressWarnings("unchecked")
	public ArrayList<ActionTemplatePrecondition> getAllPreconditions(){
		return (ArrayList<ActionTemplatePrecondition>) this.preconditions.clone();
	}
	
	/** Removes all preconditions from this template*/
	public void removeAllActionTemplatePreconditions (){
		this.preconditions.removeAll(this.preconditions);
	}
	
	/** Removes the precondition from this template*/
	public void removeActionTemplatePrecondition (ActionTemplatePrecondition precondition){
		this.preconditions.remove(precondition);
	}
	
	/**Add the postcondition to this action. Returns the new postcondition. */
	public ActionTemplatePostcondition addPostcondition (
			Class<? extends ActionTemplatePostcondition> clazz,
			Object subject,
			Object qualifier,
			InstanceReference optionalReference,
			PhenotypeObjectTemplate optionalAffectedPhenotype,
			InstanceReference optionalDelay,
			InstanceReference optionalInterruption,
			int optionalPeriodicity
			
			){

		// Check if the class matches the action type - that is, that we are not using a postcondition that 
		// is not allowed 
		if (actionType == ActionType.BETWEEN_ENCOUNTERS)
			if (!ActionTemplatePostcondition.canUseBetweenEncounters(clazz))
				throw new IllegalArgumentException("Trying to set a postcondition for an action that can be performed between encounters. However, the postcondition class cannot be used between encounters");
		if (actionType == ActionType.DURING_ENCOUNTER)
			if (!ActionTemplatePostcondition.canUseDuringEncounters(clazz))
				throw new IllegalArgumentException("Trying to set a postcondition for an action that can be performed during an encounter. However, the postcondition class cannot be used during an encounter");
		if (actionType == ActionType.SETUP_ENCOUNTER)
			if (!ActionTemplatePostcondition.canUseWhenSettingUpEncounter(clazz))
				throw new IllegalArgumentException("Trying to set a postcondition for an action that can be performed during encounter setup. However, the postcondition class cannot be during setup");

		// Create a new PreconditionTemplate based on the specified class
		ActionTemplatePostcondition newPostcondition = ActionTemplatePostcondition.createPostconditionTemplate(clazz);

		// Populate this postcondition with the specified subject and qualifier
		if (subject != null)
			newPostcondition.setSubject(subject);
		
		if (qualifier != null)
			newPostcondition.setQualifier(qualifier);

		if (newPostcondition instanceof ActionTemplatePostconditionInstantiateObject)
			((ActionTemplatePostconditionInstantiateObject)newPostcondition).setReferenceAfterCreation( optionalReference);
		
		if (newPostcondition instanceof ActionTemplatePostconditionInstantiateExtrinsic)
			((ActionTemplatePostconditionInstantiateExtrinsic)newPostcondition).setReferenceAfterCreation( optionalReference);
		
		if (newPostcondition instanceof ActionTemplatePostconditionCreateReference)
			((ActionTemplatePostconditionCreateReference)newPostcondition).setReferenceAfterCreation( optionalReference);
		
		if (newPostcondition instanceof ActionTemplatePostconditionStore) {
			ActionTemplatePostconditionStore storePC = (ActionTemplatePostconditionStore) newPostcondition;
			if (newPostcondition.subject instanceof PhenotypeSlotTemplateCaptiveResource) {
				storePC.setAffectedPhenotypicDimensions(optionalAffectedPhenotype);
			}
			
			else if  (newPostcondition.subject instanceof PhenotypeSlotTemplateDelayedResource) {
				storePC.setAffectedPhenotypicDimensions(optionalAffectedPhenotype);
				storePC.setDelay(optionalDelay);
				storePC.setInterruption(optionalInterruption);
			}
			
			else if  (newPostcondition.subject instanceof PhenotypeSlotTemplateRecurringResource) {
				storePC.setAffectedPhenotypicDimensions(optionalAffectedPhenotype);
				storePC.setInterruption(optionalInterruption);
				storePC.setPeriodicity(optionalPeriodicity);
			}
			
			else throw new IllegalStateException("Unknown slot type: " + newPostcondition.subject.getClass().getSimpleName());
			
		}
		// Check completeness 
		if (!newPostcondition.isComplete())
			throw new IncompleteConditionException ("Trying to instantiate an incomplete postcondition");

		// Add the postcondition
		postconditions.add(newPostcondition);

		
		return newPostcondition;
	}
	
	
	
	/** Add the postcondition. .*/
	public ActionTemplatePostcondition addPostcondition (
			Class<? extends ActionTemplatePostcondition> clazz,
			AbstractObjectiveTemplate subject,
			InstanceReference ref){ // Optional for PostconditionTemplateInstantiateObject
		return addPostcondition(clazz, subject, null, ref, null, null, null, -1);
	}
	
	/** Add the postcondition. Returns the new postcondition. */
	public ActionTemplatePostcondition addPostcondition (
			Class<? extends ActionTemplatePostcondition> clazz,
			Object qualifier){
		return addPostcondition(clazz, null, qualifier, null, null, null, null, -1);
	}
	
	/**Add the postcondition. Returns the new postcondition. */
	public ActionTemplatePostcondition addPostcondition (
			Class<? extends ActionTemplatePostcondition> clazz){
		return addPostcondition(clazz, null, null);
	}
	
	/** Create and set a postcondition with the same values as the supplied postcondition*/
	public ActionTemplatePostcondition addPostcondition(ActionTemplatePostcondition postcondition){
		
		if (postcondition instanceof ActionTemplatePostconditionInstantiateObject)
			return addPostcondition(postcondition.getClass(), postcondition.subject, postcondition.qualifier, ((ActionTemplatePostconditionInstantiateObject)postcondition).getReferenceAfterCreation(), null, null, null, -1);
		
		if (postcondition instanceof ActionTemplatePostconditionInstantiateExtrinsic)
			return addPostcondition(postcondition.getClass(), postcondition.subject, postcondition.qualifier, ((ActionTemplatePostconditionInstantiateExtrinsic)postcondition).getReferenceAfterCreation(), null, null, null, -1);
		
		
		if (postcondition instanceof ActionTemplatePostconditionCreateReference)
			return addPostcondition(postcondition.getClass(), postcondition.subject, postcondition.qualifier, ((ActionTemplatePostconditionCreateReference)postcondition).getReferenceAfterCreation(), null, null, null, -1);
		
		if (postcondition instanceof ActionTemplatePostconditionStore)
			return addPostcondition(
					postcondition.getClass(), 
					postcondition.subject, 
					postcondition.qualifier, 
					null, 
					((ActionTemplatePostconditionStore)postcondition).getAffectedPhenotype(), 
					((ActionTemplatePostconditionStore)postcondition).getSelectedDelay(), 
					((ActionTemplatePostconditionStore)postcondition).getSelectedInterruption(), 
					((ActionTemplatePostconditionStore)postcondition).getSelectedPeriodicity()); 
		
		return addPostcondition(postcondition.getClass(), postcondition.subject, postcondition.qualifier,null, null, null, null, -1);
	}
	
	/** Returns the postconditions. Can be null if not set yet. Usually this is a list
	 * of size 1. However, there can be multiple increase, decrease, and set phenotype postconditions*/
	public ArrayList<ActionTemplatePostcondition> getPostconditions () {return this.postconditions;}
	
	
	/** Removes all postconditions from this template*/
	public void removeAllActionTemplatePostconditions() {
		this.postconditions.removeAll(this.postconditions);
	}
	
	/** Checks completeness. An ActionTemplate is complete if it has a non-null postcondition, this postcondition is complete,
	 * and all preconditions are complete.*/
	public boolean isComplete(){
		if (postconditions.size()== 0)
			return false;
		for (ActionTemplatePostcondition post: postconditions)
			if (!post.isComplete())
				return false;
		for (ActionTemplatePrecondition pre : preconditions)
			if (!pre.isComplete())
				return false;
		return true;
	}
	
	/** Returns true if at least one precondition or postcondition of this action contains the object*/
	public boolean containsObjectTemplate(AbstractObjectiveTemplate object){
		for (ActionTemplatePrecondition pre : this.preconditions)
			if (pre.subjectEquals(object))
				return true;
		for (ActionTemplatePostcondition post : this.postconditions)
			if (post.subjectEquals(object))
				return true;
		return false;
	}
	
	/** Returns true if at least one precondition or postcondition of this actions contains the specified phenotype slot*/
	public boolean containsPhenotypeSlotTemplate (AbstractPhenotypeSlotTemplate slot) {
		for (ActionTemplatePrecondition pre : this.preconditions)
			if (pre.containsPhenotypeSlot(slot))
				return true;
		for (ActionTemplatePostcondition post : this.postconditions)
			if (post.containsPhenotypeSlot(slot))
				return true;
		return false;
	}
	
	/** Returns true if at least one postcondition of this action contains the CueTemplate*/
	public boolean containsCueTemplate(CueTemplate cue){
		for (ActionTemplatePostcondition post : this.postconditions)
			if (post.subjectEquals(cue))
				return true;
		return false;
	}
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("'"+ name + "' ||  (");
		if (preconditions.size()==0)
			sb.append("always");
		for (int i = 0; i < preconditions.size(); i++){
			sb.append(preconditions.get(i).toSuperShortString());
			if (preconditions.size()>1 && i < preconditions.size()-1)
				sb.append(" & ");
		}
		sb.append(")  ->  ");
		if (postconditions.size() == 1)
			sb.append(postconditions.get(0).toSuperShortString());
		else {
			sb.append("(");
			for (int i = 0; i < postconditions.size(); i++){
				sb.append(postconditions.get(i).toSuperShortString());
				if (postconditions.size()>1 && i < postconditions.size()-1)
					sb.append(" & ");
			}
			sb.append(")");
		}
		return sb.toString();
	}
	
	/** Returns true if at least one post or precondition contains a reference to the InstanceReference*/
	public boolean containsInstanceReference(InstanceReference ref) {
		for (ActionTemplatePrecondition pre : this.preconditions)
			if (pre.containsInstanceReference(ref))
				return true;
		for (ActionTemplatePostcondition post: this.postconditions)
			if (post.containsInstanceReference(ref))
				return true;
		return false;
		}

	/** Some postconditions have necessary preconditions. This function checks whether there are any
	 * postconditions that are necessary in the list of postconditions.*/
	public boolean containsAtLeastOnePostconditionWithNecessaryPreconditions() {
		for (ActionTemplatePostcondition post: this.postconditions)
			if (ActionTemplatePostcondition.hasNecessaryPrecondition(post.getClass()))
				return true;
		return false;	
	}
	
	/** Are there the required preconditions for all postconditions that have necessary preconditions? */
	public boolean necessaryPreconditionsPresent() {
		for (ActionTemplatePostcondition post: this.postconditions)
			if (!post.necessaryPreconditionsPresentIn(preconditions))
				return false;
		return true;
	}
	
}
