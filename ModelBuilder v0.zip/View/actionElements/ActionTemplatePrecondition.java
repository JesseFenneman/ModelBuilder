package actionElements;

import java.util.ArrayList;

import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;

/** An ActionTemplatePrecondition is a statement that must be true before an action can be taken. 
 * There are three types of actions: actions that an agent can take BETWEEN encounters; actions
 * that an agent can take DURING encounters. and actions that the 'environment' takes while setting up
 * an encounter.
 * 
 * An action can have any number of Preconditions, including zero.
 * 
 * A precondition has 4 fields, which can sometimes be null:
 * 1. Class - what type of precondition it is, known subclasses include: Location, Phenotype, Resource sampled,
 * 		Resource consumed, Time(life), and Time(cycle).
 * 2. Subject. To what kind of objectiveTemplate does this precondition apply? For instance, if there is a 
 * 		phenotype precondition, to what exact PhenotypeTemplate are we specifically referring?
 * 3. Operator. What kind of statement is this? Options include: equals, not equals, greater than, etc
 * 4. Target. What value should the class have?
 * 
 * As I stated above, sometimes a field can be null. Currently there are 6 types of preconditions, which 
 * have to have the following non-null fields:
 * 
 * Class								Subject											Possible operator					Target
 * Phenotype							A PhenotypeTemplate								< <= = >= > !						A value that the subject can have
 * Location								-												! = 								A possible patch-state
 * Time(life)							-												< <= = >= > !						A time step in agents life
 * Time(encounter)						-												< <= = >= > !						A time step during an encounter
 * Instantiation was successful			InstanceReference								true, false							-
 * At least one Resource present		A ResourceTemplate 								true, false							-
 * Resource consumed					InstanceReference 								true, false							-
 * Resource has value					InstanceReference 								< <= = >= > ! present absent		A value that the subject can have
 * Game type							-												! = 								String
 * 
 * Slot empty							PhenotypeSlot									true, false
 * Slot contains						PhenotypeSlot									! =									InferenceReference (r)
 * 
 * Note. 
 * [1] Some preconditions can only be used during resource encounters, others are only allow between resource
 * encounters, and some are always usable. 
 * [2] Sampled resource have to be declared in the workspace before they can used. They can be declared by specifying that a resource
 * # in encountered at the startup phase in each encounter.
 * [3] The game type is 'Standard' unless otherwise stated during the setup phase of an encounter.
 * */
public interface ActionTemplatePrecondition {
	
	public enum Operator {

		EQUALS("="), 
		DOES_NOT_EQUAL("!="), 
		INCLUDES("includes"),
		DOES_NOT_INCLUDE("does not include"),
		GREATER_THAN(">"), 
		SMALLER_THAN("<"), 
		GREATER_OR_EQUAL_THAN(">="), 
		SMALLER_OR_EQUAL_THAN("<="),
		TRUE("Yes"),
		FALSE("No"),
		PRESENT("Present"),
		ABSENT("Absent"),
		
		// Specifically for slots
		EMPTY("is empty"),
		FILLED("contains any resource"),
		CONTAINS_SPECIFIC("contains"),
		DOES_NOT_CONTAIN("does not contain");
		
		private String name;
		private Operator(String name){ this.name = name;}
		public boolean evaluate(){
			return true;
		}
		public String toString() {return name;}
	}


	// The subject (optional) determines to which exact objectTemplate this precondition applies. 
	// Not all Preconditions have a subject
	public abstract Object getSubject();
	public abstract ActionTemplatePrecondition setSubject(Object newSubject);
	public abstract Object[] getPossibleSubjects();

	// An operator specifies whether the Precondition should equal, not equal, be greater than etc than the target.
	// What exactly should be 'equal/unequal/greater than' to the target depends on specific implementation
	// of ActionTemplatePrecondition. For instance, in an ActionTemplatePreconditionPhenotype a specific
	// Phenotype should match these conditions. In an ActionTemplatePreconditionLocation the current location should
	// be or not be equal to the target.
	public abstract Operator getOperator();
	public abstract ActionTemplatePrecondition setOperator (Operator newOperator);
	public abstract Operator[] getPossibleOperators();

	// The target (optional) specifies what the Precondition should or should not match.
	// Not all preconditions have a target
	public abstract Object getTarget ();
	public abstract ActionTemplatePrecondition setTarget(Object newTarget);
	public abstract Object[] getPossibleTargets();

	/** Does this postcondition contain a reference to the InstanceReference?*/
	public abstract boolean containsInstanceReference(InstanceReference ref) ;
	
	/** Returns true if this precondition changes the specified PhenotypeSlotTemplate*/
	public abstract boolean containsPhenotypeSlot( AbstractPhenotypeSlotTemplate slot );

	
	/** Returns true if the subject is the specified subject */
	public abstract boolean subjectEquals(Object otherSubject);
	
	/** Returns true if the other precondition has the same Class, subject, operator, and target. Call should use
	 * ActionTemplatePrecondition's static equals function.*/
	public abstract boolean equals(ActionTemplatePrecondition otherPrecondition);
	
	/** Returns true if all required fields have been filled out. */
	public abstract boolean isComplete();

	/** The string used to represent the precondition in the view's main page. Should be as short as possible!*/
	public abstract String toSuperShortString();
	
	public abstract String toString();

	/** Returns true iff the two ActionTemplatePreconditions have the same class, subject, operator, and target*/
	public static boolean equals(ActionTemplatePrecondition a, ActionTemplatePrecondition b) {

		if (a == null)
			throw new IllegalArgumentException("Comparing two ActionTemplatePreconditions. However, a is null.");
		if (b == null)
			throw new IllegalArgumentException("Comparing two ActionTemplatePreconditions. However, b is null.");
		
		if (a.getClass() != b.getClass())
			return false;
		if (a.getSubject() != b.getSubject())
			return false;
		if (a.getOperator() != b.getOperator())
			return false;
		if (a.getTarget() != b.getTarget())
			return false;

		return true;
	}
	
	/** Returns true if the precondition can be used between encounters (i.e., when deciding to forage, travel, change phenotype, or do nothing).
	 * Note that whether a precondition can be used depends first on whether that class of precondition is suitable - for instance, a resource-encountered
	 * class is not suitable as a precondition between encounters (as there is no resource encountered, ever). Second, some preconditions require that
	 * the workspace has some other properties. For instance, you can only use a phenotype precondition if there is at least one phenotype dimension 
	 * in the workspace.*/
	public static boolean canUseBetweenEncounters( Class<? extends ActionTemplatePrecondition> clazz){
		if (clazz == ActionTemplatePreconditionLocation.class)				{	return true;  }
		if (clazz == ActionTemplatePreconditionPhenotype.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionResourceConsumed.class)		{   return false; };
		if (clazz == ActionTemplatePreconditionSuccessfulInstantiation.class)	{	return false; };
		if (clazz == ActionTemplatePreconditionAtLeastOneResourcePresent.class)	{	return false; };
		if (clazz == ActionTemplatePreconditionTimeLife.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionTimeCycle.class)				{	return false; };
		if (clazz == ActionTemplatePreconditionGameType.class)				{	return false; };
		if (clazz == ActionTemplatePreconditionResourceValue.class)			{	return false; };
		if (clazz == ActionTemplatePreconditionSlotContains.class)			{	return true; };
		if (clazz == ActionTemplatePreconditionSlotEmpty.class)				{	return true; };
		
		throw new IllegalStateException("Unknown precondition subclass: " + clazz);
	}

	/** Returns true if the precondition can be used during a resource encounter (i.e., when deciding to accept, reject, sample, wait etc.)*/
	public static boolean canUseDuringEncounters( Class<? extends ActionTemplatePrecondition> clazz){
		if (clazz == ActionTemplatePreconditionLocation.class)				{	return true;  }
		if (clazz == ActionTemplatePreconditionPhenotype.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionResourceConsumed.class)		{   return true; };
		if (clazz == ActionTemplatePreconditionSuccessfulInstantiation.class)	{	return true; };
		if (clazz == ActionTemplatePreconditionAtLeastOneResourcePresent.class)	{	return true; };
		if (clazz == ActionTemplatePreconditionTimeLife.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionTimeCycle.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionGameType.class)				{	return true; };
		if (clazz == ActionTemplatePreconditionResourceValue.class)			{	return true; };
		if (clazz == ActionTemplatePreconditionSlotContains.class)			{	return true; };
		if (clazz == ActionTemplatePreconditionSlotEmpty.class)				{	return true; };
		throw new IllegalStateException("Unknown precondition subclass: " + clazz);
	}

	/** Returns true if the precondition can be used when setting up a resource encounter (i.e., when deciding to accept, reject, sample, wait etc.)*/
	public static boolean canUseWhenSettingUpEncounter( Class<? extends ActionTemplatePrecondition> clazz){
		if (clazz == ActionTemplatePreconditionLocation.class)				{	return true;  }
		if (clazz == ActionTemplatePreconditionPhenotype.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionResourceConsumed.class)		{   return true; };
		if (clazz == ActionTemplatePreconditionSuccessfulInstantiation.class)	{	return true; };
		if (clazz == ActionTemplatePreconditionAtLeastOneResourcePresent.class)	{	return true; };
		if (clazz == ActionTemplatePreconditionTimeLife.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionTimeCycle.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionGameType.class)				{	return true; };
		if (clazz == ActionTemplatePreconditionResourceValue.class)			{	return true; };
		if (clazz == ActionTemplatePreconditionSlotContains.class)			{	return true; };
		if (clazz == ActionTemplatePreconditionSlotEmpty.class)				{	return true; };
		throw new IllegalStateException("Unknown precondition subclass: " + clazz);
	}


	/** Returns true if the precondition can be used when setting up an action phase (i.e., when deciding to accept, reject, sample, wait etc.)*/
	public static boolean canUseDuringMutationPhase( Class<? extends ActionTemplatePrecondition> clazz){
		if (clazz == ActionTemplatePreconditionLocation.class)				{	return true;  }
		if (clazz == ActionTemplatePreconditionPhenotype.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionResourceConsumed.class)		{   return true; };
		if (clazz == ActionTemplatePreconditionSuccessfulInstantiation.class)	{	return true; };
		if (clazz == ActionTemplatePreconditionAtLeastOneResourcePresent.class)	{	return true; };
		if (clazz == ActionTemplatePreconditionTimeLife.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionTimeCycle.class)				{	return true;  };
		if (clazz == ActionTemplatePreconditionGameType.class)				{	return true; };
		if (clazz == ActionTemplatePreconditionResourceValue.class)			{	return true; };
		if (clazz == ActionTemplatePreconditionSlotContains.class)			{	return true; };
		if (clazz == ActionTemplatePreconditionSlotEmpty.class)				{	return true; };
		throw new IllegalStateException("Unknown precondition subclass: " + clazz);
	}

	/** Returns true if the precondition can be used during a resource encounter (i.e., when deciding to accept, reject, sample, wait etc.)*/
	public static String toSimpleName( Class<? extends ActionTemplatePrecondition> clazz){
		if (clazz == ActionTemplatePreconditionLocation.class)				{	return "Current location";  }
		if (clazz == ActionTemplatePreconditionPhenotype.class)				{	return "Phenotype dimension";  };
		if (clazz == ActionTemplatePreconditionResourceConsumed.class)		{   return "Consumed resource"; };
		if (clazz == ActionTemplatePreconditionSuccessfulInstantiation.class)	{	return "Successfully found a resource"; };
		if (clazz == ActionTemplatePreconditionAtLeastOneResourcePresent.class)	{	return "There is at least one resource of a type"; };
		if (clazz == ActionTemplatePreconditionTimeLife.class)				{	return "Agent's age";  };
		if (clazz == ActionTemplatePreconditionTimeCycle.class)				{	return "Time in encounter";  };
		if (clazz == ActionTemplatePreconditionGameType.class)				{	return "Game type"; };
		if (clazz == ActionTemplatePreconditionResourceValue.class)			{	return "Resource value"; };
		if (clazz == ActionTemplatePreconditionSlotContains.class)			{	return "A phenotype slot is empty or not"; };
		if (clazz == ActionTemplatePreconditionSlotEmpty.class)				{	return "There is a specific resource in slot"; };
		throw new IllegalStateException("Unknown precondition subclass: " + clazz);
	}
	
	
	
	/** Returns all known ActionTemplatePrecondition subclasses*/
	@SuppressWarnings("unchecked")
	public static Class<? extends ActionTemplatePrecondition>[] getAllPreconditionTypes(){
		return (Class<? extends ActionTemplatePrecondition>[]) new Class<?>[] {
			ActionTemplatePreconditionLocation.class,
			ActionTemplatePreconditionPhenotype.class,
			ActionTemplatePreconditionResourceConsumed.class,
			ActionTemplatePreconditionSuccessfulInstantiation.class,
			ActionTemplatePreconditionAtLeastOneResourcePresent.class,
			ActionTemplatePreconditionTimeLife.class,
			ActionTemplatePreconditionTimeCycle.class,
			ActionTemplatePreconditionGameType.class,
			ActionTemplatePreconditionResourceValue.class,
			ActionTemplatePreconditionSlotContains.class,
			ActionTemplatePreconditionSlotEmpty.class
		}; 
	}

	/** Get all Precondition classes that can be used during a resource encounter*/
	public static ArrayList<Class<? extends ActionTemplatePrecondition>> getAllPreconditionTypesUsableDuringEncounter(){
		ArrayList<Class<? extends ActionTemplatePrecondition>> al = new ArrayList<>();
		for (Class<? extends ActionTemplatePrecondition> clazz: getAllPreconditionTypes())
			if (canUseDuringEncounters(clazz))
				al.add(clazz);
		return al;
	}

	/** Get all Precondition classes that can be while setting up a resource encounter*/
	public static ArrayList<Class<? extends ActionTemplatePrecondition>> getAllPreconditionTypesUsableWhenSettingUpEncounter(){
		ArrayList<Class<? extends ActionTemplatePrecondition>> al = new ArrayList<>();
		for (Class<? extends ActionTemplatePrecondition> clazz: getAllPreconditionTypes())
			if (canUseWhenSettingUpEncounter(clazz))
				al.add(clazz);
		return al;
	}
	
	/** Get all Precondition classes that can be while setting up a an action phase */
	public static ArrayList<Class<? extends ActionTemplatePrecondition>> getAllPreconditionTypesUsableForMutations(){
		ArrayList<Class<? extends ActionTemplatePrecondition>> al = new ArrayList<>();
		for (Class<? extends ActionTemplatePrecondition> clazz: getAllPreconditionTypes())
			if (canUseDuringMutationPhase(clazz))
				al.add(clazz);
		return al;
	}
	
	/** Get all Precondition classes that can be used between resource encounters*/
	public static ArrayList<Class<? extends ActionTemplatePrecondition>> getAllPreconditionTypesUsableBetweenEncounter(){
		ArrayList<Class<? extends ActionTemplatePrecondition>> al = new ArrayList<>();
		for (Class<? extends ActionTemplatePrecondition> clazz: getAllPreconditionTypes())
			if (canUseBetweenEncounters(clazz))
				al.add(clazz);
		return al;
	}

	/** Create a new ActionPreconditionTemplate of the specified class */
	public static ActionTemplatePrecondition createPreconditionTemplate(Class<? extends ActionTemplatePrecondition> clazz){

		if (clazz == ActionTemplatePreconditionLocation.class)					
			return new ActionTemplatePreconditionLocation();  

		if (clazz == ActionTemplatePreconditionPhenotype.class)					
			return new ActionTemplatePreconditionPhenotype();  

		if (clazz == ActionTemplatePreconditionResourceConsumed.class)		   
			return new ActionTemplatePreconditionResourceConsumed();

		if (clazz == ActionTemplatePreconditionSuccessfulInstantiation.class)		
			return new ActionTemplatePreconditionSuccessfulInstantiation(); 
		
		if (clazz == ActionTemplatePreconditionAtLeastOneResourcePresent.class)		
			return new ActionTemplatePreconditionAtLeastOneResourcePresent(); 

		if (clazz == ActionTemplatePreconditionTimeLife.class)					
			return new ActionTemplatePreconditionTimeLife();  

		if (clazz == ActionTemplatePreconditionTimeCycle.class)					
			return new ActionTemplatePreconditionTimeCycle();  

		if (clazz == ActionTemplatePreconditionResourceValue.class)					
			return new ActionTemplatePreconditionResourceValue();  

		if (clazz == ActionTemplatePreconditionSlotContains.class)			
			return new ActionTemplatePreconditionSlotContains();
		
		if (clazz == ActionTemplatePreconditionSlotEmpty.class)			
			return new ActionTemplatePreconditionSlotEmpty();
	
		if (clazz == ActionTemplatePreconditionGameType.class)					
			return new ActionTemplatePreconditionGameType();  

		
		throw new IllegalStateException("Unknown precondition subclass: " + clazz);
	}
	

}
