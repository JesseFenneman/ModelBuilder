package actionElements;

import java.util.ArrayList;

import actionElements.ActionTemplate.ActionType;
import actionElements.ActionTemplatePrecondition.Operator;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.Instance;
import objectiveElements.InstanceAlias;
import view.View;

public class ActionTemplateFactory {
	
	public String name;
	public ActionType actionType;
	
	public ArrayList<ActionTemplatePrecondition> preconditions;
	public ArrayList<ActionTemplatePostcondition> postconditions;
	
	public ActionTemplateFactory() {
		this.preconditions=new ArrayList<>();
		this.postconditions=new ArrayList<>();
		
	}
	
	/** Set the name of the to-be-made instance*/
	public ActionTemplateFactory setName(String name) {
		this.name = name;
		return this;
	}
	
	/** Set the action type of the to-be-made instance*/
	public ActionTemplateFactory setActionType (ActionType at) {
		this.actionType=at;
		return this;
	}
	

	/** Add a postcondition to the to-be-made instance. Does not include necessary precondition. 
	 * Cannot be used for ActionTemplatePostconditionInstantiateObject or ActionTemplatePostconditionCreateReference*/
	public ActionTemplateFactory addPostcondition(Class<? extends ActionTemplatePostcondition> clazz,
			Object subject,
			Object qualifier) {
		
		if (clazz == ActionTemplatePostconditionInstantiateObject.class)
			throw new IllegalArgumentException("Cannot use the generic addPostcondition function for InstantiateObject postcondition. Use the function addPostconditionInstantiateObject instead. ");
		if (clazz == ActionTemplatePostconditionCreateReference.class)
			throw new IllegalArgumentException("Cannot use the generic addPostcondition function for CreateReference postcondition. Use the function addPostconditionCreateReference instead. ");
		
		
		ActionTemplatePostcondition post = ActionTemplatePostcondition.createPostconditionTemplate(clazz);
		post.setSubject(subject);
		post.setQualifier(qualifier);
		
		postconditions.add(post);
		return this;
	}
	
	
	/** Add a ActionTemplatePostconditionInstantiateObject to the to-be-made instance. Also creates the instance and adds the instance to the workspace.*/
	public ActionTemplateFactory addPostconditionInstantiateObject(
			String objectTypeName,
			String instanceName		) {

		AbstractObjectiveTemplate instanceType = View.getView().workspace.getObject(objectTypeName);
		Instance instance = new Instance(instanceName, instanceType);
		View.getView().workspace.addInstance(instance);
		
		ActionTemplatePostconditionInstantiateObject post = new ActionTemplatePostconditionInstantiateObject();
		post.setSubject(instanceType);
		post.setQualifier(instanceName);
		post.setReferenceAfterCreation(instance);
	
		postconditions.add(post);
		return this;
	}
	
	
	/** Add a ActionTemplatePostconditionCreateReference to the to-be-made instance. Also creates the instance reference and adds the instance reference to the workspace.*/
	public ActionTemplateFactory addPostconditionCreateReference(
			String instanceName,
			String aliasName) {
		
	
		InstanceAlias alias = new InstanceAlias(aliasName, instanceName);
		View.getView().workspace.addInstanceAlias(alias);
	
		ActionTemplatePostconditionCreateReference post = new ActionTemplatePostconditionCreateReference();
		post.setSubject(View.getView().workspace.getInstance(instanceName));
		post.setQualifier(aliasName);
		post.setReferenceAfterCreation(alias);
	
		postconditions.add(post);
		return this;
	}
	
	/** Add a precondition to the to-be-made instance*/
	public ActionTemplateFactory addPrecondition(Class<? extends ActionTemplatePrecondition> clazz,
			Object subject,
			Operator operator,
			Object target) {
		
		ActionTemplatePrecondition pre = ActionTemplatePrecondition.createPreconditionTemplate(clazz);
		pre.setSubject(subject);
		pre.setOperator(operator);
		pre.setTarget(target);
		preconditions.add(pre);
		return this;
	}
	
	/** Build the specified instance. Also adds necessary preconditions.*/
	public ActionTemplate build() {
		ActionTemplate instance = new ActionTemplate(actionType, name);

		for (ActionTemplatePostcondition post : postconditions) {
			instance.addPostcondition(post);
			post.addMissingPreconditions(preconditions);

		}
		for (ActionTemplatePrecondition pre: preconditions)
			instance.addPrecondition(pre);
		
		return instance;
	}
	
}
