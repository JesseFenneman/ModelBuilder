package actionElements;

import java.util.ArrayList;

import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.Instance;
import objectiveElements.InstanceAlias;
import objectiveElements.InstanceReference;
import objectiveElements.InterruptionObjectTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionInterruptEncounter  extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	
	public ActionTemplatePostconditionInterruptEncounter () {
		this.possibleSubjects = View.getView().workspace.getAllInterruptionInstanceReferences().toArray(
				new InstanceReference[0]);

	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		if (!(newSubject instanceof InstanceReference))
			throw new IllegalArgumentException("Cannot use " + newSubject.getClass() + " as a subject");


		if (newSubject instanceof Instance)
			if (!(((Instance)newSubject).getAbstractObjectiveTemplate() instanceof InterruptionObjectTemplate))
				throw new IllegalArgumentException("An interrupt post condition cannot have a subject of type " + newSubject.getClass());

		if (newSubject instanceof InstanceAlias)
			if (!(((InstanceAlias)newSubject).getInitialInstance().getAbstractObjectiveTemplate() instanceof InterruptionObjectTemplate))
				throw new IllegalArgumentException("An interrupt postponing post condition cannot have a subject of type " + newSubject.getClass());
		
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {return this;}
	@Override
	public boolean isComplete() {
		return subject != null;
	}
	@Override
	public String toString() { return "A " + ((AbstractObjectiveTemplate)subject).getName() + " might occur" ;}
	@Override
	public String toSuperShortString() { return ((AbstractObjectiveTemplate)subject).getName()+" interruption";}

	@Override
	public boolean containsInstanceReference(InstanceReference ref){return subject == ref;}
	
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		return true;
	}

	
	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
	}
	
}

