package actionElements;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import helper.Helper;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionTimeCycle implements ActionTemplatePrecondition, Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	private Operator operator;
	private Integer[] possibleTargets;
	private Integer target;
	
	public ActionTemplatePreconditionTimeCycle (){
		this.possibleTargets = Helper.sequence(0, View.getView().workspace.getMaximumLifeTime(), 1);
	}
	
	//// SUBJECT: NULL FOR TIME
	@Override
	public AbstractObjectiveTemplate getSubject() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) {
		return this;
		
	}

	@Override
	public AbstractObjectiveTemplate[] getPossibleSubjects() {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public boolean subjectEquals (Object otherSubject){
		return false;
	}
	
	//// OPERATOR
	@Override
	public Operator getOperator() {
		return operator;
	}
	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{Operator.EQUALS, Operator.DOES_NOT_EQUAL, Operator.SMALLER_THAN, Operator.SMALLER_OR_EQUAL_THAN, Operator.GREATER_OR_EQUAL_THAN, Operator.GREATER_THAN};
	}
	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in a time precondition.");
		return this;
	}
	
	
	
	
	//// TARGET
	@Override
	public Object getTarget() {
		return target;
	}
	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		if (!(newTarget instanceof Integer))
			throw new IllegalArgumentException("Illegal target: cannot set a " + newTarget.getClass() + " as a time target.");
		
		List<Integer> permissibleValues = Arrays.asList(possibleTargets);
		if (permissibleValues.contains(newTarget))
			this.target = (Integer) newTarget;
		else
			throw new IllegalArgumentException("Illegal target:  " +  (Integer) newTarget + " is not a permissible target");
		return this;
		
	}
	@Override
	public Object[] getPossibleTargets() {
		return possibleTargets;
	}

	

	@Override
	public boolean isComplete() {
		return (target != null && operator != null);
	}

	
	@Override
	public String toString(){
		return "Current time step in the cycle is " + operator + " " + target;
	}
	@Override
	public String toSuperShortString() {
		return "Age " + operator + " " + target;
	}

	public boolean containsInstanceReference(InstanceReference ref) {return false;}
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	
	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}
}
