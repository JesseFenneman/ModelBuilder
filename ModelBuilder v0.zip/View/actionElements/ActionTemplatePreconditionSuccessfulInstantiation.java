package actionElements;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.Instance;
import objectiveElements.InstanceNull;
import objectiveElements.InstanceReference;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionSuccessfulInstantiation implements ActionTemplatePrecondition, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	private InstanceReference subject;
	private InstanceReference[] possibleSubjects;
	private Operator operator;
	
	public ActionTemplatePreconditionSuccessfulInstantiation (){
		ArrayList<InstanceReference> permissibleSubjects = new ArrayList<>();
		permissibleSubjects.addAll(View.getView().workspace.getAllResourceInstanceReferences());
		permissibleSubjects.addAll(View.getView().workspace.getAllDelayInstanceReferences());
		permissibleSubjects.addAll(View.getView().workspace.getAllExtrinsicInstanceReferences());
		
		this.possibleSubjects=permissibleSubjects.toArray(new InstanceReference[0]);
	}
	
	//// SUBJECT
	@Override
	public InstanceReference getSubject() {
		return subject;
	}

	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) {
		InstanceReference newSubjectInstanceReference = (InstanceReference) newSubject;

		boolean contains = false;
		for (InstanceReference ir: possibleSubjects)
			if (ir == newSubjectInstanceReference)
				contains = true;
		if (contains)
			this.subject = newSubjectInstanceReference;
		else if ( InstanceNull.isNullReference(newSubjectInstanceReference))
				throw new IllegalArgumentException("Cannot use a null instance in a succesfullInstantiation postcondition.");
		else
			throw new IllegalArgumentException("Illegal subject: " + newSubjectInstanceReference + " does not exist in view.");
		return this;
	}

	@Override
	public InstanceReference[] getPossibleSubjects() {
		return possibleSubjects;
	}

	@Override
	public boolean subjectEquals (Object otherSubject){
		return this.subject == otherSubject;
	}
	
	//// OPERATOR
	@Override
	public Operator getOperator() {
		return operator;
	}
	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in successfulInstantiation precondition.");
		return this;
	}
	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{Operator.TRUE, Operator.FALSE};
	}

	
	
	
////TARGET: NULL FOR THIS PRECONDITION
	@Override
	public Object getTarget() {
		return null;
	}
	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		return this;
	}
	@Override
	public Object[] getPossibleTargets() {
		return null;
	}

	
	
	//// COMPLETE
	@Override
	public boolean isComplete() {
		return (subject != null && operator != null);
	}

	@Override
	public String toString(){
		if (operator == Operator.TRUE)
			return("There is a '" + subject.getName().toLowerCase() + "' in this encounter");
		return("The is NOT a '" + subject.getName().toLowerCase() + "' in this encounter");
	}
	@Override
	public String toSuperShortString() {
		if (operator == Operator.TRUE)
			return "'" + subject.getName().toLowerCase() +  "' exists";
		return "NO '" + subject.getName().toLowerCase() +  "' exists";
	}

	public boolean containsInstanceReference(InstanceReference ref) {return false;}
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	
	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}
}
