package actionElements;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import helper.Helper;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionGameType implements ActionTemplatePrecondition, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	

	private Operator operator;
	private String[] possibleTargets;
	private String target;
	
	public ActionTemplatePreconditionGameType (){	
		possibleTargets = View.getView().workspace.getGameTypes().toArray(new String[0]);
	}
	
	
	
	//// SUBJECTS
	@Override
	public AbstractObjectiveTemplate getSubject() {
		return null;
	}

	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) {
		return this;
	}

	@Override
	public AbstractObjectiveTemplate[] getPossibleSubjects() {
		return null;
	}

	@Override
	public boolean subjectEquals (Object otherSubject){
		return false;
	}
	
	//// OPERATORS
	@Override
	public Operator getOperator() {
		return operator;
	}
	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in phenotype precondition.");
		return this;
	}
	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{Operator.EQUALS, Operator.DOES_NOT_EQUAL};		
	}



	//// TARGETS
	@Override
	public Object getTarget() {
		return target;
	}
	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		
		if (!(newTarget instanceof String))
			throw new IllegalArgumentException("Illegal target: cannot set a " + newTarget.getClass() + " as a game type.");
		
		if (!Helper.isVariableName((String)newTarget))
			throw new IllegalArgumentException(newTarget + " is not a permissible variable name.");
		
		List<String> permissibleValues = Arrays.asList(possibleTargets);
		if (permissibleValues.contains(newTarget))
			this.target = (String) newTarget;
		else
			throw new IllegalArgumentException("Illegal target:  " +  (String) newTarget + " is not a permissible target");
		return this;
	}
	@Override
	public Object[] getPossibleTargets() {
		return possibleTargets;
		
	}

	//// COMPLETE
	@Override
	public boolean isComplete() {
		return ( target != null);
	}


	@Override
	public String toString(){
		return("The game type is " + operator + " " +target.toUpperCase() );
	}



	@Override
	public String toSuperShortString() {
		return "GAME"+" "+operator+" "+target.toUpperCase();
	}

	public boolean containsInstanceReference(InstanceReference ref)  {return false;}
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	
	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}
}
