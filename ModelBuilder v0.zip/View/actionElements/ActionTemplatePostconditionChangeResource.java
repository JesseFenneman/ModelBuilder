package actionElements;

public class ActionTemplatePostconditionChangeResource extends ActionTemplatePostcondition {

}
