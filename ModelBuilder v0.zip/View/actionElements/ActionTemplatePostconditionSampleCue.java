package actionElements;

import java.util.ArrayList;

import actionElements.ActionTemplatePrecondition.Operator;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.Instance;
import objectiveElements.InstanceAlias;
import objectiveElements.InstanceReference;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionSampleCue  extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	
	public ActionTemplatePostconditionSampleCue () {
		this.possibleSubjects = View.getView().workspace.getAllCuedInstanceReferences().toArray(new InstanceReference[0]);
	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		if (!(newSubject instanceof InstanceReference))
			throw new IllegalArgumentException("Cannot use " + newSubject.getClass() + " as a subject");

		if (newSubject instanceof Instance)
			if (((Instance)newSubject).getAbstractObjectiveTemplate().getCueTemplate() == null)
				throw new IllegalArgumentException("Cannot sample from an object that does not provide cues");

		if (newSubject instanceof InstanceAlias)
			if (((InstanceAlias)newSubject).getInitialInstance().getAbstractObjectiveTemplate().getCueTemplate() == null)
				throw new IllegalArgumentException("Cannot sample from an object that does not provide cues");

		this.subject = newSubject;
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) { return this;}
	@Override
	public boolean isComplete() {
		return subject != null;
	}

	@Override
	public String toString() { return "Sample cue on " + ((InstanceReference)subject).getName();}

	@Override
	public String toSuperShortString() { return "Sample cue " + ((InstanceReference)subject).getName();}

	@Override
	public boolean containsInstanceReference(InstanceReference ref) {return subject == ref;}
	
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		ActionTemplatePreconditionSuccessfulInstantiation pre = new ActionTemplatePreconditionSuccessfulInstantiation ();
		pre.setSubject(this.subject);
		pre.setOperator(Operator.TRUE);
		preconditions.add(pre);
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();
		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : preconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;
					break;
				}
			if (!includedInPreconditions)
				return false;
		}
		return true;
	}

	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();
		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : existingPreconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;
					break;
				}
			if (!includedInPreconditions)
				existingPreconditions.add(np);
		}
	}

}


