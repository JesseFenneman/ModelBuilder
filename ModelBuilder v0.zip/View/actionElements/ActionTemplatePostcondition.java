package actionElements;

import java.io.Serializable;
import java.util.ArrayList;

import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.CueTemplate;
import objectiveElements.InstanceReference;
import start.CentralExecutive;

/** An ActionTemplatePostcondition is a the consequence of an action.
 * There are three types of actions: actions that an agent can take
 * between encounters; actions that an agent can take during encounters;
 * and actions that the 'environment' takes while setting up an encounter.
 *
 * A postcondition has 3 fields, which can sometimes be null:
 * 1. Class - what type of postcondition it is, known subclasses include:
 * 	-Start encounter (between; possibly starts encounter),
 *  -Move patch (between)
 *  -Wait (between)
 *  
 *  -Increase phenotype (always)
 *  -Decrease phenotype (always)
 *  -Set phenotype (always)
 *  
 *  - Sample named instance of resource (setup)
 *  - Change name of sampled resource (setup)
 *  - Set game mode (setup)
 *  
 *  -Sample cue (during)
 *  -Wait (during)
 *  -Postpone (during)
 *  -Terminate (during)
 *  -Interrupt (during)
 *
 * 2. Subject. To what kind of objectiveTemplate or cueTemplate does this postcondition apply?
 * For instance, sample cue postcondition, what type of cue is sampled?
 * 
 * 3. Qualifier. A value or interruption probability.
 *
 * Currently there are the following post conditions:
 *
 * Class						Subject	Type				Qualifier						Additional arguments/notes
 * Start encounter				-					 		-								-
 * Move patch					-							-								-
 * Wait (between)				-							-								-
 * Increase phenotype			PhenotypeObjectTemplate 	NumberObjectSingle value		-
 * Decrease phenotype			PhenotypeObjectTemplate 	NumberObjectSingle value		-
 * Set phenotype				PhenotypeObjectTemplate		NumberObjectSingle value		-
 * 
 * Instantiate object 			ObjectiveTemplate			String (input)		 			-				Note: Resource, Delay, and Interruption only. To be used during encounter setup. 		
 * Instantiate Extrinsic  		ObjectiveTemplate			String (input)					-				Note: Extrinsic event only. To be used during mutation phase. 		
 * Create Reference				InstanceReference			String (input)					-
 * Change Reference				InstanceAlias				InstanceReference				-
 * Set game mode				-							String (input)					-
 * 
 * Sample cue					InstanceReference (*)		-								-
 * Wait (during)				-							-								-
 * Postpone (Without)			InstanceReference (d)		-								-
 * Postpone (with)				InstanceReference (d)		InstanceReference				-
 * Terminate encounter			-							-								-
 * Interrupt encounter			InstanceReference (i)		-								-
 * Consume resource				InstanceReference (r)		PhenotypeObject					-
 * Apply extrinsic event		InstanceReference (e)		PhenotypeObject					-
 * 
 * Change patch state			Patch						PatchState
 * Change resource				//TODO	
 * 
 * Store (additional arguments depend on phenotype slot selected)
 * Store						PhenotypeSlot				InstanceReference (r)			If slot == 'Delayed': 	PhenotypeObject	+	InstanceReference (i)	+	InstanceReference (d) 
 * 																							If slot == 'Recurrent': PhenotypeObject	+	InstanceReference (i)	+ 	Int (periodicity)
 * 																							If slot == 'Captive': 	
 * 
 * Consume captive resource 	PhenotypeSlot				PhenotypeObject					-								-	
 * Empty slot 					PhenotypeSlot				-								-
 * 
 * Set environmental state
 * 
 * Note 1. The age is a special phenotype - it cannot be used in any postcondition! 
 * Note 2. that some postconditions can only be used during resource encounters, others are only allow between resource
 * encounters, and some are always usable.
 * 
 * Note 3. Some postconditions have necessary preconditions. Specifically, some postconditions that can
 * apply during the Setup rules or the actions available during an encounter are only possible if
 * a resource or delay has been encountered. An Interruption does have to be instantiated, but it 
 * does not matter whether that instantiation was successful - if it wasn't, then there is no
 * interruption of that type. 
 * 
 * However, during runtime it is not known whether an instantiation was successful
 * (that is, whether a resource or delay is indeed present in an encounter). After all, the probability
 * of the instantiation being successful depends on the frequency of the resource or delay.
 * 
 * As such, all postconditions that depend on an instance (or instance alias) need 
 * the necessary precondition 'SuccesfulInstantiation' for each Resource or Delay object used.
 * The subject of these precondition must be the same as the subject of the postcondition, and
 * the precondition's target must be set to 'true'. 
 * 
 * The following postconditions have necessary preconditions:
 * 
 * Postcondition			Requirement 															
 * Create Reference			Subject (delay or resource) must have been successfully instantiated													-
 * Change Reference			Subject (delay or resource) must have been successfully instantiated				
 * Sample cue				Subject (delay or resource) must have been successfully instantiated			
 * Postpone without			Subject (delay) must have been successfully instantiated		
 * Postpone with			Subject (delay) must have been successfully instantiated	
 * Consume resource			Subject (resource) must have been successfully instantiated
 *  
 *TODO: Optimize model: if a resource has a frequency of 1, do not need to check.
 * 
 * */
public abstract class ActionTemplatePostcondition implements Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;

	protected Object subject;
	protected Object[] possibleSubjects;

	protected Object qualifier;
	protected Object[] possibleQualifiers;
	
	
	/** Returns true if this postcondition contains a reference to the InstanceReference*/
	public abstract boolean containsInstanceReference( InstanceReference ref);

	/** Returns true if this postcondition changes the specified PhenotypeSlotTemplate*/
	public abstract boolean containsPhenotypeSlot( AbstractPhenotypeSlotTemplate slot );

	
	/** What sort of input is the qualifer. There are two options: the qualifier should be selected from a list
	 * of all possible values; or it is a String input*/
	public enum QualifierInputType { List, String ;}

	/** Returns the subject of this postcondition. Can be null.*/
	public Object getSubject() {return this.subject;}

	/** Set the subject. Setting a subject of an incorrect type leads to an IllegalArgumentException.
	 * Not all postconditions have a subject, in which case this function does nothing. Returns this. */
	public abstract ActionTemplatePostcondition setSubject(Object newSubject);

	/** Returns a list of AbstractObjectiveTemplates and/or cues. Can be null.*/
	public Object[] getPossibleSubjects() { return possibleSubjects;};

	/** Returns true fit this postcondition's subject equals the object (by reference)*/
	public boolean subjectEquals (AbstractObjectiveTemplate object){
		return subject==object;
	}

	/** Returns true fit this postcondition's subject equals the CueTemplate (by reference)*/
	public boolean subjectEquals (CueTemplate cue){
		return subject==cue;
	}

	/** Returns the qualifier of this postcondition. Can be null. */
	public Object getQualifier() { return this.qualifier;}

	/** Set the qualifier. Setting a subject of an incorrect type leads to an IllegalArgumentException.
	 * Not all postconditions have a qualifier, in which case this function does nothing. Returns this.*/
	public abstract ActionTemplatePostcondition setQualifier(Object newQualifier);

	/** Returns a list of qualifiers (of NumberObjectSingle or InterruptionObjectTemplate class).
	 * Often, the possible qualifiers are set only after setting the subject. Calling getPossibleQualifiers()
	 * before setting a subject can result in an IllegalStateException. Result can be null.*/
	public Object[] getPossibleQualifiers(){ return possibleQualifiers;}

	/** Returns a list of AbstractObjectiveTemplates and/or cues. Can be null.*/
	public Object[] getPossibleValuesAdditionalArgument1() { return possibleSubjects;};
	
	/** Returns true if all the required fields are set. That is, if the postcondition requires a subject
	 * and qualifier, this function returns true only if neither are null.*/
	public abstract boolean isComplete();

	/** The string used to represent the precondition in the view's main page. Should be as short as possible!*/
	public abstract String toSuperShortString();

	/** Generate a list of all preconditions that are necessary for this postconditions. Returns an empty ArrayList 
	 * if there are no necessary preconditions. Throws an IllegalStateException if this function is called
	 * when the postcondition is not (yet) complete. */
	public abstract ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions();
	
	/** Returns true if all necessary preconditions are present in the provided list of 
	 * preconditions.*/
	public abstract boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions);
	
	/** Adds all the missing preconditions for the Postcondition into the specified ArrayList*/
	public abstract void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions);
	
	/** Generate a list of all preconditions that are necessary for this postconditions.
	 *  Returns an empty ArrayList if there are no necessary preconditions. 
	 * Throws an IllegalStateException if this function is called when the postcondition is not (yet) complete. */
	//public abstract ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions(ArrayList<ActionTemplatePrecondition> preconditions);
	
	/** Returns true if the postcondition can be used between encounters */
	public static boolean canUseBetweenEncounters( Class<? extends ActionTemplatePostcondition> clazz){
		if (clazz == ActionTemplatePostconditionStartEncounter.class)							{	return true;  }
		if (clazz == ActionTemplatePostconditionMovePatch.class)								{	return true;  }

		if (clazz == ActionTemplatePostconditionIncreasePhenotype.class)						{	return true;  }
		if (clazz == ActionTemplatePostconditionDecreasePhenotype.class)						{	return true;  }
		if (clazz == ActionTemplatePostconditionSetPhenotype.class)								{	return true;  }

		if (clazz == ActionTemplatePostconditionInstantiateObject.class)						{	return false;  }
		if (clazz == ActionTemplatePostconditionInstantiateExtrinsic.class)						{	return false;  }
		if (clazz == ActionTemplatePostconditionCreateReference.class)							{	return false;  }
		if (clazz == ActionTemplatePostconditionChangeReference.class)							{	return false;  }
		if (clazz == ActionTemplatePostconditionSetGameMode.class)								{	return false;  }

		if (clazz == ActionTemplatePostconditionSampleCue.class)								{	return false;  }
		if (clazz == ActionTemplatePostconditionWait.class)										{	return true;  }
		if (clazz == ActionTemplatePostconditionPostponeWithoutInterruption.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionPostponeWithInterruption.class)					{	return false;  }
		if (clazz == ActionTemplatePostconditionTerminateEncounter.class)						{	return false;  }
		if (clazz == ActionTemplatePostconditionInterruptEncounter.class)						{	return false;  }
		if (clazz == ActionTemplatePostconditionConsumeResource.class)							{	return false;  }
		if (clazz == ActionTemplatePostconditionApplyExtrinsic.class)							{	return false;  }

		if (clazz == ActionTemplatePostconditionChangePatchState.class)							{	return false;  }
		if (clazz == ActionTemplatePostconditionChangeResource.class)							{	return false;  }
		
		if (clazz == ActionTemplatePostconditionStore.class)									{	return false;  }
		if (clazz == ActionTemplatePostconditionEmptySlot.class)								{	return true;  }
		if (clazz == ActionTemplatePostconditionUseCaptiveSlot.class)							{	return true;  }
		
		throw new IllegalStateException("Unknown postcondition subclass: " + clazz);
	}

	/** Returns true if the postcondition can be used during encounters */
	public static boolean canUseDuringEncounters( Class<? extends ActionTemplatePostcondition> clazz){
		if (clazz == ActionTemplatePostconditionStartEncounter.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionMovePatch.class)					{	return false;  }

		if (clazz == ActionTemplatePostconditionIncreasePhenotype.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionDecreasePhenotype.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionSetPhenotype.class)					{	return false;  }

		if (clazz == ActionTemplatePostconditionInstantiateObject.class)			{	return false;  }
		if (clazz == ActionTemplatePostconditionInstantiateExtrinsic.class)			{	return false;  }
		if (clazz == ActionTemplatePostconditionCreateReference.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionChangeReference.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionSetGameMode.class)					{	return false;  }

		if (clazz == ActionTemplatePostconditionSampleCue.class)					{	return true;  }
		if (clazz == ActionTemplatePostconditionWait.class)							{	return true;  }
		if (clazz == ActionTemplatePostconditionPostponeWithoutInterruption.class)	{	return true;  }
		if (clazz == ActionTemplatePostconditionPostponeWithInterruption.class)		{	return true;  }
		if (clazz == ActionTemplatePostconditionTerminateEncounter.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionInterruptEncounter.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionConsumeResource.class)				{	return true;  }
		if (clazz == ActionTemplatePostconditionApplyExtrinsic.class)				{	return false;  }
		
		if (clazz == ActionTemplatePostconditionChangePatchState.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionChangeResource.class)				{	return false;  }
		
		if (clazz == ActionTemplatePostconditionStore.class)						{	return true;  }
		if (clazz == ActionTemplatePostconditionEmptySlot.class)					{	return true;  }
		if (clazz == ActionTemplatePostconditionUseCaptiveSlot.class)				{	return true;  }
	
		throw new IllegalStateException("Unknown postcondition subclass: " + clazz);
	}

	/** Returns true if the postcondition can be used when setting up encounters */
	public static boolean canUseWhenSettingUpEncounter( Class<? extends ActionTemplatePostcondition> clazz){

		if (clazz == ActionTemplatePostconditionStartEncounter.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionMovePatch.class)					{	return false;  }

		if (clazz == ActionTemplatePostconditionIncreasePhenotype.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionDecreasePhenotype.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionSetPhenotype.class)					{	return true;  }

		if (clazz == ActionTemplatePostconditionInstantiateObject.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionInstantiateExtrinsic.class)			{	return false;  }
		if (clazz == ActionTemplatePostconditionCreateReference.class)				{	return true;  }
		if (clazz == ActionTemplatePostconditionChangeReference.class)				{	return true;  }
		if (clazz == ActionTemplatePostconditionSetGameMode.class)					{	return true;  }

		if (clazz == ActionTemplatePostconditionSampleCue.class)					{	return true;  }
		if (clazz == ActionTemplatePostconditionWait.class)							{	return false;  }
		if (clazz == ActionTemplatePostconditionPostponeWithoutInterruption.class)	{	return false;  }
		if (clazz == ActionTemplatePostconditionPostponeWithInterruption.class)		{	return false;  }
		if (clazz == ActionTemplatePostconditionTerminateEncounter.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionInterruptEncounter.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionConsumeResource.class)				{	return true;  }
		if (clazz == ActionTemplatePostconditionApplyExtrinsic.class)				{	return false;  }
		
		if (clazz == ActionTemplatePostconditionChangePatchState.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionChangeResource.class)				{	return false;  }
		
		if (clazz == ActionTemplatePostconditionStore.class)						{	return false;  }
		if (clazz == ActionTemplatePostconditionEmptySlot.class)					{	return true;  }
		if (clazz == ActionTemplatePostconditionUseCaptiveSlot.class)				{	return false;  }

		throw new IllegalStateException("Unknown postcondition subclass: " + clazz);
	}

	
	/** Returns true if the postcondition can be used when setting up action phase */
	public static boolean canUseDuringMutationPhase ( Class<? extends ActionTemplatePostcondition> clazz){

		if (clazz == ActionTemplatePostconditionStartEncounter.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionMovePatch.class)					{	return false;  }

		if (clazz == ActionTemplatePostconditionIncreasePhenotype.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionDecreasePhenotype.class)			{	return true;  }
		if (clazz == ActionTemplatePostconditionSetPhenotype.class)					{	return true;  }

		if (clazz == ActionTemplatePostconditionInstantiateObject.class)			{	return false;  }
		if (clazz == ActionTemplatePostconditionInstantiateExtrinsic.class)			{	return true;   }
		if (clazz == ActionTemplatePostconditionCreateReference.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionChangeReference.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionSetGameMode.class)					{	return false;  }

		if (clazz == ActionTemplatePostconditionSampleCue.class)					{	return false;  }
		if (clazz == ActionTemplatePostconditionWait.class)							{	return false;  }
		if (clazz == ActionTemplatePostconditionPostponeWithoutInterruption.class)	{	return false;  }
		if (clazz == ActionTemplatePostconditionPostponeWithInterruption.class)		{	return false;  }
		if (clazz == ActionTemplatePostconditionTerminateEncounter.class)			{	return false;  }
		if (clazz == ActionTemplatePostconditionInterruptEncounter.class)			{	return false;  }
		if (clazz == ActionTemplatePostconditionConsumeResource.class)				{	return false;  }
		if (clazz == ActionTemplatePostconditionApplyExtrinsic.class)				{	return true;  }

		if (clazz == ActionTemplatePostconditionChangePatchState.class)				{	return true;  }
		if (clazz == ActionTemplatePostconditionChangeResource.class)				{	return true;  }
		
		if (clazz == ActionTemplatePostconditionStore.class)						{	return false;  }
		if (clazz == ActionTemplatePostconditionEmptySlot.class)					{	return true;  }
		if (clazz == ActionTemplatePostconditionUseCaptiveSlot.class)				{	return false;  }
	
		throw new IllegalStateException("Unknown postcondition subclass: " + clazz);
	}
	/** Prints the simple name of the clazz*/
	public static String toSimpleName( Class<? extends ActionTemplatePostcondition> clazz){
		if (clazz == ActionTemplatePostconditionStartEncounter.class)				{	return "Try to start encounter - search for resources, delays, and interruptions";  }
		if (clazz == ActionTemplatePostconditionMovePatch.class)					{	return "Move to another patch";  }

		if (clazz == ActionTemplatePostconditionIncreasePhenotype.class)			{	return "Increase a phenotypic dimension";  }
		if (clazz == ActionTemplatePostconditionDecreasePhenotype.class)			{	return "Decrease a phenotypic dimension";  }
		if (clazz == ActionTemplatePostconditionSetPhenotype.class)					{	return "Set a phenotypic dimension to a certain value";  }

		if (clazz == ActionTemplatePostconditionInstantiateObject.class)			{	return "Instantiate: try to find an specific object in this encounter";  }
		if (clazz == ActionTemplatePostconditionInstantiateExtrinsic.class)			{	return "Sample an extrinsic event";  }
		if (clazz == ActionTemplatePostconditionCreateReference.class)				{	return "Create a reference to a specific object";  }
		if (clazz == ActionTemplatePostconditionChangeReference.class)				{	return "Change the reference to a specific object";  }
		if (clazz == ActionTemplatePostconditionSetGameMode.class)					{	return "Set the game mode";  }

		if (clazz == ActionTemplatePostconditionSampleCue.class)					{	return "Sample a cue";  }
		if (clazz == ActionTemplatePostconditionWait.class)							{	return "Wait (do nothing)";  }
		if (clazz == ActionTemplatePostconditionPostponeWithoutInterruption.class)	{	return "Postpone, assuming that there is no interruption";  }
		if (clazz == ActionTemplatePostconditionPostponeWithInterruption.class)		{	return "Postpone, and every time step there might be an interruption ";  }
		if (clazz == ActionTemplatePostconditionTerminateEncounter.class)			{	return "Stop the encounter";  }
		if (clazz == ActionTemplatePostconditionInterruptEncounter.class)			{	return "Possibility interrupt the encounter";  }
		if (clazz == ActionTemplatePostconditionConsumeResource.class)				{	return "Consume a found resource";  }
		if (clazz == ActionTemplatePostconditionApplyExtrinsic.class)				{	return "Apply a sampled extrinsic event to a phenotypic dimension";  }

		if (clazz == ActionTemplatePostconditionChangePatchState.class)				{	return "Change the state of a patch";  }
		if (clazz == ActionTemplatePostconditionChangeResource.class)				{	return "Change the value of a resource";  }
		
		if (clazz == ActionTemplatePostconditionStore.class)						{	return "Store a found resource in a phenotypic slot";  }
		if (clazz == ActionTemplatePostconditionEmptySlot.class)					{	return "Empty a phenotypic slot";  }
		if (clazz == ActionTemplatePostconditionUseCaptiveSlot.class)				{	return "Use a resource previously stored in a captive slot";  }
		
		throw new IllegalStateException("Unknown postcondition subclass: " + clazz);
	}


	/** Returns all known ActionTemplatePostcondition subclasses*/
	@SuppressWarnings("unchecked")
	public static Class<? extends ActionTemplatePostcondition>[] getAllPostconditionTypes(){
		return (Class<? extends ActionTemplatePostcondition>[]) new Class<?>[] {
			ActionTemplatePostconditionStartEncounter.class,
			ActionTemplatePostconditionMovePatch.class,

			ActionTemplatePostconditionIncreasePhenotype.class,
			ActionTemplatePostconditionDecreasePhenotype.class,
			ActionTemplatePostconditionSetPhenotype.class,
			ActionTemplatePostconditionInstantiateObject.class,
			ActionTemplatePostconditionInstantiateExtrinsic.class,
			ActionTemplatePostconditionCreateReference.class,
			ActionTemplatePostconditionChangeReference.class,
			ActionTemplatePostconditionSetGameMode.class,
			ActionTemplatePostconditionSampleCue.class,
			ActionTemplatePostconditionWait.class,
			ActionTemplatePostconditionPostponeWithoutInterruption.class,
			ActionTemplatePostconditionPostponeWithInterruption.class,
			ActionTemplatePostconditionTerminateEncounter.class,
			ActionTemplatePostconditionInterruptEncounter.class,
			ActionTemplatePostconditionConsumeResource.class,
			ActionTemplatePostconditionApplyExtrinsic.class,
			
			ActionTemplatePostconditionChangePatchState.class,
			ActionTemplatePostconditionChangeResource.class ,
			
			ActionTemplatePostconditionStore.class,
			ActionTemplatePostconditionEmptySlot.class,
			ActionTemplatePostconditionUseCaptiveSlot.class
		};
	}


	/** Can possible qualifier values be presented in a List, or should it be presented as a String to the user?*/
	public static QualifierInputType getQualifierInputType(Class<? extends ActionTemplatePostcondition> clazz) {
		if (clazz == ActionTemplatePostconditionStartEncounter.class)				{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionMovePatch.class)					{	return QualifierInputType.List;  }

		if (clazz == ActionTemplatePostconditionIncreasePhenotype.class)			{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionDecreasePhenotype.class)			{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionSetPhenotype.class)					{	return QualifierInputType.List;  }

		if (clazz == ActionTemplatePostconditionInstantiateObject.class)			{	return QualifierInputType.String;  }
		if (clazz == ActionTemplatePostconditionInstantiateExtrinsic.class)			{	return QualifierInputType.String;  }
		if (clazz == ActionTemplatePostconditionCreateReference.class)				{	return QualifierInputType.String;  }
		if (clazz == ActionTemplatePostconditionChangeReference.class)				{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionSetGameMode.class)					{	return QualifierInputType.String;  }

		if (clazz == ActionTemplatePostconditionSampleCue.class)					{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionWait.class)							{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionPostponeWithoutInterruption.class)	{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionPostponeWithInterruption.class)		{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionTerminateEncounter.class)			{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionInterruptEncounter.class)			{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionConsumeResource.class)				{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionApplyExtrinsic.class)				{	return QualifierInputType.List;  }
		
		if (clazz == ActionTemplatePostconditionChangePatchState.class)				{	throw new UnsupportedOperationException("NOT YET IMPLEMENTED");  }
		if (clazz == ActionTemplatePostconditionChangeResource.class)				{	throw new UnsupportedOperationException("NOT YET IMPLEMENTED");  }
		
		if (clazz == ActionTemplatePostconditionStore.class)						{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionEmptySlot.class)					{	return QualifierInputType.List;  }
		if (clazz == ActionTemplatePostconditionUseCaptiveSlot.class)				{	return QualifierInputType.List;  }
		
		throw new IllegalStateException("Unknown postcondition subclass: " + clazz);

	}

	/** Get all Postcondition classes that can be used during a resource encounter*/
	public static ArrayList<Class<? extends ActionTemplatePostcondition>> getAllPostconditionTypesUsableDuringEncounter(){
		ArrayList<Class<? extends ActionTemplatePostcondition>> al = new ArrayList<>();
		for (Class<? extends ActionTemplatePostcondition> clazz: getAllPostconditionTypes())
			if (canUseDuringEncounters(clazz))
				al.add(clazz);
		return al;
	}

	/** Get all Postcondition classes that can be used between resource encounter*/
	public static ArrayList<Class<? extends ActionTemplatePostcondition>> getAllPostconditionTypesUsableBetweenEncounter(){
		ArrayList<Class<? extends ActionTemplatePostcondition>> al = new ArrayList<>();
		for (Class<? extends ActionTemplatePostcondition> clazz: getAllPostconditionTypes())
			if (canUseBetweenEncounters(clazz))
				al.add(clazz);
		return al;
	}

	/** Get all Postcondition classes that can be used between resource encounter*/
	public static ArrayList<Class<? extends ActionTemplatePostcondition>> getAllPostconditionTypesUsableSettingUpEncounter(){

		ArrayList<Class<? extends ActionTemplatePostcondition>> al = new ArrayList<>();
		for (Class<? extends ActionTemplatePostcondition> clazz: getAllPostconditionTypes())
			if (canUseWhenSettingUpEncounter(clazz))
				al.add(clazz);

		return al;
	}

	/** Get all Postcondition classes that can be used between resource encounter*/
	public static ArrayList<Class<? extends ActionTemplatePostcondition>> getAllPostconditionTypesUsableDuringMutationPhase(){

		ArrayList<Class<? extends ActionTemplatePostcondition>> al = new ArrayList<>();
		for (Class<? extends ActionTemplatePostcondition> clazz: getAllPostconditionTypes())
			if (canUseDuringMutationPhase(clazz))
				al.add(clazz);

		return al;
	}
	
	/** Create a new ActionPostconditionTemplate of the specified class */
	public static ActionTemplatePostcondition createPostconditionTemplate(Class<? extends ActionTemplatePostcondition> clazz){

		if (clazz == ActionTemplatePostconditionStartEncounter.class)				return new ActionTemplatePostconditionStartEncounter();
		if (clazz == ActionTemplatePostconditionMovePatch.class)					return new ActionTemplatePostconditionMovePatch();

		if (clazz == ActionTemplatePostconditionIncreasePhenotype.class)			return new ActionTemplatePostconditionIncreasePhenotype();
		if (clazz == ActionTemplatePostconditionDecreasePhenotype.class)			return new ActionTemplatePostconditionDecreasePhenotype();
		if (clazz == ActionTemplatePostconditionSetPhenotype.class)					return new ActionTemplatePostconditionSetPhenotype();

		if (clazz == ActionTemplatePostconditionInstantiateObject.class)			return new ActionTemplatePostconditionInstantiateObject();
		if (clazz == ActionTemplatePostconditionInstantiateExtrinsic.class)			return new ActionTemplatePostconditionInstantiateExtrinsic();
		if (clazz == ActionTemplatePostconditionCreateReference.class)				return new ActionTemplatePostconditionCreateReference();
		if (clazz == ActionTemplatePostconditionChangeReference.class)				return new ActionTemplatePostconditionChangeReference();
		if (clazz == ActionTemplatePostconditionSetGameMode.class)					return new ActionTemplatePostconditionSetGameMode();

		if (clazz == ActionTemplatePostconditionSampleCue.class)					return new ActionTemplatePostconditionSampleCue();
		if (clazz == ActionTemplatePostconditionWait.class)							return new ActionTemplatePostconditionWait();
		if (clazz == ActionTemplatePostconditionPostponeWithoutInterruption.class)	return new ActionTemplatePostconditionPostponeWithoutInterruption();
		if (clazz == ActionTemplatePostconditionPostponeWithInterruption.class)		return new ActionTemplatePostconditionPostponeWithInterruption();
		if (clazz == ActionTemplatePostconditionTerminateEncounter.class)			return new ActionTemplatePostconditionTerminateEncounter();
		if (clazz == ActionTemplatePostconditionInterruptEncounter.class)			return new ActionTemplatePostconditionInterruptEncounter();
		if (clazz == ActionTemplatePostconditionConsumeResource.class)				return new ActionTemplatePostconditionConsumeResource();
		if (clazz == ActionTemplatePostconditionApplyExtrinsic.class)				return new ActionTemplatePostconditionApplyExtrinsic();

		if (clazz == ActionTemplatePostconditionChangePatchState.class)				{	throw new UnsupportedOperationException("NOT YET IMPLEMENTED");  }
		if (clazz == ActionTemplatePostconditionChangeResource.class)				{	throw new UnsupportedOperationException("NOT YET IMPLEMENTED");  }
		
		
		if (clazz == ActionTemplatePostconditionStore.class)						return new ActionTemplatePostconditionStore();
		if (clazz == ActionTemplatePostconditionEmptySlot.class)					return new ActionTemplatePostconditionEmptySlot();
		if (clazz == ActionTemplatePostconditionUseCaptiveSlot.class)				return new ActionTemplatePostconditionUseCaptiveSlot();

		throw new IllegalStateException("Unknown postcondition subclass: " + clazz);
	}
	
	/** Does the specified postconditions have necessary preconditions? */
	public static boolean hasNecessaryPrecondition (Class<? extends ActionTemplatePostcondition> clazz) {
		if (clazz == ActionTemplatePostconditionStartEncounter.class)				return false;
		if (clazz == ActionTemplatePostconditionMovePatch.class)					return false;

		if (clazz == ActionTemplatePostconditionIncreasePhenotype.class)			return false;
		if (clazz == ActionTemplatePostconditionDecreasePhenotype.class)			return false;
		if (clazz == ActionTemplatePostconditionSetPhenotype.class)					return false;

		if (clazz == ActionTemplatePostconditionInstantiateObject.class)			return false;
		if (clazz == ActionTemplatePostconditionInstantiateExtrinsic.class)			return false;
		if (clazz == ActionTemplatePostconditionCreateReference.class)				return true;
		if (clazz == ActionTemplatePostconditionChangeReference.class)				return true;
		if (clazz == ActionTemplatePostconditionSetGameMode.class)					return false;

		if (clazz == ActionTemplatePostconditionSampleCue.class)					return true;
		if (clazz == ActionTemplatePostconditionWait.class)							return false;
		if (clazz == ActionTemplatePostconditionPostponeWithoutInterruption.class)	return true;
		if (clazz == ActionTemplatePostconditionPostponeWithInterruption.class)		return true;
		if (clazz == ActionTemplatePostconditionTerminateEncounter.class)			return false;
		if (clazz == ActionTemplatePostconditionInterruptEncounter.class)			return false;
		if (clazz == ActionTemplatePostconditionConsumeResource.class)				return true;
		if (clazz == ActionTemplatePostconditionApplyExtrinsic.class)				return true;

		if (clazz == ActionTemplatePostconditionChangePatchState.class)				{	throw new UnsupportedOperationException("NOT YET IMPLEMENTED");  }
		if (clazz == ActionTemplatePostconditionChangeResource.class)				{	throw new UnsupportedOperationException("NOT YET IMPLEMENTED");  }
		
		
		if (clazz == ActionTemplatePostconditionStore.class)						return true;
		if (clazz == ActionTemplatePostconditionEmptySlot.class)					return false;
		if (clazz == ActionTemplatePostconditionUseCaptiveSlot.class)				return true;
		
		throw new IllegalStateException("Unknown postcondition subclass: " + clazz);
	}
	
	
}

