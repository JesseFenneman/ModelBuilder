package actionElements;

import java.util.ArrayList;

import actionElements.ActionTemplatePrecondition.Operator;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.Instance;
import objectiveElements.InstanceAlias;
import objectiveElements.InstanceReference;
import objectiveElements.InterruptionObjectTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionPostponeWithInterruption extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	
	public ActionTemplatePostconditionPostponeWithInterruption () {
		this.possibleSubjects = View.getView().workspace.getAllDelayInstanceReferences().toArray(new InstanceReference[0]);
		this.possibleQualifiers = View.getView().workspace.getAllInterruptionInstanceReferences().toArray( new InstanceReference[0]);
	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) {
		if (!(newSubject instanceof InstanceReference))
			throw new IllegalArgumentException("Cannot use " + newSubject.getClass() + " as a subject");

		if (newSubject instanceof Instance)
			if (!(((Instance)newSubject).getAbstractObjectiveTemplate() instanceof DelayObjectTemplate))
				throw new IllegalArgumentException("A postponing post condition cannot have a subject of type " + newSubject.getClass());

		if (newSubject instanceof InstanceAlias)
			if (((InstanceAlias)newSubject).getInitialInstance().getAbstractObjectiveTemplate() instanceof DelayObjectTemplate)
				throw new IllegalArgumentException("A postponing post condition cannot have a subject of type " + newSubject.getClass());
		
		this.subject = newSubject;
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {

		if (!(newQualifier instanceof InstanceReference))
			throw new IllegalArgumentException("Cannot use " + newQualifier.getClass() + " as a qualifier for a postpone postcondition");

		
		if (newQualifier instanceof Instance)
			if (!(((Instance)newQualifier).getAbstractObjectiveTemplate() instanceof InterruptionObjectTemplate))
				throw new IllegalArgumentException("A postponing post condition cannot have a qualifier of type " + newQualifier.getClass());

		if (newQualifier instanceof InstanceAlias)
			if (!(((InstanceAlias)newQualifier).getInitialInstance().getAbstractObjectiveTemplate() instanceof InterruptionObjectTemplate))
				throw new IllegalArgumentException("A postponing post condition cannot have a qualifier of type " + newQualifier.getClass());
		
		// Set this qualifier
		this.qualifier = newQualifier;
		return this;
	}
	@Override
	public boolean isComplete() {
		return subject != null && this.qualifier != null;
	}

	@Override
	public String toString() {
		return "Postpone with delay " + ((InstanceReference)subject).getName() + ". Each time step, a " + ((InstanceReference) qualifier).getName() + " might end all the total encounter.";}
	@Override
	public String toSuperShortString() { 
		return "Postpone " + ((InstanceReference)subject).getName()  + " " + ((InstanceReference)qualifier).getName()  ;}

	@Override
	public boolean containsInstanceReference(InstanceReference ref) {
		if (this.subject == ref)
			return true;
		if (qualifier == ref)
			return true;
		return false;
	}
	
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();
		ActionTemplatePreconditionSuccessfulInstantiation pre = new ActionTemplatePreconditionSuccessfulInstantiation ();
		pre.setSubject(this.subject);
		pre.setOperator(Operator.TRUE);
		preconditions.add(pre);
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();
		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : preconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;
					break;
				}
			if (!includedInPreconditions)
				return false;
		}
		return true;
	}


	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");
		
		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();
		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : existingPreconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;
					break;
				}
			if (!includedInPreconditions)
				existingPreconditions.add(np);
		}
	}

}
