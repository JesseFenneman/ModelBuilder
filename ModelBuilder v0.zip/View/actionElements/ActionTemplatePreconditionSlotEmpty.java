package actionElements;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionSlotEmpty implements ActionTemplatePrecondition, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	private AbstractPhenotypeSlotTemplate subject;
	private AbstractPhenotypeSlotTemplate[] possibleSubjects;
	private Operator operator;
	
	public ActionTemplatePreconditionSlotEmpty (){
		this.possibleSubjects = View.getView().workspace.getAllPhenotypeSlots().toArray(new AbstractPhenotypeSlotTemplate[0]);
	}
	
	//// SUBJECT
	@Override
	public AbstractPhenotypeSlotTemplate getSubject() {
		return subject;
	}

	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) {
		if (!(newSubject instanceof AbstractPhenotypeSlotTemplate))
			throw new IllegalArgumentException("Cannot use an object of type " + newSubject.getClass().getSimpleName() + " as a phenotype slot template");
		
		AbstractPhenotypeSlotTemplate slot = (AbstractPhenotypeSlotTemplate) newSubject;

		if (!View.getView().workspace.getAllPhenotypeSlots().contains(slot))
			throw new IllegalArgumentException("Illegal subject: " + slot + " does not exist in view.");
		
		this.subject = slot;
			
		return this;
	}

	@Override
	public AbstractPhenotypeSlotTemplate[] getPossibleSubjects() {
		return possibleSubjects;
	}

	@Override
	public boolean subjectEquals (Object otherSubject){
		return this.subject == otherSubject;
	}
	
	//// OPERATOR
	@Override
	public Operator getOperator() {
		return operator;
	}
	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in empty slot precondition.");
		return this;
	}
	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{Operator.FILLED, Operator.EMPTY};
	}

	
	
	
	//// TARGET: NULL FOR THIS PRECONDITION
	@Override
	public Object getTarget() {
		return null;
	}
	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		return this;
	}
	@Override
	public Object[] getPossibleTargets() {
		return null;
	}

	
	
	//// COMPLETE
	@Override
	public boolean isComplete() {
		return (subject != null && operator != null);
	}

	@Override
	public String toString(){
		if (operator == Operator.FILLED)
			return("Slot '" + subject.getName() + "' contains any resource");
		if (operator == Operator.EMPTY)
		return("Slot '" + subject.getName() + "' is empty");
		throw new IllegalStateException("Illegal operator: " + operator);
	}
	@Override
	public String toSuperShortString() {
		if (operator == Operator.FILLED)
			return("'" + subject.getName() + "' contains any resource");
		if (operator == Operator.EMPTY)
		return("'" + subject.getName() + "' is empty");
		throw new IllegalStateException("Illegal operator: " + operator);
	}

	public boolean containsInstanceReference(InstanceReference ref) {return false;}
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return subject == slot;	}
	
	
	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}
}
