package actionElements;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.InstanceReference;
import spatialAndTemporalElements.PatchStateTemplate;
import spatialAndTemporalElements.PatchTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePreconditionLocation implements ActionTemplatePrecondition, Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	private Operator operator;
	private PatchStateTemplate[] possibleTargets;
	private PatchStateTemplate target;
	
	public ActionTemplatePreconditionLocation (){
		possibleTargets = View.getView().workspace.getAllPatchSates().toArray(new PatchStateTemplate[0]);
	}
	
	///// SUBJECTS: NULL FOR LOCATION
	@Override
	public AbstractObjectiveTemplate getSubject() {
		return null;
	}
	@Override
	public AbstractObjectiveTemplate[] getPossibleSubjects() {
		return null;
	}
	@Override
	public ActionTemplatePrecondition setSubject(Object newSubject) { return this;	}

	@Override
	public boolean subjectEquals (Object otherSubject){
		return false;
	}
	
	///// OPERATOR
	@Override
	public Operator getOperator() {
		return operator;
	}
	@Override
	public ActionTemplatePrecondition setOperator(Operator newOperator) {
		List<Operator> permissibleOperators = Arrays.asList(getPossibleOperators());
		if (permissibleOperators.contains(newOperator))
			this.operator = newOperator;
		else 
			throw new IllegalArgumentException("Illegal operator: cannot use " + newOperator + " in location precondition.");
		return this;
	}
	

	@Override
	public Operator[] getPossibleOperators() {
		return new Operator[]{ Operator.EQUALS, Operator.DOES_NOT_EQUAL};		
		
	}
	
	///// TARGET
	@Override
	public Object getTarget() {
		return target;
	}
	@Override
	public ActionTemplatePrecondition setTarget(Object newTarget) {
		if (!(newTarget instanceof PatchStateTemplate))
			throw new IllegalArgumentException("Illegal target: cannot set a " + newTarget.getClass() + " as a location target.");
		
		List<PatchStateTemplate> permissibleValues = Arrays.asList(possibleTargets);
		if (permissibleValues.contains(newTarget))
			this.target = (PatchStateTemplate) newTarget;
		else
			throw new IllegalArgumentException("Illegal target:  " +  ((PatchTemplate) newTarget).getName() + " is not a permissible target");
		return this;
		
	}
	@Override
	public Object[] getPossibleTargets() {
		return possibleTargets;
	}

	/// COMPLETE
	@Override
	public boolean isComplete() {
		return (this.operator != null && this.target != null);
	}


	@Override
	public String toString(){
		if (operator == Operator.EQUALS)
			return("The agent is in location " + target.getName() + " in patch " + target.getPatch().getName());
		return("The agent is NOT in location " + target.getName() + " in patch " + target.getPatch().getName());
		
	}

	@Override
	public String toSuperShortString() {
		if (operator == Operator.EQUALS)
			return("Location: " + target.getPatch().getName()+ ":" + target.getName());
		return("Location: not " + target.getPatch().getName()+ ":" + target.getName());
		
	}

	public boolean containsInstanceReference(InstanceReference ref) {return false;}
	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {	return false;	}
	
	
	@Override
	public boolean equals(ActionTemplatePrecondition otherPrecondition) {
		return ActionTemplatePrecondition.equals(this, otherPrecondition);
	}
}
