package actionElements;

import java.util.ArrayList;
import java.util.Arrays;

import actionElements.ActionTemplatePrecondition.Operator;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.InstanceNull;
import objectiveElements.InstanceReference;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.PhenotypeSlotTemplateCaptiveResource;
import objectiveElements.PhenotypeSlotTemplateDelayedResource;
import objectiveElements.PhenotypeSlotTemplateRecurringResource;
import objectiveElements.ResourceObjectTemplate;
import start.CentralExecutive;
import view.View;

public class ActionTemplatePostconditionStore extends ActionTemplatePostcondition{
	private static final long serialVersionUID = CentralExecutive.programVersion;

	private PhenotypeObjectTemplate affectedPhenotype;
	private PhenotypeObjectTemplate[] permissiblePhenotype;

	private InstanceReference interruption;
	private InstanceReference[] permissibleInterruptions;

	private InstanceReference delay;
	private InstanceReference[] permissibleDelays;

	private int periodicity;


	public ActionTemplatePostconditionStore() {
		this.possibleSubjects = View.getView().workspace.getAllPhenotypeSlots().toArray(new Object[0]);
	}

	/** Returns the affected phenotypic dimension of this postcondition. Can be null. */
	public PhenotypeObjectTemplate getAffectedPhenotype() { return this.affectedPhenotype;}

	/** Returns the affected phenotypic dimension of this postcondition. Can be null. */
	public PhenotypeObjectTemplate[] getPermissiblePhenotypes() { return this.permissiblePhenotype;}

	/** Returns the selected interruption of this postcondition. Can be null if no interruption is selected. */
	public InstanceReference getSelectedInterruption() { return this.interruption;}

	/** Returns a list of permissible interruptions for the selected slot. Can be null. */
	public InstanceReference[] getPermissibleInterruptions() { return this.permissibleInterruptions;}

	/** Returns the selected delay of this postcondition. Can be null if no interruption is selected. */
	public InstanceReference getSelectedDelay() { return this.delay;}

	/** Returns a list of permissible delays for the selected slot. Can be null. */
	public InstanceReference[] getPermissibleDelays() { return this.permissibleDelays;}

	/** Returns the selected delay. Can be null*/
	public int getSelectedPeriodicity() {return this.periodicity;}
	
	@Override
	public boolean containsInstanceReference(InstanceReference ref) {
		if (ref.getAbstractObjectiveTemplate() instanceof ResourceObjectTemplate)
			return (ref == qualifier);
		if (ref.getAbstractObjectiveTemplate() instanceof InterruptionObjectTemplate)
			return (ref == interruption);
		if (ref.getAbstractObjectiveTemplate() instanceof DelayObjectTemplate)
			return (ref == delay);
		return false;
	}

	@Override
	public boolean containsPhenotypeSlot(AbstractPhenotypeSlotTemplate slot) {
		return this.subject == slot;
	}

	@Override
	public ActionTemplatePostcondition setSubject(Object newSubject) { 
		if (!(newSubject instanceof AbstractPhenotypeSlotTemplate))
			throw new IllegalArgumentException("Cannot use " + newSubject.getClass() + " as a Phenotype slot");

		AbstractPhenotypeSlotTemplate s = (AbstractPhenotypeSlotTemplate) newSubject;
		this.subject = s;

		// permissible resources for the selected slot
		ArrayList<InstanceReference> permissibleResources = new ArrayList<>();
		for (InstanceReference r: View.getView().workspace.getAllResourceInstanceReferences())
			if (s.canUseAsResource(r))
				permissibleResources.add(r);
		this.possibleQualifiers = permissibleResources.toArray();

		// Specific for captive: do not require phenotype yet (only when the captive resource is consumed must the user state which phenotypic dimension is affected)
		if (s instanceof PhenotypeSlotTemplateCaptiveResource) {
			this.permissiblePhenotype= null;
		} else {
			// Permissible phenotype dimensions that can be affected by resources in this slot
			ArrayList<PhenotypeObjectTemplate> permissiblePhenotypicDimensions = new ArrayList<>();
			for (PhenotypeObjectTemplate p: View.getView().workspace.getAllPhenotypeObjectsExcludingAge())
				if (s.canUsePhenotype(p))
					permissiblePhenotypicDimensions.add(p);
			this.permissiblePhenotype = (PhenotypeObjectTemplate[]) permissiblePhenotypicDimensions.toArray(new PhenotypeObjectTemplate[0]);
		}

		// Delays
		if (AbstractPhenotypeSlotTemplate.usesDelays(s.getClass())) {
			// permissible delays
			ArrayList<InstanceReference> permissibleDelays = new ArrayList<>();
			for (InstanceReference d: View.getView().workspace.getAllDelayInstanceReferences())
				if (s.canUseAsDelay(d))
					permissibleDelays.add(d);
			this.permissibleDelays= (InstanceReference[]) permissibleDelays.toArray(new InstanceReference[0]);
		}

		// Interruptions
		if (AbstractPhenotypeSlotTemplate.usesInterruptions(s.getClass())) {
			// permissible interruptions
			ArrayList<InstanceReference> permissibleInterruptions = new ArrayList<>();
			for (InstanceReference i: View.getView().workspace.getAllInterruptionInstanceReferences())
				if (s.canUseAsInterruption(i))
					permissibleInterruptions .add(i);
			this.permissibleInterruptions = (InstanceReference[]) permissibleInterruptions .toArray(new InstanceReference[0]);
		}

		this.periodicity = -1;
		return this;
	}

	@Override
	public ActionTemplatePostcondition setQualifier(Object newQualifier) {
		if (!(newQualifier instanceof InstanceReference))
			throw new IllegalArgumentException("Cannot use " + newQualifier.getClass() + " as an instance reference");

		InstanceReference ref = (InstanceReference) newQualifier;
		if (ref.getClassType() != ResourceObjectTemplate.class)
			throw new IllegalArgumentException("Cannot use " + ref.getClassType() + " as an instance reference for resources");

		if (!Arrays.asList(possibleQualifiers).contains(newQualifier))
			throw new IllegalArgumentException("Illegal qualifier: new qualifier is not listed in possible qualifiers");

		this.qualifier=ref;

		return this;
	}


	public ActionTemplatePostcondition setAffectedPhenotypicDimensions(PhenotypeObjectTemplate affected) {
		if (!Arrays.asList(this.permissiblePhenotype).contains(affected))
			throw new IllegalArgumentException("Illegal phenotypic dimension: new affected dimension is not listed in possible qualifiers");

		if (subject instanceof PhenotypeSlotTemplateCaptiveResource)
			throw new IllegalArgumentException("Trying to set a phenotype dimension for a captive resource slot.");

		this.affectedPhenotype=affected;

		return this;
	}

	public ActionTemplatePostcondition setDelay(InstanceReference delay) {
		if (subject instanceof PhenotypeSlotTemplateCaptiveResource || subject instanceof PhenotypeSlotTemplateRecurringResource)
			throw new IllegalArgumentException("Trying to set a delay for a captive resource or recurring resource slot.");

		if (!((AbstractPhenotypeSlotTemplate) subject).canUseAsDelay(delay))
			throw new IllegalArgumentException("Cannot use " + delay+ " in the slot " + subject);

		this.delay=delay;
		return this;
	}

	public ActionTemplatePostcondition setPeriodicity(int period) {
		if (subject instanceof PhenotypeSlotTemplateCaptiveResource || subject instanceof PhenotypeSlotTemplateDelayedResource)
			throw new IllegalArgumentException("Trying to set a periodicity for a captive resource or delayed resource slot.");

		if (period < 1)
			throw new IllegalArgumentException("Cannot use a non-positive value as a periodicity");
		return this;
	}


	public ActionTemplatePostcondition setInterruption(InstanceReference interruption) {
		if (subject instanceof PhenotypeSlotTemplateCaptiveResource )
			throw new IllegalArgumentException("Trying to set an interruption for a captive resource slot.");

		if (!((AbstractPhenotypeSlotTemplate) subject).canUseAsInterruption(interruption))
			throw new IllegalArgumentException("Cannot use " + interruption + " in the slot " + subject);

		this.interruption=interruption;
		return this;
	}


	@Override
	public boolean isComplete() {
		System.err.println("STORE COMPLETE1");
		if (subject == null)
			return false;
		System.err.println("STORE COMPLETE2");
		if (qualifier == null)
			return false;
		System.err.println("STORE COMPLETE3");
		System.err.println("AP: " + this.affectedPhenotype);
		if (this.affectedPhenotype == null)
			return false;
		System.err.println("STORE COMPLETE4");
		AbstractPhenotypeSlotTemplate s = (AbstractPhenotypeSlotTemplate) subject;

		if (s instanceof PhenotypeSlotTemplateCaptiveResource) {
			System.err.println("STORE COMPLETE5");
			return true;
		}
		else if (s instanceof PhenotypeSlotTemplateDelayedResource) {
			if (this.delay == null) {
				System.err.println("STORE COMPLETE6");
				return false;
			}
		}
		else if (s instanceof PhenotypeSlotTemplateRecurringResource) {
			if (this.periodicity==-1) {
				System.err.println("STORE COMPLETE7");
				return false;
			}
		}
		else 
			throw new IllegalStateException("Unknown slot type: " + s);
		return true;
	}

	@Override
	public String toSuperShortString() {
		return "Store '" + ((InstanceReference) this.qualifier).getName() + "' in " + ((AbstractPhenotypeSlotTemplate) subject).getName();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Store '" + ((InstanceReference) this.qualifier).getName() + "' in " + ((AbstractPhenotypeSlotTemplate) subject).getName()+ ". ");
		if (subject instanceof PhenotypeSlotTemplateRecurringResource) {
			sb.append("The resource will be consumed every " + this.periodicity+ " time steps");
			if (!InstanceNull.isNullReference(this.interruption) && interruption != null)
				sb.append(", but each time can be interrupted by a '" + interruption.getName() + "'.");
			else
				sb.append(".");
		}
		
		else if (subject instanceof PhenotypeSlotTemplateCaptiveResource) {
			
		} else if (subject instanceof PhenotypeSlotTemplateDelayedResource) {
			sb.append("The resource will be consumed after delay '" + this.delay.getName() + "'");
			if (!InstanceNull.isNullReference(this.interruption) && interruption != null)
				sb.append(", if there is no interruption '" + interruption.getName() + "'.");
			else
				sb.append(".");
		} else 
			throw new IllegalStateException("Unknown phenotype slot type: " + this.subject);
		
		return sb.toString();
	}
	@Override
	public ArrayList<ActionTemplatePrecondition> generateNecessaryPreconditions() {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");

		ArrayList<ActionTemplatePrecondition> preconditions = new ArrayList<>();

		// If the slot cannot be overwritten: the slot should be empty
		AbstractPhenotypeSlotTemplate s = (AbstractPhenotypeSlotTemplate) subject;
		if (!s.isOverwritable()) {
			ActionTemplatePreconditionSlotEmpty preEmpty = new ActionTemplatePreconditionSlotEmpty ();
			preEmpty.setSubject(this.subject);
			preEmpty.setOperator(Operator.EMPTY);
			preconditions.add(preEmpty);
		}

		// The resource (qualifier) should be successfully instantiated
		ActionTemplatePreconditionSuccessfulInstantiation preResource = new ActionTemplatePreconditionSuccessfulInstantiation ();
		preResource.setSubject(this.qualifier);
		preResource.setOperator(Operator.TRUE);
		preconditions.add(preResource);

		// If there are delays for this slot: the used delay must be instantiated
		if (AbstractPhenotypeSlotTemplate.usesDelays(s.getClass())) {
			ActionTemplatePreconditionSuccessfulInstantiation preDelay = new ActionTemplatePreconditionSuccessfulInstantiation ();
			preDelay.setSubject(this.delay);
			preDelay.setOperator(Operator.TRUE);
			preconditions.add(preDelay);
		}
		return preconditions;
	}

	@Override
	public boolean necessaryPreconditionsPresentIn(ArrayList<ActionTemplatePrecondition> preconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");

		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();
		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : preconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;
					break;
				}
			if (!includedInPreconditions)
				return false;
		}
		return true;
	}

	@Override
	public void addMissingPreconditions(ArrayList<ActionTemplatePrecondition> existingPreconditions) {
		if (!this.isComplete())
			throw new IllegalStateException("Asking to generate necessary preconditions for an incomplete postcondition.");

		ArrayList<ActionTemplatePrecondition> necessaryPreconditions = generateNecessaryPreconditions();
		for (ActionTemplatePrecondition np : necessaryPreconditions) {
			boolean includedInPreconditions = false;
			for (ActionTemplatePrecondition o : existingPreconditions)
				if (np.equals(o)) {
					includedInPreconditions = true;
					break;
				}
			if (!includedInPreconditions)
				existingPreconditions.add(np);
		}

	}

}
