package spatialAndTemporalElements;

import java.io.Serializable;
import java.util.HashMap;

import attributes.AttributeField;
import decimalNumber.DecimalNumber;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import rIntegration.RFunctionContainer;
import start.CentralExecutive;

/** An ObjectOffset is the patch-state specified offset to an object.
 * It contains the original AbstractObjectiveTemplate, a new frequency, 
 * and a new value distribution. Because an object might have multiple
 * RFunctionContainers that store its value (i.e., when it is split over
 * runs), this Offset maps multiple old RFunctionContainers to a new one 
 * (with the new one having the offset applied). Note that the ObjectOffset
 * only stores the new RFunctionContainer for the value distribution(s) and 
 * the new frequency; it does not store the difference between the old and
 * new values (for those exact values, consult the PatchStateTemplate).*/
public class ObjectOffset implements Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	// The patch state to which this offset applies
	private final PatchStateTemplate patchState;
	// The object to which this offset applies
	private final AbstractObjectiveTemplate object;

	// The mapping of the old RFunctionContainer to the new, offset-applied RFunctionContainer
	private final HashMap<RFunctionContainer, RFunctionContainer> oldToNew;
	
	// The new Frequency of the object
	private DecimalNumber offsettedFrequency;
	
	/** Create a new offset to an object. Note that the object cannot be of type PhenotypeObjectTemplate.
	 * Note that this constructors does not add the offsets yet. For that, use addOffsettedValueDistribution() 
	 * and addOffsettedFrequency() */
	protected ObjectOffset(AbstractObjectiveTemplate object, PatchStateTemplate patchState){
		if (object instanceof PhenotypeObjectTemplate)
			throw new IllegalArgumentException("Cannot create an offset to a phenotype.");
		this.object = object;
		this.patchState = patchState;
		
		if (!(object instanceof InterruptionObjectTemplate))	{
			offsettedFrequency = object.getFrequency().clone();
			offsettedFrequency.setRange(0, 1);
		} else
			offsettedFrequency = null;
		
		this.oldToNew = new HashMap<>();
	}
	
	/** Map the original RFunctionContainer that contains the sampling distribution for this object's values 
	 * in the unmodified BaseState to a new RFunctionContainer that contains the sampling distribution with
	 * the offset applied. If such mapping already exists, this function overwrites previous mapping. */
	public void addOffsettedValueDistribution(RFunctionContainer baseStateContainer, RFunctionContainer offsetContainer){
		this.oldToNew.put(baseStateContainer, offsetContainer);
	}
	
	/** Returns the offset RFunctionContainer that results from applying this PatchState's offset to the 
	 * object in the BaseState. That is, it gives the value distribution of this object in this PatchState.
	 * Returns null if no mapping has been set yet for this BaseStateContainer */
	public RFunctionContainer getOffsettedValueDistribution(RFunctionContainer baseStateContainer){
		return oldToNew.get(baseStateContainer);
	}

	/** Adds the offset to this frequency. 
	 * Note 1: this function does nothing for InterruptionObjectTemplate, 
	 * as interruptions to not have frequencies.
	 * Note 2: the offset should already have the offset applied! */
	public void addOffsettedFrequency(DecimalNumber offsettedFrequency){
		if (!(object instanceof InterruptionObjectTemplate))
			this.offsettedFrequency = offsettedFrequency;
	}

	/** Returns this object's frequency with the offset applied*/
	public DecimalNumber getOffsettedFrequency(){
		return offsettedFrequency;
	}
	
	/** Returns true iff all RFunctionContainers in the original object have a new RFunctionContainer with the applied offset*/
	public boolean isComplete (){
		for (RFunctionContainer baseStateContainer : object.getAllSamplingDistributions())
			if (oldToNew.get(baseStateContainer) == null)
				return false;
		return true;
	}
	
	public String toVerboseString(){
		StringBuilder sb = new StringBuilder();
		
		sb.append("An offset for object '" + object.getName() + "' in patch '" + this.patchState.getPatch().getName() + "' in state '" + patchState.getName() + "'.  ");
		if (this.offsettedFrequency != null)
			sb.append("\n\t- The offsetted frequency is: " + offsettedFrequency.toStringWithoutTrailingZeros());
		else 
			sb.append("\n\t- There is no frequency offset. ");
		
		if (oldToNew != null){
			if (oldToNew.size() >0 ){
				sb.append("These are the offsetted distributions:");
				for (RFunctionContainer key : oldToNew.keySet()){
					RFunctionContainer newRFC = oldToNew.get(key);
					
					
					sb.append("\n\t --- " + key.getRFunction().getName()+ ", with arguments: ");
					for (AttributeField af: key.getLoadedArguments())
 						sb.append(af.getName() + "=" + af.getValueString()+ " ");
					sb.append("\t   ---->   \t");
					sb.append(newRFC.getRFunction().getName() + ", with arguments: ");
					for (AttributeField af: newRFC.getLoadedArguments())
 						sb.append(af.getName() + "=" + af.getValueString()+ " ");
				}
			}
		} else {
			sb.append("\n\t- There are no value offsets.");
		}
				
		
		return sb.toString();
	}
}
