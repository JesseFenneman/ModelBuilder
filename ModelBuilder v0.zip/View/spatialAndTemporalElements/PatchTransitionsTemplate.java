package spatialAndTemporalElements;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;

import helper.Helper;
import start.CentralExecutive;

/** A patch transition object contains the transitions
 * in which an agent can move spatially between patches. (Not
 * to be confused with a PatchStateTransition objects, which
 * describes temporal state changes within a patch). The default is that
 * an agent CANNOT travel between patches - unless it is registered here
 * specifically that it can.*/
public class PatchTransitionsTemplate implements Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;

	/** A TravelPath is a pair of PatchTemplates, the first
	 * of which is the origin, and the second of which is the
	 * destination */
	private class TravelPath implements Serializable{
		private static final long serialVersionUID = CentralExecutive.programVersion;
		public final PatchTemplate origin;
		public final PatchTemplate destination;

		public TravelPath (PatchTemplate origin, PatchTemplate destination) {
			this.origin = origin;
			this.destination = destination;
		}
	}

	/** A class that stores an origin name and a set of booleans. Used to create a TableView of this object*/
	public class TransitionRow implements Serializable{
		private static final long serialVersionUID = CentralExecutive.programVersion;
		
		public final PatchTemplate origin;
		public final ArrayList<Boolean> connections = new ArrayList<>();
		protected TransitionRow(PatchTemplate patch, PatchTransitionsTemplate transitions){
			this.origin = patch;
			for (PatchTemplate destination : transitions.getOrderedPatches())
				connections.add(transitions.canTravel(origin, destination));
		}
	}

	private final HashMap<TravelPath, Boolean> travelMap;
	private final LinkedHashSet<PatchTemplate> patchesInMap;

	/** Create a new patch transition map that does not include any transitions yet */
	public PatchTransitionsTemplate(){
		this.travelMap = new HashMap<>();
		this.patchesInMap = new LinkedHashSet<>();
	}

	/** Get the travel path that starts in the origin and ends in the destination*/
	private TravelPath getPath(PatchTemplate origin, PatchTemplate destination){
		for (TravelPath path: travelMap.keySet())
			if (path.origin == origin && path.destination == destination)
				return path;
		return null;
	}

	/** Registers a new PatchTemplate. Initially a patch is accessible only every other patch.
	 * Returns false if this patch is already added before.*/
	public boolean addPatch(PatchTemplate newPatch){
		if (patchesInMap.contains(newPatch))
			return false;

		for (PatchTemplate other: patchesInMap){
				travelMap.put(new TravelPath(newPatch, other), true);
				travelMap.put(new TravelPath(other, newPatch), true);
		}
		// Cannot travel to self
		travelMap.put(new TravelPath(newPatch, newPatch), false);

		patchesInMap.add(newPatch);
		return true;
	}

	/** Removes the patch, all paths to this patch, and all paths from this patch.*/
	public void removePatch(PatchTemplate patch){
		patchesInMap.remove(patch);
		Iterator<TravelPath> it = travelMap.keySet().iterator();
		while (it.hasNext()){
			TravelPath path = it.next();
			if (path.origin == patch)
				it.remove();

			else if (path.destination == patch)
				it.remove();
		}
	}

	/** Set the path's traversability. Returns false if either the origin or destination are not
	 * in the travel map yet.*/
	public boolean setPath(PatchTemplate origin, PatchTemplate destination, boolean canTravel){
		if (!patchesInMap.contains(origin) || !patchesInMap.contains(destination))
			return false;

		travelMap.put(getPath(origin, destination), canTravel);
		return true;
	}

	/** Returns true if an agent can travel from the origin to the destination in exactly 1 move.
	 * Returns false if travel is not true, or if either the origin or destination is not mapped yet.*/
	public boolean canTravel(PatchTemplate origin, PatchTemplate destination){
		if (!patchesInMap.contains(origin) || !patchesInMap.contains(destination))
			return false;
		return travelMap.get(getPath(origin, destination));
	}

	/** Returns true if the patch is already known in the map. Returns false otherwise*/
	public boolean mapContains(PatchTemplate patch){
		return patchesInMap.contains(patch);
	}

	/** Returns all destinations b that an agent can reach from a. This ArrayList is not
	 * ordered. */
	public ArrayList<PatchTemplate> getDestinationsAccessibleFrom (PatchTemplate a){
		ArrayList<PatchTemplate> destinations = new ArrayList<>();

		for (TravelPath path : travelMap.keySet())
			if (path.origin == a)
				destinations.add(path.destination);
		return destinations;
	}

	/** Returns all origins b from which an can reach from a. This ArrayList is not ordered. */
	public ArrayList<PatchTemplate> getOriginsLeadingTo(PatchTemplate b){
		ArrayList<PatchTemplate> origins = new ArrayList<>();

		for (TravelPath path : travelMap.keySet())
			if (path.destination == b)
				origins.add(path.origin);
		return origins;

	}

	/** Returns a 2 dimensional matrix indicating if the path from origin to destination
	 * can be travelled.*/
	public Boolean[][] toBooleanMatrix(){
		Boolean[][] matrix = new Boolean[patchesInMap.size()][patchesInMap.size()];

		ArrayList<PatchTemplate> patches = getOrderedPatches();

		for (int originIndex = 0; originIndex < patchesInMap.size(); originIndex++)
			for (int destinationIndex = 0; destinationIndex < patchesInMap.size(); destinationIndex++)
				matrix[originIndex][destinationIndex] = canTravel(patches.get(originIndex), patches.get(destinationIndex));
		return matrix;
	}

	/** Returns an array that contains the patches, in the same order as toBooleanMatrix*/
	public ArrayList<PatchTemplate> getOrderedPatches(){
		ArrayList<PatchTemplate> patches = new ArrayList<>();
		for (PatchTemplate pt: patchesInMap)
			patches.add(pt);

		return patches;
	}

	/** Returns an array that contains the patch names, in the same order as toBooleanMatrix*/
	public String[] getOrderedPatchNames(){
		ArrayList<PatchTemplate> patches = getOrderedPatches();

		String[] names = new String[patchesInMap.size()];
		for (int i = 0; i < names.length; i ++)
			names[i] = patches.get(i).getName();
		return names;
	}

	public String toString(){

		ArrayList<PatchTemplate> patches = new ArrayList<>();
		ArrayList<String> patchNames = new ArrayList<>();
		int maxStringLength = 0;
		for (PatchTemplate pt: patchesInMap){
			patches.add(pt);
			patchNames.add(pt.getName());
			if (pt.getName().length() > maxStringLength) maxStringLength = pt.getName().length();
		}

		Boolean[][] matrix = toBooleanMatrix();

		StringBuilder sb = new StringBuilder();

		// print the column names
		sb.append(Helper.repString(" ", maxStringLength+2)+"\t");
		for (String h:patchNames){
			sb.append(h);
			sb.append(Helper.repString(" ", maxStringLength - h.length()));
			sb.append("\t");
		}
		sb.append("\n");
		sb.append(Helper.repString("-", maxStringLength+2)+"\t");
		for (@SuppressWarnings("unused") String s:patchNames) sb.append(Helper.repString("-", maxStringLength)+"\t");
		sb.append("\n");

		//Print the body
		// Print the row names first
		for (int r = 0; r < matrix.length; r++)		{
			sb.append(patchNames.get(r) + Helper.repString(" ", maxStringLength - patchNames.get(r).length()) + "||\t");
			for (int c=0; c < patchNames.size(); c++)	{
				String s;
				Boolean entry = matrix[r][c];
				if (entry)
					s = "Yes";
				else
					s = "-";
				String sSpaced = s + Helper.repString(" ", maxStringLength - s.length());
				sb.append(sSpaced + "\t");
			}
			sb.append("\n");

		}

		return sb.toString();

	}

	/** Returns a list of rows to be used in a TableView*/
	public ArrayList<TransitionRow> toRows(){
		ArrayList<TransitionRow> rows = new ArrayList<>();
		for (PatchTemplate pt: patchesInMap)
			rows.add(new TransitionRow(pt, this));
		return rows;

	}
	

}
