
package spatialAndTemporalElements;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import attributes.AttributeField;
import attributes.AttributeField.IncompatibleNumberObjectTypeException;
import beliefElements.AbstractBeliefTemplate;
import decimalNumber.DecimalNumber;
import interfaces_abstractions.ObserverManager;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import rIntegration.RFunctionContainer;
import start.CentralExecutive;
import start.Console;

//TODO: update description: now its a hashmap of RFunctionContainer -> RFunctionContainer for objects.
/** A PatchTemplate represents a spatial area. This area can be in different states over time - represented
 * with a PatchStateTemplate. There is a special PatchTemplate, the BasePatch, that refers to the
 * starting (or 'normal') patch. This PatchTemplate contains a special PatchStateTemplate, the
 * BaseState, that represents the unmodified state.
 *
 * A PatchStateTemplate is a set of four HashMaps that will tell the Model how to 'offset'
 * the BaseStatePatch (i.e., the 'unmodulated' Decision Structure) to create each new patch.
 * Two HashMaps link either an AbstractObjectiveTemplate or an AstractBeliefTemplate
 * to an ObjectOffset or a BeliefOffset, respectively. An object or belief can have, but does not have to,
 * an entry in these HashMaps. If it has an entry, that object or belief differs in that patch state.
 * You can call getOffsetToBelief() or getOffsetToObject() to retrieve the new RFunctionContainer
 * that has the offset applied.
 *
 * Objects
 * The object offsets are relative.
 * If an object is not split over runs (i.e., it only has a single RFunctionContainer to sample values
 * from during runtime), this ArrayList is of size 1. Otherwise, this list will have the same
 * dimensionality as the number of RFunctionContainers as the object.
 *
 * These RFunctionContainers within this ArrayList always have the same RFunction as the object 
 * has in the 'base patch'. However, it will have different arguments. Note that setting an
 * argument (i.e., placing an 'offset' to the patch) might result in a RestrictionViolationException
 * if the new arguments do not match the field restrictions of the RFunction. For instance, suppose
 * that an object's values are sampled from a Normal Distribution with a mean of 0 and SD of 2. Note that SD's
 * in a normal distribution have to be positive. A patch might offset the SD by -1 (resulting in a
 * RFunctionContainter with Mean=0, SD=1). That is fine. However, an SD offset by -2 will result in a
 * RestrictionViolationException. Of course, it is trivial in this case, but it might be less obvious
 * if the Object will be split over runs. For instance, suppose an object's mean with be between -2 and 2, and
 * its SD can have any integer values in the range 4-10. An offset by -4 will result in an Exception as it results
 * in at least one distribution with illegal arguments.  The IncompatibleNumberObjectTypeException from class
 * RFunctionContainer can be ignored.
 *
 * An ObjectOffset is created using setObjectOffset(). Using this offset, we immediately
 * make new RFunctionContainers. For example, suppose that there is an object with values from a normal distribution
 * with mean=0 and sd=2, and that there is a patch offset for mean=0 and sd=sd-1. Rather than storing the offsets
 * (i.e., that the SD should be decreased), we store a new RFunctionContainer for that object with mean=0 and
 * sd=1. However, sometimes we need to know what the 'instructions' (or offset arguments) were - for instance,
 * for displaying purposes. Hence, we also store the arguments to the setObjectOffset and setBeliefOffset function
 * calls (invoked using getObjectOffsetArguments() and getBeliefOffsetArguments() ). However, after constructing
 * the offsets, these arguments are never used in this PatchTemplate.
 
 * Two other HashMaps store the previously used previous input used to create the offsets.
 * These map ObjectiveTemplate or BeliefTemplate to a set of previously used AttributeFields (the offsets) that were
 * used to create the ArrayList of RFunctionContainers above. We store these offsets so that the View knows
 * on a later moment which arguments were used to create the new-function-container-arraylist. Use
 * getLastUsedOffsetArguments() to call these arguments.
 * 
 * Beliefs
 * The belief offset are absolute. The BeliefOffsets contained in a patch come in two flavors. In the first 
 * case, the distribution of an belief's object is known in this patch. In this case there is no learning. In
 * the second case, the distribution is not known in this patch state, and an agent has to learn it by experience.
 * If so, an user can provide a prior for this belief. This prior is a list of the number of observations (i.e.,
 * non-negative integers). These observations denote how often an agent has seen an object of a particular value
 * in its evolutionary or developmental history. More technically, a BeliefOffset contains a HashMap that links
 * a value in an AbstractObjectiveTemplate's domain to a non-negative integer count.    
 * 
 *
 * Note that Phenotypes cannot have an offset (nor a belief)
 *
 */
public class PatchStateTemplate implements Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	protected PatchTemplate patch;
	private String name;

	// The mapping from an AbstractObjectiveTemplate to the offsetted AbstractObjectiveTemplate version.
	private final HashMap<AbstractObjectiveTemplate, ObjectOffset> objectOffsets;

	// The mapping from an ObjectiveTemplate to a set of previously used AttributeFields (the Offsets) that were
	// used to create the ArrayList of RFunctionContainers above. We store these offsets so that the View knows
	// on a later moment which arguments were used to create the new-function-container-arraylist.
	private final HashMap<AbstractObjectiveTemplate, AttributeField[]> objectOffsetValueArguments;
	private final HashMap<AbstractObjectiveTemplate, DecimalNumber> objectOffsetFrequencyArguments;


	// The mapping from an AbstractBeliefTemplate to a SINGLE FunctionContainer
	private final HashMap<AbstractBeliefTemplate, BeliefOffset> beliefOffsets;

	/** Used to create the BaseState*/
	protected PatchStateTemplate(String name){
		this.objectOffsets = new HashMap<>();
		this.objectOffsetValueArguments = new HashMap<>();
		this.objectOffsetFrequencyArguments = new HashMap<>();
		this.beliefOffsets = new HashMap<>();
		this.name = name;
	}

	public PatchStateTemplate(PatchTemplate patch, String name){
		this.patch = patch;
		this.objectOffsets = new HashMap<>();
		this.objectOffsetValueArguments = new HashMap<>();
		this.objectOffsetFrequencyArguments = new HashMap<>();
		this.beliefOffsets = new HashMap<>();
		this.name = name;
	}

	public PatchStateTemplate(PatchTemplate patch){
		this.patch = patch;
		this.objectOffsets = new HashMap<>();
		this.objectOffsetValueArguments = new HashMap<>();
		this.objectOffsetFrequencyArguments = new HashMap<>();
		this.beliefOffsets = new HashMap<>();
		this.name = patch.generateNewPatchStateName();
	}

	public String getName() { return this.name;}

	public void setName(String s) { this.name = s; }

	/**Set a new patch-state-specific offset to the object. The AttributeFields will be used to create
	 *  a new value distribution. The newFrequency (which may be null) will be used to set a new frequency.
	 *  Note that interruptions do not have a frequency. Setting a new frequency will not do anything.
	 *
	 *  This overwrites any existing offsets. The offset array should contain exactly an offset for each
	 *  arguments of the objects's sampling distribution. New FunctionContainers are created, which might
	 *  result in a RestrictionViolationException if the new Containers's arguments are illegal for that
	 *  RFunction.
	 *
	 *   Note 1: there has to be one offset for each arguments required by the object's RFunction. The domain
	 *   argument of the RFunction is ignored. The offset's are matched to the arguments by name - hence, the names
	 *   of the offsets matter! Throws an IllegalArgumentException if there is at least one argument in the RFunction
	 *   that does not have an offset!
	 *   Note 2: the object cannot be a phenotype - setting an offset for a phenotype does not do anything.
	 * @throws RestrictionViolationException */
	public void setObjectOffset(AbstractObjectiveTemplate object, AttributeField[] valueOffsets, DecimalNumber offsetToFrequency) throws RestrictionViolationException{
		if (object instanceof PhenotypeObjectTemplate)
			return;

		// Remove previously existing offsets
		this.removeObjectOffset(object);
		
		// Create a new ObjectOffset
		ObjectOffset newOffset = new ObjectOffset(object, this);

		// Set the frequency offset if required
		if (offsetToFrequency != null){
			this.objectOffsetFrequencyArguments.put(object, offsetToFrequency);
			newOffset.addOffsettedFrequency(object.getFrequency().clone().add(offsetToFrequency));
			this.objectOffsets.put(object, newOffset);
			Console.print("Created a new frequency offset for object: " + object.getName() + " in patch " + this.getName() + ". New offset: " + newOffset.toVerboseString());
		}

		// If there are no value offsets, then we are done here
		if (valueOffsets == null)
			return;

		// Get all the RFunctionContainers for the original object
		ArrayList<RFunctionContainer> originalContainers = object.getAllSamplingDistributions();

		for (RFunctionContainer originalRFC : originalContainers){
			// Clone the original RFC:
			RFunctionContainer newRFC = originalRFC.clone();

			// For each argument in the new RFC that is not the domain:
			// - find the offset with the matching name
			// - Modify the value of the AttributeField
			// - Or throw an Exception if no matching offset could be found
			for (AttributeField arg : newRFC.getLoadedArguments()){
				if (!arg.getName().equalsIgnoreCase("domain")){
					AttributeField offset = null;
					for (AttributeField offsetInput : valueOffsets) 	
						if (arg.getName().equalsIgnoreCase(offsetInput.getName())) offset=offsetInput;
					if (offset == null)
						throw new IllegalArgumentException("Cannot create patch offset for object " + object.getName() + "; missing offset for: " + arg.getName() );
					try {
						arg.setValue(((NumberObjectSingle) arg.getValueCopy()).add((NumberObjectSingle) offset.getValueCopy()) );
					} catch (IncompatibleNumberObjectTypeException e) { ObserverManager.notifyObserversOfError(e);
					}
				}

			}

			// After all arguments in the new function are set: set the new mapping in the ObjectOffset
			newOffset.addOffsettedValueDistribution(originalRFC, newRFC);
		}

		// Check to see if the offset is complete; that is, that there is a new mapping from all old function containers to a new one.
		if (!newOffset.isComplete())
			throw new IllegalStateException("The resulting offset is incomplete; not all old value distributions have a new value distribution");

		// Save the newOffset
		this.objectOffsets.put(object, newOffset);
		this.objectOffsetValueArguments.put(object, valueOffsets);
		Console.print("Created a new value offset for object: " + object.getName() + " in patch " + this.getName() + "\n\n New offset: " + newOffset.toVerboseString());
	}

	/**Set a new patch-state-specific offset to the object, where only the frequency is changed.
	 *  Note that interruptions do not have a frequency. Setting a new frequency will not do anything.
	 *
	 *  This overwrites any existing offsets.
	 * @throws RestrictionViolationException */
	public void setObjectOffset(AbstractObjectiveTemplate object, DecimalNumber offsetToFrequency) throws RestrictionViolationException{
		setObjectOffset(object, null, offsetToFrequency);
	}


	/**Set a new patch-state-specific offset to the object. The AttributeFields will be used to create
	 *  a new value distribution. The newFrequency (which may be null) will be used to set a new frequency.
	 *  Note that interruptions do not have a frequency. Setting a new frequency will not do anything.
	 *
	 *  This overwrites any existing offsets. The offset array should contain exactly an offset for each
	 *  arguments of the objects's sampling distribution. New FunctionContainers are created, which might
	 *  result in a RestrictionViolationException if the new Containers's arguments are illegal for that
	 *  RFunction.
	 *
	 *   Note 1: there has to be one offset for each arguments required by the object's RFunction. The domain
	 *   argument of the RFunction is ignored. The offset's are matched to the arguments by name - hence, the names
	 *   of the offsets matter! Throws an IllegalArgumentException if there is at least one argument in the RFunction
	 *   that does not have an offset!
	 *   Note 2: the object cannot be a phenotype - setting an offset for a phenotype does not do anything.
	 * @throws RestrictionViolationException */
	public void setObjectOffset(AbstractObjectiveTemplate object, AttributeField[] valueOffsets) throws RestrictionViolationException{
		this.setObjectOffset(object, valueOffsets, null);
	}

	/**Set a new patch-state-specific offset to the belief. Specifically, tell the model that the 
	 * distribution of an object is known in this patch - i.e., there is no learning by experience.
	 *  This overwrites any existing offsets. 
	 *  
	 *   A belief can only have an offset if the distribution of values of the object of that belief has to be learned
	 *   by experience. 
	 *   */
	public void setBeliefOffset(AbstractBeliefTemplate belief){
		if (belief.isKnownDistribution())
			throw new IllegalStateException("Trying to set an offset to a belief that is known in the base patch");

		BeliefOffset newOffset = new BeliefOffset(belief);
		
		// Save the new offset
		beliefOffsets.put(belief, newOffset);

		// Save the offset arguments
		this.beliefOffsets.put(belief, newOffset);
		Console.print("Created a new offset for object: " + belief.getObject().getName() + " in patch " + this.getName() + " no longer have to be learned; the distribution is now known.");
	}
	
	/**Set a new patch-state-specific offset to the belief. Specifically, tell the model that the 
	 * distribution of an object is unknown in this patch, and has to be learned by experience.
	 * 
	 * When learning from experience, the agent has a prior belief. This prior belief is given as a 
	 * HashMap that links a value of the object to an Integer that represent the number of times an 
	 * agent has 'seen' that value. If a value of an object is not present in the specified HashMap, 
	 * it is assumed to have been seen 0 times. Note that in the actual algorithm we use Laplace
	 * Smoothing (add-one). Hence, even values seen 0 times are not impossible. 
	 * 
	 *  This overwrites any existing offsets. 
	 *  
	 *  A belief can only have an offset if the distribution of values of the object of that belief has to be learned
	 *  by experience. 
	 *   */
	public void setBeliefOffset(AbstractBeliefTemplate belief, HashMap<DecimalNumber, Integer> newObservations){
		if (belief.isKnownDistribution())
			throw new IllegalStateException("Trying to set an offset to a belief that is known in the base patch");

		BeliefOffset newOffset = new BeliefOffset(belief, newObservations);
		
		// Save the new offset
		beliefOffsets.put(belief, newOffset);

		// Save the offset arguments
		this.beliefOffsets.put(belief, newOffset);
		Console.print("Created a new offset for object: " + belief.getObject().getName() + " in patch " + this.getName() + " now have to be learned. \n \t \t The new belief offset is: " + newOffset);	
		}
	
	
	/** Get the last used arguments for the offset for this object. That is, if the original
	 * object has values from a normal distribution with mean=2 and sd=2, and the offsetted distribution
	 * has mean=4 and sd=1,  this functions returns two AttributeFields with values +2 and -1, respectively.
	 *
	 *  Returns null if there is no offset for this object in this patch or if there is only a frequency offset for this object*/
	public AttributeField[] getValueOffsets (AbstractObjectiveTemplate object) {
		return this.objectOffsetValueArguments.get(object);
		}

	/** Get the last used arguments for the offset for this object. That is, suppose the original
	 * object has values from a normal distribution with mean=2 and sd=2, and the offsetted distribution
	 * has mean=4 and sd=1. This function returns an attributeField with value +2 with the fieldName is 'mean',
	 * returns an attributeField with value -1 if the fieldName is 'sd', and null otherwise. Names are
	 * compared without capitals.
	 *
	 *  Returns null if there is no value offset for this object in this patch.*/
	public AttributeField getValueOffsets (AbstractObjectiveTemplate object, String fieldName) {
		AttributeField[] previousUsedArguments = getValueOffsets(object);
		if (previousUsedArguments == null)
			return null;

		for (AttributeField af: previousUsedArguments)
			if (af.getName().equalsIgnoreCase(fieldName))
				return af;
		return null;
		}

	/** Get the last used modification to the frequency. That is, if the original
	 * object has a frequency of 0.50 in the BaseState, but a frequency of 0.75 in this PatchState,
	 * this function returns a DecimalNumber with a value of +0.25.
	 *  Returns null if there is no frequency offset for this object in this patch.*/
	public DecimalNumber getFrequencyOffsets (AbstractObjectiveTemplate object) {
		return this.objectOffsetFrequencyArguments.get(object);
		}


	/** Get the offset for the belief in this patch state. Note that the offset contains the new distribution - not the difference
	 * between the unmodified and offsetted distributions*/
	public BeliefOffset getOffsettedBelief (AbstractBeliefTemplate belief) { return this.beliefOffsets.get(belief); }

	/** Get the object with the value and frequency offsets applied. That is, if the original
	 * object has values from a normal distribution with mean=2 and sd=2, and the offsetted distributions
	 * has mean=4 and sd=1,  this functions returns two AttributeFields with values +2 and -1, respectively.
	 *
	 *  Returns null if there is no offset for this object in this patch or if there is only a frequency offset for this object*/
	public ObjectOffset getOffsettedObject (AbstractObjectiveTemplate object) {
		return (this.objectOffsets.get(object));
	}

	/** Given an object's original (non-modified) distribution, return the patch-offset distribution */
	public RFunctionContainer getOffsettedObjectForContainer (AbstractObjectiveTemplate object, RFunctionContainer nonModifiedContainer) {
		return (this.objectOffsets.get(object).getOffsettedValueDistribution(nonModifiedContainer));
	}

	/** Returns true iff this PatchState contains an offset for the object*/
	public boolean containsOffsetFor(AbstractObjectiveTemplate object){
		return (this.objectOffsets.containsKey(object));
	}

	/** Returns true iff this PatchState contains an offset for the belief*/
	public boolean containsOffsetFor(AbstractBeliefTemplate belief){
		return (this.beliefOffsets.containsKey(belief));
	}

	/** Remove the Patch offset for this object - including both the frequency and value offsets*/
	public void removeObjectOffset(AbstractObjectiveTemplate o) {
		this.objectOffsets.remove(o);
		this.objectOffsetFrequencyArguments.remove(o);
		this.objectOffsetValueArguments.remove(o);
		Console.print("Removed the offset for object: " + o.getName() + " in patch " + this.getName());
	
	}
	
	/** Remove the Patch offset for the belief for this object - including both the frequency and value offsets*/
	public void removeBeliefOffset(AbstractObjectiveTemplate o) {
		this.removeBeliefOffset(o.getBelief());
	}

	/** Remove the Patch offset for this belief*/
	public void removeBeliefOffset(AbstractBeliefTemplate b) {
		if (b != null){
			this.beliefOffsets.remove(b);
			Console.print("Removed the offset for belief on: " + b.getObject().getName() + " in patch " + this.getName());
		}
	}

	/** Return the patch to which this state belongs*/
	public PatchTemplate getPatch(){
		return this.patch;
	}

	/** Returns true only if there is a value offset registered for the object*/
	public boolean hasValueOffsetFor(AbstractObjectiveTemplate object){
		return (this.getValueOffsets(object) != null);
	}
	
	/** Returns true only if there is a frequency offset registered for the object*/
	public boolean hasFrequencyOffsetFor(AbstractObjectiveTemplate object){
		return (this.getFrequencyOffsets(object) != null);
	}
	
	/** Returns true if there is either a frequency or a value offset for this object */
	public boolean hasOffsetFor (AbstractObjectiveTemplate object){
		return (hasValueOffsetFor(object) || hasFrequencyOffsetFor(object));
	}
	
	/** Returns true only if there is a value offset registered for the object*/
	public boolean hasOffsetFor (AbstractBeliefTemplate belief){
		return (this.beliefOffsets.containsKey(belief));
	}
	
	/** Returns a list containing each object this patch state has an offset for*/
	public ArrayList<AbstractObjectiveTemplate> getAllOffsettedObjects() {
		ArrayList<AbstractObjectiveTemplate> list = new ArrayList<>();
		for (AbstractObjectiveTemplate o : this.objectOffsets.keySet())
			list.add(o);
		return list;
	}
	
	/** Returns a list containing each belief this patch state has an offset for*/
	public ArrayList<AbstractBeliefTemplate> getAllOffsettedBeliefs() {
		ArrayList<AbstractBeliefTemplate> list = new ArrayList<>();
		for (AbstractBeliefTemplate b : this.beliefOffsets.keySet())
			list.add(b);
		return list;
	}
}
