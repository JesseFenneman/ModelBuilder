package spatialAndTemporalElements;

import java.io.Serializable;
import java.util.HashMap;

import beliefElements.AbstractBeliefTemplate;
import decimalNumber.DecimalNumber;
import objectiveElements.AbstractObjectiveTemplate;
import start.CentralExecutive;

/** A BeliefOffset maps an original belief
 * to a belief that is specific for a PatchState. Specifically, 
 * a BeliefOffset contains a boolean and a HashMap. The boolean,
 * called isKnownDistribution, specifies whether an agent knows the
 * distribution of the object of this belief (true), or whether an
 * agent has to learn this distribution from experience (false).
 * 
 * If an agent learns from experience (i.e., !isKnownDistribution),
 * the HashMap contains one entry for every possible value the object
 * might have (i.e., the full object domain). Each of these values is
 * mapped to an integer value, that represents the number of times an
 * agent has 'seen' that object to have that value. Note that in the 
 * runtime algorithm, we use Laplace smoothing (add-one) to transform
 * these counts to a prior distribution. 
 * 
 * Once set, this object cannot be changed.*/
public class BeliefOffset implements Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	private final AbstractBeliefTemplate belief;
	private final boolean isKnownDistribution;
	private final HashMap<DecimalNumber, Integer> patchSpecificObservations;
	
	/** Public constructor for a BeliefOffset for the case that the distribution of an object's value are known
	 * in this patch state (they are not known in the base state)*/
	public BeliefOffset(AbstractBeliefTemplate belief){
		this(belief, true, null);
	}
	
	/** Public constructor for a BeliefOffset for the case that the distribution of an object's value is computed
	 * using the observations in the HashMap. If a value is not present in this HashMap (but is present in the Domain of
	 * an object), then the number of observations is assumed to be 0. */
	public BeliefOffset(AbstractBeliefTemplate belief, HashMap<DecimalNumber, Integer> patchSpecificObservations){
		this(belief, false, patchSpecificObservations);
	}
	
	
	/** Private complete constructor*/
	public BeliefOffset(AbstractBeliefTemplate belief, 
			boolean isKnownDistribution,
			HashMap<DecimalNumber, Integer> patchSpecificObservations){
		
		if (belief.isKnownDistribution())
			throw new IllegalArgumentException("Trying to set a PatchState specific offset to a belief that is set to always be the same as the PatchState's value distribution.");
		this.belief = belief;
		this.isKnownDistribution = isKnownDistribution;
		this.patchSpecificObservations = patchSpecificObservations;
	}
	
	/** Returns the belief associated with this offset*/
	public AbstractBeliefTemplate getBelief () { return this.belief;}
	
	/** Returns the object associated with the belief associated with this object */
	public AbstractObjectiveTemplate getObject() {return this.belief.getObject();}
	
	/** Returns true if the distribution of an object's value is known - i.e., if there is no
	 * learning from experience. Returns false otherwise.*/
	public boolean isKnownDistribution(){
		return isKnownDistribution;
	}
	
	/** Returns true if the distribution of an object's value has to be learned by experience. Returns false otherwise.*/
	public boolean isLearned(){
		return !isKnownDistribution;
	}
	
	
	/** Returns the number of observations in this patch state for the specified value of the
	 * object. If a domain value is not present in the HashMap, nor is there a DecimalNumber with
	 * a similar value, then a 0 is returned. Returns null if a distribution is known. */
	public Integer getPatchSpecificObservations(DecimalNumber objectValue){
		if (this.isKnownDistribution)
		return null; 
		
		Integer count = patchSpecificObservations.get(objectValue);
		
		/* In case the reference is in the HashMap*/
		if (count != null)
			return count;
		
		/* If it is not, we have to see if there is a DecimalNumber with the specified value.*/
		for (DecimalNumber dn: getObject().getDomain())
			if (dn.equals(objectValue, false))
				count = patchSpecificObservations.get(objectValue);
		
		if (count != null)
			return count;

		return (new Integer(0));
	}
	
}
