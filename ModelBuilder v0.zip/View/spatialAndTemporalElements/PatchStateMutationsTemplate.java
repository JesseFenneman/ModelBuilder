package spatialAndTemporalElements;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;

import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import mutationElements.MutationElement;
import start.CentralExecutive;
import view.View;

/** A patch state mutation object is part of a single patch and contains the transitions
 * between the states of this patch over time (not to be confused with a PatchTransitionsTemplate,
 * which describes spatial travel between patches). The default is that
 * states do not change over time.*/
public class PatchStateMutationsTemplate implements Serializable, MutationElement {
	private static final long serialVersionUID = CentralExecutive.programVersion;

	/** A MutationPath is a pair of PatchStateTemplates, the first
	 * of which is the currentState, and the second of which is the
	 * nextState - it describes the probability of the oldState mutating
	 * to the newState */
	private class MutationPath implements Serializable{
		private static final long serialVersionUID = CentralExecutive.programVersion;
		public final PatchStateTemplate currentState;
		public final PatchStateTemplate nextState;

		public MutationPath (PatchStateTemplate currentState, PatchStateTemplate nextState) {
			this.currentState = currentState;
			this.nextState = nextState;
		}
	}

	private final PatchTemplate patch;
	private final HashMap<MutationPath, DecimalNumber> mutationMap;
	private final LinkedHashSet<PatchStateTemplate> patchStatesInMap;

	/** Create a new patch state transition (mutation) map that does not include any transitions yet */
	public PatchStateMutationsTemplate(PatchTemplate patch){
		this.patch = patch;
		this.mutationMap = new HashMap<>();
		this.patchStatesInMap = new LinkedHashSet<>();
	}

	/** Returns the patch to which this mutationsTemplate belongs */
	public PatchTemplate getPatch() { return this.patch;}

	/** Get the mutation (transition) pathway that from the currentState to the nextState */
	private MutationPath getPath(PatchStateTemplate currentState, PatchStateTemplate nextState){
		for (MutationPath path: mutationMap.keySet())
			if (path.currentState == currentState && path.nextState== nextState)
				return path;
		return null;
	}

	/** Registers a new PatchStateTemplate. Initially a patch state never mutates to any
	 * other state (i.e., it stays the same with probability 1). Returns false if this
	 * patch is already added before.*/
	public boolean addPatchState(PatchStateTemplate newState){
		addPatchStateWithoutUpdatingView(newState);
		View.getView().workspace.changedPatch(patch);
		return true;
	}

	/** Registers a new PatchStateTemplate. Initially a patch state never mutates to any
	 * other state (i.e., it stays the same with probability 1). Returns false if this
	 * patch is already added before. Does not notify the Workspace that a change
	 * has been made (should only be used when constructing the starting workspace)*/
	protected boolean addPatchStateWithoutUpdatingView(PatchStateTemplate newState){
		if (patchStatesInMap.contains(newState))
			return false;

		for (PatchStateTemplate other: patchStatesInMap){
				mutationMap.put(new MutationPath(newState, other), new DecimalNumber(0, 0, 1, false));
				mutationMap.put(new MutationPath(other, newState), new DecimalNumber(0, 0, 1, false));
		}
		mutationMap.put(new MutationPath(newState, newState), new DecimalNumber(1, 0, 1, false));

		patchStatesInMap.add(newState);
		
		return true;
	}
	
	/** Removes the patch state, all mutation paths to this state, and all paths from this state.*/
	public void removePatchState(PatchStateTemplate state){
		patchStatesInMap.remove(state);
		Iterator<MutationPath> it = mutationMap.keySet().iterator();
		while (it.hasNext()){
			MutationPath path = it.next();
			if (path.currentState == state)
				it.remove();

			else if (path.nextState == state)
				it.remove();
			View.getView().workspace.changedPatch(patch);
		}
	}

	/** Set the path's mutation probability (i.e., the probability that a state in state currentState
	 * mutates to a nextState state). Returns false if either the currentState or nextState are not
	 * in the travel map yet.*/
	public boolean setPath(PatchStateTemplate currentState, PatchStateTemplate nextState, DecimalNumber mutationProbability){
		if (!patchStatesInMap.contains(currentState) || !patchStatesInMap.contains(nextState))
			return false;

		mutationMap.put(getPath(currentState, nextState), mutationProbability);
		return true;
	}

	/** Gets the path's mutation probability (i.e., the probability that a patch in state currentState
	 * mutates to a nextState state). Returns null if either the origin or destination is not mapped yet.*/
	public DecimalNumber getMutationProbability(PatchStateTemplate currentState, PatchStateTemplate nextState){
		if (!patchStatesInMap.contains(currentState) || !patchStatesInMap.contains(nextState))
			return null;
		return mutationMap.get(getPath(currentState, nextState));
	}

	/** Returns true if the patch state is already known in the map. Returns false otherwise*/
	public boolean mapContains(PatchStateTemplate state){
		return patchStatesInMap.contains(state);
	}

	/** Returns all next states that the current state has a non-zero mutation probability
	 * of mutating into when the current state is a. This ArrayList is not
	 * ordered. */
	public ArrayList<PatchStateTemplate> getMutationsWhenIn(PatchStateTemplate a){
		ArrayList<PatchStateTemplate> nextStates = new ArrayList<>();

		for (MutationPath path : mutationMap.keySet())
			if (path.currentState == a)
				nextStates.add(path.nextState);
		return nextStates;
	}

	/** Returns all previous states that have a non-zero result in the agent ending up in the currentState. This ArrayList is not ordered. */
	public ArrayList<PatchStateTemplate> getMutationsResultingIn(PatchStateTemplate b){
		ArrayList<PatchStateTemplate> previousStates = new ArrayList<>();

		for (MutationPath path : mutationMap.keySet())
			if (path.nextState == b)
				previousStates.add(path.currentState);
		return previousStates;

	}

	/** Returns an array that contains the states, in the same order as toDecimalNumberMatrix*/
	public ArrayList<PatchStateTemplate> getOrderedPatchStates(){
		ArrayList<PatchStateTemplate> states = new ArrayList<>();
		for (PatchStateTemplate state: patchStatesInMap)
			states.add(state);

		return states;
	}

	/** Returns an array that contains the patch state names, in the same order as toDecimalNumberMatrix*/
	public String[] getOrderedPatchStateNames(){
		ArrayList<PatchStateTemplate> patches = getOrderedPatchStates();

		String[] names = new String[patchStatesInMap.size()];
		for (int i = 0; i < names.length; i ++)
			names[i] = patches.get(i).getName();
		return names;
	}


	/** Returns a Dimensional matrix indicating if the path from origin to destination
	 * can be travelled.*/
	public DecimalNumberMatrix toDecimalNumberMatrix(){
		DecimalNumber[][] matrix = new DecimalNumber[patchStatesInMap.size()][patchStatesInMap.size()];

		ArrayList<PatchStateTemplate> states = getOrderedPatchStates();

		for (int currentIndex = 0; currentIndex < patchStatesInMap.size(); currentIndex++)
			for (int nextIndex = 0; nextIndex < patchStatesInMap.size(); nextIndex++)
				matrix[currentIndex][nextIndex] = getMutationProbability(states.get(currentIndex), states.get(nextIndex));
		
		DecimalNumberMatrix dnm = new DecimalNumberMatrix(matrix);
		dnm.setRowNames(getOrderedPatchStateNames());
		dnm.setColumnNames(getOrderedPatchStateNames());
		return dnm;
	}

	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("The " + patch.name + "'s state can change between " + patchStatesInMap.size() + " states: ");
		
		String[] names = getOrderedPatchStateNames();
		for (int s = 0; s < names.length; s++){
			if (s  == names.length-1)
				sb.append(", and");
			else if (s>0 && s < names.length-1)
				sb.append(", ");
			sb.append(" " + "'"+names[s]+"'");
		}
		return sb.toString();

	}
	
	/** Set all values in this map to match the DecimalNumberMatrix values. Note that patches are compared on the bases of their names (i.e., column/row names).
	 * Throws an IllegalArgumentException if the new and old matrices do not match in dimensions, or the ordering of the two matrices (row and column) is not the same. */
	public void setAll(DecimalNumberMatrix newValues){
		
		// We can create a DecimalNumberMatrix for this object - the DecimalNumber's in that matrix are the same objects as in the hashmap
		DecimalNumberMatrix oldValues = toDecimalNumberMatrix(); 
		
		// Check if the row and column names are the same
		if (oldValues.nrow() != newValues.nrow())
			throw new IllegalArgumentException("Trying to set all values in a PatchStateMutationTemplate: the new values have a different number of rows as the old values.");

		String[] oldRowNames = oldValues.getRowNames();
		String[] newRowNames = newValues.getRowNames();
		for (int row = 0; row < oldValues.nrow(); row++)
			if (!oldRowNames[row].equals(newRowNames[row]))
				throw new IllegalArgumentException("Trying to set all values in a PatchStateMutationTemplate: the original row name " + oldRowNames[row] + " does not match the new row name: " + newRowNames[row]);
			
		if (oldValues.ncol() != newValues.ncol())
			throw new IllegalArgumentException("Trying to set all values in a PatchStateMutationTemplate: the new values have a different number of columns as the old values.");
		
		String[] oldColumnNames = oldValues.getColumnNames();
		String[] newColumnNames = newValues.getColumnNames();
		for (int col = 0; col < oldValues.ncol(); col++)
			if (!oldColumnNames[col].equals(newColumnNames[col]))
				throw new IllegalArgumentException("Trying to set all values in a PatchStateMutationTemplate: the original column name " + oldRowNames[col] + " does not match the new column name: " + newRowNames[col]);
			
		//For each row in newValues: check if they sum to 1.
		for (DecimalNumberArray dna : newValues.rowMatrix())
			if (!dna.sum().equals(new DecimalNumber(1), true))
				throw new IllegalArgumentException("Trying to set all values in a PatchStateMutationTemplate: at least one row does not sum to 1. Row: " + dna);
		
		// Set all values
		for (int r = 0; r < oldValues.nrow(); r++)
			for (int c = 0; c < oldValues.ncol();c++)
				oldValues.setValueAt(r, c, newValues.getValueAt(r, c));

	}

}
