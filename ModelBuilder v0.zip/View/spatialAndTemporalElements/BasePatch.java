package spatialAndTemporalElements;

import java.io.Serializable;

import decimalNumber.DecimalNumber;
import start.CentralExecutive;

/** The BasePatch represents the unmodified spatial area (i.e., the one specified when creating
 * the Decision Structure). The BasePatch contains the BaseState, which is the unmodified
 * decision structure. This state cannot be removed from the BasePatch. There can only be
 * a single BasePatch (i.e., I use a Singleton pattern).*/
public class BasePatch extends PatchTemplate implements Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	// Singleton pattern
	private static BasePatch instance;
	public static BasePatch get(){
		if (instance == null)
			instance = new BasePatch();

		return instance;
	}

	// Private constructor
	private BasePatch() {
		super();
		this.name = "Base patch";
		BaseState.get().patch = this;
		this.temporalStates.add(BaseState.get());
		this.stateMutations.addPatchStateWithoutUpdatingView(BaseState.get());
		this.startingProbability.put(BaseState.get(), new DecimalNumber(1));
	}
	
	@Override
	/** Remove the PatchStateTemplate from this PatchTemplate. Note that no patch will 
	 * be removed if this is the only PatchStateTemplate! Cannot remove the BaseState*/
	public boolean removeState (PatchStateTemplate state){
		if (state == BaseState.get())
			return false;
		if (temporalStates.size() == 1)
			return false;
		temporalStates.remove(state);
		return true;
	}
	
	@Override
	public void setName(String name){	}
	
}