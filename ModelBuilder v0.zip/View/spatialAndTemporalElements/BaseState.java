package spatialAndTemporalElements;

import java.io.Serializable;
import java.util.HashMap;

import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import attributes.AttributeField;
import beliefElements.AbstractBeliefTemplate;
import decimalNumber.DecimalNumber;
import objectiveElements.AbstractObjectiveTemplate;
import rIntegration.RFunctionContainer;
import start.CentralExecutive;

/** The BasePatch is a special type of Patch (i.e., is a Singleton) that denotes the
 * base patch. It is, in essence, the 'null patch' to refer to the unmodified Decision Structure*/
public class BaseState extends PatchStateTemplate implements Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	// Singleton pattern
	private static BaseState instance;
	public static BaseState get(){
		if (instance == null)
			instance = new BaseState();

		return instance;
	}

	// Private constructor
	private BaseState() {
		super("Base state");
	}

	// Override all functions to do nothing

	@Override
	public void setObjectOffset(AbstractObjectiveTemplate object, AttributeField[] valueOffsets, DecimalNumber offsetToFrequency) throws RestrictionViolationException{	}

	@Override
	public void setObjectOffset(AbstractObjectiveTemplate object, DecimalNumber offsetToFrequency) throws RestrictionViolationException{
		return;
	}

	@Override
	public void setObjectOffset(AbstractObjectiveTemplate object, AttributeField[] valueOffsets) throws RestrictionViolationException{
		return;
	}

	@Override
	public void setBeliefOffset(AbstractBeliefTemplate belief){}

	@Override
	public void setBeliefOffset(AbstractBeliefTemplate belief, HashMap<DecimalNumber, Integer> newObservations){}

	@Override
	public AttributeField[] getValueOffsets (AbstractObjectiveTemplate object) {
		return null;
	}

	@Override
	public AttributeField getValueOffsets (AbstractObjectiveTemplate object, String fieldName) {
		return null;
	}

	@Override
	public DecimalNumber getFrequencyOffsets (AbstractObjectiveTemplate object) {
		return null;
	}

	@Override
	public BeliefOffset getOffsettedBelief (AbstractBeliefTemplate belief) {
		return null;
	}

	@Override
	public ObjectOffset getOffsettedObject (AbstractObjectiveTemplate object) {
		return null;
	}

	@Override
	public RFunctionContainer getOffsettedObjectForContainer (AbstractObjectiveTemplate object, RFunctionContainer nonModifiedContainer) {
		return null;}

	@Override
	public boolean containsOffsetFor(AbstractObjectiveTemplate object){
		return false;}

	@Override
	public boolean containsOffsetFor(AbstractBeliefTemplate belief){
		return false;}

	@Override
	public void removeObjectOffset(AbstractObjectiveTemplate o) {}

	@Override
	public void removeBeliefOffset(AbstractBeliefTemplate b) {}

	@Override
	public boolean hasValueOffsetFor(AbstractObjectiveTemplate object){
		return false;
	}
	
	@Override
	public boolean hasFrequencyOffsetFor(AbstractObjectiveTemplate object){
		return false;
	}
	
	@Override
	public boolean hasOffsetFor (AbstractObjectiveTemplate object){
		return false;
	}
	
	@Override
	public boolean hasOffsetFor (AbstractBeliefTemplate belief){
		return false;
	}
	
	
}
