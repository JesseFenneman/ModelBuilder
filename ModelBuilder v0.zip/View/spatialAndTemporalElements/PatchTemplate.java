package spatialAndTemporalElements;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import decimalNumber.DecimalNumber;
import start.CentralExecutive;
import view.View;

/** A PatchTemplate represents a spatial area. This area can be in different states over time. The temporal
 * state of a PatchTemplate is represented using PatchStateTemplates. A PatchTemplate contains one or 
 * more PatchStateTemplates. Each PatchStateTemplate contains HashMaps that link a belief or object
 * in the Decision Structure to a new distribution (which is the original distribution plus some patch-state
 * specific offset). 
 * 
 * There is a special PatchTemplate, the BasePatch, that refers to the
 * starting (or 'normal') patch. This PatchTemplate contains a special PatchStateTemplate, the 
 * BaseState, that represents the unmodified state. 
 * 
 * 
 */
public class PatchTemplate implements Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	protected String name;
	
	protected ArrayList<PatchStateTemplate> temporalStates;
	protected HashMap<PatchStateTemplate, DecimalNumber> startingProbability;
	protected PatchStateMutationsTemplate stateMutations;
	
	/** Create a new PatchTemplate without a PatchStateTemplate or name.*/
	protected PatchTemplate(){
		this.temporalStates = new ArrayList<>();
		stateMutations = new PatchStateMutationsTemplate(this);
		startingProbability = new HashMap<>();
	}
	
	/** Create a new PatchTemplate (a spatial area). Automatically
	 * creates a new PatchStateTemplate (a temporal area).*/
	public PatchTemplate(String name){
		this.name = name;
		this.temporalStates = new ArrayList<>();
		stateMutations = new PatchStateMutationsTemplate(this);
		startingProbability = new HashMap<>(); 
		PatchStateTemplate base = new PatchStateTemplate(this, "Base state");
		this.addState(base);
		this.setStartingProbability(base, new DecimalNumber(1));
	}
	
	/** Create and add to this PatchTemplate a new PatchStateTemplate (a temporal state).
	 * Note that if a PatchStateTemplate with the same name already exists, a x is added
	 * after the name of the state to make it an unique name.
	 * 
	 * Also sets the mutation (transitions) probability for this state. Initially a 
	 * state has a probability of 1 of remaining in the same state, and the probability
	 * that the patch starts in that state is 0. 
	 * */
	public void addState (PatchStateTemplate state){
		String newName = state.getName();
		boolean unique = false;
		int suffix = 1;
		while (!unique){
			unique = (getState(newName) == null);
			if (!unique)
				newName = state.getName() + " " + suffix++;
		}
		
		state.setName(newName);
		this.temporalStates.add(state);
		this.startingProbability.put(state, new DecimalNumber(0));
		
		stateMutations.addPatchState(state);
		View.getView().workspace.changedPatch(this);
	}
	
	/** Remove the PatchStateTemplate from this PatchTemplate. Note that no patch will 
	 * be removed if this is the only PatchStateTemplate! Returns true if the state
	 * was removed*/
	public boolean removeState (PatchStateTemplate state){
		if (temporalStates.size() == 1)
			return false;
		temporalStates.remove(state);
		stateMutations.removePatchState(state);
		this.startingProbability.remove(state);
		return true;
	}
	
	/** Returns the state with the name, or null if there is no such name. Names are compared
	 * ignoring case.*/
	public PatchStateTemplate getState(String name){
		for (PatchStateTemplate state: temporalStates)
			if (state.getName().equalsIgnoreCase(name))
				return state;
		return null;
	}
	
	/** Get all PatchStateTemplates (i.e., temporal states) of this PatchTemplate (i.e., a spatial area).
	 * Note that the list itself is a copy - removing a state from the returned list does not remove
	 * that state from the Patch.*/
	@SuppressWarnings("unchecked")
	public ArrayList<PatchStateTemplate> getAllStates(){
		return (ArrayList<PatchStateTemplate>) this.temporalStates.clone();
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getName(){
		return this.name;
	}
	
	/** Returns true if there is a PatchState in this Patch with the specified name. Capitals are ignored */
	public boolean isPatchStateNameUnique(String s){
		for (PatchStateTemplate state: temporalStates)
			if (state.getName().equalsIgnoreCase(s))
				return false;
		return true;
	}
	
	/** Create a new name to give a to a new patch. Usually this is 'New patch'. However, if there already is a patch with this name,
	 * a (x) is added, where x increases from 1 onwards until the name is unique again.*/
	public String generateNewPatchStateName(){
		String newName = "State 0";
		
		boolean unique = false;
		int suffix = 1;
		while (!unique){
			unique = isPatchStateNameUnique(newName);
			if (!unique)
				newName = "State " + suffix++;
		}
		
		return newName;
	}
	
	/** Returns the mutation template for this patch - i.e., a map of how one state can mutate to another over time.*/
	public PatchStateMutationsTemplate getMutations(){
		return this.stateMutations;
	}
	
	/** Returns the starting probability of that state in this patch (i.e., the probability that the patch is in this state
	 * at time 0). Returns null if the state is not a state of this patch*/
	public DecimalNumber getStartingProbability(PatchStateTemplate state) {
		return this.startingProbability.get(state);
	}
	
	/** Sets the starting probability of that state in this patch (i.e., the probability that the patch is in this state
	 * at time 0). Throws an IllegalArgumentException if the state is not registered at this patch. Note: there is no check
	 * after this setting that all probabilities sum to 1. The View should ensure that this is the case (and the workspace
	 * checks whether it is true before creating a model) */
	public void setStartingProbability (PatchStateTemplate state, DecimalNumber newProbability) {
		if (!this.getAllStates().contains(state))
			throw new IllegalArgumentException("Setting starting probability for a state not in this patch. ");
		this.startingProbability.put(state, newProbability);
	}
	
	
}