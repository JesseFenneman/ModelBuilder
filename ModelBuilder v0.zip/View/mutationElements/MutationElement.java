package mutationElements;

/** A MutationElement is either a PhenotypeMutationTemplate (which connects an extrinsic 
 * event to a phenotype), a ObjectMutationTemplate (which changes an object with a 
 * fixed value over time),  or a PatchStateMutationsTemplate (which describes how a patch's
 * state can change over time. This interface has no methods. */
@Deprecated
public interface MutationElement {

}
