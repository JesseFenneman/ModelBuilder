package mutationElements;

import java.io.Serializable;
import java.math.RoundingMode;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper;
import objectiveElements.AbstractObjectiveTemplate;
import rIntegration.RFunction;
import start.CentralExecutive;

/** A MutationTemplate links a phenotype dimension 
 * with an extrinsic event. Nothing more, nothing less.*/
@Deprecated
public class ObjectMutationTemplate implements MutationElement, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public AbstractObjectiveTemplate object;
	
	public enum Type {CONSTANT, PERCENTAGE, DOUBLE_LINEAR, RFUNCTION};
	public final Type type;
	
	// For constant changes, percentages
	public NumberObjectSingle value;
	
	// For RFunction
	public final RFunction rFunction;
	
	/** Create a new MutationTemplate; the object will change with value each time step, either as a percentage or by adding a constant value*/
	private ObjectMutationTemplate (AbstractObjectiveTemplate object, NumberObjectSingle value, Type type, RFunction rFunction){
		if (object == null)
			throw new IllegalArgumentException("Object template is null");
		
		this.object = object;
		this.value = value;
		this.type = type;
		this.rFunction = rFunction;
	}

	/** Create a template for an object mutation that changes the object's value with a fixed number. */
	public static ObjectMutationTemplate createConstantObjectMutation(AbstractObjectiveTemplate object, NumberObjectSingle value) {
		return new ObjectMutationTemplate(object, value, Type.CONSTANT, null);
	}
	
	/** Create a template for an object mutation that changes the object's value with a percentage. */
	public static ObjectMutationTemplate createPercentageObjectMutation(AbstractObjectiveTemplate object, NumberObjectSingle value) {
		return new ObjectMutationTemplate(object, value, Type.PERCENTAGE, null);
	}
	
	/** Create a template for an object mutation that changes the object's value such that it doubles after the specified number of time steps,
	 * and grows linear in between*/
	public static ObjectMutationTemplate createDoubleLinearObjectMutation(AbstractObjectiveTemplate object, NumberObjectSingle timeSteps) {
		if (!Helper.isInteger(timeSteps.toPlainString()))
			throw new IllegalArgumentException("Time should be an integer. Current value: " + timeSteps.toPlainString());
		if (Helper.isNegativeInteger(timeSteps.toPlainString()))
			throw new IllegalArgumentException("Time cannot be negative. Current value: "+ timeSteps.toPlainString());
		return new ObjectMutationTemplate(object, timeSteps, Type.DOUBLE_LINEAR, null);
	}
	
	/** Create a template for an object mutation that changes the object's value based on the OBJECTMUTATION Rfunction*/
	public static ObjectMutationTemplate createRFunctionObjectMutation(AbstractObjectiveTemplate object, RFunction rFunction) {
		// Check if the RFunction is indeed an OBJECTMUTATION function
		boolean foundCorrectTag = false;
		for (String s: rFunction.getTagsCopy())
			if (s.equalsIgnoreCase("OBJECTMUTATION"))
				foundCorrectTag = true;
		if (!foundCorrectTag)
			throw new IllegalArgumentException("The specified RFunction does not have the OBJECTMUTATIONTAG");
		
		// Check if the rFunction has five arguments for the five parameters of the OBJECTMUTATION function:
				// 1. Value at start of encounter
				// 2. Number of time steps
				// 3. Minimum possible value
				// 4. Maximum possible value
				// 5. Value step size
		if (rFunction.getInputFieldCopy().size()!=5)
			throw new IllegalArgumentException("RFunction does not have 5 arguments. Arguments: " + Helper.arrayListToString(rFunction.getInputFieldCopy()));
		
		return new ObjectMutationTemplate(object, null, Type.RFUNCTION, rFunction);
	}
	

	public String toString(){
		switch (type) {
		case CONSTANT: 
			return "Each time step, a " + object.getName() + " changes value with " + value.toStringWithoutTrailingZeros();
		case PERCENTAGE:
			return "Each time step, a " + object.getName() + " value changes with " + value.toStringWithoutTrailingZeros() + "%";
		case DOUBLE_LINEAR:
			return "Each time step, a " + object.getName() + " value changes increases with a fixed value, such that it's value is doubled after " + value.toInt(RoundingMode.UNNECESSARY) + " time steps.";
		case RFUNCTION:
			return "Each time step, a " + object.getName() + " value changes according to the '" + rFunction.getName() + "' function. ";
		default:
			throw new IllegalStateException("Unknown object mutation type: " + type);
		
		}
		
		
	}
}
