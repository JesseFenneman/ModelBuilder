package mutationElements;

import java.io.Serializable;

import objectiveElements.ExtrinsicObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import start.CentralExecutive;

/** A MutationTemplate links a phenotype dimension 
 * with an extrinsic event. Nothing more, nothing less.*/
@Deprecated
public class PhenotypeMutationTemplate implements MutationElement, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	public PhenotypeObjectTemplate phenotype;
	public ExtrinsicObjectTemplate extrinsic;
	
	/** Create a new MutationTemplate and automatically set the phenotype and extrinsic*/
	public PhenotypeMutationTemplate (PhenotypeObjectTemplate phenotype, ExtrinsicObjectTemplate extrinsic){
		this.phenotype = phenotype;
		this.extrinsic = extrinsic;
	}

	/** Create a new and empty MutationTemplate*/
	public PhenotypeMutationTemplate (){
	}

	public String toString(){
		return "A random " + extrinsic.getName().toLowerCase() + " extrinsic event affects an agent's " + phenotype.getName().toLowerCase();
	}
}
