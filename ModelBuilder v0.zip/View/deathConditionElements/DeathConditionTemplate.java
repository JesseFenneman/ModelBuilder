package deathConditionElements;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import objectiveElements.PhenotypeObjectTemplate;

/** A DeathCondition specifies when an agent dies*/
public class DeathConditionTemplate {
	
	public enum Operator {

		EQUALS("="), 
		DOES_NOT_EQUAL("!="), 
		GREATER_THAN(">"), 
		SMALLER_THAN("<"), 
		GREATER_OR_EQUAL_THAN(">="), 
		SMALLER_OR_EQUAL_THAN("<=");
		private String name;
		private Operator(String name){ this.name = name;}
		public boolean evaluate(){
			return true;
		}
		public String toString() {return name;}
	}
	
	public final PhenotypeObjectTemplate phenotype;
	public final Operator operator;
	public final NumberObjectSingle value;
	
	/** Create a new DeathConditionTemplate. The agent will die if the 
	 * phenotype is [operator] then the value*/
	public DeathConditionTemplate(PhenotypeObjectTemplate phenotype, Operator operator, NumberObjectSingle value){
		this.phenotype = phenotype;
		this.operator = operator;
		this.value= value;
	}

	public String toString(){
		return "An agent dies if its " + phenotype.getName().toLowerCase() + " " + operator + " " + value.toStringWithoutTrailingZeros() ;
	}
}
