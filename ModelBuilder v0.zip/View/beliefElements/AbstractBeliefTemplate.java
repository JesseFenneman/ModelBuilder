package beliefElements;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;

import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import interfaces_abstractions.ObserverManager;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextFlow;
import objectiveElements.AbstractObjectiveTemplate;
import spatialAndTemporalElements.BaseState;
import spatialAndTemporalElements.PatchStateTemplate;
import start.CentralExecutive;
import start.Console;
import view.PopupBelief;
import view.PopupPatchStateBeliefOffset;
import view.View;
import view.View.ViewState;

public abstract class AbstractBeliefTemplate extends VBox implements Serializable, EventHandler<MouseEvent>{
	private static final long serialVersionUID = CentralExecutive.programVersion;

	// The object over which an agent has a belief
	private final AbstractObjectiveTemplate object; 

	// Is the distribution known, or should an agent learn from experience?
	private boolean distributionKnown; 

	// If the distribution is not known, an agent should have a prior. 
	// Because the domain of all objects only consists of discrete values,
	// the belief over it is a multinomial distribution. The prior is therefore
	// a mapping of counts: for each possible domain value, how often has an
	// agent already seen an instance of this object with that value?
	private LinkedHashMap <DecimalNumber, Integer> hashMapObservations ;

	//JAVAFX and JAVAFX related objects
	private transient final static String cssStyleSheetLocation = AbstractBeliefTemplate.class.getResource("../CSSLayout/buttonBeliefElement.css").toExternalForm();
	private transient GridPane grid;
	private transient Label titleLabel;
	private transient TextFlow textFlow;
	public static final double BOX_HEIGHT = 75;


	public AbstractBeliefTemplate(AbstractObjectiveTemplate object){
		this.object = object;
		this.distributionKnown = true;
		this.hashMapObservations = new LinkedHashMap<>();

		this.resetDomain();

		// Set the height/width in the view
		this.setMaxWidth(Double.MAX_VALUE);
		this.setPrefHeight(BOX_HEIGHT);

		// Set the css for this object
		this.getStylesheets().add(cssStyleSheetLocation);
		this.getStyleClass().add("vbox");

		// Set the nodes in for this object
		loadDisplayNodes();

		// When pressed, show a popup depending on the state
		this.setOnMouseClicked(this);
	}

	/** FXML objects are, annoyingly, not serializable and transient. Hence, after loading this object from
	 * disk, we have to reinflate the FXML part */
	public void reinflate(){
		// Set the height/width in the view
		this.setMaxWidth(Double.MAX_VALUE);
		this.setPrefHeight(BOX_HEIGHT);

		// Set the css for this object
		this.getStylesheets().add(cssStyleSheetLocation);
		this.getStyleClass().add("vbox");

		// Set the nodes in for this object
		loadDisplayNodes();

		// When pressed, show a popup depending on the state
		this.setOnMouseClicked(event -> { 

			if (View.getView().getState() == ViewState.DECISION_STRUCTURE) new PopupBelief(event,this);
		});
	}


	/** Set all the nodes in this object for display purposes. Does not 'fill in' the details yet - that is done with UpdateView*/
	private void loadDisplayNodes(){
		// Set the GridPane
		grid = new GridPane();
		grid.setMinHeight(GridPane.USE_COMPUTED_SIZE);
		grid.setPrefHeight(GridPane.USE_COMPUTED_SIZE);
		grid.setMaxHeight(GridPane.USE_COMPUTED_SIZE);
		grid.setMaxWidth(GridPane.USE_COMPUTED_SIZE);
		grid.setMinWidth(GridPane.USE_COMPUTED_SIZE);
		grid.setGridLinesVisible(true);

		RowConstraints row0 = new RowConstraints(25);
		RowConstraints row1 = new RowConstraints();
		row1.setMinHeight(USE_COMPUTED_SIZE);
		row1.setPrefHeight(USE_COMPUTED_SIZE);
		row1.setMaxHeight(USE_COMPUTED_SIZE);
		row1.setVgrow(Priority.ALWAYS);

		ColumnConstraints col = new ColumnConstraints();
		col.setMinWidth(USE_COMPUTED_SIZE);
		col.setPrefWidth(USE_COMPUTED_SIZE);
		col.setMaxWidth(USE_COMPUTED_SIZE);
		col.setHgrow(Priority.ALWAYS);

		grid.getRowConstraints().addAll(row0, row1);
		grid.getColumnConstraints().addAll(col);
		grid.setGridLinesVisible(false);
		VBox.setVgrow(grid, Priority.ALWAYS);
		this.getChildren().add(grid);

		// Set the titleLabel
		titleLabel = new Label("TITLE");
		GridPane.setValignment(titleLabel, VPos.CENTER);
		GridPane.setHalignment(titleLabel, HPos.CENTER);
		titleLabel.getStyleClass().add("titleText");
		grid.add(titleLabel, 0, 0);

		// Set the TextFlow
		textFlow = new TextFlow();
		GridPane.setMargin(textFlow, new Insets(0, 5, 0, 5));
		grid.add(textFlow, 0, 1);
	}



	/** All beliefs are about an object. Returns the object for this belief. */
	public AbstractObjectiveTemplate getObject() { return this.object; }


	/** Set the distribution of the object to be known to the agent. There will be no learning 
	 * from experience. This is the default setting*/
	public void setDistributionKnown(){
		distributionKnown=true;
		this.update();
	}

	/** Set the distribution of the object to be unknown. An agent has to learn this
	 * distribution by experience, separately for each state in each patch*/
	public void setHasToLearnFromExperience(){
		distributionKnown=false;
		this.update();
	}

	/** Returns true if the distribution of this object is known to the agent. Returns
	 * false if the agent has to learn from experience.*/
	public boolean isKnownDistribution(){
		return this.distributionKnown;
	}

	/** Set the prior. This function also sets this belief to 'has to learn from experience'. 
	 * The newObservations is a HashMap that links a value from the object's domain to an 
	 * integer indicating how often the agent has 'seen' and object with this value in the past.
	 * If a value is not included in this HashMap, it's count is set to 0.
	 * 
	 * Note: the actual algorithm uses Laplace Smoothing (add-one smoothing)
	 */
	public void setObservations(HashMap<DecimalNumber, Integer> newObservations) {
		this.setHasToLearnFromExperience();

		// For each value in the domain set:
		for (DecimalNumber domainValue : this.hashMapObservations.keySet()){
			// Is there a new count in newObsevations? 
			// If so, set the count in hashMapObservations to the new count;
			// If not, set the count in hashMapObservations to 0
			if (newObservations.get(domainValue) != null)
				hashMapObservations.put(domainValue, newObservations.get(domainValue));
			else
				hashMapObservations.put(domainValue, 0);
		}
		Console.print("Setting a new list of observations for the belief for object: " + object.getName().toLowerCase() +". New observations:");
		for (DecimalNumber domainValue : this.hashMapObservations.keySet())
			Console.print(domainValue.toStringWithoutTrailingZeros() + " --> " + hashMapObservations.get(domainValue));

		this.update();
	}

	/** Returns null if the distribution is known.
	 * Otherwise, returns for each possible value of the object, the number of 
	 * times times an agent has 'seen' an object with that value*/
	public LinkedHashMap<DecimalNumber, Integer> getObservations(){
		if (distributionKnown)
			return null;
		return this.hashMapObservations;
	}

	/** Returns the number of times the agent has seen an object with the specified value.
	 * Returns null if an agent knows the distribution of objects in all patches - in which
	 * case the prior should be retrieved from the object, not the belief.*/
	public Integer getObservedCount(DecimalNumber objectValue){
		if (distributionKnown)
			return null;

		Integer value = hashMapObservations.get(objectValue);

		if (value != null)
			return value;
		else
			throw new IllegalStateException("Object value: '" + objectValue.toStringWithoutTrailingZeros() + "' not in observation hashmap.");
	}

	/** Call this when the object of this belief has had a change in domain. 
	 * After this domain change, the belief should be completely reset to avoid any 
	 * misspecfication. This function changes the 'domain' of this belief and sets
	 * all observed counts to 0.   */
	public void resetDomain(){
		// Empty the hashmap
		this.hashMapObservations.clear();

		// Add new 0 's for each domain value
		DecimalNumberArray objectDomain = object.getDomain();
		for (DecimalNumber domainValue : objectDomain)
			hashMapObservations.put(domainValue, 0);	
	}


	/** Updates the look of this belief*/
	public void update(){
		// Remove the ID
		this.setId("");


		// Set the title to be the name of this object
		this.titleLabel.setText("Belief: \"" + object.getName().toLowerCase() + "\"");	
		// Set the TextFlow
		textFlow.getChildren().removeAll(textFlow.getChildren());

		// Set the look and feel
		if (View.getView().getState() == ViewState.DECISION_STRUCTURE)
			this.updateDecisionStructure();
		else if (View.getView().getState() == ViewState.PATCH_AND_TIME)
			this.updatePatchAndTime();
		else
			this.updateActionsAndMutations();
	}

	/** Update the objects so that it displays all the information needed for the DECISION STRUCTURE state*/
	protected void updateDecisionStructure(){
		this.setDisable(false);
		if (this.distributionKnown){
			textFlow.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("Agent knows distribution of "+ object.getName().toLowerCase() + " values.", "normalText"));
		} 

		if (!distributionKnown) {
			textFlow.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("Agent has to learn the distribution of " + object.getName().toLowerCase()+ " from experience. ", "normalText"));
		}
	}


	/** Update the objects so that it displays all the information needed for the PATCH AND TIME state*/
	protected void updatePatchAndTime(){
		PatchStateTemplate selectedState = View.getView().getSelectedPatchState();
		if (selectedState == BaseState.get()){
			textFlow.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("You cannot set an offset to a belief in the base state", "normalText"));
			this.setDisable(true);
			return;
		}

		// If the distribution of the object is known, its not possible to set a prior for any patch state
		if (this.isKnownDistribution()){
			textFlow.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("The distribution of resources is already known. There is no learning from experience. ", "normalText"));
			this.setDisable(true);
			return;
		}


		// If there already is an offset, tell the user that an offset can be set
		if (selectedState.hasOffsetFor(this)){
			this.setId("hasPatchOffset");
			textFlow.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("There is a different prior in this patch. Click to view/adjust.", "normalText"));
			this.setDisable(false);
			return;
		}

		// If there is no offset, tell the user that an offset can be set
		this.setId("noPatchOffset");
		textFlow.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("Prior is the same as the base state. Click to set a different prior for this patch state.", "normalText"));
		this.setDisable(false);
		return;

	}

	/** Update the objects so that it displays all the information needed for the ACTIONS AND MUTATIONS state*/
	protected void updateActionsAndMutations(){
		this.updateDecisionStructure();
		this.setDisable(true);
	}
	
	

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		if (this.distributionKnown)
			sb.append("Belief on object: " + this.object.getName().toLowerCase() + ". An agent knows the distribution of values in all patch states. There is no learning from experience.");
		else {
			sb.append("Belief on object: " + this.object.getName().toLowerCase() + ". An agent has to learn the distribution from experience. It's prior is the following counts (note, in the actual algorithm we use Laplace Smoothing (add-one):");
			for (DecimalNumber domainValue : hashMapObservations.keySet())
				sb.append("\n\t" + domainValue.toStringWithoutTrailingZeros() + " --> " + hashMapObservations.get(domainValue));

		}
		return sb.toString();
	}


	
	@Override
 	public void handle(MouseEvent event) {
		if (View.getView().getState() == ViewState.DECISION_STRUCTURE) 
			new PopupBelief(event,this);

 		if (View.getView().getState() == ViewState.PATCH_AND_TIME)
 			if (View.getView().getSelectedPatchState() == BaseState.get())
 				 ObserverManager.makeWarningToast("Cannot set offsets to the base state");
 			 else
 				new PopupPatchStateBeliefOffset(event, this, View.getView().getSelectedPatchState());


 	}
}
