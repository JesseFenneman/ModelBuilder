package beliefElements;

import objectiveElements.AbstractObjectiveTemplate;
import start.CentralExecutive;

public class ResourceBeliefTemplate extends AbstractBeliefTemplate{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public ResourceBeliefTemplate(AbstractObjectiveTemplate object) {
		super(object);
	}

}
