package beliefElements;

import objectiveElements.AbstractObjectiveTemplate;
import start.CentralExecutive;

public class ExtrinsicBeliefTemplate extends AbstractBeliefTemplate{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public ExtrinsicBeliefTemplate(AbstractObjectiveTemplate object) {
		super(object);
	}

}
