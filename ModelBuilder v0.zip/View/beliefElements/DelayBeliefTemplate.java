package beliefElements;

import objectiveElements.AbstractObjectiveTemplate;
import start.CentralExecutive;

public class DelayBeliefTemplate extends AbstractBeliefTemplate {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public DelayBeliefTemplate(AbstractObjectiveTemplate object) {
		super(object);
	}

}
