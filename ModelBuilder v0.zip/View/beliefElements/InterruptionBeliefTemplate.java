package beliefElements;

import objectiveElements.AbstractObjectiveTemplate;
import start.CentralExecutive;

public class InterruptionBeliefTemplate extends AbstractBeliefTemplate {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public InterruptionBeliefTemplate(AbstractObjectiveTemplate object) {
		super(object);
	}

}
