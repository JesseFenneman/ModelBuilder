package FitnessElement;

import objectiveElements.PhenotypeElement;
import rIntegration.RFunction;

/** A FitnessFucntionTemplate is a container for a RFunction.
 * Specifically, it contains a RFunction for the fitness function, and
 * then any number of phenotypic dimensions.*/
public class FitnessFunctionTemplate {

	public final RFunction fitnessFunction;
	public final PhenotypeElement[] args;
	
	/** Create a new FitnessFunctionTemplate. The fitnessFunction must have the 'FITNESSFUNCTION' tag.*/
	public FitnessFunctionTemplate(RFunction fitnessFunction, PhenotypeElement ... args){
		this.fitnessFunction = fitnessFunction;
		boolean includesTag = false;
		for (String s : fitnessFunction.getTagsCopy())
			if (s.equalsIgnoreCase("FITNESSFUNCTION"))
				includesTag = true;
		if (!includesTag)
			throw new IllegalArgumentException("Trying to create a fitness function with something that is not a fitness function.");
		this.args = args;
	}
	
	public String toString(){
		StringBuilder sb = new StringBuilder(fitnessFunction.getName() + "(");
		for (int i = 0 ; i < args.length; i ++){
			sb.append(args[i].getName());
			if (i != args.length-1 && args.length > 1)
				sb.append(", ");
		}
		sb.append(")");
		
		return sb.toString();
	}
}
