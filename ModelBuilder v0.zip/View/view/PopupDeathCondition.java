package view;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import deathConditionElements.DeathConditionTemplate;
import deathConditionElements.DeathConditionTemplate.Operator;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.ObserverManager;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import objectiveElements.PhenotypeObjectTemplate;

public class PopupDeathCondition extends AbstractPopup {

	@FXML public ComboBox<PhenotypeObjectTemplate> comboboxPhenotype;
	@FXML public ComboBox<Operator> comboboxOperator;
	@FXML public ComboBox<NumberObjectSingle> comboboxValue;
	@FXML public Button buttonAdd;

	public PopupDeathCondition(){
		super("fxml_popupAddDeathCondition.fxml", 
				View.getView().getPaneCenterX()-200, 
				View.getView().getPaneCenterY()-52, true);


		// Set the nodes
		setNodes();

		// Set the values in the nodes
		update();

	}

	@Override
	public void setNodes() {
		// Set the combobox for the phenotypes
		comboboxPhenotype.getItems().addAll(View.getView().workspace.getAllPhenotypeObjects());

		// Set how the combobox should represent items
		Callback<ListView<PhenotypeObjectTemplate>, ListCell<PhenotypeObjectTemplate>> phenotypeFactory =
				new  Callback<ListView<PhenotypeObjectTemplate>, ListCell<PhenotypeObjectTemplate>>(){
			@Override
			public ListCell<PhenotypeObjectTemplate> call(
					ListView<PhenotypeObjectTemplate> phen) {
				return new ListCell<PhenotypeObjectTemplate>(){
					@Override
					protected void updateItem(PhenotypeObjectTemplate item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText("An agent's "+ item.getName().toLowerCase() );
						}
					}
				};
			}
		};
		comboboxPhenotype.setCellFactory(phenotypeFactory);
		comboboxPhenotype.setButtonCell(phenotypeFactory.call(null));

		// The operator and value combo boxes should only be visible if a phenotypic dimension is selected
		this.comboboxOperator.visibleProperty().bind(comboboxPhenotype.getSelectionModel().selectedItemProperty().isNotNull());
		this.comboboxValue.visibleProperty().bind(comboboxPhenotype.getSelectionModel().selectedItemProperty().isNotNull());

		// Set the operators
		for (Operator op : DeathConditionTemplate.Operator.values())
			comboboxOperator.getItems().add(op);

		// Whenever a phenotype is selected, set the comboboxValues
		comboboxPhenotype.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			comboboxValue.getItems().removeAll(comboboxValue.getItems());

			if (newValue != null)
				comboboxValue.getItems().addAll(newValue.getDomain().toArray());
		});

		// Set how the values are represented
		Callback<ListView<NumberObjectSingle>, ListCell<NumberObjectSingle>> valueCellFactory =
				new  Callback<ListView<NumberObjectSingle>, ListCell<NumberObjectSingle>>(){
			@Override
			public ListCell<NumberObjectSingle> call(
					ListView<NumberObjectSingle> val) {
				return new ListCell<NumberObjectSingle>(){
					@Override
					protected void updateItem(NumberObjectSingle item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(item.toStringWithoutTrailingZeros());
						}
					}
				};
			}
		};
		comboboxValue.setCellFactory(valueCellFactory);
		comboboxValue.setButtonCell(valueCellFactory.call(null));

		// Set the button to add
		buttonAdd.setOnAction(e -> {
			if (comboboxPhenotype.getSelectionModel().getSelectedItem() == null){
				ObserverManager.makeWarningToast("Please select a phenotypic dimension");
				return;
			}
			
			if (comboboxOperator.getSelectionModel().getSelectedItem() == null){
				ObserverManager.makeWarningToast("Please select an operator");
				return;
			}
				
			if (comboboxValue.getSelectionModel().getSelectedItem() == null){
				ObserverManager.makeWarningToast("Please select a value");
				return;
			}
			View.getView().workspace.addDeathCondition(new DeathConditionTemplate(
					comboboxPhenotype.getSelectionModel().getSelectedItem(),
					comboboxOperator.getSelectionModel().getSelectedItem(),
					comboboxValue.getSelectionModel().getSelectedItem()));
			ObserverManager.makeToast("Succesfully added a death condition");
			close();
		});

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}
}
