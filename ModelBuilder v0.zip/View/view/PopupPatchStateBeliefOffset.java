package view;

import java.util.HashMap;

import beliefElements.AbstractBeliefTemplate;
import decimalNumber.DecimalNumber;
import decimalNumber.SafeDecimalNumberToStringConverter;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.ObserverManager;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;
import javafx.util.converter.IntegerStringConverter;
import spatialAndTemporalElements.BeliefOffset;
import spatialAndTemporalElements.PatchStateTemplate;
import start.Console;

/** */
public class PopupPatchStateBeliefOffset extends AbstractPopup{

	/** A private class to populate the TableView with.
	 * Each row should show the value of the object's domain,
	 * and the corresponding number of observations for that value.*/
	private class TableRow {
		public DecimalNumber objectDomainValue;
		public int observationsInBaseState;
		public int observationsInOffset;
		public TableRow(DecimalNumber objectValue, int observationsInBaseState, int observationsInOffset){
			this.objectDomainValue  = objectValue; 
			this.observationsInBaseState = observationsInBaseState;
			this.observationsInOffset = observationsInOffset;
		}
	}

	@FXML public Label labelTitle;
	@FXML public TableView<TableRow> tableView;
	@FXML public TableColumn<TableRow, DecimalNumber> tableColumnDomainValue;
	@FXML public TableColumn<TableRow, Integer> tableColumnBaseObservations, tableColumnNewObservations;
	@FXML public RadioButton radioButtonKnown, radioButtonLearn;
	@FXML public Button buttonApplyChanges, buttonDelete;

	// A map that connects the name of an attribute of the distribution to the TextField for that attribute
	public ObservableList<TableRow> data;

	private final PatchStateTemplate state;
	private final AbstractBeliefTemplate belief;
	private final BeliefOffset existingOffset;
	
	public PopupPatchStateBeliefOffset(MouseEvent e, AbstractBeliefTemplate belief, PatchStateTemplate state){
		super("fxml_popupPatchStateBeliefOffset.fxml", e, true);
		this.belief = belief;
		this.state = state;
		
		// Create the data for the TableView
		data = FXCollections.observableArrayList();

		// Is there already an offset for this belief?
		existingOffset = state.getOffsettedBelief(belief);
		
		// Get the counts from the unmodified belief, and, if applicable, from an existing offset
		for (DecimalNumber key: belief.getObservations().keySet()){
			int observationsInBaseState = belief.getObservedCount(key);
			int observationsInPatchState;
			if (existingOffset != null)
				if (existingOffset.isLearned())
					observationsInPatchState = existingOffset.getPatchSpecificObservations(key);
				else 
					observationsInPatchState = 0;
			else
				observationsInPatchState = 0;
			data.add(new TableRow (key, observationsInBaseState, observationsInPatchState));
		}

		// Set the nodes
		setNodes();

		// Set the values in the nodes
		update();

		Console.print("Opened a new Popup window for a patch specific offset for belief: " + belief.getObject().getName() + " in patch state: " + state.getName());
	}

	@Override
	public void setNodes() {
		// Set the text on the title label and the RadioButton labels
		if (existingOffset == null){
			labelTitle.setText("Set a patch state specific prior for " + belief.getObject().getName().toLowerCase());
			this.buttonApplyChanges.setText("Create new offset");
			buttonDelete.setVisible(false);
		}
		else
			labelTitle.setText("Modity a patch state specific prior for " + belief.getObject().getName().toLowerCase());
		
		// Set the visibility of the tableView
		tableView.visibleProperty().bind(radioButtonLearn.selectedProperty());
		tableView.managedProperty().bind(radioButtonLearn.selectedProperty());

		// Set the data in the TableView
		tableView.setItems(data);

		////// tableColumnDomainValue
		// Set the header of the first column in the tableView
		tableColumnDomainValue.setText(belief.getObject().getName() + " value");

		// Set the CellValueFactory for tableColumnDomainValue: 
		// this factory determines which DecimalNumber should be shown.
		tableColumnDomainValue.setCellValueFactory(
				new Callback<CellDataFeatures<TableRow, DecimalNumber>, ObservableValue<DecimalNumber>>(){
					@Override
					public ObservableValue<DecimalNumber> call(CellDataFeatures<TableRow, DecimalNumber> t) {
						return new SimpleObjectProperty<>(	t.getValue().objectDomainValue);
					}
				});

		// Set the Cell factory for tableColumnDomainValue
		// How to print a DecimalNumber?
		tableColumnDomainValue.setCellFactory(TextFieldTableCell.forTableColumn(new SafeDecimalNumberToStringConverter().setRemoveTrailingZeros(true)));



		///// tableColumnBaseObservations
		// Set the Cell factory for tableColumnBaseObservations
		// How to print an Integer?
		tableColumnBaseObservations.setCellFactory(TextFieldTableCell.<TableRow, Integer>forTableColumn(new IntegerStringConverter()));

		// Set the CellValueFactory for tableColumnBaseObservations: 
		// Which value to show?
		tableColumnBaseObservations.setCellValueFactory(
				new Callback<CellDataFeatures<TableRow, Integer>, ObservableValue<Integer>>(){
					@Override
					public ObservableValue<Integer> call(CellDataFeatures<TableRow, Integer> t) {
						return new SimpleObjectProperty<>(	t.getValue().observationsInBaseState);
					}
				});


		
		///// tableColumnNewObservations: this is the one column that is editable
		// Set the CellValueFactory: this factory determines which integer should be shown.
		tableColumnNewObservations.setCellValueFactory(
				new Callback<CellDataFeatures<TableRow, Integer>, ObservableValue<Integer>>(){
					@Override
					public ObservableValue<Integer> call(CellDataFeatures<TableRow, Integer> t) {
						return new SimpleObjectProperty<>(	t.getValue().observationsInOffset);
					}
				});

		// Tell Java how to go from a Integer to a string.
		tableColumnNewObservations.setCellFactory(TextFieldTableCell.<TableRow, Integer>forTableColumn(new IntegerStringConverter()));

		tableView.setEditable(true);

		// Tell java how to handle the changes
		tableColumnNewObservations.setOnEditCommit(
				new EventHandler<TableColumn.CellEditEvent<TableRow, Integer>>() {
					@Override
					public void handle(CellEditEvent<TableRow, Integer> t) {
						if (t.getNewValue() >= 0)
							t.getRowValue().observationsInOffset = t.getNewValue();
						else
							ObserverManager.makeWarningToast("Please enter a non-negative integer value");

						t.getTableView().refresh();
					}});

		// When buttonApplyChanges is pressed:
		// 	If the radioButtonLearn is selected: turn the data array list into a hashmap, 
		// 		give that hashmap to the belief, provide a toast, and close this popup
		//  If the radioButtonKnown is selected: tell the belief to set a known distribution,
		//		provide a toast, and close this popup
		buttonApplyChanges.setOnAction(e -> {
			if (radioButtonLearn.isSelected()){
				HashMap<DecimalNumber, Integer> map = new HashMap<>();
				for (TableRow r : data)
					map.put(r.objectDomainValue, r.observationsInOffset);
				state.setBeliefOffset(belief, map);
				ObserverManager.makeToast("Succesfully changed patch state specific belief offset: agent now has to learn from experience in patch state: " + state.getName());
				View.getView().update();
				this.close();
			} else {
				state.setBeliefOffset(belief); // Sets a 'can now directly observe'  offset
				ObserverManager.makeToast("Succesfully changed patch state specific belief offset: agent now knows the distribution in patch state: " + state.getName());
				View.getView().update();
				this.close();
			}
		});

		buttonDelete.setOnAction(e -> {
			state.removeBeliefOffset(this.belief); 
			this.close();
		});
	}

	@Override
	public void update() {
		// If there is a known distribution, only select the top radio button
		if (belief.isKnownDistribution())
			radioButtonKnown.setSelected(true);
		else{
			// Otherwise, set the lower radio button
			radioButtonLearn.setSelected(true);
		}
	}
}
