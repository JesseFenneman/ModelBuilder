package view;


import java.util.ArrayList;
import java.util.Iterator;

import FitnessElement.FitnessFunctionTemplate;
import actionElements.ActionTemplate;
import actionElements.ActionTemplate.ActionType;
import attributes.AttributeField;
import beliefElements.AbstractBeliefTemplate;
import beliefElements.DelayBeliefTemplate;
import beliefElements.ExtrinsicBeliefTemplate;
import beliefElements.InterruptionBeliefTemplate;
import beliefElements.ResourceBeliefTemplate;
import deathConditionElements.DeathConditionTemplate;
import decimalNumber.DecimalNumber;
import helper.Helper;
import interfaces_abstractions.ObserverManager;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate.SlotType;
import objectiveElements.AgeTemplate;
import objectiveElements.CueTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.ExtrinsicObjectTemplate;
import objectiveElements.Instance;
import objectiveElements.InstanceAlias;
import objectiveElements.InstanceReference;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeElement;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.PhenotypeSlotTemplateDelayedResource;
import objectiveElements.ResourceObjectTemplate;
import rIntegration.RFunction;
import rIntegration.RFunctionContainer;
import spatialAndTemporalElements.BasePatch;
import spatialAndTemporalElements.PatchStateTemplate;
import spatialAndTemporalElements.PatchTemplate;
import spatialAndTemporalElements.PatchTransitionsTemplate;
import start.CentralExecutive;
import start.Console;
import staticManagers.ExternalFileManager;
import staticManagers.ExternalFileManager.AssociatedFileExtention;
import staticManagers.ExternalFileManager.FILE_TYPE;

/** A Workspace contains all elements of a model. Basically, this is used
 * to save and load models. 
 * 
 * There are three things that all Workspaces must have:
 * 1. A base patch, which reflects the patch where resources, beliefs, extrinsics, delays, and interruptions are as defined in the decision structure;
 * 2. A base state, which reflects the unmodified state in the base patch;
 * 3. A phenotype called age. */
public class Workspace implements AssociatedFileExtention{
	private static final long serialVersionUID = CentralExecutive.programVersion;

	// Did something change after we saved last time?
	private boolean changedAfterSaving = false;

	// Lists of objects
	private final ArrayList<PhenotypeObjectTemplate> 	phenotypeObjectList;
	private final ArrayList<ResourceObjectTemplate> 	resourceObjectList;
	private final ArrayList<InterruptionObjectTemplate> interruptionObjectList;
	private final ArrayList<DelayObjectTemplate> 		delayObjectList;
	private final ArrayList<ExtrinsicObjectTemplate> 	extrinsicObjectList;
	private final ArrayList<AbstractPhenotypeSlotTemplate> 		phenotypeSlots;
	
	// Lists of beliefs
	private final ArrayList<ResourceBeliefTemplate> 	resourceBeliefList;
	private final ArrayList<InterruptionBeliefTemplate> interruptionBeliefList;
	private final ArrayList<DelayBeliefTemplate> 		delayBeliefList;
	private final ArrayList<ExtrinsicBeliefTemplate> 	extrinsicBeliefList;

	// Patches
	private final ArrayList<PatchTemplate>				patchList;
	private final PatchTransitionsTemplate				patchTransitions;


	// Actions, setup rules, and mutations
	private int maximumLifeTime, maximumCycleTime;
	private final ArrayList<ActionTemplate>				setupEncounterActions;
	private final ArrayList<ActionTemplate>				mutations;
	private final ArrayList<ActionTemplate>				betweenEncounterActions;
	private final ArrayList<ActionTemplate>				duringEncounterActions;
	private final ArrayList<Instance>					instances;
	private final ArrayList<InstanceAlias>				instanceAliases;
	private final ArrayList<String>						gameTypes;

	// Death and fitness
	private FitnessFunctionTemplate 					fitnessFunction;
	private final ArrayList<DeathConditionTemplate>		deathConditionList;
	private DecimalNumber								deathFitness;
	private boolean 									useFitnessFunctionBeforeMaximumAge;

	public Workspace() {
		phenotypeObjectList = new ArrayList<>();
		resourceObjectList = new ArrayList<>();
		interruptionObjectList = new ArrayList<>();
		delayObjectList = new ArrayList<>();
		extrinsicObjectList = new ArrayList<>();
		phenotypeSlots = new ArrayList<>();
		
		resourceBeliefList = new ArrayList<>();
		interruptionBeliefList = new ArrayList<>();
		delayBeliefList = new ArrayList<>();
		extrinsicBeliefList = new ArrayList<>();

		patchList = new ArrayList<>();
		patchTransitions = new PatchTransitionsTemplate();

		duringEncounterActions = new ArrayList<>();
		betweenEncounterActions = new ArrayList<>();
		setupEncounterActions = new ArrayList<>();
		mutations = new ArrayList<>();
		instances= new ArrayList<>();
		instanceAliases = new ArrayList<>();
		gameTypes = new ArrayList<>();
		gameTypes.add("Standard");
	
		deathConditionList = new ArrayList<>();

		// Manually add the base patch and its transitions
		patchList.add(BasePatch.get());
		patchTransitions.addPatch(BasePatch.get());

		// Make sure that the maximum times are positive integers
		maximumLifeTime = 100;
		maximumCycleTime = 10;

		// Manually add the age
		phenotypeObjectList.add(new AgeTemplate());
		this.changedAfterSaving= false;
	}


	/** Tell the workspace that it has been saved - that is, that there are no more changed after the
	 * last time it was saved*/
	public void setSaved(){
		this.changedAfterSaving = false;
	}

	/** Returns true if at least one change has been made after saving this workspace. */
	public boolean isChangedAfterSaving() { return this.changedAfterSaving;}

	/////////////////////////////////////////////////////////////////////////
	/////////////////////// 	Object and beliefs 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////
	/** Add an objectiveTemplate to the workspace. */
	public void addObjectiveTemplate(AbstractObjectiveTemplate newObject){
		Class<?extends AbstractObjectiveTemplate> type = AbstractObjectiveTemplate.objectToClass(newObject);

		if(type == PhenotypeObjectTemplate.class){
			phenotypeObjectList.add((PhenotypeObjectTemplate) newObject);
			View.getView().addPhenotypeObject((PhenotypeObjectTemplate) newObject);
		}

		if(type == ResourceObjectTemplate.class){
			resourceObjectList.add((ResourceObjectTemplate) newObject);
			for (AbstractPhenotypeSlotTemplate slot : this.getAllPhenotypeSlots())
				slot.addResourceType((ResourceObjectTemplate) newObject, true);
			View.getView().addResourceObject((ResourceObjectTemplate) newObject);
		}

		if(type == InterruptionObjectTemplate.class){
			interruptionObjectList.add((InterruptionObjectTemplate) newObject);
			View.getView().addInterruptionObject((InterruptionObjectTemplate) newObject);
		}

		if(type == DelayObjectTemplate.class){
			delayObjectList.add((DelayObjectTemplate) newObject);
			for (AbstractPhenotypeSlotTemplate slot : this.getAllPhenotypeSlots(SlotType.DELAYED_RESOURCE))
				((PhenotypeSlotTemplateDelayedResource)slot).addDelayType((DelayObjectTemplate) newObject, true);
			View.getView().addDelayObject((DelayObjectTemplate) newObject);
		}

		if(type == ExtrinsicObjectTemplate.class){
			extrinsicObjectList.add((ExtrinsicObjectTemplate) newObject);
			View.getView().addExtrinsicObject((ExtrinsicObjectTemplate) newObject);
		}

		Console.print("Added object: " + newObject.getName());

		//Update the view
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}
	
	/** Remove an objectiveTemplate from the workspace. Cannot remove the age. Also removes
	 * all beliefs, actions, and patch specific offsets that contain this object. */
	public void removeObjectiveTemplate(AbstractObjectiveTemplate object){
		if (object instanceof AgeTemplate)
			throw new IllegalArgumentException("Trying to remove the age phenotype.");

		Class<?extends AbstractObjectiveTemplate> type = AbstractObjectiveTemplate.objectToClass(object);

		if(type == PhenotypeObjectTemplate.class){
			phenotypeObjectList.remove((PhenotypeObjectTemplate) object);
			for (AbstractPhenotypeSlotTemplate slot : this.getAllPhenotypeSlots())
				slot.removePhenotypeType((PhenotypeObjectTemplate) object);
			View.getView().removePhenotypeObject((PhenotypeObjectTemplate) object);
			
		}

		if(type == ResourceObjectTemplate.class){
			resourceObjectList.remove((ResourceObjectTemplate) object);
			for (AbstractPhenotypeSlotTemplate slot : this.getAllPhenotypeSlots())
				slot.removeResourceType((ResourceObjectTemplate) object);
			View.getView().removeResourceObject((ResourceObjectTemplate) object);
		}

		if(type == InterruptionObjectTemplate.class){
			interruptionObjectList.remove((InterruptionObjectTemplate) object);
			View.getView().removeInterruptionObject((InterruptionObjectTemplate) object);
		}

		if(type == DelayObjectTemplate.class){
			delayObjectList.remove((DelayObjectTemplate) object);
			for (AbstractPhenotypeSlotTemplate slot : this.getAllPhenotypeSlots(SlotType.DELAYED_RESOURCE))
				((PhenotypeSlotTemplateDelayedResource)slot).removeDelayType((DelayObjectTemplate) object);
			View.getView().removeDelayObject((DelayObjectTemplate) object);
		}

		if(type == ExtrinsicObjectTemplate.class){
			extrinsicObjectList.remove((ExtrinsicObjectTemplate) object);
			View.getView().removeExtrinsicObject((ExtrinsicObjectTemplate) object);
		}

		Console.print("Removed object: " + object.getName());

		// Remove all related elements
		removeAllElementsContainingObject(object);

		//Update the view
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Sets all fields in the originalObject to match the newObject. The two objects must have the same type!
	 * Cannot change the age!
	 * 
	 * If domainChanged is true, all actions, beliefs, and patch specific offsets that include this object will be removed*/
	public void changeObjectiveTemplate(AbstractObjectiveTemplate originalObject, AbstractObjectiveTemplate newObject, boolean changedDomain){
		if (originalObject instanceof AgeTemplate)
			throw new IllegalArgumentException("Trying to change the age phenotype.");

		if (originalObject.getClass() != newObject.getClass())
			throw new IllegalArgumentException("Trying to change an object to a different class of objects.");

		originalObject.copyAllSettings(newObject);

		Console.print("Changed object: " + newObject.getName());


		// If domain changed, remove all elements containing this object
		if (changedDomain)
			removeAllElementsContainingObject(originalObject);


		//Update the view
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Removes all beliefs, actions, and patch specific offsets that contain this object.*/
	public void removeAllElementsContainingObject(AbstractObjectiveTemplate object){
		// Reset the domain in the belief - that is, make the distribution of this object known again
		if (object.getBelief() != null)
			object.getBelief().resetDomain();

		// Remove all actions that contain this object
		for (Iterator<ActionTemplate> it = this.betweenEncounterActions.iterator(); it.hasNext();)
			if (it.next().containsObjectTemplate(object))
				it.remove();

		for (Iterator<ActionTemplate> it = this.duringEncounterActions.iterator(); it.hasNext();)
			if (it.next().containsObjectTemplate(object))
				it.remove();
		
		// Remove all mutations that contain this object
		for (Iterator<ActionTemplate> it = this.setupEncounterActions.iterator(); it.hasNext();)
			if (it.next().containsObjectTemplate(object))
				it.remove();

		for (Iterator<ActionTemplate> it = this.mutations.iterator(); it.hasNext();)
			if (it.next().containsObjectTemplate(object))
				it.remove();


		// Remove all beliefs and object offsets for the patch states
		for (PatchTemplate pt: this.patchList)
			for (PatchStateTemplate state : pt.getAllStates()){
				state.removeObjectOffset(object);
				state.removeBeliefOffset(object);
			}


		// Specifically for phenotype templates: remove death conditions, and fitness function
		if (object instanceof PhenotypeObjectTemplate) {
			for (Iterator<DeathConditionTemplate> it = this.deathConditionList.iterator(); it.hasNext();)
				if (it.next().phenotype ==(PhenotypeObjectTemplate) object)
					it.remove();
			
			if (this.fitnessFunction != null)
				for (PhenotypeElement pheno : this.fitnessFunction.args)
					if (pheno == (PhenotypeObjectTemplate) object)
						this.fitnessFunction = null;
			View.getView().update();
		}

		// Remove all ActionTemplates that have a pre- or postconditions featuring a 
		// reference to this object
		// Find all InstanceReference pointing towards this object
		ArrayList<InstanceReference> refs = new ArrayList<>();
		for (InstanceReference ref : this.instances)
			if (ref.getAbstractObjectiveTemplate() == object)
				refs.add(ref);
		for (InstanceReference ref : this.instanceAliases)
			if (ref.getAbstractObjectiveTemplate() == object)
				refs.add(ref);

		for (InstanceReference ref : refs) {

			for (Iterator<ActionTemplate> it = this.betweenEncounterActions.iterator(); it.hasNext(); ) {
				ActionTemplate a = it.next();
				if (a.containsInstanceReference(ref))
					it.remove();
			}

			for (Iterator<ActionTemplate> it = this.duringEncounterActions.iterator(); it.hasNext(); ) {
				ActionTemplate a = it.next();
				if (a.containsInstanceReference(ref))
					it.remove();
			}

			for (Iterator<ActionTemplate> it = this.setupEncounterActions.iterator(); it.hasNext(); ) {
				ActionTemplate a = it.next();
				if (a.containsInstanceReference(ref))
					it.remove();
			}
			for (Iterator<ActionTemplate> it = this.mutations.iterator(); it.hasNext(); ) {
				ActionTemplate a = it.next();
				if (a.containsInstanceReference(ref))
					it.remove();
			}
		}

		//Update the view
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Removes all beliefs, actions, and patch specific offsets that contain this object.*/
	public void removeAllElementsContainingSlot(AbstractPhenotypeSlotTemplate slot){
	
		// Remove all actions that contain this object
		for (Iterator<ActionTemplate> it = this.betweenEncounterActions.iterator(); it.hasNext();)
			if (it.next().containsPhenotypeSlotTemplate(slot))
				it.remove();

		for (Iterator<ActionTemplate> it = this.duringEncounterActions.iterator(); it.hasNext();)
			if (it.next().containsPhenotypeSlotTemplate(slot))
				it.remove();
		
		// Remove all mutations that contain this object
		for (Iterator<ActionTemplate> it = this.setupEncounterActions.iterator(); it.hasNext();)
			if (it.next().containsPhenotypeSlotTemplate(slot))
				it.remove();

		for (Iterator<ActionTemplate> it = this.mutations.iterator(); it.hasNext();)
			if (it.next().containsPhenotypeSlotTemplate(slot))
				it.remove();

		// Remove fitness function
		if (this.fitnessFunction != null)
			for (PhenotypeElement pheno : this.fitnessFunction.args)
				if (pheno == (PhenotypeElement) slot)
					this.fitnessFunction = null;
		View.getView().update();


		//Update the view
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	
	/** Check if an InstanceReference (either Instance or InstanceAlias) is still used, and remove if it is not*/
	private void refreshInstanceReferences() {
		for (Iterator<Instance> it = instances.iterator() ; it.hasNext();) {
			Instance ref = it.next();

			boolean inUse = false;
			for (ActionTemplate a : betweenEncounterActions)
				if (a.containsInstanceReference(ref))
					inUse=true;
			for (ActionTemplate a : duringEncounterActions)
				if (a.containsInstanceReference(ref))
					inUse=true;
			for (ActionTemplate a : setupEncounterActions)
				if (a.containsInstanceReference(ref))
					inUse=true;
			for (ActionTemplate a : mutations)
				if (a.containsInstanceReference(ref))
					inUse=true;
			if (!inUse)
				it.remove();
		}

		for (Iterator<InstanceAlias> it = instanceAliases.iterator() ; it.hasNext();) {
			InstanceAlias ref = it.next();

			boolean inUse = false;
			for (ActionTemplate a : betweenEncounterActions)
				if (a.containsInstanceReference(ref))
					inUse=true;
			for (ActionTemplate a : duringEncounterActions)
				if (a.containsInstanceReference(ref))
					inUse=true;
			for (ActionTemplate a : setupEncounterActions)
				if (a.containsInstanceReference(ref))
					inUse=true;
			for (ActionTemplate a : mutations)
				if (a.containsInstanceReference(ref))
					inUse=true;
			if (!inUse)
				it.remove();
		}
	}

	/** Removes this beliefs from all patch offsets.*/
	public void removeAllElementsContainingBelief(AbstractBeliefTemplate belief){
		// Remove all beliefs and object offsets for the patch states
		for (PatchTemplate pt: this.patchList)
			for (PatchStateTemplate state : pt.getAllStates()){
				state.removeBeliefOffset(belief);
			}

		//Update the view
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}


	/** Get a list containing all ObjectiveTemplates in the workspace. This list is by passed by reference - changes in the objects in this list
	 * will change the objects in the workspace! */
	public ArrayList<AbstractObjectiveTemplate> getAllObjects(){
		ArrayList<AbstractObjectiveTemplate> objects = new ArrayList<>();

		objects.addAll(phenotypeObjectList);
		objects.addAll(resourceObjectList);
		objects.addAll(interruptionObjectList);
		objects.addAll(delayObjectList);
		objects.addAll(extrinsicObjectList);

		return objects;
	}

	/** Get a list containing all non-phenotype ObjectiveTemplates in the workspace. This list is by passed by reference - changes in the objects in this list
	 * will change the objects in the workspace! */
	public ArrayList<AbstractObjectiveTemplate> getAllNonPhenotypeObjects(){
		ArrayList<AbstractObjectiveTemplate> objects = new ArrayList<>();

		objects.addAll(resourceObjectList);
		objects.addAll(interruptionObjectList);
		objects.addAll(delayObjectList);
		objects.addAll(extrinsicObjectList);

		return objects;
	}

	/** Get a list containing all non-phenotype, non-extrinsic ObjectiveTemplates in the workspace. This list is by passed by reference - changes in the objects in this list
	 * will change the objects in the workspace! */
	public ArrayList<AbstractObjectiveTemplate> getAllResourceInterruptionAndDelayObjects(){
		ArrayList<AbstractObjectiveTemplate> objects = new ArrayList<>();

		objects.addAll(resourceObjectList);
		objects.addAll(interruptionObjectList);
		objects.addAll(delayObjectList);

		return objects;
	}


	/** Returns the AbstractObjectiveTemplate with the specified name. Returns null if no such object exists*/
	public AbstractObjectiveTemplate getObject(String name){
		for (AbstractObjectiveTemplate obj : getAllObjects())
			if (obj.getName().equals(name))
				return obj;

		return null;
	}

	/** Get a list of all cues set to all resource objects*/
	public ArrayList<CueTemplate> getAllCueTemplates(){
		ArrayList<CueTemplate> cues = new ArrayList<>();
		for (AbstractObjectiveTemplate o : getAllObjects())
			if (o.getCueTemplate() != null)
				cues.add(o.getCueTemplate());
		return cues;
	}

	/** Removes all actions that use this CueTemplate. */
	public void removeAllActionsContainingCueTemplate (CueTemplate cueTemplate){
		// Remove all actions that contain this object
		for (Iterator<ActionTemplate> it = this.betweenEncounterActions.iterator(); it.hasNext();)
			if (it.next().containsCueTemplate(cueTemplate))
				it.remove();

		for (Iterator<ActionTemplate> it = this.duringEncounterActions.iterator(); it.hasNext();)
			if (it.next().containsCueTemplate(cueTemplate))
				it.remove();
	}

	/** Updates the lists that contain all beliefs by looking at which belief there are in the objects stored within the workspace.*/
	private void updateBeliefLists(){
		resourceBeliefList.removeAll(resourceBeliefList);
		interruptionBeliefList.removeAll(interruptionBeliefList);
		delayBeliefList.removeAll(delayBeliefList);
		extrinsicBeliefList.removeAll(extrinsicBeliefList);

		for (AbstractObjectiveTemplate o : this.resourceObjectList) 	if (o.getBelief() != null) resourceBeliefList.add((ResourceBeliefTemplate) o.getBelief());
		for (AbstractObjectiveTemplate o : this.delayObjectList) 		if (o.getBelief() != null) delayBeliefList.add( (DelayBeliefTemplate) o.getBelief());
		for (AbstractObjectiveTemplate o : this.interruptionObjectList) if (o.getBelief() != null) interruptionBeliefList.add( (InterruptionBeliefTemplate) o.getBelief());
		for (AbstractObjectiveTemplate o : this.extrinsicObjectList) 	if (o.getBelief() != null) extrinsicBeliefList.add( (ExtrinsicBeliefTemplate) o.getBelief());
	}

	public ArrayList<PhenotypeObjectTemplate> 	 getAllPhenotypeObjects() 		{ return this.phenotypeObjectList;}
	public ArrayList<PhenotypeObjectTemplate> 	 getAllPhenotypeObjectsExcludingAge() 		{ 
		ArrayList<PhenotypeObjectTemplate> list = new ArrayList<>();
		for (PhenotypeObjectTemplate p : phenotypeObjectList)
			if (!(p instanceof AgeTemplate))
				list.add(p);
		return list;
	}

	public ArrayList<ResourceObjectTemplate> 	 getAllResourceObjects() 		{ return this.resourceObjectList;}
	public ArrayList<InterruptionObjectTemplate> getAllInterruptionObjects() 	{ return this.interruptionObjectList;}
	public ArrayList<DelayObjectTemplate> 		 getAllDelayObjects()     		{ return this.delayObjectList;}
	public ArrayList<ExtrinsicObjectTemplate> 	 getAllExtrinsicObjects() 		{ return this.extrinsicObjectList;}

	/** Get a list containing all BeliefTemplates in the workspace. This list is by passed by reference - changes in the beliefs in this list
	 * will change the beliefs in the workspace! */
	public ArrayList<AbstractBeliefTemplate> getAllBeliefs(){
		ArrayList<AbstractBeliefTemplate> beliefs= new ArrayList<>();

		updateBeliefLists();

		beliefs.addAll(resourceBeliefList);
		beliefs.addAll(interruptionBeliefList);
		beliefs.addAll(delayBeliefList);
		beliefs.addAll(extrinsicBeliefList);

		return beliefs;
	}

	
	
	/// Phenotype slots
	/** Get a list containing all phenotype objects and phenotype slots in this workspace.*/
	public ArrayList<PhenotypeElement> getAllPhenotypeElements(){
		ArrayList<PhenotypeElement> els = new ArrayList<>();
		els.addAll(this.getAllPhenotypeObjects());
		els.addAll(this.getAllPhenotypeSlots());
		return els;
	}
	
	/** Get the phenotype slot with the specified name (ignoring caps). Returns null if no such phenotypic slot exists*/
	public AbstractPhenotypeSlotTemplate getPhenotypeSlot(String name){
		for (AbstractPhenotypeSlotTemplate s : this.phenotypeSlots)
			if (s.getName().equalsIgnoreCase(name))
				return s;
		return null;
	}
	/** Get a list containing all phenotype slots in this workspace.*/
	public ArrayList<AbstractPhenotypeSlotTemplate> getAllPhenotypeSlots(){
		return this.phenotypeSlots;
	}
	
	/** Get a list containing all phenotype slots in this workspace that have the specified type.*/
	public ArrayList<AbstractPhenotypeSlotTemplate> getAllPhenotypeSlots(SlotType type){
		ArrayList<AbstractPhenotypeSlotTemplate> list= new ArrayList<>();
		for (AbstractPhenotypeSlotTemplate s: this.phenotypeSlots)
			if (s.getSlotType() == type)
				list.add(s);
		return list;
	}
	
	/** Add a PhenotypeSlotTemplate to this workspace*/
	public void addPhenotypeSlot (AbstractPhenotypeSlotTemplate slot) {
		if (this.getPhenotypeSlot(slot.getName()) != null)
			throw new IllegalStateException("Trying to add a phenotype slot with the name '" + slot.getName() + "'. However, there already is a phenotype slot with that same name in the workspace.");
		this.phenotypeSlots.add(slot);
		
		Console.print("Added slot: " + slot.getName() + "(Class: " + slot.getClass().getSimpleName() + ")");

		//Update the view
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Remove the specified phenotype from the workspace*/
	public void removePhenotypeSlot (AbstractPhenotypeSlotTemplate slot) {
		this.phenotypeSlots.remove(slot);
		
		Console.print("Removed slot: " + slot.getName() + "(Class: " + slot.getClass().getSimpleName() + ")");

		//Update the view
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	
	
	/** FXML objects are, annoyingly, not serializable and therefore transient. Hence, after loading this object from
	 * disk, we have to reinflate the FXML part */
	public void reinflateAllObjectsAndBeliefs(){
		for (AbstractObjectiveTemplate object : this.getAllObjects())
			object.reinflate();
		for (AbstractPhenotypeSlotTemplate slot : this.phenotypeSlots)
			slot.reinflate();
		for (AbstractBeliefTemplate belief : this.getAllBeliefs())
			belief.reinflate();
	}
	/////////////////////////////////////////////////////////////////////////
	/////////////////////// 	Patches and time 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////

	/** Tell the workspace to make a new PatchTemplate and add it to the workspace.
	 * This function automatically harmonizes the view with the workspace. Returns the
	 * newly created patch*/
	public PatchTemplate addNewPatch(){
		PatchTemplate newPatch = new PatchTemplate(generateNewPatchName());
		addPatch(newPatch);
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
		return newPatch;
	}

	/** Add the patch to the workspace*/
	public void addPatch(PatchTemplate patch){
		patchList.add(patch);
		patchTransitions.addPatch(patch);
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Remove the patch from the workspace. Will not remove the BasePatch. */
	public void removePatch(PatchTemplate pt){
		if (pt == BasePatch.get())
			return;
		patchList.remove(pt);
		patchTransitions.removePatch(pt);
		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Returns a patch with that name, or a null if no such patch exists. Capitals are ignored. */
	public PatchTemplate getPatch(String name){
		for (PatchTemplate pt: patchList)
			if (pt.getName().equalsIgnoreCase(name))
				return pt;
		return null;
	}

	/** Returns the PatchTransitions object in which all patch transitions are stored.
	 * Note that these transitions are either true or false, indicating whether an agent
	 * can go from one patch to another (true) or not (false)*/
	public PatchTransitionsTemplate getPatchTransitions(){
		return this.patchTransitions;
	}

	/** Returns an ArrayList containing all patch names in this workspace*/
	public ArrayList<String> getAllPatchNames(){
		ArrayList<String> list = new ArrayList<>();
		for (PatchTemplate pt: patchList)
			list.add(pt.getName());
		return list;
	}

	/** Create a new name to give a to a new patch. Usually this is 'New patch'. However, if there already is a patch with this name,
	 * a (x) is added, where x increases from 1 onwards until the name is unique again.*/
	private String generateNewPatchName(){
		String newName = "Patch 0";

		boolean unique = false;
		int suffix = 1;
		while (!unique){
			unique = isPatchNameUnique(newName);
			if (!unique)
				newName = "Patch " + suffix++;
		}

		return newName;
	}

	/** Returns true if there is no patch with name s (ignores capitals) */
	public boolean isPatchNameUnique(String s){
		boolean unique = true;
		for (String existing: getAllPatchNames())
			if (existing.equalsIgnoreCase(s))
				unique = false;
		return unique;
	}

	/** Get all patches in the workspace*/
	public ArrayList<PatchTemplate> getAllPatches(){
		return this.patchList;
	}

	/** Get a list of all PatchStates in all patches*/
	public ArrayList<PatchStateTemplate> getAllPatchSates(){
		ArrayList<PatchStateTemplate> states = new ArrayList<>();
		for (PatchTemplate pt: patchList)
			states.addAll(pt.getAllStates());
		return states;
	}

	/** Called by a PatchTemplate to inform the workspace that this patch is updated.
	 * Used only because a PatchTemplate might have multiple states, in which case
	 * that patch should be listed in the View's mutations*/
	public void changedPatch(PatchTemplate pt){
		this.harmonizeWithView();
	}
	/////////////////////////////////////////////////////////////////////////////
	/////////////////////// 	Actions and mutations 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////////
	/** Sets the maximum number of time steps that an agent can be alive. If this new maximum is
	 * lower than the maximumCycleTime, the maximumCycleStep is set to be equal to the new value.
	 * Throws an illegalArgumentException if the new value is <= 0. Also changes the AgeTemplate*/
	public void setMaximumLifeTime (int newValue){
		if (newValue <= 0)
			throw new IllegalArgumentException("Trying to set the maximum age to a non-positive number");
		this.maximumLifeTime = newValue;

		// Update the age
		((PhenotypeObjectTemplate) getObject("Age")).update();

		if (newValue < this.maximumCycleTime)
			maximumCycleTime = newValue;

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}
	/** Get the maximum number of time steps the agent will be alive*/
	public int getMaximumLifeTime() {return this.maximumLifeTime;}

	/** Sets the maximum number of time steps that an agent can be in a single encounter. If this new maximum is
	 * higher than the maximumLifeTime, the maximumLifeStep is set to be equal to the new value.
	 * Throws an illegalArgumentException if the new value is <= 0*/
	public void setMaximumCycleTime (int newValue){
		if (newValue <= 0)
			throw new IllegalArgumentException("Trying to set the maximum time spend during a single encounter to a non-positive number");
		this.maximumCycleTime = newValue;

		if (newValue > this.maximumLifeTime)
			maximumLifeTime = newValue;

		// Note that we have changed something after saving
		changedAfterSaving=true;
	} 
	/** Get the maximum number of time steps the agent will be alive*/
	public int getMaximumCycleTime() {return this.maximumCycleTime;}

	/** Add an ActionTemplate. This function automatically determines if it is an between-encounters, during-encounter action, setup encounter mutation, or mutation.*/
	public void addAction(ActionTemplate newAction){
		if (newAction.getType() == ActionType.BETWEEN_ENCOUNTERS)
			this.betweenEncounterActions.add(newAction);
		else if  (newAction.getType() == ActionType.DURING_ENCOUNTER)
			this.duringEncounterActions.add(newAction);
		else if (newAction.getType() == ActionType.SETUP_ENCOUNTER)
			this.setupEncounterActions.add(newAction);
		else if (newAction.getType() == ActionType.MUTATION)
			this.mutations.add(newAction);
		
		Console.print("Added an action: " + newAction);
		harmonizeWithView();
		View.getView().update();
		// Note that we have changed something after saving
		changedAfterSaving=true;

	}
	
	/** Returns a shallow copy of an array list that contains all action that an agent will be able to
	 * take during encounters (i.e., when engaged with a resource)*/
	@SuppressWarnings("unchecked")
	public ArrayList<ActionTemplate> getAllDuringActions(){
		return (ArrayList<ActionTemplate>) this.betweenEncounterActions.clone();
	}
	/** Returns a shallow copy of an array list that contains all action that an agent will be able to
	 * take between encounters (i.e., when not engaged with a resource)*/
	@SuppressWarnings("unchecked")
	public ArrayList<ActionTemplate> getAllBetweenActions(){
		return (ArrayList<ActionTemplate>) this.betweenEncounterActions.clone();
	}

	/** Returns a shallow copy of an array list that contains all action that the environment will take
	 * to set up an encounter. */
	@SuppressWarnings("unchecked")
	public ArrayList<ActionTemplate> getAllEncounterSetupRules(){
		return (ArrayList<ActionTemplate>) this.setupEncounterActions.clone();
	}

	/** Returns a shallow copy of an array list that contains all action that the environment will take
	 * during the mutation phase. */
	@SuppressWarnings("unchecked")
	public ArrayList<ActionTemplate> getAllActionPhaseSetupRules(){
		return (ArrayList<ActionTemplate>) this.mutations.clone();
	}

	/** Returns true if there already is another instance of an object template that has the specified name.
	 * Note: names are compared ignoring case. */
	public boolean containsInstanceWithName(String name) {
		for (Instance ref : this.instances)
			if (ref.getName().equalsIgnoreCase(name))
				return true;
		return false;
	}

	/** Returns true if there already is another instance alias of an object template that has the specified name.
	 * Note: names are compared ignoring case. */
	public boolean containsInstanceAliasWithName(String name) {
		for (InstanceAlias ref : this.instanceAliases)
			if (ref.getName().equalsIgnoreCase(name))
				return true;
		return false;
	}



	////////////////////// Instances, InstanceReferences, and InstanceAliases /////////////////////////////

	/** Returns a shallow copy of an array list that contains all named instances in the workspace */
	@SuppressWarnings("unchecked")
	public ArrayList<Instance> getAllInstances(){
		return (ArrayList<Instance>) this.instances.clone();
	}

	/** Returns a shallow copy of an array list that contains all instanceAliases in the workspace */
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceAlias> getAllInstanceAliases(){
		return (ArrayList<InstanceAlias>) this.instanceAliases.clone();
	}
	/** Returns an array list that contains all instanceReferences in the workspace */
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceReference> getAllInstanceReferences(){
		ArrayList<InstanceReference> references = new ArrayList<>();
		references.addAll(this.instanceAliases);
		references.addAll(this.instances);
		return references;
	}
	/** Get the InstanceReference to a specific instance of an object. Can be either an Instance or
	 * InstanceReference.  Returns null if there is no such InstanceReference. Names are compared without capitalization. */
	public InstanceReference getInstanceOrAlias(String name){
		for (InstanceReference a : instances)
			if (a.getName().equalsIgnoreCase(name))
				return a;
		for (InstanceAlias a : instanceAliases)
			if (a.getName().equalsIgnoreCase(name))
				return a;
		return null;
	}


	/** Returns the Instance with the specified name. Returns null if no Instance with that name exists (yet). 
	 * Note: names are compared ignoring case. (Note: there might be an InstanceAlias with that name!)*/
	public Instance getInstance(String name) {
		for (Instance ref: instances)
			if (ref.getName().equalsIgnoreCase(name))
				return ref;
		return null;
	}

	/** Returns the InstanceAlias with the specified name. Returns null if no InstanceAlias with that name exists (yet). 
	 * Note: names are compared ignoring case. (Note: there might be an Instance with that name!)*/
	public InstanceAlias getInstanceAlias(String name) {
		for (InstanceAlias ref: instanceAliases)
			if (ref.getName().equalsIgnoreCase(name))
				return ref;
		return null;
	}

	/** Remove the Instance with the specified name. */
	public void removeInstance(String name) {
		InstanceReference p = null;
		for (Instance o : instances)
			if (o.getName().equalsIgnoreCase(name))
				p = o;
		if (p != null)
			instances.remove(p);
	}


	/** Remove the InstanceAlias with the specified name. */
	public void removeInstanceAlias(String name) {		
		InstanceReference p = null;
		for (InstanceAlias o : instanceAliases)
			if (o.getName().equalsIgnoreCase(name))
				p = o;
		if (p != null)
			instanceAliases.remove(p);
	}



	/** Add the Instance with the specified name. 
	 * Throws an IllegalArgumentException if there already is an Instance or InstanceAlias with the same name (ignoring case) */
	public void addInstance(Instance instance) {
		if (instance.getName() == null)
			throw new IllegalArgumentException("Trying to add instance without a name");
		
		if (this.getInstanceOrAlias(instance.getName())!=null)
			throw new IllegalArgumentException("Trying to add instance with name '"+ instance.getName() + "', however there already is an instance or reference with that name");
		this.instances.add(instance);
	}

	/** Add the InstanceAlias with the specified name. 
	 * Throws an IllegalArgumentException if there already is an Instance or InstanceAlias with the same name (ignoring case) */
	public void addInstanceAlias(InstanceAlias alias) {
		if (this.getInstanceOrAlias(alias.getName())!=null)
			throw new IllegalArgumentException("Trying to add instance alias with name '"+ alias.getName() + "', however there already is an instance or reference with that name");
		this.instanceAliases.add(alias);
	}

	/** Does the Workspace contain an InstanceReference with the specified name?*/
	public boolean containsInstanceReference(String name) {
		InstanceReference ref = this.getInstanceOrAlias(name);
		if (ref == null)
			return false;
		return true;
	}
	
	/** Does the Workspace contain an Instance with the specified name?*/
	public boolean containsInstance(String name) {
		InstanceReference ref = this.getInstance(name);
		if (ref == null)
			return false;
		return true;
	}
	
	/** Does the Workspace contain an InstanceAlias with the specified name?*/
	public boolean containsInstanceAlias(String name) {
		InstanceReference ref = this.getInstanceAlias(name);
		if (ref == null)
			return false;
		return true;
	}
	
	
	/** Returns a new Arraylist containing all Instances (but not InstanceAliases) that refer to an ResourceObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<Instance> getAllResourceInstances(){
		ArrayList<Instance> a = new ArrayList<>();
		for (Instance i : instances)
			if (i.getAbstractObjectiveTemplate() instanceof ResourceObjectTemplate)
				a.add(i);
		return a;
	}

	/** Returns a new Arraylist containing all InstanceAliases (but not Instances) that refer to an ResourceObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceAlias> getAllResourceInstanceAliases(){
		ArrayList<InstanceAlias> a = new ArrayList<>();
		for (InstanceAlias i : instanceAliases)
			if (i.getAbstractObjectiveTemplate() instanceof ResourceObjectTemplate)
				a.add(i);
		return a;
	}

	/** Returns a new Arraylist containing all InstanceReferences (i.e., Instances and InstanceAliases) that 
	 * refer to an ResourceObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceReference> getAllResourceInstanceReferences(){
		ArrayList<InstanceReference> a = new ArrayList<>();
		a.addAll(getAllResourceInstances());
		a.addAll(getAllResourceInstanceAliases());
		return a;
	}



	/** Returns a new Arraylist containing all InstanceReference (i.e., Instances and InstanceAliases) that 
	 * refer to an ResourceObjectTemplate AND can be sampled for cues.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceReference> getAllCuedInstanceReferences(){
		ArrayList<InstanceReference> a = new ArrayList<>();
		a.addAll(getAllCuedInstances());
		a.addAll(getAllCuedInstanceAliases());
		return a;
	}


	/** Returns a new Arraylist containing all Instances (but not InstanceAliases) that refer to an AbstractObjectTemplate
	 *  that can be sampled for cues.*/
	@SuppressWarnings("unchecked")
	public ArrayList<Instance> getAllCuedInstances(){
		ArrayList<Instance> a = new ArrayList<>();
		for (Instance i : instances)
			if (i.getAbstractObjectiveTemplate() != null)
				a.add(i);
		return a;
	}

	/** Returns a new Arraylist containing all InstanceAliases (but not Instances) that refer to an AbstractObjectTemplate
	 * that can be sampled for cues.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceAlias> getAllCuedInstanceAliases(){
		ArrayList<InstanceAlias> a = new ArrayList<>();
		for (InstanceAlias i : instanceAliases)
			if (i.getAbstractObjectiveTemplate().getCueTemplate() != null)
				a.add(i);
		return a;
	}


	/** Returns a new Arraylist containing all Instances (but not InstanceAliases) that refer to an DelayObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<Instance> getAllDelayInstances(){
		ArrayList<Instance> a = new ArrayList<>();
		for (Instance i : instances)
			if (i.getAbstractObjectiveTemplate() instanceof DelayObjectTemplate)
				a.add(i);
		return a;
	}

	/** Returns a new Arraylist containing all InstanceAliases (but not Instances) that refer to an DelayObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceAlias> getAllDelayInstanceAliases(){
		ArrayList<InstanceAlias> a = new ArrayList<>();
		for (InstanceAlias i : instanceAliases)
			if (i.getAbstractObjectiveTemplate() instanceof DelayObjectTemplate)
				a.add(i);
		return a;
	}

	/** Returns a new Arraylist containing all InstanceReferences (i.e., Instances and InstanceAliases) that 
	 * refer to an DelayObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceReference> getAllDelayInstanceReferences(){
		ArrayList<InstanceReference> a = new ArrayList<>();
		a.addAll(getAllDelayInstances());
		a.addAll(getAllDelayInstanceAliases());
		return a;
	}
	
	/** Returns a new Arraylist containing all Instances (but not InstanceAliases) that refer to an InterruptionObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<Instance> getAllInterruptionInstances(){
		ArrayList<Instance> a = new ArrayList<>();
		for (Instance i : instances)
			if (i.getAbstractObjectiveTemplate() instanceof InterruptionObjectTemplate)
				a.add(i);
		return a;
	}

	/** Returns a new Arraylist containing all InstanceAliases (but not Instances) that refer to an InterruptionObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceAlias> getAllInterruptionInstanceAliases(){
		ArrayList<InstanceAlias> a = new ArrayList<>();
		for (InstanceAlias i : instanceAliases)
			if (i.getAbstractObjectiveTemplate() instanceof InterruptionObjectTemplate)
				a.add(i);
		return a;
	}

	/** Returns a new Arraylist containing all InstanceReferences (i.e., Instances and InstanceAliases) that 
	 * refer to an InterruptionObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceReference> getAllInterruptionInstanceReferences(){
		ArrayList<InstanceReference> a = new ArrayList<>();
		a.addAll(getAllInterruptionInstances());
		a.addAll(getAllInterruptionInstanceAliases());
		return a;
	}


	/** Returns a new Arraylist containing all Instances (but not InstanceAliases) that refer to an ExtrinsicObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<Instance> getAllExtrinsicInstances(){
		ArrayList<Instance> a = new ArrayList<>();
		for (Instance i : instances)
			if (i.getAbstractObjectiveTemplate() instanceof ExtrinsicObjectTemplate)
				a.add(i);
		return a;
	}

	/** Returns a new Arraylist containing all InstanceAliases (but not Instances) that refer to an ExtrinsicObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceAlias> getAllExtrinsicInstanceAliases(){
		ArrayList<InstanceAlias> a = new ArrayList<>();
		for (InstanceAlias i : instanceAliases)
			if (i.getAbstractObjectiveTemplate() instanceof ExtrinsicObjectTemplate)
				a.add(i);
		return a;
	}

	/** Returns a new Arraylist containing all InstanceReferences (i.e., Instances and InstanceAliases) that 
	 * refer to an ExtrinsicObjectTemplate.*/
	@SuppressWarnings("unchecked")
	public ArrayList<InstanceReference> getAllExtrinsicInstanceReferences(){
		ArrayList<InstanceReference> a = new ArrayList<>();
		a.addAll(getAllExtrinsicInstances());
		a.addAll(getAllExtrinsicInstanceAliases());
		return a;
	}

	////////////////// Actions ////////////////////


	/** Get the ActionTemplate with the specified name from the list of all possible between
	 * encounter actions (i.e., when the agent is not engaged with a resource). Returns null
	 * if there is no action with that name. Names are compared without capitalisation. */
	public ActionTemplate getBetweenAction(String name){
		for (ActionTemplate a : betweenEncounterActions)
			if (a.getName().equalsIgnoreCase(name))
				return a;
		return null;
	}
	
	/** Get the ActionTemplate with the specified name from the list of all possible during
	 * encounter actions (i.e., when the agent is not engaged with a resource). Returns null
	 * if there is no action with that name. Names are compared without capitalisation. */
	public ActionTemplate getDuringAction(String name){
		for (ActionTemplate a : betweenEncounterActions)
			if (a.getName().equalsIgnoreCase(name))
				return a;
		return null;
	}

	/** Get the ActionTemplate with the specified name from the list of all possible setup
	 * encounter actions (i.e., the rules that govern what occurs at the start of an encounter). Returns null
	 * if there is no action with that name. Names are compared without capitalization. */
	public ActionTemplate getEncounterSetupRule(String name){
		for (ActionTemplate a : this.setupEncounterActions)
			if (a.getName().equalsIgnoreCase(name))
				return a;
		return null;
	}
	
	/** Get the ActionTemplate with the specified name from the list of all possible 
	 * mutation phase actions (i.e., the rules that govern what occurs during the mutation phase). Returns null
	 * if there is no action with that name. Names are compared without capitalization. */
	public ActionTemplate getMutation(String name){
		for (ActionTemplate a : this.mutations)
			if (a.getName().equalsIgnoreCase(name))
				return a;
		return null;
	}

	/** Add a new label for the game type. The game type is on 'Standard' by default, but
	 * can be changed during the setup of an encounter. It can be used to affect which actions
	 * are possible during setup and during the encounter. Note, a game type will NOT be
	 * added if it is already present in the workspace.*/
	public void addGameType (String s) {
		for (String o: this.gameTypes)
			if (o.equalsIgnoreCase(s))
				return;
		gameTypes.add(s.toUpperCase());
	}

	/** Get all game types registered. The game type is on 'Standard' by default, but
	 * can be changed during the setup of an encounter. It can be used to affect which actions
	 * are possible during setup and during the encounter*/
	@SuppressWarnings("unchecked")
	public ArrayList<String> getGameTypes () {
		return (ArrayList<String>) gameTypes.clone();
	}

	/** Remove a game type. The game type is on 'Standard' by default, but
	 * can be changed during the setup of an encounter. The 'Standard' game type 
	 * cannot be removed. It can be used to affect which actions
	 * are possible during setup and during the encounter*/
	public void removeGameType (String s) {
		if (s.equals("Standard")) 
			throw new IllegalArgumentException("Cannot remove the 'Standard' game type.");

		this.gameTypes.remove(s);
	}


	/** Get the action with the name, or null if no such action exists. This action can be
	 * both a between-encounters actions as well as a during-encounters action. If you want
	 * to specifically get an action with this name this is either between or during, then
	 * use getDuringAction(String name) and getBetweenAction(String name) instead.*/
	public ActionTemplate getAction(String name){
		ActionTemplate a = getDuringAction(name);
		if (a == null)
			a = getBetweenAction(name);
		return a;
	}

	/** Get the names of all ActionTemplates that are possible between
	 * encounters (i.e., when the agent is not engaged with a resource). Note that names
	 * can only contain numbers, letter, and whitespace (i.e., no weird characters)*/
	public ArrayList<String> getBetweenActionNames(){
		ArrayList<String> names = new ArrayList<>();
		for (ActionTemplate a : betweenEncounterActions)
			names.add(a.getName());
		return names;
	}

	/** Get the names of all ActionTemplates that are possible during an
	 * encounter (i.e., when the agent is engaged with a resource). Note that names
	 * can only contain numbers, letter, and whitespace (i.e., no weird characters) */
	public ArrayList<String> getDuringActionNames(){
		ArrayList<String> names = new ArrayList<>();
		for (ActionTemplate a : duringEncounterActions)
			names.add(a.getName());
		return names;
	}
	
	/** Get the names of all ActionTemplates that are taking during the setup of an encounter. Note that names
	 * can only contain numbers, letter, and whitespace (i.e., no weird characters) */
	public ArrayList<String> getSetupEncounterNames(){
		ArrayList<String> names = new ArrayList<>();
		for (ActionTemplate a : this.setupEncounterActions)
			names.add(a.getName());
		return names;
	}
	

	/** Get the names of all ActionTemplates that are taking during a mutation phase. Note that names
	 * can only contain numbers, letter, and whitespace (i.e., no weird characters) */
	public ArrayList<String> getMutationNames(){
		ArrayList<String> names = new ArrayList<>();
		for (ActionTemplate a : this.mutations)
			names.add(a.getName());
		return names;
	}


	/** Returns true if the name is combination of numbers, letters, and whitespace (i.e.,
	 * no weird signs) and unique (i.e., there is no between or during action already with
	 * that name). Names are compared without capitalisation. Needs at least one character */
	public boolean isActionNamePermissible(String s){
		if (s.length() == 0)
			return false;
		if (!Helper.isNumbersAndLettersOnly(s))
			return false;
		for (String n : getBetweenActionNames())
			if (n.equalsIgnoreCase(s))
				return false;
		for (String n: getDuringActionNames())
			if (n.equalsIgnoreCase(s))
				return false;
		for (String n: getSetupEncounterNames())
			if (n.equalsIgnoreCase(s))
				return false;
		for (String n: getMutationNames())
			if (n.equalsIgnoreCase(s))
				return false;
		return true;
	}

	/** Removes the action from the workspace. Checks both between and during lists.
	 * Automatically updates the view after removal. */
	public void removeAction(ActionTemplate action){
		this.betweenEncounterActions.remove(action);
		this.duringEncounterActions.remove(action);

		Console.print("Removed an action: " + action);

		harmonizeWithView();
		View.getView().update();
		// Note that we have changed something after saving
		changedAfterSaving=true;
	}


	/** Removes the encounter setup action from the workspace.
	 * Automatically updates the view after removal. */
	public void removeEncounterSetupRule(ActionTemplate action){
		this.setupEncounterActions.remove(action);
		Console.print("Removed an encounter setup rule: " + action);

		harmonizeWithView();
		View.getView().update();
		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Removes the mutation from the workspace.
	 * Automatically updates the view after removal. */
	public void removeMutation(ActionTemplate action){
		this.mutations.remove(action);
		Console.print("Removed an mutation phase rule: " + action);

		harmonizeWithView();
		View.getView().update();
		// Note that we have changed something after saving
		changedAfterSaving=true;
	}


	/////////////////////////////////////////////////////////////////////////
	/////////////////////// 	Fitness and death 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////
	/** Set the Workspace's fitness function. The fitnessFunction must have the 'FITNESSFUNCTION' tag. The order of the arguments is preserved. */
	public void setFitnessFunction(RFunction fitnessFunction, PhenotypeElement... args){
		this.fitnessFunction = new FitnessFunctionTemplate(fitnessFunction, args);
		Console.print("Changed the fitness function. New function: " + this.fitnessFunction);

		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Returns the fitness function stored in the workspace. Can be null. */
	public FitnessFunctionTemplate getFitnessFunction() { return this.fitnessFunction;}

	/** Add the death condition to the workspace*/
	public void addDeathCondition(DeathConditionTemplate deathCondition) {
		this.deathConditionList.add(deathCondition);
		Console.print("Added a death condition. An agent now dies if its " + deathCondition.phenotype.getName().toLowerCase() + " " + deathCondition.operator + " " + deathCondition.value.toStringWithoutTrailingZeros());

		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Remove the death condition from the workspace*/
	public void removeDeathCondition(DeathConditionTemplate deathCondition){
		this.deathConditionList.remove(deathCondition);
		Console.print("Removed a death condition. An agent no longer dies if its " + deathCondition.phenotype.getName().toLowerCase() + " " + deathCondition.operator + " " + deathCondition.value.toStringWithoutTrailingZeros());

		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}

	/** Returns a list of all death conditions present in this workspace*/
	@SuppressWarnings("unchecked")
	public ArrayList<DeathConditionTemplate> getAllDeathConditions(){
		return (ArrayList<DeathConditionTemplate>) this.deathConditionList.clone();
	}
	/** When an agent dies before the last cycle, do we use a fixed value for fitness,
	 * or do we still evaluate the fitness based on that agent's phenotype?*/
	public boolean getUseFitnessFunctionBeforeMaximumAge() {
		return useFitnessFunctionBeforeMaximumAge ;
	}
	/** When an agent dies before the last cycle, do we use a fixed value for fitness,
	 * or do we still evaluate the fitness based on that agent's phenotype?*/
	public void setUseFitnessFunctionBeforeMaximumAge(boolean useFitnessFunctionBeforeMaximumAge) {
		this.useFitnessFunctionBeforeMaximumAge = useFitnessFunctionBeforeMaximumAge;
	}
	/** Set the fitness of death */
	public void setFitnessDeath(DecimalNumber newFitness){
		this.deathFitness = newFitness;

		harmonizeWithView();
		View.getView().update();

		// Note that we have changed something after saving
		changedAfterSaving=true;
	}
	/** Returns the fitness of an agent that dies before the last cycle. Used only if setUseFitnessFunctionBeforeMaximumAge is true.*/
	public DecimalNumber getFitnessDeath() {return this.deathFitness;}
	/////////////////////////////////////////////////////////////////////
	/////////////////////// 	View mechanics 	/////////////////////////
	/////////////////////////////////////////////////////////////////////

	/** Removes all objects and beliefs from the view, and adds all objects and beliefs from this Workspace to the View. Note: does not tell all these objects to redraw
	 * themselves. For that you should call View.getView().update()*/
	public void harmonizeWithView(){
		// Remove all objects, beliefs, patches, times, actions, mutations, and death conditions.
		View.getView().clearAllObjectsAndBeliefs();
		View.getView().clearAllPatches();
		View.getView().clearAllActionsAndMutations();
		View.getView().clearAllDeathConditions();

		// Add objects
		for (PhenotypeObjectTemplate    o : this.phenotypeObjectList)    View.getView().addPhenotypeObject(o);
		for (AbstractPhenotypeSlotTemplate      o : this.phenotypeSlots) 		 View.getView().addPhenotypeSlot(o);
		for (ResourceObjectTemplate     o : this.resourceObjectList)     View.getView().addResourceObject(o);
		for (InterruptionObjectTemplate o : this.interruptionObjectList) View.getView().addInterruptionObject(o);
		for (DelayObjectTemplate        o : this.delayObjectList)        View.getView().addDelayObject(o);
		for (ExtrinsicObjectTemplate    o : this.extrinsicObjectList)    View.getView().addExtrinsicObject(o);

		// Add beliefs
		this.updateBeliefLists();
		for (ResourceBeliefTemplate     o : this.resourceBeliefList)     View.getView().addResourceBelief(o);
		for (InterruptionBeliefTemplate o : this.interruptionBeliefList) View.getView().addInterruptionBelief(o);
		for (DelayBeliefTemplate        o : this.delayBeliefList)        View.getView().addDelayBelief(o);
		for (ExtrinsicBeliefTemplate    o : this.extrinsicBeliefList)    View.getView().addExtrinsicBelief(o);

		// Add patches
		for (PatchTemplate pt: patchList) View.getView().addPatch(pt);
		// Times are regulated when selecting a patch

		// Add actions and mutations
		View.getView().setMaximumCycle(maximumCycleTime);
		View.getView().setMaximumLifetime(maximumLifeTime);
		View.getView().addBetweenActions(betweenEncounterActions);
		View.getView().addDuringActions(duringEncounterActions);
		View.getView().addEncounterSetupActions(this.setupEncounterActions);
		View.getView().addMutations(this.mutations);

		// Set fitness function
		View.getView().setFitnessFunction(fitnessFunction);
		View.getView().setFixedFitnessForDeadButNotAgeRestrictedStates(deathFitness);

		// Add death conditions
		View.getView().addAllDeathConditions(deathConditionList);

		// Check if we can remove some InstanceReference
		refreshInstanceReferences();

	}

	@Override
	public FILE_TYPE getFileType() {
		return ExternalFileManager.FILE_TYPE.WORKSPACE;
	}

	public String toString(){

		StringBuilder sb = new StringBuilder();
		sb.append("Workspace @ " + Helper.timestamp() );
		if (changedAfterSaving)
			sb.append(" (contains unsaved data)");

		sb.append("\n\n------------------------------------------");
		sb.append("\n---------- OBJECTS IN WORKSPACE ----------");
		sb.append("\n------------------------------------------");
		sb.append("\n\n+++++++ Phenotype object types:");
		if (phenotypeObjectList.size()==0)
			sb.append("\n(none)");
		for (PhenotypeObjectTemplate o: phenotypeObjectList)
			sb.append("\n-" + o);

		sb.append("\n\n+++++++ Phenotype slots:");
		if (this.phenotypeSlots.size()==0)
			sb.append("\n(none)");
		for (AbstractPhenotypeSlotTemplate o: phenotypeSlots)
			sb.append("\n-" + o);
		
		sb.append("\n\n+++++++ Resource object types:");
		if (resourceObjectList.size()==0)
			sb.append("\n(none)");
		for (ResourceObjectTemplate o: resourceObjectList)
			sb.append("\n-" + o);

		sb.append("\n\n+++++++ Interruption object types:");
		if (interruptionObjectList.size()==0)
			sb.append("\n(none)");
		for (InterruptionObjectTemplate o: interruptionObjectList)
			sb.append("\n-" + o);

		sb.append("\n\n+++++++ Delay object types:");
		if (delayObjectList.size()==0)
			sb.append("\n(none)");
		for (DelayObjectTemplate o: delayObjectList)
			sb.append("\n-" + o);

		sb.append("\n\n+++++++ Extrinsic object types:");
		if (extrinsicObjectList.size()==0)
			sb.append("\n(none)");
		for (ExtrinsicObjectTemplate o: extrinsicObjectList)
			sb.append("\n-" + o);

		sb.append("\n\n+++++++ Instantiated objects:");
		if (instances.size()==0)
			sb.append("\n(none)");
		for (InstanceReference o: instances)
			sb.append("\n-" + o);

		sb.append("\n\n+++++++ Aliases:");
		if (instances.size()==0)
			sb.append("\n(none)");
		for (InstanceReference o: instanceAliases)
			sb.append("\n-" + o);

		
		sb.append("\n\n\n------------------------------------------");
		sb.append("\n---------- BELIEFS IN WORKSPACE ----------");
		sb.append("\n------------------------------------------");
		sb.append("\n\n+++++++ Resource beliefs:");
		for (ResourceBeliefTemplate b: resourceBeliefList)
			sb.append("\n-" + b);
		if (resourceBeliefList.size()==0)
			sb.append("\n(none)");

		sb.append("\n\n+++++++ Interruption beliefs:");
		for (InterruptionBeliefTemplate b: interruptionBeliefList)
			sb.append("\n-" + b);
		if (interruptionBeliefList.size()==0)
			sb.append("\n(none)");

		sb.append("\n\n+++++++ Delay beliefs:");
		for (DelayBeliefTemplate b: delayBeliefList)
			sb.append("\n-" + b);
		if (delayBeliefList.size()==0)
			sb.append("\n(none)");

		sb.append("\n\n+++++++ Extrinsic beliefs:");
		for (ExtrinsicBeliefTemplate b: extrinsicBeliefList)
			sb.append("\n-" + b);
		if (extrinsicBeliefList.size()==0)
			sb.append("\n(none)");


		sb.append("\n\n\n------------------------------------------");
		sb.append("\n---------- PATCHES IN WORKSPACE ----------");
		sb.append("\n------------------------------------------");
		for (PatchTemplate pt: patchList){
			sb.append("\n\n\n+++++++ PATCH: '" + pt.getName());
			ArrayList<PatchStateTemplate> states = pt.getAllStates();
			sb.append("', which has " + states.size() + " states: ");

			for (PatchStateTemplate s : states){

				ArrayList<AbstractObjectiveTemplate> oList = s.getAllOffsettedObjects();

				sb.append("\n\n--- STATE: " + s.getName());
				sb.append("\nThis state has the following "+ oList.size()+" object offsets:" );

				for (AbstractObjectiveTemplate o: oList){
					sb.append("\n-" + o.getName());
					if (s.hasFrequencyOffsetFor(o)) 
						sb.append(": Frequency offset += " + 
								s.getFrequencyOffsets(o).toStringWithoutTrailingZeros() + " (new frequency = " + s.getOffsettedObject(o).getOffsettedFrequency().toStringWithoutTrailingZeros() + ")");


					if (s.getValueOffsets(o) != null){
						sb.append("; Value offset(s) = {");
						for (AttributeField af: s.getValueOffsets(o))
							sb.append(af.getName() + " + " + af.getValueStringWithoutTrailingZeros() + "; ");
						sb.append("}. The new distributions are: ");
						for (RFunctionContainer dist : o.getAllSamplingDistributions())
							sb.append("\n\t-" + dist + " -> " + s.getOffsettedObject(o).getOffsettedValueDistribution(dist));
					}
				}

				ArrayList<AbstractBeliefTemplate> bList = s.getAllOffsettedBeliefs();
				sb.append("\n\nThis state has the following "+ bList.size()+" belief offsets:" );	
				for (AbstractBeliefTemplate b: bList){
					sb.append("\n-" + b.getObject().getName());
					if (s.getOffsettedBelief(b).isKnownDistribution())
						sb.append(". An agent knows the distribution in this patch state.");
					else {
						sb.append(". The prior has the following observations: {" );
						for (DecimalNumber domain : b.getObject().getDomain())
							sb.append("["+domain.toStringWithoutTrailingZeros()+ "->" + s.getOffsettedBelief(b).getPatchSpecificObservations(domain)+ "],");
						sb.append("}");
					}	
				}
			}
			sb.append("\n\nStarting probabilities:");
			for (PatchStateTemplate s: states) {
				sb.append("\n\t" + s.getName() + ": " + pt.getStartingProbability(s).toStringWithoutTrailingZeros());
			}

			sb.append("\n\nMutation Matrix: \n" + pt.getMutations().toDecimalNumberMatrix());
		}
		sb.append("\n\nPatches transition matrix: \n" + Helper.arrayToString(patchTransitions.toBooleanMatrix()) );


		sb.append("\n\n\n---------------------------------------------------------------");
		sb.append("\n---------- ACTIONS AND MUTATIONS IN WORKSPACE ----------");
		sb.append("\n---------------------------------------------------------------");
		sb.append("\nMaximum life time: " + maximumLifeTime);
		sb.append("\nMaximum cycle time: " + maximumCycleTime);
		sb.append("\nGame types:");
		for (String s: this.gameTypes)
			sb.append("\n\t" + s);
		
		
		sb.append("\n\nSetup rules start encounter (order matters): ");
		for (ActionTemplate a: this.setupEncounterActions)
			sb.append("\n\t" + a);
		if (setupEncounterActions.size()==0)
			sb.append("\n(none)");

		sb.append("\n\nMutations (order matters): ");
		for (ActionTemplate a: this.mutations)
			sb.append("\n\t" + a);
		if (mutations.size()==0)
			sb.append("\n(none)");
		
		sb.append("\n\nBetween encounter actions: ");
		for (ActionTemplate a:betweenEncounterActions)
			sb.append("\n\t" + a);
		if (betweenEncounterActions.size()==0)
			sb.append("\n(none)");


		sb.append("\n\nDuring encounter actions: ");
		for (ActionTemplate a:duringEncounterActions)
			sb.append("\n\t" + a);
		if (duringEncounterActions.size()==0)
			sb.append("\n(none)");

	

		sb.append("\n\n\n-----------------------------------------------------");
		sb.append("\n---------- DEATH & FITNESS IN WORKSPACE ----------");
		sb.append("\n---------------------------------------------------");
		if (fitnessFunction != null)
			sb.append("\nFitness function = " + fitnessFunction.toString());
		else 
			sb.append("\n!!Fitness function NOT SPECIFIED!!" );

		if (deathFitness != null)
			sb.append("\nDeath fitness = " + deathFitness.toString());
		else 
			sb.append("\n!!Death fitness NOT SPECIFIED!!" );

		sb.append("\n\nDeath conditions:");
		for (DeathConditionTemplate dt: deathConditionList)
			sb.append("\n\t-" + dt);

		return sb.toString();
	}


	//////////////////////////////////////////////////////////////////////////////
	/////////////////////// 	Model construction		/////////////////////////
	////////////////////////////////////////////////////////////////////////////

	/** Returns true if the workspace is complete - that is, if a model can be constructed based on the 
	 * templates in the workspace. If something is missing (e.g., the fitness function), this function
	 * givens a warning toast informing the user what is missing, and returns false.*/
	public boolean isReadyForModelConstruction(){
		// There has to be at least one non-age phenotypic dimension
		if (this.getAllPhenotypeObjectsExcludingAge().size() ==0) {
			ObserverManager.makeWarningToast("Cannot build model from workspace: needs at least one non-age phenotypic dimension");
			return false;
		}
		// There should be at least one action between encounters that an agent can take
		if (this.betweenEncounterActions.size() == 0){
			ObserverManager.makeWarningToast("Cannot build model from workspace: needs at least one between encounter action");
			return false;
		}

		// If there is at least one during action, there has to be a resource
		if (this.duringEncounterActions.size() > 0 && this.resourceObjectList.size() == 0){
			ObserverManager.makeWarningToast("Cannot build model from workspace: there are actions during encounters, but there is no resource to encounter");
			return false;
		}

		// Check if all fitness elements are set properly
		if (this.fitnessFunction == null ){
			ObserverManager.makeWarningToast("Cannot build model from workspace: please specify a fitness function and use the button to set it");
			return false;
		}

		if (this.deathFitness == null){
			ObserverManager.makeWarningToast("Cannot build model from workspace: please specify the fitness of death");
			return false;
		}

		// TODO: check if starting states in each patch sum to 1 (and none is negative)
		// TODO: check if all patch state mutations sum to 1 (and none is negative)
		return true;
	}
}
