package view;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import helper.Helper;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.LayoutManager;
import interfaces_abstractions.LayoutManager.State;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplateFactory;
import objectiveElements.AgeTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.PhenotypeSlotTemplateDelayedResource;
import objectiveElements.PhenotypeSlotTemplateRecurringResource;
import objectiveElements.ResourceObjectTemplate;
import start.Console;

public class PopupSlot extends AbstractPopup {
	private transient final static String cssStyleSheetLocationCheckBox = PopupSlot.class.getResource("../CSSLayout/checkBox.css").toExternalForm();

	// FXML elements 
	@FXML public Label 		labelTitle;
	@FXML public TextField 	textFieldName;

	@FXML public ComboBox<Class<? extends AbstractPhenotypeSlotTemplate>> comboboxType;

	@FXML public GridPane gridPaneResources;
	@FXML public ListView<ObjectAndBooleanCombination> listViewResources;

	@FXML public GridPane gridPanePhenotypes;
	@FXML public ListView<ObjectAndBooleanCombination> listViewPhenotypes;

	@FXML public GridPane gridPaneDelays;
	@FXML public ListView<ObjectAndBooleanCombination> listViewDelays;

	@FXML public GridPane gridPaneInterruptions;
	@FXML public ListView<ObjectAndBooleanCombination> listViewInterruptions;

	@FXML public GridPane gridPanePeriod;
	@FXML public Spinner<Integer> spinnerPeriod;

	@FXML public ComboBox<Boolean> comboboxOverwritten;

	@FXML public Button buttonApplyChanges, buttonDelete;
	@FXML public GridPane gridPaneSpacer;

	// If this popup is created to modify an already existing slot, the existingTemplate points towards that slot. Otherwise, it is null
	private final AbstractPhenotypeSlotTemplate existingTemplate;

	/** Create a new ActionPopup. If the action is left empty,
	 * a new action will be created. If the action is not empty,
	 * that action will be modified. The popup will show in the
	 * middle of the View's main scroll pane.*/
	public PopupSlot(MouseEvent e, AbstractPhenotypeSlotTemplate existingTemplate){
		super("fxml_popupSlot.fxml", e, true);

		this.existingTemplate = existingTemplate;

		// Set the nodes
		setNodes();

		// Set the values in the nodes
		update();

		if (existingTemplate == null)
			Console.print("Opened a new popup window for to create a new Phenotype Slot.");
		else
			Console.print("Opened a new popup window for to modify the phenotype slot : " + existingTemplate.getName() + ".");

	}

	@Override
	public void setNodes() {
		// Set the difference between creating a new slot or changing/deleting an existing slot
		if (existingTemplate == null){
			labelTitle.setText("Create a new phenotypic slot");
			buttonApplyChanges.setText("Create slot");
			gridPaneSpacer.setManaged(false);
			gridPaneSpacer.setVisible(false);
			buttonDelete.setManaged(false);
			buttonDelete.setVisible(false);
		} else {
			labelTitle.setText("Change an existing phenotypic slot");
			buttonApplyChanges.setText("Apply changes");
			this.textFieldName.setDisable(true);
			this.comboboxType.setDisable(true);
		}

		LayoutManager.setLayoutHandler(textFieldName, FieldRestriction.VARIABLE_NAME);

		comboboxType.setCellFactory(lv -> {
			ListCell<Class<? extends AbstractPhenotypeSlotTemplate>> cell = new ListCell<Class<? extends AbstractPhenotypeSlotTemplate>>() {
				@Override
				protected void updateItem(Class<? extends AbstractPhenotypeSlotTemplate> item, boolean empty) {
					super.updateItem(item, empty);
					if (item == null || empty) {
						setGraphic(null);
						setText(null);
					} else {

						VBox box = new VBox();
						box.setAlignment(Pos.CENTER_LEFT);
						box.setMinHeight(60);
						box.setMinHeight(60);

						// Set the type label
						Label type = new Label(AbstractPhenotypeSlotTemplate.getTypeName(item));
						type.setStyle("-fx-font-weight: bold;");
						box.getChildren().add(type);

						Label description = new Label(AbstractPhenotypeSlotTemplate.getDescription(item));
						description.setStyle("-fx-font-style: italic;");
						box.getChildren().add(description);

						type.setAlignment(Pos.CENTER_RIGHT);
						description.setAlignment(Pos.CENTER_LEFT);

						this.setGraphic(box);
					}
				}
			};
			return cell;
		});

		Callback<ListView<Class<?extends AbstractPhenotypeSlotTemplate>>, ListCell<Class<?extends AbstractPhenotypeSlotTemplate>>> buttonCellFactory =
				new  Callback<ListView<Class<?extends AbstractPhenotypeSlotTemplate>>, ListCell<Class<?extends AbstractPhenotypeSlotTemplate>>>(){
			@Override
			public ListCell<Class<? extends AbstractPhenotypeSlotTemplate>> call(
					ListView<Class<? extends AbstractPhenotypeSlotTemplate>> clazz) {
				return new ListCell<Class<? extends AbstractPhenotypeSlotTemplate>>(){
					@Override
					protected void updateItem(Class<? extends AbstractPhenotypeSlotTemplate> item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(AbstractPhenotypeSlotTemplate.getTypeName(item));
						}
					}
				};
			}
		};

		comboboxType.setButtonCell(buttonCellFactory.call(null));
		comboboxType.getItems().addAll(AbstractPhenotypeSlotTemplate.getAllSlotTypes());

		// Set the listener that determines, based on the type of phenotype slot selected, which other fields should be visible
		comboboxType.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (newValue != null) { 
				gridPaneResources.setVisible(true);
				gridPaneResources.setManaged(true);
				gridPanePhenotypes.setVisible(true);
				gridPanePhenotypes.setManaged(true);

				// gridPaneDelays
				if (AbstractPhenotypeSlotTemplate.usesDelays(newValue)) {
					gridPaneDelays.setVisible(true);
					gridPaneDelays.setManaged(true);
				}else {
					gridPaneDelays.setVisible(false);
					gridPaneDelays.setManaged(false);
				}

				// gridPaneInterruptions
				if (AbstractPhenotypeSlotTemplate.usesInterruptions(newValue)) {
					gridPaneInterruptions.setVisible(true);
					gridPaneInterruptions.setManaged(true);
				}else {
					gridPaneInterruptions.setVisible(false);
					gridPaneInterruptions.setManaged(false);
				}

				// gridPanePeriod
				if (AbstractPhenotypeSlotTemplate.usesPeriodicity(newValue)) {
					gridPanePeriod.setVisible(true);
					gridPanePeriod.setManaged(true);
				}else {
					gridPanePeriod.setVisible(false);
					gridPanePeriod.setManaged(false);
				}
			} else {
				// Nothing selected: show nothing
				gridPaneResources.setVisible(false);
				gridPaneResources.setManaged(false);
				gridPanePhenotypes.setVisible(false);
				gridPanePhenotypes.setManaged(false);
				gridPaneDelays.setVisible(false);
				gridPaneDelays.setManaged(false);
				gridPaneInterruptions.setVisible(false);
				gridPaneInterruptions.setManaged(false);
				gridPanePeriod.setVisible(false);
				gridPanePeriod.setManaged(false);
			}
		});

		// When nothing is selected, show nothing
		if (existingTemplate == null) {
			gridPaneResources.setVisible(false);
			gridPaneResources.setManaged(false);
			gridPanePhenotypes.setVisible(false);
			gridPanePhenotypes.setManaged(false);
			gridPaneDelays.setVisible(false);
			gridPaneDelays.setManaged(false);
			gridPaneInterruptions.setVisible(false);
			gridPaneInterruptions.setManaged(false);
			gridPanePeriod.setVisible(false);
			gridPanePeriod.setManaged(false);
		}


		// Create a cell factory for the ObjectAndBooleanCombination
		Callback<ListView<ObjectAndBooleanCombination>, ListCell<ObjectAndBooleanCombination>> cellFactory =
				new  Callback<ListView<ObjectAndBooleanCombination>, ListCell<ObjectAndBooleanCombination>>(){
			@Override
			public ListCell<ObjectAndBooleanCombination> call(	ListView<ObjectAndBooleanCombination> item) {
				return new ListCell<ObjectAndBooleanCombination>(){
					@Override
					protected void updateItem(ObjectAndBooleanCombination item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							String name = "  " + item.object.getName();
							int strlen = name.length();
							int ideallen = 75;
							if (strlen < ideallen) 
								name = name + Helper.repString(" ", ideallen-strlen);
							CheckBox cb = new CheckBox(name);
							cb.setSelected(item.isSelected);
							cb.getStylesheets().add(cssStyleSheetLocationCheckBox);
							cb.getStyleClass().add("largeObject");
							cb.setId("largeObject");

							cb.selectedProperty().addListener((obs, oldValue, newValue) -> { item.isSelected = newValue;});
							this.setGraphic(cb);
						}
					}
				};
			}
		};

		// ListView Resources
		// Add the resources in the workspace to the ListView
		for (ResourceObjectTemplate r : View.getView().workspace.getAllResourceObjects())
			this.listViewResources.getItems().add(new ObjectAndBooleanCombination(true, r));
		listViewResources.setSelectionModel(new NoSelectionModel<>());
		listViewResources.setCellFactory(cellFactory);
		listViewResources.setPlaceholder(new Label("There are no resources in the workspace yet."));

		// ListViewPhenotypes (does NOT include age!)
		for (PhenotypeObjectTemplate p : View.getView().workspace.getAllPhenotypeObjects())
			if (!(p instanceof AgeTemplate))
				this.listViewPhenotypes.getItems().add(new ObjectAndBooleanCombination(true, p));
		listViewPhenotypes.setSelectionModel(new NoSelectionModel<>());
		listViewPhenotypes.setCellFactory(cellFactory);
		listViewPhenotypes.setPlaceholder(new Label("There are no non-age phenotypic dimensions in the workspace yet."));

		//ListViewDelays
		for (DelayObjectTemplate r : View.getView().workspace.getAllDelayObjects())
			this.listViewDelays.getItems().add(new ObjectAndBooleanCombination(true, r));
		listViewDelays.setSelectionModel(new NoSelectionModel<>());
		listViewDelays.setCellFactory(cellFactory);
		listViewDelays.setPlaceholder(new Label("There are no delays in the workspace yet."));

		//ListViewInterruptions
		for (InterruptionObjectTemplate r : View.getView().workspace.getAllInterruptionObjects())
			this.listViewInterruptions.getItems().add(new ObjectAndBooleanCombination(true, r));
		listViewInterruptions.setSelectionModel(new NoSelectionModel<>());
		listViewInterruptions.setCellFactory(cellFactory);
		listViewInterruptions.setPlaceholder(new Label("There are no interruptions in the workspace yet."));

		// Set the periodicity spinner
		this.spinnerPeriod.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, Integer.MAX_VALUE));

		// Set the overwritten object
		Callback<ListView<Boolean>, ListCell<Boolean>> boolFactoryLong =
				new  Callback<ListView<Boolean>, ListCell<Boolean>>(){
			@Override
			public ListCell<Boolean> call(	ListView<Boolean> item) {
				return new ListCell<Boolean>(){
					@Override
					protected void updateItem(Boolean item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
							setText(null);
						} else {
							if (item)
								setText("Yes - the resource in the slot will be removed when subsequent action stores a new resource.");
							else
								setText("No - no action can place a resource when there already is a resource in this slot.");
						}
					}
				};
			}
		};
		Callback<ListView<Boolean>, ListCell<Boolean>> boolFactoryShort =
				new  Callback<ListView<Boolean>, ListCell<Boolean>>(){
			@Override
			public ListCell<Boolean> call(	ListView<Boolean> item) {
				return new ListCell<Boolean>(){
					@Override
					protected void updateItem(Boolean item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
							setText(null);
						} else {
							if (item)
								setText("Yes.");
							else
								setText("No.");
						}
					}
				};
			}
		};
		this.comboboxOverwritten.setCellFactory(boolFactoryLong);
		comboboxOverwritten.setButtonCell(boolFactoryShort.call(null));
		comboboxOverwritten.getItems().add(true);
		comboboxOverwritten.getItems().add(false);
		comboboxOverwritten.getSelectionModel().select(false);

		// Set the handler for when the user pressed the apply changes button
		this.buttonApplyChanges.setOnAction(e -> { applyChangesButtonPressed();});
		this.buttonDelete.setOnAction(e -> { deleteButtonPressed();});
	}


	@Override
	public void update() {
		// If there is an existing template, load that template's settings into the popup
		if (existingTemplate != null) {
			this.textFieldName.setText(existingTemplate.getName());
			this.comboboxType.getSelectionModel().select(existingTemplate.getClass());
			for (ObjectAndBooleanCombination c : this.listViewResources.getItems()) 
				c.isSelected = existingTemplate.canUseResource((ResourceObjectTemplate) c.object);

			for (ObjectAndBooleanCombination c : this.listViewPhenotypes.getItems()) 
				c.isSelected = existingTemplate.canUsePhenotype((PhenotypeObjectTemplate) c.object);

			if (existingTemplate.getClass() == PhenotypeSlotTemplateDelayedResource.class)
				for (ObjectAndBooleanCombination c : this.listViewDelays.getItems()) 
					c.isSelected = ((PhenotypeSlotTemplateDelayedResource) existingTemplate).canUseDelay((DelayObjectTemplate) c.object);

			if (existingTemplate.getClass() == PhenotypeSlotTemplateDelayedResource.class )
				for (ObjectAndBooleanCombination c : this.listViewInterruptions.getItems()) 
					c.isSelected = ((PhenotypeSlotTemplateDelayedResource) existingTemplate).canUseInterruption((InterruptionObjectTemplate) c.object);

			if (existingTemplate.getClass() == PhenotypeSlotTemplateRecurringResource.class )
				for (ObjectAndBooleanCombination c : this.listViewInterruptions.getItems()) 
					c.isSelected = ((PhenotypeSlotTemplateRecurringResource) existingTemplate).canUseInterruption((InterruptionObjectTemplate) c.object);

			if (existingTemplate.getClass() == PhenotypeSlotTemplateRecurringResource.class )
				this.spinnerPeriod.getValueFactory().setValue(((PhenotypeSlotTemplateRecurringResource) existingTemplate).getPeriodicity());

			this.comboboxOverwritten.getSelectionModel().select(existingTemplate.isOverwritable());

		}


	}

	private void applyChangesButtonPressed() {
		// Are we changing an existing slot, or creating a new one?
		if (existingTemplate == null) {

			// Creating a new slot:
			// Step 1: check if the name is OK
			if (LayoutManager.isInvalid(textFieldName)) {
				View.getView().showWarningToast("Invalid phenotype slot name.");
				return;
			}
			if (View.getView().workspace.getPhenotypeSlot(textFieldName.getText()) != null){
				View.getView().showWarningToast("There already is a phenotype slot with that same name in the workspace. Please select another name.");
				LayoutManager.setState(textFieldName, State.Invalid);
				return;
			}

			// Step 2: a type of slot has to be selected
			if (this.comboboxType.getSelectionModel().getSelectedItem() == null) {
				View.getView().showWarningToast("Please select a type of slot.");
				return;
			}

			// Step 3: Check if at least one resource has been selected
			boolean atLeastOneResource = false;
			for (ObjectAndBooleanCombination c: this.listViewResources.getItems())
				if (c.isSelected)
					atLeastOneResource = true;
			if (!atLeastOneResource) { 
				View.getView().showWarningToast("At least one resource has to be permissible");
				return;
			}

			// Step 3: Check if at least one non-age phenotypic dimension has been selected
			boolean atLeastOnePhenotype = false;
			for (ObjectAndBooleanCombination c: this.listViewPhenotypes.getItems())
				if (c.object instanceof AgeTemplate)
					throw new IllegalStateException("Age is in the listview for phenotypic dimensions. That should not have happened.");
				else if (c.isSelected)
					atLeastOnePhenotype = true;
			if (!atLeastOnePhenotype) { 
				View.getView().showWarningToast("At least one phenotypic dimension has to be permissible");
				return;
			}

			// Step 5: For a delayed resource there must be at least one permissible delay
			if (this.comboboxType.getSelectionModel().getSelectedItem() == PhenotypeSlotTemplateDelayedResource.class) {
				boolean atLeastOneDelay = false;
				for (ObjectAndBooleanCombination c: this.listViewDelays.getItems())
					if (c.isSelected)
						atLeastOneDelay = true;
				if (!atLeastOneDelay) { 
					View.getView().showWarningToast("At least one delay has to be permissible");
					return;
				}
			}

			// Step 6: the overwritten combobox should not be empty
			if (this.comboboxOverwritten.getSelectionModel().getSelectedItem() == null) {
				View.getView().showWarningToast("Please select whether this slot can be overwritten.");
				return;
			}

			// Now that we know that the settings are all correct, we can use an AbstractPhenotypeSlotTemplateFactory to build a new PhenotypeSlot:
			AbstractPhenotypeSlotTemplateFactory factory = new AbstractPhenotypeSlotTemplateFactory();
			factory.setSlotType(this.comboboxType.getSelectionModel().getSelectedItem())
			.setName(this.textFieldName.getText())
			.setCanBeOverwritten(this.comboboxOverwritten.getSelectionModel().getSelectedItem());
			
			for (ObjectAndBooleanCombination c : this.listViewResources.getItems())
				factory.setCanUseResource((ResourceObjectTemplate) c.object, c.isSelected);

			for (ObjectAndBooleanCombination c : this.listViewPhenotypes.getItems())
				factory.setCanUsePhenotype((PhenotypeObjectTemplate) c.object, c.isSelected);

			
			// Delayed resources can use delays
			if (this.comboboxType.getSelectionModel().getSelectedItem() == PhenotypeSlotTemplateDelayedResource.class)
				for (ObjectAndBooleanCombination c : this.listViewDelays.getItems())
					factory.setCanUseDelay((DelayObjectTemplate) c.object, c.isSelected);

			// Delayed resources and recurring resources can use interrruptions 
			if (this.comboboxType.getSelectionModel().getSelectedItem() == PhenotypeSlotTemplateDelayedResource.class || this.comboboxType.getSelectionModel().getSelectedItem() == PhenotypeSlotTemplateRecurringResource.class)
				for (ObjectAndBooleanCombination c : this.listViewInterruptions.getItems())
					factory.setCanUseInterruption((InterruptionObjectTemplate) c.object, c.isSelected);

			// Recurring resources need a periodicity
			if (this.comboboxType.getSelectionModel().getSelectedItem() == PhenotypeSlotTemplateRecurringResource.class)
				factory.setPeriodicity(this.spinnerPeriod.getValue());

			// Build
			AbstractPhenotypeSlotTemplate s = factory.build();

			// Add to workspace
			View.getView().workspace.addPhenotypeSlot(s);

			// Close
			this.close();
		}
		else {
			// Ah, we are changing an already existing template. In that case, we have to change some stuff
			for (ObjectAndBooleanCombination c : this.listViewResources.getItems())
				existingTemplate.modifyCanUseResource((ResourceObjectTemplate) c.object, c.isSelected);
			
			for (ObjectAndBooleanCombination c : this.listViewPhenotypes.getItems())
				existingTemplate.modifyCanUsePhenotype((PhenotypeObjectTemplate) c.object, c.isSelected);
			
			existingTemplate.setOverwritable(this.comboboxOverwritten.getSelectionModel().getSelectedItem());

			// Delayed resources can have delays
			if (existingTemplate.getClass() == PhenotypeSlotTemplateDelayedResource.class)
				for (ObjectAndBooleanCombination c : this.listViewDelays.getItems())
					((PhenotypeSlotTemplateDelayedResource) existingTemplate).modifyCanUseDelay((DelayObjectTemplate) c.object, c.isSelected);

			// Delayed resources can have interruptions
			if (existingTemplate.getClass() == PhenotypeSlotTemplateDelayedResource.class)
				for (ObjectAndBooleanCombination c : this.listViewInterruptions.getItems())
					((PhenotypeSlotTemplateDelayedResource) existingTemplate).modifyCanUseInterruption((InterruptionObjectTemplate) c.object, c.isSelected);

			// Recurring resources can have interruptions
			if (existingTemplate.getClass() == PhenotypeSlotTemplateRecurringResource.class)
				for (ObjectAndBooleanCombination c : this.listViewInterruptions.getItems())
					((PhenotypeSlotTemplateRecurringResource) existingTemplate).modifyCanUseInterruption((InterruptionObjectTemplate) c.object, c.isSelected);

			// Recurring resources have a periodicity
			if (existingTemplate.getClass() == PhenotypeSlotTemplateRecurringResource.class) {
				((PhenotypeSlotTemplateRecurringResource) existingTemplate).setPeriodicity(this.spinnerPeriod.getValue());
			}

			View.getView().update();
			this.close();
		}
	}

	private void deleteButtonPressed() {
		if (View.getView().deletePhenotypeSlot(existingTemplate))
			close();
	}










	/** A private class used to show the AbstractPhenotypeObjects and a boolean into a single listcell.
	 * This class is used to depict each of the resources, delays, and interruptions in the listviews.*/
	private class ObjectAndBooleanCombination {

		public boolean isSelected;
		public final AbstractObjectiveTemplate object;

		public ObjectAndBooleanCombination(boolean isSelected, AbstractObjectiveTemplate object) {
			this.isSelected = isSelected;
			this.object = object;
		}
	}

	/** A private class to use as a listview selection model - this selection model does not allow any selection */
	public class NoSelectionModel<T> extends MultipleSelectionModel<T> {

		@Override
		public ObservableList<Integer> getSelectedIndices() {
			return FXCollections.emptyObservableList();
		}

		@Override
		public ObservableList<T> getSelectedItems() {
			return FXCollections.emptyObservableList();
		}

		@Override
		public void selectIndices(int index, int... indices) {
		}

		@Override
		public void selectAll() {
		}

		@Override
		public void selectFirst() {
		}

		@Override
		public void selectLast() {
		}

		@Override
		public void clearAndSelect(int index) {
		}

		@Override
		public void select(int index) {
		}

		@Override
		public void select(T obj) {
		}

		@Override
		public void clearSelection(int index) {
		}

		@Override
		public void clearSelection() {
		}

		@Override
		public boolean isSelected(int index) {
			return false;
		}

		@Override
		public boolean isEmpty() {
			return true;
		}

		@Override
		public void selectPrevious() {
		}

		@Override
		public void selectNext() {
		}
	}

}
