package view;

import java.util.ArrayList;
import java.util.HashMap;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import attributes.AttributeField;
import decimalNumber.DecimalNumber;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.LayoutManager;
import interfaces_abstractions.ObserverManager;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.InterruptionObjectTemplate;
import rIntegration.RFunctionContainer;
import spatialAndTemporalElements.PatchStateTemplate;

public class PopupPatchStateObjectOffset extends AbstractPopup{
	
	@FXML public Label labelTitle;
	@FXML public TextField textFieldName, textFieldType, textFieldDistribution;
	@FXML public Button buttonDelete, buttonApplyChanges;
	@FXML public VBox vboxArguments;
	@FXML public GridPane gridPaneArgumentHeaders;
	
	@FXML public VBox vboxFrequency;
	@FXML public RadioButton radioButtonFrequencyNo, radioButtonFrequencyYes;
	@FXML public TextField textFieldFrequencyOriginal, textFieldFrequencyOffset;
	@FXML public GridPane gridPaneFrequency;
	
	@FXML public RadioButton radioButtonValueNo, radioButtonValueYes;
	
	// A map that connects the name of an attribute of the distribution to the TextField for that attribute
	HashMap<String, TextField> argumentNameToOriginalTextFieldMap = new HashMap<>();
	HashMap<String, TextField> argumentNameToOffsetTextFieldMap = new HashMap<>();

	// An offset is always for a specific patch state
	private final PatchStateTemplate state;
	private AbstractObjectiveTemplate object;
	
	private final boolean thereAlreadyIsAnOffsetToThisObject;
	
	/** Main constructor*/
	public PopupPatchStateObjectOffset(MouseEvent e, PatchStateTemplate state, AbstractObjectiveTemplate object){
		super("fxml_popupPatchStateObjectOffset.fxml", e, true);

		this.state = state;
		this.object = object;
		
		if (object == null)
			throw new IllegalStateException("Setting an offset to a non-existing object");
		if (state == null)
			throw new IllegalStateException("Setting an offset to a non-existing patch state");
		
		// Either find the existing offset or create a new one
		thereAlreadyIsAnOffsetToThisObject = state.hasOffsetFor(object);
				
		// Set the nodes
		setNodes();

		// Set the values in the nodes
		update();
		
	}

	@Override
	public void setNodes() {
		// Set the remove button mechanics
		buttonDelete.setOnAction(e -> {state.removeObjectOffset(object); this.close();});
	
		// Set the add button mechanics
		buttonApplyChanges.setOnAction(e -> {
			if (validateInput()){
				setNewOffset();
				View.getView().update();
				close();
			}
		});
		
		// Set visibility mechanics
		gridPaneFrequency.managedProperty().bind(this.radioButtonFrequencyYes.selectedProperty());
		gridPaneFrequency.visibleProperty().bind(this.radioButtonFrequencyYes.selectedProperty());
		
		vboxArguments.managedProperty().bind(this.radioButtonValueYes.selectedProperty());
		vboxArguments.visibleProperty().bind(this.radioButtonValueYes.selectedProperty());

		if (object instanceof InterruptionObjectTemplate){
			vboxFrequency.managedProperty().bind(this.radioButtonFrequencyYes.selectedProperty());
			vboxFrequency.visibleProperty().bind(this.radioButtonFrequencyYes.selectedProperty());
		}
	}

	@Override
	public void update() {
		
		// Set the text on the title label and apply changes button
		if (!thereAlreadyIsAnOffsetToThisObject) {
			labelTitle.setText("New offset");
			buttonApplyChanges.setText("Create offset");
		} else {
			labelTitle.setText("Modify offset");
			buttonApplyChanges.setText("Apply changes");
		}

		// Set the labelName and labelType labels
		textFieldName.setText(object.getName());
		textFieldType.setText( AbstractObjectiveTemplate.classToClassString(AbstractObjectiveTemplate.objectToClass(object)));
		textFieldDistribution.setText(object.getAllSamplingDistributions().get(0).toString());

		// If there is a frequency, set that. 
		if (!(object instanceof InterruptionObjectTemplate)){
			textFieldFrequencyOriginal.setText(object.getFrequency().toStringWithoutTrailingZeros());
			
			// The new frequency (i.e., the original + offset) must be between 0 and 1
			DecimalNumber minimumAllowed = object.getFrequency().clone().negate();
			DecimalNumber maximumAllowed = new DecimalNumber(1).subtract(object.getFrequency());

			LayoutManager.setLayoutHandlerInRange(textFieldFrequencyOffset, minimumAllowed, maximumAllowed);
		
		}

		// If there already is an offset, set the textFieldFrequencyOffset to that offset. Otherwise, set a 0
		if (state.hasFrequencyOffsetFor(object)){
			this.radioButtonFrequencyYes.setSelected(true);
			textFieldFrequencyOffset.setText(state.getFrequencyOffsets(object).toStringWithoutTrailingZeros());
		}
		else {
			this.radioButtonFrequencyNo.setSelected(true);
			textFieldFrequencyOffset.setText("0");
		}

		
		// Next, set the offset to the sampling distribution
		RFunctionContainer rfc = object.getAllSamplingDistributions().get(0);
		
		// Set the textFieldDistribution
		textFieldDistribution.setText(rfc.getRFunction().getName());

		// Empty vboxArguments
		vboxArguments.getChildren().removeAll(vboxArguments.getChildren());
		vboxArguments.getChildren().add(this.gridPaneArgumentHeaders);

		// Empty the hashmaps
		argumentNameToOriginalTextFieldMap = new HashMap<>();
		argumentNameToOffsetTextFieldMap = new HashMap<>();
		
		// Create a new row in vboxArguments for each argument used by the function
		for (AttributeField af: rfc.getRFunction().getInputFieldCopy()){
			// can skip the domain - no offset for domains
			if (!af.getName().equalsIgnoreCase("domain")){
				GridPane newGrid = new GridPane();
				newGrid.setMinHeight(30);
				newGrid.setMaxHeight(30);
				newGrid.setMaxWidth(vboxArguments.getWidth());
				newGrid.setMinWidth(vboxArguments.getWidth());

				//Add the columns
				ColumnConstraints col0 = new ColumnConstraints(10);
				ColumnConstraints col1 = new ColumnConstraints(70);
				ColumnConstraints col2 = new ColumnConstraints(5);
				ColumnConstraints col3 = new ColumnConstraints(95);
				ColumnConstraints col4 = new ColumnConstraints(15);
				ColumnConstraints col5 = new ColumnConstraints(100);
				ColumnConstraints col6 = new ColumnConstraints(5);
				newGrid.getColumnConstraints().addAll(col0, col1, col2, col3, col4, col5, col6);

				// Create the label for the field name
				Label labelName = new Label(af.getName().substring(0, 1).toUpperCase() +af.getName().substring(1).toLowerCase()+":");
				labelName.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupLabel.css").toExternalForm());
				labelName.getStyleClass().add("fieldName");

				// Create a disabled TextField for the old value
				// Note that if there is an object that is split over runs, the text in this field is a bit more complicated (minimum and maximum)
				TextField textFieldOriginalArgument= new TextField();
				textFieldOriginalArgument.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupTextField.css").toExternalForm());
				textFieldOriginalArgument.setDisable(true);
				
				// Keep a record of the argument name and text field
				argumentNameToOriginalTextFieldMap.put(af.getName(), textFieldOriginalArgument);

				// Create the TextField for the offsets
				TextField textFieldOffset= new TextField();
				textFieldOffset.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupTextField.css").toExternalForm());
				
				// Keep a record of the argument name and text field
				argumentNameToOffsetTextFieldMap.put(af.getName(), textFieldOffset);
				
				// Create a label for the + sign
				Label labelPlus = new Label("+");
				GridPane.setHalignment(labelPlus, HPos.CENTER);
				
				// Add and set Margins
		        newGrid.addRow(0, new Label(""), labelName, new Label(""), textFieldOriginalArgument, labelPlus, textFieldOffset, new Label(""));

				vboxArguments.getChildren().add(newGrid);
			}
		}

		// If there is a single function
		if ( object.useOneDistribution()){
			// Set the textfields for the arguments
			for (AttributeField af: rfc.getLoadedArguments()){
				if (!af.getName().equalsIgnoreCase("domain")){
					// Set the original value
					this.argumentNameToOriginalTextFieldMap.get(af.getName()).setText(af.getValueStringWithoutTrailingZeros());
					
					// The new value (i.e., the original + offset) must adhere to the restrictions posed by the function argument
					DecimalNumber minimumAllowed = FieldRestriction.additionUntilMinimum(af.getValueStringWithoutTrailingZeros(), af.getFieldRestriction());
					DecimalNumber maximumAllowed = FieldRestriction.additionUntilMaximum(af.getValueStringWithoutTrailingZeros(), af.getFieldRestriction());

					LayoutManager.setLayoutHandlerInRange(this.argumentNameToOffsetTextFieldMap.get(af.getName()), minimumAllowed, maximumAllowed);
				}
			}
		}

		// If there is are multiple function
		if ( !object.useOneDistribution()){
			// Set the textfields for the arguments
			for (AttributeField af: rfc.getLoadedArguments()){
				if (!af.getName().equalsIgnoreCase("domain")){
					
					// Set the original value: the minimum and maximum
					AttributeField[] previouslyUsedParameterValues = object.getPreviouslyUsedMinimumMaximumAndStepsize(af.getName());

					String text = "Between " + previouslyUsedParameterValues[0].getValueStringWithoutTrailingZeros() + " and " +previouslyUsedParameterValues[1].getValueStringWithoutTrailingZeros();
					this.argumentNameToOriginalTextFieldMap.get(af.getName()).setText(text);

					// After applying the offset, the lowest used argument plus that offset cannot be lower than the minimum value allowed for this argument
					DecimalNumber minimumAllowed = FieldRestriction.additionUntilMinimum(previouslyUsedParameterValues[0].getValueStringWithoutTrailingZeros(), af.getFieldRestriction());

					// After applying the offset, the highest used argument plus that offset cannot be higher than the maximum value allowed for this argument
					DecimalNumber maximumAllowed = FieldRestriction.additionUntilMaximum(previouslyUsedParameterValues[1].getValueStringWithoutTrailingZeros(), af.getFieldRestriction());

					LayoutManager.setLayoutHandlerInRange(this.argumentNameToOffsetTextFieldMap.get(af.getName()), minimumAllowed, maximumAllowed);
				}
			}
		}

		// If there is a value offset to this object: fill in the offsets. Otherwise, set 0's
		if (state.hasValueOffsetFor(object)){
			this.radioButtonValueYes.setSelected(true);
			for (String s: argumentNameToOffsetTextFieldMap.keySet()){
				TextField tf = argumentNameToOffsetTextFieldMap.get(s);
				tf.setText(state.getValueOffsets(object, s).getValueStringWithoutTrailingZeros());
			}
		} else {
			this.radioButtonValueYes.setSelected(false);
			for (String s: argumentNameToOffsetTextFieldMap.keySet()){
				TextField tf = argumentNameToOffsetTextFieldMap.get(s);
				tf.setText("0");
			}
		}
	}
	
	/** Checks if all fields have permissible values. If not, pops off a warning toast and returns false.*/
	private boolean validateInput(){
	
		if (this.gridPaneFrequency.isVisible() && LayoutManager.isInvalid(textFieldFrequencyOffset)){
			View.getView().showWarningToast("Please enter a valid frequency offsets. Frequences have to be within 0 and 1.");
			return false;
		}	
		for (String key: this.argumentNameToOffsetTextFieldMap.keySet()){
			TextField tf = argumentNameToOffsetTextFieldMap.get(key);
			if (LayoutManager.isInvalid(tf)){
				View.getView().showWarningToast("Please enter a valid offset value for " + key);
				return false;
			}
		}
		return true;
	}

	/** Set an object offset based on the filled in data. Returns null if neither a frequency nor a value offset is set.*/
	private void setNewOffset(){
		try {
			if (radioButtonFrequencyNo.isSelected() && radioButtonValueNo.isSelected())
				return ;

			// Get the frequency offset, if applicable
			DecimalNumber frequencyOffset = null;
			if (radioButtonFrequencyYes.isSelected()){
				frequencyOffset = new DecimalNumber(textFieldFrequencyOffset.getText());
			}

			// Get the value offset, if applicable
			AttributeField[] argumentOffsets = null;
			if (radioButtonValueYes.isSelected()){
				ArrayList<String> keySet = new ArrayList<>();
				for (String s : argumentNameToOffsetTextFieldMap.keySet())
					keySet.add(s);
				
				argumentOffsets = new AttributeField[keySet.size()];
				for (int i = 0; i < keySet.size(); i++)
					argumentOffsets[i] = new AttributeField(
							keySet.get(i), 
							new DecimalNumber(argumentNameToOffsetTextFieldMap.get(keySet.get(i)).getText()));
			}

			state.setObjectOffset(object, argumentOffsets, frequencyOffset);
		} catch (RestrictionViolationException e) {ObserverManager.notifyObserversOfError(e);}
	}

	
	
}
