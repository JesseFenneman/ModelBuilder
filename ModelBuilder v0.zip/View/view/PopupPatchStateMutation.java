package view;

import java.util.HashMap;

import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import decimalNumber.DecimalNumberMatrixTableView;
import decimalNumber.SafeDecimalNumberToStringConverter;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.ObserverManager;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.GridPane;
import javafx.util.Callback;
import spatialAndTemporalElements.PatchStateMutationsTemplate;
import spatialAndTemporalElements.PatchStateTemplate;
import spatialAndTemporalElements.PatchTemplate;
import start.Console;

/** The popup that shows the state transitions (mutations)
 * for a PatchState*/
public class PopupPatchStateMutation extends AbstractPopup{

	@FXML public Label 		labelTitle;
	@FXML public GridPane 	gridPaneMatrixContainer, gridPaneStartingContainer;
	@FXML public Button		buttonOK;
	@FXML public TableView< PatchStateTemplate > tableViewStartingProbabilities;
	@FXML public TableColumn<PatchStateTemplate, String> tableColumnStartingState;
	@FXML public TableColumn<PatchStateTemplate, DecimalNumber> tableColumnStartingProbability;

	public DecimalNumberMatrixTableView mutationMatrixView;	
	public final PatchTemplate patch;
	public final PatchStateMutationsTemplate mutations;
	public final ObservableList<PatchStateTemplate> states;
	public final HashMap<PatchStateTemplate, DecimalNumber> tempStartingProbabilityHashMap;

	// The values on the screen are not directly changed in the MutationsTemplate (they have to be checked first). Hence, we will first store them in a tempMatrix
	public final DecimalNumberMatrix tempMatrixMutation; 

	public boolean somethingChanges = false;

	public PopupPatchStateMutation(PatchTemplate patch){
		super("fxml_popupPatchStateMutations.fxml", View.getView().getPaneCenterX(), View.getView().getPaneCenterY(), false);

		this.patch = patch;
		this.mutations = patch.getMutations();

		// Get a tempMatrix to store the mutation values in
		this.tempMatrixMutation = mutations.toDecimalNumberMatrix().clone();

		// Set the states
		states = FXCollections.observableArrayList();
		tempStartingProbabilityHashMap = new HashMap<>();
		for (PatchStateTemplate s: patch.getAllStates()) {
			states.add(s);
			tempStartingProbabilityHashMap.put(s, patch.getStartingProbability(s));
		}

		// Set the nodes
		setNodes();

		// Set the values in the nodes
		update();

		Console.print("Opened a new Popup window for Patch state mutations in patch: '" + mutations.getPatch().getName() + "': \n" + mutations);
	}

	@Override
	public void setNodes() {
		labelTitle.setText("How do states mutate in patch " + patch.getName()+ "?");
		buttonOK.setOnAction(e -> { 

			// Check if there is at least 1 negative value in the starting probabilities
			if (this.containsNegativeStartingProbabilities())
				ObserverManager.makeWarningToast("There is at least one negative starting probability. Please enter only non-negative numbers.");

			// Check if there is at least 1 negative value in the mutation matrix 
			if (this.containsNegativeMutationProbabilities())
				ObserverManager.makeWarningToast("There is at least one negative mutation probability. Please enter only non-negative numbers.");

			// Check if the starting probabilities need to be normalized
			else if (this.normalizeStartingProbabilities())
				ObserverManager.makeWarningToast("Changed starting probabilities so that they sum to 1. Please recheck values. Press button again to accept changes.");

			// Check if the mutation matrix need to be normalized
			else if (normalizeMutationMatrix()){
				ObserverManager.makeWarningToast("Changed values so that each row sums to 1. Please recheck values. Press button again to accept changes.");

				// Finally: all is good. Change the actual starting probabilities and mutation matrix
			} else{
				mutations.setAll(tempMatrixMutation);
				
				for (PatchStateTemplate state: patch.getAllStates()) {
					patch.setStartingProbability(state, tempStartingProbabilityHashMap.get(state));
				}
				ObserverManager.makeToast("Succesfully changed the mutation probabilities of patch " + patch.getName());
				close();
			}
		});

		// Set the TableView for the starting probabilities
		tableViewStartingProbabilities.setEditable(true);

		// Set the CellValueFactory for tableColumnStartingState: this factory determines which String should be shown.
		tableColumnStartingState.setCellValueFactory(
				new Callback<CellDataFeatures<PatchStateTemplate, String>, ObservableValue<String>>(){
					@Override
					public ObservableValue<String> call(CellDataFeatures<PatchStateTemplate, String> t) {
						return new SimpleStringProperty(t.getValue().getName());
					}
				});		
		tableColumnStartingState.setEditable(false);

		// Set the CellValueFactory for tableColumnStartingProbability: this factory determines which DecimalNumber should be shown.
		tableColumnStartingProbability.setCellValueFactory(
				new Callback<CellDataFeatures<PatchStateTemplate, DecimalNumber>, ObservableValue<DecimalNumber>>(){
					@Override
					public ObservableValue<DecimalNumber> call(CellDataFeatures<PatchStateTemplate, DecimalNumber> t) {
						return new SimpleObjectProperty<>(tempStartingProbabilityHashMap.get(t.getValue()));
					}
				});

		// Set the CellFactory for tableColumnStartingProbability: tell Java how to go from a DecimalNumber to a string.
		tableColumnStartingProbability.setCellFactory(TextFieldTableCell.forTableColumn(new SafeDecimalNumberToStringConverter().setRemoveTrailingZeros(true)));


		// Tell java how to handle the changes
		tableColumnStartingProbability.setOnEditCommit(
				new EventHandler<TableColumn.CellEditEvent<PatchStateTemplate, DecimalNumber>>() {
					@Override
					public void handle(CellEditEvent<PatchStateTemplate, DecimalNumber> t) {
						if (t.getNewValue() == null) {
							t.getTableView().refresh();
							return;
						}
						// Find origin 
						PatchStateTemplate origin = t.getRowValue();
						tempStartingProbabilityHashMap.put(origin, t.getNewValue());
						t.getTableView().refresh();
					}});
		tableColumnStartingProbability.setEditable(true);

		// Set the data
		tableViewStartingProbabilities.setItems(this.states);

		// Create a TableView for the mutation probability matrix
		mutationMatrixView = new DecimalNumberMatrixTableView(tempMatrixMutation, -1, true, true, false ,-1, true);
		gridPaneMatrixContainer.getChildren().add(mutationMatrixView);
	}

	@Override
	public void update() {

	}


	/** Returns true if at least one starting probability has a negative value*/
	public boolean containsNegativeStartingProbabilities() {
		for (DecimalNumber dn: this.tempStartingProbabilityHashMap.values())
			if (dn.smallerThan(0))
				return true;
		return false;
	}

	/** Returns true if at least one mutation probability has a negative value*/
	public boolean containsNegativeMutationProbabilities() {
		for (DecimalNumberArray dna : tempMatrixMutation.rowMatrix())
			for (DecimalNumber entry: dna)
				if (entry .smallerThan(0))
					return true;	
		return false;
	}

	/** Normalizes the starting probabilities so that all probabilities sum to 1. Returns true if any normalization was done, and false otherwise*/
	private boolean normalizeStartingProbabilities(){
		boolean changedSomething = false;
		DecimalNumber sum = new DecimalNumber(0);
		for (DecimalNumber dn: this.tempStartingProbabilityHashMap.values())
			sum.add(dn, true);
		if (!sum.equals(DecimalNumber.ONE, false)) {
			changedSomething = true;
			if (!sum.equals(DecimalNumber.ZERO)) {
				for (DecimalNumber dn: this.tempStartingProbabilityHashMap.values())
					dn.divide(sum, true);
			} else {
				for (DecimalNumber dn: this.tempStartingProbabilityHashMap.values())
					dn.set(new DecimalNumber(1).divide(patch.getAllStates().size()));
			}
		}

		this.tableViewStartingProbabilities.refresh();	
		return changedSomething;
	}

	/** Normalizes the mutation matrix so that all rows sum to 1. Returns true if any normalization was done, and false otherwise*/
	private boolean normalizeMutationMatrix(){
		boolean changedSomething = false;
		for (DecimalNumberArray dna : tempMatrixMutation.rowMatrix()) {
			if (!dna.sum().equals(1)){
				dna.scaleToSumToOne();
				changedSomething = true;
			} 
		}

		mutationMatrixView.refresh();	
		return changedSomething;
	}



}
