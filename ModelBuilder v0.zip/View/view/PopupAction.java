package view;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import actionElements.ActionTemplate;
import actionElements.ActionTemplate.ActionType;
import actionElements.ActionTemplatePostcondition;
import actionElements.ActionTemplatePostconditionApplyExtrinsic;
import actionElements.ActionTemplatePostconditionChangeReference;
import actionElements.ActionTemplatePostconditionConsumeResource;
import actionElements.ActionTemplatePostconditionCreateReference;
import actionElements.ActionTemplatePostconditionDecreasePhenotype;
import actionElements.ActionTemplatePostconditionIncreasePhenotype;
import actionElements.ActionTemplatePostconditionInstantiateExtrinsic;
import actionElements.ActionTemplatePostconditionInstantiateObject;
import actionElements.ActionTemplatePostconditionInterruptEncounter;
import actionElements.ActionTemplatePostconditionMovePatch;
import actionElements.ActionTemplatePostconditionPostponeWithInterruption;
import actionElements.ActionTemplatePostconditionPostponeWithoutInterruption;
import actionElements.ActionTemplatePostconditionSampleCue;
import actionElements.ActionTemplatePostconditionSetGameMode;
import actionElements.ActionTemplatePostconditionSetPhenotype;
import actionElements.ActionTemplatePostconditionStartEncounter;
import actionElements.ActionTemplatePostconditionStore;
import actionElements.ActionTemplatePrecondition;
import actionElements.ActionTemplatePrecondition.Operator;
import actionElements.ActionTemplatePreconditionAtLeastOneResourcePresent;
import actionElements.ActionTemplatePreconditionGameType;
import actionElements.ActionTemplatePreconditionLocation;
import actionElements.ActionTemplatePreconditionPhenotype;
import actionElements.ActionTemplatePreconditionResourceConsumed;
import actionElements.ActionTemplatePreconditionResourceValue;
import actionElements.ActionTemplatePreconditionSuccessfulInstantiation;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.LayoutManager;
import interfaces_abstractions.LayoutManager.State;
import interfaces_abstractions.ObserverManager;
import javafx.collections.ListChangeListener;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.util.Callback;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.CueTemplate;
import objectiveElements.Instance;
import objectiveElements.InstanceAlias;
import objectiveElements.InstanceNull;
import objectiveElements.InstanceReference;
import objectiveElements.PhenotypeObjectTemplate;
import spatialAndTemporalElements.PatchStateTemplate;
import start.Console;

public class PopupAction extends AbstractPopup {

	@FXML public Label labelTitle;
	@FXML public Label labelBelowPreconditions,labelBelowPostconditions,labelName;

	@FXML public TextField textFieldActionName;
	@FXML public ListView<ActionTemplatePrecondition> listViewPreconditions;
	@FXML public ComboBox<Class<?extends ActionTemplatePrecondition>> comboboxPreconditionClass;
	@FXML public ComboBox<Object> comboboxPreconditionSubject;
	@FXML public ComboBox<Operator> comboboxPreconditionOperator;
	@FXML public ComboBox<Object> comboboxPreconditionTarget;
	@FXML public Button buttonAddPrecondition;
	@FXML public Button buttonRemovePrecondition;

	@FXML public ListView<ActionTemplatePostcondition> listViewPostconditions;
	@FXML public ComboBox<Class< ? extends ActionTemplatePostcondition>> comboboxPostconditionClass;
	@FXML public ComboBox<Object> comboboxPostconditionSubject;
	@FXML public ComboBox<Object> comboboxPostconditionQualifier;

	// Specific elements for the 'Store' postcondition.
	@FXML public ComboBox<PhenotypeObjectTemplate> comboboxPostconditionSlotPhenotypeObject;
	@FXML public ComboBox<InstanceReference> comboboxPostconditionSlotInterruptionReference;
	@FXML public ComboBox<InstanceReference> comboboxPostconditionSlotDelay;
	@FXML public Spinner<Integer> spinnerSlotPeriodicity;

	@FXML public Button buttonAutofill;
	@FXML public Button buttonSetPostcondition;
	@FXML public Button buttonRemovePostcondition;
	@FXML public TextField textFieldActionQualifierName;

	@FXML public Button buttonApplyChanges;

	private final ActionType type;
	private final ActionTemplate existingTemplate;
	private ActionTemplatePrecondition temporaryPrecondition; // The precondition that we are still 'building' with the comboboxes
	private ActionTemplatePostcondition temporaryPostcondition; // The Postcondition that we are still 'building' with the comboboxes


	/** Create a new ActionPopup. If the action is left empty,
	 * a new action will be created. If the action is not empty,
	 * that action will be modified. The popup will show in the
	 * middle of the View's main scroll pane.*/
	public PopupAction(ActionTemplate action, ActionType type){
		super("fxml_popupAddOrModifyAction.fxml",
				View.getView().getPaneCenterX()-500,
				View.getView().getPaneCenterY()-230, true);

		this.type = type;
		this.existingTemplate = action;

		// Set the nodes
		setNodes();

		// Set the values in the nodes
		update();

		if (existingTemplate == null)
			Console.print("Opened a new popup window for to create a new ActionTemplate with type: " + type + ".");
		else
			Console.print("Opened a new popup window for to modify the action: " + existingTemplate.getName() + ".");

	}

	@Override
	public void setNodes() {
		if (existingTemplate == null){

			if (type == ActionType.BETWEEN_ENCOUNTERS) {
				buttonApplyChanges.setText("Add new action");
				labelTitle.setText("Add a possible action an agent can take between encounters");
				labelBelowPreconditions.setText("Can perform this action if:");
				labelBelowPostconditions.setText("The consequences of this action are:");
				labelName.setText("Action name:");
			}

			else if (type == ActionType.DURING_ENCOUNTER){
				buttonApplyChanges.setText("Add new action");
				labelTitle.setText("Add a possible action an agent can take during a resource encounter");
				labelBelowPreconditions.setText("Can perform this action if:");
				labelBelowPostconditions.setText("The consequences of this action are:");
				labelName.setText("Action name:");
			}


			else if (type == ActionType.MUTATION) {
				buttonApplyChanges.setText("Add a new Mutation phase rule");
				labelTitle.setText("Add a new rule that is executed during each mutation phase");
				labelBelowPreconditions.setText("This rule will be executed if:");
				labelBelowPostconditions.setText("The consequences of this rule are:");
				labelName.setText("Rule name:");
			}

			else if (type == ActionType.SETUP_ENCOUNTER) {
				buttonApplyChanges.setText("Add new encounter startup rule");
				labelTitle.setText("Add a new rule that is executed at the start of an encounter");
				labelBelowPreconditions.setText("This rule will be executed if:");
				labelBelowPostconditions.setText("The consequences of this rule are:");
				labelName.setText("Rule name:");
			}
		}
		else{


			this.textFieldActionName.setDisable(true);
			if (type == ActionType.BETWEEN_ENCOUNTERS){
				labelTitle.setText("Change the action an agent can take between encounters");
				labelBelowPreconditions.setText("Can perform this action if:");
				labelBelowPostconditions.setText("The consequences of this action are:");
				labelName.setText("Action name:");
				buttonApplyChanges.setText("Modify action");
			}

			else if (type == ActionType.DURING_ENCOUNTER){
				labelTitle.setText("Change the action an agent can take durng a resource encounter");
				labelBelowPreconditions.setText("Can perform this action if:");
				labelBelowPostconditions.setText("The consequences of this action are:");
				labelName.setText("Action name:");
				buttonApplyChanges.setText("Modify action");
			}

			else if (type == ActionType.MUTATION){
				labelTitle.setText("Change a rule that is executed at each mutation phase");
				labelBelowPreconditions.setText("This rule will be executed if:");
				labelBelowPostconditions.setText("The consequences of this rule are:");
				labelName.setText("Rule name:");
				buttonApplyChanges.setText("Modify startup rule");
			}
			else if (type == ActionType.SETUP_ENCOUNTER){
				labelTitle.setText("Change a rule that is executed at the start of an encounter");
				labelBelowPreconditions.setText("This rule will be executed if:");
				labelBelowPostconditions.setText("The consequences of this rule are:");
				labelName.setText("Rule name:");
				buttonApplyChanges.setText("Modify startup rule");
			}

		}

		LayoutManager.setLayoutHandler(textFieldActionName, FieldRestriction.STRING_NUMBERS_LETTERS_ONLY);
		LayoutManager.setLayoutHandler(textFieldActionQualifierName, FieldRestriction.VARIABLE_NAME);

		buttonApplyChanges.setOnAction(e -> {applyChangeButtonPressed();});

		setPreconditionNodes();
		setPostconditionNodes();
	}


	/** Set all nodes for the precondition side of the popup*/
	private void setPreconditionNodes() {

		// The buttonAddPrecondition to be invisible until all fields have been filled.
		// When pressed, the temporary precondition (which we make and update every time
		// we change the precondition comboboxes) should be added to the listview
		buttonAddPrecondition.setVisible(false);
		buttonAddPrecondition.setOnAction(e -> {
			listViewPreconditions.getItems().add(temporaryPrecondition);
			comboboxPreconditionClass.getSelectionModel().select(-1);
			comboboxPreconditionSubject.getSelectionModel().select(-1);
			comboboxPreconditionOperator.getSelectionModel().select(-1);
			comboboxPreconditionTarget.getSelectionModel().select(-1);
			comboboxPreconditionSubject.getItems().removeAll(comboboxPreconditionSubject.getItems());
			comboboxPreconditionOperator.getItems().removeAll(comboboxPreconditionOperator.getItems());
			comboboxPreconditionTarget.getItems().removeAll(comboboxPreconditionTarget.getItems());
			comboboxPreconditionSubject.setVisible(false);
			comboboxPreconditionOperator.setVisible(false);
			comboboxPreconditionTarget.setVisible(false);
			buttonAddPrecondition.setVisible(false);
			temporaryPrecondition = null;
		});

		// The remove precondition button is visible only if a precondition in the listview is selected
		buttonRemovePrecondition.visibleProperty().bind(listViewPreconditions.getSelectionModel().selectedItemProperty().isNotNull());
		buttonRemovePrecondition.setOnAction(e -> {listViewPreconditions.getItems().remove(listViewPreconditions.getSelectionModel().getSelectedItem());});

		// The first precondition combobox should have almost all the possible precondition classes for this action type...
		if (this.type == ActionType.DURING_ENCOUNTER)
			comboboxPreconditionClass.getItems().addAll(ActionTemplatePrecondition.getAllPreconditionTypesUsableDuringEncounter());
		else if (this.type == ActionType.BETWEEN_ENCOUNTERS)
			comboboxPreconditionClass.getItems().addAll(ActionTemplatePrecondition.getAllPreconditionTypesUsableBetweenEncounter());
		else if (this.type == ActionType.MUTATION)
			comboboxPreconditionClass.getItems().addAll(ActionTemplatePrecondition.getAllPreconditionTypesUsableForMutations());
		else if (this.type == ActionType.SETUP_ENCOUNTER)
			comboboxPreconditionClass.getItems().addAll(ActionTemplatePrecondition.getAllPreconditionTypesUsableWhenSettingUpEncounter());

		//... and then remove all the options that are not (yet) available:
		// PRECONDITIONS
		// If no resource has been instantiated yet, do not show resources
		if (View.getView().workspace.getAllResourceInstances().size() == 0){
			comboboxPreconditionClass.getItems().remove(ActionTemplatePreconditionResourceConsumed.class);
			comboboxPreconditionClass.getItems().remove(ActionTemplatePreconditionAtLeastOneResourcePresent.class);
			comboboxPreconditionClass.getItems().remove(ActionTemplatePreconditionResourceValue.class);
		}

		// If there is only the standard game type, do not show game type
		if (View.getView().workspace.getGameTypes().size() == 1){
			comboboxPreconditionClass.getItems().remove(ActionTemplatePreconditionGameType.class);
		}

		// If there are no phenotypic dimensions declared yet, do not show phenotypes
		if (View.getView().workspace.getAllPhenotypeObjects().size() == 0)
			comboboxPreconditionClass.getItems().remove(ActionTemplatePreconditionPhenotype.class);

		// Also, if there is only one patch, asking for the location doesn't make much sense.
		if (View.getView().workspace.getAllPatches().size() == 1)
			comboboxPreconditionClass.getItems().remove(ActionTemplatePreconditionLocation.class);

		// If there are no attempted instantiation, then do not show the precondition asking whether an instantiation was successful
		if (View.getView().workspace.getAllInstances().size() == 0)
			comboboxPreconditionClass.getItems().remove(ActionTemplatePreconditionSuccessfulInstantiation.class);

		// If there are no phenotypic slots defined, do not show any preconditions with phenotype slots
		//TODO:


		// The second, third, and fourth precondition comboboxes should be invisible if there is no selection in the first
		comboboxPreconditionSubject.setVisible(false);
		comboboxPreconditionOperator.setVisible(false);
		comboboxPreconditionTarget.setVisible(false);

		// The contents of the second, third, and fourth precondition comboboxes depends on what the first combobox has
		comboboxPreconditionClass.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			comboboxPreconditionSubject.getSelectionModel().select(-1);
			comboboxPreconditionOperator.getSelectionModel().select(-1);
			comboboxPreconditionTarget.getSelectionModel().select(-1);
			comboboxPreconditionSubject.getItems().removeAll(comboboxPreconditionSubject.getItems());
			comboboxPreconditionOperator.getItems().removeAll(comboboxPreconditionOperator.getItems());
			comboboxPreconditionTarget.getItems().removeAll(comboboxPreconditionTarget.getItems());

			if (newValue != null){
				temporaryPrecondition = ActionTemplatePrecondition.createPreconditionTemplate(comboboxPreconditionClass.getSelectionModel().getSelectedItem());

				// Set the subjects
				if (temporaryPrecondition.getPossibleSubjects() != null){
					comboboxPreconditionSubject.getItems().addAll(temporaryPrecondition.getPossibleSubjects());
					comboboxPreconditionSubject.setVisible(true);
				} else
					comboboxPreconditionSubject.setVisible(false);

				// Set the operators
				if (temporaryPrecondition.getPossibleOperators() != null){
					comboboxPreconditionOperator.getItems().addAll(temporaryPrecondition.getPossibleOperators());
					comboboxPreconditionOperator.setVisible(true);
				} else
					comboboxPreconditionOperator.setVisible(false);

				// Set the targets
				if (temporaryPrecondition.getPossibleTargets() != null){
					comboboxPreconditionTarget.getItems().addAll(temporaryPrecondition.getPossibleTargets());
					comboboxPreconditionTarget.setVisible(true);
				}else
					comboboxPreconditionTarget.setVisible(false);
			}
			checkIfAddPreconditionButtonShouldBeVisible();
		});

		// Every time the 2, 3, and 4th comboboxes are changed, the temporaryPrecondition should be updated
		// Also note that when updating the subject, we sometimes have to update the target box - as the
		// targets might depend on the subject selected
		comboboxPreconditionSubject.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (temporaryPrecondition != null && newValue != null){
				temporaryPrecondition.setSubject(comboboxPreconditionSubject.getSelectionModel().getSelectedItem());
				if (temporaryPrecondition.getPossibleTargets() != null){
					comboboxPreconditionTarget.getItems().removeAll(comboboxPreconditionTarget.getItems());
					comboboxPreconditionTarget.getItems().addAll(temporaryPrecondition.getPossibleTargets());
					comboboxPreconditionTarget.setVisible(true);
				}
				checkIfAddPreconditionButtonShouldBeVisible();
			}
		});
		comboboxPreconditionOperator.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (temporaryPrecondition != null && newValue != null){
				temporaryPrecondition.setOperator(comboboxPreconditionOperator.getSelectionModel().getSelectedItem());
				checkIfAddPreconditionButtonShouldBeVisible();}
		});
		comboboxPreconditionTarget.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (temporaryPrecondition != null && newValue != null){
				temporaryPrecondition.setTarget(comboboxPreconditionTarget.getSelectionModel().getSelectedItem());
				checkIfAddPreconditionButtonShouldBeVisible();}
		});

		// Set how the precondition CLASS combobox should represent items
		Callback<ListView<Class<?extends ActionTemplatePrecondition>>, ListCell<Class<?extends ActionTemplatePrecondition>>> preconditionClassCellFactory =
				new  Callback<ListView<Class<?extends ActionTemplatePrecondition>>, ListCell<Class<?extends ActionTemplatePrecondition>>>(){
			@Override
			public ListCell<Class<? extends ActionTemplatePrecondition>> call(
					ListView<Class<? extends ActionTemplatePrecondition>> clazz) {
				return new ListCell<Class<? extends ActionTemplatePrecondition>>(){
					@Override
					protected void updateItem(Class<? extends ActionTemplatePrecondition> item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(ActionTemplatePrecondition.toSimpleName(item));
						}
					}
				};
			}
		};
		comboboxPreconditionClass.setCellFactory(preconditionClassCellFactory);
		comboboxPreconditionClass.setButtonCell(preconditionClassCellFactory.call(null));

		// Set how the precondition SUBJECT combobox should represent items
		Callback<ListView<Object>, ListCell<Object>> preconditionSubjectCellFactory =
				new  Callback<ListView<Object>, ListCell<Object>>(){
			@Override
			public ListCell<Object> call(
					ListView<Object> sub) {
				return new ListCell<Object>(){
					@Override
					protected void updateItem(Object item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) 
							setGraphic(null);
						else if (item instanceof AbstractObjectiveTemplate)
							setText(((AbstractObjectiveTemplate)item).getName());
						else if (item instanceof Instance)
							setText(((InstanceReference)item).getName()+" (class: " + ((Instance)item).getAbstractObjectiveTemplate().getName()+ ")");
						else if (item instanceof InstanceReference)
							setText(((InstanceReference)item).getName()+" (class: " + ((InstanceReference)item).getAbstractObjectiveTemplate().getName()+ ")");
						else if (item instanceof AbstractPhenotypeSlotTemplate)
							setText("Slot: '" + ((AbstractPhenotypeSlotTemplate)item).getName()+ "'");
					}
				};
			}
		};
		comboboxPreconditionSubject.setCellFactory(preconditionSubjectCellFactory);
		comboboxPreconditionSubject.setButtonCell(preconditionSubjectCellFactory.call(null));

		// Set how the precondition OPERATOR combobox should represent items
		Callback<ListView<Operator>, ListCell<Operator>> preconditionOperatorCellFactory =
				new  Callback<ListView<Operator>, ListCell<Operator>>(){
			@Override
			public ListCell<Operator> call(
					ListView<Operator> op) {
				return new ListCell<Operator>(){
					@Override
					protected void updateItem(Operator item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(item.toString());
						}
					}
				};
			}
		};
		comboboxPreconditionOperator.setCellFactory(preconditionOperatorCellFactory);
		comboboxPreconditionOperator.setButtonCell(preconditionOperatorCellFactory.call(null));


		// Set how the precondition TARGET combobox should represent items
		Callback<ListView<Object>, ListCell<Object>> preconditionTargetCellFactory =
				new  Callback<ListView<Object>, ListCell<Object>>(){
			@Override
			public ListCell<Object> call(
					ListView<Object> tar) {
				return new ListCell<Object>(){
					@Override
					protected void updateItem(Object item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							if (item instanceof NumberObjectSingle)
								setText(((NumberObjectSingle) item).toStringWithoutTrailingZeros());
							else if (item instanceof PatchStateTemplate)
								setText(((PatchStateTemplate) item).getName() + " in patch: " + ((PatchStateTemplate) item).getPatch().getName());
							else if (item instanceof Instance)
								setText(((Instance)item).getName()+" (class: " + ((Instance)item).getAbstractObjectiveTemplate().getName()+ ")");
							else if (item instanceof InstanceAlias)
								setText(((InstanceAlias)item).getName()+" (class: " + ((InstanceAlias)item).getInitialInstance().getAbstractObjectiveTemplate().getName()+ ")");
							else
								setText(item.toString());
						}
					}
				};
			}
		};
		comboboxPreconditionTarget.setCellFactory(preconditionTargetCellFactory);
		comboboxPreconditionTarget.setButtonCell(preconditionTargetCellFactory.call(null));


	}

	/** Set all the nodes for the postcondition side of the popup*/
	private void setPostconditionNodes() {
		buttonSetPostcondition.setVisible(false);
		buttonAutofill.setVisible(false);
		buttonAutofill.setManaged(false);
		
		// The first postcondition combobox should have almost all the possible postcondition classes for this action type...
		if (type == ActionType.BETWEEN_ENCOUNTERS)
			comboboxPostconditionClass.getItems().addAll(ActionTemplatePostcondition.getAllPostconditionTypesUsableBetweenEncounter());
		else if (type == ActionType.DURING_ENCOUNTER)
			comboboxPostconditionClass.getItems().addAll(ActionTemplatePostcondition.getAllPostconditionTypesUsableDuringEncounter());
		else if (type == ActionType.SETUP_ENCOUNTER)
			comboboxPostconditionClass.getItems().addAll(ActionTemplatePostcondition.getAllPostconditionTypesUsableSettingUpEncounter());
		else if (type == ActionType.MUTATION)
			comboboxPostconditionClass.getItems().addAll(ActionTemplatePostcondition.getAllPostconditionTypesUsableDuringMutationPhase());
		else
			throw new IllegalStateException("Unknown action type: " + type);

		// But again, with some exceptions.
		// First, if there are no non-age phenotyes, remove the increase, decrease, and set phenotype options.
		if (View.getView().workspace.getAllPhenotypeObjectsExcludingAge().size() == 0){
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionIncreasePhenotype.class);
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionDecreasePhenotype.class);
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionSetPhenotype.class);
		}

		// Second, if there are no cues, remove the sample option
		if (View.getView().workspace.getAllCueTemplates().size() == 0)
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionSampleCue.class);

		// Third, if there are no instantiated resources, or there is no non-age phenotype, there is no consume resource action
		if (View.getView().workspace.getAllResourceInstanceReferences().size()==0 || 
				View.getView().workspace.getAllPhenotypeObjectsExcludingAge().size() == 0){
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionConsumeResource.class);
		}

		// Fourth, if there is no interruption, there is no interrupt encounter
		if (View.getView().workspace.getAllInterruptionObjects().size() == 0)
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionInterruptEncounter.class);

		// Fifth, if there is only one patch, there is no moving
		if (View.getView().workspace.getAllPatches().size() == 1)
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionMovePatch.class);

		// Sixth, if there is no encounter, there is no foraging
		if (View.getView().workspace.getAllResourceObjects().size() == 0)
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionStartEncounter.class);

		// Seventh and finally, if there is no instantiated delay, then there is no postponing
		if (View.getView().workspace.getAllDelayInstanceReferences().size()==0) {
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionPostponeWithInterruption.class);
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionPostponeWithoutInterruption.class);
		}

		// Eight, if there are no instantiated objects, there is nothing to set a reference to
		if (View.getView().workspace.getAllInstanceReferences().size() == 0) 
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionCreateReference.class);


		// Nine, if there are no instance references, cannot set a reference to a different instance
		if (View.getView().workspace.getAllInstanceAliases().size() == 0)
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionChangeReference.class);

		// Ten, if there are no interruptions, resources, or delays, cannot instantiated an object (phenotypes and extrinsic events cannot be instantiated)
		if (View.getView().workspace.getAllResourceObjects().size() + View.getView().workspace.getAllDelayObjects().size() + View.getView().workspace.getAllInterruptionObjects().size() == 0)
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionInstantiateObject.class);
		if (View.getView().workspace.getAllExtrinsicObjects().size() == 0)
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionInstantiateExtrinsic.class);

		// Eleven, without extrinsic events instantiated, cannot apply an extrinsic event
		if (View.getView().workspace.getAllExtrinsicInstances().size() == 0)
			comboboxPostconditionClass.getItems().remove(ActionTemplatePostconditionApplyExtrinsic.class);

		// Twelfth: if there are no phenotype slots, there should not be phenotype slot postconditions
		// TODO:

		// 13 (typing out the numbers was getting annoying): no delay instances means no storing in delayed resource slots

		// The other arguments should be invisible if there is no selection in the first
		comboboxPostconditionSubject.setVisible(false);
		comboboxPostconditionQualifier.setVisible(false);
		comboboxPostconditionQualifier.setManaged(false);
		textFieldActionQualifierName.setVisible(false);
		textFieldActionQualifierName.setManaged(false);
		comboboxPostconditionSlotPhenotypeObject.setManaged(false);
		comboboxPostconditionSlotInterruptionReference.setManaged(false);
		comboboxPostconditionSlotDelay.setManaged(false);
		spinnerSlotPeriodicity.setManaged(false);

		comboboxPostconditionSlotPhenotypeObject.setVisible(false);
		comboboxPostconditionSlotInterruptionReference.setVisible(false);
		comboboxPostconditionSlotDelay.setVisible(false);
		spinnerSlotPeriodicity.setVisible(false);

		// The remove postcondition button is visible only if a postcondition in the listview is selected
		buttonRemovePostcondition.visibleProperty().bind(listViewPostconditions.getSelectionModel().selectedItemProperty().isNotNull());
		buttonRemovePostcondition.setOnAction(e -> {

			ActionTemplatePostcondition selected = listViewPostconditions.getSelectionModel().getSelectedItem();

			if (selected instanceof ActionTemplatePostconditionInstantiateObject) 
				View.getView().workspace.harmonizeWithView();
			if (selected instanceof ActionTemplatePostconditionInstantiateExtrinsic) 
				View.getView().workspace.harmonizeWithView();
			if (selected instanceof ActionTemplatePostconditionCreateReference) 
				View.getView().workspace.harmonizeWithView();

			listViewPostconditions.getItems().remove(listViewPostconditions.getSelectionModel().getSelectedItem());
		});




		// The content and visibility of argument comboboxes and spinner depends on what is selected in the first combobox
		comboboxPostconditionClass.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {

			comboboxPostconditionSubject.getSelectionModel().select(-1);
			comboboxPostconditionQualifier.getSelectionModel().select(-1);
			comboboxPostconditionSlotPhenotypeObject.getSelectionModel().select(-1);
			comboboxPostconditionSlotInterruptionReference.getSelectionModel().select(-1);
			comboboxPostconditionSlotDelay.getSelectionModel().select(-1);
			//spinnerSlotPeriodicity.getValueFactory().setValue(null);

			comboboxPostconditionSubject.getItems().removeAll(comboboxPostconditionSubject.getItems());
			comboboxPostconditionQualifier.getItems().removeAll(comboboxPostconditionQualifier.getItems());
			comboboxPostconditionSlotPhenotypeObject.getItems().removeAll(comboboxPostconditionSlotPhenotypeObject.getItems());
			comboboxPostconditionSlotInterruptionReference.getItems().removeAll(comboboxPostconditionSlotInterruptionReference.getItems());
			comboboxPostconditionSlotInterruptionReference.getItems().removeAll(comboboxPostconditionSlotInterruptionReference.getItems());

			comboboxPostconditionSlotPhenotypeObject.setVisible(false);
			comboboxPostconditionSlotInterruptionReference.setVisible(false);
			comboboxPostconditionSlotDelay.setVisible(false);
			spinnerSlotPeriodicity.setVisible(false);

			comboboxPostconditionSlotPhenotypeObject.setManaged(false);
			comboboxPostconditionSlotInterruptionReference.setManaged(false);
			comboboxPostconditionSlotDelay.setManaged(false);
			spinnerSlotPeriodicity.setManaged(false);

			if (newValue != null){
				temporaryPostcondition = ActionTemplatePostcondition.createPostconditionTemplate(comboboxPostconditionClass.getSelectionModel().getSelectedItem());

				// Set the subjects
				if (temporaryPostcondition.getPossibleSubjects() != null){
					comboboxPostconditionSubject.getItems().addAll(temporaryPostcondition.getPossibleSubjects());
					comboboxPostconditionSubject.setVisible(true);
				} else
					comboboxPostconditionSubject.setVisible(false);

				// Set the qualifiers
				if (ActionTemplatePostcondition.getQualifierInputType(newValue) == ActionTemplatePostcondition.QualifierInputType.List) {
					textFieldActionQualifierName.setVisible(false);
					textFieldActionQualifierName.setManaged(false);
					if (temporaryPostcondition.getPossibleQualifiers() != null){
						comboboxPostconditionQualifier.getItems().addAll(temporaryPostcondition.getPossibleQualifiers());
						comboboxPostconditionQualifier.setVisible(true);
						comboboxPostconditionQualifier.setManaged(true);
					} else {
						comboboxPostconditionQualifier.setVisible(false);
						comboboxPostconditionQualifier.setManaged(false);
					}
				} else {
					textFieldActionQualifierName.setVisible(true);
					textFieldActionQualifierName.setManaged(true);
					comboboxPostconditionQualifier.setVisible(false);
					comboboxPostconditionQualifier.setManaged(false);
				}
			}
			checkIfSetPostconditionButtonShouldBeVisible();
		});

		// The qualifiers and additional argument can depend on what subject is selected
		// Every time the postcondition subject is changed, the temporaryPostcondition should be updated
		comboboxPostconditionSubject.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (temporaryPostcondition != null && newValue != null){
				temporaryPostcondition.setSubject(comboboxPostconditionSubject.getSelectionModel().getSelectedItem());

				if (temporaryPostcondition.getPossibleQualifiers() != null){
					comboboxPostconditionQualifier.getItems().removeAll(comboboxPostconditionQualifier.getItems());
					comboboxPostconditionQualifier.getItems().addAll(temporaryPostcondition.getPossibleQualifiers());
					comboboxPostconditionQualifier.setVisible(true);
					comboboxPostconditionQualifier.setManaged(true);
				}

				// The store command works a little bit different - it requires multiple additional arguments
				if (temporaryPostcondition instanceof ActionTemplatePostconditionStore) {
					ActionTemplatePostcondition storePostcondition = (ActionTemplatePostconditionStore) temporaryPostcondition;

					// The subject is the selected slot
					AbstractPhenotypeSlotTemplate selectedSlot = (AbstractPhenotypeSlotTemplate) newValue;

					// The qualifier here is which resource should be stored ?
					comboboxPostconditionQualifier.getItems().removeAll(comboboxPostconditionQualifier.getItems());
					comboboxPostconditionQualifier.getItems().addAll(temporaryPostcondition.getPossibleQualifiers());
					comboboxPostconditionQualifier.setVisible(true);
					comboboxPostconditionQualifier.setManaged(true);
					
					// In all known slot types, the postconditionSlotPhenotypeObject is necessary - it regulates which phenotypic dimension is affected
					comboboxPostconditionSlotPhenotypeObject.setPlaceholder(new Label("Affected phenotypic dimension"));
					comboboxPostconditionSlotPhenotypeObject.getSelectionModel().select(-1);
					comboboxPostconditionSlotPhenotypeObject.getItems().removeAll(comboboxPostconditionSlotPhenotypeObject.getItems());
					comboboxPostconditionSlotPhenotypeObject.getItems().addAll(View.getView().workspace.getAllPhenotypeObjectsExcludingAge());
					comboboxPostconditionSlotPhenotypeObject.setVisible(true);
					comboboxPostconditionSlotPhenotypeObject.setManaged(true);

					if (AbstractPhenotypeSlotTemplate.usesDelays(selectedSlot.getClass())) {
						comboboxPostconditionSlotDelay.setVisible(true);
						comboboxPostconditionSlotDelay.setManaged(true);
						comboboxPostconditionSlotDelay.setPlaceholder(new Label("With delay"));
						comboboxPostconditionSlotDelay.getSelectionModel().select(-1);
						comboboxPostconditionSlotDelay.getItems().removeAll(comboboxPostconditionSlotDelay.getItems());
						for (InstanceReference d : View.getView().workspace.getAllDelayInstanceReferences())
							if (selectedSlot.canUseAsDelay(d))
								comboboxPostconditionSlotDelay.getItems().add(d);
					}

					if (AbstractPhenotypeSlotTemplate.usesInterruptions(selectedSlot.getClass())) {
						comboboxPostconditionSlotInterruptionReference.setVisible(true);
						comboboxPostconditionSlotInterruptionReference.setManaged(true);
						comboboxPostconditionSlotInterruptionReference.setPlaceholder(new Label("Possible interruption"));
						comboboxPostconditionSlotInterruptionReference.getSelectionModel().select(-1);
						comboboxPostconditionSlotInterruptionReference.getItems().removeAll(comboboxPostconditionSlotInterruptionReference.getItems());
						comboboxPostconditionSlotInterruptionReference.getItems().add(InstanceNull.getNullInstanceForInterruptions());
						for (InstanceReference i : View.getView().workspace.getAllInterruptionInstanceReferences())
							if (selectedSlot.canUseAsInterruption(i))
								comboboxPostconditionSlotInterruptionReference.getItems().add(i);
					}

					if (AbstractPhenotypeSlotTemplate.usesPeriodicity(selectedSlot.getClass())) {
						spinnerSlotPeriodicity.setVisible(true);
						spinnerSlotPeriodicity.setManaged(true);
					}

				}
				checkIfSetPostconditionButtonShouldBeVisible();
			}
		});
		comboboxPostconditionQualifier.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (temporaryPostcondition != null && newValue != null){
				temporaryPostcondition.setQualifier(comboboxPostconditionQualifier.getSelectionModel().getSelectedItem());
				checkIfSetPostconditionButtonShouldBeVisible();}
		});

		comboboxPostconditionSlotPhenotypeObject.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (temporaryPostcondition != null && newValue != null && temporaryPostcondition instanceof ActionTemplatePostconditionStore ){
				ActionTemplatePostconditionStore pStore = (ActionTemplatePostconditionStore) temporaryPostcondition;
				pStore.setAffectedPhenotypicDimensions(newValue);
				checkIfSetPostconditionButtonShouldBeVisible();
			}
		});

		comboboxPostconditionSlotInterruptionReference.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (temporaryPostcondition != null && newValue != null && temporaryPostcondition instanceof ActionTemplatePostconditionStore ){
				ActionTemplatePostconditionStore pStore = (ActionTemplatePostconditionStore) temporaryPostcondition;
				pStore.setInterruption(newValue);
				checkIfSetPostconditionButtonShouldBeVisible();
			}
		});

		comboboxPostconditionSlotDelay.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (temporaryPostcondition != null && newValue != null && temporaryPostcondition instanceof ActionTemplatePostconditionStore ){
				ActionTemplatePostconditionStore pStore = (ActionTemplatePostconditionStore) temporaryPostcondition;
				pStore.setDelay(newValue);
				checkIfSetPostconditionButtonShouldBeVisible();
			}
		});

		// If the textfield textFieldActionQualifierName is visible, the buttonSetPostcondition should be visible IFF
		// the text in the textFieldActionQualifierName is a permissible variable name
		textFieldActionQualifierName.getStyleClass().addListener( new ListChangeListener<String>(){
			@Override
			public void onChanged(Change<? extends String> arg0) {
				if (LayoutManager.isInvalid(textFieldActionQualifierName)) 	
					buttonSetPostcondition.setVisible(false);
				else
					buttonSetPostcondition.setVisible(true);


			}});
		// Set how the postcondition CLASS combobox should represent items
		Callback<ListView<Class<?extends ActionTemplatePostcondition>>, ListCell<Class<?extends ActionTemplatePostcondition>>> postconditionClassCellFactory =
				new  Callback<ListView<Class<?extends ActionTemplatePostcondition>>, ListCell<Class<?extends ActionTemplatePostcondition>>>(){
			@Override
			public ListCell<Class<? extends ActionTemplatePostcondition>> call(
					ListView<Class<? extends ActionTemplatePostcondition>> clazz) {
				return new ListCell<Class<? extends ActionTemplatePostcondition>>(){
					@Override
					protected void updateItem(Class<? extends ActionTemplatePostcondition> item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(ActionTemplatePostcondition.toSimpleName(item));
						}
					}
				};
			}
		};
		comboboxPostconditionClass.setCellFactory(postconditionClassCellFactory);
		comboboxPostconditionClass.setButtonCell(postconditionClassCellFactory.call(null));

		// Set how the postcondition SUBJECT combobox should represent items
		Callback<ListView<Object>, ListCell<Object>> postconditionSubjectCellFactory =
				new  Callback<ListView<Object>, ListCell<Object>>(){
			@Override
			public ListCell<Object> call(
					ListView<Object> sub) {
				return new ListCell<Object>(){
					@Override
					protected void updateItem(Object item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							if (item instanceof AbstractObjectiveTemplate)
								setText(((AbstractObjectiveTemplate)item).getName());
							else if (item instanceof CueTemplate)
								setText("A "+((CueTemplate)item).object.getName() + " cue");
							else if (item instanceof InstanceReference)
								setText(((InstanceReference)item).getName());
							else if (item instanceof AbstractPhenotypeSlotTemplate)
								setText("Slot '"+((AbstractPhenotypeSlotTemplate)item).getName() + "'");
						}
					}
				};
			}
		};

		comboboxPostconditionSubject.setCellFactory(postconditionSubjectCellFactory);
		comboboxPostconditionSubject.setButtonCell(postconditionSubjectCellFactory.call(null));

		// Set how the postcondition QUALIFIER combobox should represent items
		Callback<ListView<Object>, ListCell<Object>> postconditionQualifierCellFactory =
				new  Callback<ListView<Object>, ListCell<Object>>(){
			@Override
			public ListCell<Object> call(
					ListView<Object> sub) {
				return new ListCell<Object>(){
					@Override
					protected void updateItem(Object item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							if (item instanceof AbstractObjectiveTemplate)
								setText(((AbstractObjectiveTemplate)item).getName());
							else if (item instanceof NumberObjectSingle)
								setText(((NumberObjectSingle)item).toStringWithoutTrailingZeros());
							else if (item instanceof InstanceReference)
								setText(((InstanceReference)item).getName());
						}
					}
				};
			}
		};
		comboboxPostconditionQualifier.setCellFactory(postconditionQualifierCellFactory);
		comboboxPostconditionQualifier.setButtonCell(postconditionQualifierCellFactory.call(null));

		// Set how the comboboxPostconditionSlotPhenotypeObject should represent phenotypic dimensions
		Callback<ListView<PhenotypeObjectTemplate>, ListCell<PhenotypeObjectTemplate>> postconditionPhenotypicDimensionFactory =
				new  Callback<ListView<PhenotypeObjectTemplate>, ListCell<PhenotypeObjectTemplate>>(){
			@Override
			public ListCell<PhenotypeObjectTemplate> call(
					ListView<PhenotypeObjectTemplate> sub) {
				return new ListCell<PhenotypeObjectTemplate>(){
					@Override
					protected void updateItem(PhenotypeObjectTemplate item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(" affects '" + item.getName() + "'");
						}
					}
				};
			}
		};
		comboboxPostconditionSlotPhenotypeObject.setCellFactory(postconditionPhenotypicDimensionFactory);
		comboboxPostconditionSlotPhenotypeObject.setButtonCell(postconditionPhenotypicDimensionFactory.call(null));

		// Set the behavior for the buttonAutofill
		buttonAutofill.setOnAction(e -> {
			this.autoFill();
		});

		// When the set postcondition is set, the temporaryPostcondition should be displayed in the postcondition
		buttonSetPostcondition.setOnAction(e -> {

			// If the textFieldActionQualifierName is visible:
			if (textFieldActionQualifierName.isVisible()) {

				// If we instantiate a new object:
				if (this.comboboxPostconditionClass.getSelectionModel().getSelectedItem() == ActionTemplatePostconditionInstantiateObject.class 
						|| this.comboboxPostconditionClass.getSelectionModel().getSelectedItem() == ActionTemplatePostconditionInstantiateExtrinsic.class){

					// Check if there already is an InstanceReference with that name
					if (View.getView().workspace.containsInstanceReference(textFieldActionQualifierName.getText())) {
						View.getView().showWarningToast("There already is an instance in the workspace with that name. Please select another name.");
						LayoutManager.setState(textFieldActionQualifierName, State.Invalid);
						return;
					}

					// Create a new Instance
					Instance newInstance = new Instance(textFieldActionQualifierName.getText(),
							(AbstractObjectiveTemplate) comboboxPostconditionSubject.getSelectionModel().getSelectedItem());
					View.getView().workspace.addInstance(newInstance);

					if (this.comboboxPostconditionClass.getSelectionModel().getSelectedItem() == ActionTemplatePostconditionInstantiateObject.class)
						((ActionTemplatePostconditionInstantiateObject) temporaryPostcondition).setReferenceAfterCreation(newInstance);
					if (this.comboboxPostconditionClass.getSelectionModel().getSelectedItem() == ActionTemplatePostconditionInstantiateExtrinsic.class)
						((ActionTemplatePostconditionInstantiateExtrinsic) temporaryPostcondition).setReferenceAfterCreation(newInstance);
				}


				// If we create a new reference
				if (this.comboboxPostconditionClass.getSelectionModel().getSelectedItem() == ActionTemplatePostconditionCreateReference.class) {

					// If there is no InstanceReference with that name yet
					if (View.getView().workspace.containsInstanceReference(textFieldActionQualifierName.getText())) {
						View.getView().showWarningToast("There already is an instance or reference in the workspace with that name. Please select another name.");
						LayoutManager.setState(textFieldActionQualifierName, State.Invalid);
						return;
					}

					// Create a new InstanceReference
					InstanceReference ref = (InstanceReference) this.comboboxPostconditionSubject.getSelectionModel().getSelectedItem();
					String nameOfInstance;
					if (ref instanceof Instance)
						nameOfInstance = ref.getName();
					else
						nameOfInstance = ((InstanceAlias)ref).getInitialInstance().getName();

					InstanceReference newRef= new InstanceAlias(textFieldActionQualifierName.getText(),
							nameOfInstance);

					View.getView().workspace.addInstanceAlias((InstanceAlias) newRef);
					((ActionTemplatePostconditionCreateReference) temporaryPostcondition).setReferenceAfterCreation(newRef);

				}
			}

			if (this.comboboxPostconditionClass.getSelectionModel().getSelectedItem() == ActionTemplatePostconditionSetGameMode.class) {
				((ActionTemplatePostconditionSetGameMode) temporaryPostcondition).setStringAfterCreation(textFieldActionQualifierName.getText());
			}

			// Add the postcondition to the list
			listViewPostconditions.getItems().add(temporaryPostcondition);

			// Clear the comboboxes
			this.comboboxPostconditionClass.getSelectionModel().clearSelection();
			this.comboboxPostconditionQualifier.setVisible(false);
			this.comboboxPostconditionSubject.setVisible(false);
			this.textFieldActionQualifierName.setText("");
			this.textFieldActionQualifierName.setVisible(false);

			// Check whether the autofill button should become visible
			if (this.possibleToAutofill()) {
				this.buttonAutofill.setVisible(true);
				buttonAutofill.setManaged(true);
			}
			else {
				this.buttonAutofill.setVisible(false);
				buttonAutofill.setManaged(false);
			}
			
			// Hide the set button again
			buttonSetPostcondition.setVisible(false);
		});



	}
	@Override
	public void update() {
		if (existingTemplate == null)
			return;

		this.textFieldActionName.setText(existingTemplate.getName());
		this.listViewPreconditions.getItems().addAll(existingTemplate.getAllPreconditions());
		this.listViewPostconditions.getItems().addAll(existingTemplate.getPostconditions());

	}


	/** Checks if all the comboboxes that need to be filled in, have been filled in.
	 * If so, makes the add precondition button visible
	 * If not, makes the the add precondition button invisible*/
	private void checkIfAddPreconditionButtonShouldBeVisible(){
		if (temporaryPrecondition.isComplete())
			this.buttonAddPrecondition.setVisible(true);
		else
			this.buttonAddPrecondition.setVisible(false);
	}

	/** Checks if all the comboboxes that need to be filled in, have been filled in.
	 * If so, makes the add precondition button visible
	 * If not, makes the the add precondition button invisible*/
	private void checkIfSetPostconditionButtonShouldBeVisible(){
		if (temporaryPostcondition.isComplete())
			this.buttonSetPostcondition.setVisible(true);
		else
			this.buttonSetPostcondition.setVisible(false);

	}


	/** Many different postconditions require some preconditions. For example, sampling a cue from a resource called 
	 * 'resource' is only possible if the attempt to initialize 'resource' was successful - that is, whether a 
	 * 'resource' was indeed encountered during this particular encounter. This function checks whether all
	 * necessary preconditions are added to the PopupAction. If all necessary preconditions are added, this function
	 * return true. If not all preconditions are there yet, the user receives a popup prompt stating that there 
	 * are necessary preconditions missing.*/
	public boolean necessaryPreconditionsPresent() {
		ArrayList<ActionTemplatePrecondition> preArrayList = new ArrayList<>();
		preArrayList.addAll(this.listViewPreconditions.getItems());

		for (ActionTemplatePostcondition post : this.listViewPostconditions.getItems())
			if (!post.necessaryPreconditionsPresentIn(preArrayList))
				return false;
		return true;
	}

	/** Should the autofill button be visible?*/
	public boolean possibleToAutofill() {
		ArrayList<ActionTemplatePrecondition> preArrayList = new ArrayList<>();
		preArrayList.addAll(this.listViewPreconditions.getItems());

		for (ActionTemplatePostcondition post : this.listViewPostconditions.getItems())
			if (ActionTemplatePostcondition.hasNecessaryPrecondition(post.getClass()))
				if (!post.necessaryPreconditionsPresentIn(preArrayList))
					return true;
		return false;

	}

	/** What to do when the Autofill button has been pressed*/
	public void autoFill() {
		ArrayList<ActionTemplatePrecondition> preArrayList = new ArrayList<>();
		preArrayList.addAll(this.listViewPreconditions.getItems());

		for (ActionTemplatePostcondition post: this.listViewPostconditions.getItems())
			post.addMissingPreconditions(preArrayList);

		this.listViewPreconditions.getItems().removeAll(this.listViewPreconditions.getItems());
		this.listViewPreconditions.getItems().addAll(preArrayList);

		if (!this.necessaryPreconditionsPresent())
			throw new IllegalStateException("There are still missing preconditions after autofilling.");

		this.buttonAutofill.setVisible(false);
		buttonAutofill.setManaged(false);

	}

	/** What to do when the OK/apply changes button has been pressed*/
	private void applyChangeButtonPressed(){

		// First things first: check if the name is either unique, or used by the existingTemplate.
		// If not, give a warning and do nothing.
		if (!View.getView().workspace.isActionNamePermissible(this.textFieldActionName.getText()))
			if (existingTemplate == null){
				ObserverManager.makeWarningToast("Cannot create action: please use an unique name");
				return;
			}
			else if (View.getView().workspace.getAction(this.textFieldActionName.getText()) != existingTemplate){
				ObserverManager.makeWarningToast("Cannot create action: please use an unique name");
				return;
			}

		// Check if there is at least one postcondition
		if (this.listViewPostconditions.getItems().size() == 0){
			ObserverManager.makeWarningToast("Cannot create action: please set a postcondition.");
			return;
		}

		// Are all the necessary preconditions for the postconditions present?
		if (!this.necessaryPreconditionsPresent()) {
			ObserverManager.makeWarningToast("At least one postcondition has a missing necessary precondition. Please add this precondition manually, or use the Autofill button.");
			return;
		}


		// An instantiate object postcondition cannot have any preconditions
		for (ActionTemplatePostcondition atp : this.listViewPostconditions.getItems()) {
			if (atp instanceof ActionTemplatePostconditionInstantiateObject ||atp instanceof ActionTemplatePostconditionInstantiateExtrinsic ) {
				if (this.listViewPreconditions.getItems().size()>0) {
					ObserverManager.makeWarningToast("An instantiation call cannot have a precondition");
					return;
				}
			}
		}

		// If there is a set game type postcondition, this is the time to register the new game type at the workspace
		for (ActionTemplatePostcondition p : this.listViewPostconditions.getItems())
			if (p instanceof ActionTemplatePostconditionSetGameMode)
				View.getView().workspace.addGameType((String)p.getQualifier());

		// If there already is an existingTemplate, we have to change that template, rather than adding a new one.
		if (existingTemplate != null){
			existingTemplate.removeAllActionTemplatePreconditions();
			existingTemplate.removeAllActionTemplatePostconditions();
			for (ActionTemplatePrecondition pre : this.listViewPreconditions.getItems())
				existingTemplate.addPrecondition(pre);
			for (ActionTemplatePostcondition pro: this.listViewPostconditions.getItems())
				existingTemplate.addPostcondition(pro);
			if (!existingTemplate.isComplete())
				throw new IllegalStateException("A modified action reports being incomplete, but it really should not be.");
			ObserverManager.makeToast("Succesfully changed the " + existingTemplate.getName()+ " action.");
			View.getView().workspace.harmonizeWithView();
			close();
		} else {

			// Otherwise we have to make a new one, and inform the workspace that we have created a new one.
			ActionTemplate newAction = new ActionTemplate(type, this.textFieldActionName.getText());
			for (ActionTemplatePrecondition pre : this.listViewPreconditions.getItems())
				newAction.addPrecondition(pre);
			for (ActionTemplatePostcondition pro: this.listViewPostconditions.getItems())
				newAction.addPostcondition(pro);


			if (!newAction.isComplete())
				throw new IllegalStateException("A new action reports being incomplete, but it really should not be.");
			View.getView().workspace.addAction(newAction);
			ObserverManager.makeToast("Succesfully created " + newAction.getName());

			close();
		}

	}
}
