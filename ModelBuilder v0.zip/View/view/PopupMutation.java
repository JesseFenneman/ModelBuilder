package view;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import attributes.AttributeField;
import decimalNumber.DecimalNumber;
import helper.Helper;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.LayoutManager;
import interfaces_abstractions.ObserverManager;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import mutationElements.ObjectMutationTemplate;
import mutationElements.PhenotypeMutationTemplate;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.ExtrinsicObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import rIntegration.RFunction;
import rIntegration.RManager;

@Deprecated
public class PopupMutation extends AbstractPopup {

	@FXML public RadioButton radioButtonExtrinsic, radioButtonObject;
	@FXML public GridPane	gridPaneExtrinsic, gridPaneObject;	
	
	@FXML public ComboBox<ExtrinsicObjectTemplate> comboboxExtrinsic;
	@FXML public ComboBox<PhenotypeObjectTemplate> comboboxPhenotype;
	@FXML public VBox vboxObject;
	
	// The radio buttons for the different options
	@FXML public RadioButton 	radioButtonConstant, 
								radioButtonPercentage,
								radioButtonLinearDouble,
								radioButtonRFunction;
	
	// The gridpanes that will be visible/managed whenever an option is selected
	@FXML public GridPane	gridPaneObjectConstant, 
							gridPaneObjectPercentage,
							gridPaneObjectLinearDouble,
							gridPaneObjectRFunction;
	
	// The comboboxes for the 'select an object type'
	@FXML public ComboBox<AbstractObjectiveTemplate> 	comboboxObjectTypeConstant,
														comboboxObjectTypePercentage,
														comboboxObjectTypeLinearDouble,
														comboboxObjectTypeRFunction;
	
	// The right hand side node that asks for details
	@FXML public ComboBox<NumberObjectSingle> comboboxObjectValueConstant;
	@FXML public TextField 	textFieldPercentage,
							textFieldLinearDouble;
	@FXML public ComboBox<RFunction> comboboxObjectValueRFunction;
	

	
	@FXML public Button buttonAdd;
	
	public PopupMutation(){
		super("fxml_popupAddMutation.fxml", 
				View.getView().getPaneCenterX()-200, 
				View.getView().getPaneCenterY()-52, true);


		// Set the nodes
		setNodes();

		// Set the values in the nodes
		update();

	}

	@Override
	public void setNodes() {
		
		// Set visibility mechanics
		gridPaneExtrinsic.visibleProperty().bind(this.radioButtonExtrinsic.selectedProperty());
		gridPaneExtrinsic.managedProperty().bind(this.radioButtonExtrinsic.selectedProperty());
		vboxObject.visibleProperty().bind(this.radioButtonObject.selectedProperty());
		vboxObject.managedProperty().bind(this.radioButtonObject.selectedProperty());
		
		// The four options for object changes
		gridPaneObjectConstant.visibleProperty().bind(this.radioButtonConstant.selectedProperty());
		gridPaneObjectConstant.managedProperty().bind(this.radioButtonConstant.selectedProperty());
		gridPaneObjectPercentage.visibleProperty().bind(this.radioButtonPercentage.selectedProperty());
		gridPaneObjectPercentage.managedProperty().bind(this.radioButtonPercentage.selectedProperty());
		gridPaneObjectLinearDouble.visibleProperty().bind(this.radioButtonLinearDouble.selectedProperty());
		gridPaneObjectLinearDouble.managedProperty().bind(this.radioButtonLinearDouble.selectedProperty());
		gridPaneObjectRFunction.visibleProperty().bind(this.radioButtonRFunction.selectedProperty());
		gridPaneObjectRFunction.managedProperty().bind(this.radioButtonRFunction.selectedProperty());
	
		
		// Set disable mechanics - the value comboboxes should be invisible if no object is selected (yet)
		comboboxObjectValueConstant.visibleProperty().bind(comboboxObjectTypeConstant.getSelectionModel().selectedItemProperty().isNotNull());
		textFieldPercentage.visibleProperty().bind(comboboxObjectTypePercentage.getSelectionModel().selectedItemProperty().isNotNull());
		textFieldLinearDouble.visibleProperty().bind(comboboxObjectTypeLinearDouble.getSelectionModel().selectedItemProperty().isNotNull());
		comboboxObjectValueRFunction.visibleProperty().bind(comboboxObjectTypeRFunction.getSelectionModel().selectedItemProperty().isNotNull());
		
		// Set the combobox for extrinsic events
		comboboxExtrinsic.getItems().addAll(View.getView().workspace.getAllExtrinsicObjects());

		// Set how the combobox should represent items
		Callback<ListView<ExtrinsicObjectTemplate>, ListCell<ExtrinsicObjectTemplate>> extrinsicFactory =
				new  Callback<ListView<ExtrinsicObjectTemplate>, ListCell<ExtrinsicObjectTemplate>>(){
			@Override
			public ListCell<ExtrinsicObjectTemplate> call(
					ListView<ExtrinsicObjectTemplate> ex) {
				return new ListCell<ExtrinsicObjectTemplate>(){
					@Override
					protected void updateItem(ExtrinsicObjectTemplate item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(Helper.capitalize(item.getName()) + " events");
						}
					}
				};
			}
		};
		comboboxExtrinsic.setCellFactory(extrinsicFactory);
		comboboxExtrinsic.setButtonCell(extrinsicFactory.call(null));
		
		
		
		// Set the combobox for the phenotypes
		comboboxPhenotype.getItems().addAll(View.getView().workspace.getAllPhenotypeObjectsExcludingAge());

		// Set how the combobox should represent items
		Callback<ListView<PhenotypeObjectTemplate>, ListCell<PhenotypeObjectTemplate>> phenotypeFactory =
				new  Callback<ListView<PhenotypeObjectTemplate>, ListCell<PhenotypeObjectTemplate>>(){
			@Override
			public ListCell<PhenotypeObjectTemplate> call(
					ListView<PhenotypeObjectTemplate> phen) {
				return new ListCell<PhenotypeObjectTemplate>(){
					@Override
					protected void updateItem(PhenotypeObjectTemplate item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText("an agent's "+ item.getName().toLowerCase() );
						}
					}
				};
			}
		};
		comboboxPhenotype.setCellFactory(phenotypeFactory);
		comboboxPhenotype.setButtonCell(phenotypeFactory.call(null));
		
		
		// Set the combobox for the object types
		comboboxObjectTypeConstant.getItems().addAll(View.getView().workspace.getAllResourceInterruptionAndDelayObjects());
		comboboxObjectTypePercentage.getItems().addAll(View.getView().workspace.getAllResourceInterruptionAndDelayObjects());
		comboboxObjectTypeLinearDouble.getItems().addAll(View.getView().workspace.getAllResourceInterruptionAndDelayObjects());
		comboboxObjectTypeRFunction.getItems().addAll(View.getView().workspace.getAllResourceInterruptionAndDelayObjects());

		// Set how the combobox should represent items
		Callback<ListView<AbstractObjectiveTemplate>, ListCell<AbstractObjectiveTemplate>> objectTypeFactory =
				new  Callback<ListView<AbstractObjectiveTemplate>, ListCell<AbstractObjectiveTemplate>>(){
			@Override
			public ListCell<AbstractObjectiveTemplate> call(
					ListView<AbstractObjectiveTemplate> ex) {
				return new ListCell<AbstractObjectiveTemplate>(){
					@Override
					protected void updateItem(AbstractObjectiveTemplate item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(Helper.capitalize("A " + item.getName()) + " object");
						}
					}
				};
			}
		};
		comboboxObjectTypeConstant.setCellFactory(objectTypeFactory);
		comboboxObjectTypeConstant.setButtonCell(objectTypeFactory.call(null));
		
		comboboxObjectTypePercentage.setCellFactory(objectTypeFactory);
		comboboxObjectTypePercentage.setButtonCell(objectTypeFactory.call(null));
		
		comboboxObjectTypeLinearDouble.setCellFactory(objectTypeFactory);
		comboboxObjectTypeLinearDouble.setButtonCell(objectTypeFactory.call(null));
		
		comboboxObjectTypeRFunction.setCellFactory(objectTypeFactory);
		comboboxObjectTypeRFunction.setButtonCell(objectTypeFactory.call(null));
		
		
		// Set the cell factory for comboboxObjectValueConstant
		Callback<ListView<NumberObjectSingle>, ListCell<NumberObjectSingle>> objectValueFactory =
				new  Callback<ListView<NumberObjectSingle>, ListCell<NumberObjectSingle>>(){
			@Override
			public ListCell<NumberObjectSingle> call(
					ListView<NumberObjectSingle> ex) {
				return new ListCell<NumberObjectSingle>(){
					@Override
					protected void updateItem(NumberObjectSingle item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(item.toStringWithoutTrailingZeros());
						}
					}
				};
			}
		};
		comboboxObjectValueConstant.setCellFactory(objectValueFactory);
		comboboxObjectValueConstant.setButtonCell(objectValueFactory.call(null));
		
		// Set the cell factory for comboboxObjectValueFunction
		Callback<ListView<RFunction>, ListCell<RFunction>> functionFactory =
				new  Callback<ListView<RFunction>, ListCell<RFunction>>(){
			@Override
			public ListCell<RFunction> call(
					ListView<RFunction> ex) {
				return new ListCell<RFunction>(){
					@Override
					protected void updateItem(RFunction item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null || empty) {
							setGraphic(null);
						} else {
							setText(item.getName());
						}
					}
				};
			}
		};
		comboboxObjectValueConstant.setCellFactory(objectValueFactory);
		comboboxObjectValueConstant.setButtonCell(objectValueFactory.call(null));
		
		// Add the items for the combobox for fixed
		comboboxObjectTypeConstant.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (newValue != null) {
				comboboxObjectValueConstant.getItems().removeAll(comboboxObjectValueConstant.getItems());
				comboboxObjectValueConstant.getItems().addAll(newValue.getDomain().toArray());
			}
		});
		
		// Set the text fields for percentage and linear double
		LayoutManager.setLayoutHandler(textFieldPercentage, FieldRestriction.DOUBLE);
		
		LayoutManager.setLayoutHandler(textFieldLinearDouble, FieldRestriction.POSITIVE_INTEGER);
		
		// Add the items for the combobox for RFunction: all RFunctions tagged as "OBJECTMUTATION"
		comboboxObjectTypeRFunction.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			if (newValue != null) {
				comboboxObjectValueRFunction.getItems().removeAll(comboboxObjectValueRFunction.getItems());
				
				for (RFunction rf: RManager.getAllRFunctionsWithTag("OBJECTMUTATION")){
					// An OBJECT_MUTATION function should have 5 arguments (in that order!): 
					// value: the object value at the start of the encounter, 
					// time: the number of time steps passed
					// minimumValue: the smallest value that the object is allowed to be
					// maximumValue: the largest value that the object is allowed to be
					// stepsizeValue: the increment of the object's value (if the object is a delay or resource; not for interruptions)
					if (comboboxObjectTypeRFunction.getSelectionModel().getSelectedItem().getClass() != InterruptionObjectTemplate.class && rf.getInputFieldCopy().size()!=5) {
						ObserverManager.makeWarningToast("RFunction with name \"" + rf.getName() + "\" does not have exactly five argument required for a resource or delay (value, time, minimum, maximum, and step size), and therefore cannot be used as an extrinsic object mutation.");
						return;
					}
					
					if (comboboxObjectTypeRFunction.getSelectionModel().getSelectedItem().getClass() == InterruptionObjectTemplate.class && rf.getInputFieldCopy().size()!=4) {
						ObserverManager.makeWarningToast("RFunction with name \"" + rf.getName() + "\" does not have exactly four argument required for an interruption (value, time, minimum, maximume), and therefore cannot be used as an extrinsic object mutation.");
						return;
					}
					
					// Check if the first argument, the object value, has the correct field restriction. 
					// That is: a probability for interruptions, any value for resources, and non-negative integers for delays.
					//If so, add it to the list of potential RFunctions
					if (comboboxObjectTypeRFunction.getSelectionModel().getSelectedItem() instanceof InterruptionObjectTemplate) {
						if (rf.getInputFieldCopy().get(0).getFieldRestriction() == FieldRestriction.PROBABILITY)
							comboboxObjectValueRFunction.getItems().add(rf);
					}
					
					if (comboboxObjectTypeRFunction.getSelectionModel().getSelectedItem() instanceof ResourceObjectTemplate) {
						if (rf.getInputFieldCopy().get(0).getFieldRestriction() == FieldRestriction.DOUBLE)
							comboboxObjectValueRFunction.getItems().add(rf);
					}
					
					
					if (comboboxObjectTypeRFunction.getSelectionModel().getSelectedItem() instanceof DelayObjectTemplate) {
						if (rf.getInputFieldCopy().get(0).getFieldRestriction() == FieldRestriction.NON_NEGATIVE_INTEGER)
							comboboxObjectValueRFunction.getItems().add(rf);
					}
					
				}
				
				comboboxObjectValueConstant.getItems().addAll(newValue.getDomain().toArray());
			}
		});
		
		
		
		// Set the button to add
		buttonAdd.setOnAction(e -> {
			if (!validateInput()) {
				return;

			}
			if (radioButtonExtrinsic.isSelected()) {
				View.getView().workspace.addPhenotypeMutation(new PhenotypeMutationTemplate(
						comboboxPhenotype.getSelectionModel().getSelectedItem(),
						comboboxExtrinsic.getSelectionModel().getSelectedItem()));
				ObserverManager.makeToast("Succesfully added a phenotypic mutation");
			} else {
				if (radioButtonConstant.isSelected()) {
					View.getView().workspace.addObjectMutation(ObjectMutationTemplate.createConstantObjectMutation(
							comboboxObjectTypeConstant.getSelectionModel().getSelectedItem(), 
							comboboxObjectValueConstant.getSelectionModel().getSelectedItem()));
					ObserverManager.makeToast("Succesfully added a constant object mutation");
				}

				if (this.radioButtonPercentage.isSelected()) {
					View.getView().workspace.addObjectMutation(ObjectMutationTemplate.createPercentageObjectMutation(
							this.comboboxObjectTypePercentage.getSelectionModel().getSelectedItem(), 
							new DecimalNumber(textFieldPercentage.getText())));
					ObserverManager.makeToast("Succesfully added a percentage object mutation");
				}
				
				if (this.radioButtonLinearDouble.isSelected()) {
					View.getView().workspace.addObjectMutation(ObjectMutationTemplate.createDoubleLinearObjectMutation(
							this.comboboxObjectTypeLinearDouble.getSelectionModel().getSelectedItem(), 
							new DecimalNumber(this.textFieldLinearDouble.getText())));
					ObserverManager.makeToast("Succesfully added a double linear object mutation");
				}
				
				if (this.radioButtonRFunction.isSelected()) {
					View.getView().workspace.addObjectMutation(ObjectMutationTemplate.createRFunctionObjectMutation(
							this.comboboxObjectTypeRFunction.getSelectionModel().getSelectedItem(), 
							this.comboboxObjectValueRFunction.getSelectionModel().getSelectedItem()));
					ObserverManager.makeToast("Succesfully added a R function based object mutation");
				}
			}


			close();
		});

	}
	
	public boolean validateInput() {
		// Extrinsic -> phenotype
		if (radioButtonExtrinsic.isSelected()) {
			if (comboboxPhenotype.getSelectionModel().getSelectedItem() == null){
				ObserverManager.makeWarningToast("Please select a phenotypic dimension");
				return false;
			}
			
			if (comboboxExtrinsic.getSelectionModel().getSelectedItem() == null){
				ObserverManager.makeWarningToast("Please select an extrinsic event");
				return false;
			}
		}
		
		// Object changes
		else if (radioButtonObject.isSelected()) {
			
			// Constant
			if (radioButtonConstant.isSelected()) {
				if (comboboxObjectTypeConstant.getSelectionModel().getSelectedItem() == null){
					ObserverManager.makeWarningToast("Please select an object type");
					return false;
				}
				
				if (comboboxObjectValueConstant.getSelectionModel().getSelectedItem() == null){
					ObserverManager.makeWarningToast("Please select a value");
					return false;
				}
			}
			
			
			// Percentage
			if (radioButtonPercentage.isSelected()) {
				if (comboboxObjectTypePercentage.getSelectionModel().getSelectedItem() == null){
					ObserverManager.makeWarningToast("Please select an object type");
					return false;
				}
				
				if (LayoutManager.isInvalid(this.textFieldPercentage)){
					ObserverManager.makeWarningToast("Please provide a valid value");
					return false;
				}
			}
			
			// Linear double
			if (radioButtonLinearDouble.isSelected()) {
				if (comboboxObjectTypeLinearDouble.getSelectionModel().getSelectedItem() == null){
					ObserverManager.makeWarningToast("Please select an object type");
					return false;
				}
				
				if (LayoutManager.isInvalid(this.textFieldLinearDouble)){
					ObserverManager.makeWarningToast("Please provide a valid number of time steps");
					return false;
				}
			}
			
			// RFunction
			if (radioButtonRFunction.isSelected()) {
				if (comboboxObjectTypeRFunction.getSelectionModel().getSelectedItem() == null){
					ObserverManager.makeWarningToast("Please select an object type");
					return false;
				}
				
				if (comboboxObjectValueRFunction.getSelectionModel().getSelectedItem() == null){
					ObserverManager.makeWarningToast("Please select a value");
					return false;
				}
			}
			
		}
		
		return true;
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}
}
