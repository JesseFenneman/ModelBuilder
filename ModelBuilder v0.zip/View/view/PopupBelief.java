package view;

import java.util.HashMap;

import beliefElements.AbstractBeliefTemplate;
import decimalNumber.DecimalNumber;
import decimalNumber.SafeDecimalNumberToStringConverter;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.ObserverManager;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;
import javafx.util.converter.IntegerStringConverter;
import start.Console;

public class PopupBelief extends AbstractPopup{

	/** A private class to populate the TableView with.
	 * Each row should show the value of the object's domain,
	 * and the corresponding number of observations for that value.*/
	private class TableRow {
		public DecimalNumber objectDomainValue;
		public int observations;
		public TableRow(DecimalNumber objectValue, int observations){
			this.objectDomainValue  = objectValue; this.observations = observations;
		}
	}

	@FXML public Label labelTitle;
	@FXML public TableView<TableRow> tableView;
	@FXML public TableColumn<TableRow, DecimalNumber> tableColumnDomainValue;
	@FXML public TableColumn<TableRow, Integer> tableColumnObservations;
	@FXML public RadioButton radioButtonKnown, radioButtonLearn;
	@FXML public Button buttonApplyChanges;

	// A map that connects the name of an attribute of the distribution to the TextField for that attribute
	public ObservableList<TableRow> data;

	private final AbstractBeliefTemplate belief;

	public PopupBelief(MouseEvent e, AbstractBeliefTemplate belief){
		super("fxml_popupModifyBelief.fxml", e, true);
		this.belief = belief;


		// Create the data for the TableView
		data = FXCollections.observableArrayList();

		// If the belief is based on a known distribution, create for each  possible 
		// object value (i.e., each value in that object's domain) a new TableRow, that contains
		// 0 observations
		if (belief.isKnownDistribution())
			for (DecimalNumber objectValue: belief.getObject().getDomain())
				data.add(new TableRow(objectValue, 0));

		// Otherwise, ask the belief what these counts should be
		else
			for (DecimalNumber key: belief.getObservations().keySet())
				data.add(new TableRow (key, belief.getObservations().get(key)));

		// Set the nodes
		setNodes();

		// Set the values in the nodes
		update();

		Console.print("Opened a new Popup window for belief: " + belief.getObject().getName());
	}

	@Override
	public void setNodes() {
		// Set the text on the title label and the RadioButton labels
		labelTitle.setText("Change the beliefs about " + belief.getObject().getName().toLowerCase());

		// Set the visibility of the tableView
		tableView.visibleProperty().bind(radioButtonLearn.selectedProperty());
		tableView.managedProperty().bind(radioButtonLearn.selectedProperty());


		// Set the header of the first column in the tableView
		tableColumnDomainValue.setText(belief.getObject().getName() + " value");

		// Set the CellValueFactory: this factory determines which DecimaalNumber should be shown.
		tableColumnDomainValue.setCellValueFactory(
				new Callback<CellDataFeatures<TableRow, DecimalNumber>, ObservableValue<DecimalNumber>>(){
					@Override
					public ObservableValue<DecimalNumber> call(CellDataFeatures<TableRow, DecimalNumber> t) {
						return new SimpleObjectProperty<>(	t.getValue().objectDomainValue);
					}
				});


		// Set the Cell value factory for tableColumnDomainValue
		tableColumnDomainValue.setCellFactory(TextFieldTableCell.forTableColumn(new SafeDecimalNumberToStringConverter().setRemoveTrailingZeros(true)));


		// Set the behavior of the tableView's Observations column
		// Set the CellValueFactory: this factory determines which interger should be shown.
		tableColumnObservations.setCellValueFactory(
				new Callback<CellDataFeatures<TableRow, Integer>, ObservableValue<Integer>>(){
					@Override
					public ObservableValue<Integer> call(CellDataFeatures<TableRow, Integer> t) {
						return new SimpleObjectProperty<>(	t.getValue().observations);
					}
				});

		// Tell Java how to go from a Integer to a string.
		tableColumnObservations.setCellFactory(TextFieldTableCell.<TableRow, Integer>forTableColumn(new IntegerStringConverter()));
		
		tableView.setEditable(true);
		
		// Tell java how to handle the changes
		tableColumnObservations.setOnEditCommit(
				new EventHandler<TableColumn.CellEditEvent<TableRow, Integer>>() {
					@Override
					public void handle(CellEditEvent<TableRow, Integer> t) {
						if (t.getNewValue() >= 0)
							t.getRowValue().observations = t.getNewValue();
						else
							ObserverManager.makeWarningToast("Please enter a non-negative integer value");
						
						t.getTableView().refresh();
					}});
		
		// When buttonApplyChanges is pressed:
		// 	If the radioButtonLearn is selected: turn the data array list into a hashmap, 
		// 		give that hashmap to the belief, provide a toast, and close this popup
		//  If the radioButtonKnown is selected: tell the belief to set a known distribution,
		//		provide a toast, and close this popup
		buttonApplyChanges.setOnAction(e -> {
			if (radioButtonLearn.isSelected()){
				HashMap<DecimalNumber, Integer> map = new HashMap<>();
				for (TableRow r : data)
					map.put(r.objectDomainValue, r.observations);

				belief.setObservations(map);

				ObserverManager.makeToast("Succesfully changed belief: agent now has to learn from experience");
				this.close();
			} else {
				belief.setDistributionKnown();
				ObserverManager.makeToast("Succesfully changed belief: belief is now known.");
				this.close();
			}
		});

	}

	@Override
	public void update() {
		// If there is a known distribution, only select the top radio button
		if (belief.isKnownDistribution())
			radioButtonKnown.setSelected(true);
		else{
			
			// Otherwise, set the lower radio button
			radioButtonLearn.setSelected(true);
		}

		tableView.setItems(data);
	}

	



}
