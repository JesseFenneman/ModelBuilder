package view;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import FitnessElement.FitnessFunctionTemplate;
import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectRepresentation;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import actionElements.ActionTemplate;
import actionElements.ActionTemplate.ActionType;
import attributes.AttributeField;
import beliefElements.AbstractBeliefTemplate;
import beliefElements.DelayBeliefTemplate;
import beliefElements.ExtrinsicBeliefTemplate;
import beliefElements.InterruptionBeliefTemplate;
import beliefElements.ResourceBeliefTemplate;
import core.Model;
import deathConditionElements.DeathConditionTemplate;
import decimalNumber.DecimalNumber;
import helper.Helper;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.AbstractTab;
import interfaces_abstractions.LayoutManager;
import interfaces_abstractions.ObserverManager;
import interfaces_abstractions.ObserverManager.ObserverStage;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.StringConverter;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractPhenotypeSlotTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.ExtrinsicObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeElement;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import rIntegration.RFunction;
import rIntegration.RManager;
import spatialAndTemporalElements.BasePatch;
import spatialAndTemporalElements.BaseState;
import spatialAndTemporalElements.PatchStateTemplate;
import spatialAndTemporalElements.PatchTemplate;
import start.CentralExecutive;
import start.Console;
import staticManagers.ExternalFileManager;
import staticManagers.ExternalFileManager.FILE_TYPE;
import view.JavaFXHelper.Toaster;


public class View implements ObserverStage
{
	//	TODO: Death conditions should be termination conditions
	// 	TODO: memory buffer
	// TODO: if there are recurring or delayed slot, check if they should fire as a mutation
	// TODO: postpone with and without interruption should become one 
	
	// Bugs
	// Interrupt postcondition does not show set button
	
	public final CentralExecutive				centralExecutive;
	public Workspace							workspace;
	public	Stage								stage;
	public Scene								scene;
	private final Toaster 						toaster;


	@FXML   private MenuItem					menuitemNewWorkspace, menuitemSaveWorkspace,menuitemOpenWorkspace;
	@FXML	private MenuItem					menuItemRunRunSimulation;
	@FXML 	private MenuItem					menuItemRunRetrain;
	@FXML 	private MenuItem					menuitemPrintWorkspace;

	@FXML	public Button						buttonOutputDirectory;
	@FXML	public CheckMenuItem				CheckMenuItemLimitRAMUse;
	@FXML 	public Spinner<Integer>				spinnerProcessingThreads;
	@FXML 	public RadioMenuItem				radioMenuItemHighSpeed, radioMenuItemHighAccuracy;
	@FXML 	public CheckMenuItem				checkMenuItemSaveResultsPerAge, checkMenuItemSaveT1, checkMenuItemDoTests;
	@FXML 	public RadioMenuItem				radioMenuItemNoSaveT2, radioMenuItemSaveAllT2, radioMenuItemSaveT2FirstTimeOnly;
	public enum SaveEncounterStateMode {ALL, NONE, T0_ONLY} 
	
	@FXML	public AnchorPane					contentPaneContainer; // the anchor pane containing all right-hand side nodes in the screen (i.e., no tabs)
	@FXML 	public AnchorPane					anchorPaneScrollPane; // The anchorPane of the scrollPane

	@FXML	public ScrollPane 					scrollPane;
	@FXML	private	ToggleButton				tabDecisionStructure, tabPatchesAndTime, tabActionPhase, tabMutationPhase, tabDeathAndFitness, tabModelProgress;
	private ArrayList<ToggleButton>				tabToggleButtons;

	// Frame nodes
	public ArrayList<AbstractTab>				tabs;
	public AbstractTab							tabIntroduction;
	public AbstractTab							tabManageElements;

	// Main panel nodes
	@ FXML	public VBox							vboxObjectPhenotypeDimension, vboxObjectResource, vboxObjectInterruption, vboxObjectDelay, vboxObjectExtrinsic,
												vboxPhenotypeSlot, vboxBeliefResource, vboxBeliefInterruption, vboxBeliefDelay, vboxBeliefExtrinsic;
	@FXML public Label 							labelViewState;

	// Base decision structure nodes
	@FXML	public GridPane						gridPaneBackgroundDecisionStructure;
	@FXML 	public Button 						buttonAddPhenotypeDimension, buttonAddResource, buttonAddInterruption, buttonAddDelay, buttonAddExtrinsic, buttonAddPhenotypeSlot;
	public ArrayList<Button>					addBaseElementButtons = new ArrayList<>();

	// Patch and time nodes
	@FXML	public ScrollPane					scrollPanePatchesAndTime;
	@FXML	public GridPane						gridPanePatches;
	@FXML 	public ListView<PatchTemplate>		listViewPatches;
	@FXML	public Button						buttonRemovePatch, buttonAddPatch, buttonPatchTravel;

	@FXML	public GridPane						gridPanePatchStateSeparator;

	@FXML	public GridPane						gridPanePatchStates;
	@FXML 	public ListView<PatchStateTemplate>	listViewPatchStates;
	@FXML	public Button						buttonRemovePatchState, buttonAddPatchState, buttonTemporalDynamics;

	// Action Phase nodes
	@FXML   public GridPane						gridPaneBetween, gridPaneDuring;
	@FXML	public TextField					textFieldMaximumLifetime, textFieldMaximumCycle;
	@FXML   public ListView<ActionTemplate>		listViewBetween, listViewDuring;
	@FXML   public Button						buttonRemoveBetween, buttonModifyBetween, buttonNewBetween,
												buttonRemoveDuring, buttonModifyDuring, buttonNewDuring;
	// Mutation Phase nodes
	@FXML   public GridPane						gridPaneEncounterSetup, gridPaneMutations;
	@FXML   public ListView<ActionTemplate>		listViewEncounterSetup, listViewMutations;
	@FXML   public Button						buttonNewSetupEncounter, buttonModifySetupEncounter, buttonRemoveSetupEncounter, buttonSetupEncounterUp, buttonSetupEncounterDown,
												buttonNewMutation, buttonModifyMutation, buttonRemoveMutation, buttonMutationUp, buttonMutationDown;


				
	public ArrayList<AbstractPopup> 			activePopups;

	// Death and fitness nodes
	@FXML 	public Button						buttonSetFitnessFunction;
	@FXML	public GridPane						gridPaneFitnessBackground, gridPaneDeathBackground;
	@FXML 	public ComboBox<RFunction>			comboboxFitnessFunction;
	@FXML 	public GridPane						gridPaneFitnessArguments;
	private ArrayList<ComboBox<PhenotypeElement>>	arrayListFitnessArgumentNameToComboBox;
	@FXML 	public Button						buttonNewDeathCondition, buttonRemoveDeathCondition;
	@FXML 	public ListView<DeathConditionTemplate> listViewDeathConditions;
	@FXML	public TextField					textFieldFitnessDeath;
	
	// Model progress nodes
	@FXML 	public ScrollPane					scrollPaneModelProgress;
	//@FXML	public TableView<ModelRecord>		tableViewActiveModels;
	//@FXML	public TableColumn<ModelRecord, String>		 tableColumnModelName,tableColumnModelDescription, tableColumnModelStatus;
	//@FXML	public TableColumn<ModelRecord, Integer> tableColumnModelForwards, tableColumnModelBackwards;
	@FXML 	public Label						labelElapsedTime, labelRemainingTime, labelPercentageDone;
	@FXML	public Button						buttonInterruptActiveModels;
	
	public enum ViewState {
		DECISION_STRUCTURE,
		PATCH_AND_TIME,
		ACTION_PHASE,
		MUTATION_PHASE,
		FITNESS_DEATH;};


	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////////// 	Constructor and initialization 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	// Use a SingletonPattern
	private static View viewInstance;

	/** Start the view if there is no View yet. Does nothing if the View is already started. */
	public static void startView(CentralExecutive model){
		if (viewInstance == null){
			Console.print(" \t Starting View....");
			viewInstance = new View(model);
		}

	}
	/** This exception is thrown when trying to access the view, but the view has not been started yet.*/
	@SuppressWarnings("serial")
	public static class ViewNotStartedException extends RuntimeException { public ViewNotStartedException() {     super("Trying to access view, but the view has not yet been started!");  }}

	/** Returns the singleton View. The View has to be started by calling startView(). If View is not started, throws an ViewNotStartedException*/
	public static View getView(){
		if (viewInstance == null)
			throw new ViewNotStartedException();
		return viewInstance;
	}

	private View (CentralExecutive centralExecutive)	{
		// Set the main objects
		this.centralExecutive = centralExecutive;

		// Set an empty workspace
		this.workspace = new Workspace();
		
		// Parse the FXML and start all the nodes
		try {startStage();} catch (Exception e) {Console.printError("Could not start the frame stage.");e.printStackTrace();}

		//Register the view at the ObserverManager
		this.toaster = new Toaster(contentPaneContainer);
		ObserverManager.registerObserver(this);

		// Create a list to register all popups
		activePopups = new ArrayList<>();
		// Tell the SaveAndLoadManager to use this stage to display its FileChooser dialog boxes in
		ExternalFileManager.setStage(stage);

		// Update the view
		this.update();

		Console.print(" \t View started succesfully. ");
	}

	/**
	 * Start the Window.
	 * @throws IOException
	 */
	private void startStage () throws IOException
	{
		// Start the stage
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("fxml_View.fxml"));
		loader.setController(this);
		Parent root = (Parent) loader.load();

		scene = new Scene(root);
		stage = new Stage();
		stage.setTitle("A model of models version 1.0");
		stage.setScene(scene);

		// Initialise all nodes in the scene
		startNodes();

		// If the main window stage closes, all opened substages should likewise close
		stage.setOnCloseRequest(e -> Console.shutdownSequence());
		stage.show();

		// Load all the style classes that we might need to change the layout (e.g., for changing the layout of invalid text fields, tooltip layout etc)
		scene.getStylesheets().add(this.getClass().getResource("../CSSLayout/textFieldNormal.css").toExternalForm());
		scene.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupTextField.css").toExternalForm());
		scene.getStylesheets().add(this.getClass().getResource("../CSSLayout/spinner.css").toExternalForm());
		scene.getStylesheets().add(this.getClass().getResource("../CSSLayout/tooltip.css").toExternalForm());

		// Tell the ExternalFileManager that we have a stage ready
		ExternalFileManager.setStage(stage);

	}

	/** Sets all the nodes in the frame (ToggleButtons, MenuItems, Tabs, etc.)*/
	private void startNodes() {

		/////////////////////////////////////////////
		///////// View state mechanics ////////////
		///////////////////////////////////////////
		startMenuNodes();

		// Add all the left hand side toggleButtons to tabToggleButtons
		this.tabToggleButtons = new ArrayList<>();
		tabToggleButtons.add(tabDecisionStructure);
		tabToggleButtons.add(tabPatchesAndTime);
		tabToggleButtons.add(tabActionPhase);
		tabToggleButtons.add(tabMutationPhase);
		
		// These toggleButtons determine the state of the View. Hence, if they change, the view should be updated
		for (ToggleButton tab: tabToggleButtons)
			tab.selectedProperty().addListener((arg, oldVal, newVal) -> { if (oldVal) changedState(); } );

		// Add all the 'add [element] buttons to addBaseElementButtons
		this.addBaseElementButtons.add(buttonAddPhenotypeDimension);
		this.addBaseElementButtons.add(buttonAddPhenotypeSlot);
		this.addBaseElementButtons.add(buttonAddResource);
		this.addBaseElementButtons.add(buttonAddInterruption);
		this.addBaseElementButtons.add(buttonAddDelay);
		this.addBaseElementButtons.add(buttonAddExtrinsic);

		//// Set the tab button mechanics for the base elements, patches, and time
		for(Button b:addBaseElementButtons)
			b.visibleProperty().bind(this.tabDecisionStructure.selectedProperty());

		// Set the background color for gridPaneBackgroundDecisionStructure
		this.tabDecisionStructure.selectedProperty().addListener((obs, oldValue, newValue) -> {
			if (newValue)
				gridPaneBackgroundDecisionStructure.setStyle("-fx-background-color:  rgb(255, 248, 241);");
			else 
				gridPaneBackgroundDecisionStructure.setStyle("-fx-background-color:  rgb(255, 255, 255);");
		});

		// Set the labelFrameState to be visible when the PatchesAndTime tab is selected
		this.labelViewState.visibleProperty().bind(
				Bindings.or(
						Bindings.or(
								Bindings.or(
										this.tabPatchesAndTime.selectedProperty(),
										this.tabActionPhase.selectedProperty()),
								this.tabMutationPhase.selectedProperty()),
						this.tabDeathAndFitness.selectedProperty()));
		this.labelViewState.managedProperty().bind(
				Bindings.or(
						Bindings.or(
								Bindings.or(
										this.tabPatchesAndTime.selectedProperty(),
										this.tabActionPhase.selectedProperty()),
								this.tabMutationPhase.selectedProperty()),
						this.tabDeathAndFitness.selectedProperty()));

		// Set the visibility mechanics of the right hand slide panel
		this.scrollPanePatchesAndTime.visibleProperty().bind(this.tabPatchesAndTime.selectedProperty());
		this.scrollPanePatchesAndTime.managedProperty().bind(this.tabPatchesAndTime.selectedProperty());
		this.gridPanePatchStateSeparator.visibleProperty().bind(listViewPatches.getSelectionModel().selectedIndexProperty().greaterThan(-1));
		this.gridPanePatchStateSeparator.managedProperty().bind(listViewPatches.getSelectionModel().selectedIndexProperty().greaterThan(-1));
		this.gridPanePatchStates.visibleProperty().bind(listViewPatches.getSelectionModel().selectedIndexProperty().greaterThan(-1));
		this.gridPanePatchStates.managedProperty().bind(listViewPatches.getSelectionModel().selectedIndexProperty().greaterThan(-1));

		// Set the visibility mechanics of the right hand model progress slide panel
		this.scrollPaneModelProgress.visibleProperty().bind(this.tabModelProgress.selectedProperty());
		this.scrollPaneModelProgress.managedProperty().bind(this.tabModelProgress.selectedProperty());
		
		
		// Set the text of the labelViewState when patches and states are selected
		this.tabPatchesAndTime.selectedProperty().addListener((obs, oldValue, newValue) -> {
			if (newValue)
				labelViewState.setText("Select or create patches and states at the right panel. Then select objects and beliefs bekiw to set a patch state specific offset.");
			});
			
		// Set the visibility mechanics of the actions and mutations
		this.tabActionPhase.selectedProperty().addListener((obs, oldValue, newValue) -> {
			if (newValue){
				labelViewState.setText("Please change the actions that an agent can take during an Action Phase below. ");
				gridPaneBetween.setStyle("-fx-background-color:  rgb(255, 248, 241);");
				gridPaneDuring.setStyle("-fx-background-color:  rgb(255, 248, 241);");
			} else {
				gridPaneBetween.setStyle("-fx-background-color:  rgb(255, 255, 255);");
				gridPaneDuring.setStyle("-fx-background-color:  rgb(255, 255, 255);");
			}
		});
		this.tabMutationPhase.selectedProperty().addListener((obs, oldValue, newValue) -> {
			if (newValue){
				labelViewState.setText("Please change the action that the environment takes during a Mutation Phase below. ");
				gridPaneMutations.setStyle("-fx-background-color:  rgb(255, 248, 241);");
				gridPaneEncounterSetup.setStyle("-fx-background-color:  rgb(255, 248, 241);");
			} else {
				gridPaneEncounterSetup.setStyle("-fx-background-color:  rgb(255, 255, 255);");
				gridPaneMutations.setStyle("-fx-background-color:  rgb(255, 255, 255);");
			}
		});

		this.listViewBetween.disableProperty().bind(tabActionPhase.selectedProperty().not());
		this.listViewDuring.disableProperty().bind(tabActionPhase.selectedProperty().not());
		this.listViewEncounterSetup.disableProperty().bind(tabMutationPhase.selectedProperty().not());
		this.listViewMutations.disableProperty().bind(tabMutationPhase.selectedProperty().not());
		
		

		// Action Phase buttons and fields
		this.textFieldMaximumCycle.disableProperty().bind(tabActionPhase.selectedProperty().not());
		this.textFieldMaximumLifetime.disableProperty().bind(tabActionPhase.selectedProperty().not());
		
		this.buttonRemoveBetween.visibleProperty().bind(Bindings.and(
				tabActionPhase.selectedProperty(),
				listViewBetween.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonModifyBetween.visibleProperty().bind(Bindings.and(
				tabActionPhase.selectedProperty(),
				listViewBetween.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonNewBetween.visibleProperty().bind(tabActionPhase.selectedProperty());

		this.buttonRemoveDuring.visibleProperty().bind(Bindings.and(
				tabActionPhase.selectedProperty(),
				listViewDuring.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonModifyDuring.visibleProperty().bind(Bindings.and(
				tabActionPhase.selectedProperty(),
				listViewDuring.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonNewDuring.visibleProperty().bind(tabActionPhase.selectedProperty());

		
		// Mutation Phase
		this.buttonRemoveSetupEncounter.visibleProperty().bind(Bindings.and(
				tabMutationPhase.selectedProperty(),
				listViewEncounterSetup.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonModifySetupEncounter.visibleProperty().bind(Bindings.and(
				tabMutationPhase.selectedProperty(),
				listViewEncounterSetup.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonNewSetupEncounter.visibleProperty().bind(tabMutationPhase.selectedProperty());
		this.buttonSetupEncounterUp.visibleProperty().bind(Bindings.and(
				tabMutationPhase.selectedProperty(),
				listViewEncounterSetup.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonSetupEncounterDown.visibleProperty().bind(Bindings.and(
				tabMutationPhase.selectedProperty(),
				listViewEncounterSetup.getSelectionModel().selectedItemProperty().isNotNull()));
		
		this.buttonRemoveMutation.visibleProperty().bind(Bindings.and(
				tabMutationPhase.selectedProperty(),
				listViewMutations.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonModifyMutation.visibleProperty().bind(Bindings.and(
				tabMutationPhase.selectedProperty(),
				listViewMutations.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonNewMutation.visibleProperty().bind(tabMutationPhase.selectedProperty());
		this.buttonMutationUp.visibleProperty().bind(Bindings.and(
				tabMutationPhase.selectedProperty(),
				listViewMutations.getSelectionModel().selectedItemProperty().isNotNull()));
		this.buttonMutationDown.visibleProperty().bind(Bindings.and(
				tabMutationPhase.selectedProperty(),
				listViewMutations.getSelectionModel().selectedItemProperty().isNotNull()));
		
		
		// Set the visibility mechanics for Fitness and Death
		buttonSetFitnessFunction.visibleProperty().bind(tabDeathAndFitness.selectedProperty());
		this.listViewDeathConditions.disableProperty().bind(tabDeathAndFitness.selectedProperty().not());
		this.comboboxFitnessFunction.disableProperty().bind(this.tabDeathAndFitness.selectedProperty().not());
		this.textFieldFitnessDeath.disableProperty().bind(this.tabDeathAndFitness.selectedProperty().not());
		this.tabDeathAndFitness.selectedProperty().addListener((obs, oldValue, newValue) -> {
			if (newValue){
				labelViewState.setText("Please change the fitness function and conditions of death below. ");
				gridPaneDeathBackground.setStyle("-fx-background-color:  rgb(255, 248, 241);");
				gridPaneFitnessBackground.setStyle("-fx-background-color:  rgb(255, 248, 241);");
			} else {
				gridPaneDeathBackground.setStyle("-fx-background-color:  rgb(255, 255, 255);");
				gridPaneFitnessBackground.setStyle("-fx-background-color:  rgb(255, 255, 255);");
			}
		});
		this.buttonNewDeathCondition.visibleProperty().bind(tabDeathAndFitness.selectedProperty());
		this.buttonRemoveDeathCondition.visibleProperty().bind(Bindings.and(
				tabDeathAndFitness.selectedProperty(),
				listViewDeathConditions.getSelectionModel().selectedItemProperty().isNotNull()));

		// Set the decision structure elements
		startDecisionStructureNodes();

		// Set the patches and time elements
		startPatchAndTimeNodes();

		// Set the actions and mutations elements
		startActionsAndMutationNodes();

		// Set Fitness and Death elements
		startFitnessAndDeathNodes();
		
		// Set the Model progress elements
		startModelProgressNodes();
	}

	/** Start all the nodes in the menu bar*/
	private void startMenuNodes(){
		menuitemNewWorkspace.setOnAction(e -> {
			if (workspace.isChangedAfterSaving()){
				if(ObserverManager.showConfirmationMessage("Discard all unsaved progress?", "Creating a new workspace will remove the current workspace. However, the current workspace has unsaved changed. Do you wish to discard these changes?", "Yes", "No", null))
					workspace = new Workspace();
			} else
				workspace = new Workspace();

			workspace.harmonizeWithView();
			this.update();
			workspace.setSaved();
			});

		menuitemSaveWorkspace.setOnAction(e -> {
			ExternalFileManager.saveObjectToFileUsingFileChooser(workspace);
			workspace.setSaved();
		});

		menuitemOpenWorkspace.setOnAction(e -> {
			if (workspace.isChangedAfterSaving()){
				if(ObserverManager.showConfirmationMessage("Discard all unsaved progress?", "Creating a new workspace will remove the current workspace. However, the current workspace has unsaved changed. Do you wish to discard these changes?", "Yes", "No", null)){
					this.workspace = ExternalFileManager.loadAndCastObjectFromFile(FILE_TYPE.WORKSPACE, Workspace.class);
					workspace.reinflateAllObjectsAndBeliefs();
				}
			} else {
				this.workspace = ExternalFileManager.loadAndCastObjectFromFile(FILE_TYPE.WORKSPACE, Workspace.class);
				workspace.reinflateAllObjectsAndBeliefs();
			}
			workspace.harmonizeWithView();
			this.update();
		});
		
		menuitemPrintWorkspace.setOnAction(e -> {Console.print("PRINTOUT OF WORKSPACE:\n\n"+ workspace);});
		menuItemRunRunSimulation.setOnAction( e -> { runModels();});
		
		///// Runtime parameters
		if (ExternalFileManager.outputFolderDirectory.exists())
			buttonOutputDirectory.setText(ExternalFileManager.outputFolderDirectory.getAbsolutePath());
		else
			ExternalFileManager.outputFolderDirectory.mkdirs();
		buttonOutputDirectory.setOnAction(e -> {
			File newDir = ExternalFileManager.selectDirectory(new File(buttonOutputDirectory.getText()), "Select folder to store results");
			if (newDir != null)
				if (newDir.exists())
					buttonOutputDirectory.setText(newDir.getAbsolutePath());
		});
		
		// Set the processing threads spinner
		int initialThreads = Math.max(Runtime.getRuntime().availableProcessors()-2, 1);
		spinnerProcessingThreads.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10000,
				initialThreads));
		
	}

	/** Set all nodes associated with the DecisionStructure tab*/
	private void startDecisionStructureNodes(){
		//// Set the decision structure buttons
		this.buttonAddPhenotypeDimension.setOnMouseClicked(event -> { new PopupObject(event, PhenotypeObjectTemplate.class); });
		this.buttonAddPhenotypeSlot.setOnMouseClicked(event -> { new PopupSlot(event, null);}); //TODO
		this.buttonAddResource.setOnMouseClicked(event -> { new PopupObject(event, ResourceObjectTemplate.class); });
		this.buttonAddInterruption.setOnMouseClicked(event -> { new PopupObject( event, InterruptionObjectTemplate.class); });
		this.buttonAddDelay.setOnMouseClicked(event -> { new PopupObject( event, DelayObjectTemplate.class); });
		this.buttonAddExtrinsic.setOnMouseClicked(event -> { new PopupObject( event, ExtrinsicObjectTemplate.class); });

	}

	/** Set all nodes associated with the Patches and time tab*/
	private void startPatchAndTimeNodes(){
		/////////////////////////////////////////////
		///////// Set the patch elements ///////////
		///////////////////////////////////////////
		// Set listViewPatches
		listViewPatches.setCellFactory(listViewPatch -> {
			TextFieldListCell<PatchTemplate> cell = new TextFieldListCell<PatchTemplate>();
			cell.setConverter(new StringConverter<PatchTemplate>() {
				@Override
				public String toString(PatchTemplate p) {
					return p.getName();
				}
				@Override
				public PatchTemplate fromString(String s) {
					PatchTemplate patch = cell.getItem();
					if (patch == BasePatch.get()){
						ObserverManager.makeWarningToast("Cannot change the name of the base patch");
						return patch;
					}

					if (workspace.isPatchNameUnique(s))
						patch.setName(s);
					else {
						if (workspace.getPatch(s) != patch)
							ObserverManager.makeWarningToast("This patch name already exists. Please add a unique name.");
					}
					return patch;
				}
			});
			return cell;
		});
		listViewPatches.setEditable(true);

		// When a new item is selected:
		// - show the delete button if there is a delete-able patch is selected
		// Add the states in the patch to listViewPatchStates
		buttonRemovePatch.setVisible(false);

		listViewPatches.getSelectionModel().selectedItemProperty().addListener( (observerable, oldValue, newValue) -> {
			if (newValue == null)
				return;
			if (newValue == BasePatch.get() )
				buttonRemovePatch.setVisible(false);
			else
				buttonRemovePatch.setVisible(true);

			// Add all states to listViewPatchStates and select the first
			listViewPatchStates.getItems().removeAll(listViewPatchStates.getItems());
			listViewPatchStates.getItems().addAll(newValue.getAllStates());
			listViewPatchStates.getSelectionModel().select(0);
		});

		// When adding new items to the PatchList: select the base patch
		listViewPatches.getItems().addListener((ListChangeListener<PatchTemplate>)(c -> {listViewPatches.getSelectionModel().select(BasePatch.get());}));

		// Set remove/add patch button behaviors
		buttonAddPatch.setOnAction(e -> {
			closeAllPopups(PopupPatchTravel.class);
			closeAllPopups(PopupPatchStateMutation.class);
			PatchTemplate newPatch = workspace.addNewPatch();
			listViewPatches.getSelectionModel().select(newPatch);
		});
		buttonRemovePatch.setOnAction(e -> {
			closeAllPopups(PopupPatchTravel.class);
			closeAllPopups(PopupPatchStateMutation.class);
			if (listViewPatches.getSelectionModel().getSelectedItem() != null)
				if (ObserverManager.showConfirmationMessage("Remove patch?", "This permanently removes the patch. This action cannot be undone. Continue?", "Yes", "No", null)){
					workspace.removePatch(listViewPatches.getSelectionModel().getSelectedItem());
					listViewPatches.getSelectionModel().select(BasePatch.get());
				}
		});
		buttonPatchTravel.setOnAction(e -> {
			closeAllPopups(PopupPatchTravel.class);
			closeAllPopups(PopupPatchStateMutation.class);
			new PopupPatchTravel(workspace.getPatchTransitions());});



		//////////////////////////////////////////////////
		///////// Set the patch state elements //////////
		////////////////////////////////////////////////
		// Set listViewPatchStates
		listViewPatchStates.setCellFactory(listViewPatch -> {
			TextFieldListCell<PatchStateTemplate> cell = new TextFieldListCell<PatchStateTemplate>();

			cell.setConverter(new StringConverter<PatchStateTemplate>() {
				@Override
				public String toString(PatchStateTemplate state) {
					return state.getName();
				}
				@Override
				public PatchStateTemplate fromString(String s) {
					PatchStateTemplate state = cell.getItem();
					if (state == BaseState.get()){
						ObserverManager.makeWarningToast("Cannot change the name of the base state patch");
						return state;
					}

					if (listViewPatches.getSelectionModel().getSelectedItem().isPatchStateNameUnique(s))
						state.setName(s);
					else {
						if (listViewPatches.getSelectionModel().getSelectedItem().getState(s) != state)
							ObserverManager.makeWarningToast("This state name already exists. Please add a unique name.");
					}
					return state;
				}
			});
			return cell;
		});
		listViewPatchStates.setEditable(true);

		listViewPatchStates.getSelectionModel().selectedItemProperty().addListener( (observerable, oldValue, newValue) -> {
			if (newValue == null)
				return;
			if (newValue == BaseState.get() )
				buttonRemovePatchState.setVisible(false);
			else
				buttonRemovePatchState.setVisible(true);

			// Set the text on the labelFrameState
			labelViewState.setText("Now showing the objects and beliefs in patch '" + listViewPatches.getSelectionModel().getSelectedItem().getName() +
					"', when that patch is in the state '" + newValue.getName() + "'");
			this.update();
		});
		buttonAddPatchState.setOnAction(e -> {
			closeAllPopups(PopupPatchTravel.class);
			closeAllPopups(PopupPatchStateMutation.class);

			// Create a new PatchState
			PatchTemplate currentPatch = listViewPatches.getSelectionModel().getSelectedItem();
			PatchStateTemplate newState = new PatchStateTemplate(currentPatch);
			currentPatch.addState(newState);

			// Reset the items in listViewPatchStates and select the new state
			listViewPatchStates.getItems().removeAll(listViewPatchStates.getItems());
			listViewPatchStates.getItems().addAll(currentPatch.getAllStates());
			listViewPatchStates.getSelectionModel().select(newState);
		});

		buttonRemovePatchState.setOnAction(e -> {
			closeAllPopups(PopupPatchTravel.class);
			closeAllPopups(PopupPatchStateMutation.class);

			PatchTemplate currentPatch = listViewPatches.getSelectionModel().getSelectedItem();
			if (listViewPatchStates.getSelectionModel().getSelectedItem() != null)
				if (ObserverManager.showConfirmationMessage("Remove patch state?", "This permanently removes the patch state. This action cannot be undone. Continue?", "Yes", "No", null)){
					boolean removedState = currentPatch.removeState(listViewPatchStates.getSelectionModel().getSelectedItem());

					// Reset the items in listViewPatchStates and select the first state
					if (removedState) {
						listViewPatchStates.getItems().removeAll(listViewPatchStates.getItems());
						listViewPatchStates.getItems().addAll(currentPatch.getAllStates());
						listViewPatchStates.getSelectionModel().select(currentPatch.getAllStates().get(0));
					} else
						ObserverManager.makeToast("Could not remove patch state - there must always be at least one patch state in a patch");
				}
		});

		buttonTemporalDynamics.setOnAction(e -> { new PopupPatchStateMutation(listViewPatches.getSelectionModel().getSelectedItem());});
	}

	/** Set all nodes associated with the Actions and mutations tab*/
	//TODO
	private void startActionsAndMutationNodes(){
		setMaximumLifetimeTextField();
		setMaximumCycleTextField();
		buttonNewBetween.setOnAction(e -> {	new PopupAction(null, ActionType.BETWEEN_ENCOUNTERS);});
		buttonModifyBetween.setOnAction(e -> {new PopupAction(listViewBetween.getSelectionModel().getSelectedItem(), ActionType.BETWEEN_ENCOUNTERS);});
		buttonRemoveBetween.setOnAction(e -> {workspace.removeAction(listViewBetween.getSelectionModel().getSelectedItem());});

		buttonNewDuring.setOnAction(e -> {	new PopupAction(null, ActionType.DURING_ENCOUNTER);});
		buttonModifyDuring.setOnAction(e -> {new PopupAction(listViewDuring.getSelectionModel().getSelectedItem(), ActionType.BETWEEN_ENCOUNTERS);});
		buttonRemoveDuring.setOnAction(e -> {workspace.removeAction(listViewDuring.getSelectionModel().getSelectedItem());});
		
		buttonNewSetupEncounter.setOnAction(e -> {	new PopupAction(null, ActionType.SETUP_ENCOUNTER);});
		buttonModifySetupEncounter.setOnAction(e -> {new PopupAction(listViewEncounterSetup.getSelectionModel().getSelectedItem(), ActionType.SETUP_ENCOUNTER);});
		buttonRemoveSetupEncounter.setOnAction(e -> {workspace.removeEncounterSetupRule(listViewEncounterSetup.getSelectionModel().getSelectedItem());});
		
		buttonNewMutation.setOnAction(e -> {	new PopupAction(null, ActionType.MUTATION);});
		buttonModifyMutation.setOnAction(e -> {new PopupAction(listViewMutations.getSelectionModel().getSelectedItem(), ActionType.MUTATION);});
		buttonRemoveMutation.setOnAction(e -> {workspace.removeMutation(listViewMutations.getSelectionModel().getSelectedItem());});
		
		
		// Make the listViewBetween clickable
		listViewBetween.setCellFactory(lv -> {
            ListCell<ActionTemplate> cell = new ListCell<ActionTemplate>() {
                @Override
                protected void updateItem(ActionTemplate item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item == null || empty) {
						setGraphic(null);
						setText(null);
					} else {
						setText( item.toString());
					}
                }
            };
            cell.setOnMouseClicked(e -> {
                if (!cell.isEmpty() && tabActionPhase.isSelected()&& e.getClickCount()>1) {
                    this.buttonModifyBetween.fire();
                    e.consume();
                }
            });
            return cell;
        });

		// Make the listViewDuring clickable
		listViewDuring.setCellFactory(lv -> {
		            ListCell<ActionTemplate> cell = new ListCell<ActionTemplate>() {
		                @Override
		                protected void updateItem(ActionTemplate item, boolean empty) {
		                    super.updateItem(item, empty);
		                    if (item == null || empty) {
								setGraphic(null);
								setText(null);
							} else {
								setText( item.toString());
							}
		                }
		            };
		            cell.setOnMouseClicked(e -> {
		                if (!cell.isEmpty() && tabActionPhase.isSelected() && e.getClickCount()>1) {
		                    this.buttonModifyDuring.fire();
		                    e.consume();
		                }
		            });
		            return cell;
		        });
		
		// Make the listViewEncounterSetup numbered and clickable
		listViewEncounterSetup.setCellFactory(lv -> {
            ListCell<ActionTemplate> cell = new ListCell<ActionTemplate>() {
                @Override
                protected void updateItem(ActionTemplate item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item == null || empty) {
						setGraphic(null);
						setText(null);
					} else {
						setText((listViewEncounterSetup.getItems().indexOf(item)+1)+": " + item.toString());
					}
                }
            };
            cell.setOnMouseClicked(e -> {
                if (!cell.isEmpty() && tabMutationPhase.isSelected()&& e.getClickCount()>1) {
                    this.buttonModifySetupEncounter.fire();
                    e.consume();
                }
            });
            return cell;
		});
		
		// The buttonSetupEncounterUp and buttonSetupEncounterDown should increase and decrease the ordering of the Setup rules, respectively
		buttonSetupEncounterUp.setOnAction(e -> {
			ActionTemplate selected = this.listViewEncounterSetup.getSelectionModel().getSelectedItem();
			int startingPosition = this.listViewEncounterSetup.getSelectionModel().getSelectedIndex();
			if (selected != null && this.listViewEncounterSetup.getItems().size()>1) {
				if (startingPosition == 0)
					return;
			
				// Remove the selected item from the list
				this.listViewEncounterSetup.getItems().remove(startingPosition);
				
				// Add back in
				this.listViewEncounterSetup.getItems().add(startingPosition-1, selected);	
				
				// Select the original item
				this.listViewEncounterSetup.getSelectionModel().select(startingPosition-1);
			}
		});
		buttonSetupEncounterDown.setOnAction(e -> {
			ActionTemplate selected = this.listViewEncounterSetup.getSelectionModel().getSelectedItem();
			int startingPosition = this.listViewEncounterSetup.getSelectionModel().getSelectedIndex();
			if (selected != null && this.listViewEncounterSetup.getItems().size()>1) {
				if (startingPosition == this.listViewEncounterSetup.getItems().size()-1)
					return;
			
				// Remove the selected item from the list
				this.listViewEncounterSetup.getItems().remove(startingPosition);
				
				// Add back in
				this.listViewEncounterSetup.getItems().add(startingPosition+1, selected);	
				
				// Select the original item
				this.listViewEncounterSetup.getSelectionModel().select(startingPosition+1);
			}
		});
		

		// Make the listViewMutations numbered and clickable
		listViewMutations.setCellFactory(lv -> {
            ListCell<ActionTemplate> cell = new ListCell<ActionTemplate>() {
                @Override
                protected void updateItem(ActionTemplate item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item == null || empty) {
						setGraphic(null);
						setText(null);
					} else {
						setText((listViewMutations.getItems().indexOf(item)+1)+": " + item.toString());
					}
                }
            };
            cell.setOnMouseClicked(e -> {
                if (!cell.isEmpty() && tabMutationPhase.isSelected()&& e.getClickCount()>1) {
                    this.buttonModifyMutation.fire();
                    e.consume();
                }
            });
            return cell;
		});
		
		// The buttonSetupEncounterUp and buttonSetupEncounterDown should increase and decrease the ordering of the Setup rules, respectively
		buttonMutationUp.setOnAction(e -> {
			ActionTemplate selected = this.listViewMutations.getSelectionModel().getSelectedItem();
			int startingPosition = this.listViewMutations.getSelectionModel().getSelectedIndex();
			if (selected != null && this.listViewMutations.getItems().size()>1) {
				if (startingPosition == 0)
					return;
			
				// Remove the selected item from the list
				this.listViewMutations.getItems().remove(startingPosition);
				
				// Add back in
				this.listViewMutations.getItems().add(startingPosition-1, selected);	
				
				// Select the original item
				this.listViewMutations.getSelectionModel().select(startingPosition-1);
			}
		});
		buttonMutationDown.setOnAction(e -> {
			ActionTemplate selected = this.listViewMutations.getSelectionModel().getSelectedItem();
			int startingPosition = this.listViewMutations.getSelectionModel().getSelectedIndex();
			if (selected != null && this.listViewMutations.getItems().size()>1) {
				if (startingPosition == this.listViewMutations.getItems().size()-1)
					return;
			
				// Remove the selected item from the list
				this.listViewMutations.getItems().remove(startingPosition);
				
				// Add back in
				this.listViewMutations.getItems().add(startingPosition+1, selected);	
				
				// Select the original item
				this.listViewMutations.getSelectionModel().select(startingPosition+1);
			}
		});
		
	}

	/** Set all nodes associated with the Fitness and death tab*/
	private void startFitnessAndDeathNodes(){
		// Create the cell factory for the comboboxFitnessFunction, which determines how to render a RFunction
		Callback<ListView<RFunction>, ListCell<RFunction>> cellFactory = new Callback<ListView<RFunction>,ListCell<RFunction>>(){
			@Override
			public ListCell<RFunction> call(ListView<RFunction> arg0) {
				return new ListCell<RFunction>(){
					@Override public void updateItem(RFunction item, boolean empty){
						super.updateItem(item,empty);
						if (item == null) return;
						this.setText(item.getName());
					}
				};
			}};
		comboboxFitnessFunction.setCellFactory(cellFactory);
		comboboxFitnessFunction.setButtonCell(cellFactory.call(null));

		// Set the fitness functions as items
		comboboxFitnessFunction.getItems().addAll( RManager.getAllRFunctionsWithTag("FITNESSFUNCTION"));

		// When a new fitness function is selected: add the necessary comboboxes to gridPaneFitnessArguments, and store
		// the combobox in arrayListFitnessArgumentNameToComboBox
		arrayListFitnessArgumentNameToComboBox = new ArrayList<>();
		comboboxFitnessFunction.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
			gridPaneFitnessArguments.getChildren().removeAll(gridPaneFitnessArguments.getChildren());

			if (newValue == null)
				return;

			ArrayList<ColumnConstraints> colConstraints = new ArrayList<>();
			ArrayList<Node> nodes = new ArrayList<>();

			for (int i = 0; i < newValue.getInputFieldCopy().size();i++){
				AttributeField af = newValue.getInputFieldCopy().get(i);

				gridPaneFitnessArguments.getColumnConstraints().add(new ColumnConstraints(100));

				// If this arguments has to be a Single value, then it can either be a phenotypic dimension or an agent's age
				if (NumberObjectSingle.class.isAssignableFrom(af.getClassRestriction())){

					// Create a combobox with phenotypic dimensions (including age)
					ComboBox<PhenotypeElement> cb = new ComboBox<>();
					cb.getStylesheets().add(this.getClass().getResource("../CSSLayout/comboBoxFitnessFunction.css").toExternalForm());

					// Set the cell factory on the new combobox
					Callback<ListView<PhenotypeElement>, ListCell<PhenotypeElement>> cellFactoryPhenotype =
							new  Callback<ListView<PhenotypeElement>, ListCell<PhenotypeElement>>(){
						@Override
						public ListCell<PhenotypeElement> call(
								ListView<PhenotypeElement> phen) {
							return new ListCell<PhenotypeElement>(){
								@Override
								protected void updateItem(PhenotypeElement item, boolean empty) {
									super.updateItem(item, empty);
									if (item == null || empty) {
										setGraphic(null);
									} else {
										setText(item.getName());
									}
								}
							};
						}
					};
					cb.setCellFactory(cellFactoryPhenotype);
					cb.setButtonCell(cellFactoryPhenotype.call(null));

					
					// Add all items
					for (PhenotypeObjectTemplate pheno : workspace.getAllPhenotypeObjects())
						cb.getItems().add(pheno);
					cb.setMinWidth(140);

					// Make the CB disabled with the death and fitness tab is not selected
					cb.disableProperty().bind(tabDeathAndFitness.selectedProperty().not());

					// Keep a record of the argument name and text field
					arrayListFitnessArgumentNameToComboBox.add(cb);

					// Add to nodes
					nodes.add(cb);

				// If this argument has to be an array, it must be a belief
				} else if (af.getClassRestriction() == NumberObjectArray.class) {
					// TODO add belief
				}

				// If its not the last field, add a ' , '
				if (i != newValue.getInputFieldCopy().size()-1 && newValue.getInputFieldCopy().size() > 1){
					gridPaneFitnessArguments.getColumnConstraints().add(new ColumnConstraints(25));
					Label commaLabel = new Label(" , ");
					commaLabel.getStylesheets().add(this.getClass().getResource("../CSSLayout/label.css").toExternalForm());
					commaLabel.setId("actionMutationHeader");
					commaLabel.setMinWidth(25);
					nodes.add(commaLabel);
				}


			}

			gridPaneFitnessArguments.getColumnConstraints().removeAll(gridPaneFitnessArguments.getColumnConstraints());
			gridPaneFitnessArguments.getColumnConstraints().addAll(colConstraints);
			// Add all to the gridPaneFitnessArguments
			gridPaneFitnessArguments.addRow(0, nodes.toArray(new Node[0]));
		});
		
		// Set the buttonNewDeathCondition and buttonRemoveDeathCondition
		buttonNewDeathCondition.setOnAction(e -> {
			if (workspace.getAllPhenotypeObjects().size() == 0)
				ObserverManager.makeWarningToast("Cannot add a death condition without a phenotypic dimension");
			else
				new PopupDeathCondition();
		});
		buttonRemoveDeathCondition.setOnAction(e -> {
			if (this.listViewDeathConditions.getSelectionModel().getSelectedItem() != null)
				workspace.removeDeathCondition(listViewDeathConditions.getSelectionModel().getSelectedItem());
		});
		buttonSetFitnessFunction.setOnAction(e -> {
			// Check if the comboboxFitnessFunction has a selected fitness function
			if (comboboxFitnessFunction.getSelectionModel().getSelectedItem() == null){
				ObserverManager.makeWarningToast("Please select a fitness function");
				return;
			}
			
			// Check if all the arguments are filled in
			for (int i = 0; i < this.arrayListFitnessArgumentNameToComboBox.size(); i ++)
				if (this.arrayListFitnessArgumentNameToComboBox.get(i).getSelectionModel().getSelectedItem() == null){
					ObserverManager.makeWarningToast("Please select a valid value for the " + i + "th argument in the fitness function");
					return;
				}
			
			// Check if the death fitness is a valid number
			if (LayoutManager.isInvalid(this.textFieldFitnessDeath)){
				ObserverManager.makeWarningToast("Please enter a numeric value for the fitness associated with death");
				return;
			}
				
			// Set the fitness function
			PhenotypeElement[] args = new PhenotypeObjectTemplate[this.arrayListFitnessArgumentNameToComboBox.size()];
			for (int i = 0; i < args.length; i ++)
				args[i] = this.arrayListFitnessArgumentNameToComboBox.get(i).getSelectionModel().getSelectedItem();
			workspace.setFitnessFunction(this.comboboxFitnessFunction.getSelectionModel().getSelectedItem(), args);
				
			// Set the fitness of death
			workspace.setFitnessDeath(new DecimalNumber(this.textFieldFitnessDeath.getText()));
		});
		
		// Make sure that fitness(death) is a numeric value
		LayoutManager.setLayoutHandler(textFieldFitnessDeath, FieldRestriction.DOUBLE);
	}

	/** Set all nodes associated with the Model progress tab*/
	private void startModelProgressNodes() {
		/*
		this.labelElapsedTime.setText("Not started yet.");
		this.labelRemainingTime.setText("Not started yet.");
		
		this.buttonInterruptActiveModels.setOnAction(e -> {
			ModelManager.get().stopAllModels();
		});
		
		// Set up the TableView that shows the progress of all models
		this.tableColumnModelName.setCellValueFactory(
				new Callback<CellDataFeatures<ModelRecord, String>, ObservableValue<String>>(){
					@Override
					public ObservableValue<String> call(CellDataFeatures<ModelRecord, String> t) {
						return new SimpleStringProperty(t.getValue().modelName);
					}});
		this.tableColumnModelDescription.setCellValueFactory(
				new Callback<CellDataFeatures<ModelRecord, String>, ObservableValue<String>>(){
					@Override
					public ObservableValue<String> call(CellDataFeatures<ModelRecord, String> t) {
						return new SimpleStringProperty(t.getValue().modelDescription);
					}});
		
		// Create and set the cell factory that contains the progress bar for the forwards pass
		Callback<TableColumn<ModelRecord, Integer>, TableCell<ModelRecord, Integer>> cellFactory =
			    new Callback<TableColumn<ModelRecord, Integer>, TableCell<ModelRecord, Integer>>() {
			public TableCell<ModelRecord, Integer> call(TableColumn<ModelRecord, Integer> p) {
			    return new TableCell<ModelRecord, Integer>() {

			        private ProgressBar pb = new ProgressBar();
			        @Override
			        public void updateItem(Integer item, boolean empty) {
			            super.updateItem(item, empty);
			            if (empty) {
			                setText(null);
			                setGraphic(null);
			            } else {
			                pb.setProgress((double)item/100);
			                
			                if (item >= 100) {
			                	pb.setStyle("complete");
			                	pb.getStyleClass().add("complete");
			                }
			                setGraphic(pb);
			            }
			        }
			    };
			}
			};
		this.tableColumnModelForwards.setCellFactory( cellFactory );
		this.tableColumnModelBackwards.setCellFactory( cellFactory );
		
		// Set the cell value factories
		this.tableColumnModelForwards.setCellValueFactory(
				new Callback<CellDataFeatures<ModelRecord, Integer>, ObservableValue<Integer>>(){
					@Override
					public ObservableValue<Integer> call(CellDataFeatures<ModelRecord, Integer> t) {
						return new SimpleIntegerProperty(t.getValue().percentageForwardsPassCompleted).asObject();
					}});

		this.tableColumnModelBackwards.setCellValueFactory(
				new Callback<CellDataFeatures<ModelRecord, Integer>, ObservableValue<Integer>>(){
					@Override
					public ObservableValue<Integer> call(CellDataFeatures<ModelRecord, Integer> t) {
						return new SimpleIntegerProperty(t.getValue().percentageBackwardsPassCompleted).asObject();
					}});
				
		// Set the status column
		this.tableColumnModelStatus.setCellValueFactory(
				new Callback<CellDataFeatures<ModelRecord, String>, ObservableValue<String>>(){
					@Override
					public ObservableValue<String> call(CellDataFeatures<ModelRecord, String> t) {
						ModelRecord rec = t.getValue();
						String status;
						if (rec.stage == ModelStage.BUSY_WITH_FORWARDS_PASS)
							status = "F: " + rec.percentageForwardsPassCompleted + "%";
						else if (rec.stage == ModelStage.BUSY_WITH_BACKWARDS_PASS)
							status = "B: " + rec.percentageBackwardsPassCompleted + "%";
						else if (rec.stage == ModelStage.INTERRUPTED)
							status = "Interrupted";
						else if (rec.stage == ModelStage.WAITING)
							status = "Waiting";
						else
							status = "Done";
						return new SimpleStringProperty(status);
					}});
		// Add the ActiveModels to the tableview
		this.tableViewActiveModels.setItems(ModelManager.get().getAllRecords());
		*/
	}

	/** Sets the behavior of the textfieldMaximumLifetime */
	private void setMaximumLifetimeTextField(){
		// Set the listeners that govern the validity (and layout)
		textFieldMaximumLifetime.textProperty().addListener(new ChangeListener<String>(){
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {

				if (FieldRestriction.isValid(newValue, FieldRestriction.POSITIVE_INTEGER))
					textFieldMaximumLifetime.getStyleClass().add("changed");
				else
					textFieldMaximumLifetime.getStyleClass().add("invalid");
			}
		});

		// make the focus listener fire after enter has been pressed
		textFieldMaximumLifetime.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				textFieldMaximumLifetime.getParent().requestFocus();
			}
		});

		// Update whenever the focus is lost: check whether the new value is valid.
		// If so, change it in the workspace.
		// If not, restore the previous value and give a warning toast.
		textFieldMaximumLifetime.focusedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if (!newValue && !FieldRestriction.isValid(textFieldMaximumLifetime.getText(), FieldRestriction.POSITIVE_INTEGER)) {
					textFieldMaximumLifetime.setText(workspace.getMaximumLifeTime()+ "");
					textFieldMaximumLifetime.getStyleClass().removeAll(Collections.singleton("invalid"));
					textFieldMaximumLifetime.getStyleClass().removeAll(Collections.singleton("changed"));
					textFieldMaximumLifetime.getStyleClass().add("normal");
					ObserverManager.makeWarningToast("Invalid maximum lifetime value. Life times can only be positive integers.");
				} else {
					textFieldMaximumLifetime.getStyleClass().removeAll(Collections.singleton("invalid"));
					textFieldMaximumLifetime.getStyleClass().removeAll(Collections.singleton("changed"));
					textFieldMaximumLifetime.getStyleClass().add("normal");
					workspace.setMaximumLifeTime(Integer.parseInt(textFieldMaximumLifetime.getText()));
				}
			}
		});
	}

	/** Sets the behavior of the textfieldMaximumLifetime */
	private void setMaximumCycleTextField(){
		// Set the listeners that govern the validity (and layout)
		textFieldMaximumCycle.textProperty().addListener(new ChangeListener<String>(){
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {

				if (FieldRestriction.isValid(newValue, FieldRestriction.POSITIVE_INTEGER))
					textFieldMaximumCycle.getStyleClass().add("changed");
				else
					textFieldMaximumCycle.getStyleClass().add("invalid");
			}
		});

		// make the focus listener fire after enter has been pressed
		textFieldMaximumCycle.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				textFieldMaximumCycle.getParent().requestFocus();
			}
		});

		// Update whenever the focus is lost: check whether the new value is valid.
		// If so, change it in the workspace.
		// If not, restore the previous value and give a warning toast.
		textFieldMaximumCycle.focusedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if (!newValue && !FieldRestriction.isValid(textFieldMaximumCycle.getText(), FieldRestriction.POSITIVE_INTEGER)) {
					textFieldMaximumCycle.setText(workspace.getMaximumLifeTime()+ "");
					textFieldMaximumCycle.getStyleClass().removeAll(Collections.singleton("invalid"));
					textFieldMaximumCycle.getStyleClass().removeAll(Collections.singleton("changed"));
					textFieldMaximumCycle.getStyleClass().add("normal");
					ObserverManager.makeWarningToast("Invalid maximum cycle time value. Cycle times can only be positive integers.");
				} else {
					textFieldMaximumCycle.getStyleClass().removeAll(Collections.singleton("invalid"));
					textFieldMaximumCycle.getStyleClass().removeAll(Collections.singleton("changed"));
					textFieldMaximumCycle.getStyleClass().add("normal");
					workspace.setMaximumLifeTime(Integer.parseInt(textFieldMaximumCycle.getText()));
				}
			}
		});
	}
	
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Mechanics 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** A x and y position is often required to draw on the scrollPane. For instance, when adding a popupPane to the scrollPane.
	 * However, the mouse might not be on the scrollPane directly, making a mouseEvent unusable. What is accessible, however,
	 * is the location of scrollPane relative on the total Scene. This function converts the X position of the scene (which
	 * can be acquired by any mouse event) and translates it to the corresponding X position on the Frame's scrollPane.
	 * @param sceneX
	 */
	public double sceneXtoPaneX(double sceneX) {
		Bounds b = anchorPaneScrollPane.localToScene(anchorPaneScrollPane.getBoundsInLocal());
		return sceneX - b.getMinX();
	}

	/** Return the x position of the center of the main scrolling pane*/
	public double getPaneCenterX(){
		return anchorPaneScrollPane.getWidth()/2;
	}
	
	/** Return the x position of the center of the scene*/
	public double getSceneCenterX(){
		return scene.getX() + (scene.getWidth()/2);
	}

	/** A x and y position is often required to draw on the scrollPane. For instance, when adding a popupPane to the scrollPane.
	 * However, the mouse might not be on the scrollPane directly, making a mouseEvent unusable. What is accessible, however,
	 * is the location of scrollPane relative on the total Scene. This function converts the Y position of the scene (which
	 * can be acquired by any mouse event) and translates it to the corresponding Y position on the Frame's scrollPane.
	 * @param sceneY
	 */
	public double sceneYtoPaneY(double sceneY) {
		Bounds b = anchorPaneScrollPane.localToScene(anchorPaneScrollPane.getBoundsInLocal());
		return sceneY - b.getMinY();
	}

	/** Return the y position of the center of the main scrolling pane*/
	public double getPaneCenterY(){
		return anchorPaneScrollPane.getHeight()/2;
	}

	/** Return the y position of the center of the scene*/
	public double getSceneCenterY(){
		return scene.getY() + (scene.getHeight()/2);
	}

	/**Get the State of the View. The state basically means: which left-hand side tab is open?*/
	public ViewState getState(){
		if (tabDecisionStructure.isSelected())
			return ViewState.DECISION_STRUCTURE;
		if (tabPatchesAndTime.isSelected())
			return ViewState.PATCH_AND_TIME;
		if (tabActionPhase.isSelected() )
			return ViewState.ACTION_PHASE;
		if (tabMutationPhase.isSelected())
			return ViewState.MUTATION_PHASE;
		if (tabDeathAndFitness.isSelected())
			return ViewState.FITNESS_DEATH;
		return null;

	}

	/**Redraws all objects, beliefs, and actions to match the current state of the View.
	 * Also makes sure no nodes are selected after changing state
	 * Should be done with the left hand side toggleButtons only*/
	private void changedState(){
		Console.print("Changed the state of the view to: " + this.getState());
		if (this.getState() != ViewState.MUTATION_PHASE){
			listViewEncounterSetup.getSelectionModel().select(null);
			listViewMutations.getSelectionModel().select(null);
		}
		if (this.getState() != ViewState.ACTION_PHASE){
			listViewBetween.getSelectionModel().select(null);
			listViewDuring.getSelectionModel().select(null);
		}
		
		
		update();
		this.closeAllPopups();
	}
	
	/** Register a popup. This should be done by AbstractPopup */
	public void registerPopup(AbstractPopup newPopup) {
		this.activePopups.add(newPopup);
	}

	/** Closes all registeredPopup */
	public void closeAllPopups() {
		for (AbstractPopup popup: activePopups)
			popup.close();
	}

	/** Closes all registeredPopup of the specified class*/
	public void closeAllPopups(Class<? extends AbstractPopup> clazz) {
		for (AbstractPopup popup: activePopups)
			if (popup.getClass().isAssignableFrom(clazz))
				popup.close();
	}

	/** Redraws all ObjectiveTemplates, beliefs, and actions in the view.*/
	public void update(){
		// Objects
		for (Node n: this.vboxObjectPhenotypeDimension.getChildren())
			if (n instanceof AbstractObjectiveTemplate)
				((AbstractObjectiveTemplate) n).update();
		for (Node n: this.vboxPhenotypeSlot.getChildren())
			if (n instanceof AbstractPhenotypeSlotTemplate)
				((AbstractPhenotypeSlotTemplate) n).update();
		for (Node n: this.vboxPhenotypeSlot.getChildren())
			if (n instanceof AbstractObjectiveTemplate)
				((AbstractObjectiveTemplate) n).update();
		for (Node n: this.vboxObjectResource.getChildren())
			if (n instanceof AbstractObjectiveTemplate)
				((AbstractObjectiveTemplate) n).update();
		for (Node n: this.vboxObjectDelay.getChildren())
			if (n instanceof AbstractObjectiveTemplate)
				((AbstractObjectiveTemplate) n).update();
		for (Node n: this.vboxObjectInterruption.getChildren())
			if (n instanceof AbstractObjectiveTemplate)
				((AbstractObjectiveTemplate) n).update();
		for (Node n: this.vboxObjectExtrinsic.getChildren())
			if (n instanceof AbstractObjectiveTemplate)
				((AbstractObjectiveTemplate) n).update();

		// Beliefs
		for (Node n: this.vboxBeliefResource.getChildren())
			if (n instanceof AbstractBeliefTemplate)
				((AbstractBeliefTemplate) n).update();
		for (Node n: this.vboxBeliefDelay.getChildren())
			if (n instanceof AbstractBeliefTemplate)
				((AbstractBeliefTemplate) n).update();
		for (Node n: this.vboxBeliefInterruption.getChildren())
			if (n instanceof AbstractBeliefTemplate)
				((AbstractBeliefTemplate) n).update();
		for (Node n: this.vboxBeliefExtrinsic.getChildren())
			if (n instanceof AbstractBeliefTemplate)
				((AbstractBeliefTemplate) n).update();
		
		// Update the fitness function
		this.setFitnessFunction(workspace.getFitnessFunction());
			
	}

	/** Returns the selected patch, or null if no patch is selected*/
	public PatchTemplate getSelectedPatch(){
		return listViewPatches.getSelectionModel().getSelectedItem();
	}

	/** Returns the selected patch state, or null if no patch state is selected*/
	public PatchStateTemplate getSelectedPatchState(){
		return listViewPatchStates.getSelectionModel().getSelectedItem();
	}

	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Communication with Workspace 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////

	/////////////////// Functions called by the workspace
	/** Remove all objects and beliefs from the view (does not remove them from the workspace)*/
	protected void clearAllObjectsAndBeliefs(){
		this.vboxObjectPhenotypeDimension.getChildren().removeAll(vboxObjectPhenotypeDimension.getChildren());
		this.vboxPhenotypeSlot.getChildren().removeAll(vboxPhenotypeSlot.getChildren());
		this.vboxObjectResource.getChildren().removeAll(vboxObjectResource.getChildren());
		this.vboxObjectInterruption.getChildren().removeAll(vboxObjectInterruption.getChildren());
		this.vboxObjectDelay.getChildren().removeAll(vboxObjectDelay.getChildren());
		this.vboxObjectExtrinsic.getChildren().removeAll(vboxObjectExtrinsic.getChildren());

		this.vboxBeliefResource.getChildren().removeAll(vboxBeliefResource.getChildren());
		this.vboxBeliefInterruption.getChildren().removeAll(vboxBeliefInterruption.getChildren());
		this.vboxBeliefDelay.getChildren().removeAll(vboxBeliefDelay.getChildren());
		this.vboxBeliefExtrinsic.getChildren().removeAll(vboxBeliefExtrinsic.getChildren());
	}

	/** Called by the workspace to tell the View that a new PhenotypeTemplate object should be added to the view*/
	protected void addPhenotypeObject (PhenotypeObjectTemplate newObject)			{	this.vboxObjectPhenotypeDimension.getChildren().add(newObject);	}

	/** Called by the workspace to tell the View that a new PhenotypeTemplate object should be added to the view*/
	protected void addPhenotypeSlot (AbstractPhenotypeSlotTemplate newObject) { this.vboxPhenotypeSlot.getChildren().add(newObject);}
	
	/** Called by the workspace to tell the View that a new ResourceTemplate object should be added to the view*/
	protected void addResourceObject (ResourceObjectTemplate newObject)			{	this.vboxObjectResource.getChildren().add(newObject);	}

	/** Called by the workspace to tell the View that a new DelayTemplate object should be added to the view*/
	protected void addDelayObject (DelayObjectTemplate newObject)					{	this.vboxObjectDelay.getChildren().add(newObject);	}

	/** Called by the workspace to tell the View that a new InterruptionTemplate object should be added to the view*/
	protected void addInterruptionObject (InterruptionObjectTemplate newObject)	{	this.vboxObjectInterruption.getChildren().add(newObject);	}

	/** Called by the workspace to tell the View that a new ExtrinsicTemplate object should be added to the view*/
	protected void addExtrinsicObject (ExtrinsicObjectTemplate newObject)			{	this.vboxObjectExtrinsic.getChildren().add(newObject);	}

	/** Called by the workspace to tell the View that a new PhenotypeTemplate object should be removed from the view*/
	protected void removePhenotypeObject (PhenotypeObjectTemplate newObject)			{	this.vboxObjectPhenotypeDimension.getChildren().remove(newObject);	}

	/** Called by the workspace to tell the View that a new PhenotypeDelayedResourceSlotTemplate object should be removed from the view*/
	protected void removePhenotypeSlot(PhenotypeObjectTemplate newObject)			{	this.vboxPhenotypeSlot.getChildren().remove(newObject);	}

	/** Called by the workspace to tell the View that a new ResourceTemplate object should be removed from the view*/
	protected void removeResourceObject (ResourceObjectTemplate newObject)				{	this.vboxObjectResource.getChildren().remove(newObject);	}

	/** Called by the workspace to tell the View that a new DelayTemplate object should be removed from the view*/
	protected void removeDelayObject (DelayObjectTemplate newObject)					{	this.vboxObjectDelay.getChildren().remove(newObject);	}

	/** Called by the workspace to tell the View that a new InterruptionTemplate object should be removed from the view*/
	protected void removeInterruptionObject (InterruptionObjectTemplate newObject)		{	this.vboxObjectInterruption.getChildren().remove(newObject);	}

	/** Called by the workspace to tell the View that a new ExtrinsicTemplate object should be removed from the view*/
	protected void removeExtrinsicObject (ExtrinsicObjectTemplate newObject)			{	this.vboxObjectExtrinsic.getChildren().remove(newObject);	}

	/** Called by the workspace to tell the View that a new ResourceTemplate Belief should be added to the view*/
	protected void addResourceBelief(ResourceBeliefTemplate newBelief)			{	this.vboxBeliefResource.getChildren().add(newBelief);	}

	/** Called by the workspace to tell the View that a new DelayTemplate Belief should be added to the view*/
	protected void addDelayBelief (DelayBeliefTemplate newBelief)					{	this.vboxBeliefDelay.getChildren().add(newBelief);	}

	/** Called by the workspace to tell the View that a new InterruptionTemplate Belief should be added to the view*/
	protected void addInterruptionBelief (InterruptionBeliefTemplate newBelief)	{	this.vboxBeliefInterruption.getChildren().add(newBelief);	}

	/** Called by the workspace to tell the View that a new ExtrinsicTemplate Belief should be added to the view*/
	protected void addExtrinsicBelief (ExtrinsicBeliefTemplate newBelief)			{	this.vboxBeliefExtrinsic.getChildren().add(newBelief);	}

	/** Called by the workspace to tell the View that a new PatchTemplate should be added to the view*/
	protected void addPatch(PatchTemplate pt) { this.listViewPatches.getItems().add(pt);}

	/** Called by the workspace to tell the View that an existing PatchTemplate should be removed from the view*/
	protected void removePatch(PatchTemplate pt) { this.listViewPatches.getItems().remove(pt);}

	/** Called by the workspace to tell the View that all PatchTemplates should be removed from the view*/
	protected void clearAllPatches() { this.listViewPatches.getItems().removeAll(listViewPatches.getItems());}

	/** Set a patch to be selected*/
	protected void selectPatch(PatchTemplate pt) { listViewPatches.getSelectionModel().select(pt);}

	/** Set the maximum lifetime length*/
	protected void setMaximumLifetime(int value) {
		textFieldMaximumLifetime.setText(value+"");}

	/** Set the maximum cycle length */
	protected void setMaximumCycle(int value) { textFieldMaximumCycle.setText(value+"");}

	/** Remove all actions and mutations in the view. Does not remove them from the workspace*/
	protected void clearAllActionsAndMutations(){
		this.listViewBetween.getItems().removeAll(listViewBetween.getItems());
		this.listViewDuring.getItems().removeAll(listViewDuring.getItems());
		this.listViewEncounterSetup.getItems().removeAll(listViewEncounterSetup.getItems());
		this.listViewMutations.getItems().removeAll(listViewMutations.getItems());
	}

	/** Add the ActionTemplates to the Between action listview. Does not remove actions first.*/
	protected void addBetweenActions(ArrayList<ActionTemplate> actions){
		this.listViewBetween.getItems().addAll(actions);
	}

	/** Add the ActionTemplates to the During action listview. Does not remove actions first.*/
	protected void addDuringActions(ArrayList<ActionTemplate> actions){
		this.listViewDuring.getItems().addAll(actions);
	}

	/** Add the ActionTemplates to the encounter setup rules listview. Does not remove actions first.*/
	protected void addEncounterSetupActions(ArrayList<ActionTemplate> actions){
		this.listViewEncounterSetup.getItems().addAll(actions);
	}

	/** Add the ActionTemplates to the action phase setup rules listview. Does not remove actions first.*/
	protected void addMutations(ArrayList<ActionTemplate> mut){
		this.listViewMutations.getItems().addAll(mut);
	}


	/** Adds a mutation to the listViewMutations*/
	protected void addMutation(ActionTemplate mutation){
		this.listViewMutations.getItems().add(mutation);
	}

	/** Add all mutations to the listViewMutations*/
	protected void addAllMutations(ArrayList<ActionTemplate> mutations){
		this.listViewMutations.getItems().addAll(mutations);
	}
	
	/** Set the fitness function*/
	protected void setFitnessFunction(FitnessFunctionTemplate fitnessFunction){
		if (fitnessFunction == null) {
			this.comboboxFitnessFunction.getSelectionModel().select(null);
			return;
		}
		// First, set the fitnessFunction combobox.
		this.comboboxFitnessFunction.getSelectionModel().select(fitnessFunction.fitnessFunction);
		
		// This should create the comboboxes for the arguments, which are stored in arrayListFitnessArgumentNameToComboBox
		// Next, we update these comboboxes
		for (int i = 0; i < fitnessFunction.args.length; i ++)
			arrayListFitnessArgumentNameToComboBox.get(i).getSelectionModel().select(
					fitnessFunction.args[i]);
	}
	
	/** Sets the fitness associated with death (note, whether it is used depends on whether the fitness function or a fixed
	 * fitness value is used for dead-before-the-end-of-run states*/
	public void setFixedFitnessForDeadButNotAgeRestrictedStates(DecimalNumber fitness){
		if (fitness != null)
			this.textFieldFitnessDeath.setText(fitness.toStringWithoutTrailingZeros());
	}
	
	/** Remove all death conditions in the view. Does not remove them from the workspace*/
	protected void clearAllDeathConditions(){
		this.listViewDeathConditions.getItems().removeAll(listViewDeathConditions.getItems());
	}
	
	/** Add all death conditions to the listViewMutations*/
	protected void addAllDeathConditions(ArrayList<DeathConditionTemplate> deathConditions){
		this.listViewDeathConditions.getItems().addAll(deathConditions);
	}

	/////////////////// Functions called by other objects to inform the workspace
	/** Called by any function. Sets all fields in the originalObject to match the newObject.
	 * If changedDomain is true, all beliefs, actions, and patch specific offsets that include this
	 * object will be removed from the workspace.*/
	public void changeObject(AbstractObjectiveTemplate originalObject, AbstractObjectiveTemplate newObject, boolean changedDomain){
		this.workspace.changeObjectiveTemplate(originalObject, newObject, changedDomain);
	}

	/** Called by any function. Delete object from workspace. Returns true if the user is sure, and false if they changed their mind.*/
	public boolean deleteObject(AbstractObjectiveTemplate o){
		if (ObserverManager.showConfirmationMessage("Remove object?", "This permanently removes the object "+ o.getName()+". This action cannot be undone. Continue?", "Yes", "No", null)) {
			this.workspace.removeObjectiveTemplate(o);
			return true;
		}
		return false;
	}

	/** Called by any function. Delete phenotype slot from workspace. Returns true if the user is sure, and false if they changed their mind.*/
	public boolean deletePhenotypeSlot(AbstractPhenotypeSlotTemplate s){
		if (ObserverManager.showConfirmationMessage("Remove phenotype slot?", "This permanently removes the phenotype slot "+ s.getName()+". This action cannot be undone. Continue?", "Yes", "No", null)) {
			this.workspace.removePhenotypeSlot(s);
			return true;
		}
		return false;
	}
	/** Called by any function. Add object to workspace*/
	public void addObject(AbstractObjectiveTemplate o){
		this.workspace.addObjectiveTemplate(o);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Model progress 	/////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** A clock that updates the time elapsed/ time remaining labels when running a model */
	public class RuntimeClock implements Runnable {
		private final long timeWhenStartingRun;
		public Label labelElapsedTime, labelRemainingTime, labelPercentageDone;
		public ObservableList<ModelRecord> modelRecords;
		
		private boolean stopped;
		public RuntimeClock(Label labelElapsedTime, 
				Label labelRemainingTime,
				Label labelPercentageDone) {
			this.timeWhenStartingRun = System.nanoTime();
			this.labelElapsedTime = labelElapsedTime;
			this.labelPercentageDone = labelPercentageDone;
			this.labelRemainingTime = labelRemainingTime;
			this.modelRecords = ModelManager.get().getAllRecords();
			stopped = false;
		}

		public void stopClockReasonInterrupted() {
			labelRemainingTime.setText("Stopped due to interruption");
			stopped = true;
		}
		
		public void stopClockReasonDone() {
			labelRemainingTime.setText("All models completed");
			stopped = true;
		}
		
		// TODO:
		private void update() {
			// Figure out how long it has been since the start of the runs
			/*long elapsedTime = System.nanoTime() - timeWhenStartingRun;
			labelElapsedTime.setText(Helper.nanoSecondsDifferenceToHumanReadableFormat(
					elapsedTime));
			
			// Get number of active models
			double models = modelRecords.size();
			
			// Each finished model adds 1/models to the total done proportion
			double weightPerModel = 1/models;
			
			// Check for each active model how far they are, weighing
			// the forwards pass and backwards pass equally
			double totalProportionDone = 0;
			for (ModelRecord record: this.modelRecords) {
				double proportionModelDone = 0;
				proportionModelDone = proportionModelDone + 0.5 * (double) ((double)record.percentageForwardsPassCompleted/100);
				proportionModelDone = proportionModelDone + 0.5 * (double) ((double)record.percentageBackwardsPassCompleted/100);
				totalProportionDone = totalProportionDone + weightPerModel * proportionModelDone;
			}
			
			labelPercentageDone.setText(Math.round(totalProportionDone*100) + "%");
			
			if (totalProportionDone < 0.001) {
				labelRemainingTime.setText("Too early to give estimate...");
				return ;
			} 
			if (totalProportionDone > 0.999999999999) {
				//this.stopClockReasonDone();
				return;
			}
				
			
			// Next, give a best estimate on the remaining time;
			// Estimate how long each done 
			long totalTimeLeft = (long) (elapsedTime / totalProportionDone);
			labelRemainingTime.setText(Helper.nanoSecondsDifferenceToHumanReadableFormat(
					totalTimeLeft));*/
			
		}

		@Override
		public void run() {
			while (!stopped) {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						update();
					}});
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					ObserverManager.notifyObserversOfError(e);
				}
			}
		}
	}
	private RuntimeClock runtimeClock;
	
	/** Create and run all models that the workspace has to create */
	private void runModels() {
		throw new UnsupportedOperationException();
		// Check if we are able to create a model
		if (!workspace.isReadyForModelConstruction())
			return;

		// If there are active models: is the user sure that all models should be interrupted?
		if (ModelManager.get().isThereAnActiveModel())
			// Ask the user if they are sure
			if (!ObserverManager.showConfirmationMessage("Stop all active models?", 
					"This action will stop all active models. Their progress will not be saved, and this action cannot be undone. Do you want to continue?", 
					"Stop all active models", 
					"Cancel",
					null))
				return ;

		// Tell the ModelManager to interrupt everything
		ModelManager.get().stopAllModels();
		
		// Set the time labels
		this.labelElapsedTime.setText("Not updated yet");
		this.labelRemainingTime.setText("Not updated yet");
		
		// Figure out what the model settings will be 
		File userSpecifiedOutputDirectory = new File(buttonOutputDirectory.getText());
		int threads = this.spinnerProcessingThreads.getValue();
		boolean saveT1StatesAsOutput = this.checkMenuItemSaveT1.isSelected();
		SaveT2Mode saveT2Mode;
		if (this.radioMenuItemSaveAllT2.isSelected())
			saveT2Mode = SaveT2Mode.ALL;
		else if (this.radioMenuItemNoSaveT2.isSelected())
			saveT2Mode = SaveT2Mode.NONE;
		else
			saveT2Mode = SaveT2Mode.T0_ONLY;
		boolean saveT2TreesToFile = this.CheckMenuItemLimitRAMUse.isSelected();
		boolean savePerAge = this.checkMenuItemSaveResultsPerAge.isSelected();
		boolean doTests = this.checkMenuItemDoTests.isSelected();
		NumberObjectRepresentation nro;
		if (radioMenuItemHighAccuracy.isSelected())
			nro = NumberObjectRepresentation.DECIMALNUMBER;
		else
			nro = NumberObjectRepresentation.DOUBLENUMBER;
		
		// Compute all combinations of all sampling distributions of all objects
		ArrayList< ArrayList<Integer>> allIntegerCombinations = new ArrayList<>();
		ArrayList< AbstractObjectiveTemplate> objects = workspace.getAllNonPhenotypeObjects();
		for (int o = 0; o < objects.size(); o++) {
			// Create a list of Integers that range from 1 to n, where n is the number
			// of sampling distributions of this object
			ArrayList<Integer> samplingDistributionsOfObject = new ArrayList<>();
			
			
			if (objects.get(o).getAllSamplingDistributions() != null) // Skip constants
				for (int i = 0; i < objects.get(o).getAllSamplingDistributions().size(); i ++)
					samplingDistributionsOfObject.add(i);
			else
				samplingDistributionsOfObject.add(-1);
			allIntegerCombinations.add(samplingDistributionsOfObject);
		}
		
		// Get all possible permutations of sampling distributions - there
		// will be exactly one model for each combination
		ArrayList<ArrayList<Integer>> allPermutations = Helper.getAllPermutations(allIntegerCombinations);
	
		// For each possible combination of sampling distributions:
		// Create a HashMap that maps each object to an integer
		// that specifies which sampling distribution to use. 
		ArrayList<HashMap<AbstractObjectiveTemplate, Integer>> samplingDistributionsToUseForAllModels = new ArrayList<>();
		for (ArrayList<Integer> permutation : allPermutations) {
			HashMap<AbstractObjectiveTemplate, Integer> map = new HashMap<>();
			for (int i = 0; i < permutation.size(); i ++)
				if (permutation.get(i) != -1) // constants have a -1, and should be skipped
					map.put(objects.get(i), permutation.get(i));
			samplingDistributionsToUseForAllModels.add(map);
		}
		
		// Now we know which combinations of sampling distributions we will use for a model
		// The next step is to create all the models, and put them into an ArrayList
		ArrayList<Model> models = new ArrayList<>();
		for (int i = 0; i < samplingDistributionsToUseForAllModels.size(); i ++) {
			Model m = new Model(
					this.workspace,
					this,
					i,
					samplingDistributionsToUseForAllModels.get(i), 
					threads,
					userSpecifiedOutputDirectory,
					saveT1StatesAsOutput,
					saveT2Mode,
					saveT2TreesToFile,
					savePerAge,
					doTests,
					nro);
			models.add(m);
		}
		
		// Ask user to start the run
		if (!ObserverManager.showConfirmationMessage("Start run?", 
				"This action will construct and run "+ models.size() +" models as specified in the workspace. Continue?", 
				"Run models", 
				"Cancel", 
				workspace.toString()))
			return;
		

		// If the answer was yet, pass all the Models over to the ModelManager
		ModelManager.get().addModelsToQueue(models);
		
		// Switch the view to the model progress tab
		this.tabModelProgress.setSelected(true);
		
		// Start the clock
		this.runtimeClock = new RuntimeClock(labelElapsedTime, labelRemainingTime,labelPercentageDone);
		Thread clockThread = new Thread(runtimeClock);
		clockThread.setName("Clock thread");
		clockThread.start();
	}

	/** Update the TableView to show the progress of the models */
	public void updateModelProgress() {
		throw new UnsupportedOperationException();
		Platform.runLater(new Runnable() {
			public void run() {
				tableViewActiveModels.refresh();
			}
		});
	}
	
	/////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Messaging system 	/////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////


	@Override
	public void showErrorMessage(String title, String message, String details) {
		if (details == null)
			JavaFXHelper.showErrorAlert(title, message, this.stage);
		else
			JavaFXHelper.showErrorAlert(title, message, details, this.stage);
	}

	@Override
	public void showWarningMessage(String title, String message, String details) {
		if (details == null)
			JavaFXHelper.showWarningAlert(title, message, this.stage);
		else
			JavaFXHelper.showWarningAlert(title, message, details, this.stage);

	}

	@Override
	public void showToast(String message) {
		toaster.makeToast(message);
	}

	@Override
	public boolean confirmationMessage(String title, String message, String textForYesButton, String textForNoButton, String details) {
		return JavaFXHelper.showConfirmationYesNoAlert(title, message, this.stage, textForYesButton, textForNoButton, details);
	}

	@Override
	public Stage getStage() {
		return this.stage;
	}

	@Override
	public void showWarningToast(String message) {
		toaster.makeWarningToast(message);

	}





}
