package view;

import interfaces_abstractions.AbstractPopup;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.util.Callback;
import javafx.util.StringConverter;
import spatialAndTemporalElements.PatchTemplate;
import spatialAndTemporalElements.PatchTransitionsTemplate;
import spatialAndTemporalElements.PatchTransitionsTemplate.TransitionRow;
import start.Console;

public class PopupPatchTravel extends AbstractPopup {

	@FXML public TableView<TransitionRow> tableView;
	@FXML public TableColumn<TransitionRow, String> tableColumnOriginNames;
	private final PatchTransitionsTemplate patchTransitions;

	// Rather than showing 'true' and 'false', we'll use these labels
	public static final String trueString = "Yes";
	public static final String falseString = "No";

	public PopupPatchTravel(PatchTransitionsTemplate patchTransitions){
		super("fxml_popupPatchTravel.fxml", View.getView().getPaneCenterX(), View.getView().getPaneCenterY(), true);

		this.patchTransitions = patchTransitions;

		// Set the nodes
		setNodes();

		// Set the values in the nodes
		update();

		Console.print("Opened a new Popup window for Patch transitions: \n" + patchTransitions);
	}
	@Override
	public void setNodes() {
		// Set the column that shows names
		// Set the CellValueFactory: this factory determines what should be shown.
		// In this case the name of the origin
		tableColumnOriginNames.setCellValueFactory(
				new Callback<CellDataFeatures<TransitionRow, String>, ObservableValue<String>>(){
					@Override
					public ObservableValue<String> call(CellDataFeatures<TransitionRow, String> t) {
						return new SimpleStringProperty(t.getValue().origin.getName());

					}
				});
		tableColumnOriginNames.setStyle("rowNames");

		// Rescale the TableView so that we don't have to look at those unused rows
		tableView.setEditable(true);
		tableView.setFixedCellSize(25);
		tableView.prefHeightProperty().bind(Bindings.size(tableView.getItems()).multiply(tableView.getFixedCellSize()).add(26));

		// Create and add a new column for each destination.
		// This column should show the name of the destination on the header,
		// and show the transitions as comboboxes, from which a user can select a yes or no 
		// Tell Java how to go from a DecimalNumber to a string.
		for (PatchTemplate destination : patchTransitions.getOrderedPatches()){
			TableColumn<TransitionRow, Boolean> destinationColumn = new TableColumn<>(destination.getName());

			// Set the CellValueFactory: this factory determines which Boolean should be shown.
			destinationColumn.setCellValueFactory(
					new Callback<CellDataFeatures<TransitionRow, Boolean>, ObservableValue<Boolean>>(){
						@Override
						public ObservableValue<Boolean> call(CellDataFeatures<TransitionRow, Boolean> t) {
							boolean canTravel = patchTransitions.canTravel(t.getValue().origin, destination);
							if (t.getValue().origin == destination)
								return null;
							return new SimpleObjectProperty<>(	canTravel);
						}
					});

			// Tell Java how to go from a Boolean to a string.
			destinationColumn.setCellFactory(ComboBoxTableCell.forTableColumn(
					new CustomBooleanConverter(),
					FXCollections.observableArrayList(new Boolean(true), new Boolean(false))));
		
			// Tell java how to handle the changes
			destinationColumn.setOnEditCommit(
					new EventHandler<TableColumn.CellEditEvent<TransitionRow, Boolean>>() {
						@Override
						public void handle(CellEditEvent<TransitionRow, Boolean> t) {
							// Find origin (we already know the destination when creating this column)
							PatchTemplate origin = t.getRowValue().origin;
							
							// Set the new value
							if (origin != destination)
								patchTransitions.setPath(origin, destination, t.getNewValue());
							else {
								patchTransitions.setPath(origin, destination, false);
							}
							t.getTableView().refresh();
						}});
						// Add the column to the tableView
			tableView.getColumns().add(destinationColumn);
		}
		
		// Set the width of the table 
		double totalWidth = 0;

		for (TableColumn<TransitionRow, ?> tc : tableView.getColumns()){
			totalWidth += tc.getWidth();
			tableView.widthProperty().add(tc.widthProperty());
		}
		
		tableView.setMinWidth(totalWidth);
		tableView.setMaxWidth(totalWidth);
	}

	@Override
	public void update() {
		tableView.getItems().removeAll(tableView.getItems());
		tableView.getItems().addAll(patchTransitions.toRows());

	}


	/** A class to use when converting boolean values to 'yes' and '-' */
	public class CustomBooleanConverter extends StringConverter<Boolean>{

		@Override
		public Boolean fromString(String s) {
			if (s.equals(falseString))
				return new Boolean(false);
			return new Boolean(true);
		}

		@Override
		public String toString(Boolean b) {
			if (b == null)
				return "";
			if (b.booleanValue())
				return trueString;
			return falseString;
		}

	}

	public class CustomComboBoxTableCell extends ComboBoxTableCell<TransitionRow, Boolean> {

		@Override
		public void updateItem(Boolean item, boolean empty){
			super.updateItem(item, empty);
			if (item == null)
				this.setDisable(true);

		}


	}


}
