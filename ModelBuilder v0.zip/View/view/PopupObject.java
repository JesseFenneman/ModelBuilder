package view;

import java.util.ArrayList;
import java.util.HashMap;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import attributes.AttributeField;
import decimalNumber.DecimalNumber;
import interfaces_abstractions.AbstractPopup;
import interfaces_abstractions.LayoutManager;
import interfaces_abstractions.ObserverManager;
import javafx.beans.binding.Bindings;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.AbstractObjectiveTemplateFactory;
import objectiveElements.CueLabel;
import objectiveElements.CueTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import rIntegration.RFunction;
import rIntegration.RFunctionContainer;
import rIntegration.RFunctionContainer.UnknownArgumentException;
import rIntegration.RManager;
import start.Console;

public class PopupObject extends AbstractPopup{

	// FXML elements for the Title section
	@FXML public Label 		labelTitle;
	@FXML public TextField 	textFieldName, textFieldType, textFieldFrequency;
	@FXML public Button		buttonDelete;
	@FXML public GridPane 	gridPaneFrequency,gridPaneDelete;

	// FXML elements for domain
	@FXML public Label		labelDomain;
	@FXML public RadioButton radioButtonDomainFixed, radioButtonDomainRange;
	@FXML public VBox 		vboxDomain;
	@FXML public TextField	textFieldDomainFixed, textFieldDomainRangeMinimum, textFieldDomainRangeMaximum, textFieldDomainRangeStepsize;
	@FXML public GridPane 	gridPaneDomainFixed, gridPaneDomainRange;

	// FXML elements for Observability
	@FXML public Label		labelObservatbility;
	@FXML public RadioButton radioButtonObservabilityYes, radioButtonObservabilityNo, radioButtonCueYes, radioButtonCueNo;
	@FXML public VBox 		vboxObservability;
	@FXML public GridPane	gridPaneCueOptions;
	@FXML public ToggleButton 	toggleButtonSetCue;

	// FXML elements for Values
	@FXML public Label		labelValues;
	@FXML public RadioButton radioButtonValuesYes, radioButtonValuesNo;
	@FXML public VBox 		vboxValues,vboxValueArguments;
	@FXML public ComboBox<RFunction>	comboBoxValueFunction;

	//FXML elements for apply changes
	@FXML public Button 	buttonApplyChanges;

	//FXML elements for the cue side panel
	@FXML public VBox 		vboxCueSidePanel, vboxCueArguments;
	@FXML public ListView<CueLabel> 	listViewCueLabels;
	@FXML public TextField	textFieldCueLabelName;
	@FXML public Button		buttonRemoveCueLabel, buttonAddCueLabel;
	@FXML public ComboBox<RFunction>	comboBoxCueFunction;
	@FXML public TextField	textFieldCueMaximumNumber;


	// This popup can be summoned to create a new AbstractObjectiveTemplate or modify an existing one.
	AbstractObjectiveTemplate object;
	Class<? extends AbstractObjectiveTemplate> type;

	// A map that connects the name of an attribute to the TextField
	HashMap<String, TextField> valueArgumentNameToTextFieldMap = new HashMap<>();
	HashMap<String, TextField> cueArgumentNameToTextFieldMap = new HashMap<>();

	/** Constructor when calling this field to make a new Object*/
	public PopupObject(MouseEvent e, Class<? extends AbstractObjectiveTemplate> type){
		this(e, type, null);
		labelTitle.setText("Adding a new object");
		buttonApplyChanges.setText("Add new object");
		gridPaneDelete.setVisible(false);
		gridPaneDelete.setManaged(false);
	}

	/** Constructor when calling this field to change an existing object*/
	public PopupObject(MouseEvent e, AbstractObjectiveTemplate existingObject){
		this(e, AbstractObjectiveTemplate.objectToClass(existingObject), existingObject);
		labelTitle.setText("Modifying an existing object");
		buttonApplyChanges.setText("Apply changes");
		gridPaneDelete.setVisible(true);
		gridPaneDelete.setManaged(true);
		buttonDelete.setOnAction(event -> {
			if (View.getView().deleteObject(existingObject));
			close();
		});
	}

	/** Main constructor*/
	private PopupObject(MouseEvent e, Class<? extends AbstractObjectiveTemplate> type, AbstractObjectiveTemplate existingObject){
		super("fxml_popupAddOrModifyObject.fxml", e, true);

		this.object = existingObject;
		this.type = type;

		setNodes();

		// If this window is called to modify an existing object, load all nodes with the correct values.
		update();
		
		// Register all textfields as 'not changed' (they have changed after the update, but that doesn't really count as a change)
		setAllTextFieldsToNormal();
		
		Console.print("Opened a new Popup window for object: " + object);
	}

	@Override
	public void setNodes() {
		setVisibilityMechanics();

		// Set the Frequency field
		LayoutManager.setLayoutHandler(textFieldFrequency, FieldRestriction.PROBABILITY);
		if (this.type == InterruptionObjectTemplate.class || this.type == PhenotypeObjectTemplate.class){
			gridPaneFrequency.setVisible(false);
			gridPaneFrequency.setManaged(false);
		}

		// Set the Type field
		textFieldType.setText(AbstractObjectiveTemplate.classToClassString(type));

		// Only variable names are allowed as names
		LayoutManager.setLayoutHandler(textFieldName, FieldRestriction.VARIABLE_NAME);

		// Set the FieldRestriction on the domains
		LayoutManager.setLayoutHandler(textFieldDomainFixed, AbstractObjectiveTemplate.getDomainFieldRestriction(type) );
		LayoutManager.setLayoutHandler(textFieldDomainRangeMinimum, AbstractObjectiveTemplate.getDomainFieldRestriction(type) );
		LayoutManager.setLayoutHandler(textFieldDomainRangeMaximum, AbstractObjectiveTemplate.getDomainFieldRestriction(type) );
		if (this.type == DelayObjectTemplate.class)
			LayoutManager.setLayoutHandler(textFieldDomainRangeStepsize, FieldRestriction.POSITIVE_INTEGER );
		else
			LayoutManager.setLayoutHandler(textFieldDomainRangeStepsize, FieldRestriction.POSITIVE_DOUBLE );

		// Set both of the comboboxes for function
		setComboBoxMechanics();

		// Set the slide window that appears when the set cue button is pressed
		setCueMechanics();

		// Set the behavior of the buttonApplyChanges
		buttonApplyChanges.setOnAction(e -> { 
			try {
				if (this.object == null) {
					AbstractObjectiveTemplate ob = this.createObjectBasedOnInput();
					if (ob != null) {
						View.getView().addObject(ob);
						this.close();
					}
				} else
					changeExistingObject();
			} catch (Exception e1) {ObserverManager.notifyObserversOfError(e1);}
		});

	}

	
	/** Sets the dynamics of visibility: what should be visible when which options are selected?*/
	private void setVisibilityMechanics(){
		
		// For non-interruption objects: hide everything when there is no name yet (for interruptions: always hide the vboxDomain)
		if (type != InterruptionObjectTemplate.class) {
			vboxDomain.visibleProperty().bind(Bindings.lessThan(0, Bindings.length(textFieldName.textProperty())));
			vboxDomain.managedProperty().bind(Bindings.lessThan(0, Bindings.length(textFieldName.textProperty())));
		} else {
			vboxDomain.setManaged(false);
			vboxDomain.setVisible(false);

		}
		// Set the names in the labels
		labelDomain.textProperty().bind(Bindings.concat("Domain: can a " , textFieldName.textProperty() , " have more than one value?"));
		labelObservatbility.textProperty().bind(Bindings.concat("Observability: does an agent know the value of a " , textFieldName.textProperty() , "?"));
		labelValues.textProperty().bind(Bindings.concat("Values: how are " , textFieldName.textProperty() , " values distributed?"));


		// Domain: fixed versus ranges should provide a single, or three TextFields, respectively
		// Never visible for interruptions
		if (type == InterruptionObjectTemplate.class) {
			gridPaneDomainFixed.setManaged(false);
			gridPaneDomainFixed.setVisible(false);

			gridPaneDomainRange.setManaged(false);
			gridPaneDomainRange.setVisible(false);
		} else {

			gridPaneDomainFixed.managedProperty().bind(this.radioButtonDomainFixed.selectedProperty());
			gridPaneDomainFixed.visibleProperty().bind(this.radioButtonDomainFixed.selectedProperty());

			gridPaneDomainRange.managedProperty().bind(this.radioButtonDomainRange.selectedProperty());
			gridPaneDomainRange.visibleProperty().bind(this.radioButtonDomainRange.selectedProperty());
		}

		// A phenotype object has no observability, value, or cue - so we do not have to show these fields at all
		if (this.type == PhenotypeObjectTemplate.class){
			vboxObservability.setManaged(false);
			vboxObservability.setVisible(false);
			vboxValues.setManaged(false);
			vboxValues.setVisible(false);
			vboxCueSidePanel.setVisible(false);
			vboxCueSidePanel.setManaged(false);
			return;
		} 

		// Should always show observability and values for interruptions.
		else if (type == InterruptionObjectTemplate.class) {
		
			vboxObservability.setManaged(true);
			vboxObservability.setVisible(true);

			vboxValues.setManaged(true);
			vboxValues.setVisible(true);
		} 

		// For all other types (resource, extrinsic, delay): don't have to show the observability and value sections if there is only one value
		else {
			vboxObservability.managedProperty().bind(radioButtonDomainRange.selectedProperty());
			vboxObservability.visibleProperty().bind(radioButtonDomainRange.selectedProperty());

			vboxValues.managedProperty().bind(radioButtonDomainRange.selectedProperty());
			vboxValues.visibleProperty().bind(radioButtonDomainRange.selectedProperty());
		}

		// Observability: Show the cue row only when the agent has beliefs
		gridPaneCueOptions.managedProperty().bind(this.radioButtonObservabilityNo.selectedProperty());
		gridPaneCueOptions.visibleProperty().bind(this.radioButtonObservabilityNo.selectedProperty());

		// Set cue button only visible when there are cues
		toggleButtonSetCue.visibleProperty().bind(radioButtonCueYes.selectedProperty());

		// The vboxCueSidePanel is only visible when the toggleButtonSetCue is active
		vboxCueSidePanel.visibleProperty().bind(Bindings.and(toggleButtonSetCue.selectedProperty(), radioButtonDomainRange.selectedProperty()));
		vboxCueSidePanel.managedProperty().bind(Bindings.and(toggleButtonSetCue.selectedProperty(), radioButtonDomainRange.selectedProperty()));
		
		// The toggleButtonSetCue should be set to inactive if the radioButtonCueNo is selected
		radioButtonCueNo.selectedProperty().addListener((observable, newValue, oldValue) -> {
			if (!newValue)
				toggleButtonSetCue.setSelected(false);
		});
		
		// Same for radioButtonObservabilityYes: the toggleButtonSetCue should be set to inactive if the radioButtonObservabilityYes is selected
		radioButtonObservabilityYes.selectedProperty().addListener((observable, newValue, oldValue) -> {
			if (!newValue)
				toggleButtonSetCue.setSelected(false);
		});
		

	}

	/** Set the behavior of the comboboxes, and what fields appear when selecting a function*/
	private void setComboBoxMechanics(){
		Callback<ListView<RFunction>, ListCell<RFunction>> cellFactory = new Callback<ListView<RFunction>,ListCell<RFunction>>(){
			@Override
			public ListCell<RFunction> call(ListView<RFunction> arg0) {
				return new ListCell<RFunction>(){
					@Override public void updateItem(RFunction item, boolean empty){
						super.updateItem(item,empty);
						if (item == null) return;
						ArrayList<AttributeField> arguments = item.getInputFieldCopy();

						StringBuilder sb = new StringBuilder();
						sb.append(item.getName() + "   (" + arguments.size() + " arguments: ");
						for (int i = 0; i < arguments.size(); i++){
							sb.append(arguments.get(i).getName());
							if (i != arguments.size()-1)
								sb.append(", ");
						}
						sb.append(")");
						this.setText(sb.toString());
					}
				};
			}};
			ArrayList<RFunction> includedFunctions = new ArrayList<>();
			ArrayList<RFunction> functionWithCorrectTag = RManager.getAllRFunctionsWithTag("DOMAINFUNCTION");
			for (RFunction rf: functionWithCorrectTag)
				includedFunctions.add(rf);
			
			comboBoxValueFunction.setButtonCell(cellFactory.call(null));
			comboBoxValueFunction.setCellFactory(cellFactory);
			
			comboBoxValueFunction.getItems().addAll(includedFunctions);
			comboBoxCueFunction.setButtonCell(cellFactory.call(null));
			comboBoxCueFunction.setCellFactory(cellFactory);
			comboBoxCueFunction.getItems().addAll(includedFunctions);

			comboBoxValueFunction.getSelectionModel().selectedItemProperty().addListener(
					(observable, oldValue, newValue) -> {
						if (newValue != null){
							addFunctionArgumentsToVBox(comboBoxValueFunction.getSelectionModel().getSelectedItem(), vboxValueArguments, radioButtonValuesNo.isSelected() );
							vboxValueArguments.setVisible(true);
							vboxValueArguments.setManaged(true);
						}else {
							vboxValueArguments.setVisible(false);
							vboxValueArguments.setManaged(false);
						}});
			radioButtonValuesNo.selectedProperty().addListener(e -> {
				if (vboxValueArguments.isVisible())
					addFunctionArgumentsToVBox(comboBoxValueFunction.getSelectionModel().getSelectedItem(), vboxValueArguments, radioButtonValuesNo.isSelected() );			});

			comboBoxCueFunction.getSelectionModel().selectedItemProperty().addListener(
					(observable, oldValue, newValue) -> {
						if (newValue != null){
							addFunctionArgumentsToVBox(comboBoxCueFunction.getSelectionModel().getSelectedItem(), vboxCueArguments, false );
							vboxCueArguments.setVisible(true);
							vboxCueArguments.setManaged(true);
						}else {
							vboxCueArguments.setVisible(false);
							vboxCueArguments.setManaged(false);
						}});
	}

	/** Set all the mechanics in the cue popup slide */
	private void setCueMechanics(){
		// In the textFieldCueMaximumNumber only positive integers are allowed
		LayoutManager.setLayoutHandler(textFieldCueMaximumNumber, FieldRestriction.POSITIVE_DOUBLE);
		
		// Set a cell factory for the ListView
		Callback<ListView<CueLabel>, ListCell<CueLabel>> cellFactory = new Callback<ListView<CueLabel>,ListCell<CueLabel>>(){
			@Override
			public ListCell<CueLabel> call(ListView<CueLabel> arg0) {
				return new ListCell<CueLabel>(){
					@Override public void updateItem(CueLabel cl, boolean empty){
						super.updateItem(cl,empty);
						if (cl == null) {setText(null); setGraphic(null); return;}


						ArrayList<AttributeField> arguments = cl.functionContainer.getLoadedArguments();

						StringBuilder sb = new StringBuilder();
						sb.append(cl.name + "   ("+cl.functionContainer.getRFunction().getName()+" with ");

						for (int i = 0; i < arguments.size(); i++){
							sb.append(arguments.get(i).getName().toUpperCase() + "="+arguments.get(i).getValueStringWithoutTrailingZeros());
							if (i != arguments.size()-1)
								sb.append(", ");
						}
						sb.append(")");
						this.setText(sb.toString());
					}
				};
			}};
			listViewCueLabels.setCellFactory(cellFactory);

			buttonRemoveCueLabel.setOnAction(e -> {
				if (listViewCueLabels.getSelectionModel().getSelectedItem() != null)
					listViewCueLabels.getItems().remove(listViewCueLabels.getSelectionModel().getSelectedItem());
			});

			LayoutManager.setLayoutHandler(textFieldCueLabelName, FieldRestriction.VARIABLE_NAME);

			buttonAddCueLabel.setOnAction(e -> {
				// First, check if the name is correct:
				if (LayoutManager.isInvalid(textFieldCueLabelName)){
					View.getView().showWarningToast("Cannot add cue label. Please add a correct label name. Names should adhere to R's convention for variable names: do not start with numbers, do not include space.");
					return;
				}
				String name = textFieldCueLabelName.getText();

				// Second: check if there is a selected function
				RFunction selectedFunction = comboBoxCueFunction.getSelectionModel().getSelectedItem();
				if (selectedFunction == null){
					View.getView().showWarningToast("Cannot add cue label. Please select a function first.");
					return;
				}

				// Make a list of all argument text fields
				ArrayList<TextField> tfs = new ArrayList<>();
				ArrayList<String> argumentNames = new ArrayList<>();
				for (Node gp: vboxCueArguments.getChildren())
					if (gp instanceof GridPane) {

						GridPane container = (GridPane) gp;
						// Find the textField
						TextField foundField = null;
						for (Node n: container.getChildren() )
							if (n instanceof TextField)
								foundField = (TextField) n;

						// If there is a TextField: find the corresponding name
						String argName = null;
						if (foundField != null)
							for (Node n: container.getChildren())
								if (n instanceof Label)
									argName = ((Label)n).getText();

						// If something is found: store both name and textField
						tfs.add(foundField);
						
						// The name might have a ":" at the end - remove t
						argumentNames.add(argName.replace(":", ""));
					}

				// Make sure all text fields have been filled in correctly.
				// If they are, make a AttributeField
				ArrayList<AttributeField> arguments = new ArrayList<>();
				for (int i = 0; i < tfs.size(); i++){
					if (LayoutManager.isInvalid(tfs.get(i))){
						View.getView().showWarningToast("Cannot add label, as the " + argumentNames.get(i) + " argument is invalid. Please, only enter " + selectedFunction.getInputFieldCopy().get(i).getFieldRestriction()+ " values." );
						return;
					}
					try {
						arguments.add(new AttributeField(argumentNames.get(i), new DecimalNumber(tfs.get(i).getText())));
					} catch (RestrictionViolationException ex) { ObserverManager.notifyObserversOfError(ex);}
				}

				// Create a new CueLabel and add it to the listview
				try {
					listViewCueLabels.getItems().add(new CueLabel(
							name, 
							new RFunctionContainer(selectedFunction, arguments)));
				} catch (RestrictionViolationException | UnknownArgumentException e1) {ObserverManager.notifyObserversOfError(e1);}
				listViewCueLabels.getSelectionModel().select(null);
				View.getView().showToast("Label added succesfully.");

				// Reset all UI elements
				textFieldCueLabelName.setText("");
				comboBoxCueFunction.getSelectionModel().select(null);

				vboxCueArguments.getChildren().removeAll(vboxCueArguments.getChildren());
				vboxCueArguments.setVisible(true);
				vboxCueArguments.setManaged(true);

			});
	}


	/**When selecting a function type, the correct arguments for that function have to be shown.
	 * Because we have two function selectors, here is a function that sets them both. When
	 * multipleFunction is true, that means that the user has specified that he/she wants to
	 * to use multiple distributions, which will be run over multiple models.
	 *
	 * If multipleFunction is false, we only have to set one TextField for each argument (keeping
	 * the correct FieldRestriction in mind).
	 *
	 * If multipleFunction is true, we have to set three TextFields for each argument, for the
	 * minimum, maximum, and stepsize, respectively (keeping the correct FieldRestrictions in mind)
	 *
	 * Also sets the valueArgumentNameToTextFieldMap and cueArgumentNameToTextFieldMap
	 * For each argument this function creates a GridPane to store the TextFields in.*/
	private void addFunctionArgumentsToVBox(RFunction rf, VBox box, boolean multipleFunction){
		// Remove pre existing
		box.getChildren().removeAll(box.getChildren());
		HashMap<String, TextField> nameToTextFieldMap = null;
		if (box == this.vboxValueArguments)
			nameToTextFieldMap = valueArgumentNameToTextFieldMap;
		else if (box == this.vboxCueArguments)
			nameToTextFieldMap = cueArgumentNameToTextFieldMap;
		nameToTextFieldMap.clear();
		
		if (rf == null)
			return;
		for (AttributeField af: rf.getInputFieldCopy()){
			// can skip the domain - we already have that
			if (!af.getName().equalsIgnoreCase("domain")){
				GridPane newGrid = new GridPane();
				newGrid.setMinHeight(30);
				newGrid.setMaxHeight(30);
				newGrid.setMaxWidth(box.getWidth());
				newGrid.setMinWidth(box.getWidth());

				// If only one value for the argument is required:
				if (!multipleFunction){
					// Only need two columns
					ColumnConstraints leftCol = new ColumnConstraints(140);
			        ColumnConstraints rightCol = new ColumnConstraints(220);
			        newGrid.getColumnConstraints().addAll(leftCol, rightCol);


					// Create the label for the field name
					Label labelName = new Label(af.getName().substring(0, 1).toUpperCase() +af.getName().substring(1).toLowerCase()+":");
					labelName.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupLabel.css").toExternalForm());
					labelName.getStyleClass().add("fieldName");

					// Create the TextField (and make sure to add the correct FieldRestriction)
					TextField textFieldArgument= new TextField();
					textFieldArgument.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupTextField.css").toExternalForm());
					LayoutManager.setLayoutHandler(textFieldArgument, af.getFieldRestriction());
					textFieldArgument.setPromptText("Only " + (af.getFieldRestriction()).toString().toUpperCase().replace("_", " ") + " are allowed.");

					// Keep a record of the argument name and text field
					nameToTextFieldMap.put(af.getName(), textFieldArgument);

					// Add and set Margins
			        newGrid.addRow(0, labelName, textFieldArgument);
					GridPane.setMargin(labelName, new Insets(0,0,0,10));
				} else {
					//Need three fields each!
					ColumnConstraints col0 = new ColumnConstraints(10);
					ColumnConstraints col1 = new ColumnConstraints(70);
					ColumnConstraints col2 = new ColumnConstraints(65);
			        ColumnConstraints col3 = new ColumnConstraints(30);
			        ColumnConstraints col4 = new ColumnConstraints(65);
			        ColumnConstraints col5 = new ColumnConstraints(65);
			        ColumnConstraints col6 = new ColumnConstraints(65);

			        newGrid.getColumnConstraints().addAll(col0, col1, col2, col3, col4, col5, col6);


					// Create the labels: from, to, and stepsize
			        Label empty = new Label("");
					Label labelFrom = new Label(af.getName().substring(0, 1).toUpperCase() +af.getName().substring(1).toLowerCase()+": ");
					labelFrom.setWrapText(true);
					labelFrom.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupLabel.css").toExternalForm());
					labelFrom.getStyleClass().add("fieldName");

					Label labelTo = new Label(" to ");
					labelTo.setWrapText(true);
					labelTo.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupLabel.css").toExternalForm());
					labelTo.getStyleClass().add("fieldName");

					Label labelStep = new Label(" with steps of ");
					labelStep.setWrapText(true);
					labelStep.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupLabel.css").toExternalForm());
					labelStep.getStyleClass().add("fieldName");

					// Create the TextFields (and make sure to add the correct FieldRestriction)
					TextField textFieldFrom = new TextField();
					textFieldFrom.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupTextField.css").toExternalForm());
					LayoutManager.setLayoutHandler(textFieldFrom, af.getFieldRestriction());
					textFieldFrom.setPromptText(af.getFieldRestriction().toString().toUpperCase().replace("_", " "));

					TextField textFieldTo = new TextField();
					textFieldTo.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupTextField.css").toExternalForm());
					LayoutManager.setLayoutHandler(textFieldTo, af.getFieldRestriction());
					textFieldTo.setPromptText(af.getFieldRestriction().toString().toUpperCase().replace("_", " "));

					TextField textFieldStep = new TextField();
					textFieldStep.getStylesheets().add(this.getClass().getResource("../CSSLayout/popupTextField.css").toExternalForm());
					LayoutManager.setLayoutHandler(textFieldStep, FieldRestriction.POSITIVE_DOUBLE);
					textFieldStep.setPromptText(FieldRestriction.POSITIVE_DOUBLE.toString().toUpperCase().replace("_", " "));

					// Keep a recond
					nameToTextFieldMap.put(af.getName()+"From", textFieldFrom);
					nameToTextFieldMap.put(af.getName()+"To", textFieldTo);
					nameToTextFieldMap.put(af.getName()+"StepSize", textFieldStep);

					// Add
			        newGrid.addRow(0, empty, labelFrom, textFieldFrom, labelTo, textFieldTo, labelStep, textFieldStep);

				}
				box.getChildren().add(newGrid);
			}
			}


	}

	/** Sets all TextFields as 'normal' rather than 'changed'. Should be used after loading an existing object to the popup*/
	private void setAllTextFieldsToNormal(){
		LayoutManager.setProcessed(textFieldName);
		LayoutManager.setProcessed(textFieldFrequency);
		
		LayoutManager.setProcessed(textFieldDomainFixed);
		LayoutManager.setProcessed(textFieldDomainRangeMinimum);
		LayoutManager.setProcessed(textFieldDomainRangeMaximum);
		LayoutManager.setProcessed(textFieldDomainRangeStepsize);
		
		for (TextField tf: valueArgumentNameToTextFieldMap.values())
			LayoutManager.setProcessed(tf);
		for (TextField tf: cueArgumentNameToTextFieldMap.values())
			LayoutManager.setProcessed(tf);
	}
	
	
	/** Changes all fields to match the Object that this popup is summoned to change. If object is null,
	 * nothing happens.*/
	@Override
	public void update() {
		if (object == null)
			return;

		textFieldName.setText(object.getName());
		if (object.getFrequency() != null)
			textFieldFrequency.setText(object.getFrequency().toStringWithoutTrailingZeros());
		
		// Set all the UI elements to match the object
		// Domain
		if (object.isConstant()){
			radioButtonDomainFixed.setSelected(true);
			textFieldDomainFixed.setText(object.getDomain().get(0).toStringWithoutTrailingZeros());
			return;
		} else {
			radioButtonDomainRange.setSelected(true);
			textFieldDomainRangeMinimum.setText(object.getDomainMinimum().toStringWithoutTrailingZeros());
			textFieldDomainRangeMaximum.setText(object.getDomainMaximum().toStringWithoutTrailingZeros());
			textFieldDomainRangeStepsize.setText(object.getDomainStepSize().toStringWithoutTrailingZeros());
		}
		
		// A phenotype has no observability, values, or cues; we are done here
		if ( type == PhenotypeObjectTemplate.class)
			return;

		// Observability

		if (object.isObservable())
			radioButtonObservabilityYes.setSelected(true);
		else{
			radioButtonObservabilityNo.setSelected(true);
			if (object.getCueTemplate() == null)
				radioButtonCueNo.setSelected(true);
			else {
				radioButtonCueYes.setSelected(true);
				toggleButtonSetCue.setSelected(true);
				listViewCueLabels.getItems().addAll(object.getCueTemplate().cueLabels);
				textFieldCueMaximumNumber.setText(""+object.getCueTemplate().maximumNumberOfCuesAnAgentCanSample);
			}
		}

		// Values
		if (object.useOneDistribution())
			radioButtonValuesYes.setSelected(true);
		 else 
			 radioButtonValuesNo.setSelected(true);
		
		// Set function
		RFunction functionInBox = null;
		RFunction functionInObject = null;
		if (object.useOneDistribution())
			functionInObject = object.getSamplingDistribution().getRFunction();
		else
			functionInObject = object.getPreviousRuntimeParameterFunction();
		
		for (RFunction rf: comboBoxValueFunction.getItems())
			if (rf.getName().equals(functionInObject.getName())){
				// Set the function in the combobox
				functionInBox = rf;
			}
		
		if (functionInBox == null){
			View.getView().showWarningToast("Warning: existing sampling distributions uses unknown function. Reverting to null.");
			return;
		}
		comboBoxValueFunction.getSelectionModel().select(functionInBox);

		// Set the textfields
		if (object.useOneDistribution()){
			for (AttributeField af: object.getSamplingDistribution().getLoadedArguments())
				if (!af.getName().equalsIgnoreCase("domain")){
					valueArgumentNameToTextFieldMap.get(af.getName()).setText(af.getValueStringWithoutTrailingZeros());
				}
		} else {
			ArrayList<AttributeField[]> lastUsedInputs = object.getPreviousRuntimeParameters();
			int indexInLastUsed = 0;

			for (AttributeField af: object.getPreviousRuntimeParameterFunction().getInputFieldCopy())
				if (!af.getName().equalsIgnoreCase("domain")){
					valueArgumentNameToTextFieldMap.get(af.getName()+ "From")    .setText(lastUsedInputs.get(indexInLastUsed)[0].getValueStringWithoutTrailingZeros());
					valueArgumentNameToTextFieldMap.get(af.getName()+ "To")      .setText(lastUsedInputs.get(indexInLastUsed)[1].getValueStringWithoutTrailingZeros());
					valueArgumentNameToTextFieldMap.get(af.getName()+ "StepSize").setText(lastUsedInputs.get(indexInLastUsed)[2].getValueStringWithoutTrailingZeros());
					indexInLastUsed++;
				}
		}
	}

	/** Checks if all fields have permissible values. If not, pops off a warning toast and returns false.*/
	private boolean validateInput(){
		if (LayoutManager.isInvalid(textFieldName)){
			ObserverManager.makeWarningToast("Please enter a valid object name. Names should follow R's convention for variable names: no starting with numbers, no space.");
			return false;
		}
		
		if (gridPaneFrequency.isVisible() && LayoutManager.isInvalid(textFieldFrequency)){
			ObserverManager.makeWarningToast("Please enter a valid frequency. Frequences have to be within 0 and 1.");
			return false;
		}
	
		if (gridPaneDomainFixed.isVisible() && LayoutManager.isInvalid(textFieldDomainFixed)){
			ObserverManager.makeWarningToast("Please enter a valid fixed value.");
			return false;
		}
		
		if (gridPaneDomainRange.isVisible() && LayoutManager.isInvalid(textFieldDomainRangeMinimum)){
			ObserverManager.makeWarningToast("Please enter a valid minimum domain value.");
			return false;
		}
		if (gridPaneDomainRange.isVisible() && LayoutManager.isInvalid(textFieldDomainRangeMaximum)){
			ObserverManager.makeWarningToast("Please enter a valid maximum domain value.");
			return false;
		}
		if (gridPaneDomainRange.isVisible() && new DecimalNumber(textFieldDomainRangeMaximum.getText()).smallerThanOrEqualTo( new DecimalNumber(textFieldDomainRangeMinimum.getText()))) {
			ObserverManager.makeWarningToast("The maximum domain value cannot be smaller than the minimum domain value.");
			return false;
		}
		if (gridPaneDomainRange.isVisible() && LayoutManager.isInvalid(textFieldDomainRangeStepsize)){
			ObserverManager.makeWarningToast("Please enter a valid domain step size value.");
			return false;
		}

		if (radioButtonCueYes.isSelected() && listViewCueLabels.getItems().size() <= 1){
			ObserverManager.makeWarningToast("Either turn off cues or set at least two cue labels.");
			return false;
		}
		
		if (radioButtonCueYes.isSelected() && LayoutManager.isInvalid(textFieldCueMaximumNumber)){
			ObserverManager.makeWarningToast("Please add a positive (>0) number of cues an agent can maximally sample"); 
			return false;
		}
					
		
		if (vboxValues.isVisible() && comboBoxValueFunction.getSelectionModel().isEmpty()){
			ObserverManager.makeWarningToast("Please select a value distribution.");
			return false;
		}
		
		for (String key: this.valueArgumentNameToTextFieldMap.keySet()){
			TextField tf = valueArgumentNameToTextFieldMap.get(key);
			if (LayoutManager.isInvalid(tf)){
				ObserverManager.makeWarningToast("Please enter a valid value for " + key);
				return false;
			}
		}
		
			
		return true;
	}
	
	/** Creates a new AbstractObjectiveTemplate with the values as specified by all the popup fields 
	 * @throws RestrictionViolationException */
	public AbstractObjectiveTemplate createObjectBasedOnInput() throws RestrictionViolationException{
		// First, check if all inputs are valid (i.e., no red text fields)
		boolean isValidInput = validateInput();

		if (!isValidInput)
			return null;

		AbstractObjectiveTemplateFactory factory = new AbstractObjectiveTemplateFactory();
		
		// Set name 
		factory.setName(textFieldName.getText());
		factory.setType(type);
		if (type != InterruptionObjectTemplate.class && type != PhenotypeObjectTemplate.class)
			factory.setFrequency(new DecimalNumber(textFieldFrequency.getText()));
		if (radioButtonDomainFixed.isSelected() && type != InterruptionObjectTemplate.class )
			factory.setConstant(new DecimalNumber(textFieldDomainFixed.getText()));

		// If more than one value: set domain, observability, and values
		if (radioButtonDomainRange.isSelected() || type == InterruptionObjectTemplate.class ){
			
			if (type != InterruptionObjectTemplate.class )
				factory.setRange(new DecimalNumber(textFieldDomainRangeMinimum.getText()), new DecimalNumber(textFieldDomainRangeMaximum.getText()), new DecimalNumber(textFieldDomainRangeStepsize.getText()));
			if (type == InterruptionObjectTemplate.class )
				factory.setRange(new DecimalNumber(0), new DecimalNumber(1), new DecimalNumber(1));
			
			// observability and cue
			if (radioButtonObservabilityYes.isSelected())
				factory.setObservability(true);

			if (radioButtonObservabilityNo.isSelected()){
				factory.setObservability(false);
				if (radioButtonCueYes.isSelected()){
					CueTemplate cue = new CueTemplate();
					cue.cueLabels = new ArrayList<>();
					cue.cueLabels.addAll(listViewCueLabels.getItems());
					cue.maximumNumberOfCuesAnAgentCanSample = Integer.parseInt(this.textFieldCueMaximumNumber.getText());
					factory.setCueTemplate(cue);
				}
			}
			
			
			// 1 sampling distribution
			if (radioButtonValuesYes.isSelected() &&  type != PhenotypeObjectTemplate.class){
				RFunction rf = comboBoxValueFunction.getValue();
				ArrayList<AttributeField> args = new ArrayList<>();
				ArrayList<AttributeField> requiredArgs = rf.getInputFieldCopy();
				
				for (int i = 0; i < requiredArgs.size(); i++){
					for (String key: this.valueArgumentNameToTextFieldMap.keySet())
						if (requiredArgs.get(i).getName().equals(key))
							args.add(new AttributeField(key, new DecimalNumber(valueArgumentNameToTextFieldMap.get(key).getText())));
								
				}
				try {
					factory.setSingleSamplingDistribution(new RFunctionContainer(rf, args.toArray(new AttributeField[args.size()])));
				} catch (UnknownArgumentException e) {ObserverManager.notifyObserversOfError(e);}
			}
			
			// Multiple distributions
			if (radioButtonValuesNo.isSelected() && type != PhenotypeObjectTemplate.class){
				RFunction rf = comboBoxValueFunction.getValue();
				
				ArrayList<AttributeField> requiredArgs = rf.getInputFieldCopy();
				ArrayList<AttributeField[]> args = new ArrayList<>();

				// Add all the other parameter ranges
				for (int i = 0; i < requiredArgs.size(); i++){
					String argName = requiredArgs.get(i).getName();
					if (!argName.equalsIgnoreCase("domain")){
						AttributeField from = null, to = null, stepsize = null;

						for (String key: this.valueArgumentNameToTextFieldMap.keySet() ){
							if ( (argName+"From").equals(key))
								from = new AttributeField("minimum", new DecimalNumber(valueArgumentNameToTextFieldMap.get(key).getText()));
							if ( (argName+"To").equals(key))
								to = new AttributeField("maximum", new DecimalNumber(valueArgumentNameToTextFieldMap.get(key).getText()));
							if ( (argName+"StepSize").equals(key))
								stepsize = new AttributeField("stepsize", new DecimalNumber(valueArgumentNameToTextFieldMap.get(key).getText()));
						}

						AttributeField[] entry = new AttributeField[]{from, to, stepsize};
						args.add(entry);
					}
				}
				factory.setMultipleSamplingDistributions(rf, args);
			}
		}
		
		AbstractObjectiveTemplate newObject =  factory.build();
		newObject.updateDomain();
		return newObject;
	}
	
	/** Change the selected object. Used when pressing on the buttonApplyChanges button. This function also handles input validation
	 * @throws RestrictionViolationException */
	public void changeExistingObject() throws RestrictionViolationException {
		// First, check if all inputs are valid (i.e., no red text fields)
		boolean isValidInput = validateInput();

		if (!isValidInput)
			return;

		// Next: changing an object in any way, shape, or form means that all patch offsets disappear. Is
		// the user OK with this?
		if (!ObserverManager.showConfirmationMessage("Continue?", "Changing an object in any way, shape, or form means that all patch state offsets, actions, beliefs, death conditions, and fitness elements related to this object will be removed. This removal cannot be undone. Do you want to continue?", "Yes - remove it all", "No - do not remove anything", null))
			return;
		
		// Make true on our promise: remove all things related to the object
		View.getView().workspace.removeAllElementsContainingObject(object);

		// Next, check if we removed a cue (i.e., it was in the original object, but now the this.radioButtonCueNo is selected)
		// If so, continuing means removing all actions that use that cue. Ask the user if she wants to continue
		boolean removedCue = false;
		if (object != null)
			if (object.getCueTemplate() != null && this.radioButtonCueNo.isSelected()&& this.radioButtonCueNo.isVisible())
				removedCue = true;
		if (removedCue){
			if (!ObserverManager.showConfirmationMessage("Continue?", "After these changes, this object no longer has a cue associated with it. This might remove any action that uses this cue. These changes are irreversible. Do you want to continue?", "Yes - remove cue", "No - cancel action", null))
				return;
			else {
				object.removeCue(object.getCueTemplate());
			}
		}

		// Create a new object based on the input
		AbstractObjectiveTemplate newObject = this.createObjectBasedOnInput();

		object.copyAllSettings(newObject);
		
		View.getView().update();
		this.close();

	}
}
