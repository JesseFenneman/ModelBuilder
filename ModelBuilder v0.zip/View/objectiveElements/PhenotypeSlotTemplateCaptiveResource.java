package objectiveElements;

import java.util.ArrayList;

import javafx.scene.Node;
import javafx.scene.text.TextFlow;
import start.CentralExecutive;
import view.View;

/**A Captive Slot can hold a resource that will only be consumed after another action - or when
 * interrupted via an extrinsic event. Specifically, a resource will always remain in a slot, even
 * when consumed, unless the slot is explicitly emptied (or overwritten). */
public class PhenotypeSlotTemplateCaptiveResource extends AbstractPhenotypeSlotTemplate{

	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	/** Creates a new slot template. Adds all the resources and delays in the workspace to this slot. The default is
	 * that all resource or delays can be used.*/
	public PhenotypeSlotTemplateCaptiveResource(String name, boolean isOverwritable) {
		super();
		this.name=name;
		this.isOverwritable=isOverwritable;
		
		update();
	}

	public PhenotypeSlotTemplateCaptiveResource() {
		super();
		
		update();
	}


	/** Sets whether this slot can be overwritten by a new resource (true), or whether this slot can only be filled with a new entry if the current entry
	 * is finished (false)*/
	@Override
	public void setOverwritable(boolean isOverwritable) {
		this.isOverwritable= isOverwritable;
	}

	@Override
	public SlotType getSlotType() {
		return SlotType.CAPTIVE_RESOURCE;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(name + ". A captive resource slot. This slot stores resources of types ");
		
		ArrayList<ResourceObjectTemplate> permissibleResources = new ArrayList<>();
		for (ResourceObjectTemplate r : this.hashMapResources.keySet())
			if (hashMapResources.get(r))
				permissibleResources.add(r);
		
		for (int i = 0; i < permissibleResources.size(); i++) {
			sb.append(permissibleResources.get(i).getName());
			if (i == permissibleResources.size()-1 && permissibleResources.size() > 1)
				sb.append(", and ");
			else if (i < permissibleResources.size()-1)
				sb.append(", ");
		}
		
		sb.append(". These resources can effect these phenotypic dimensions: ");
		ArrayList<PhenotypeObjectTemplate> permissiblePhenotypes = new ArrayList<>();
		for (PhenotypeObjectTemplate p : this.hashMapPhenotypes.keySet())
			if (hashMapPhenotypes.get(p))
				permissiblePhenotypes.add(p);
		
		for (int i = 0; i < permissiblePhenotypes.size(); i++) {
			sb.append(permissiblePhenotypes.get(i).getName());
			if (i == permissiblePhenotypes.size()-1 && permissiblePhenotypes.size() > 1)
				sb.append(", and ");
			else if (i < permissiblePhenotypes.size()-1)
				sb.append(", ");
		}
		
		
		if (this.isOverwritable)
			sb.append(". This slot can be overwritten.");
		else
			sb.append(". This slot cannot be overwritten.");
		return sb.toString();
	}

	@Override
	protected ArrayList<Node> displaySlotSpecificProperties() {
		return new ArrayList<Node>();
		}

	@Override
	public boolean canUseAsDelay(InstanceReference delayReference) {
		return false;
	}

	@Override
	public boolean canUseAsInterruption(InstanceReference interruptionReference) {
		return false;
	}


}
