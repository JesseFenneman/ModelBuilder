package objectiveElements;

import java.io.Serializable;

import start.CentralExecutive;

/** During the setup of a model, we often think of objects in terms
 * of the distribution of these objects in the environment (i.e.,
 * we specify a distribution of resources). Sometimes however,
 * we want to talk about a single instance of an object type (e.g.,
 * we might want to talk about a single specific resource that 
 * an agent encountered). To allow us to refer to a single 
 * element from a larger distribution, an Instance 
 * is a single object that contains a reference to the type of
 * AbstractObjectTempalte it will be sampled from. 
 * 
 * Note: an AbastractInstance cannot refer to the phenotype.
 * */
public class Instance implements Serializable, InstanceReference {

	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	
	private final AbstractObjectiveTemplate instanceType;
	private final String name;
	
	
	
	public Instance (String name, AbstractObjectiveTemplate type) {
		this.name = name;
		this.instanceType = type;
		
		if (type instanceof PhenotypeObjectTemplate)
			throw new IllegalArgumentException("Cannot create a single instance of a phenotype template");
		if (this.name == null)
			throw new IllegalArgumentException("Cannot create an Instance with name null");
	}
		
	public String toString() { return "'" + name + "' (Class: "+ this.instanceType.name + ")";}


	@Override
	public Class<? extends AbstractObjectiveTemplate> getClassType() {
		return instanceType.getClass();
	}

	public AbstractObjectiveTemplate getAbstractObjectiveTemplate() {
		return instanceType;
	}

	@Override
	public String getName() {
		return name;
	}



}