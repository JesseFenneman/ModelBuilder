package objectiveElements;

/** Now here is a hacky workaround: sometimes I need a class to refer to
 * both all AbstractObjectiveTemplates and all possible CueTemplate. However,
 * I do not want to make a CueTemplate a subclass of AbstractObjectiveTemplate, 
 * as it is very different from resources, extrinsics, interruptions, phenotypes,
 * and delays. Hence this interface that, as the name subtly suggests, is 
 * implemented by both AbstractObjectiveTemplate and CueTemplate. */
@Deprecated
public interface AbstractObjectiveTemplateOrCueTemplate {

}
