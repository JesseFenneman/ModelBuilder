package objectiveElements;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import helper.Helper;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextFlow;
import start.CentralExecutive;
import view.PopupSlot;
import view.View;
import view.View.ViewState;


/**
 * Phenotype slots are slots where resources can be stored. Each slot can contain 0 or 1 resources.
 * It should be noted that including more slots will have an extreme effect on the runtime performance
 * of the to-be-build model: each additional slot can contain multiple possible resources, making the
 * total state space rather large. Currently, the following slots exist:
 * 
 * Name						Parameters					Description
 * Delayed resource			InstanceReference (r)		A resource-delay combination. After the delay is over, the resource will be consumed.
 * 							InstanceReference (d)
 * 							InstanceReference (i)		An optional interruption
 * 							PhenotypeObject				The affected phenotypic dimension
 * Recurring resource		InstanceReference (r)		A resource that will affect the specified phenotype dimension every x time steps, unless an interruption occurs
 * 							Integer 					
 * 							InstanceReference (i)		An optional interruption
 * 							PhenotypeObject
 * Captive resource			InstanceReference (r)		A resource that is kept, but not used without an additional action
 * 							
 *
 * Note that each slot can contain a resource. As such, which resources can be contained in the resources
 * is implemented by the AbstractPhenotypeSlotTemplate. There are other instances that can be used as well -
 * for example, the delayed resource type also contains a delay instance. These detailes are handled by
 * by the individual extended classes. 
 */
public abstract class AbstractPhenotypeSlotTemplate   extends VBox implements EventHandler<MouseEvent>, Serializable, PhenotypeElement {

	private static final long serialVersionUID = CentralExecutive.programVersion;

	//JAVAFX and JAVAFX related objects
	protected transient final static String cssStyleSheetLocation = AbstractObjectiveTemplate.class.getResource("../CSSLayout/buttonObjectiveElement.css").toExternalForm();

	public static final double MINIMUM_HEIGHT = AbstractObjectiveTemplate.MINIMUM_HEIGHT;
	private transient double heightInDecisionStructure; // An object's height in any tab should be the size of when it is in the DecisionStructure

	/** Name of this slot*/
	protected String name;

	/** Not all resources can be used in all slots. This HashMap provides a boolean for each possible resource, dictating whether that resource can be used */
	protected final HashMap<ResourceObjectTemplate, Boolean> hashMapResources;

	/** Not all phenotypic dimensions can be affected by resources used in all slots. 
	 * This HashMap provides a boolean for each possible resource, dictating whether that resource can be used */
	protected final HashMap<PhenotypeObjectTemplate, Boolean> hashMapPhenotypes;

	/** Some slots can be overwritten - that is, filled with another Resource-Delay pair before the delay timer is over. */
	protected boolean isOverwritable;

	public enum SlotType { 
		DELAYED_RESOURCE("Delayed resource"), 		
		RECURRING_RESOURCE("Recurring resource"), 
		CAPTIVE_RESOURCE("Captive resource");	
		private String name;
		SlotType(String s) { name = s; }
	}

	public AbstractPhenotypeSlotTemplate() {
		this.hashMapResources = new HashMap<>();
		for (ResourceObjectTemplate o : View.getView().workspace.getAllResourceObjects())
			this.hashMapResources.put(o, true);

		this.hashMapPhenotypes = new HashMap<>();
		for (PhenotypeObjectTemplate p : View.getView().workspace.getAllPhenotypeObjects())
			if (!(p instanceof AgeTemplate))
				this.hashMapPhenotypes.put(p, true);


		this.setMaxWidth(Double.MAX_VALUE);
		this.setPrefHeight(MINIMUM_HEIGHT);

		// Set the css for this object
		this.getStylesheets().add(cssStyleSheetLocation);
		this.getStyleClass().add("vbox");

		// Set the nodes in for this object
		loadDisplayNodes();

		// When pressed, show a popup depending on the state
		this.setOnMouseClicked(this);
	}


	public void setName(String newName) {
		if (newName == null)
			throw new IllegalArgumentException("Cannot use a null name");
		if (!Helper.isVariableName(newName))
			throw new IllegalArgumentException("Trying to set an invalid name for a PhenptypeDelayedResourceSlotTemplate.");
		this.name = newName;
	}

	public abstract void setOverwritable(boolean isOverwritable);

	public String getName() {
		return this.name;
	}

	/** Can this slot be overwritten by a new resource (true), or can there only be new entries in this slot if the current one is finished (false)?*/
	public boolean isOverwritable() {
		return this.isOverwritable;
	}

	public abstract SlotType getSlotType() ;


	/////////////////////////////// JAVAFX STUFF //////////////////////////////////

	/** Set all the nodes in this object for display purposes. Does not 'fill in' the details yet - that is done with UpdateView*/
	private void loadDisplayNodes(){
		this.spacingProperty().set(10);
		this.setPadding(new Insets(0,10,10,10));
	}

	/** FXML objects are, annoyingly, not serializable and transient. Hence, after loading this object from
	 * disk, we have to reinflate the FXML part */
	public void reinflate(){
		// Set the css for this object
		this.getStylesheets().add(cssStyleSheetLocation);
		this.getStyleClass().add("vbox");

		// Set the nodes in for this object
		loadDisplayNodes();

		// When pressed, show a popup depending on the state
		this.setOnMouseClicked(this);

	}


	/** Updates the look of this OBJECT*/
	public void update(){
		// Remove all existing nodes
		this.getChildren().removeAll(this.getChildren());

		// Remove the ID
		this.setId("");

		// Remove height restriction
		this.setMinHeight(USE_COMPUTED_SIZE);

		// Set the title and subtitle
		GridPane gridTitle = new GridPane();
		gridTitle.setMinHeight(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setPrefHeight(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setMaxHeight(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setMaxWidth(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setMinWidth(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setGridLinesVisible(true);

		RowConstraints row0 = new RowConstraints(25); //title
		RowConstraints row1 = new RowConstraints(25); //subtitle
		ColumnConstraints col = new ColumnConstraints();
		col.setMinWidth(USE_COMPUTED_SIZE);
		col.setPrefWidth(USE_COMPUTED_SIZE);
		col.setMaxWidth(USE_COMPUTED_SIZE);
		col.setHgrow(Priority.ALWAYS);

		gridTitle.getRowConstraints().addAll(row0, row1);
		gridTitle.getColumnConstraints().addAll(col);
		gridTitle.setGridLinesVisible(false);
		VBox.setVgrow(gridTitle, Priority.ALWAYS);

		// Set the titleLabel
		Label titleLabel = new Label("'"+name+ "'");
		GridPane.setValignment(titleLabel, VPos.CENTER);
		GridPane.setHalignment(titleLabel, HPos.CENTER);
		titleLabel.getStyleClass().add("titleText");
		gridTitle.add(titleLabel, 0, 0);

		// Set the subtitle
		Label subLabel = new Label("(A " + this.getSlotType().name.toLowerCase() + " phenotype slot)");
		GridPane.setValignment(subLabel, VPos.TOP);
		GridPane.setHalignment(subLabel, HPos.CENTER);
		subLabel.getStyleClass().add("subtitleText");
		gridTitle.add(subLabel, 0, 1);

		this.getChildren().add(gridTitle);

		// Set the textflows representing the permissible resources
		TextFlow tfResources = new TextFlow();
		int numberOfResourceIncluded = 0;
		for (ResourceObjectTemplate r : View.getView().workspace.getAllResourceObjects())
			if (this.canUseResource(r)) 
				numberOfResourceIncluded++;

		if (numberOfResourceIncluded == 0)
			tfResources.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("This slot can NOT be used by any resource", "normalText"));
		else {
			tfResources.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("This slot can store the following types of resources:  ", "normalText"));
			tfResources.getChildren().addAll(new Label(" "));
			int index = 0;
			for (ResourceObjectTemplate r : View.getView().workspace.getAllResourceObjects())
				if (this.canUseResource(r)) {
					index++;
					tfResources.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(r.getName(), "valueText"));
					if (index == (numberOfResourceIncluded-1))
						tfResources.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", and ", "normalText"));
					else if (index <= (numberOfResourceIncluded-1))
						tfResources.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", ", "normalText"));
				}
		}
		this.getChildren().add(tfResources);

		// Set the textflows representing the permissible phenotypes
		TextFlow tfPhenotype = new TextFlow();
		int numberOfPhenotypeIncluded = 0;
		for (PhenotypeObjectTemplate p : View.getView().workspace.getAllPhenotypeObjects())
			if (!(p instanceof AgeTemplate))
				if (this.canUsePhenotype(p)) 
					numberOfPhenotypeIncluded++;

		if (numberOfPhenotypeIncluded == 0)
			tfPhenotype.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("Resources in this slot cannot affect any phenotypic dimensions", "normalText"));
		else {
			tfPhenotype.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("Resources in this slot can affect the following phenotypic dimensions: ", "normalText"));
			tfPhenotype.getChildren().addAll(new Label(" "));
			int index = 0;
			for (PhenotypeObjectTemplate p : View.getView().workspace.getAllPhenotypeObjects())
				if (!(p instanceof AgeTemplate))
					if (this.canUsePhenotype(p)) {
						index++;
						tfPhenotype.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(p.getName(), "valueText"));
						if (index == (numberOfPhenotypeIncluded-1))
							tfPhenotype.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", and ", "normalText"));
						else if (index <= (numberOfPhenotypeIncluded-1))
							tfPhenotype.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", ", "normalText"));
					}
		}
		this.getChildren().add(tfPhenotype);


		// Ask the specific extension to provide the necessary information
		this.getChildren().addAll(displaySlotSpecificProperties());

		// Add the information on whether this slot can be overwritten.
		TextFlow tfOverwrite = new TextFlow();
		Label s = new Label("This slot ");
		s.getStylesheets().add(cssStyleSheetLocation);
		s.getStyleClass().add("normalText");
		tfOverwrite.getChildren().add(s);
		if (!this.isOverwritable) {
			Label can = new Label("can ");
			can.getStylesheets().add(cssStyleSheetLocation);
			can.getStyleClass().add("normalText");
			Label not = new Label("not ");
			not.getStylesheets().add(cssStyleSheetLocation);
			not.getStyleClass().add("valueText");
			tfOverwrite.getChildren().addAll(can, not);
		}else {
			Label can = new Label("can ");
			can.getStylesheets().add(cssStyleSheetLocation);
			can.getStyleClass().add("valueText");
			tfOverwrite.getChildren().add(can);
		}
		Label e = new Label(" be overwritten.");
		e.getStylesheets().add(cssStyleSheetLocation);
		e.getStyleClass().add("normalText");
		tfOverwrite.getChildren().add(e);
		this.getChildren().add(tfOverwrite);

		// Save the height. Note that the first time that an ObjectTemplate is drawn, it is updated before JavaFX is done drawing it.
		// (Yes, it's one of those annoying javafx things). Hence, a runlater threat that will fire after the UI is done doing its thing.
		Platform.runLater(() -> {
			this.heightInDecisionStructure = getHeight();
		});

		// Enforce the height
		Platform.runLater(() -> {
			double height = Math.max(MINIMUM_HEIGHT, heightInDecisionStructure);
			this.setMinHeight(height);
		});
	}

	/** All slot types have a name, set of permissible resources, and a boolean indicating whether this slot 
	 * can be overwritten. These elements are drawn by the Abstract class. However, specific implementations
	 * can (and almost always do) have specific fields that different between extensions. These specific fields
	 * should be drawn (or printed) between the permissible resources and the 'can be overwritten' statement.
	 * This drawing is handled by this function, which should return a set of nodes.*/
	protected abstract ArrayList<Node> displaySlotSpecificProperties();

	/** Can the specified ResourceObjectTemplate be used in this slot?*/
	public boolean canUseResource(ResourceObjectTemplate resource) {
		if (!this.hashMapResources.containsKey(resource))
			throw new IllegalArgumentException("Trying to get whether a resource can be used in a slot, but the resource is not yet in the HashMap.");

		return hashMapResources.get(resource);
	}

	/** Can the specified PhenotypeObjectTemplate be used in this slot?*/
	public boolean canUsePhenotype(PhenotypeObjectTemplate pheno) {
		if (pheno instanceof AgeTemplate)
			throw new IllegalArgumentException("Can never use the age in a phenotypic slot!");

		if (!this.hashMapPhenotypes.containsKey(pheno))
			throw new IllegalArgumentException("Trying to get whether a phenotype can be used in a slot, but the phenotype is not yet in the HashMap.");

		return hashMapPhenotypes.get(pheno);
	}
	

	/** Modifies whether the specified ResourceObjectTemplate can be used in this slot*/
	public void modifyCanUseResource(ResourceObjectTemplate resource, boolean possibleToUse) {
		if (!this.hashMapResources.containsKey(resource))
			throw new IllegalArgumentException("Modifying a resource to use in a slot, but the resource is not yet in the HashMap.");

		hashMapResources.put(resource, possibleToUse);
	}

	/** Modifies whether the specified PhenotypeObjectTemplate can be used in this slot*/
	public void modifyCanUsePhenotype(PhenotypeObjectTemplate pheno, boolean possibleToUse) {
		if (pheno instanceof AgeTemplate)
			throw new IllegalArgumentException("Can never use the age in a phenotypic slot!");

		if (!this.hashMapPhenotypes.containsKey(pheno))
			throw new IllegalArgumentException("Modifying a phenotype to use in a slot, but the phenotype is not yet in the HashMap.");

		hashMapPhenotypes.put(pheno, possibleToUse);
	}

	/** Should be called by the Workspace whenever a new resource is added to the Workspace*/
	public void addResourceType(ResourceObjectTemplate newResource,  boolean possibleToUse) {
		this.hashMapResources.put(newResource, possibleToUse);
	}

	/** Should be called by the Workspace whenever a new resource is added to the Workspace*/
	public void addPhenotypeType(PhenotypeObjectTemplate newPhenotype,  boolean possibleToUse) {
		if (newPhenotype instanceof AgeTemplate)
			throw new IllegalArgumentException("Can never use the age in a phenotypic slot!");

		this.hashMapPhenotypes.put(newPhenotype, possibleToUse);
	}

	/** Should be called by the Workspace whenever the resource is removed from the Workspace*/
	public void removeResourceType(ResourceObjectTemplate toBeRemovedResource) {
		this.hashMapResources.remove(toBeRemovedResource);
	}

	/** Should be called by the Workspace whenever the Phenotype is removed from the Workspace*/
	public void removePhenotypeType(PhenotypeObjectTemplate toBeRemovedPhenotype) {
		this.hashMapPhenotypes.remove(toBeRemovedPhenotype);
	}

	@Override
	public void handle(MouseEvent event) {
		if (View.getView().getState() == ViewState.DECISION_STRUCTURE)
			new PopupSlot(event,this);
	}

	// Forces each subclass to implement toString
	public abstract String toString();

	
	/** Can the specified InstanceReference be used as an resource in this slot?*/
	public boolean canUseAsResource(InstanceReference resourceReference) {
		if (!this.hashMapResources.containsKey(resourceReference.getAbstractObjectiveTemplate()))
			throw new IllegalArgumentException("Trying to get whether a resource instance can be used in a slot, but the AbstractObjectiveTemplate of this resource is not yet in the HashMap.");

		return hashMapResources.get(resourceReference.getAbstractObjectiveTemplate());
	}
	
	/** Can the specified InstanceReference be used as a delay in this slot?*/
	public abstract boolean canUseAsDelay(InstanceReference delayReference) ;
	
	/** Can the specified InstanceReference be used as an interruption in this slot?*/
	public abstract boolean canUseAsInterruption(InstanceReference interruptionReference) ;
	
	
	/////////////////////////////// Static functions //////////////////////////////////


	/** Returns a String providing the name of the AbstractPhenotypeSlotTemplate extension*/
	public static String getTypeName(Class<? extends AbstractPhenotypeSlotTemplate> clazz) {

		if (clazz == PhenotypeSlotTemplateCaptiveResource.class) 	{ return "Captive resource";}
		if (clazz == PhenotypeSlotTemplateDelayedResource.class) 	{ return "Delayed resource";}
		if (clazz == PhenotypeSlotTemplateRecurringResource.class) 	{ return "Recurring resource";}

		throw new IllegalArgumentException("Unknown slot type: " + clazz.getSimpleName());
	}


	/** Returns a String providing a brief description of the AbstractPhenotypeSlotTemplate extension*/
	public static String getDescription(Class<? extends AbstractPhenotypeSlotTemplate> clazz) {

		if (clazz == PhenotypeSlotTemplateCaptiveResource.class) 	{ return "A resource that is kept by the agent, but that can only be consumed through another action.";}
		if (clazz == PhenotypeSlotTemplateDelayedResource.class) 	{ return "A resource that will be consumed after a specified delay. This resource can become interrupted. After consumption, this resource disappears.";}
		if (clazz == PhenotypeSlotTemplateRecurringResource.class) 	{ return "A resource that will be consumed once every x time steps. After consumption, this resource will remain in the slot.";}

		throw new IllegalArgumentException("Unknown slot type: " + clazz.getSimpleName());
	}

	/** Get a list of all known classes that extend AbstractPhenotypeSlotTemplate*/
	public static ArrayList<Class<? extends AbstractPhenotypeSlotTemplate>> getAllSlotTypes(){
		ArrayList<Class<? extends AbstractPhenotypeSlotTemplate>> clazzes = new ArrayList<>();
		clazzes.add(PhenotypeSlotTemplateCaptiveResource.class);
		clazzes.add(PhenotypeSlotTemplateDelayedResource.class);
		clazzes.add(PhenotypeSlotTemplateRecurringResource.class);
		return clazzes;
	}

	/** A boolean indicating whether this slot type uses delays - and hence, whether delays should be offered on the phenotypic slot popup*/
	public static boolean usesDelays(Class<? extends AbstractPhenotypeSlotTemplate> clazz) {
		if (clazz == PhenotypeSlotTemplateCaptiveResource.class) 	{ return false;}
		if (clazz == PhenotypeSlotTemplateDelayedResource.class) 	{ return true;}
		if (clazz == PhenotypeSlotTemplateRecurringResource.class) 	{ return false;}

		throw new IllegalArgumentException("Unknown slot type: " + clazz.getSimpleName());
	}

	/** A boolean indicating whether this slot type uses interruptions - and hence, whether interruptions should be offered on the phenotypic slot popup*/
	public static boolean usesInterruptions(Class<? extends AbstractPhenotypeSlotTemplate> clazz) {
		if (clazz == PhenotypeSlotTemplateCaptiveResource.class) 	{ return false;}
		if (clazz == PhenotypeSlotTemplateDelayedResource.class) 	{ return true;}
		if (clazz == PhenotypeSlotTemplateRecurringResource.class) 	{ return true;}

		throw new IllegalArgumentException("Unknown slot type: " + clazz.getSimpleName());
	}


	/** A boolean indicating whether this slot type uses an integer for its periodicity*/
	public static boolean usesPeriodicity(Class<? extends AbstractPhenotypeSlotTemplate> clazz) {
		if (clazz == PhenotypeSlotTemplateCaptiveResource.class) 	{ return false;}
		if (clazz == PhenotypeSlotTemplateDelayedResource.class) 	{ return false;}
		if (clazz == PhenotypeSlotTemplateRecurringResource.class) 	{ return true;}

		throw new IllegalArgumentException("Unknown slot type: " + clazz.getSimpleName());
	}

	/** Create a new AbstractPhenotypeSlotTemplate of the specified class */
	public static AbstractPhenotypeSlotTemplate createSlot(Class<? extends AbstractPhenotypeSlotTemplate> clazz){

		if (clazz == PhenotypeSlotTemplateCaptiveResource.class)			return new PhenotypeSlotTemplateCaptiveResource();
		if (clazz == PhenotypeSlotTemplateDelayedResource.class)			return new PhenotypeSlotTemplateDelayedResource();
		if (clazz == PhenotypeSlotTemplateRecurringResource.class)			return new PhenotypeSlotTemplateRecurringResource();

		throw new IllegalStateException("Unknown postcondition subclass: " + clazz);

	}
}
