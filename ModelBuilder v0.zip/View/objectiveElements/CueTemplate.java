package objectiveElements;

import java.io.Serializable;
import java.util.ArrayList;

import start.CentralExecutive;

/** A CueTemplate is a holding object for a bunch of CueLabels and a single Object.*/
public class CueTemplate implements AbstractObjectiveTemplateOrCueTemplate, Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public ArrayList<CueLabel> cueLabels;
	public AbstractObjectiveTemplate object;
	public int maximumNumberOfCuesAnAgentCanSample;
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("Cue for " + object.name+ ", with labels: ");
		for (int i =0; i < cueLabels.size(); i++)
			sb.append("   "+(i+1)+")" + cueLabels.get(i) + "; ");
		return sb.toString();
	}


}
