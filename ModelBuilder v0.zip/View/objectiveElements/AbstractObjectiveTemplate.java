package objectiveElements;

import java.io.Serializable;
import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import attributes.AttributeField;
import attributes.AttributeField.IncompatibleNumberObjectTypeException;
import beliefElements.AbstractBeliefTemplate;
import beliefElements.DelayBeliefTemplate;
import beliefElements.ExtrinsicBeliefTemplate;
import beliefElements.InterruptionBeliefTemplate;
import beliefElements.ResourceBeliefTemplate;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import interfaces_abstractions.ObserverManager;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextFlow;
import rIntegration.RFunction;
import rIntegration.RFunctionContainer;
import rIntegration.RFunctionContainer.UnknownArgumentException;
import spatialAndTemporalElements.BaseState;
import spatialAndTemporalElements.PatchStateTemplate;
import start.CentralExecutive;
import view.PopupObject;
import view.PopupPatchStateObjectOffset;
import view.View;
import view.View.ViewState;

/** An object template is the visual representation of that object in the View. It is not the
 * same as the object used by a Model. Rather, it specified how the Model should make
 * a 'true' object. This visual representation is based on JavaFX's button. Note that
 * domain and runtime parameter fields have a protected visibility. Specific subclasses
 * of AbstractObjectiveTemplate have to manually implement setters for these fields. */
public abstract class AbstractObjectiveTemplate extends VBox implements EventHandler<MouseEvent>, AbstractObjectiveTemplateOrCueTemplate, Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;

	public static final double MINIMUM_HEIGHT = 85;
	@SuppressWarnings("serial")
	public static class MissspecificationException extends RuntimeException { public MissspecificationException(String message) { 	 super(message);  }};

	protected String name;

	// What is the probability for each time step that an agent encounters an object?
	// Note: this is implemented by the subclasses, as not all objects have a frequency
	// Specifically, the interruption probability is a probability already, no need for
	// a field like frequency.
	protected DecimalNumber frequency;

	// The domain specifies the range of an object during runtime - which values are
	// permissible for this object to have? The full set of numbers are stored in the
	// DecimalNumberArray domain. The minimum, maximum, and stepsize 'summaries' are
	// stored in minimum, maximum, and stepsize.
	protected boolean isConstant; // True if the domain is of size 1 - i.e., if only one value is possible
	protected DecimalNumberArray domain;
	protected DecimalNumber minimum, maximum, stepsize;

	// An object can be directly observable or not. If not, an agent has to have a
	// belief about that object, and may, or may not, be able to sample cues about the
	// true value of that object.
	protected boolean isObservable;
	protected AbstractBeliefTemplate belief;
	protected CueTemplate cue;

	// An object can be instantiated differently over runs. For instance, resources might
	// be normally distributed with a mean of 0 and multiple SD's. These distributions are
	// instantiated during runtime by a function call to R.
	protected boolean splitOverRuns;
	protected ArrayList<RFunctionContainer> samplingDistributions;
	private ArrayList<AttributeField[]> lastUsedParameters; // We'll use this to reset the fields in the view if we need to change an object
	private RFunction lastUsedRFunction;

	//JAVAFX and JAVAFX related objects
	private transient final static String cssStyleSheetLocation = AbstractObjectiveTemplate.class.getResource("../CSSLayout/buttonObjectiveElement.css").toExternalForm();
	protected transient double heightInDecisionStructure; // An object's height in any tab should be the size of when it is in the DecisionStructure

	public AbstractObjectiveTemplate(){
		this.setMaxWidth(Double.MAX_VALUE);
		this.setPrefHeight(MINIMUM_HEIGHT);

		// Set the css for this object
		this.getStylesheets().add(cssStyleSheetLocation);
		this.getStyleClass().add("vbox");

		// Set the nodes in for this object
		loadDisplayNodes();

		// When pressed, show a popup depending on the state
		this.setOnMouseClicked(this);

	}

	/** FXML objects are, annoyingly, not serializable and transient. Hence, after loading this object from
	 * disk, we have to reinflate the FXML part */
	public void reinflate(){
		// Set the css for this object
		this.getStylesheets().add(cssStyleSheetLocation);
		this.getStyleClass().add("vbox");

		// Set the nodes in for this object
		loadDisplayNodes();

		// When pressed, show a popup depending on the state
		this.setOnMouseClicked(this);

	}

	/** Set all the nodes in this object for display purposes. Does not 'fill in' the details yet - that is done with UpdateView*/
	private void loadDisplayNodes(){
		this.spacingProperty().set(10);
		this.setPadding(new Insets(0,10,10,10));
	}

	/** Set all fields in this AbstractObjectiveTemplate to match the original AbstractObjectiveTemplate.
	 * Does not copy the type! */
	public void copyAllSettings(AbstractObjectiveTemplate original){
		this.name = original.name;
		if (this.frequency != null)
			this.frequency.set(original.frequency);

		this.isConstant = original.isConstant;
		if (isConstant)
			this.removeBelief();

		//this.domain.setAll(original.domain);
		this.domain = original.domain;
		this.minimum.set(original.minimum);
		this.maximum.set(original.maximum);
		this.stepsize.set(original.stepsize);

		this.setObservable(original.isObservable);

		this.setCueTemplate(original.getCueTemplate());
		try {
			if (!original.isConstant && AbstractObjectiveTemplate.objectToClass(this) != PhenotypeObjectTemplate.class)
				if (!original.splitOverRuns){
					this.setSingleSamplingDistribution(original.getSamplingDistribution());
				} else {
					this.setMultipleSamplingDistributions(original.lastUsedRFunction, original.lastUsedParameters);
				}
		} catch (IncompatibleNumberObjectTypeException | RestrictionViolationException e) {ObserverManager.notifyObserversOfError(e);}

	}

	/** Is there only one distribution (false), or are there more distributions, and do we have to
	 * create separate runs for each (true)?*/
	public boolean useOneDistribution(){ return !splitOverRuns;}

	/** If there is only one distribution (splitOverRuns()==false), what is the
	 * sampling distribution that we will use? Note, this is the baseline distribution:
	 * patches and environmental states can add or subtract values. Returns null if
	 * there is more than 1 distribution.*/
	public RFunctionContainer getSamplingDistribution() {
		if (!this.useOneDistribution())
			return null;
		return this.samplingDistributions.get(0);
	}

	/** Returns an ArrayList that contains all sampling distributions. Note that this
	 * ArrayList is of size 1 if there is only one distribution (i.e., if this
	 * object will not be split over runs).*/
	public ArrayList<RFunctionContainer> getAllSamplingDistributions() {
		return this.samplingDistributions;
	}


	/** Set the object to have values sampled from the new function. Note, this overwrites all existing sampling distributions,
	 * and sets the object to have only a single distribution (that does not change over runs). Also note that this is the base
	 * distribution - patches might add adjustments. Finally, this object well automatically add its domain to the function
	 * @throws RestrictionViolationException
	 * @throws IncompatibleNumberObjectTypeException */
	public void setSingleSamplingDistribution(RFunctionContainer newFunction) throws IncompatibleNumberObjectTypeException, RestrictionViolationException{
		this.samplingDistributions = new ArrayList<>();
		this.samplingDistributions.add(newFunction.clone());
		try {
			this.samplingDistributions.get(0).replaceOrAddArgument(new AttributeField("domain", domain));
		} catch (UnknownArgumentException e) {ObserverManager.notifyObserversOfError(e);}
		this.splitOverRuns = false;
	}

	/** Set multiple samplingDistributions. For each distribution there will be a separate run.
	 * The runtimeParameters argument should consist of a AttributeField array for each non-domain
	 * argument of samplingDistribution (the domain argument gets added and maintained by this object).
	 * Each array should have 3 attributeFields, called: minimum, maximum, and stepsize. I'll leave it
	 * to the reader to figure out what that means... Hint: the arrayList has to be ordered for each
	 * non-domain argument used by the RFunction.
	 *  (Note: implicitly calls setSingleSamplingDistribution if the function does not have any arguments in addition to the domain)
	 * @throws RestrictionViolationException */
	public void setMultipleSamplingDistributions(RFunction samplingDistribution, ArrayList<AttributeField[]> runtimeParameters) throws RestrictionViolationException{
		// If there is only the domain argument, there really isn't any need to split over runs.
		// But getting this into the UI was a hassle, so I'll just block it here
		if (samplingDistribution.getInputFieldCopy().size() == 1){
			RFunctionContainer newRFC = null;
			try {
				newRFC = new RFunctionContainer(samplingDistribution, new ArrayList<AttributeField>());
			} catch (UnknownArgumentException e) { ObserverManager.notifyObserversOfError(e);}
			this.setSingleSamplingDistribution(newRFC);
			return;
		}

		// Save the used RuntimeParameters for later use - for when we need to reload the view with the used arguments
		lastUsedParameters = runtimeParameters;
		lastUsedRFunction = samplingDistribution;
		// Get the inputs required for samplingDistribution
		ArrayList<AttributeField> inputsRequiredByFunction = samplingDistribution.getInputFieldCopy();

		// Remove the domain input required (the instantiated object will use its own domain)
		ArrayList<AttributeField> inputsRequired = new ArrayList<>();
		for (AttributeField inputField: inputsRequiredByFunction)
			if (!inputField.getName().equalsIgnoreCase("domain"))
				inputsRequired.add(inputField.clone());

		// For each input make a DecimalNumberArray that contains all values that input might have
		DecimalNumberArray[] allPossibleInputs = new DecimalNumberArray[inputsRequired.size()];
		for (int i = 0; i < allPossibleInputs.length; i++){
			// Extract minimum, maximum, stepsize
			AttributeField minimum = null;
			AttributeField maximum = null;
			AttributeField stepsize = null;

			for (AttributeField af: runtimeParameters.get(i))
				if (af.getName().equalsIgnoreCase("minimum"))
					minimum = af;
				else if (af.getName().equalsIgnoreCase("maximum"))
					maximum = af;
				else if (af.getName().equalsIgnoreCase("stepsize"))
					stepsize = af;

			// Check if all three are present. If not, throw MissspecificationException
			if (minimum == null || maximum == null || stepsize == null)
				throw new MissspecificationException("Cannot set runtime parameters for set of distributions: missing either minimum, maximum, or stepsize for " + i + "th argument.");

			// Check whether min < max
			if (((NumberObjectSingle) minimum.getValueCopy()).largerThan(((NumberObjectSingle) minimum.getValueCopy() ) ) )
				throw new MissspecificationException("Cannot set runtime parameters for set of distributions: minimum is larger than maximum for " + i + "th argument.");

			// Check whether stepsize is a positive value
			if (!FieldRestriction.isValid(stepsize.getValueString(), FieldRestriction.POSITIVE_DOUBLE))
				throw new MissspecificationException("Cannot set runtime parameters for set of distributions: stepsize is not a positive value for " + i + "th argument.");

			allPossibleInputs[i] = new DecimalNumberArray(
					(NumberObjectSingle)minimum.getValueCopy(),
					(NumberObjectSingle)maximum.getValueCopy(),
					(NumberObjectSingle)stepsize.getValueCopy());
		}

		DecimalNumberMatrix allCombinations = null;
		if (allPossibleInputs.length == 1)
			allCombinations = new DecimalNumberMatrix(allPossibleInputs[0]).transpose();
		if (allPossibleInputs.length == 2)
			allCombinations = DecimalNumberArray.expandGrid(allPossibleInputs[0], allPossibleInputs[1]);
		if (allPossibleInputs.length == 2){
			allCombinations = DecimalNumberArray.expandGrid(allPossibleInputs[0], allPossibleInputs[1]);
			for (int i = 2; i < allPossibleInputs.length; i ++)
				allCombinations = DecimalNumberMatrix.expandGrid(allCombinations, allPossibleInputs[i]);
		}

		// Now that we know all possible inputs, create a RFunctionContainer for each possible combination of inputs, and add the domain
		ArrayList<RFunctionContainer> allFunctions = new ArrayList<>();
		for (int r = 0; r < allCombinations.nrow(); r++){
			ArrayList<AttributeField> arguments = new ArrayList<>();
			for (int c = 0; c< allCombinations.ncol(); c++)
				arguments.add(new AttributeField(inputsRequired.get(c).getName(), allCombinations.getValueAt(r, c)));
			arguments.add(new AttributeField("domain", domain));
			try {allFunctions.add(new RFunctionContainer(samplingDistribution, arguments));
			} catch (UnknownArgumentException e) {ObserverManager.notifyObserversOfError(e);}
		}
		this.samplingDistributions = allFunctions;

		this.splitOverRuns = true;
	}

	/** Returns the previous runtime parameters used to construct the sampling distributions. These
	 * parameters are no longer in use - changing them does not change anything. Returns null if only
	 * a single sampling distributions is used.*/
	public ArrayList<AttributeField[]> getPreviousRuntimeParameters(){
		if (!splitOverRuns)
			return null;
		return this.lastUsedParameters;
	}

	/** When setting multiple distributions over runs, the user specified a RFunction to use. Moreover,
	 * she specified for each argument needed by this function a minimum, maximum, and stepzise. For instance,
	 * she could have specified a normal distribution, where the sd varies from 1 to 10 with steps of 1. This
	 * function returns for a given parameter name (e.g., sd) the minimum, maximum, and stepsize (in that order).
	 * Names are compared without capitals.
	 *
	 * Note that the minimum, maximum, and stepsize are no longer in use - changing them does not change anything
	 * in the sampling distributions. Returns null if only a single sampling distributions is used, or this RFunction
	 * does not have a parameter with that name.*/
	public AttributeField[] getPreviouslyUsedMinimumMaximumAndStepsize(String parameterName){
		if (!splitOverRuns)
			return null;

		String[] rFunctionArgumentNames = this.lastUsedRFunction.getOrderOfArguments();
		// remove domain
		ArrayList<String> inputsRequired = new ArrayList<>();
		for (String s: rFunctionArgumentNames)
			if (!s.equalsIgnoreCase("domain"))
				inputsRequired.add(s);

		for (int i = 0; i < inputsRequired.size(); i++)
			if (inputsRequired.get(i).equalsIgnoreCase(parameterName))
				return lastUsedParameters.get(i);
		return null;
	}

	/** Returns the previous runtime parameters used to construct the sampling distributions. These
	 * parameters are no longer in use - changing them does not change anything. Returns null if only
	 * a single sampling distributions is used.*/
	public RFunction getPreviousRuntimeParameterFunction(){
		if (!splitOverRuns)
			return null;
		return this.lastUsedRFunction;
	}

	/**Set the name of this AbstractObjectiveTemplate. Names should be adhere to
	 * the FieldRestriction.VARIABLE_NAME restriction - i.e., no starting with numbers,
	 * include spaces, or other weird characters. Returns false if the name could not be
	 * set (i.e., if the name is invalid) */
	public boolean setName(String name){
		if (FieldRestriction.isValid(name, FieldRestriction.VARIABLE_NAME)){
			this.name = name;
			return true;
		}
		throw new MissspecificationException("Invalid object name.");
	}

	/**Returns the name of this AbstractObjectiveTemplate. Names always adhere to
	 * the FieldRestriction.VARIABLE_NAME restriction - i.e., no starting with numbers,
	 * include spaces, or other weird characters.*/
	public String getName(){
		return this.name;
	}

	/** Set the frequency. Note: interruptions and phenotypes do not have a frequency. Calling this function on
	 * an InterruptionObjectTemplate or a PhenotypeObjectTemplate will not do anything.*/
	public abstract void setFrequency(DecimalNumber frequency);


	/** Get the frequency (deep clone) - the probability in each time step that an object occurs. Note:
	 * Interruptions do not have a frequency and will return null. */
	public DecimalNumber getFrequency(){
		if (this.frequency == null)
			return null;
		return this.frequency.clone();}

	/** Set the domain (a DecimalNumberArray) of this AbstractObjectiveTemplate to be all multiples
	 * of (stepsize) in the range [minimum, maximum], inclusive. For instance, the set of all
	 * multiples of 0.5 in the range -2.9 to 1 is:
	 * 
	 *  {-2.5, -2, -1.5, -1, -0.5, 0, 0.5, 1}
	 * 
	 *  Note that this function should sets the minimum, maximum, and stepsize fields. This function
	 *  also sets isConstant to false. To set the domain to be fixed (i.e., always have the same
	 *   singular value), use setDomainFixed(DecimalNumber) instead.
	 *
	 * Some objects (e.g., interruptions) might have a restricted range (i.e., between 0 and 1).
	 * 
	 * Returns true if set was successful */
	public abstract boolean setDomainRange(DecimalNumber minimum, DecimalNumber maximum, DecimalNumber stepsize);

	/** Set the domain (a DecimalNumberArray) of this AbstractObjectiveTemplate to a single, fixed
	 * value. That is, turns this object into a constant. If this object should have more than 1
	 * possible value, consider using setDomainRange() instead. This function also sets
	 * isConstant to true. Also, for consistency, consider setting the minimum and maximum
	 * to the fixed value.
	 * Returns true if set was successful */
	public abstract boolean setDomainFixed(DecimalNumber fixedValue);

	/** Call this after the domain of this object has changed - it makes sure that the cue labels and
	 * sample distribution functions use the correct domain*/
	public void updateDomain(){
		try {
			if (this.samplingDistributions != null)
				for (RFunctionContainer rfc: samplingDistributions)
					rfc.replaceArgument(new AttributeField("domain", domain));

			if (cue !=null){
				this.cue.object=this;
				// Set the domain of the cue labels to this object's domain
				for (CueLabel cl: this.cue.cueLabels)
					cl.functionContainer.replaceArgument(new AttributeField("domain", domain));
			}
		} catch (IncompatibleNumberObjectTypeException | RestrictionViolationException | UnknownArgumentException e) {ObserverManager.notifyObserversOfError(e);}
	}

	/** Can this object have only one possible value (true) or are multiple values possible?*/
	public boolean isConstant(){
		return this.isConstant;
	}

	/** Returns the domain of this object type. That is, an array of all possible values this
	 * object can have during runtime. */
	public DecimalNumberArray getDomain() {return this.domain;}

	/** Returns the lowest possible value an object of this type can have. */
	public DecimalNumber getDomainMinimum() {return this.minimum;}

	/** Returns the highest possible value an object of this type can have. */
	public DecimalNumber getDomainMaximum() {return this.maximum;}

	/** Returns the step size that possible value an object of this type can have.
	 * An object can only have values in the set {x*ss | x > minimum AND x < maximum},
	 * where ss is the step size.  */
	public DecimalNumber getDomainStepSize() {return this.stepsize;}

	/** Can an agent directly observe the value of this object, or does
	 * it only have a belief about this value?*/
	public boolean isObservable() {return this.isObservable;}

	/** Sets the observability, which determines whether an agent can directly
	 * 'know' the value, or whether it has to form a belief about this value. If
	 * an object is observable, there is never a belief. If it is not observable,
	 * it always has a belief. Note that constant objects AWLAYS are observable */
	public void setObservable(boolean observability){
		this.isObservable = observability;
		if (isConstant)
			this.isObservable = true;
		if (isObservable)
			this.belief = null;
		else {
			if (this.belief == null)
				this.createBelief();
		}
	}

	/** Set the belief of this object. Note that only non-observable, non-phenotype objects have beliefs. */
	private void createBelief(){
		Class<?extends AbstractObjectiveTemplate> thisSubClass = AbstractObjectiveTemplate.objectToClass(this);

		if (thisSubClass == PhenotypeObjectTemplate.class)
			return;

		if (thisSubClass == DelayObjectTemplate.class)
			this.belief = new DelayBeliefTemplate(this);

		if (thisSubClass == InterruptionObjectTemplate.class)
			this.belief = new InterruptionBeliefTemplate(this);

		if (thisSubClass == ExtrinsicObjectTemplate.class)
			this.belief = new ExtrinsicBeliefTemplate(this);

		if (thisSubClass == ResourceObjectTemplate.class)
			this.belief = new ResourceBeliefTemplate(this);

	}

	/** Returns the (prior) belief an agent has over this object. Returns null if this object is observable*/
	public AbstractBeliefTemplate getBelief(){
		if (isObservable())
			return null;
		return this.belief;
	}
	/** Returns the CueTemplate associated with this object. Returns null if
	 * no cue has been set. Note: this function also sets the domain argument for
	 * the function that we are using. */
	public CueTemplate getCueTemplate() {return this.cue;}

	/** Sets the CueTemplate associated with this object. Note, this overwrites
	 * the existing cue if newCue is not null. Also note: this binding is associative; this object will
	 * also set itself into the CueTemplate as the object. */
	public void setCueTemplate(CueTemplate newCueTemplate){
		if (newCueTemplate == null)
			return;

		this.isObservable=false;
		this.cue = newCueTemplate;
		if (cue !=null){
			this.cue.object=this;
			// Set the domain of the cue labels to this object's domain
			for (CueLabel cl: this.cue.cueLabels)
				try {
					cl.functionContainer.replaceArgument(new AttributeField("domain", domain));
				} catch (IncompatibleNumberObjectTypeException | RestrictionViolationException | UnknownArgumentException e) {ObserverManager.notifyObserversOfError(e);}
		}
	}

	/** Removes the belief from this object. Does not delete the belief from the View (however, it does update the view,
	 * and as this object no longer has a belief, no new belief is added after updating). Also removes all
	 * patch state offsets associated with the belief. */
	private void removeBelief(){
		View.getView().workspace.removeAllElementsContainingBelief(this.belief);
		this.belief = null;
	}

	/** Remove the cue to this object. Overwrites existing cues (there can only be 1 cue per object, but a cue
	 * can have multiple labels*/
	public void removeCue(CueTemplate cue){
		this.cue = null;
	}

	/** Transforms a sentence string to a set of labels containing individual words. These labels come with the StyleClass.
	 * Each label (expect for the last one) ends with a space. */
	public static ArrayList<Label> stringToSetOfLabels(String sentence, String styleClass){
		ArrayList<Label> setOfLabels = new ArrayList<>();

		String[] splits = sentence.split(" ");
		for (String word: splits){
			Label l = new Label();
			if (word != splits[splits.length-1])
				l.setText(word + " ");
			else
				l.setText(word);
			l.getStylesheets().add(cssStyleSheetLocation);
			l.getStyleClass().add(styleClass);
			setOfLabels.add(l);
		}
		return setOfLabels;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Object: "+ name + " (" + AbstractObjectiveTemplate.classToClassString(AbstractObjectiveTemplate.objectToClass(this)) + ")");
		sb.append("\n\t-Frequency: " + frequency);
		sb.append("\n\t-Domain: " + domain);
		sb.append("\n\t-Is constant? : " + isConstant);

		if (AbstractObjectiveTemplate.objectToClass(this) == PhenotypeObjectTemplate.class)
			return sb.toString();
		if (!isConstant){
			sb.append("\n\t-Observable: " + isObservable);
			if (!isObservable){
				sb.append("\n\t\t-Cue: " + cue);
				sb.append("\n\t\t-Belief: " + belief);
			}
			if (!splitOverRuns){
				sb.append("\n\t-Values sampled from: " + samplingDistributions.get(0).getRFunction().getName()+ ", with arguments: ");
				for (AttributeField af: samplingDistributions.get(0).getLoadedArguments())
					sb.append(af.getName() + "=" + af.getValueString()+ " ");
			} else {
				sb.append("\n\t-Values differ over runs, with the following values: ");
				for (RFunctionContainer dis : samplingDistributions){
					sb.append("\n\t-A " + dis.getRFunction().getName()+ ", with arguments: ");
					for (AttributeField af: dis.getLoadedArguments())
						sb.append(af.getName() + "=" + af.getValueString()+ " ");
				}

			}
		}

		return sb.toString();
	}

	/** Returns the type of this object - i.e., whether it is a phenotype, resource, interruption, delay, or extrinsic. */
	public static Class<? extends AbstractObjectiveTemplate> objectToClass(AbstractObjectiveTemplate object) {
		if (PhenotypeObjectTemplate.class.isAssignableFrom(object.getClass()))
			return PhenotypeObjectTemplate.class;

		if (ResourceObjectTemplate.class.isAssignableFrom(object.getClass()))
			return ResourceObjectTemplate.class;

		if (InterruptionObjectTemplate.class.isAssignableFrom(object.getClass()))
			return InterruptionObjectTemplate.class;

		if (DelayObjectTemplate.class.isAssignableFrom(object.getClass()))
			return DelayObjectTemplate.class;

		if (ExtrinsicObjectTemplate.class.isAssignableFrom(object.getClass()))
			return ExtrinsicObjectTemplate.class;

		throw new MissspecificationException("Found an object that is neither a phenotype, resource, interruption, delay, or extrinsic event. ");
	}

	/** Returns a clean string of the type of the specified class - i.e., whether it is a phenotype, resource, interruption, delay, or extrinsic. */
	public static String classToClassString(Class<? extends AbstractObjectiveTemplate> clazz) {
		if (PhenotypeObjectTemplate.class.isAssignableFrom(clazz))
			return "Phenotypic dimension";
		if (ResourceObjectTemplate.class.isAssignableFrom(clazz))
			return "Resource";
		if (InterruptionObjectTemplate.class.isAssignableFrom(clazz))
			return "Interruption";
		if (DelayObjectTemplate.class.isAssignableFrom(clazz))
			return "Delay";
		if (ExtrinsicObjectTemplate.class.isAssignableFrom(clazz))
			return "Extrinsic event";

		throw new MissspecificationException("Found an object that is neither a phenotype, resource, interruption, delay, or extrinsic event. ");
	}

	/** Some objects have restricted domains - e.g., the probability of an interruption cannot be lower than 1 or smaller than 0*/
	public static FieldRestriction getDomainFieldRestriction(Class<? extends AbstractObjectiveTemplate> clazz){
		if (PhenotypeObjectTemplate.class.isAssignableFrom(clazz))
			return FieldRestriction.DOUBLE;
		if (ResourceObjectTemplate.class.isAssignableFrom(clazz))
			return FieldRestriction.DOUBLE;
		if (InterruptionObjectTemplate.class.isAssignableFrom(clazz))
			return FieldRestriction.PROBABILITY;
		if (DelayObjectTemplate.class.isAssignableFrom(clazz))
			return FieldRestriction.NON_NEGATIVE_INTEGER;
		if (ExtrinsicObjectTemplate.class.isAssignableFrom(clazz))
			return FieldRestriction.DOUBLE;

		throw new MissspecificationException("Found an object that is neither a phenotype, resource, interruption, delay, or extrinsic event. ");
	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Look and feel 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void handle(MouseEvent event) {
		if (View.getView().getState() == ViewState.DECISION_STRUCTURE)
			new PopupObject(event,this);

		if (View.getView().getState() == ViewState.PATCH_AND_TIME)
			if (View.getView().getSelectedPatchState() == BaseState.get())
				ObserverManager.makeWarningToast("Cannot set offsets to the base state");
			else
				new PopupPatchStateObjectOffset(event, View.getView().getSelectedPatchState(), this);


	}


	/** Updates the look of this OBJECT*/
	public void update(){
		// Remove the ID
		this.setId("");

		// Remove height restriction
		this.setMinHeight(USE_COMPUTED_SIZE);

		// Remove all existing nodes
		this.getChildren().removeAll(this.getChildren());

		// Remove the ID
		this.setId("");

		// Remove height restriction
		this.setMinHeight(USE_COMPUTED_SIZE);

		// Set the title and subtitle
		GridPane gridTitle = new GridPane();
		gridTitle.setMinHeight(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setPrefHeight(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setMaxHeight(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setMaxWidth(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setMinWidth(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setGridLinesVisible(true);

		RowConstraints row0 = new RowConstraints(25); //title
		RowConstraints row1 = new RowConstraints(25); //subtitle
		ColumnConstraints col = new ColumnConstraints();
		col.setMinWidth(USE_COMPUTED_SIZE);
		col.setPrefWidth(USE_COMPUTED_SIZE);
		col.setMaxWidth(USE_COMPUTED_SIZE);
		col.setHgrow(Priority.ALWAYS);

		gridTitle.getRowConstraints().addAll(row0, row1);
		gridTitle.getColumnConstraints().addAll(col);
		gridTitle.setGridLinesVisible(false);
		VBox.setVgrow(gridTitle, Priority.ALWAYS);

		// Set the titleLabel
		Label titleLabel = new Label("'"+name+ "'");
		GridPane.setValignment(titleLabel, VPos.CENTER);
		GridPane.setHalignment(titleLabel, HPos.CENTER);
		titleLabel.getStyleClass().add("titleText");
		gridTitle.add(titleLabel, 0, 0);

		// Set the subtitle
		Label subLabel;
		if (this instanceof ExtrinsicObjectTemplate || this instanceof InterruptionObjectTemplate)
			subLabel = new Label("(An " + AbstractObjectiveTemplate.classToClassString(AbstractObjectiveTemplate.objectToClass(this)).toLowerCase() + ")");
		else
			subLabel = new Label("(A " + AbstractObjectiveTemplate.classToClassString(AbstractObjectiveTemplate.objectToClass(this)).toLowerCase() + " )");
		GridPane.setValignment(subLabel, VPos.TOP);
		GridPane.setHalignment(subLabel, HPos.CENTER);
		subLabel.getStyleClass().add("subtitleText");
		gridTitle.add(subLabel, 0, 1);

		this.getChildren().add(gridTitle);

		// Update this ObjectTemplate according to the View's state
		if (View.getView().getState() == ViewState.DECISION_STRUCTURE)
			updateDecisionStructure();
		if (View.getView().getState() == ViewState.PATCH_AND_TIME)
			updatePatchAndTime();
		if (View.getView().getState() == ViewState.ACTION_PHASE)
			this.updateActionPhase();
		if (View.getView().getState() == ViewState.MUTATION_PHASE)
			this.updateMutationPhase();
		if (View.getView().getState()== null){
			updateDecisionStructure();
			setDisable(true);
		}

		// Enforce the height
		Platform.runLater(() -> {
			double height = Math.max(MINIMUM_HEIGHT, heightInDecisionStructure);
			this.setMinHeight(height);
		});
	}

	/** Generate Nodes to represent the text inside the AbstractObjectiveTemplate so that it displays all the information needed for the DECISION STRUCTURE state.
	 * These nodes are placed in this (a VBOX) immediately.*/
	protected void updateDecisionStructure(){
		this.setDisable(false);
		
		ArrayList<Node> nodes = new ArrayList<>();
		TextFlow tfDomain = new TextFlow();
		nodes.add(tfDomain);
		// In the decision structure mode we have to show details about the domain, and if applicable, the observability, value, and cue
		
		// DOMAIN
		if (isConstant ){
			// Constant: only show value
			tfDomain.getChildren().addAll(stringToSetOfLabels("A "+ name.toLowerCase() + " always has a value of", "normalText"));
			tfDomain.getChildren().add(new Label(" "));
			tfDomain.getChildren().addAll(stringToSetOfLabels(this.getDomain().get(0).toStringWithoutTrailingZeros(), "domainText"));
			tfDomain.getChildren().add(new Label(". "));
		} else {

			// Domain
			tfDomain.getChildren().addAll(stringToSetOfLabels("A "+ name.toLowerCase() + " can have values that are multiples of", "normalText"));
			tfDomain.getChildren().add(new Label(" "));
			tfDomain.getChildren().addAll(stringToSetOfLabels(this.getDomainStepSize().toStringWithoutTrailingZeros() + " ", "domainText"));
			tfDomain.getChildren().add(new Label(" "));
			tfDomain.getChildren().addAll(stringToSetOfLabels(" ranging between", "normalText"));
			tfDomain.getChildren().add(new Label(" "));
			tfDomain.getChildren().addAll(stringToSetOfLabels(this.getDomainMinimum().toStringWithoutTrailingZeros(), "domainText"));
			tfDomain.getChildren().add(new Label(" "));
			tfDomain.getChildren().addAll(stringToSetOfLabels("and", "normalText"));
			tfDomain.getChildren().add(new Label(" "));
			tfDomain.getChildren().addAll(stringToSetOfLabels(this.getDomainMaximum().toStringWithoutTrailingZeros() , "domainText"));
			tfDomain.getChildren().add(new Label(". "));

			// A phenotype does not have a value, observability, or frequency. So we are done here.
			if (AbstractObjectiveTemplate.objectToClass(this) == PhenotypeObjectTemplate.class) {
				this.getChildren().addAll(nodes);
				Platform.runLater(() -> {
					this.heightInDecisionStructure = getHeight();
				});
				return ;
			}

			// Values
			TextFlow tfValues = new TextFlow();
			nodes.add(tfValues);
			if (!splitOverRuns ){
				// Only one distribution
				tfValues.getChildren().addAll(stringToSetOfLabels("- Values are sampled from a", "normalText"));
				tfValues.getChildren().add(new Label(" "));
				tfValues.getChildren().addAll(stringToSetOfLabels(this.getSamplingDistribution().getRFunction().getName().toLowerCase()+ " ", "valueText"));
				tfValues.getChildren().add(new Label(" "));

				ArrayList<AttributeField> excludingDomain = new ArrayList<>();
				for (AttributeField af: samplingDistributions.get(0).getLoadedArguments())
					if (!af.getName().equalsIgnoreCase("domain"))
						excludingDomain.add(af);

				if (excludingDomain.size()>0)
					tfValues.getChildren().addAll(stringToSetOfLabels("where", "normalText"));
				for (int i = 0; i <  excludingDomain.size(); i ++){
					AttributeField af = excludingDomain.get(i);
					tfValues.getChildren().addAll(stringToSetOfLabels(" the", "normalText"));
					tfValues.getChildren().add(new Label(" "));
					tfValues.getChildren().addAll(stringToSetOfLabels(af.getName().toUpperCase()+ " is " + af.getValueStringWithoutTrailingZeros(), "valueText"));
					if (i !=  excludingDomain.size()-1 && excludingDomain.size()>1)
						tfValues.getChildren().addAll(stringToSetOfLabels(", and ", "normalText"));
				}
				tfValues.getChildren().add(new Label(". "));

				// Multiple distributions
			} else {
				this.setId("useMultipleDistributions");
				tfValues.getChildren().addAll(stringToSetOfLabels("- Values are sampled from multiple ", "normalText"));
				tfValues.getChildren().add(new Label(" "));
				tfValues.getChildren().addAll(stringToSetOfLabels(this.getPreviousRuntimeParameterFunction().getName().toLowerCase()+ "s", "valueText"));

				ArrayList<AttributeField> excludingDomain = new ArrayList<>();
				for (AttributeField af: getPreviousRuntimeParameterFunction().getInputFieldCopy())
					if (!af.getName().equalsIgnoreCase("domain"))
						excludingDomain.add(af);

				if (excludingDomain.size()>0)
					tfValues.getChildren().addAll(stringToSetOfLabels(" where", "normalText"));
				for (int i = 0; i < excludingDomain.size(); i++){
					AttributeField af =excludingDomain.get(i);

					String from = lastUsedParameters.get(i)[0].getValueStringWithoutTrailingZeros();
					String to = lastUsedParameters.get(i)[1].getValueStringWithoutTrailingZeros();
					String stepsize = lastUsedParameters.get(i)[2].getValueStringWithoutTrailingZeros();
					tfValues.getChildren().addAll(stringToSetOfLabels(" the ", "normalText"));
					tfValues.getChildren().add(new Label(" "));
					tfValues.getChildren().addAll(stringToSetOfLabels(af.getName().toUpperCase(), "valueText"));
					tfValues.getChildren().addAll(stringToSetOfLabels(" ranges from", "normalText"));
					tfValues.getChildren().add(new Label(" "));
					tfValues.getChildren().addAll(stringToSetOfLabels(from, "valueText"));
					tfValues.getChildren().add(new Label(" "));
					tfValues.getChildren().addAll(stringToSetOfLabels("to", "normalText"));
					tfValues.getChildren().add(new Label(" "));
					tfValues.getChildren().addAll(stringToSetOfLabels(to, "valueText"));
					tfValues.getChildren().add(new Label(" "));
					tfValues.getChildren().addAll(stringToSetOfLabels(" with increments of", "normalText"));
					tfValues.getChildren().add(new Label(" "));
					tfValues.getChildren().addAll(stringToSetOfLabels(stepsize, "valueText"));
					if (i !=  excludingDomain.size()-1 && excludingDomain.size()>1)
						tfValues.getChildren().addAll(stringToSetOfLabels(", and ", "normalText"));
					tfValues.getChildren().add(new Label(". "));
				}

			}
		}

		// Observable?
		TextFlow tfObservable = new TextFlow();
		nodes.add(tfObservable);
		if (isObservable()){
			tfObservable.getChildren().addAll(stringToSetOfLabels("- Values are directly observable", "normalText"));
			tfObservable.getChildren().add(new Label(". "));

		} else {
			if (!isConstant){
				tfObservable.getChildren().addAll(stringToSetOfLabels("- Values are not observable", "normalText"));
				tfObservable.getChildren().add(new Label(". "));
				if (getCueTemplate() != null){
					tfObservable.getChildren().add(new Label(" "));
					tfObservable.getChildren().addAll(stringToSetOfLabels("However, there are ", "normalText"));
					tfObservable.getChildren().add(new Label(" "));
					tfObservable.getChildren().addAll(stringToSetOfLabels("cues", "cueText"));
					tfObservable.getChildren().add(new Label(" "));
					tfObservable.getChildren().addAll(stringToSetOfLabels(" that can have ", "normalText"));
					tfObservable.getChildren().add(new Label(" "));
					tfObservable.getChildren().addAll(stringToSetOfLabels(getCueTemplate().cueLabels.size()+"", "cueText"));
					tfObservable.getChildren().add(new Label(" "));
					tfObservable.getChildren().addAll(stringToSetOfLabels("labels:", "normalText"));
					for (CueLabel cl : getCueTemplate().cueLabels){
						tfObservable.getChildren().add(new Label(" "));
						tfObservable.getChildren().addAll(stringToSetOfLabels(cl.name+" ", "cueText"));
					}
					tfObservable.getChildren().addAll(stringToSetOfLabels(")", "normalText"));
					tfObservable.getChildren().add(new Label(". "));
				}
			}
		}
		
		// Frequency
		TextFlow tfFrequency = new TextFlow();
		nodes.add(tfFrequency);
		if (frequency != null){
			tfFrequency.getChildren().addAll(stringToSetOfLabels("- A "+ name.toLowerCase() + " occurs with a frequency of", "normalText"));
			tfFrequency.getChildren().add(new Label(" "));
			tfFrequency.getChildren().addAll(stringToSetOfLabels(this.frequency.toStringWithoutTrailingZeros(), "domainText"));
			tfFrequency.getChildren().add(new Label(" "));
		}

		this.getChildren().addAll(nodes);
		// Save the height. Note that the first time that an ObjectTemplate is drawn, it is updated before JavaFX is done drawing it.
		// (Yes, it's one of those annoying javafx things). Hence, a runlater threat that will fire after the UI is done doing its thing.
		Platform.runLater(() -> {
			this.heightInDecisionStructure = getHeight();
		});

	}


	/** Update the objects so that it displays all the information needed for the PATCH AND TIME state*/
	protected void updatePatchAndTime(){

		PatchStateTemplate selectedState = View.getView().getSelectedPatchState();
		if (selectedState == BaseState.get()){
			TextFlow tf = new TextFlow();
			this.getChildren().add(tf);
			tf.getChildren().addAll(stringToSetOfLabels("You cannot set an offset to an object in the base state", "normalText"));
			this.setDisable(true);
			return;
		}

		if (objectToClass(this) == PhenotypeObjectTemplate.class){
			TextFlow tf = new TextFlow();
			this.getChildren().add(tf);
			tf.getChildren().addAll(stringToSetOfLabels("Phenotypic states cannot have an offset", "normalText"));
			this.setDisable(true);
			return;
		}

		if (this.isConstant){
			TextFlow tf = new TextFlow();
			this.getChildren().add(tf);
			tf.getChildren().addAll(stringToSetOfLabels("Constant values cannot have an offset", "normalText"));
			this.setDisable(true);
			return;
		}

		this.setDisable(false);


		// If there is no offset, no need to show anything
		if (!selectedState.hasOffsetFor(this)){
			TextFlow tf = new TextFlow();
			this.getChildren().add(tf);
			this.setId("noPatchOffset");
			tf.getChildren().addAll(stringToSetOfLabels("There is no offset for this object in this patch. Click to set an offset.", "normalText"));
			return;
		}

		// Textflow for frequency offsets
		TextFlow tfFrequency = new TextFlow();
		this.getChildren().add(tfFrequency);
		
		if (selectedState.hasFrequencyOffsetFor(this) ) {
			this.setId("hasPatchOffset");
			tfFrequency.getChildren().addAll(stringToSetOfLabels("In this patch state " + this.getName().toLowerCase() + " has a different frequency.", "normalText"));
			tfFrequency.getChildren().add(new Label(" "));
			tfFrequency.getChildren().addAll(stringToSetOfLabels("The modified frequency is: ", "normalText"));
			tfFrequency.getChildren().add(new Label("  "));
			tfFrequency.getChildren().addAll(stringToSetOfLabels(this.frequency.toStringWithoutTrailingZeros(), "normalText"));
			tfFrequency.getChildren().addAll(stringToSetOfLabels(" + ", "normalText"));
			tfFrequency.getChildren().addAll(stringToSetOfLabels(selectedState.getFrequencyOffsets(this).toStringWithoutTrailingZeros()+"", "domainText"));
			tfFrequency.getChildren().add(new Label(" "));
		}

		// Value offset textFlow
		TextFlow tfValue = new TextFlow();
		this.getChildren().add(tfFrequency);
		
		if (selectedState.hasValueOffsetFor(this) && !splitOverRuns){
			this.setId("hasPatchOffset");
			tfValue.getChildren().addAll(stringToSetOfLabels("In this patch state " + this.getName().toLowerCase() + " values are sampled from a different distribution. They are sampled from a", "normalText"));
			tfValue.getChildren().add(new Label(" "));
			tfValue.getChildren().addAll(stringToSetOfLabels(this.getSamplingDistribution().getRFunction().getName().toLowerCase()+ " ", "normalText"));
			tfValue.getChildren().add(new Label(" "));

			ArrayList<AttributeField> excludingDomain = new ArrayList<>();
			for (AttributeField af: samplingDistributions.get(0).getLoadedArguments())
				if (!af.getName().equalsIgnoreCase("domain"))
					excludingDomain.add(af);

			if (excludingDomain.size()>0)
				tfValue.getChildren().addAll(stringToSetOfLabels(" where", "normalText"));
			for (int i = 0; i <  excludingDomain.size(); i ++){
				AttributeField af = excludingDomain.get(i);
				tfValue.getChildren().addAll(stringToSetOfLabels(" the ofsetted", "normalText"));
				tfValue.getChildren().add(new Label(" "));
				tfValue.getChildren().addAll(stringToSetOfLabels(af.getName().toUpperCase(), "valueText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(" is " , "normalText"));
				tfValue.getChildren().add(new Label(" "));
				tfValue.getChildren().addAll(stringToSetOfLabels(af.getValueStringWithoutTrailingZeros(), "normalText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(" + ", "normalText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(selectedState.getValueOffsets(this, af.getName()).getValueStringWithoutTrailingZeros(), "valueText"));
				if (i !=  excludingDomain.size()-1 && excludingDomain.size()>1)
					tfValue.getChildren().addAll(stringToSetOfLabels(", and ", "normalText"));
			}
			tfValue.getChildren().add(new Label(". "));
		}


		if (selectedState.hasValueOffsetFor(this) && splitOverRuns){
			this.setId("useMultipleHasOffset");

			tfValue.getChildren().addAll(stringToSetOfLabels("In this patch state " + this.getName().toLowerCase() + " values are sampled from  different distributions. They are sampled from multiple ", "normalText"));
			tfValue.getChildren().add(new Label(" "));
			tfValue.getChildren().addAll(stringToSetOfLabels(this.getPreviousRuntimeParameterFunction().getName().toLowerCase()+ "s", "normalText"));

			ArrayList<AttributeField> excludingDomain = new ArrayList<>();
			for (AttributeField af: getPreviousRuntimeParameterFunction().getInputFieldCopy())
				if (!af.getName().equalsIgnoreCase("domain"))
					excludingDomain.add(af);

			if (excludingDomain.size()>0)
				tfValue.getChildren().addAll(stringToSetOfLabels("where", "normalText"));
			for (int i = 0; i < excludingDomain.size(); i++){
				AttributeField af =excludingDomain.get(i);

				String from = lastUsedParameters.get(i)[0].getValueStringWithoutTrailingZeros();
				String to = lastUsedParameters.get(i)[1].getValueStringWithoutTrailingZeros();
				String stepsize = lastUsedParameters.get(i)[2].getValueStringWithoutTrailingZeros();
				tfValue.getChildren().addAll(stringToSetOfLabels(" the offsetted", "normalText"));
				tfValue.getChildren().add(new Label(" "));
				tfValue.getChildren().addAll(stringToSetOfLabels(af.getName().toUpperCase(), "valueText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(" ranges from (", "normalText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(from, "normalText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(" + ", "normalText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(selectedState.getValueOffsets(this, af.getName()).getValueStringWithoutTrailingZeros(),  "valueText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(")", "normalText"));
				tfValue.getChildren().add(new Label(" "));
				tfValue.getChildren().addAll(stringToSetOfLabels("to (", "normalText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(to, "normalText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(" + ", "normalText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(selectedState.getValueOffsets(this, af.getName()).getValueStringWithoutTrailingZeros(),  "valueText"));
				tfValue.getChildren().addAll(stringToSetOfLabels(")", "normalText"));
				tfValue.getChildren().add(new Label(" "));
				tfValue.getChildren().addAll(stringToSetOfLabels(" with increments of", "normalText"));
				tfValue.getChildren().add(new Label(" "));
				tfValue.getChildren().addAll(stringToSetOfLabels(stepsize, "normalText"));
				if (i !=  excludingDomain.size()-1 && excludingDomain.size()>1)
					tfValue.getChildren().addAll(stringToSetOfLabels(", and ", "normalText"));
			}

		}
		
		// Save the height. Note that the first time that an ObjectTemplate is drawn, it is updated before JavaFX is done drawing it.
		// (Yes, it's one of those annoying javafx things). Hence, a runlater threat that will fire after the UI is done doing its thing.
		Platform.runLater(() -> {
			this.heightInDecisionStructure = getHeight();
		});
	}

	/** Update the objects so that it displays all the information needed for the ENVIRONMENT ACTIONS state*/
	protected void updateActionPhase(){
		this.updateDecisionStructure();
		this.setDisable(true);
	}

	/** Update the objects so that it displays all the information needed for the AGENT ACTIONS state*/
	protected void updateMutationPhase(){
		this.updateDecisionStructure();
		this.setDisable(true);
	}

}
