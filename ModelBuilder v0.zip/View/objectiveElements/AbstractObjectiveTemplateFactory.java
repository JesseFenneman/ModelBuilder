package objectiveElements;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import attributes.AttributeField;
import attributes.AttributeField.IncompatibleNumberObjectTypeException;
import decimalNumber.DecimalNumber;
import rIntegration.RFunction;
import rIntegration.RFunctionContainer;

/** A Factory class for AbstractObjectiveTemplate*/
public class AbstractObjectiveTemplateFactory{
	@SuppressWarnings("serial")
	public static class IncorrectObjectSpecifcationException extends RuntimeException { public IncorrectObjectSpecifcationException(String message) {     super(message);  }}

	private String name;
	private Class<? extends AbstractObjectiveTemplate> type;
	private DecimalNumber frequency;

	private boolean isConstant;
	private DecimalNumber constantValue;
	private DecimalNumber domainMinimum, domainMaximum, domainStep;

	private boolean isObservable;
	private CueTemplate cue;

	private boolean hasOneSamplingDistribution;
	private RFunctionContainer samplingDistribution;
	private RFunction multipleDistribution;
	private ArrayList<AttributeField[]> distributionArguments;

	public AbstractObjectiveTemplateFactory() {}

	/** Set the to-be-object's name. Returns this.*/
	public AbstractObjectiveTemplateFactory setName(String name) {
		this.name = name;
		return this;
	}

	/** Set the to-be-object's type (i.e., phenotype, resource, interruption, delay, or extrinsic. Returns this.*/
	public AbstractObjectiveTemplateFactory setType(Class<? extends AbstractObjectiveTemplate> type) {
		this.type = type;
		return this;
	}

	/** Set the to-be-object's name. Returns this.*/
	public AbstractObjectiveTemplateFactory setFrequency(DecimalNumber frequency) {
		this.frequency = frequency;
		return this;
	}

	/** Set the to-be-object to have a fixed value. Overwrite all other domain settings. Returns this. */
	public AbstractObjectiveTemplateFactory setConstant(DecimalNumber constantValue) {
		this.isConstant = true;
		this.constantValue = constantValue;
		return this;
	}

	/** Set the to-be-object to have a ranged domain. Overwrite all other domain settings. Returns this. */
	public AbstractObjectiveTemplateFactory setRange(DecimalNumber minimum, DecimalNumber maximum, DecimalNumber stepSize) {
		this.isConstant = false;
		this.domainMinimum = minimum;
		this.domainMaximum = maximum;
		this.domainStep = stepSize;
		return this;
	}

	/** Sets the observability of the to-be-object. Overwrites all other observability settings. Returns this. */
	public AbstractObjectiveTemplateFactory setObservability (boolean isObservable) {
		this.isObservable = isObservable;

		return this;
	}

	/** Sets a cue for the to-be-object. Overwrites all other observability settings. Returns this. */
	public AbstractObjectiveTemplateFactory setCueTemplate (CueTemplate cueTemplate) {
		this.isObservable = false;
		this.cue = cueTemplate;
		return this;
	}

	/** Set the RFunctionContainer as the sampling distribution for this object. Overwrites all other
	 * value settings. Returns this*/
	public AbstractObjectiveTemplateFactory setSingleSamplingDistribution(RFunctionContainer samplingDistribution){
		this.hasOneSamplingDistribution= true;
		this.samplingDistribution = samplingDistribution;
		return this;
	}

	/** Set the to-be-object to run multiple sampling distributions over runs. Overwrites all other
	 * value settings. Returns this*/
	public AbstractObjectiveTemplateFactory setMultipleSamplingDistributions(RFunction multipleDistribution, ArrayList<AttributeField[]> distributionArguments){
		this.hasOneSamplingDistribution= false;
		this.multipleDistribution = multipleDistribution;
		this.distributionArguments = distributionArguments;
		return this;
	}

	/** Constructs a AbstractObjectiveTemplate with the specification of the factory.
	 * Throws an incorrectObjectSpecifcationException if at least one field is not properly specified. 
	 * @throws RestrictionViolationException 
	 * @throws IncompatibleNumberObjectTypeException */
	public AbstractObjectiveTemplate build () throws IncorrectObjectSpecifcationException, IncompatibleNumberObjectTypeException, RestrictionViolationException{
		AbstractObjectiveTemplate newObject = null;

		// Determine the type
		if (type == DelayObjectTemplate.class)
			newObject = new DelayObjectTemplate();
		if (type == ExtrinsicObjectTemplate.class)
			newObject = new ExtrinsicObjectTemplate();
		if (type == InterruptionObjectTemplate.class)
			newObject = new InterruptionObjectTemplate();
		if (type == ResourceObjectTemplate.class)
			newObject = new ResourceObjectTemplate();
		if (type == PhenotypeObjectTemplate.class)
			newObject = new PhenotypeObjectTemplate();

		// Determine name
		if (this.name == null)
			throw new IncorrectObjectSpecifcationException("AbstractObjectiveTemplate has no name when calling factory build.");
		newObject.name = this.name;

		// Determine Frequency
		if (this.frequency == null)
			if (type != InterruptionObjectTemplate.class && type != PhenotypeObjectTemplate.class)
				throw new IncorrectObjectSpecifcationException("AbstractObjectiveTemplate has no frequency when calling factory build.");
		newObject.setFrequency(frequency);

		// Determine domain
		// Interruptions have a fixed domain (0 or 1). All other types can have other domains
		if (type != InterruptionObjectTemplate.class) {
			if (isConstant){
				if (this.constantValue == null)
					throw new IncorrectObjectSpecifcationException("AbstractObjectiveTemplate has no constant value when calling factory build.");
				newObject.setDomainFixed(constantValue);
			} else {
				if (this.domainMinimum == null)
					throw new IncorrectObjectSpecifcationException("AbstractObjectiveTemplate has no minimum domain when calling factory build.");
				if (this.domainMaximum == null)
					throw new IncorrectObjectSpecifcationException("AbstractObjectiveTemplate has no maximum domain when calling factory build.");
				if (this.domainStep == null)
					throw new IncorrectObjectSpecifcationException("AbstractObjectiveTemplate has no step size domain when calling factory build.");

				newObject.setDomainRange(domainMinimum, domainMaximum, domainStep);
			}
		} else {
			// Set the domain of an interruption
			newObject.setDomainRange(new DecimalNumber(0), new DecimalNumber(1), new DecimalNumber(1));
		}
			

		// Constant values and phenotypes do not have to have an observability or values
		if (!isConstant && type != PhenotypeObjectTemplate.class){
			// Determine observability
			newObject.setObservable(isObservable);
			if (this.cue != null){
				newObject.setCueTemplate(cue);
				cue.object = newObject;
			}

			// Determine values
			if (hasOneSamplingDistribution){
				if (this.samplingDistribution == null )
					throw new IncorrectObjectSpecifcationException("AbstractObjectiveTemplate has no sampling distribution when calling factory build.");
				newObject.setSingleSamplingDistribution(samplingDistribution);
			} else {
				if (this.multipleDistribution == null)
					throw new IncorrectObjectSpecifcationException("AbstractObjectiveTemplate has no sampling distribution type when calling factory build.");
				if (this.distributionArguments == null)
					throw new IncorrectObjectSpecifcationException("AbstractObjectiveTemplate has no sampling distribution arguments when calling factory build.");

				newObject.setMultipleSamplingDistributions(multipleDistribution, distributionArguments);
			}
		}
		return newObject;

	}

}
