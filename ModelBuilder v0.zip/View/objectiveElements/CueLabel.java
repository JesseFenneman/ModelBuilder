package objectiveElements;

import java.io.Serializable;
import java.util.ArrayList;

import attributes.AttributeField;
import rIntegration.RFunctionContainer;
import start.CentralExecutive;

/** A cue consists of labels. Each label has an emission probability function:
 * what is the probability that a resource with value x emits a cue with that label?
 * Note that the sum of all labels emitted by a resource with value x does not sum
 * to 1. The emission probability function is not (yet) a cue emission matrix! Also,
 * because the domain of the object is not set in stone yet, we do not instantiate yet,
 * rather, we just save the function call, and execute it when during the runtime of the
 * model. */
public class CueLabel implements Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public String name;
	public RFunctionContainer functionContainer;

	public CueLabel(String name, RFunctionContainer rfc){
		this.name = name; 
		this.functionContainer = rfc;
	}

	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("'"+ name + "' (" + functionContainer.getRFunction().getName()+ "");
		ArrayList<AttributeField> inputs = functionContainer.getLoadedArguments();
		
		for (int i = 0; i < inputs.size(); i++){
			sb.append(inputs.get(i).getName().toUpperCase() + "="+inputs.get(i).getValueStringWithoutTrailingZeros());
			if (i != inputs.size()-1)
				sb.append(", ");
		}
		return sb.toString();
	}
}