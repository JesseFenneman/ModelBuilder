package objectiveElements;

/** An instance to represent a null (i.e., none selected) reference.
 * There can only be one InstanceNull for each separate type (resource, interruption, delay, extrinsic) at any time*/
public class InstanceNull implements InstanceReference{

	// Use multiple SingletonPatterns
	private static InstanceNull instanceResource, instanceExtrinsic, InstanceDelay, InstanceInterruption;
		
	private final String name;
	private final Class<? extends AbstractObjectiveTemplate> clazz;
	
	private InstanceNull(String name, Class<? extends AbstractObjectiveTemplate> clazz) {
		this.name = name;
		this.clazz = clazz;
	}
	
	public static InstanceNull getNullInstanceForResources() {
		if (instanceResource == null)
			instanceResource = new InstanceNull("No resource", ResourceObjectTemplate.class);
		return instanceResource;
	}
	
	public static InstanceNull getNullInstanceForInterruptions() {
		if (InstanceInterruption == null)
			InstanceInterruption = new InstanceNull("No interruption", InterruptionObjectTemplate.class);
		return InstanceInterruption;
	}
	
	public static InstanceNull getNullInstanceForDelays() {
		if (InstanceDelay == null)
			InstanceDelay = new InstanceNull("No delay", DelayObjectTemplate.class);
		return InstanceDelay;
	}
	
	public static InstanceNull getNullInstanceForExtrinsicEvents() {
		if (instanceExtrinsic == null)
			instanceExtrinsic = new InstanceNull("No extrinsic event", ExtrinsicObjectTemplate.class);
		return instanceExtrinsic;
	}
	
	public static boolean isNullReference(InstanceReference ref) {
		if (ref == instanceResource)
			return true;
		if (ref == InstanceInterruption)
			return true;
		if (ref == InstanceDelay)
			return true;
		if (ref == instanceExtrinsic)
			return true;
		return false;
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return name;
	}
	
	@Override
	public AbstractObjectiveTemplate getAbstractObjectiveTemplate() {
		return null;
	}

	@Override
	public Class<? extends AbstractObjectiveTemplate> getClassType() {
		return clazz;
	}
	

}
