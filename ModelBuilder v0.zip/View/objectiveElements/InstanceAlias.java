package objectiveElements;

import java.io.Serializable;

import helper.Helper;
import start.CentralExecutive;
import view.View;

/** An InstanceAlias is an object that links a name to 
 * an instance. In a way, it is just another name to
 * refer to that instance. If an Alias is created with
 * another Alias, the new Alias will point directly towards
 * the first Alias's Instance (pass by reference).
 * 
 * An InstanceAlias can be changed to refer to a different object (even during runtime of the model!), 
 * BUT the object has to always be of the same class. For instance, if an Alias
 * is created to refer to a 'Resource', it must ALWAYS refer to a 'Resource'.*/
public class InstanceAlias implements InstanceReference, Serializable {

	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	private final 	String nameOfAlias;
	
	//  To insure that an InstanceAlias always points to an Alias, an Alias MUST refer to a specific object when it is first created.
	// Afterwards, the Alias might point to another object.
	private final 	Instance initialInstance; 
	
	
	
	/** 
	 * An InstanceAlias must always refer to an Instance - although it
	 * can change to which instance it refers to. However, we want to 
	 * avoid situations where there is an Alias that does not point
	 * to an Instance. To avoid this, we force the user to first set
	 * an InstanceAlias before it can subsequently be changed.
	 * @param nameOfAlias
	 * @param initialInstanceName
	 */
	public InstanceAlias (String nameOfAlias, String initialInstanceName) {
		// Check if the supplied nameOfAlias is indeed a string:
		if (nameOfAlias == null)
			throw new IllegalArgumentException("Cannot create an InstanceAlias a name.");
		if (initialInstanceName == null)
			throw new IllegalArgumentException("Cannot create an InstanceAlias without specifying the name of the initial instance to be cloned.");
		
		Instance init = View.getView().workspace.getInstance(initialInstanceName);
		if (init == null) {
			InstanceAlias a = View.getView().workspace.getInstanceAlias(initialInstanceName);
			if (a == null)
				throw new IllegalStateException("Cannot create InstanceAlias that refers to '" + initialInstanceName + "' as no such object exists in the workspace.");
			init = a.getInitialInstance();
		}
		
		if (init == null)
			throw new IllegalArgumentException("Trying to create an InstanceAlias that has a non-existing initial Instance.");
		if (View.getView().workspace.getInstanceAlias(nameOfAlias) != null)
			throw new IllegalArgumentException("Trying to create an InstanceAlias with name '" + nameOfAlias + "'. However, there already is an InstanceAlias with that name");
		if (View.getView().workspace.getInstance(nameOfAlias) != null)
			throw new IllegalArgumentException("Trying to create an InstanceAlias with name '" + nameOfAlias + "'. However, there already is an Instance with that name");
		
		if (!Helper.isVariableName(nameOfAlias))
			throw new IllegalArgumentException("Trying to create an InstanceAlias with name '" + nameOfAlias + "'. However, that is not a valid variable name.");
		
		this.nameOfAlias= nameOfAlias;
		initialInstance = View.getView().workspace.getInstance(initialInstanceName);


	}
	
	/** Ideally, we would be able to use an InstanceReference in place of an Instance throughout. However, there are
	 * some issues that arise when we do not know the type of the InstanceAlias during the runtime of the model.
	 * For example, suppose that we want to sample a cue about the value of the Aliased instance. This is a valid action if the InstanceAlias
	 * points towards an AbstractObjectiveTemplate that generates cues. This action is not valid if the Alias points
	 * towards an AbstractObjectiveTemplate that does not generate cues. As we can shift the instance the alias points to during runtime,
	 * this creates a problem: how do we know that we can sample the InstanceAlias - which can refer to different objects - can be
	 * sampled for cues?
	 * 
	 * The solution is simple, but somewhat limiting: once set to a certain type of AbstractObjectiveTemplate (e.g., an AbstractResourceTemplate with the name 'res'),
	 * the InstanceAlias can only ever refer to an Instance with that type (e.g., only to other instances from the type of 'res'). 
	 * TODO: Future versions of FMB might come up with a different way of tackling this.**/
	public boolean canBeSetTo (InstanceReference newReference) {
		if (newReference == this)
			return false;
		
		if (newReference instanceof Instance) {
			Instance instance = ((Instance) newReference);
			if (instance.getAbstractObjectiveTemplate() == this.initialInstance.getAbstractObjectiveTemplate())
				return true;
		}
		
		if (newReference instanceof InstanceAlias) {
			InstanceAlias alias= ((InstanceAlias) newReference);
			if (alias.initialInstance.getAbstractObjectiveTemplate() == this.initialInstance.getAbstractObjectiveTemplate())
				return true;
		}
			
		return false;
	}
	
	
	/** Returns the class of the Instance that this Alias is referring to (i.e.,
	 * Resource, Extrinsic, or Delay). */
	public Class<? extends AbstractObjectiveTemplate> getClassType (){
		return initialInstance.getClassType();
	}
	
	/** An InstanceAlias can be changed to refer to another Instance - if the new
	 * InstanceReference refers to an instance of the same class (i.e., Resource,
	 * Delay, or Extrinsic).*/
	public boolean hasSameClass(InstanceReference other) {
		return this.getClassType() == other.getClassType();
	}
	

	public Instance getInitialInstance () {
		return this.initialInstance;
	}

	public String toString() { return "'" + nameOfAlias + "' (Alias, Class: "+ this.getClassType()+ ")";}



	@Override
	public String getName() {
	
		return nameOfAlias;
	}

	@Override
	public AbstractObjectiveTemplate getAbstractObjectiveTemplate() {
		return initialInstance.getAbstractObjectiveTemplate();
	}



	


}
