package objectiveElements;

import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import start.CentralExecutive;

public class ExtrinsicObjectTemplate extends AbstractObjectiveTemplate {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public ExtrinsicObjectTemplate() {
		super();
	}

	@Override
	public void setFrequency(DecimalNumber frequency) {
		this.frequency = frequency.clone();
		frequency.setRange(0, 1);
	}

	@Override
	public boolean setDomainRange(DecimalNumber minimum, DecimalNumber maximum, DecimalNumber stepsize) {
		if (maximum.smallerThan(minimum))
			throw new IllegalArgumentException("Error when creating new extrinsic object: maximum domain cannot be smaller than minimum domain.");

		this.isConstant = false;
		this.minimum = minimum;
		this.maximum = maximum;
		this.stepsize = stepsize;
		this.domain = DecimalNumberArray.allMultiplesInRange(minimum, maximum, stepsize);
		return true;
	}

	@Override
	public boolean setDomainFixed(DecimalNumber fixedValue) {
		this.isConstant = true;
		this.domain = new DecimalNumberArray(fixedValue);
		this.minimum = fixedValue;
		this.maximum = fixedValue;
		this.stepsize = null;
		this.belief = null;
		return true;
	}

}
