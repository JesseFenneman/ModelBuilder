package objectiveElements;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.text.TextFlow;
import start.CentralExecutive;
import view.View;

/** A recurring resource is consumed (without removing the resource) every x time steps, unless
 * an interruptions takes place. An interruption does not remove the resource from the slot.  */
public class PhenotypeSlotTemplateRecurringResource extends AbstractPhenotypeSlotTemplate{

	private static final long serialVersionUID = CentralExecutive.programVersion;

	// Not all interruptions can be used in this slot. This HashMap provides a boolean for each possible interruption. 
	private final HashMap<InterruptionObjectTemplate, Boolean> hashMapInterruptions;

	private int periodicity;

	/** Creates a new slot template. Adds all the resources and delays in the workspace to this slot. The default is
	 * that all resource or delays can be used.*/
	public PhenotypeSlotTemplateRecurringResource(String name, boolean isOverwritable, int periodicity) {
		this();
		this.name=name;
		this.isOverwritable=isOverwritable;
		this.periodicity=periodicity;
	}

	/** Creates a new slot template. Adds all the resources and delays in the workspace to this slot. The default is
	 * that all resource or delays can be used.*/
	public PhenotypeSlotTemplateRecurringResource() {
		super();

		this.hashMapInterruptions = new HashMap<>();

		for (InterruptionObjectTemplate i  : View.getView().workspace.getAllInterruptionObjects())
			this.hashMapInterruptions.put(i, true);

		update();
	}

	/** Modifies the periodicity of this slot */
	public void setPeriodicity(int periodicity) {
		if (periodicity < 1)
			throw new IllegalArgumentException("Cannot use a non-positive, non-zero number as a periodicity - tried to use: " + periodicity);
		this.periodicity=periodicity;
	}


	/** Gets the periodicity of this slot*/
	public int getPeriodicity () {
		return this.periodicity;
	}


	/** Can the specified InterruptionObjectTemplate be used in this slot?*/
	public boolean canUseInterruption(InterruptionObjectTemplate interruption) {
		if (!this.hashMapInterruptions.containsKey(interruption))
			throw new IllegalArgumentException("Trying to get whether an interruption can be used in a slot, but the interruption is not yet in the HashMap.");

		return hashMapInterruptions.get(interruption);
	}

	/** Can the specified InstanceReference be used as an resource in this slot?*/
	public boolean canUseAsInterruption(InstanceReference interruptionReference) {
		if (interruptionReference == InstanceNull.getNullInstanceForInterruptions())
			return true;
		
		if (!this.hashMapInterruptions.containsKey(interruptionReference.getAbstractObjectiveTemplate()))
			throw new IllegalArgumentException("Trying to get whether an interruption instance can be used in a slot, but the AbstractObjectiveTemplate of this interruption is not yet in the HashMap.");

		return hashMapInterruptions.get(interruptionReference.getAbstractObjectiveTemplate());
	}

	/** Modifies whether the specified InterruptionObjectTemplate can be used in this slot*/
	public void modifyCanUseInterruption(InterruptionObjectTemplate interruption, boolean possibleToUse) {
		if (!this.hashMapInterruptions.containsKey(interruption))
			throw new IllegalArgumentException("Modifying an interruption to use in a slot, but the interruption is not yet in the HashMap.");

		hashMapInterruptions.put(interruption, possibleToUse);
	}


	/** Should be called by the Workspace whenever a new interruption is added to the Workspace*/
	public void addInterruptionType(InterruptionObjectTemplate newInterruption,  boolean possibleToUse) {
		this.hashMapInterruptions.put(newInterruption, possibleToUse);
	}

	/** Should be called by the Workspace whenever the Interruption is removed from the Workspace*/
	public void removeInterruptionType(InterruptionObjectTemplate toBeRemovedInterruption) {
		this.hashMapInterruptions.remove(toBeRemovedInterruption);
	}



	/** Sets whether this slot can be overwritten by a new resource (true), or whether this slot can only be filled with a new entry if the current entry
	 * is finished (false)*/
	@Override
	public void setOverwritable(boolean isOverwritable) {
		this.isOverwritable= isOverwritable;
	}

	@Override
	public SlotType getSlotType() {
		return SlotType.RECURRING_RESOURCE;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(name + ". A recurring resource slot. This slot stores resources of types: ");

		// Permissible resources
		ArrayList<ResourceObjectTemplate> permissibleResources = new ArrayList<>();
		for (ResourceObjectTemplate r : this.hashMapResources.keySet())
			if (hashMapResources.get(r))
				permissibleResources.add(r);
		for (int i = 0; i < permissibleResources.size(); i++) {
			sb.append(permissibleResources.get(i).getName());
			if (i == permissibleResources.size()-2 && permissibleResources.size() > 1)
				sb.append(", and ");
			else if (i < permissibleResources.size()-1)
				sb.append(", ");
		}

		// Permissible phenotypes
		sb.append(". These resources can effect these phenotypic dimensions: ");
		ArrayList<PhenotypeObjectTemplate> permissiblePhenotypes = new ArrayList<>();
		for (PhenotypeObjectTemplate p : this.hashMapPhenotypes.keySet())
			if (hashMapPhenotypes.get(p))
				permissiblePhenotypes.add(p);

		for (int i = 0; i < permissiblePhenotypes.size(); i++) {
			sb.append(permissiblePhenotypes.get(i).getName());
			if (i == permissiblePhenotypes.size()-1 && permissiblePhenotypes.size() > 1)
				sb.append(", and ");
			else if (i < permissiblePhenotypes.size()-1)
				sb.append(", ");
		}

		sb.append(". Resources are consumed every " + this.periodicity + " time steps");

		// Permissible interruptions
		ArrayList<InterruptionObjectTemplate> permissibleInterruptions = new ArrayList<>();
		for (InterruptionObjectTemplate i : this.hashMapInterruptions.keySet())
			if (hashMapInterruptions.get(i))
				permissibleInterruptions.add(i);

		if (permissibleInterruptions.size() == 0)
			sb.append(". Resources in this slot cannot be interrupted");
		else {
			sb.append(", and face the following interruptions: ");
			for (int i = 0; i < permissibleInterruptions.size(); i++) {
				sb.append(permissibleInterruptions.get(i).getName());
				if (i == permissibleInterruptions.size()-2 && permissibleInterruptions.size() > 1)
					sb.append(", and ");
				else if (i < permissibleInterruptions.size()-1)
					sb.append(", ");
			}
		}

		if (this.isOverwritable)
			sb.append(". This slot can be overwritten.");
		else
			sb.append(". This slot cannot be overwritten.");
		return sb.toString();
	}

	@Override
	protected ArrayList<Node> displaySlotSpecificProperties() {
		ArrayList<Node> nodes = new ArrayList<>();

		// Permissible interruptions
		int numberOfInterruptionsIncluded = 0;
		for (InterruptionObjectTemplate i : View.getView().workspace.getAllInterruptionObjects())
			if (this.canUseInterruption(i)) 
				numberOfInterruptionsIncluded++;

		TextFlow tfInterruption = new TextFlow();
		nodes.add(tfInterruption );
		if (numberOfInterruptionsIncluded == 0)
			tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("Resources in this slot cannot be interrupted.", "normalText"));
		else {
			tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("The following interruptions can occur:  ", "normalText"));
			tfInterruption.getChildren().addAll(new Label(" "));
			int index = 0;
			for (InterruptionObjectTemplate i : View.getView().workspace.getAllInterruptionObjects())
				if (this.canUseInterruption(i)) {
					index++;
					tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(i.getName(), "valueText"));
					if (index == (numberOfInterruptionsIncluded-1))
						tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", and ", "normalText"));
					if (index <= (numberOfInterruptionsIncluded-1))
						tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", ", "normalText"));
				}
		}

		// Periodicity
		TextFlow tfPeriod = new TextFlow();
		Label s = new Label("Resources in this slot are consumed every ");
		s.getStylesheets().add(cssStyleSheetLocation);
		s.getStyleClass().add("normalText");
		tfPeriod.getChildren().add(s);

		Label ts = new Label(this.periodicity+" ");
		ts.getStylesheets().add(cssStyleSheetLocation);
		ts.getStyleClass().add("valueText");
		tfPeriod.getChildren().add(ts);

		Label e = new Label("time steps.");
		e.getStylesheets().add(cssStyleSheetLocation);
		e.getStyleClass().add("normalText");
		tfPeriod.getChildren().add(e);

		nodes.add(tfPeriod);
		return nodes;
	}

	@Override
	public boolean canUseAsDelay(InstanceReference delayReference) {
		return false;
	}

}
