package objectiveElements;

/** An interface implemented by PhenotypeObjects and PhenotypeSlots*/
public interface PhenotypeElement {

	public abstract String getName();
}
