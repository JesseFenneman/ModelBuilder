package objectiveElements;

import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextFlow;
import start.CentralExecutive;
import view.View;
import view.View.ViewState;

/** All agents have an age, which is always an integer value with a minimum of 0 (at which point it dies).
 * Because all agents have an age, it is always in the workspace.
 * 
 * The only change to the age phenotype that a user can make is the maximum age, which 
 * can be set through the textField in the View. */
public class AgeTemplate extends PhenotypeObjectTemplate {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public AgeTemplate (){
		super();
		this.isConstant = false;
		this.isObservable = true;
		this.name = "Age";
	}
	
	/** The domain of Age cannot be set this way by the user. Instead, it is updated by changing
	 * the maximum age TextField in the View. */
	@Override
	public boolean setDomainRange(DecimalNumber minimum, DecimalNumber maximum, DecimalNumber stepsize) {
		return false;
	}

	/** The domain of Age cannot be set this way by the user. Instead, it is updated by changing
	 * the maximum age TextField in the View. */
	@Override
	public boolean setDomainFixed(DecimalNumber fixedValue) {
		return false;
	}
	
	/** Updates the age. Specifically, sets the maximum age to be the maximum age stored in the workspace */
	public void updateAge(){
		this.minimum = new DecimalNumber(0);
		this.maximum = new DecimalNumber(View.getView().workspace.getMaximumLifeTime());
		this.stepsize = new DecimalNumber(1);
		
		if (this.maximum.smallerThan(1))
			throw new IllegalStateException("Cannot set the age maximum to " + maximum + " - the maximum has to be at least 1");
		this.domain = new DecimalNumberArray(minimum, maximum, stepsize);
	}
	
	@Override
	public boolean setName(String name) { return false; }

	/** The age has a different look and feel.*/
	@Override
	public void update(){
		updateAge();
		
		// Remove the ID
		this.setId("");

		// Remove height restriction
		this.setMinHeight(USE_COMPUTED_SIZE);

		// Remove all existing nodes
		this.getChildren().removeAll(this.getChildren());

		// Remove the ID
		this.setId("");

		// Remove height restriction
		this.setMinHeight(USE_COMPUTED_SIZE);

		// Set the title and subtitle
		GridPane gridTitle = new GridPane();
		gridTitle.setMinHeight(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setPrefHeight(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setMaxHeight(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setMaxWidth(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setMinWidth(GridPane.USE_COMPUTED_SIZE);
		gridTitle.setGridLinesVisible(true);

		RowConstraints row0 = new RowConstraints(25); //title
		RowConstraints row1 = new RowConstraints(25); //subtitle
		ColumnConstraints col = new ColumnConstraints();
		col.setMinWidth(USE_COMPUTED_SIZE);
		col.setPrefWidth(USE_COMPUTED_SIZE);
		col.setMaxWidth(USE_COMPUTED_SIZE);
		col.setHgrow(Priority.ALWAYS);

		gridTitle.getRowConstraints().addAll(row0, row1);
		gridTitle.getColumnConstraints().addAll(col);
		gridTitle.setGridLinesVisible(false);
		VBox.setVgrow(gridTitle, Priority.ALWAYS);

		// Set the titleLabel
		Label titleLabel = new Label("'Age'");
		GridPane.setValignment(titleLabel, VPos.CENTER);
		GridPane.setHalignment(titleLabel, HPos.CENTER);
		titleLabel.getStyleClass().add("titleText");
		gridTitle.add(titleLabel, 0, 0);

		// Set the subtitle
		Label subLabel = new Label("(A required phenotypic dimension)");
		GridPane.setValignment(subLabel, VPos.TOP);
		GridPane.setHalignment(subLabel, HPos.CENTER);
		subLabel.getStyleClass().add("subtitleText");
		gridTitle.add(subLabel, 0, 1);

		this.getChildren().add(gridTitle);

		// Update this ObjectTemplate according to the View's state
		if (View.getView().getState() == ViewState.DECISION_STRUCTURE){
			setDisable(true);
			TextFlow tf = new TextFlow();
			this.getChildren().add(tf);
			tf.getChildren().addAll(stringToSetOfLabels("(The maximum age can be set under the actions tab)", "normalText"));
			
		}else if (View.getView().getState() == ViewState.PATCH_AND_TIME){
			setDisable(true);
			TextFlow tf = new TextFlow();
			this.getChildren().add(tf);
			tf.getChildren().addAll(stringToSetOfLabels("(An agent's age cannot change between environments)", "normalText"));
		} else {
			setDisable(false);
		}
		
		// Save the height. Note that the first time that an ObjectTemplate is drawn, it is updated before JavaFX is done drawing it.
		// (Yes, it's one of those annoying javafx things). Hence, a runlater threat that will fire after the UI is done doing its thing.
		Platform.runLater(() -> {
			this.heightInDecisionStructure = getHeight();
		});

		// Enforce the height
		Platform.runLater(() -> {
			double height = Math.max(MINIMUM_HEIGHT, heightInDecisionStructure);
			this.setMinHeight(height);
		});
		
	}
	
	
	
 	@Override
 	public void handle(MouseEvent event) {

 	}
}
