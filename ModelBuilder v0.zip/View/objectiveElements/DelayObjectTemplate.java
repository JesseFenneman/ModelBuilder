package objectiveElements;

import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import start.CentralExecutive;

public class DelayObjectTemplate extends AbstractObjectiveTemplate {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public DelayObjectTemplate(){
		super();
	}

	@Override
	public void setFrequency(DecimalNumber frequency) {
		this.frequency = frequency.clone();
		frequency.setRange(0, 1);
	}

	@Override
	public boolean setDomainRange(DecimalNumber minimum, DecimalNumber maximum, DecimalNumber stepsize) {
		if (minimum.smallerThan(0))
			throw new IllegalArgumentException("Error when creating new delay object: minimum domain cannot be negative.");
		if (maximum.smallerThan(minimum))
			throw new IllegalArgumentException("Error when creating new delay object: maximum domain cannot be smaller than minimum domain.");

		if (! minimum.isInteger())
			throw new IllegalArgumentException("Error when creating new delay object: minimum domain should be an integer value.");
		if (! maximum.isInteger())
			throw new IllegalArgumentException("Error when creating new delay object: maximum domain should be an integer value.");
		if (! stepsize.isInteger())
			throw new IllegalArgumentException("Error when creating new delay object: step size domain should be an integer value.");
		
		this.isConstant = false;
		this.minimum = minimum;
		this.maximum = maximum;
		this.stepsize = stepsize;
		this.domain = DecimalNumberArray.allMultiplesInRange(minimum, maximum, stepsize);
		return true;
	}

	@Override
	public boolean setDomainFixed(DecimalNumber fixedValue) {
		if (fixedValue.smallerThan(0))
			throw new IllegalArgumentException("Error when creating new delay object: domain cannot be negative.");
		if (! fixedValue.isInteger())
			throw new IllegalArgumentException("Error when creating new delay object: domain must be an integer value.");
		
		this.isConstant = true;
		this.domain = new DecimalNumberArray(fixedValue);
		this.minimum = fixedValue;
		this.maximum = fixedValue;
		this.stepsize = null;
		this.belief = null;
		return true;
	}





}
