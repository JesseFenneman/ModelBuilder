package objectiveElements;

import java.util.HashMap;

import objectiveElements.AbstractPhenotypeSlotTemplate.SlotType;
import view.View;

/** A Factory class for AbstractPhenotypeSlotTemplateFactory*/
public class AbstractPhenotypeSlotTemplateFactory{
	@SuppressWarnings("serial")
	public static class IncorrectObjectSpecifcationException extends RuntimeException { public IncorrectObjectSpecifcationException(String message) {     super(message);  }}

	private String name;
	private Class<? extends AbstractPhenotypeSlotTemplate> type;

	private final HashMap<ResourceObjectTemplate, Boolean> hashMapResources;
	private final HashMap<PhenotypeObjectTemplate, Boolean> hashMapPhenotypes;
	private final HashMap<DelayObjectTemplate, Boolean> hashMapDelays;
	private final HashMap<InterruptionObjectTemplate, Boolean> hashMapInterruptions;

	private int periodicity;
	private boolean isOverwritable;

	/** Create a new factory. By default, all resources, delays, and interruptions that
	 * are in the workspace at the time of creating this factory are included as permissible
	 * objects. The factory should be manually updated with resources, delays, or interruptions that
	 * are added after the creation of this factory. As such, it is recommended to build from this
	 * factory quickly after creating the factory. */
	public AbstractPhenotypeSlotTemplateFactory(String name) {
		this();
		this.name = name;
	}

	/** Create a new factory. By default, all resources, delays, and interruptions that
	 * are in the workspace at the time of creating this factory are included as permissible
	 * objects. The factory should be manually updated with resources, delays, or interruptions that
	 * are added after the creation of this factory. As such, it is recommended to build from this
	 * factory quickly after creating the factory. */
	public AbstractPhenotypeSlotTemplateFactory() {
		this.name = null;

		this.hashMapResources = new HashMap<>();
		this.hashMapPhenotypes = new HashMap<>();
		this.hashMapDelays = new HashMap<>();
		this.hashMapInterruptions = new HashMap<>();

		for (ResourceObjectTemplate res: View.getView().workspace.getAllResourceObjects())
			hashMapResources.put(res, true);
		for (DelayObjectTemplate del: View.getView().workspace.getAllDelayObjects())
			hashMapDelays.put(del, true);
		for (InterruptionObjectTemplate inte: View.getView().workspace.getAllInterruptionObjects())
			hashMapInterruptions.put(inte, true);

		this.periodicity=-1;
		this.isOverwritable=false;
	}

	/** Set the name of the to-be-created phenotypic slot*/
	public AbstractPhenotypeSlotTemplateFactory setName(String name) {
		this.name=name;
		return this;
	}

	/** Set the type of the to-be-created phenotypic slot.*/
	public AbstractPhenotypeSlotTemplateFactory setSlotType (Class<? extends AbstractPhenotypeSlotTemplate> clazz) {
		this.type = clazz;
		return this;
	}

	/** Set the type of the to-be-created phenotypic slot.*/
	public AbstractPhenotypeSlotTemplateFactory setSlotType (SlotType slotType) {
		if (slotType == SlotType.CAPTIVE_RESOURCE)
			this.type = PhenotypeSlotTemplateCaptiveResource.class;
		else if (slotType == SlotType.DELAYED_RESOURCE)
			this.type = PhenotypeSlotTemplateDelayedResource.class;
		else if (slotType == SlotType.RECURRING_RESOURCE)
			this.type = PhenotypeSlotTemplateRecurringResource.class;
		else
			throw new IncorrectObjectSpecifcationException("Unknown slot type:" + slotType);
		return this;
	}

	/** Set whether the resource can be used or not in the to-be-created phenotypic slot.*/
	public AbstractPhenotypeSlotTemplateFactory setCanUseResource (ResourceObjectTemplate resource, boolean canUse) {
		this.hashMapResources.put(resource, canUse);
		return this;
	}
	
	/** Set whether the resource can be used or not in the to-be-created phenotypic slot.*/
	public AbstractPhenotypeSlotTemplateFactory setCanUsePhenotype(PhenotypeObjectTemplate pheno, boolean canUse) {
		if (pheno instanceof AgeTemplate)
			throw new IllegalArgumentException("Trying to use the age as a phenotypic dimension in a phenotype slot.");
		this.hashMapPhenotypes.put(pheno, canUse);
		return this;
	}
	
	
	/** Set whether the delay can be used or not in the to-be-created phenotypic slot.*/
	public AbstractPhenotypeSlotTemplateFactory setCanUseDelay (DelayObjectTemplate delay, boolean canUse) {
		this.hashMapDelays.put(delay, canUse);
		return this;
	}
	
	/** Set whether the interruption can be used or not in the to-be-created phenotypic slot.*/
	public AbstractPhenotypeSlotTemplateFactory setCanUseInterruption (InterruptionObjectTemplate interruption, boolean canUse) {
		this.hashMapInterruptions.put(interruption, canUse);
		return this;
	}

	/** Set the periodicity of the to-be-created phenotypic slot*/
	public AbstractPhenotypeSlotTemplateFactory setPeriodicity(int periodicity) {
		if (periodicity<1)
			throw new IncorrectObjectSpecifcationException("Cannot use the non-positive periodicity " + periodicity);
		this.periodicity=periodicity;
		return this;
	}

	/** Set whether the to-be-created phenotypic slot can be overwritten.*/
	public AbstractPhenotypeSlotTemplateFactory setCanBeOverwritten (boolean canBeOverwritten) {
		this.isOverwritable=canBeOverwritten;
		return this;
	} 

	/** Build the AbstractPhenotypeSlotTemplate as specified prior. Throws a IncorrectObjectSpecifcationException
	 * if the specifications are illegal (including when there are delays, interruptions, or resources in the workspace
	 * that are not included in the factory)*/
	public AbstractPhenotypeSlotTemplate build() {
		AbstractPhenotypeSlotTemplate slot = AbstractPhenotypeSlotTemplate.createSlot(type);

		if (name == null)
			throw new IncorrectObjectSpecifcationException("�annot use a null name when constructing a phenotype slot");
		slot.name=this.name;

		// Check if there is an entry for each resource in the workspace in the hashMapResources
		for (ResourceObjectTemplate rW : View.getView().workspace.getAllResourceObjects())
			if (this.hashMapResources.get(rW) == null)
				throw new IncorrectObjectSpecifcationException("In the workspace, there is a resource called " + rW.getName() + ", which is not in the factory hashmap");
		// Conversely, each entry in the HashMap should also be in the workspace
		for (ResourceObjectTemplate rH : this.hashMapResources.keySet())
			if (View.getView().workspace.getObject(rH.getName()) == null)
				throw new IncorrectObjectSpecifcationException("In the factory hashmap, there is a resource called " + rH.getName() + ", which is not in the workspace");
		// Finally, add all entries in this hashmap to the slot's hashmap
		for (ResourceObjectTemplate rH : this.hashMapResources.keySet())
			slot.addResourceType(rH, this.hashMapResources.get(rH));

		// Do the same for delays, if the slot uses delays (which only is a Delayed Resource slot at the moment - hence the cast in the last row)
		if (AbstractPhenotypeSlotTemplate.usesDelays(type)) {
			for (DelayObjectTemplate dW : View.getView().workspace.getAllDelayObjects())
				if (this.hashMapDelays.get(dW) == null)
					throw new IncorrectObjectSpecifcationException("In the workspace, there is a delay called " + dW.getName() + ", which is not in the factory hashmap");
			for (DelayObjectTemplate dH : this.hashMapDelays.keySet())
				if (View.getView().workspace.getObject(dH.getName()) == null)
					throw new IncorrectObjectSpecifcationException("In the factory hashmap, there is a delay called " + dH.getName() + ", which is not in the workspace");
			for (DelayObjectTemplate dH : this.hashMapDelays.keySet())
				((PhenotypeSlotTemplateDelayedResource) slot).addDelayType(dH, this.hashMapDelays.get(dH));
		}

		// And thirdly, the same for the persmissable interruptions (which are used by both delayed resources and recurring resources)
		if (AbstractPhenotypeSlotTemplate.usesInterruptions(type)) {
			for (InterruptionObjectTemplate iW : View.getView().workspace.getAllInterruptionObjects())
				if (this.hashMapInterruptions.get(iW) == null)
					throw new IncorrectObjectSpecifcationException("In the workspace, there is an interruption called " + iW.getName() + ", which is not in the factory hashmap");
			for (InterruptionObjectTemplate iH : this.hashMapInterruptions.keySet())
				if (View.getView().workspace.getObject(iH.getName()) == null)
					throw new IncorrectObjectSpecifcationException("In the factory hashmap, there is an interruption called " + iH.getName() + ", which is not in the workspace");

			// There are two classes (currently) which use interruptions
			if (slot instanceof PhenotypeSlotTemplateDelayedResource)
				for (InterruptionObjectTemplate iH : this.hashMapInterruptions.keySet())
					((PhenotypeSlotTemplateDelayedResource) slot).addInterruptionType(iH, this.hashMapInterruptions.get(iH));

			// There are two classes (currently) which use interruptions
			if (slot instanceof PhenotypeSlotTemplateRecurringResource)
				for (InterruptionObjectTemplate iH : this.hashMapInterruptions.keySet())
					((PhenotypeSlotTemplateRecurringResource) slot).addInterruptionType(iH, this.hashMapInterruptions.get(iH));
		}

		if (slot instanceof PhenotypeSlotTemplateRecurringResource)
			((PhenotypeSlotTemplateRecurringResource) slot).setPeriodicity(periodicity);
		
		slot.setOverwritable(isOverwritable);
		return slot;
	}
}