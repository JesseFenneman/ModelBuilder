package objectiveElements;

import java.util.ArrayList;

import attributes.AttributeField;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import rIntegration.RFunction;
import rIntegration.RFunctionContainer;
import start.CentralExecutive;

/** A phenotype object is a special object: it is always observable and does not have any values (rather,
 * its values will be the state values in the algorithm; they are outcomes rather than independent variables.*/
public class PhenotypeObjectTemplate  extends AbstractObjectiveTemplate implements PhenotypeElement {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public PhenotypeObjectTemplate() {
		super();
	}

	@Override
	public void setFrequency(DecimalNumber frequency) {
		return;
	}

	@Override
	public boolean setDomainRange(DecimalNumber minimum, DecimalNumber maximum, DecimalNumber stepsize) {
		if (maximum.smallerThan(minimum))
			throw new IllegalArgumentException("Error when creating new phenotype object: maximum domain cannot be smaller than minimum domain.");

		this.isConstant = false;
		this.minimum = minimum;
		this.maximum = maximum;
		this.stepsize = stepsize;
		this.domain = DecimalNumberArray.allMultiplesInRange(minimum, maximum, stepsize);
		return true;
	}

	@Override
	public boolean setDomainFixed(DecimalNumber fixedValue) {
		this.isConstant = true;
		this.domain = new DecimalNumberArray(fixedValue);
		this.minimum = fixedValue;
		this.maximum = fixedValue;
		this.stepsize = null;
		return true;
	}

	/** A phenotypic state is always observable*/
	@Override
	public void setObservable(boolean observability){
		return;
	}

	/** A phenotypic state is always observable - no cues necessary*/
	@Override
	public void setCueTemplate(CueTemplate ct){
		return;
	}

	/** A phenotypic state's values are not sampled from a distribution*/
	@Override
	public void setSingleSamplingDistribution(RFunctionContainer rfc){
		return;
	}

	/** A phenotypic state's values are not sampled from a distribution*/
	@Override
	public void setMultipleSamplingDistributions(RFunction rf, ArrayList<AttributeField[]> args){
		return ;
	}
}
