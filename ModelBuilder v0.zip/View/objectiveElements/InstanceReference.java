package objectiveElements;

/** There are two ways to refer to an Instance: either
 * by using the Instance itself, or to use an InstanceAlias
 * that refers to that Instance. In some cases we do not know
 * whether we are dealing with an Instance or an Alias - indeed,
 * that is the whole point of allowing aliases. However, we still
 * want to use these two types interchangeably - hence, this interface.*/
public interface InstanceReference {


	/** Returns the name of this InstanceReference */
	public String getName();
	
	/** An Instance (or Alias to an Instance) is an Instance of some class. Which class?
	 * That you can find out with this function.*/
	public AbstractObjectiveTemplate getAbstractObjectiveTemplate();
	
	/** Is this an Instance or InstanceAlias that refers to a ResourceObjectTemplate,
	 * a DelayObjectTemplate, or an ExtrinsicObjectTemplate?*/
	public Class<? extends AbstractObjectiveTemplate> getClassType() ;
	
}
