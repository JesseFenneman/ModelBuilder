package objectiveElements;

import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import start.CentralExecutive;

public class InterruptionObjectTemplate extends AbstractObjectiveTemplate {
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	public InterruptionObjectTemplate() {
		super();
	}

	@Override
	public void setFrequency(DecimalNumber frequency) {
		return;
		
	}

	
	@Override
	/** Interruptions always have a domain of 0 and 1, and cannot be constant*/
	public boolean setDomainRange(DecimalNumber minimum, DecimalNumber maximum, DecimalNumber stepsize) {
		if (!minimum.equals(0))
			throw new IllegalArgumentException("Error when creating new interruption object: cannot set the minimum domain of an interruption to anything other than 0.");
		if (!maximum.equals(1))
			throw new IllegalArgumentException("Error when creating new interruption object: cannot set the maximum domain of an interruption to anything other than 1.");
		if (!stepsize.equals(1))
			throw new IllegalArgumentException("Error when creating new interruption object: cannot set the stepsize domain of an interruption to anything other than 1.");
				
		this.isConstant = false;
		this.minimum = minimum;
		this.maximum = maximum;
		this.stepsize = stepsize;
		this.domain = DecimalNumberArray.allMultiplesInRange(minimum, maximum, stepsize);
		return true;
	}

	@Override
	/** Interruptions always have a domain of 0 and 1, and cannot be constant*/
	public boolean setDomainFixed(DecimalNumber fixedValue) {
		throw new IllegalArgumentException("Error when creating new interruption object: cannot set the domain of an interruption to be fixed.");
	}
}