package objectiveElements;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.text.TextFlow;
import start.CentralExecutive;
import view.View;

/** During the runtime of a model, some resources can be consumed with a delay. There
 * are two types of delays possible: postponing, and waiting. While postponing, an 
 * agent cannot take any further action. Or stated differently: the encounter ends only
 * after the resources is consumed. During waiting delays the agent is free to take
 * other actions. That is, a resource is placed into a slot, which will be automatically
 * consumed after the set delay ends. This means that the encounter can be terminated
 * without immediately consuming the resources. 
 * 
 * Conceptually, a delayed resource slot is part of the agent's phenotype - and hence, will be displayed
 * at the location of the 'beliefs' in the View (as phenotypes are always visible,
 * the 'beliefs' slot is not used anyway. 
 * 
 * Note: a waiting delay is not the same as the action to wait. During the wait action,
 * which is available both during and between encounters, is a 'null' postcondition that
 * does not do anything. In contract, a waiting delay occurs only when a queue slot
 * is filled with a resource and a delay. */
public class PhenotypeSlotTemplateDelayedResource extends AbstractPhenotypeSlotTemplate{

	private static final long serialVersionUID = CentralExecutive.programVersion;

	// Not all delays can be used in this slot. This HashMap provides a boolean for each possible delay, dictating whether that delay can be used
	private final HashMap<DelayObjectTemplate, Boolean> hashMapDelays;

	// Not all interruptions can be used in this slot. This HashMap provides a boolean for each possible interruption. 
	private final HashMap<InterruptionObjectTemplate, Boolean> hashMapInterruptions;


	/** Creates a new slot template. Adds all the resources and delays in the workspace to this slot. The default is
	 * that all resource or delays can be used.*/
	public PhenotypeSlotTemplateDelayedResource(String name, boolean isOverwritable) {
		this();

		this.name=name;
		this.isOverwritable=isOverwritable;
	}

	/** Creates a new slot template. Adds all the resources and delays in the workspace to this slot. The default is
	 * that all resource or delays can be used.*/
	public PhenotypeSlotTemplateDelayedResource() {
		super();

		this.hashMapDelays = new HashMap<>();
		this.hashMapInterruptions = new HashMap<>();

		for (DelayObjectTemplate d : View.getView().workspace.getAllDelayObjects())
			this.hashMapDelays.put(d, true);

		for (InterruptionObjectTemplate i  : View.getView().workspace.getAllInterruptionObjects())
			this.hashMapInterruptions.put(i, true);

		update();
	}

	/** Can the specified DelayObjectTemplate be used in this slot?*/
	public boolean canUseDelay(DelayObjectTemplate delay) {
		if (!this.hashMapDelays.containsKey(delay))
			throw new IllegalArgumentException("Trying to get whether a delay can be used in a slot, but the delay is not yet in the HashMap.");

		return hashMapDelays.get(delay);
	}
	

	/** Can the specified InstanceReference be used as an resource in this slot?*/
	public boolean canUseAsDelay(InstanceReference delayReference) {
		if (!this.hashMapDelays.containsKey(delayReference.getAbstractObjectiveTemplate()))
			throw new IllegalArgumentException("Trying to get whether a delay instance can be used in a slot, but the AbstractObjectiveTemplate of this delay is not yet in the HashMap.");

		return hashMapDelays.get(delayReference.getAbstractObjectiveTemplate());
	}

	/** Modifies whether the specified DelayObjectTemplate can be used in this slot*/
	public void modifyCanUseDelay(DelayObjectTemplate delay, boolean possibleToUse) {
		if (!this.hashMapDelays.containsKey(delay))
			throw new IllegalArgumentException("Modifying a delay to use in a slot, but the delay is not yet in the HashMap.");

		hashMapDelays.put(delay, possibleToUse);
	}


	/** Should be called by the Workspace whenever a new delay is added to the Workspace*/
	public void addDelayType(DelayObjectTemplate newDelay,  boolean possibleToUse) {
		this.hashMapDelays.put(newDelay, possibleToUse);
	}

	/** Should be called by the Workspace whenever the delay is removed from the Workspace*/
	public void removeDelayType(DelayObjectTemplate toBeRemovedDelay) {
		this.hashMapDelays.remove(toBeRemovedDelay);
	}


	/** Can the specified InterruptionObjectTemplate be used in this slot?*/
	public boolean canUseInterruption(InterruptionObjectTemplate interruption) {
		if (!this.hashMapInterruptions.containsKey(interruption))
			throw new IllegalArgumentException("Trying to get whether an interruption can be used in a slot, but the interruption is not yet in the HashMap.");

		return hashMapInterruptions.get(interruption);
	}

	/** Can the specified InstanceReference be used as an resource in this slot?*/
	public boolean canUseAsInterruption(InstanceReference interruptionReference) {
		if (interruptionReference == InstanceNull.getNullInstanceForInterruptions())
			return true;
		if (!this.hashMapInterruptions.containsKey(interruptionReference.getAbstractObjectiveTemplate()))
			throw new IllegalArgumentException("Trying to get whether an interruption instance can be used in a slot, but the AbstractObjectiveTemplate of this interruption is not yet in the HashMap.");

		return hashMapInterruptions.get(interruptionReference.getAbstractObjectiveTemplate());
	}
	
	/** Modifies whether the specified InterruptionObjectTemplate can be used in this slot*/
	public void modifyCanUseInterruption(InterruptionObjectTemplate interruption, boolean possibleToUse) {
		if (!this.hashMapInterruptions.containsKey(interruption))
			throw new IllegalArgumentException("Modifying an interruption to use in a slot, but the interruption is not yet in the HashMap.");

		hashMapInterruptions.put(interruption, possibleToUse);
	}


	/** Should be called by the Workspace whenever a new interruption is added to the Workspace*/
	public void addInterruptionType(InterruptionObjectTemplate newInterruption,  boolean possibleToUse) {
		this.hashMapInterruptions.put(newInterruption, possibleToUse);
	}

	/** Should be called by the Workspace whenever the Interruption is removed from the Workspace*/
	public void removeInterruptionType(InterruptionObjectTemplate toBeRemovedInterruption) {
		this.hashMapInterruptions.remove(toBeRemovedInterruption);
	}




	/** Sets whether this slot can be overwritten by a new resource (true), or whether this slot can only be filled with a new entry if the current entry
	 * is finished (false)*/
	@Override
	public void setOverwritable(boolean isOverwritable) {
		this.isOverwritable= isOverwritable;
	}



	@Override
	public SlotType getSlotType() {
		return SlotType.DELAYED_RESOURCE;
	}


	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(name + ". A delayed resource slot. This slot stores resources of types: ");

		// Permissible resources
		ArrayList<ResourceObjectTemplate> permissibleResources = new ArrayList<>();
		for (ResourceObjectTemplate r : this.hashMapResources.keySet())
			if (hashMapResources.get(r))
				permissibleResources.add(r);
		for (int i = 0; i < permissibleResources.size(); i++) {
			sb.append(permissibleResources.get(i).getName());
			if (i == permissibleResources.size()-2 && permissibleResources.size() > 1)
				sb.append(", and ");
			else if (i < permissibleResources.size()-1)
				sb.append(", ");
		}
		
		// Permissible phenotypes
		sb.append(". These resources can effect these phenotypic dimensions: ");
		ArrayList<PhenotypeObjectTemplate> permissiblePhenotypes = new ArrayList<>();
		for (PhenotypeObjectTemplate p : this.hashMapPhenotypes.keySet())
			if (hashMapPhenotypes.get(p))
				permissiblePhenotypes.add(p);
		
		for (int i = 0; i < permissiblePhenotypes.size(); i++) {
			sb.append(permissiblePhenotypes.get(i).getName());
			if (i == permissiblePhenotypes.size()-1 && permissiblePhenotypes.size() > 1)
				sb.append(", and ");
			else if (i < permissiblePhenotypes.size()-1)
				sb.append(", ");
		}
		
		// Permissible delays
		sb.append(", can use the following delays: ");
		ArrayList<DelayObjectTemplate> permissibleDelays = new ArrayList<>();
		for (DelayObjectTemplate d : this.hashMapDelays.keySet())
			if (hashMapDelays.get(d))
				permissibleDelays.add(d);
		for (int i = 0; i < permissibleDelays.size(); i++) {
			sb.append(permissibleDelays.get(i).getName());
			if (i == permissibleDelays.size()-2 && permissibleDelays.size() > 1)
				sb.append(", and ");
			else if (i < permissibleDelays.size()-1)
				sb.append(", ");
		}

		// Permissible interruptions
		ArrayList<InterruptionObjectTemplate> permissibleInterruptions = new ArrayList<>();
		for (InterruptionObjectTemplate i : this.hashMapInterruptions.keySet())
			if (hashMapInterruptions.get(i))
				permissibleInterruptions.add(i);

		if (permissibleInterruptions.size() == 0)
			sb.append(". Resources in this slot cannot be interrupted");
		else {
			sb.append(", and face the following interruptions: ");
			for (int i = 0; i < permissibleInterruptions.size(); i++) {
				sb.append(permissibleInterruptions.get(i).getName());
				if (i == permissibleInterruptions.size()-2 && permissibleInterruptions.size() > 1)
					sb.append(", and ");
				else if (i < permissibleInterruptions.size()-1)
					sb.append(", ");
			}
		}

		if (this.isOverwritable)
			sb.append(". This slot can be overwritten.");
		else
			sb.append(". This slot cannot be overwritten.");
		return sb.toString();
	}

	@Override
	protected ArrayList<Node> displaySlotSpecificProperties() {
		ArrayList<Node> nodes = new ArrayList<>();
		
		// Permissible delays
		int numberOfDelaysIncluded = 0;
		for (DelayObjectTemplate d : View.getView().workspace.getAllDelayObjects())
			if (this.canUseDelay(d)) 
				numberOfDelaysIncluded++;
		
		TextFlow tfDelay = new TextFlow();
		nodes.add(tfDelay);
		if (numberOfDelaysIncluded == 0)
			tfDelay.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("This slot cannot be used by any delays", "normalText"));
		else {
			tfDelay.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("This slot can store the following delays:", "normalText"));
			tfDelay.getChildren().addAll(new Label(" "));
			int index = 0;
			for (DelayObjectTemplate d : View.getView().workspace.getAllDelayObjects())
				if (this.canUseDelay(d)) {
					index++;
					tfDelay.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(d.getName(), "valueText"));
					if (index == (numberOfDelaysIncluded-1))
						tfDelay.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", and ", "normalText"));
					if (index <= (numberOfDelaysIncluded-1))
						tfDelay.getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", ", "normalText"));
				}
		}
		
		// Permissible interruptions
		int numberOfInterruptionsIncluded = 0;
		for (InterruptionObjectTemplate i : View.getView().workspace.getAllInterruptionObjects())
			if (this.canUseInterruption(i)) 
				numberOfInterruptionsIncluded++;
		
		TextFlow tfInterruption = new TextFlow();
		nodes.add(tfInterruption );
		if (numberOfInterruptionsIncluded == 0)
			tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("Resources in this slot cannot be interrupted.", "normalText"));
		else {
			tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels("The following interruptions can occur:  ", "normalText"));
			tfInterruption.getChildren().addAll(new Label(" "));
			int index = 0;
			for (InterruptionObjectTemplate i : View.getView().workspace.getAllInterruptionObjects())
				if (this.canUseInterruption(i)) {
					index++;
					tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(i.getName(), "valueText"));
					if (index == (numberOfInterruptionsIncluded-1))
						tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", and ", "normalText"));
					if (index <= (numberOfInterruptionsIncluded-1))
						tfInterruption .getChildren().addAll(AbstractObjectiveTemplate.stringToSetOfLabels(", ", "normalText"));
				}
		}
		
		
		return nodes;
	}

	
}
