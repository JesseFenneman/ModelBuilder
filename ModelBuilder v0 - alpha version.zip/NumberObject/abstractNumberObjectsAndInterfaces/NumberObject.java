package abstractNumberObjectsAndInterfaces;

import java.math.BigDecimal;

import abstractNumberObjectsAndInterfaces.NumberObject.UnknownNumberObjectException;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import doubleNumber.DoubleNumber;
import doubleNumber.DoubleNumberArray;
import doubleNumber.DoubleNumberMatrix;
import rIntegration.RParsable;

/** Represents all possible NumberObjects - including singleton values, 1D arrays, and 2D matrices. */
public abstract interface NumberObject extends RParsable{
	/** This exception is thrown when performing an operation on or with a NumberObjectSingle object that is flagged as NULL*/
	@SuppressWarnings("serial")
	public static class NumberObjectIncorrectRepresentationException extends RuntimeException { public NumberObjectIncorrectRepresentationException(String message) {     super(message);  }}
	/** This exception is thrown when performing an operation on or with a NumberObjectSingle object that is flagged as NULL*/
	@SuppressWarnings("serial")
	public static class NumberObjectNULLException extends RuntimeException { public NumberObjectNULLException(String message) {     super(message);  }}
	
	/** This exception is thrown when performing an operation on or with a NumberObjectSingle object that is flagged as NaN*/
	@SuppressWarnings("serial")
	public static class NumberObjectNaNException extends RuntimeException { public NumberObjectNaNException(String message) {     super(message);  }}
	/** This exception is thrown when performing an operation on or with a NumberObjectSingle object that is flagged as POSITIVE_INFINITE*/
	@SuppressWarnings("serial")
	public static class NumberObjectPositiveInfinityException extends RuntimeException { public NumberObjectPositiveInfinityException(String message) {     super(message);  }}
	/** This exception is thrown when performing an operation on or with a NumberObjectSingle object that is flagged as NEGATIVE_INFINITE*/
	@SuppressWarnings("serial")
	public static class NumberObjectNegativeInfinityException extends RuntimeException { public NumberObjectNegativeInfinityException(String message) {     super(message);  }}
	@SuppressWarnings("serial")
	public static class IllegalRangeException extends RuntimeException { public IllegalRangeException(String message) {     super(message);  }};
	@SuppressWarnings("serial")
	public static class IllegalScaleException extends RuntimeException { public IllegalScaleException(String message) { 	 super(message);  }};
	/** An exception to throw if a column or row is requested by name, but no column or row with that name exists. */
	@SuppressWarnings("serial")
	public static class NoSuchNameException extends RuntimeException { public NoSuchNameException(String message) { 	 super(message);  }};
	/**
	 * An exception to throw if a computation is impossible (even though the arguments are valid).
	 *
	 */
	@SuppressWarnings("serial")
	public static class ComputationException extends RuntimeException { public ComputationException(String message) {     super(message);  }}
	/** This exception is thrown when performing an operation on or with an not yet implemented NumberObjectRepresentation*/
	@SuppressWarnings("serial")
	public static class UnknownNumberObjectException extends RuntimeException {
		public UnknownNumberObjectException(String message) {     super(message);  }
		public UnknownNumberObjectException() {     super();  }
	}

	/** An enum that lists all implementations of NumberObject. At the time of writing, this are 
	 * the DoubleNumber and DecimalNumber classes. DoubleNumber is based on the primitive double,
	 * and is fast, but suffers from floating point inaccuracy. DecimalNumber is based on Java's 
	 * BigDecimal class, and is precise, yet suffers from poor speed.*/
	public static enum NumberObjectRepresentation { DECIMALNUMBER, DOUBLENUMBER};

	/** Returns true if the NumberObject matches the NumberObjectRepresentation*/
	public static boolean matchesNumberObjectRepresentation( NumberObject object, NumberObjectRepresentation representation) {
		if (representation == NumberObjectRepresentation.DECIMALNUMBER) {
			if (object instanceof DecimalNumber || object instanceof DecimalNumberArray || object instanceof DecimalNumberMatrix)
				return true;
			return false;
		}
		if (object instanceof DoubleNumber || object instanceof DoubleNumberArray || object instanceof DoubleNumberMatrix)
			return true;
		return false;
	}
	/** returns true iff all NumberObject objects in this array match their correct fieldType */
	public abstract boolean matchesFieldRestriction(FieldRestriction ft) ;

	/** Returns a deep clone of this NumberObject */
	public abstract NumberObject clone();

	/** Prevent any further changes to this NumberObject, and all NumberObjects contained within */
	public void makeImmutable();

	/** Returns the value, and only the value, of this NumberObject*/
	public abstract String toString();

	/** Returns the value, and only the value, of this NumberObject. Should not have any useless zeros at the end*/
	public abstract String toStringWithoutTrailingZeros();

	/** Returns the value, and only the value, of this NumberObject, rounded to the nearest significant digit*/
	public abstract String toString(int significantDigit);




	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	SINGLE NUMBER CONSTRUCTORS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** The main constructor. Most, if not all, other constructors refer back to this one. It is private because in theory you can make a ranged DecimalNumber that never checks its range. */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, BigDecimal value, BigDecimal minimum, BigDecimal maximum, boolean rangeSpecified, boolean immutable) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(  value,  minimum,  maximum,  rangeSpecified,  immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber( value,  minimum,  maximum,  rangeSpecified,  immutable);
		throw new UnknownNumberObjectException();
	}

	/** Create a NaN Number in the chosen representation*/
	public static NumberObjectSingle createNaN(NumberObject.NumberObjectRepresentation formatToUse)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return DecimalNumber.NaN;
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return null;//return DoubleNumber.NaN;
		throw new UnknownNumberObjectException();
	}
	
	/** Creates a new mutable NumberObjectSingle without a specified range
	 *
	 * @param value
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, Number value)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value);
		throw new UnknownNumberObjectException();
	}

	/** Creates a new mutable NumberObjectSingle without a specified range
	 *
	 * @param value
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, String value)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value);
		throw new UnknownNumberObjectException();
	}

	/** Creates a new mutable NumberObjectSingle without a specified range
	 *
	 * @param value
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, BigDecimal value)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value);
		throw new UnknownNumberObjectException();
	}

	/** Copy constructor. Returns a shallow clone  */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, NumberObjectSingle value)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value);
		throw new UnknownNumberObjectException();
	}

	/** Creates a new NumberObjectSingle without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, Number value, boolean immutable)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value, immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value, immutable);
		throw new UnknownNumberObjectException();
	}

	/** Creates a new NumberObjectSingle without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, String value, boolean immutable)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value, immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value, immutable);
		throw new UnknownNumberObjectException();
	}

	/** Creates a new NumberObjectSingle without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, BigDecimal value, boolean immutable)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value, immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value, immutable);
		throw new UnknownNumberObjectException();
	}

	/** Creates a new NumberOjectSingle without a specified range and with a specified mutability
	 *
	 * @param value
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, NumberObjectSingle value, boolean immutable)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value, immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value, immutable);
		throw new UnknownNumberObjectException();
	}

	/** Creates a NumberObjectSingle with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, Number value, Number minimum, Number maximum, boolean immutable) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value, minimum, maximum, immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value, minimum, maximum, immutable);
		throw new UnknownNumberObjectException();
	}

	/** Creates a NumberObjectSingle with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, Number value, NumberObjectSingle minimum, NumberObjectSingle maximum, boolean immutable) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value, minimum, maximum, immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value, minimum, maximum, immutable);
		throw new UnknownNumberObjectException();
	}

	/** Creates a NumberObjectSingle with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, String value, String minimum, String maximum, boolean immutable) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value, minimum, maximum, immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value, minimum, maximum, immutable);
		throw new UnknownNumberObjectException();
	}

	/** Creates a NumberObjectSingle with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, BigDecimal value, BigDecimal minimum, BigDecimal maximum, boolean immutable) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value, minimum, maximum, immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value, minimum, maximum, immutable);
		throw new UnknownNumberObjectException();
	}

	/** Creates a NumberObjectSingle with a specified range and mutability
	 *
	 * @param value
	 * @param minimum
	 * @param maximum
	 * @return
	 */
	public static NumberObjectSingle createNumber (NumberObject.NumberObjectRepresentation formatToUse, NumberObjectSingle value, NumberObjectSingle minimum, NumberObjectSingle maximum, boolean immutable) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumber(value, minimum, maximum, immutable);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumber(value, minimum, maximum, immutable);
		throw new UnknownNumberObjectException();
	}




	/////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	ARRAY CONSTRUCTORS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////
	public static NumberObjectArray createArray (NumberObject.NumberObjectRepresentation formatToUse, NumberObjectSingle... numbers) { 
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberArray(numbers);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberArray(numbers);
		throw new UnknownNumberObjectException();

	}

	/** Creates a NumberObjectArray of type formatToUse, consisting of mutable DoubleNumbers with the values specified and without a range limitation
	 * 
	 * @param numbers The double values to be converted to mutable DoubleNumbers
	 */
	public static NumberObjectArray createArray (NumberObject.NumberObjectRepresentation formatToUse, double... numbers) { 
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberArray(numbers);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberArray(numbers);
		throw new UnknownNumberObjectException();
	}

	/** Creates a NumberObjectArray of type formatToUse, consisting of mutable DoubleNumbers with the values, range and immutability specified
	 * 
	 * @param numbers The double values to be converted to mutable DecimalNumbers
	 */
	public static NumberObjectArray createArray (NumberObject.NumberObjectRepresentation formatToUse, double minimum, double maximum, boolean immutable, double... numbers) { 
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberArray( minimum,  maximum,  immutable,  numbers);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberArray( minimum,  maximum,  immutable,  numbers);
		throw new UnknownNumberObjectException();
	}

	/** Creates a NumberObjectArray of type formatToUse that contains all values between minimum and maximum that
	 * are in the set {x | minimum+nx, x < maximum}.
	 * 
	 * If the supplied minimum is larger than the maximum, the two are reversed.
	 * Thus, the stepSize always has to be positive (no fancy stuff like: an array from -2 to -10 with steps of -1; 
	 * only -10 to -2 with steps of 1 is allowed!).
	 * @return
	 */
	public static NumberObjectArray createArray (NumberObject.NumberObjectRepresentation formatToUse, NumberObjectSingle minimum, NumberObjectSingle maximum, NumberObjectSingle stepSize) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberArray( minimum,  maximum,  stepSize);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberArray( minimum,  maximum,  stepSize);
		throw new UnknownNumberObjectException();
	}


	/** Creates a NumberObjectArray of type formatToUse of size n. 	 */
	public static NumberObjectArray createArray (NumberObject.NumberObjectRepresentation formatToUse, int n) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberArray(n);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberArray(n);
		throw new UnknownNumberObjectException();
	}

	/** Copy constructor. Returns a deep clone. */
	public static NumberObjectArray createArray (NumberObject.NumberObjectRepresentation formatToUse, NumberObjectArray original) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberArray(original.toDecimalNumberArray(), true);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberArray(original, true);
		throw new UnknownNumberObjectException();

	}

	
	

	/////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	MATRIX CONSTRUCTORS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	/** Instantiate a NumberObjectArray from a 2 dimensional array of doubles ([rows][columns]). The nrow
	 * of the resulting NumberObjectArray is the number of rows in the double matrix (first index). The ncol
	 * of the resulting NumberObjectArray is the length of the first array in the arrays of doubles.
	 *
	 * The doubleMatrix should have rows (first index) of equal length. If not, an IllegalArgumentException is thrown.
	 * @param matrix
	 */
	public static NumberObjectMatrix createMatrix (NumberObject.NumberObjectRepresentation formatToUse, double[][] doubleMatrix) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberMatrix(doubleMatrix);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberMatrix(doubleMatrix);
		throw new UnknownNumberObjectException();
	}

	/** Instantiate a NumberObjectArray from a 2 dimensional array of NumberObjectSingles ([rows][columns]).
	 * The numberObjectMatrix should have rows (first index) of equal length. If not, an IllegalArgumentException is thrown.
	 * @param matrix
	 */
	public static NumberObjectMatrix createMatrix (NumberObject.NumberObjectRepresentation formatToUse, NumberObjectSingle[][] numberObjectMatrix) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberMatrix(numberObjectMatrix);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberMatrix(numberObjectMatrix);
		throw new UnknownNumberObjectException();
	}

	public static NumberObjectMatrix createMatrix (NumberObject.NumberObjectRepresentation formatToUse, NumberObjectArray... rows)	{
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberMatrix(rows);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberMatrix(rows);
		throw new UnknownNumberObjectException();
	}

	/**
	 * Creates a matrix containing nrow by ncol mutable NumberObjectSingles with value 0 and without range.
	 * @param columnNames
	 * @param nrow
	 * @param ncol
	 */
	public static NumberObjectMatrix createMatrix (NumberObject.NumberObjectRepresentation formatToUse, int nrow, int ncol)	{
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberMatrix(nrow, ncol);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberMatrix(nrow, ncol);
		throw new UnknownNumberObjectException();
	}

	/**
	 * Creates a matrix containing nrow by ncol mutable NumberObjectSingles with value <value>.
	 * @param columnNames
	 * @param nrow
	 * @param ncol
	 */
	public static NumberObjectMatrix createMatrix (NumberObject.NumberObjectRepresentation formatToUse, int nrow, int ncol, double value)	{
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberMatrix(nrow, ncol, value);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberMatrix(nrow, ncol, value);
		throw new UnknownNumberObjectException();
	}

	/**
	 * Create a new NumberObjectMatrix with nrow rows and ncol columns from an array of NumberObjectSingles. If byrow is set to true,
	 * the NumberObjectSingles are added per row. Otherwise, they are added per column.
	 * @param nrow
	 * @param ncol
	 * @param columnNames
	 * @param byrow
	 * @param decimalNumbers
	 */
	public static NumberObjectMatrix createMatrix (NumberObject.NumberObjectRepresentation formatToUse, int nrow, int ncol, boolean byrow, NumberObjectArray array)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberMatrix(nrow, ncol, byrow, array);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberMatrix(nrow, ncol, byrow, array);
		throw new UnknownNumberObjectException();
	}



	/** Create a new NumberObjectMatrix with nrow rows and ncol columns from an array of NumberObjectSingle. If byrow is set to true,
	 * the DecimalNumbers are added per row. Otherwise, they are added per column.
	 * @param nrow
	 * @param ncol
	 * @param columnNames
	 * @param byrow
	 * @param decimalNumbers
	 */
	public static NumberObjectMatrix createMatrix (NumberObject.NumberObjectRepresentation formatToUse, int nrow, int ncol, boolean byrow, NumberObjectSingle... numbers)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberMatrix(nrow, ncol, byrow, numbers);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberMatrix(nrow, ncol, byrow, numbers);
		throw new UnknownNumberObjectException();
	}

	/** Create a new NumberObjectMatrix with nrow rows and ncol columns from an array of doubles. If byrow is set to true,
	 * the doubles are added per row. Otherwise, they are added per column.
	 */
	public static NumberObjectMatrix createMatrix (NumberObject.NumberObjectRepresentation formatToUse, int nrow, int ncol, boolean byrow, double... doubleNumbers)  {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberMatrix(nrow, ncol, byrow, doubleNumbers);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberMatrix(nrow, ncol, byrow, doubleNumbers);
		throw new UnknownNumberObjectException();
	}

	/** Copy constructor. If deepClone is true, the resulting Array is a deep clone (all objects in this array are cloned as well). 
	 * Otherwise its a shallow clone (the objects in this array point to the original objects)*/
	public static NumberObjectMatrix createMatrix (NumberObject.NumberObjectRepresentation formatToUse, NumberObjectMatrix original, boolean deepClone) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return new DecimalNumberMatrix(original, deepClone);
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return new DoubleNumberMatrix(original, deepClone);
		throw new UnknownNumberObjectException();
	}




}
