package abstractNumberObjectsAndInterfaces;

import java.math.RoundingMode;
import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject.UnknownNumberObjectException;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import doubleNumber.DoubleNumber;
import doubleNumber.DoubleNumberArray;
import doubleNumber.DoubleNumberMatrix;

public interface NumberObjectMatrix extends NumberObject {

	
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////// 	Getters and Setters 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** Returns a 2 dimensional array of double values, representing this matrix.*/
	public double[][] to2DDoubleMatrix();
	
	/** Returns a 2 dimensional array of DecimalNuber values, representing this matrix.*/
	public DecimalNumber[][] to2DDecimalNumberMatrix();
	
	/** Returns a 2 dimensional array of DoubleNumber values, representing this matrix.*/
	public DoubleNumber[][] to2DDoubleNumberMatrix();
	
	/** Returns a 2 dimensional array of values of the specified format (DoubleNumber or DecimalNumber), representing this matrix. All values are deep clones*/
	public NumberObjectSingle[][] to2DNumberObjectSingleMatrix(NumberObject.NumberObjectRepresentation formatToUse);
	
	/** Returns a 2 dimensional array of values that representing this matrix.
	 * The returns values are the actual objects underlying this matrix, and hence, will come in the format (DoubleNumber or
	 * DecimalNumber) of the object upon which this function is called (ie, DoubleNumberArray or DecimalNumberArray)*/
	public NumberObjectSingle[][] to2DNumberObjectSingleMatrix();
	
	/** Returns a 2 dimensional array of integer values, representing this matrix.*/
	public Integer[][] toIntegerMatrix(RoundingMode roundingMode);
	
	/** Returns a DecimalNumberMatrix with the same values, column names, and row names as this object*/
	public DecimalNumberMatrix toDecimalNumberMatrix();
	
	/** Returns a DoubleNumberMatrix with the same values, column names and row names as this object*/
	public DoubleNumberMatrix toDoubleNumberMatrix();
	
	/** Returns a DoubleNumberMatrix with the same values, column names and row names as this object*/
	public NumberObjectMatrix toNumberObjectMatrix(NumberObject.NumberObjectRepresentation formatToUse);
	
	
	/** Returns an array of NumberObjectArrays that represent this matrix*/
	public NumberObjectArray[] toArrayOfArrays();
	
	/** Returns the number of rows in this NumberObjectMatrix*/
	public int nrow();
	
	/** Returns the number of rows in this NumberObjectMatrix*/
	public int ncol();
	
	/** Returns the dimensions of the matrix: (nrow, ncol) */
	public int[] dim();
	
	/** Is this matrix set to be immutable?*/
	public boolean isImmutable();
	
	/** Sets the matrix, AND ALL ARRAYS AND DECIMAL NUMBERS WITHIN THIS MATRIX to the desired immutability (i.e., unable to change). 
	 * If set to immutable, subsequent operation that attempts to change this matrix (or the DecimalNumberArrays and DecimalNumbers within
	 * this array) result in a UnsupportedOperationException being thrown. Returns this.
	 * 
	 *  ATTENTION: THIS FUNCTION SHOULD BE USED WITH CAUTION. There is probably a good reason why something is marked as immutable. 
	 * If the goal is to make this object immutable, consider using makeImmutable() */
	public NumberObjectMatrix setImmutable(boolean immutable) ;
	
	/** Marks the matrix, AND ALL ARRAYS AND NumberObjects WITHIN THIS MATRIX as immutable (i.e., unable to change). 
	 * Subsequent operation that attempts to change this matrix (or the DecimalNumberArrays and DecimalNumbers within
	 * this array) result in a UnsupportedOperationException being thrown. */
	public void makeImmutable() ;
		
	
	////////////////////////////	Arrays of rows/columns	/////////////////////////////
	/** Return this matrix as an array of rows. Note that the returned rows are SHALLOW clones of the actual rows - changes in the NumberObject values in the clone result in the same changes in the matrix, but adding an additional entry to the column does not add another entry in the matrix.*/ 
	public NumberObjectArray[] rowMatrix();
	
	/** Return this matrix as an array of columns. Note that the returned columns are SHALLOW clones of the actual columns - changes in the NumberObject values in the clone result in the same changes in the matrix, but adding an additional entry to the column does not add another entry in the matrix. */
	public NumberObjectArray[] columnMatrix() ;
	
	//////////////////////////// 	Names 	/////////////////////////////
	/** Attempts to set the columnNames of the matrix. If the number of names does not match the number of columns, an IllegalArgumentException is thrown. Throws an UnsupportedOperationException if the matrix is immutable*/
	public void setColumnNames (String... newNames) ;
	
	/** Attempts to set the columnNames of the matrix. If the number of names does not match the number of columns, an IllegalArgumentException is thrown. Throws an UnsupportedOperationException if the matrix is immutable*/
	public void setColumnNames (ArrayList<String> newNames) ;
	
	/** Attempts to set the column name of the matrix at index. If the column does not exist, an IllegalArgumentException is thrown. Throws a UnsupportedOperationException if the matrix is immutable.*/
	public void setColumnName (int index, String newName) ;
	
	/** Returns the column names of this matrix. If none are specified, a null is returned.  */
	public String[] getColumnNames() ;

	/** Attempts to set the row names of the matrix. If the number of names does not match the number of rows, an IllegalArgumentException is thrown. Throws an UnsupportedOperationException if the matrix is immutable*/
	public void setRowNames (String... newNames) ;

	/** Attempts to set the row names of the matrix. If the number of names does not match the number of rows, an IllegalArgumentException is thrown. Throws an UnsupportedOperationException if the matrix is immutable*/	
	public void setRowNames (ArrayList<String> newNames) ;
	
	/** Attempts to set the row name of the matrix at index. If the row does not exist, an IllegalArgumentException is thrown. Throws a UnsupportedOperationException if the matrix is immutable.*/
	public void setRowName (int index, String newName);
	
	/** Returns the row with the specified name. If no names are specified a null. */
	public String[] getRowNames() ;
	
	////////////////////////////	Getting indices		/////////////////////////////
	/** Get the index of the column with the specified name. If no names have been specified a ComputationException is thrown. If the name does not exist, an IllegalArgumentException is thrown. */
	public int getIndexOfColumn(String name);
	
	/** Get the index of the row with the specified name. If no names have been specified, a ComputationException is thrown. If the name does not exist, an IllegalArgumentException is thrown. */
	public int getIndexOfRow(String name) ;
	
	/** Get the row index where the specified column has a value of value. If multiple rows match the specification the
	 * lowest index is returned. If no match is found, returns -1.
	 * @return
	 */
	public int getIndexOfRowWhereColumnIs(String columnName, NumberObjectSingle value);

	/** Get the row index where the specified column has a value of value. If multiple rows match the specification the
	 * lowest index is returned. If no match is found, returns -1.
	 * @return
	 */
	public int getIndexOfRowWhereColumnIs(String columnName, double value);

	/**
	 * Get the row index where the specified column has a value of value. If multiple rows match the specification the
	 * lowest index is returned. If no match is found, returns -1.
	 * @return
	 */
	public int getIndexOfRowWhereColumnIs(int columnIndex, NumberObjectSingle value);

	/** Get the row index where the specified column has a value of value. If multiple rows match the specification the
	 * lowest index is returned. If no match is found, returns -1.
	 * @return
	 */
	public int getIndexOfRowWhereColumnIs(int columnIndex, double value);

	/**
	 * Get the first row in which the column has the value. Returns null if value does not occurring at all in the column.
	 * @param value
	 * @param column
	 * @return
	 */
	public NumberObjectArray getRowWhereColumnIs (String columnName, NumberObjectSingle value);
	
	/** Returns the index of the NumberObjectArray (as row) in the matrix. Note that this function only compares pointers, not values. Hence, the argument matches
	 * an row vector only if they are the same object in memory. Returns -1 if no match is found
	 * @return
	 */
	public int getIndexOfNumberObjectArrayRow(NumberObjectArray array) ;
	
	/** Returns the index of the NumberObjectArray (as column) in the matrix. Note that this function only compares pointers, not values. Hence, the argument matches
	 * an row vector only if they are the same object in memory. Returns -1 if no match is found
	 * @return
	 */
	public int getIndexOfNumberObjectArrayColumn(NumberObjectArray array);

	
	////////////////////////////	Rows and columns	/////////////////////////////
	/** Returns a SHALLOW copy of the specified column. If the colnr exceeds the number of columns in the matrix, an IllegalArgumentException is returned. */
	public NumberObjectArray getColumn (int colnr);

	/** Returns a SHALLOW copy of the specified column. If the name does not exist in the matrix, an IllegalArgumentException is returned. */
	public NumberObjectArray getColumn (String name);

	/** Set the column at the specified index position. If the colnr exceeds the number of columns in the matrix, an IllegalArgumentException is thrown. A UnsupportedOperationException is thrown if the matrix is set to immutable (default is mutable) */
	public void setColumn (int colnr, NumberObjectArray array);

	/**Set the column with the specified name. If no column names have been specified a ComputationException is thrown. Throws an UnsupportedOperationException if the matrix is immutable. Throws an IllegalArgumentException name does not exist in the matrix.*/
	public void setColumn (String name, NumberObjectArray array);

	/** Returns a SHALLOW copy of the specified row. If the rownr exceeds the number of row in the matrix, an IllegalArgumentException is returned. */
	public NumberObjectArray getRow (int rownr);

	/** Get the named row. If rows do not have names, a ComputationException is thrown. If the name does not match any of the row names an IllegalArgumentException is thrown. */
	public NumberObjectArray getRow (String rowName);
	
	/** Set the row at the rownr position. If the rownr is <0 or larger than then number of rows, or the new row has an incorrect length, an IllegalArgumentException is thrown. Throws a UnsupportedOperationException if the matrix is immutable */
	public void setRow (int rownr, NumberObjectArray array);
	
	/** Set the row at the rownr position. If the new row has an incorrect length, or the name does not exist in the matrix, an IllegalArgumentException is thrown. Throws a ComputationException if row names have not been specified yet. Throws an UnsupportedOperationException if the matrix is immutable. */
	public void setRow (String name, NumberObjectArray array);

	/**
	 * Get a SHALLOW clone of the first row in which the column has the value. Returns null if value does not occurring at all in the column.
	 * @param value
	 * @param column
	 * @return
	 */
	public NumberObjectArray getRowWhereColumnIs (int columnIndex, NumberObjectSingle value);
	
	/** Get a shallow clone of the row vector where the specified column has the specified value. Use only if the column is sorted ascending. Returns null if the value is not in the column vector.*/
	public NumberObjectArray getRowWhereColumnIs(int columnIndex, double value, boolean sorted);
	
	////////////////////////////	NumberObject objects	/////////////////////////////
	/** Set all the values in the matrix to v. Throws a UnsupportedOperationException if the matrix is immutable. */
	public void setAllValues(NumberObjectSingle v);
	
	/** Returns the NumberObject at position (row, col). */
	public NumberObjectSingle getValueAt (int row, int col);

	/** Get the NumberObject at the named row and named columName. Returns an IllegalArgumentException if either the row name or column name does not exist. Returns a ComputationException if either row or column names have not been specified yet. */
	public NumberObjectSingle getValueAt (String rowName, String columnName) ;
	
	/** Get the NumberObject at the numbered row of the named column. If the matrix has no column names a ComputationException is thrown. If the column name does not exist, an IllegalArgumentException is thrown. If the row index is invalid, an IllegalArgumentException is thrown.  */
	public NumberObjectSingle getValueAt (int row, String columnName);
	
	/** Set the value at position (row, col). The NumberObject object is maintained, but its value is changed. Returns a UnsupportedOperationException is the matrix (or NumberObject) is immutable. Throws an IllegalArgumentException is the row or column number is invalid. */
	public void setValueAt(int row, int col, NumberObjectSingle value);
	
	/** Set the value at position (row, col). The NumberObject object is maintained, but its value is changed. Returns a UnsupportedOperationException is the matrix (or NumberObject) is immutable. Throws an IllegalArgumentException is the row or column number is invalid. */
	public void setValueAt(int row, int col, double value);

	/////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Adding/removing rows/columns 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	/** Appends a new row to the end of the matrix. Since this operation involves copying an array of NumberObjectArrays, this operations can be inefficient. 
	 * Throws an UnsupportedOperationException if the matrix is immmutable. Throws an IllegalArgumentException if the new row has a length different from the number
	 * of columns in the matrix. If row names are specified, the name of this row is set to "".
	 */
	public void appendRow(NumberObjectArray newRow) ;
	
	/** Inserts a new row at the index position. Since this operation involves copying an array of NumberObjectArrays, it might be an inefficient operation. 
	 * Throws a UnsupportedOperationException if the matrix is immutable. Throws an IllegalArgumentException if the length of newRow does not match the number
	 * of columns in the matrix or if the index is out of bounds.
	 * If row names are specified, the name of this row is set to newRowName.
	 */
	public void insertRow(int index, NumberObjectArray newRow, String newRowName);
	/** Inserts a new row at the index position. Since this operation involves copying an array of NumberObjectArrays, it might be an inefficient operation. 
	 * Throws a UnsupportedOperationException if the matrix is immutable. Throws an IllegalArgumentException if the length of newRow does not match the number
	 * of columns in the matrix.
	 * If row names are specified, the name of this row is set to newRowName.
	 */
	public void insertRow(int index, NumberObjectArray newRow) ;

	/** Removes the row at the index position. Since this operation involves copying an array of NumberObjectArrays, it might be an inefficient operation. 
	 * Throws a UnsupportedOperationException if the matrix is immutable. Throws an IllegalArgumentException if the index is out of bounds. */
	public void removeRow(int index);
	
	/** Inserts a new column at the index position. Since this operation involves copying an array of NumberObjectArrays, it can be an quite inefficient operation. 
	 * Throws a UnsupportedOperationException if the matrix (or row vectors) is immutable. Throws an IllegalArgumentException if the length of newColumn does not match the number
	 * of rows in the matrix or if the index is out of bounds.
	 * If column names are specified, the name of this column is set to newRowName.
	 */
	public void insertColumn (int index, NumberObjectArray newColumn, String newColumnName);
	
	/** Inserts a new column at the index position. Since this operation involves copying an array of NumberObjectArrays, it can be an quite inefficient operation. 
	 * Throws a UnsupportedOperationException if the matrix (or row vectors) is immutable. Throws an IllegalArgumentException if the length of newColumn does not match the number
	 * of rows in the matrix or if the index is out of bounds.
	 * If column names are specified, the name of this column is set to "".
	 */
	public void insertColumn (int index, NumberObjectArray newColumn) ;
	
	/** Removes the column at the index position. Since this operation involves copying an array of NumberObjectArrays, it might be an inefficient operation. 
	 * Throws a UnsupportedOperationException if the matrix is immutable. Throws an IllegalArgumentException if the index is out of bounds. */
	public void removeColumn (int index);
	
	/** Replaces the array of NumberObjectArrays (i.e., the matrix itself), the column names, and the row names of this matrix with the new matrix. In essence, 
	 * this matrix is removed, and replaced with the new matrix, while saving the reference pointer. Use this function is the whole matrix has to be replaced.
	 * Does nothing if the matrix is set to immutable (default is mutable)
	 * @param newMatrix
	 */
	public void replaceMatrixWith (NumberObjectMatrix newMatrix) ;
	
	/////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////		Matrix multiplication	/////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * Multiplies this matrix (with dimensions n*m) with matrix B (with dimensions
	 * m * p). The result is a matrix C with dimensions n*p, where the entry at row
	 * i and column j is:
	 * 
	 * C(i, j) = sum ( A(i,k) * B(k,j) ) forall k in [1, m].
	 * 
	 * if the number of columns in A does not match the number of rows in B (i.e.,
	 * ( dimension(A) = [n,m1], dimension(B) = [m2, p], and m1 != m2), an
	 * illegalArgumentException is thrown.
	 * 
	 * This call uses the IKJ method with DecimalNumbers (not doubles).
	 * 
	 * @param matrix1
	 * @param matrix2
	 * @return
	 */
	public NumberObjectMatrix matrixMultiplication (NumberObjectMatrix othermatrix)  ;
	

	/////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////		Other Matrix operations /////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////
	/** Round all NumberObject objects in this matrix to significant digits, or throws UnsupportedOperationException (if matrix is immutable) */
	public NumberObjectMatrix round(int significantDigits) ;
	
	/** Multiplies all NumberObject objects in this matrix with the multiplicand. Throws UnsupportedOperationException if the matrix is mutable. Returns this
	 * @return */
	public NumberObjectMatrix scalarMultiplication(NumberObjectSingle multiplicand) ;
	
	/** Multiplies all NumberObject in this matrix with the multiplicand. Throws UnsupportedOperationException if the matrix is immutable. Returns this. 
	 * @return */
	public NumberObjectMatrix scalarMultiplication(double multiplicand) ;
	
	/**
	 * Multiplies all values in this matrix in an entrywise (or Hadamard) fashion with the elements in othermatrix. Formally:
	 * 
	 * this(i,j) = this(i,j) * otherMatrix(i,j), for all rows i and columns j.
	 * 
	 * Throws an IllegalArgumentException if the dimensions of A are unequal to the dimensions of C.
	 * Throws an UnsupportedOperationException if this matrix is immutable.
	 * 
	 * Returns this.
	 * @param A
	 * @param B
	 * @return 
	 * @return
	 */
	public NumberObjectMatrix entrywiseMultiplication(NumberObjectMatrix  otherMatrix) ;
	
	/** Sets all values in this matrix such that: 
	 * this(i,j) = this(i,j) + augend.
	 * 
	 * Note that this operation does not change values in A.
	 * Throws UnsupportedOperationException if the matrix is immutable
	 * 
	 * Returns this.
	 * @param A
	 * @param augend
	 * @return 
	 */
	public NumberObjectMatrix scalarAddition(NumberObjectSingle augend);
	
	/** Sets all values in this matrix such that: 
	 * this(i,j) = this(i,j) + augend.
	 * 
	 * Note that this operation does not change values in A.
	 * Throws UnsupportedOperationException if the matrix is immutable
	 * 
	 * Returns this.
	 * @param A
	 * @param augend
	 * @return 
	 */
	public NumberObjectMatrix scalarAddition(double augend)	;

	
	/** Adds the other matrix (with dimensions n*m) to this matrix (with dimensions
	 * n*m) as follows:
	 * 
	 * this(i, j) = this(i,j) + otherMatrix(i,j) forall k in [1, m].
	 * 
	 * if the dimensions of A and B do not match an
	 * illegalArgumentException is thrown.
	 * If this matrix is immutable, an UnsupportedOperationException is thrown.
	 * 
	 * returns this.
	 * @param matrix1
	 * @param matrix2
	 * @return
	 */
	public NumberObjectMatrix matrixAddition (NumberObjectMatrix otherMatrix) ;
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Other operations on this matrix 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////

	/** 
	 * Returns a new NumberObjectMatrix, which is the transpose of this matrix. This new NumberObjectMatrix is a shallow copy.
	 * @return
	 */
	public NumberObjectMatrix transpose() ;
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Matrix properties 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * Checks if value exists in the matrix. If approximately is true, values within 0.0000001 are counted as equal.
	 */
	public boolean contains (NumberObjectSingle value, boolean approximately);
	/**
	 * Checks if value exists in the matrix. If approximately is true, values within 0.0000001 are counted as equal.
	 */
	public boolean contains (double value, boolean approximately);
	
	/** Returns the sum of all NumberObject objects in this matrix */
	public NumberObjectSingle sum() ;

	//////////////////////////////////////////////////////////////////////////////////////
	////////////////// 	Subsets, reduction, combination, clone   /////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////
	
	/** Turns the matrix into a single array (shallow copy). If byrow, the array is ordered by row. If not byrow, the matrix is ordered by column */ 
	public NumberObjectArray vectorize(boolean byrow);
	
	/** Returns a DEEP clone (i.e., all DecimalNumberArrays and DecimalNumber's in
	 * this matrix are cloned as well). All cloned values are mutable.
	 */
	public NumberObjectMatrix clone ()	;
	
	/** Returns a SHALLOW clone of the the NumberObjectMatrix. This means that
	 * the objects in the clone are the same references as the objects in the
	 * original - changes in the shallow clone result in changes of the deep clone.
	 * @return
	 */
	public NumberObjectMatrix shallowClone() ;
	/**
	 * Get a new NumberObjectMatrix that houses a subset of all specified range.
	 * @param from
	 * @param to
	 * @return
	 */
	public NumberObjectMatrix subsetRangeOfRows(int from, int to)	;
	
	/**
	 * Get a new NumberObjectMatrix that houses a subset of all specified rows.
	 * @param from
	 * @param to
	 * @return
	 */
	public NumberObjectMatrix subsetRows(int... rowsToKeep);
	
	/**
	 * Returns a SHALLOW copy with the specified entries in the specified column either removed (if removeListed is true),
	 * or returns a copy with only the specified entries (if removeListed = false)
	 * 
	 * If approximate is set to true, values that are 0.00000001 or closer are considered to be equal (use this to
	 * combat rounding issues)
	 * @param columnNameToSelect
	 * @param entries
	 * @param removeListed
	 * @return
	 */
	public NumberObjectMatrix reduce(String columnToSelect, NumberObjectArray entries, boolean removeListed, boolean approximately);
	
	/**
	 * Combine the rows of two NumberObjectMatrix's into a single, new table. Can only combine tables that have the same
	 * number of columns and have the same columnNames names. If only one, but not the other, matrix has specified row
	 * names, new row names with 0 characters (i.e., "") will be created for the not-specified names.
	 * @param table1
	 * @param table2
	 * @return
	 */
	public NumberObjectMatrix rowBind(NumberObjectMatrix otherMatrix);
	
	 /** Combines the column vectors into a single, new table. Throws an IllegalArgumentException if the vectors are of unequal length
	 * The new matrix does not have row or column names.
	 * Changes in the new matrix will result in changes in the arrays, and vice versa.
	 * @param table1
	 * @param table2
	 * @return
	 */
	public NumberObjectMatrix columnBind(NumberObjectArray... columnVectors) ;	
	
	
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Miscellaneous 	/////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////// 
	/** Creates new a new NumberObjectArray that contains the values of this matrix per column, for each column. 
	 * These values are references, not copies (i.e., changes in the array results in changes in the matrix and 
	 * vice versa). Because under the hood the matrix is an array of row vectors, this is a relatively expensive 
	 * operation. It is advised not to use this function too often. If you have to use this function repeatedly, 
	 * consider transposing the matrix once, and using the rows instead. */
	public NumberObjectArray[] toColumnVectors() ;
	
	/** Two matrices are equal if and only if all entries have the same value. */
	public boolean equals (Object other);

	@Override
	public String toString()	;
	/**
	 * 
	 * @param significantDigits
	 * @param colwidth
	 * @return
	 */
	public String toString(int significantDigits, int colwidth);

	void sort(int columnToSortOn, boolean ascending);

	String toCSV(String delimiter);
	
	
}
