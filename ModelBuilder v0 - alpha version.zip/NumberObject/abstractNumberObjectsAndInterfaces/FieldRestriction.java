package abstractNumberObjectsAndInterfaces;

import decimalNumber.DecimalNumber;
import helper.Helper;

public enum FieldRestriction {

	DOUBLE, POSITIVE_DOUBLE, NEGATIVE_DOUBLE, NON_NEGATIVE_DOUBLE, NON_POSITIVE_DOUBLE,
	INTEGER, POSITIVE_INTEGER, NEGATIVE_INTEGER, NON_NEGATIVE_INTEGER, NON_POSITIVE_INTEGER,
	PROBABILITY, NO_RESTRICTIONS,

	DOUBLE_ALLOWING_EMPTY, POSITIVE_DOUBLE_ALLOWING_EMPTY, NEGATIVE_DOUBLE_ALLOWING_EMPTY, NON_NEGATIVE_DOUBLE_ALLOWING_EMPTY, NON_POSITIVE_DOUBLE_ALLOWING_EMPTY,
	PROBABILITY_ALLOWING_EMPTY,

	VARIABLE_NAME, STRING_NUMBERS_LETTERS_ONLY;

	/** An Exception that can be thrown if a restriction is violated*/
	@SuppressWarnings("serial")
	public static class RestrictionViolationException extends Exception { public RestrictionViolationException(String message) {     super(message);  }};

	/** Returns true iff the string matches the specified criterium (e.g., if the string represents a valid double) */
	public static boolean isValid(String s, FieldRestriction criterium) {
		switch(criterium) {
		case DOUBLE: 			return Helper.isDouble(s);
		case POSITIVE_DOUBLE: 	return Helper.isPositiveDouble(s);
		case NEGATIVE_DOUBLE:	return Helper.isNegativeDouble(s);
		case NON_NEGATIVE_DOUBLE: return Helper.isDouble(s) && !Helper.isNegativeDouble(s);
		case NON_POSITIVE_DOUBLE: return Helper.isDouble(s) && !Helper.isPositiveDouble(s);

		case INTEGER: 			return Helper.isInteger(s);
		case POSITIVE_INTEGER: 	return Helper.isPositiveInteger(s);
		case NEGATIVE_INTEGER:	return Helper.isNegativeInteger(s);
		case NON_NEGATIVE_INTEGER: return Helper.isInteger(s) && !Helper.isNegativeInteger(s);
		case NON_POSITIVE_INTEGER: return Helper.isInteger(s) && !Helper.isPositiveInteger(s);

		case DOUBLE_ALLOWING_EMPTY: 			 return s.length()==0 || Helper.isDouble(s);
		case POSITIVE_DOUBLE_ALLOWING_EMPTY: 	 return s.length()==0 || Helper.isPositiveDouble(s);
		case NEGATIVE_DOUBLE_ALLOWING_EMPTY:	 return s.length()==0 || Helper.isNegativeDouble(s);
		case NON_NEGATIVE_DOUBLE_ALLOWING_EMPTY: return s.length()==0 || Helper.isDouble(s) && !Helper.isNegativeDouble(s);
		case NON_POSITIVE_DOUBLE_ALLOWING_EMPTY: return s.length()==0 || Helper.isDouble(s) && !Helper.isPositiveDouble(s);

		case PROBABILITY:						return Helper.isProbability(s);
		case PROBABILITY_ALLOWING_EMPTY:		return s.length()==0 || Helper.isProbability(s);

		case VARIABLE_NAME:					return Helper.isVariableName(s);
		case STRING_NUMBERS_LETTERS_ONLY:	return Helper.isNumbersAndLettersOnly(s);
		case NO_RESTRICTIONS:				return true;
		default:				return false;
		}
	}

	/** Returns the lowest number that a value can have without violating this criterium.
	 * Can return DecimalNumber.NEGATIVE_INFINITY.
	 *
	 * IMPORTANT: this call has an accuracy of DecimalNumber.boundsOfApproximation (by default
	 * that is 0.0000000001). For example, the minimum of positive doubles is 0.0000000001.
	 *
	 * This function returns a value assuming that empty fields are not allowed*/
	public static DecimalNumber getLowestPermissibleValue(FieldRestriction criterium){
		switch(criterium) {
		case DOUBLE: 			return DecimalNumber.NEGATIVE_INFINITY;
		case POSITIVE_DOUBLE: 	return new DecimalNumber(DecimalNumber.boundsOfApproximation);
		case NEGATIVE_DOUBLE:	return DecimalNumber.NEGATIVE_INFINITY;
		case NON_NEGATIVE_DOUBLE: return new DecimalNumber(0);
		case NON_POSITIVE_DOUBLE: return DecimalNumber.NEGATIVE_INFINITY;

		case INTEGER: 			return DecimalNumber.NEGATIVE_INFINITY;
		case POSITIVE_INTEGER: 	return new DecimalNumber(1);
		case NEGATIVE_INTEGER:	return DecimalNumber.NEGATIVE_INFINITY;
		case NON_NEGATIVE_INTEGER: return new DecimalNumber(0);
		case NON_POSITIVE_INTEGER: return DecimalNumber.NEGATIVE_INFINITY;

		case DOUBLE_ALLOWING_EMPTY: 			 return DecimalNumber.NEGATIVE_INFINITY;
		case POSITIVE_DOUBLE_ALLOWING_EMPTY: 	 return new DecimalNumber(DecimalNumber.boundsOfApproximation);
		case NEGATIVE_DOUBLE_ALLOWING_EMPTY:	 return DecimalNumber.NEGATIVE_INFINITY;
		case NON_NEGATIVE_DOUBLE_ALLOWING_EMPTY: return new DecimalNumber(0);
		case NON_POSITIVE_DOUBLE_ALLOWING_EMPTY:  return DecimalNumber.NEGATIVE_INFINITY;

		case PROBABILITY:						return new DecimalNumber(0);
		case PROBABILITY_ALLOWING_EMPTY:		return new DecimalNumber(0);

		case VARIABLE_NAME:					return null;
		case STRING_NUMBERS_LETTERS_ONLY:	return null;
		case NO_RESTRICTIONS:				return DecimalNumber.NEGATIVE_INFINITY;
		default:				return null;
		}
	}
	/** Returns the highest number that a value can have without violating this criterium.
	 * Can return DecimalNumber.Positive_INFINITY.
	 *
	 * IMPORTANT: this call has an accuracy of DecimalNumber.boundsOfApproximation (by default
	 * that is 0.0000000001). For example, the maximum of negative doubles is -0.0000000001.
	 *
	 * This function returns a value assuming that empty fields are not allowed*/
	public static DecimalNumber getHighestPermissibleValue(FieldRestriction criterium){
		switch(criterium) {
		case DOUBLE: 			return DecimalNumber.POSITIVE_INFINITY;
		case POSITIVE_DOUBLE: 	return DecimalNumber.POSITIVE_INFINITY;
		case NEGATIVE_DOUBLE:	return new DecimalNumber(DecimalNumber.boundsOfApproximation).negate();
		case NON_NEGATIVE_DOUBLE: return DecimalNumber.POSITIVE_INFINITY;
		case NON_POSITIVE_DOUBLE: return new DecimalNumber(0);

		case INTEGER: 			return DecimalNumber.POSITIVE_INFINITY;
		case POSITIVE_INTEGER: 	return DecimalNumber.POSITIVE_INFINITY;
		case NEGATIVE_INTEGER:	return  new DecimalNumber(-1);
		case NON_NEGATIVE_INTEGER: return DecimalNumber.POSITIVE_INFINITY;
		case NON_POSITIVE_INTEGER: return new DecimalNumber(0);

		case DOUBLE_ALLOWING_EMPTY: 			 return DecimalNumber.POSITIVE_INFINITY;
		case POSITIVE_DOUBLE_ALLOWING_EMPTY: 	 return DecimalNumber.POSITIVE_INFINITY;
		case NEGATIVE_DOUBLE_ALLOWING_EMPTY:	 return new DecimalNumber(DecimalNumber.boundsOfApproximation).negate();
		case NON_NEGATIVE_DOUBLE_ALLOWING_EMPTY: return DecimalNumber.POSITIVE_INFINITY;
		case NON_POSITIVE_DOUBLE_ALLOWING_EMPTY:  return new DecimalNumber(0);

		case PROBABILITY:						return new DecimalNumber(1);
		case PROBABILITY_ALLOWING_EMPTY:		return new DecimalNumber(1);

		case VARIABLE_NAME:					return null;
		case STRING_NUMBERS_LETTERS_ONLY:	return null;
		case NO_RESTRICTIONS:				return DecimalNumber.POSITIVE_INFINITY;
		default:				return null;
		}
	}
	/** First parses the numberString to a DecimalNumber. If the number is not a possible DecimalNumber,
	 * this function returns null.
	 *
	 * Next, returns the lowest number x that, when added to this number, results in the criterium's minimum value.
	 * Might return DecimalNumber.NEGATIVE_INFINITY. Note that this function returns a
	 * positive value if numberString is a number lower than the minimum.  */
	public static DecimalNumber additionUntilMinimum(String numberString, FieldRestriction criterium){
		if (!Helper.isDouble(numberString))
			return null;

		DecimalNumber lowerBound = getLowestPermissibleValue(criterium) ;
		if (lowerBound == DecimalNumber.NEGATIVE_INFINITY)
			return DecimalNumber.NEGATIVE_INFINITY;

		return lowerBound.subtract(new DecimalNumber(numberString));
	}

	/** First parses the numberString to a DecimalNumber. If the number is not a possible DecimalNumber,
	 * this function returns null.
	 *
	 * Next, returns the highest number x that, when added to this number, results in the criterium's maximum value.
	 * Might return DecimalNumber.POSITIVE_INFINITY. Note that this function returns a
	 * negative value if numberString is a number higher than the maximum.  */
	public static DecimalNumber additionUntilMaximum(String numberString, FieldRestriction criterium){
		if (!Helper.isDouble(numberString))
			return null;

		DecimalNumber upperBound = getHighestPermissibleValue(criterium) ;
		if (upperBound == DecimalNumber.POSITIVE_INFINITY)
			return DecimalNumber.POSITIVE_INFINITY;

		return upperBound.subtract(new DecimalNumber(numberString));
	}
}
