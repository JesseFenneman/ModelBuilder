package attributes;

import java.io.Serializable;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectMatrix;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import interfaces_abstractions.ObserverManager;
import start.CentralExecutive;

/**
 * An AttributeField object is, essentially, NumberObject 'slot' (i.e., something can contain a single NumberObject).
 * Each AttributeField object has
 * - A name;
 * - A value (the NumberObject);
 * - A class restriction (determines whether this object can contain only NumberObjectSingle, NumberObjectArray, NumberObjectMatrix, or whether it can contain all NumberObject values);
 * - A FieldRestriction (determines which values are permissible - e.g, only positive integers).
 * - A description to convey what this attribute does (optional, can be set only once - after which it is permanent)
 * */
public class AttributeField implements Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	/** Sometimes the value of this AttributeField can only be NumberObjectSingle, or NumberObjectArray, or a NumberObjectMatrix. If so, assigning a wrong type results in a IncombatibleNumberObjectTypeException. */
	@SuppressWarnings("serial")
	public static class IncompatibleNumberObjectTypeException extends RuntimeException { public IncompatibleNumberObjectTypeException(String message) {     super(message);  }}

	private final String name;
	private String description;
	private NumberObject value;
	private FieldRestriction fieldRestriction; // The restriction the value can have (e.g., allow only positive doubles)
	private Class<? extends NumberObject> classRestriction; //The type of class (NumberObjectSingle, NumberObjectArray, or NumberObjectMatrix) the value can be.
	private boolean isMutable;


	/// Constructors and factories

	/** Create an AttributeField with no field or class restrictions. The exceptions here can be safely ignored. There are no class restrictions for future values.
	 * That is, this AttributeField can contain single numbers, array, or matrices. */
	public static AttributeField attributeFieldFactory(String name, NumberObject value) {
		try {
			return new AttributeField(name, value, FieldRestriction.NO_RESTRICTIONS, NumberObject.class);
		} catch (IncompatibleNumberObjectTypeException | RestrictionViolationException e) {
			ObserverManager.notifyObserversOfError(e);
			return null;
		}
	}

	/** Create an AttributeField with no field or class restrictions - and no initial value. You can ignore the Exceptions, as there is no value to violate anything.
	 * @throws RestrictionViolationException
	 * @throws IncompatibleNumberObjectTypeException **/
	public AttributeField(String name) throws IncompatibleNumberObjectTypeException, RestrictionViolationException{
		this(name, null, FieldRestriction.NO_RESTRICTIONS, NumberObject.class);
	}

	/** Create an AttributeField with no field or class restrictions.
	 * The classRestriction is set to the class of value - that is, all future values must be of the same NumberObject subclass
	 * (i.e., NumberObjectSingle, NumberObjectArray, or NumberObjectMatrix).
	 * @throws RestrictionViolationException
	 * @throws IncompatibleNumberObjectTypeException */
	public AttributeField(String name, NumberObject value) throws RestrictionViolationException {
		this(name, value, FieldRestriction.NO_RESTRICTIONS, valueToClassRestriction(value));
	}

	/** Create an AttributeField. If the value does not match the FieldRestriction, a RestrictionViolationException is thrown.
	 *  The classRestriction is set to the class of value - that is, all future values must be of the same NumberObject subclass
	 *  (i.e., NumberObjectSingle, NumberObjectArray, or NumberObjectMatrix). */
	public AttributeField(String name, NumberObject value, FieldRestriction fieldRestriction) throws RestrictionViolationException {
		this(name, value, fieldRestriction, valueToClassRestriction(value));
	}

	/** Create an AttributeField with field and range restrictions, but no value (yet). Can ignore the Exceptions.
	 */
	public AttributeField(String name, FieldRestriction fieldRestriction, Class<? extends NumberObject> classRestriction) throws RestrictionViolationException {
		this(name, null, fieldRestriction, classRestriction);
	}
	/** The full constructor. Create an AttributeField with the specified name and value. This value, and all future values,
	 * have to satisfy the specified fieldRestriction (e.g., have to be positive doubles), and the
	 * classRestriction (i.e., this attributeField can sometimes only contain single, array, or matrix values).
	 *
	 * Failing to satisfy the fieldRestriction results in a RestrictionViolationException. Failing to satisfy the
	 * classRestriction results in a IncompatibleNumberObjectTypeException. */
	public AttributeField(String name, NumberObject value, FieldRestriction fieldRestriction, Class<? extends NumberObject> classRestriction)
			throws RestrictionViolationException, IncompatibleNumberObjectTypeException {
		this.name = name;
		this.value = value;
		this.fieldRestriction = fieldRestriction;
		this.isMutable = true;
		this.classRestriction = classRestriction;

		if (classRestriction != NumberObjectSingle.class &&
				classRestriction != NumberObjectArray.class &&
				classRestriction != NumberObjectMatrix.class)
			throw new IllegalArgumentException("Illegal class restriction: '" + classRestriction.getSimpleName() + "' is neither NumberObjectSingle, NumberObjectArray, or NumberObjectMatrix" );
		
		if (value != null){
			if (!value.matchesFieldRestriction(fieldRestriction))
				throw new RestrictionViolationException("Trying to create an AttributeField with a value that does match the restriction for this value. Value: " + value + ". Restriction: " + fieldRestriction.name());

			if (classRestriction != NumberObject.class)
				if (! classRestriction.isAssignableFrom(value.getClass()))
					throw new IncompatibleNumberObjectTypeException("Trying to create a " + value.getClass().getSimpleName() + " object to an AttributeField that can only contain instances of " + classRestriction.getSimpleName());
		}
	}

	/** Copy constructor */
	public AttributeField(AttributeField original) {
		this.name = original.name;
		this.value = original.getValueCopy();
		this.fieldRestriction = original.fieldRestriction;
		this.isMutable = true;
		this.classRestriction = original.classRestriction;
	}

	//// Static functions

	/** The class restrictions of an AttributeField can be NumberObjectSingle, NumberObjectArray, or NumberObjectMatrix.
	 * Usually, this restriction is set upon instantiating an AttributeField object. Specifically, it is implicitly assumed
	 * that all future values of an AttributeField must have the same class as the value that this attribute is instantiated with.
	 * For instance, a Constant object contains a single AttributeField - its value. This value is specified when first instantiating
	 * the Constant object (e.g., 2). In the future this value may change the class (e.g., 3), but it should always have the
	 * same class (i.e., a single value, not an array). However, the value passed to the constructor is not a NumberObjectSingle,
	 * NumberObjectArray, or NumberObjectMatrix, as these are interfaces (and thus cannot be instantiated). This function
	 * takes as input a NumberObject (e.g., a DecimalNumber with value 2) and returns the correct interface (e.g., a NumberObjectSingle).
	 */
	public static Class<? extends NumberObject> valueToClassRestriction(NumberObject value){
		if (NumberObjectSingle.class.isAssignableFrom(value.getClass()))
			return NumberObjectSingle.class;
		if (NumberObjectArray.class.isAssignableFrom(value.getClass()))
			return NumberObjectArray.class;
		if (NumberObjectMatrix.class.isAssignableFrom(value.getClass()))
			return NumberObjectMatrix.class;
		throw new IllegalStateException("Trying to identify the class of a value to determine future class restrictions. However, the value is not a NumberObjectSingle, NumberObjectArray, or NumberObjectMatrix. The value is of class: " + value.getClass().getSimpleName());
	}

	//// Getters, setters, and state-checkers
	/** Returns true if, and only if, the newValue satisfies the fieldRestriction (e.g., all values must be positive integers). */
	public boolean satisfiesFieldRestriction(NumberObject newValue) {
		return (newValue.matchesFieldRestriction(fieldRestriction));
	}
	 /** Returns true if, and only if, the newValue satisfies the classRestriction (i.e., the newValue must be an NumberObjectSingle object, or must be a NumberObjectArray type, or a NumberObjectMatrix type.) */
	public boolean satisfiesClassRestriction(NumberObject newValue) {
		return ( classRestriction.isAssignableFrom(newValue.getClass()));
	}

	/** Set the description of this Field. Returns false if a description already exists. Note that descriptions cannot be overwritten! */
	public boolean setDescription(String description){
		if (this.description == null){
			this.description = description;
			return true;
			}
		return false;
	}
	/** Set the value of this Field.
	 * If the value does not match the FieldRestriction, an RestrictionViolationException is thrown.
	 * if there is a restriction to the type of NumberObject this attribute can house, and the newValue is not of this type, an IncompatibleNumberObjectTypeException is thrown.
	 * If this AttributeField is not mutable, a UnsupportedOperationException is thrown. */
	public void setValue(NumberObject newValue) throws IncompatibleNumberObjectTypeException, RestrictionViolationException{
		if (!satisfiesFieldRestriction(newValue))
			throw new RestrictionViolationException("Trying to set an AttributeField with a value that does match the field restriction for this value. New value: " + newValue + ". Restriction: " + fieldRestriction.name());

		if (!satisfiesClassRestriction(newValue))
			if (! classRestriction.isAssignableFrom(newValue.getClass()))
				throw new IncompatibleNumberObjectTypeException("Trying to assign a " + newValue.getClass().getSimpleName() + " object to an AttributeField that can only contain instances of " + classRestriction.getSimpleName());

		if (!isMutable)
			throw new UnsupportedOperationException("Trying to change an immutable AttributeField.");

		this.value = newValue;
	}

	/** Set the fieldRestriction of this Field.
	 * If the existing value does not match this restriction, a RestrictionViolationException is thrown.
	 * If this AttributeField is not mutable, a UnsupportedOperationException is thrown.*/
	public void setFieldRestriction(FieldRestriction newFieldRestriction) throws RestrictionViolationException {
		if (!satisfiesFieldRestriction(value))
			throw new RestrictionViolationException("Trying to change the restriction of a AttributeField. However, the existing value of this Attribute does not match the restriction. Value: " + value + ". New field restriction: " + newFieldRestriction.name());

		if (!isMutable)
			throw new UnsupportedOperationException("Trying to change an immutable AttributeField.");

		this.fieldRestriction = newFieldRestriction;
	}

	/** Sets both the value and restriction of this field.
	 * If the newValue does not match the newRestriction, a RestrictionViolationException is thrown.
	 * If there is a restriction to the type of NumberObject this attribute can house, and the newValue is not of this type, an IncompatibleNumberObjectTypeException is thrown.
	 * If this AttributeField is not mutable, a UnsupportedOperationException is thrown.*/
	public void setValueAndRestriction(NumberObject newValue, FieldRestriction newFieldRestriction) throws RestrictionViolationException {
		if (!satisfiesFieldRestriction(newValue))
			throw new RestrictionViolationException("Trying to change the restriction and value of a AttributeField. However, the new value of this Attribute does not match the new restriction. New value: " + newValue + ". New field restriction: " + newFieldRestriction.name());

		if (!satisfiesClassRestriction(newValue))
			if (! classRestriction.isAssignableFrom(newValue.getClass()))
				throw new IncompatibleNumberObjectTypeException("Trying to assign a " + newValue.getClass().getSimpleName() + " object to an AttributeField that can only contain instances of " + classRestriction.getSimpleName());

		if (!isMutable)
			throw new UnsupportedOperationException("Trying to change an immutable AttributeField.");

		this.value = newValue;
		this.fieldRestriction = newFieldRestriction;
	}

	/** Set the class restriction for this object. This determines what type of class this AttributeField can hold (i.e., single, array, or matrix). This class has to be a direct subclass of NumberObject.
	 * If not, a RestrictionViolationException is thrown. If the current value is not of the correct class, a IncompatibleNumberObjectTypeException is also thrown.
	 * To remove the class restriction (for instance, when the value has to be changed first), you can first assign the NumberObject class as the restriction. */
	public void setClassRestriction(Class<? extends NumberObject> newClassRestriction) {
		
System.err.println("Here? " + newClassRestriction);
		if (!satisfiesClassRestriction(value))
				throw new IncompatibleNumberObjectTypeException("Trying to set the class restriction to " + newClassRestriction.getSimpleName() + ". However, the current value is an instance of " + value.getClass().getSimpleName() + ". (Tip: consider first setting the class restriction to NumberObject, then changing the value, and then again setting the class restriction.)");
		this.classRestriction = newClassRestriction;
	}

	/** Returns a deep clone*/
	public AttributeField clone(){
		return new AttributeField(this);
	}

	/** Returns a deep clone of the value.
	 *  Changes in this clone do not result in changes in the AttributeField. 
	 *  Will return null of no value has been set yet. */
	public NumberObject getValueCopy () {
		if (value == null)
			return null;
		return value.clone();
	}

	/** Returns a description if set. Otherwise returns null. */
	public String getDescription(){
		return this.description;
	}

	public String getName() {
		return this.name;
	}

	/**Returns a call to the .toString() function of the value. Does not require a copy of the value. */
	public String getValueString() {
		return value.toString();
	}
	
	/**Returns a call to the .toString() function of the value. Does not require a copy of the value. */
	public String getValueStringWithoutTrailingZeros() {
		return value.toStringWithoutTrailingZeros();
	}

	/**Returns a call to the .toString() function of the value. Does not require a copy of the value. */
	public String getValueString(int significantDigits) {
		return value.toString(significantDigits);
	}

	public String toString() {
		return "An AttributeField with the name: '" + name + "' and value: " + value + "\n\t(This Attribute has the following class restrictions: " + classRestriction.getSimpleName() + ")\n\t(This class has the following value restriction: " + fieldRestriction + ")" ;
	}

	/** Returns true if changes to this AttributeField are permitted. */
	public boolean isMutable() {return isMutable;}

	/** Prevent further changes to this AttributeField. If changes are attempted while this AttributeField is not mutable, a UnsupportedOperationException is thrown. Note: his does NOT make the NumberObject in this attribute immutable! */
	public void makeImmutable() { this.isMutable = false; }

	@Deprecated
	/** Allows future changes to this Field. Should not really be used - there is probably a reason why this field is set to be immutable. Note: this does NOT make the NumberObject in this attribute mutable! */
	public void iAmReallySureIWantToMakeThisFieldMutable() { this.isMutable = true;}

	/** Returns the FieldRestriction used for this attribute */
	public FieldRestriction getFieldRestriction() {return this.fieldRestriction;}

	/** Returns the FieldRestriction used for this attribute */
	public Class<? extends NumberObject> getClassRestriction() {return this.classRestriction;}
}
