package doubleNumber;

import abstractNumberObjectsAndInterfaces.NamedNumberObjectMatrix;
import abstractNumberObjectsAndInterfaces.NumberObject;

public class NamedDoubleNumberMatrix extends DoubleNumber implements NamedNumberObjectMatrix{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NumberObject toNumberObject() {
		// TODO Auto-generated method stub
		return null;
	}

}
