package doubleNumber;

import abstractNumberObjectsAndInterfaces.NamedNumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObject;

public class NamedDoubleNumberArray extends DoubleNumberArray implements NamedNumberObjectArray{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NumberObject toNumberObject() {
		// TODO Auto-generated method stub
		return null;
	}

}
