package doubleNumber;

import java.io.Serializable;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Iterator;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle.VALUE_FLAG;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import helper.Helper;

public class DoubleNumberArray implements Serializable, Cloneable, Iterable<DoubleNumber>, NumberObjectArray{

	private static final long serialVersionUID = Helper.programmeVersion;
	public DoubleNumber[] array;
	private int length;
	private boolean immutable = false;


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	CONSTRUCTORS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	public DoubleNumberArray(NumberObjectSingle... numbers) { 
		this.array = new DoubleNumber[numbers.length] ;
		for (int i = 0; i < array.length; i ++)
			array[i] = numbers[i].toDoubleNumber();
		this.length = array.length; 
	}

	/** Creates a DoubleNumberArray, consisting of mutable DoubleNumbers with the values specified and without a range limitation
	 * 
	 * @param numbers The double values to be converted to mutable DoubleNumbers
	 */
	public DoubleNumberArray(double... numbers) { 
		this.array = new DoubleNumber[numbers.length] ;
		for (int i = 0; i < array.length; i ++)
			array[i] = new DoubleNumber(numbers[i]);
		this.length = array.length; 
	}

	/** Shallow clone*/
	public DoubleNumberArray(DoubleNumber... numbers) { 
		this.array = new DoubleNumber[numbers.length] ;
		for (int i = 0; i < array.length; i ++)
			array[i] = numbers[i];
		this.length = array.length; 
	}

	/** Creates a DoubleNumberArray, consisting of mutable DoubleNumbers with the values, range and immutability specified
	 * 
	 * @param numbers The double values to be converted to mutable DecimalNumbers
	 */
	public DoubleNumberArray(double minimum, double maximum, boolean immutable, double... numbers) { 
		this.length = numbers.length;
		this.array = new DoubleNumber[length];
		for (int i = 0; i < length; i ++)
			array[i] = new DoubleNumber(numbers[i], minimum, maximum, false); 

	}

	/** Creates a DoubleNumberArray that contains all values between minimum and maximum that
	 * are in the set {x | minimum+nx, x < maximum}.
	 * 
	 * If the supplied minimum is larger than the maximum, the two are reversed.
	 * Thus, the stepSize always has to be positive (no fancy stuff like: an array from -2 to -10 with steps of -1; 
	 * only -10 to -2 with steps of 1 is allowed!).
	 * @return
	 */
	public DoubleNumberArray (NumberObjectSingle minimum, NumberObjectSingle maximum, NumberObjectSingle stepSize) {
		// Make sure that the minimum is smaller than the maximum. If this is not the case, flip the two around
		if (!maximum.largerThanOrEqualTo(minimum)) {
			NumberObjectSingle temp = maximum;
			maximum = minimum;
			minimum = temp;
		}

		// The step size has to be a positive value
		if (stepSize.smallerThan(0))
			if (!minimum.equals(maximum))
				throw new IllegalArgumentException("Trying to create a DecimalNumberArray with a non-positive step size. ");

		this.length=maximum.subtract(minimum, false).divide(stepSize).round(0, RoundingMode.DOWN).toInt(RoundingMode.HALF_EVEN)+1;
		this.array = new DoubleNumber[this.length];
		for (int i = 0; i < length; i++) 
			array[i] = minimum.add(stepSize.multiply(i, false), false).toDoubleNumber();
	}


	/** Creates a DoubleNumberArray of size n. The DoubleNumbers in this array are all non-initialized (i.e., null)
	 * 
	 * @param n
	 */
	public DoubleNumberArray(int n) {
		this.array = new DoubleNumber[n];
		this.length=n;
	}

	/** Copy constructor. If deepClone is true, the resulting Array is a deep clone (all objects in this array are cloned as well). Otherwise its a shallow clone (the objects in this array point to the original objects)*/
	public DoubleNumberArray (NumberObjectArray original, boolean deepClone) {
		this.length = original.size();
		this.array = new DoubleNumber[length];
		for (int i = 0; i < length; i ++)
			if (deepClone)
				array[i] = original.get(i).toDoubleNumber().clone();
			else
				array[i] = original.get(i).toDoubleNumber().clone();

	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Static functions that create new Arrays 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/** Creates an array of length length with values between min and max.*/
	public static DoubleNumberArray randomArray(int length, double min, double max, boolean integerOnly ) {
		double[] values = new double[length];
		for (int i = 0; i < length; i++) {
			values[i] = Math.random()*(max-min) + min;
			if (integerOnly) values[i] = Math.round(values[i]);
		}
		return new DoubleNumberArray(values);
	}

	/** Creates an array that consists of n repeats of value */
	public static DoubleNumberArray repeat(int length, Number value) {
		DoubleNumber[] array = new DoubleNumber[length];
		for (int i = 0; i < length; i++)
			array[i] = new DoubleNumber(value);
		return new DoubleNumberArray(array);
	}

	/** Creates an array that consists of n repeats of value */
	public static DoubleNumberArray repeat(int length, NumberObjectSingle value) {
		DoubleNumber[] array = new DoubleNumber[length];
		for (int i = 0; i < length; i++)
			array[i] = value.toDoubleNumber().clone();
		return new DoubleNumberArray(array);
	}

	/**
	 * Returns the dot product (AKA inner product) of both arrays. Formally, returns:
	 * sum( this[i] * otherArray[i] ) for all i in [0, this.length]. 
	 * 
	 * Throws a UnsupportedOperationException if the arrays are unequal in length.
	 * @param array1
	 * @param array2
	 * @return
	 */
	public static DoubleNumber dotProduct(NumberObjectArray array1, NumberObjectArray array2)   {
		if (array1.size() != array2.size())
			throw new IllegalArgumentException("Dotproduct: trying to get dot product of arrays of unequal size.");

		DoubleNumber sum = new DoubleNumber(0);
		for (int i = 0; i < array1.size(); i ++)
			sum.add(array1.get(i).multiply(array2.get(i), false));

		return sum;
	}

	/** Returns a unity vector (a row vector containing only 1's) of the specified length */
	public static DoubleNumberArray unityVector(int length) {
		return DoubleNumberArray.rep(1, length);
	}


	/**
	 * Results in an array containing the sequence from <from> (inclusive) to <to> (exclusive),
	 *  increasing with step size <step>.
	 * @param from
	 * @param to
	 * @param step
	 * @return
	 */
	public static DoubleNumberArray sequence(NumberObjectSingle from, NumberObjectSingle to, NumberObjectSingle step)  	{		
		DoubleNumber f = from.toDoubleNumber();
		DoubleNumber t = to.toDoubleNumber();
		DoubleNumber s = step.toDoubleNumber();

		int indices = t.subtract(f, false).divide(s, false).toInt(RoundingMode.HALF_EVEN)+1;

		DoubleNumber[] sequence = new DoubleNumber[indices];
		for (int i = 0; i < indices; i++) {
			sequence[i] = f.add(s.multiply(i, false), false).setImmutable(false);
		}

		return new DoubleNumberArray(sequence);
	}

	/** Results in an array containing the sequence from <from> (inclusive) to <to> (exclusive),
	 *  increasing with step size <step>.
	 * @param from
	 * @param to
	 * @param step
	 * @return 
	 */
	public static DoubleNumberArray sequence(double from, double to, double step)  	{
		int indices = (int) ( (to-from)/(step)) + 1;

		DoubleNumber[] sequence = new DoubleNumber[indices];
		for (int i = 0; i < indices; i++)
			sequence[i] = new DoubleNumber(from + (step*i));

		return new DoubleNumberArray(sequence);
	}

	/**
	 * Results in an array containing n clones of the value.
	 * @param from
	 * @param to
	 * @param step
	 * @return
	 */
	public static DoubleNumberArray rep(NumberObjectSingle value, int n)	{
		DoubleNumber[] sequence = new DoubleNumber[n];
		for (int i = 0; i < n; i++)
			sequence[i] = value.toDoubleNumber().clone();

		return new DoubleNumberArray(sequence);
	}

	/**
	 * Results in an array containing n clones of the value.
	 * @param from
	 * @param to
	 * @param step
	 * @return
	 */
	public static DoubleNumberArray rep(double value, int n)	{
		DoubleNumber[] sequence = new DoubleNumber[n];
		for (int i = 0; i < n; i++)
			sequence[i] = new DoubleNumber(value);

		return new DoubleNumberArray(sequence);
	}


	/** Creates a DoubleNumberArray that contains all values that are a multiple of stepsize and fall in the range
	 * [minimum, maximum]. Specifically, all values that are in the set 
	 * 
	 * {n * stepsize | x = n*stepsize, minimum < x < maximum}.
	 * 
	 * If the supplied minimum is larger than the maximum, the two are reversed.
	 * Thus, the stepSize always has to be positive (no fancy stuff like: an array from -2 to -10 with steps of -1; 
	 * only -10 to -2 with steps of 1 is allowed!).
	 * @return
	 */
	public static DoubleNumberArray allMultiplesInRange (NumberObjectSingle minimum, NumberObjectSingle maximum, NumberObjectSingle stepSize) {
		DoubleNumber min = minimum.toDoubleNumber();
		DoubleNumber max = maximum.toDoubleNumber();
		DoubleNumber step = stepSize.toDoubleNumber();

		// Make sure that the minimum is smaller than the maximum. If this is not the case, flip the two around
		if (!max.largerThanOrEqualTo(min)) {
			DoubleNumber temp = max;
			max = min;
			min = temp;
		}
		// The step size has to be a positive value
		if (step.smallerThan(0))
			if (!min.equals(max))
				throw new IllegalArgumentException("Trying to create a DoubleNumberArray with a non-positive step size. ");

		// Compute the lowest multiple of stepsize that is still larger than minimum.
		// First, compute the lowest multiple that is smaller than the minimum
		// This value is the computed by computing the module between minimum and stepsize.
		// Because the first multiple must be larger than the minimum, we subtract the modulus
		// from the stepsize, and add the result to the minimum. Hence:
		// smallestMultiple = minimum - mod(minimum, stepsize)
		DoubleNumber smallestMultiple = min.subtract( (min.mod(step)) ) ;

		// This value can be lower than the minimum. If so, add one stepsize
		if (smallestMultiple.smallerThan(min))
			smallestMultiple.add(step, true);

		// Similarly, the largestMultiple is maximum - mod(maximum, stepsize)
		DoubleNumber largestMultiple = max.subtract(   max.mod(step)   );

		// The array is then a sequence from smallestMultiple to largestMultiple with the same stepSize:
		return new DoubleNumberArray(smallestMultiple, largestMultiple, step);


	}

	/////////////////////////////////////////////////////////////////////////////
	/////////////////////////// 	Transformations /////////////////////////////
	/////////////////////////////////////////////////////////////////////////////
	@Override
	public double[] toDoubleArray() {
		double[] doubleArray = new double[length];
		for (int i = 0; i < length; i ++)
			doubleArray[i] = array[i].toDouble();
		return doubleArray;
	}

	@Override
	public Integer[] toIntegerArray(RoundingMode rm) {
		Integer[] a = new Integer[length];
		for (int i = 0; i < length; i ++)
			a[i] = array[i].toInt(rm);
		return a;
	}

	@Override
	public DecimalNumberArray toDecimalNumberArray() {return new DecimalNumberArray(this.array);}

	@Override
	public DoubleNumberArray toDoubleNumberArray() {return this; }

	@Override
	public NumberObjectArray toNumberObjectArray(NumberObjectRepresentation formatToUse) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return this.toDecimalNumberArray();
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return  this.toDoubleNumberArray();
		throw new UnknownNumberObjectException();
	}


	@Override
	public NumberObjectSingle[] toArray() {
		return array;
	}

	@Override
	public NumberObjectSingle[] toArray(NumberObjectRepresentation formatToUse) {
		NumberObjectSingle[] a = new NumberObjectSingle[length];
		for (int i = 0; i < length; i ++)
			a[i] = array[i].toNumberObjectSingle(formatToUse);
		return a;
	}

	/** Provides a NumberObjectMatrix with all possible combinations of array1 and array2.
	 * For example, if array1 = {1,2,3} and array2 = {4,5,6}, then the result is a matrix with
	 * two columns:
	 * array1 			array2
	 * -------------------------
	 * 1			4
	 * 1			5
	 * 1			6
	 * 2			4
	 * 2			5
	 * 2			6
	 * 3			4
	 * 3			5
	 * 3			6
	 * */
	public static DoubleNumberMatrix expandGrid(NumberObjectArray array1, NumberObjectArray array2) {
		// TODO
		throw new UnsupportedOperationException("Not yet implemented. Use DecimalNumberArray version instead.");
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////// 	Elementary operations - setters, getters, checks 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean isImmutable() { return this.immutable; }

	@Override	
	public int size() {
		return array.length;
	}

	@Override
	public DoubleNumber get(int index) { return array[index]; }

	@Override
	public void set(int index, NumberObjectSingle element) 	{ 
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		if (index < 0 || index> length ) throw new ArrayIndexOutOfBoundsException("Trying to set index " + index + "of an array with size " + size());

		array[index] = element.toDoubleNumber();
	}

	@Override
	public void set (int index, double element) 	{ 
		this.set(index, new DoubleNumber(element));
	}

	@Override
	public void setAll(double newValue){
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");

		for (int i = 0; i <array.length; i++) {
			if (array[i] == null)
				array[i] = new DoubleNumber(newValue);
			else 
				array[i].set(newValue);
		}
	}

	@Override
	public void setAll(NumberObjectArray newValues)   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		if (newValues.size()> length ) throw new ArrayIndexOutOfBoundsException("Trying to set all values in this array, with has size " + size() + ", to the values in another array, which has size " + newValues.size());

		for (int i = 0; i < length; i ++)
			array[i].set(newValues.get(i));

	}

	@Override
	public void insert(int index, NumberObjectSingle number) {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		if (index < 0 || index> length ) throw new ArrayIndexOutOfBoundsException("Trying to set index " + index + "of an array with size " + size());

		DoubleNumber[] newArray = new DoubleNumber[length+1];
		System.arraycopy(array, 0, newArray, 0, index);
		System.arraycopy(array, index, newArray, index + 1, array.length - index );
		newArray[index] = number.toDoubleNumber();
		array = newArray;
		length = array.length;
	}

	@Override
	public void remove(int index) {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		if (index < 0 || index> length ) throw new ArrayIndexOutOfBoundsException("Trying to set index " + index + "of an array with size " + size());


		DoubleNumber[] newArray = new DoubleNumber[array.length-1];		
		System.arraycopy(array,0,newArray,0,index);
		if (index != array.length)
			System.arraycopy(array, index+1, newArray, index, array.length-index-1);
		this.array = newArray;

		length = array.length;
	}

	@Override
	public DoubleNumberArray setImmutable(boolean immutability) {
		this.immutable = immutability;
		for(DoubleNumber dn: array)
			dn.setImmutable(immutability);
		return this;
	}

	@Override
	public void makeImmutable() {
		setImmutable(true);
	}

	@Override
	public void setImmutableArrayOnly(boolean immutability) {
		this.immutable = immutability;
	}

	@Override
	public void replaceAll(NumberObjectArray newArray) {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		this.array = newArray.toDoubleNumberArray().array;
		this.length = newArray.size();
	}

	@Override
	public void setAllRanges(double minimum, double maximum) {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");

		for (DoubleNumber dn: array) 
			dn.setRange(minimum, maximum);
	}


	/**
	 * Returns the index of the element in the array. If the element is not in the array, a -1 is returned.
	 * If the element is at multiple positions, the first position is returned.
	 * @param element
	 * @return
	 */
	public int indexOf(DoubleNumber element){
		for (int i = 0; i < length; i++)
			if (array[i].equals(element))
				return i;
		return -1;

	}

	@Override
	public int indexOf(NumberObjectSingle element){
		for (int i = 0; i < length; i++)
			if (array[i].equals(element))
				return i;
		return -1;
	}

	@Override
	public int indexOf(double element){
		for (int i = 0; i < length; i++)
			if (array[i].equals(element))
				return i;
		return -1;
	}

	////////////////////////////////////////////////////////////////////////////
	/////////////////// 	toString variants 	////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	@Override
	public String toString()	{
		StringBuilder sb = new StringBuilder();
		DecimalFormat df = new DecimalFormat("#." + Helper.repString("#", DecimalNumber.SCALE));
		sb.append("[");

		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else {
				if (array[i].getFlag() == VALUE_FLAG.NaN) sb.append("NaN");
				else if (array[i].getFlag() == VALUE_FLAG.NULL) sb.append("Null");
				else if (array[i].getFlag()== VALUE_FLAG.NEGATIVE_INFINITY) sb.append("-Inf");
				else if (array[i].getFlag() == VALUE_FLAG.POSITIVE_INFINITY) sb.append("Inf");
				else
					sb.append(df.format(array[i].toDouble()));

				if (array[i].isImmutable()) 
					sb.append("*");
			}
			if (i != array.length-1)
				sb.append("   ");

		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();		
	}

	@Override
	public String toString(int significantDigits)	{
		StringBuilder sb = new StringBuilder();
		DecimalFormat df = new DecimalFormat("#." + Helper.repString("#",significantDigits));
		sb.append("[");

		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else {
				if (array[i].getFlag() == VALUE_FLAG.NaN) sb.append("NaN");
				else if (array[i].getFlag() == VALUE_FLAG.NULL) sb.append("Null");
				else if (array[i].getFlag()== VALUE_FLAG.NEGATIVE_INFINITY) sb.append("-Inf");
				else if (array[i].getFlag() == VALUE_FLAG.POSITIVE_INFINITY) sb.append("Inf");
				else
					sb.append(df.format(array[i].toDouble()));

				if (array[i].isImmutable()) 
					sb.append("*");
			}
			if (i != array.length-1)
				sb.append("   ");

		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();		
	}


	@Override
	public String toPlainString()	{
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else
				sb.append(array[i].toPlainString());
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();

	}

	@Override
	public String toPlainString(int significantDigits)	{
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else
				sb.append(array[i].toString(significantDigits));
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();

	}

	@Override
	public String toStringWithoutTrailingZeros()	{
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else
				sb.append(" " +array[i].toStringWithoutTrailingZeros() + " ");
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();

	}

	@Override
	public String toExactString()	{
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else
				sb.append(array[i].toDouble());
			if (array[i].isImmutable()) 
				sb.append("*");
			if (i != array.length-1)
				sb.append("\t");
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();

	}

	@Override
	public String toRParsableString ()	{
		StringBuilder sb = new StringBuilder();
		sb.append("c(");
		for (int n = 0; n<array.length; n++)
		{
			String number = array[n].toRParsableString();
			number = number.replace(",", ".");
			sb.append(number);
			if (n != array.length-1)
				sb.append(",");
		}
		sb.append(")");
		return sb.toString();
	}


	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////// 	Boolean properties of array ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean containsNull() {
		for (DoubleNumber dn: array)
			if (dn == null)
				return true;
			else if (dn.isNull())
				return true;
		return false;
	}

	@Override
	public boolean containsNaN() {
		for (DoubleNumber dn: array)
			if (dn.isNaN())
				return true;
		return false;
	}

	@Override
	public boolean containsNegativeInfinity() {
		for (DoubleNumber dn: array)
			if (dn.isNegativeInfinity())
				return true;
		return false;
	}

	@Override
	public boolean containsPositiveInfinity() {
		for (DoubleNumber dn: array)
			if (dn.isPositiveInfinity())
				return true;
		return false;
	}

	@Override
	public boolean contains(NumberObjectSingle element, boolean approximately) {
		for (DoubleNumber dn: array)
			if (dn.equals(element, approximately))
				return true;
		return false;
	}

	@Override
	public boolean contains(double element, boolean approximately) {
		for (DoubleNumber dn: array)
			if (dn.equals(element, approximately)) 
				return true;
		return false;
	}


	@Override
	public boolean equals(NumberObjectArray other) {
		if (length != other.size())
			return false;

		for (int i = 0; i < length; i++)
			if (!array[i].equals(other.get(i)))
				return false;
		return true;
	}

	@Override
	public boolean isProbability() {
		if (this.min().compareTo(0)==-1)
			return false;
		if (!this.sum().equals(1, true))
			return false;
		return true;
	}

	@Override
	public boolean matchesFieldRestriction(FieldRestriction ft) {
		for (DoubleNumber dn: array)
			if (!FieldRestriction.isValid(dn.toPlainString(), ft))
				return false;
		return true;
	}



	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////// 	Operations on this array 	////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void toProbability()   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array") ;

		if (min().compareTo(0)==-1)
			throw new UnsupportedOperationException("Error at DecimalNumberArray.toProbability(): trying to turn an array containing negative values into a probability distribution");
		DoubleNumber sum = this.sum();

		// if sum ~ 0: create uniform distribution
		if (sum.equals(0, true)) {
			double uniform = 1.0/length;
			for (int i = 0 ; i < array.length; i ++)
				array[i].set(uniform);
		}

		else
			for (int i = 0 ; i < array.length; i ++)
				array[i] = array[i].divide(sum);
	}

	@Override
	public DoubleNumberArray scale(NumberObjectSingle scalar)   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array") ;
		for (int i = 0; i < length; i ++)
			array[i] = array[i].multiply(scalar);
		return this;
	}

	@Override
	public DoubleNumberArray scale(double scalar)   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array") ;
		for (int i = 0; i < length; i ++)
			array[i] = array[i].multiply(scalar);
		return this;
	}

	@Override
	public DoubleNumberArray scaleToSumToOne()   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array") ;
		DoubleNumber sum = this.sum();
		if (sum.equals(0, false)) {
			DoubleNumber uniform = DoubleNumber.ONE.divide(length);
			for (DoubleNumber dn: array)
				dn.set(uniform);
			return this;
		}

		for (DoubleNumber dn: array)
			dn.set(dn.divide(sum));
		return this;
	}

	@Override
	public DoubleNumber max()	{
		DoubleNumber max = array[0];
		for (DoubleNumber n: array)
			if (n.compareTo(max)==1)
				max = n;
		return max;
	}

	@Override
	public DoubleNumber min()
	{
		DoubleNumber min = array[0];
		for (DoubleNumber n: array)
			if (n.compareTo(min)==-1)
				min = n;
		return min;
	}


	@Override
	public DoubleNumber sum()	{
		DoubleNumber sum = new DoubleNumber(0);
		for (DoubleNumber dn:array)
			sum.add(dn, true);
		return sum;
	}

	@Override
	public int validN() {
		int i = 0;
		for (DoubleNumber dn: array){
			i++;
		}
		return i;
	}

	@Override
	public DoubleNumber mean()   {
		return sum().divide(validN());
	}

	@Override
	public DoubleNumber variance()   {
		int validN = validN();
		if (validN <2)
			throw new IllegalStateException("Exception in DoubleNumberArray.variance(): trying to compute variance with less than 2 valid values (Nvalid = " + validN +". Array: " + this);

		DoubleNumber variance = new DoubleNumber(0, DoubleNumber.ZERO, DoubleNumber.POSITIVE_INFINITY, false);
		DoubleNumber mean = mean().setImmutable(true);

		for (DoubleNumber dn: array) 
			variance.add(dn.subtract(mean, false).abs().pow(2, true));
		return variance.divide(validN-1);
	}

	@Override
	public DoubleNumber standardDeviation()   {
		return variance().pow(0.5, true);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	///////////////////////		Vector multiplication	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	@Override
	public DoubleNumber dotProduct(NumberObjectArray otherArray)   {
		if (this.length != otherArray.size())
			throw new IllegalArgumentException("Dotproduct: trying to get dot product of arrays of unequal size.");

		DoubleNumber sum = new DoubleNumber(0);
		for (int i = 0; i < length; i ++)
			sum.add(array[i].multiply(otherArray.get(i)), true);

		return sum;
	}



	/////////////////////////////////////////////////////////////////////////////////////
	////////////// 	Other operations resulting in a new array 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DoubleNumberArray clone() {
		DoubleNumber[] newArray = new DoubleNumber[length];
		for (int i = 0; i<length; i++) newArray[i] = new DoubleNumber(array[i]);

		DoubleNumberArray clone = new DoubleNumberArray(newArray);
		clone.setImmutable(false);
		return clone;
	}

	@Override
	public NumberObjectArray shallowClone() {
		DoubleNumberArray clone = new DoubleNumberArray(array);
		clone.setImmutableArrayOnly(false);
		return clone;
	}

	@Override
	public NumberObjectArray subset(int from, int to)	{
		return new DoubleNumberArray(Arrays.copyOfRange(array, from, to));
	}

	@Override
	public DoubleNumberArray multiply(NumberObjectArray other)   {
		if (length != other.size()) return null;

		DoubleNumberArray product = DoubleNumberArray.rep(0, length);
		for (int i = 0; i < product.length; i++)
			product.set(i, array[i].multiply(other.get(i), false));

		return product;
	}

	@Override
	public DoubleNumberArray concatenate(NumberObjectArray otherArray)	{
		int newLength = array.length + otherArray.size();
		DoubleNumber[] newArray = Arrays.copyOfRange(array, 0, newLength);

		for (int i=0; i < otherArray.size(); i++) 
			newArray[this.length+i] = otherArray.get(i).toDoubleNumber();
		return new DoubleNumberArray(newArray);
	}


	@Override
	public Iterator<DoubleNumber> iterator() {
		return new Iterator<DoubleNumber>() {
			int currentIndex = 0;

			@Override
			public boolean hasNext() {
				return currentIndex < length && array[currentIndex] != null;
			}

			@Override
			public DoubleNumber next() {
				return array[currentIndex++];
			}

		};
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(array);
		result = prime * result + (immutable ? 1231 : 1237);
		result = prime * result + length;
		return result;
	}


}
