package doubleNumber;

import abstractNumberObjectsAndInterfaces.NamedNumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject;
import decimalNumber.DecimalNumber;

public class NamedDoubleNumber extends DoubleNumber implements NamedNumberObjectSingle {

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NumberObject toNumberObject() {
		// TODO Auto-generated method stub
		return null;
	}

}
