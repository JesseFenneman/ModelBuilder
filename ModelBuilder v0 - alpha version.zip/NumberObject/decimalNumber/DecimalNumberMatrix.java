package decimalNumber;

import java.io.Serializable;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectMatrix;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject.UnknownNumberObjectException;
import decimalNumber.TransformationFunction.TransformationFunctionDecimalNumber;
import doubleNumber.DoubleNumber;
import doubleNumber.DoubleNumberMatrix;
import helper.Helper;


// TODO: comments. Include: 1) matrix is defined as array of rows. However, also has represenation for columns (precomputed, because faster).
public class DecimalNumberMatrix implements Cloneable, Serializable, Iterable<DecimalNumberArray>, NumberObjectMatrix {
	private static final long serialVersionUID = Helper.programmeVersion;

	private String[] columnNames; 					// The column names are set from the start and have to be specified
	private String[] rowNames;						// The row names are optional, and are set with setRowNames(String[] rowNames)

	private DecimalNumberArray[] matrix; 			// the matrix consists of row columns...
	private DecimalNumberArray[] columns;			//... but for ease of computation later on we also store a representation in columns.
	private int ncol;
	private int nrow;
	private final DecimalFormat df = new DecimalFormat("0." + Helper.repString("0",10));

	private boolean immutable = false;

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	CONSTRUCTORS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** Instantiate a DecimalNumberMatrix from a 2 dimensional array of doubles ([rows][columns]). The nrow
	 * of the resulting DecimalNumberMatrix is the number of rows in the double matrix (first index). The ncol
	 * of the resulting DecimalNumberMatrix is the length of the first array in the arrays of doubles.
	 *
	 * The doubleMatrix should have rows (first index) of equal length. If not, an IllegalArgumentException is thrown.
	 * @param matrix
	 */
	public DecimalNumberMatrix (double[][] doubleMatrix) {
		this.nrow = doubleMatrix.length;
		// find the ncol
		this.ncol = doubleMatrix[0].length;
		for (double[] row: doubleMatrix) if (row.length != ncol)
			throw new IllegalArgumentException("Exception when constructing a DecimalNumberMatrix from a double[][] array: double[][] array contained rows of equal length");

		this.matrix = new DecimalNumberArray[nrow];
		for (int r = 0; r < nrow; r++)
			matrix[r] = new DecimalNumberArray(doubleMatrix[r]);
		columns = new DecimalNumberArray[ncol];
		setAllColumns();
	}

	/** Instantiate a DecimalNumberMatrix from a 2 dimensional array of DecimalNumbers ([rows][columns]).
	 * The decimalNumberMatrix should have rows (first index) of equal length. If not, an IllegalArgumentException is thrown.
	 * @param matrix
	 */
	public DecimalNumberMatrix (NumberObjectSingle[][] NumberObjectMatrix) {
		this.nrow = NumberObjectMatrix.length;

		// find the ncol
		this.ncol = NumberObjectMatrix[0].length;
		for (NumberObjectSingle[] row: NumberObjectMatrix) if (row.length != ncol)
			throw new IllegalArgumentException("Exception when constructing a DecimalNumberMatrix from a DecimalNumber[][] array: DecimalNumber[][] array contained rows of equal length");

		this.matrix = new DecimalNumberArray[nrow];
		for (int r = 0; r < nrow; r++)
			matrix[r] = new DecimalNumberArray(NumberObjectMatrix[r]);
		columns = new DecimalNumberArray[ncol];
		setAllColumns();
	}

	public DecimalNumberMatrix (NumberObjectArray... rows)	{
		DecimalNumberArray[] m = new DecimalNumberArray[rows.length];
		for (int i = 0; i< m.length; i++)
			m[i] = rows[i].toDecimalNumberArray();
		
		this.matrix = m;

		this.nrow = m.length;
		int columns = 0;
		for (DecimalNumberArray row: matrix)
			if (row.size()> columns)
				columns = row.size();
		ncol = columns;
		this.columns = new DecimalNumberArray[ncol];
		setAllColumns();
	}

	/**
	 * Creates a matrix containing nrow by ncol mutable DecimalNumbers with value 0 and without range.
	 * @param columnNames
	 * @param nrow
	 * @param ncol
	 */
	public DecimalNumberMatrix (int nrow, int ncol)	{
		this.matrix = new DecimalNumberArray[nrow];

		this.ncol = ncol;
		this.nrow = nrow;

		for (int r = 0; r < nrow; r++)
			matrix[r] = DecimalNumberArray.rep(new DecimalNumber(0), ncol);
		columns = new DecimalNumberArray[ncol];
		setAllColumns();
	}

	/**
	 * Creates a matrix containing nrow by ncol mutable DecimalNumbers with value <value>.
	 * @param columnNames
	 * @param nrow
	 * @param ncol
	 */
	public DecimalNumberMatrix (int nrow, int ncol, double value)	{
		this.matrix = new DecimalNumberArray[nrow];

		this.ncol = ncol;
		this.nrow = nrow;

		for (int r = 0; r < nrow; r++)
			matrix[r] = DecimalNumberArray.rep(new DecimalNumber(value), ncol);
		columns = new DecimalNumberArray[ncol];
		setAllColumns();
	}

	/**
	 * Create a new DecimalNumberMatrix with nrow rows and ncol columns from an array of DecimalNumbers. If byrow is set to true,
	 * the DecimalNumbers are added per row. Otherwise, they are added per column.
	 * @param nrow
	 * @param ncol
	 * @param columnNames
	 * @param byrow
	 * @param decimalNumbers
	 */
	public DecimalNumberMatrix (int nrow, int ncol, boolean byrow, NumberObjectArray a)  {
		DecimalNumberArray array = a.toDecimalNumberArray();
		if (nrow*ncol != array.size())
			throw new ComputationException("Error in DecimalNumberMatrix constructor (int row, int ncol, DecimalNumberArray): the product of the specified rows and columns does not match the length of the array specified ");
		matrix = new DecimalNumberArray[nrow];
		for (int i = 0 ; i < matrix.length; i ++)
			matrix[i] = new DecimalNumberArray(ncol);

		this.nrow = nrow;
		this.ncol = ncol;

		int pos = 0;
		if (byrow)
			while (pos< array.size()) {
				matrix[pos/nrow].set(pos % nrow, array.array[pos]);
				pos++;
			}
		else
			while (pos < array.size()) {
				matrix[pos%nrow].set(pos/ nrow, array.array[pos]);
				pos++;
			}
		columns = new DecimalNumberArray[ncol];
		setAllColumns();
	}

	/** wraps the DecimalNumberArray in a matrix that has 1 column */
	public static DecimalNumberMatrix toColumnVector(NumberObjectArray vector) {
		return new DecimalNumberMatrix(vector.size(), 1, false, vector);
	}

	 /** Create a new DecimalNumberMatrix with nrow rows and ncol columns from an array of DecimalNumbers. If byrow is set to true,
	 * the DecimalNumbers are added per row. Otherwise, they are added per column.
	 * @param nrow
	 * @param ncol
	 * @param columnNames
	 * @param byrow
	 * @param decimalNumbers
	 */
	public DecimalNumberMatrix (int nrow, int ncol, boolean byrow, NumberObjectSingle... numberObjects)  {
		if (nrow*ncol != numberObjects.length)
			throw new ComputationException("Error in DecimalNumberMatrix constructor (int row, int ncol, DecimalNumber... decimalNumbers): the product of the specified rows and columns does not match the number of decimalNumbers specified ");
		matrix = new DecimalNumberArray[nrow];
		for (int i = 0 ; i < matrix.length; i ++)
			matrix[i] = new DecimalNumberArray(ncol);

		this.nrow = nrow;
		this.ncol = ncol;

		int pos = 0;
		if (byrow)
			while (pos< numberObjects.length) {
				matrix[pos/nrow].set(pos % nrow, numberObjects[pos].toDecimalNumber());
				pos++;
			}
		else
			while (pos < numberObjects.length) {
				matrix[pos%nrow].set(pos/ nrow, numberObjects[pos].toDecimalNumber());
				pos++;
			}
		columns = new DecimalNumberArray[ncol];
		setAllColumns();
	}

	/** Create a new DecimalNumberMatrix with nrow rows and ncol columns from an array of DecimalNumbers. If byrow is set to true,
	 * the DecimalNumbers are added per row. Otherwise, they are added per column.
	 * @param nrow
	 * @param ncol
	 * @param columnNames
	 * @param byrow
	 * @param decimalNumbers
	 */
	public DecimalNumberMatrix (int nrow, int ncol, boolean byrow, double... doubleNumbers)  {
		if (nrow*ncol != doubleNumbers.length)
			throw new ComputationException("Error in DecimalNumberMatrix constructor (int row, int ncol, double... doubleNumbers): the product of the specified rows and columns does not match the number of doubles specified ");
		matrix = new DecimalNumberArray[nrow];
		for (int i = 0 ; i < matrix.length; i ++)
			matrix[i] = new DecimalNumberArray(ncol);
		this.nrow = nrow;
		this.ncol = ncol;

		int pos = 0;
		if (byrow)
			while (pos< doubleNumbers.length) {
				matrix[pos/ncol].set(pos % ncol, new DecimalNumber(doubleNumbers[pos]));
				pos++;
			}
		else
			while (pos < doubleNumbers.length) {
				matrix[pos%nrow].set(pos / nrow, new DecimalNumber(doubleNumbers[pos]));
				pos++;
			}
		columns = new DecimalNumberArray[ncol];
		setAllColumns();
	}

	/** Copy constructor. If deepClone is true, the resulting Array is a deep clone (all objects in this array are cloned as well). Otherwise its a shallow clone (the objects in this array point to the original objects)*/
	public DecimalNumberMatrix (NumberObjectMatrix o, boolean deepClone) {
		DecimalNumberMatrix original = o.toDecimalNumberMatrix();
		this.nrow = original.nrow;
		this.ncol = original.ncol;

		matrix = new DecimalNumberArray[nrow];
		for (int i = 0 ; i < matrix.length; i ++)
			matrix[i] = new DecimalNumberArray(original.getRow(i), deepClone);

		if (original.getColumnNames() != null) {
			if (deepClone) {
				this.columnNames = new String[ncol];
				System.arraycopy( original.columnNames, 0, columnNames, 0, ncol);
			} else {
				this.columnNames=original.columnNames;
			}
		}

		if (this.getRowNames() != null) {
			if (deepClone) {
				String[] rowNames = new String[nrow];
				System.arraycopy( original.rowNames, 0, this.rowNames, 0, rowNames.length );
			}

		}
	}

	/** Set the DecimalNumberArray[] columns to represent the columns in the matrix. Call this at initialisation. */
	private void setAllColumns() {
		for (int c = 0; c < ncol; c++)
			setColumn(c);
	}

	private void setColumn(int c) {
		DecimalNumber[] columnArray = new DecimalNumber[nrow];
		for (int r = 0; r < nrow; r++){
				columnArray[r] = matrix[r].get(c);
		}
		columns[c] = new DecimalNumberArray(columnArray);
	}

	public static DecimalNumberMatrix randomMatrix (int nrow, int ncol, double min, double max, boolean integerOnly) {
		DecimalNumberArray[] rows = new DecimalNumberArray[nrow];
		for (int i = 0; i< nrow; i ++) {
			DecimalNumberArray newRow = new DecimalNumberArray(ncol);
			for (int j = 0; j < ncol; j++) {
				double value = Math.random()*(max-min) + min;
				if (integerOnly) value = Math.round(value);
				newRow.set(j, new DecimalNumber(value));
			}

			rows[i] = newRow;
		}
		return new DecimalNumberMatrix(rows);

	}

	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////// 	Getters and Setters 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public double[][] to2DDoubleMatrix(){
		double[][] doubleMatrix = new double[nrow][ncol];
		for (int r = 0; r < nrow; r++)
			doubleMatrix[r] = matrix[r].toDoubleArray();
		return doubleMatrix;
	}
	
	@Override
	public DecimalNumber[][] to2DDecimalNumberMatrix(){
		DecimalNumber[][] m = new DecimalNumber[nrow][ncol];
		for (int r = 0; r < nrow; r++)
			m[r] = matrix[r].array;
		return m;
	}
	
	@Override
	public DoubleNumber[][] to2DDoubleNumberMatrix(){
		DoubleNumber[][] doubleMatrix = new DoubleNumber[nrow][ncol];
		for (int r = 0; r < nrow; r++)
			doubleMatrix[r] = (DoubleNumber[]) matrix[r].toDoubleNumberArray().toArray();
		return doubleMatrix;
	}
	
	@Override
	public NumberObjectSingle[][] to2DNumberObjectSingleMatrix() {
		return this.to2DDecimalNumberMatrix();
	}
	
	@Override
	public NumberObjectSingle[][] to2DNumberObjectSingleMatrix(NumberObjectRepresentation formatToUse) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return this.to2DDecimalNumberMatrix();
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return  this.to2DDoubleNumberMatrix();
		throw new UnknownNumberObjectException();
	}
	
	@Override
	public Integer[][] toIntegerMatrix(RoundingMode roundingMode){
		Integer[][] intMatrix = new Integer[nrow][ncol];
		for (int r = 0; r < nrow; r++)
			intMatrix[r] = matrix[r].toIntegerArray(roundingMode);
		return intMatrix;
	}

	@Override
	public DecimalNumberMatrix toDecimalNumberMatrix() { return this; }

	@Override
	public DoubleNumberMatrix toDoubleNumberMatrix() {
		return new DoubleNumberMatrix(this.to2DNumberObjectSingleMatrix()) ;} 

	@Override
	public NumberObjectMatrix toNumberObjectMatrix(NumberObject.NumberObjectRepresentation formatToUse) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return this.toDecimalNumberMatrix();
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return  this.toDoubleNumberMatrix();
		throw new UnknownNumberObjectException();
	}
	
	@Override
	public DecimalNumberArray[] toArrayOfArrays() {
		return this.matrix;
	}

	@Override
	public int nrow() { return nrow;}

	@Override
	public int ncol() { return ncol;}

	@Override
	public int[] dim() { return new int[] {nrow, ncol};}

	@Override
	public boolean isImmutable() { return this.immutable; }

	@Override
	public DecimalNumberMatrix setImmutable(boolean immutable) {
		this.immutable = immutable;
		for (DecimalNumberArray dna: matrix)
			dna.setImmutable(immutable);
		return this;
	}

	@Override
	public void makeImmutable() {
		setImmutable(true);
	}


	////////////////////////////	Arrays of rows/columns	/////////////////////////////
	@Override
	public DecimalNumberArray[] rowMatrix()	{
		DecimalNumberArray[] shallowMatrix = new DecimalNumberArray[nrow];
		for (int r = 0; r < nrow; r++)
			shallowMatrix[r] = matrix[r].shallowClone().toDecimalNumberArray();

		return shallowMatrix;
	}

	@Override
	public DecimalNumberArray[] columnMatrix() {
		DecimalNumberArray[] shallowMatrix = new DecimalNumberArray[ncol];
		for (int c = 0; c < ncol; c++)
			shallowMatrix[c] = columns[c].shallowClone().toDecimalNumberArray();

		return shallowMatrix;
	}

	//////////////////////////// 	Names 	/////////////////////////////
	@Override
	public void setColumnNames (String... newNames) {
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.setColumnNames: trying to set names of an immutable matrix.");
		if (newNames == null) {
			columnNames = null;
			return;
		}

		if (newNames.length != ncol)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.setColumnNames: number of names does not match number of columns.");

		this.columnNames = newNames;
	}

	@Override
	public void setColumnNames (ArrayList<String> newNames) {
		setColumnNames(newNames.toArray(new String[newNames.size()]));
	}

	@Override
	public void setColumnName (int index, String newName) {
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.setColumnName: trying to set names of immutable matrix.");
		if (index < 0 || index > ncol)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.setColumnName: specified column number does not exist.");

		if (columnNames == null){
			columnNames = new String[ncol];
			for (int i = 0; i < ncol; i++) columnNames[i] = "";
		}

		columnNames[index] = newName;
	}

	@Override
	public String[] getColumnNames() { return columnNames; }

	@Override
	public void setRowNames (String... newNames) {
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.setRowName: trying to set names of immutable matrix.");

		if (newNames == null) {
			rowNames = null;
			return;
		}

		if (newNames.length != nrow)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.setRowNames: number of names does not match number of rows.");

		this.rowNames = newNames;
	}

	@Override
	public void setRowNames (ArrayList<String> newNames) {
		setRowNames(newNames.toArray(new String[newNames.size()]));
	}

	@Override
	public void setRowName (int index, String newName) {
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.setRowName: trying to set names of immutable matrix.");
		if (index < 0 || index >= nrow)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.setRowName: specified column number does not exist.");

		if (rowNames == null){
			rowNames = new String[nrow];
			for (int i = 0; i < nrow; i++) rowNames[i] = "";
		}

		rowNames[index] = newName;
	}

	@Override
	public String[] getRowNames() { return rowNames; }

	////////////////////////////	Getting indices		/////////////////////////////
	@Override
	public int getIndexOfColumn(String name) {
		if (columnNames == null)
			throw new ComputationException("Exception in DecimalNumberMatrix.getIndexOfColumn: attempting to get a column by name, but no names have been specified yet. " );

		for (int i = 0; i < columnNames.length; i ++)
			if (name.equals(columnNames[i]))
				return i;

		throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getIndexOfColumn: attempting to get a column by name (\"" + name + "\"), but no column with this name exists.");
	}

	@Override
	public int getIndexOfRow(String name) {
		if (rowNames == null) {
			throw new ComputationException("Exception in DecimalNumberMatrix.getIndexOfRow: attempting to get a row by name, but no names have been specified yet. " );
		}
		for (int i = 0; i < rowNames.length; i ++)
			if (name.equals(rowNames[i]))
				return i;

		throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getIndexOfRow: attempting to get a row by name (\"" + name + "\"), but no row with this name exists.");
	}

	@Override
	public int getIndexOfRowWhereColumnIs(String columnName, NumberObjectSingle value)	{
		for (int i = 0; i<this.getColumn(columnName).size();i++)
			if (this.getColumn(columnName).get(i).equals(value))
				return i;
		return -1;
	}

	@Override
	public int getIndexOfRowWhereColumnIs(String columnName, double value)	{
		for (int i = 0; i<this.getColumn(columnName).size();i++)
			if (this.getColumn(columnName).get(i).equals(value))
				return i;
		return -1;
	}

	@Override
	public int getIndexOfRowWhereColumnIs(int columnIndex, NumberObjectSingle value)	{
		for (int i = 0; i<this.getColumn(columnIndex).size();i++)
			if (this.getColumn(columnIndex).get(i).equals(value))
				return i;
		return -1;
	}

	@Override
	public int getIndexOfRowWhereColumnIs(int columnIndex, double value)	{
		for (int i = 0; i<this.getColumn(columnIndex).size();i++)
			if (this.getColumn(columnIndex).get(i).equals(value))
				return i;
		return -1;
	}

	@Override
	public DecimalNumberArray getRowWhereColumnIs (String columnName, NumberObjectSingle value)	{
		DecimalNumberArray relevantColumn = this.getColumn(columnName);
		for (int i = 0; i < nrow; i++)
			if (relevantColumn.get(i).equals(value))
				return matrix[i];
		return null;
	}

	@Override
	public int getIndexOfNumberObjectArrayRow(NumberObjectArray array) {
		for (int n =0; n < nrow; n++)
			if (matrix[n] == array)
				return n;
		return -1;

	}

	@Override
	public int getIndexOfNumberObjectArrayColumn(NumberObjectArray array) {
		for (int n =0; n < nrow; n++)
			if (matrix[n] == array)
				return n;
		return -1;

	}


	////////////////////////////	Rows and columns	/////////////////////////////
	@Override
	public DecimalNumberArray getColumn (int colnr)	{
		if (colnr < 0 || colnr >= ncol)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getColumn: trying to get a column index higher than the number of columns in the matrix. ");
		return columns[colnr].shallowClone().toDecimalNumberArray();
	}

	@Override
	public DecimalNumberArray getColumn (String name)	{
		if (columnNames == null)
			throw new ComputationException("Exception in DecimalNumberMatrix.getColumn: attempting to get a DecimalNumberArray at column " + name + ". However, column names have not been specified for this matrix.");

		int index = getIndexOfColumn(name);
		if (index == -1)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getColumn: Attempting to get a DecimalNumberArray at column " + name + ". However, no column has this name. ");

		return getColumn (index);
	}

	@Override
	public void setColumn (int colnr, NumberObjectArray array)	{
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.setColumn: trying to set immutable matrix.");

		if (array.size() != nrow) throw new IllegalArgumentException ("Exception in DecimalNumberMatrix.setColumn: new column has incorrect length.");

		if (colnr > ncol) throw new IllegalArgumentException ("Exception in DecimalNumberMatrix.setColumn: colnr out of bounds.");

		for (int i = 0; i < array.size(); i++)
			matrix[i].get(colnr).set(array.get(i));
	}

	@Override
	public void setColumn (String name, NumberObjectArray array)	{
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.setColumn: trying to set immutable matrix.");
		if (columnNames == null)  throw new ComputationException("Exception in DecimalNumberMatrix.setColumn: trying to set column with name \"" + name + "\", but no names have been specified.");

		int index = getIndexOfColumn(name);
		if (index == -1) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.setColumn: attempting to set a DecimalNumberArray at column " + name + ". However, no column has this name.");

		setColumn(index, array);
	}

	@Override
	public DecimalNumberArray getRow (int rownr)	{
		if (rownr < 0 || rownr >= nrow) throw new IllegalArgumentException("Exception in DecimalNumber.getRow: rownr out of bounds.");
		return matrix[rownr].shallowClone().toDecimalNumberArray();
	}

	@Override
	public DecimalNumberArray getRow (String rowName) {
		if (rowNames == null)
			throw new ComputationException("Exception in DecimalNumberMatrix.getRow: attempting to get a DecimalNumberArray with name " + rowName + ". However, row names have not been specified for this matrix.");

		int index = getIndexOfRow(rowName);
		if (index == -1)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getRow: Attempting to get a DecimalNumberArray with name " + rowName + ". However, no row has this name.");


		return getRow(index);
	}

	@Override
	public void setRow (int rownr, NumberObjectArray array)	{
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.setRow: trying to set an immutable matrix.");

		if (rownr < 0 || rownr >= nrow)
			throw new IllegalArgumentException ("Exception in DecimalNumberMatrix.setRow: rownr out of bounds.");


		if (array.size() != ncol)
			throw new IllegalArgumentException ("Exception in DecimalNumberMatrix.setRow: new row has incorrect length.");

		for (int i = 0; i < ncol; i ++)
			matrix[rownr].get(i).set(array.get(i));
	}

	@Override
	public void setRow (String name, NumberObjectArray array)	{
		if (rowNames == null) throw new ComputationException("Exception in DecimalNumberMatrix.setRow: trying to set a row by name, but no names have been specified");

		int index = getIndexOfRow(name);
		if (index == -1) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.setRow: trying to set a row with name \"" + name + "\", but that name does not exist in the matrix.");

		setRow(index, array);
	}

	@Override
	public DecimalNumberArray getRowWhereColumnIs (int columnIndex, NumberObjectSingle value)	{
		DecimalNumberArray relevantColumn = this.getColumn(columnIndex);
		for (int i = 0; i < nrow; i++)
			if (relevantColumn.get(i).equals(value))
				return matrix[i].shallowClone().toDecimalNumberArray();
		return null;
	}

	@Override
	public DecimalNumberArray getRowWhereColumnIs(int columnIndex, double value, boolean sorted) {
		if (columnIndex < 0 || columnIndex > ncol())
			return null;

		DecimalNumberArray column = getColumn(columnIndex);
		for (int r = 0; r < nrow; r++) {
			DecimalNumber entry = column.get(r);
			if (entry.equals(value))
				return matrix[r].shallowClone().toDecimalNumberArray();
			if (entry.compareTo(value) == 1)
				return null;
		}
		return null;
	}

	////////////////////////////	NumberObjects /////////////////////////////
	@Override
	public void setAllValues(NumberObjectSingle v)	{
		if (immutable)
			throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.setAllValues: trying to set values of immutable matrix.");
		for (int r =0;r<nrow;r++ )
			for (int c=0;c<ncol;c++)
				matrix[r].set(c, new DecimalNumber(v));
	}

	@Override
	public DecimalNumber getValueAt (int row, int col)	{
		return matrix[row].get(col);
	}

	@Override
	public DecimalNumber getValueAt (String rowName, String columnName) {
		if (rowNames == null) throw new ComputationException("Exception in DecimalNumberMatrix.getValueAt: trying to get row by name, but no row names have been specified.");
		int rowIndex = getIndexOfRow(rowName);
		if (rowIndex == -1) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getValueAt: trying to set a row with name \"" + rowName + "\", but that name does not exist in the matrix.");


		if (columnNames == null) throw new ComputationException("Exception in DecimalNumberMatrix.getValueAt: trying to get column by name, but no column names have been specified.");
		int columnIndex = getIndexOfColumn(columnName);
		if (columnIndex == -1) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getValueAt: trying to set a column with name \"" + columnName + "\", but that name does not exist in the matrix.");

		return getValueAt(rowIndex, columnIndex);
	}

	@Override
	public DecimalNumber getValueAt (int row, String columnName) {
		if (columnNames == null) throw new ComputationException("Exception in DecimalNumberMatrix.getValueAt: trying to get column by name, but no column names have been specified.");
		int columnIndex = getIndexOfColumn(columnName);
		if (columnIndex == -1) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getValueAt: trying to set a column with name \"" + columnName + "\", but that name does not exist in the matrix.");

		if (row < 0 || row >= nrow) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getValueAt: attempting to acces a row with index that is out of bounds.");

		return getValueAt(row, columnIndex);
	}

	@Override
	public void setValueAt(int row, int col, NumberObjectSingle value)	{
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.getValueAt: setting an immutable matrix.");

		if (row >= 0 && row < nrow)
			if (col >= 0 && col < ncol) {
				matrix[row].get(col).set(value);
				return;
				}
		throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getValueAt: out of bounds for either the row or column index.");
	}

	@Override
	public void setValueAt(int row, int col, double value)	{
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.getValueAt: setting an immutable matrix.");

		if (row >= 0 && row < nrow)
			if (col >= 0 && col < ncol) {
				matrix[row].get(col).set(value);
				return;
				}
		throw new IllegalArgumentException("Exception in DecimalNumberMatrix.getValueAt: out of bounds for either the row or column index.");
	}

	/////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Adding/removing rows/columns 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void appendRow(NumberObjectArray newRow) {
		if (immutable)
			throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.appendRow: trying to append row to an immutable matrix.");

		if (newRow.size() != ncol)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.appendRow: new row has an invalid length.");

		nrow++;
		matrix = Arrays.copyOf(matrix, nrow);
		matrix[nrow-1] = newRow.toDecimalNumberArray();

		if (rowNames != null) {
			rowNames = Arrays.copyOf(rowNames, nrow);
			rowNames[nrow-1] = "";
		}
		for (int c = 0; c < ncol; c++)
			columns[c].insert(nrow-1, newRow.get(c));
	}

	@Override
	public void insertRow(int index, NumberObjectArray newRow, String newRowName) {
		if (immutable)
			throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.appendRow: trying to append row to an immutable matrix.");

		if (newRow.size() != ncol)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.appendRow: new row has an invalid length.");

		if (index < 0 || index > nrow)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.appendRow: index out of bounds.");

		DecimalNumberArray[] newMatrix = new DecimalNumberArray[nrow+1];
		System.arraycopy(matrix, 0, newMatrix, 0, index);
		System.arraycopy(matrix, index, newMatrix, index + 1, matrix.length - index );
		newMatrix[index] = newRow.toDecimalNumberArray();
		matrix = newMatrix;

		if (rowNames != null) {
			String[] newRowNames = new String[nrow+1];
			System.arraycopy(rowNames, 0, newRowNames, 0, index);
			System.arraycopy(rowNames, index, newRowNames, index + 1, rowNames.length - index );
			newRowNames[index] = newRowName;
			rowNames = newRowNames;
		}

		nrow++;

		for (int c = 0; c < ncol; c++)
			columns[c].insert(index, newRow.get(c));
	}

	@Override
	public void insertRow(int index, NumberObjectArray newRow) {
		insertRow(index, newRow, "");
	}

	@Override
	public void removeRow(int index) {
		if (immutable)
			throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.removeRow: trying to remove row in an immutable matrix.");

		if (index < 0 || index > nrow)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.RemoveRow: index out of bounds");

		DecimalNumberArray[] newMatrix = new DecimalNumberArray[matrix.length-1];
		System.arraycopy(matrix,0,newMatrix,0,index);
		if (index != matrix.length)
			System.arraycopy(matrix, index+1, newMatrix, index, matrix.length-index-1);
		this.matrix = newMatrix;

		if (rowNames != null) {
			String[] newRowNames = new String[rowNames.length-1];
			System.arraycopy(rowNames,0,newRowNames,0,index);
			if (index != matrix.length)
				System.arraycopy(rowNames, index+1, newRowNames, index, rowNames.length-index-1);
			this.rowNames = newRowNames;
		}
		nrow = matrix.length;

		for (int c = 0; c < ncol; c++)
			columns[c].remove(index);

	}

	@Override
	public void insertColumn (int index, NumberObjectArray newColumn, String newColumnName) {
		if (immutable)
			throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.insertColumn: trying to insert row in an immutable matrix.");

		if (newColumn.size() != nrow)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.insertColumn: new columnhas an invalid length.");

		if (index < 0 || index > ncol)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.insertColumn: index out of bounds.");

		for (int r = 0; r < matrix.length;r++)
			matrix[r].insert(index, newColumn.get(r));

		if (columnNames != null) {
			String[] newColumnNames = new String[ncol+1];
			System.arraycopy(columnNames, 0, newColumnNames, 0, columnNames.length);
			System.arraycopy(columnNames, index, newColumnNames, index + 1, columnNames.length - index );
			newColumnNames[index] = newColumnName;
			columnNames = newColumnNames;
		}

		DecimalNumberArray[] newColumns = new DecimalNumberArray[ncol+1];
		System.arraycopy(columns, 0, newColumns, 0, index);
		System.arraycopy(columns, index, newColumns, index + 1, columns.length - index );
		newColumns[index] = newColumn.toDecimalNumberArray();
		columns = newColumns;

		this.ncol++;
	}

	@Override
	public void insertColumn (int index, NumberObjectArray newColumn) {
		insertColumn(index, newColumn, "");
	}

	@Override
	public void removeColumn (int index) {
		if (immutable)
			throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.removeColumn: trying to remove column in an immutable matrix.");

		if (index < 0 || index > nrow)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.removeColumn: index out of bounds");


		for (DecimalNumberArray a: matrix)
			a.remove(index);

		if (columnNames != null) {
			String[] newColumnNames = new String[columnNames.length-1];
			System.arraycopy(columnNames,0,newColumnNames,0,index);
			if (index != matrix.length)
				System.arraycopy(columnNames, index+1, newColumnNames, index, columnNames.length-index-1);
			this.columnNames = newColumnNames;
		}

		DecimalNumberArray[] newColumns = new DecimalNumberArray[columns.length-1];
		System.arraycopy(columns,0,newColumns,0,index);
		if (index != columns.length)
			System.arraycopy(columns, index+1, newColumns, index, columns.length-index-1);
		this.columns = newColumns;

		this.ncol--;
	}

	@Override
	public void replaceMatrixWith (NumberObjectMatrix newMatrix) {
		if (immutable)
			return;

		this.ncol = newMatrix.ncol();
		this.nrow = newMatrix.nrow();
		this.columnNames = newMatrix.getColumnNames();
		this.rowNames = newMatrix.getRowNames();

		NumberObjectArray[] otherMatrix = newMatrix.toArrayOfArrays();
		this.matrix = new DecimalNumberArray[nrow];
		for (int r = 0; r < nrow; r++)
			this.matrix[r] = otherMatrix[r].toDecimalNumberArray();

		this.setAllColumns();
	}


	/////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////		Matrix multiplication	/////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////
	/** Multiplies matrix A (with dimensions n*m) with matrix B (with dimensions
	 * m * p). The result is a matrix C with dimensions n*p, where the entry at row
	 * i and column j is:
	 *
	 * C(i, j) = sum ( A(i,k) * B(k,j) ) forall k in [1, m].
	 *
	 * if the number of columns in A does not match the number of rows in B (i.e.,
	 * ( dimension(A) = [n,m1], dimension(B) = [m2, p], and m1 != m2), an
	 * illegalArgumentException is thrown.
	 *
	 * This method multiplies DecimalNumbers using the IJK method. The results from
	 * this method are free of floating point issues.
	 *
	 * @param matrix1
	 * @param matrix2
	 * @return
	 */
	public static DecimalNumberMatrix matrixMultiplication (DecimalNumberMatrix A, DecimalNumberMatrix B)  {
		if (A.ncol != B.nrow)
			throw new IllegalArgumentException("Matrix multiplication: trying a multiply two matrix of size n * m1 with a matrix of size m2 * p, but m1 is not equal to m2.");

		// Create a new DecimalNumberMatrix with size [n, p], where n = rows(A) and p = column(B)
		DecimalNumberMatrix C = new DecimalNumberMatrix(A.nrow, B.ncol, 0);

		for (int i = 0; i < A.nrow; i++)
			for (int j = 0; j < B.ncol; j++)
				for (int k = 0; k < A.ncol; k++)
					C.getRow(i).get(j).add(A.getRow(i).get(k).multiply(B.getRow(k).get(j),false),true);

		return C;
	}

	/** Multiplies matrix A (with dimensions n*m) with matrix B (with dimensions
	 * m * p). The result is a matrix C with dimensions n*p, where the entry at row
	 * i and column j is:
	 *
	 * C(i, j) = sum ( A(i,k) * B(k,j) ) forall k in [1, m].
	 *
	 * if the number of columns in A does not match the number of rows in B (i.e.,
	 * ( dimension(A) = [n,m1], dimension(B) = [m2, p], and m1 != m2), an
	 * illegalArgumentException is thrown.
	 *
	 * This method multiplies DecimalNumbers using the IKJ method. The results from
	 * this method are free of floating point issues.
	 *
	 * @param matrix1
	 * @param matrix2
	 * @return
	 */
	public static DecimalNumberMatrix matrixMultiplicationDecimalNumberIKJ (DecimalNumberMatrix A, DecimalNumberMatrix B)  {
		if (A.ncol != B.nrow)
			throw new IllegalArgumentException("Matrix multiplication: trying a multiply two matrix of size n * m1 with a matrix of size m2 * p, but m1 is not equal to m2.");

		// Create a new DecimalNumberMatrix with size [n, p], where n = rows(A) and p = column(B)
		DecimalNumberMatrix C = new DecimalNumberMatrix(A.nrow, B.ncol, 0);

		for (int i = 0; i < A.nrow; i++)
	        for (int k = 0; k < A.ncol; k++)
	            for (int j = 0; j < B.ncol; j++)
	            	C.getRow(i).get(j).add(A.getRow(i).get(k).multiply(B.getRow(k).get(j),false),true);

		return C;
	}

	/** Multiplies matrix A (with dimensions n*m) with matrix B (with dimensions
	 * m * p). The result is a matrix C with dimensions n*p, where the entry at row
	 * i and column j is:
	 *
	 * C(i, j) = sum ( A(i,k) * B(k,j) ) forall k in [1, m].
	 *
	 * if the number of columns in A does not match the number of rows in B (i.e.,
	 * ( dimension(A) = [n,m1], dimension(B) = [m2, p], and m1 != m2), an
	 * illegalArgumentException is thrown.
	 *
	 * This method first transforms the DecimalNumberMatrix to double[][] and subsequently
	 * multiplies these doubles using the IJK method. The results from this method are
	 * NOT free of floating point issues - specifically, results cannot be trusted after
	 * the 9th decimal point or so.
	 *
	 * @param matrix1
	 * @param matrix2
	 * @return
	 */
	public static DecimalNumberMatrix matrixMultiplicationDoubleIKJ (DecimalNumberMatrix A, DecimalNumberMatrix B)  {
		double[][] A2 = A.to2DDoubleMatrix();
		double[][] B2 = B.to2DDoubleMatrix();
		double[][] C  = new double[A.nrow][B.ncol];
		for (int i = 0; i < A.nrow; i++)
	        for (int k = 0; k < A.ncol; k++)
	            for (int j = 0; j < B.ncol; j++)
	            	C[i][j] += A2[i][k] * B2[k][j];
		return new DecimalNumberMatrix(C);
	}

	/** Multiplies matrix A (with dimensions n*m) with matrix B (with dimensions
	 * m * p). The result is a matrix C with dimensions n*p, where the entry at row
	 * i and column j is:
	 *
	 * C(i, j) = sum ( A(i,k) * B(k,j) ) forall k in [1, m].
	 *
	 * if the number of columns in A does not match the number of rows in B (i.e.,
	 * ( dimension(A) = [n,m1], dimension(B) = [m2, p], and m1 != m2), an
	 * illegalArgumentException is thrown.
	 *
	 * This method first transforms the DecimalNumberMatrix to double[][] and subsequently
	 * multiplies these doubles using the IJK method. The results from this method are
	 * NOT free of floating point issues - specifically, results cannot be trusted after
	 * the 9th decimal point or so. This method is, however, way faster than the
	 * DecimalNumber implementation of matrix multiplication IF A AND B CONSIST OF
	 * MULTIPLE ROWS AND COLUMNS.
	 *
	 * @param matrix1
	 * @param matrix2
	 * @return
	 */
	public static DecimalNumberMatrix matrixMultiplicationDoubleIJK (DecimalNumberMatrix A, DecimalNumberMatrix B)  {
		double[][] A2 = A.to2DDoubleMatrix();
		double[][] B2 = B.to2DDoubleMatrix();
		double[][] C  = new double[A.nrow][B.ncol];

		for (int i = 0; i < A.nrow; i++)
			for (int j = 0; j < B.ncol; j++)
				for (int k = 0; k < A.ncol; k++)
					C[i][j] += A2[i][k] * B2[k][j];

		return new DecimalNumberMatrix(C);
	}

	@Override
	public DecimalNumberMatrix matrixMultiplication (NumberObjectMatrix othermatrix)  {
		return DecimalNumberMatrix.matrixMultiplicationDoubleIKJ(this, othermatrix.toDecimalNumberMatrix());
	}


	/////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////		Other Matrix operations /////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DecimalNumberMatrix round(int significantDigits) {
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.round: trying to multiply multiplicand to immutable matrix.");

		for (DecimalNumberArray a: matrix )
			for (DecimalNumber dn: a)
				dn.round(significantDigits, RoundingMode.HALF_EVEN);
		return this;
	}

	/** Creates a new matrix where all entries are the scalar product of the values in matrix A and the multiplicand.
	 * The original matrix is not changed.*/
	public static DecimalNumberMatrix scalarMultiplication(DecimalNumberMatrix A, DecimalNumber multiplicand) {
		DecimalNumberMatrix M = A.clone();
		for (DecimalNumberArray row: M)
			for (DecimalNumber v: row)
				v.multiply(multiplicand);
		return M;
	}

	/** Creates a new matrix where all entries are the scalar product of the values in matrix A and the multiplicand.
	 * The original matrix is not changed.*/
	public static DecimalNumberMatrix scalarMultiplication(DecimalNumberMatrix A, double multiplicand) {
		DecimalNumberMatrix M = A.clone();

		for (DecimalNumberArray row: M)
			for (DecimalNumber v: row)
				v.multiply(multiplicand, true);
		return M;
	}

	@Override
	public DecimalNumberMatrix scalarMultiplication(NumberObjectSingle multiplicand) {
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.scalarMultiplication: trying to multiply multiplicand to immutable matrix.");
		for (DecimalNumberArray row:this)
			for (DecimalNumber v: row)
				v.multiply(multiplicand, true);
		return this;
	}

	@Override
	public DecimalNumberMatrix scalarMultiplication(double multiplicand) {
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.scalarMultiplication: trying to multiply multiplicand to immutable matrix.");
		for (DecimalNumberArray row:this)
			for (DecimalNumber v: row)
				v.multiply(multiplicand, true);
		return this;
	}

	/**
	 * Creates a new matrix C that is the entrywise (or Hadamard) product of matrices A and B. Specifically,
	 * creates a new matrix C where
	 *
	 * C(i,j) = A(i,j) * B(i,j), for all rows i and columns j.
	 *
	 * This does not influence matrices A or B.
	 *
	 * Throws an IllegalArgumentException if the dimensions of A are unequal to the dimensions of C
	 * @param A
	 * @param B
	 * @return
	 */
	public static DecimalNumberMatrix entrywiseMultiplication(DecimalNumberMatrix  A, DecimalNumberMatrix B) {
		if (A.ncol != B.ncol || A.nrow != B.nrow)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.entrywiseMultiplication: the dimensions of A do not match the dimensions of B" );

		DecimalNumberMatrix C = new DecimalNumberMatrix(A.nrow, A.ncol);
		for (int r = 0; r < A.nrow; r++)
			for (int c= 0; c< A.ncol; c++)
				C.setValueAt(r, c, A.getValueAt(r, c).multiply(B.getValueAt(r, c), false));

		return C;
	}

	@Override
	public DecimalNumberMatrix entrywiseMultiplication(NumberObjectMatrix  otherMatrix) {
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.entrywiseMultiplication: trying to add to immutable matrix.");

		if (ncol != otherMatrix.ncol() || nrow != otherMatrix.nrow())
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.entrywiseMultiplication: the dimensions of this matrix do not match the dimensions of other matrix" );

		for (int r = 0; r < nrow; r++)
			for (int c= 0; c< ncol; c++)
				matrix[r].get(c).set( matrix[r].get(c).multiply(otherMatrix.getRow(r).get(c), false));

		return this;
	}

	/** Returns a new matrix B where all entries are:
	 * B(i,j) = A(i,j) + augend.
	 *
	 * Note that this operation does not change values in A.
	 * @param A
	 * @param augend
	 */
	public static DecimalNumberMatrix scalarAddition(DecimalNumberMatrix A, DecimalNumber augend) {
		DecimalNumberMatrix B = A.clone();
		for (DecimalNumberArray row: B)
			for (DecimalNumber v: row)
				v.add(augend, true);
		return B;
	}

	/** Returns a new matrix B where all entries are:
	 * B(i,j) = A(i,j) + augend.
	 *
	 * Note that this operation does not change values in A.
	 * @param A
	 * @param augend
	 */
	public static DecimalNumberMatrix scalarAddition(DecimalNumberMatrix A, double augend) {
		DecimalNumberMatrix B = A.clone();
		for (DecimalNumberArray row: B)
			for (DecimalNumber v: row)
				v.add(augend, true);
		return B;
	}

	@Override
	public DecimalNumberMatrix scalarAddition(NumberObjectSingle augend)	{
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.scalarAddition: trying to add augend to immutable matrix.");
		for (DecimalNumberArray row:this)
			for (DecimalNumber v:row)
				v.add(augend, true);
		return this;
	}

	@Override
	public DecimalNumberMatrix scalarAddition(double augend)	{
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.scalarAddition: trying to add augend to immutable matrix.");
		for (DecimalNumberArray row:this)
			for (DecimalNumber v:row)
				v.add(augend, true);
		return this;
	}

	/** Adds matrix A (with dimensions n*m) to matrix B (with dimensions
	 * n*m). The result is a matrix C with dimensions n*m, where the entry at row
	 * i and column j is:
	 *
	 * C(i, j) = A(i,j) + B(i,j) forall k in [1, m].
	 *
	 * if the dimensions of A and B do not match an
	 * illegalArgumentException is thrown.
	 *
	 * @param matrix1
	 * @param matrix2
	 * @return
	 */
	public static DecimalNumberMatrix matrixAddition (DecimalNumberMatrix A, DecimalNumberMatrix B)  {
		if (A.nrow != B.nrow || A.ncol!= B.ncol)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.matrixAddition: trying a add two matrix with unequal dimensions.");

		DecimalNumberMatrix C = A.clone();

		// Fill the matrix with dot products between
		for (int r = 0; r < C.nrow; r++)
			for (int c = 0; c < C.ncol; c++) {
				DecimalNumber sum = A.getRow(r).get(c).add(B.getRow(r).get(c), false);
				C.getRow(r).get(c).set(sum);
			}

		return C;
	}

	@Override
	public DecimalNumberMatrix matrixAddition (NumberObjectMatrix otherMatrix)  {
		if (nrow != otherMatrix.nrow() || ncol!= otherMatrix.ncol())
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.matrixAddition: trying a add two matrix with unequal dimensions.");
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.matrixAddition: trying to add multiplicand to immutable matrix.");

		// Fill the matrix with dot products between
		for (int r = 0; r < nrow; r++)
			for (int c = 0; c < ncol; c++) {
				matrix[r].get(c).add(otherMatrix.getValueAt(r, c), true);
			}
		return this;
	}

	/** Applies the function to all DecimalNumber in the matrix. Throws UnsupportedComputationException if the matrix is immutable. Returns this
	 * @return */
	public DecimalNumberMatrix apply(TransformationFunctionDecimalNumber function ) {
		if (immutable) throw new UnsupportedOperationException("Exception in DecimalNumberMatrix.apply: trying to apply function to immutable matrix.");
		for (int r = 0; r < nrow; r++)
			for (int c= 0; c< ncol; c++)
				matrix[r].get(c).set( function.function(matrix[r].get(c)));
		return this;
	}

	/** Creates a new matrix B, where
	 * B(i,j) = function(A(i,j)).
	 *
	 * A remains unchanged.
	 */
	public static DecimalNumberMatrix apply(DecimalNumberMatrix A, TransformationFunctionDecimalNumber function ) {
		DecimalNumberMatrix B = A.clone();
		for (DecimalNumberArray row: B)
			for (DecimalNumber v: row)
				v.set(function.function(v));
		return B;

	}


	/////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Other operations on this matrix 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public DecimalNumberMatrix transpose() {
		// first, vectorize this array by row
		DecimalNumberArray vector = this.vectorize(true);

		// Create a new matrix, adding the values by column
		DecimalNumberMatrix newMatrix = new DecimalNumberMatrix(ncol, nrow, false, vector);

		// Set the col and row names
		newMatrix.columnNames = rowNames;
		newMatrix.rowNames = columnNames;

		return newMatrix;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Matrix properties 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean contains (NumberObjectSingle value, boolean approximately)
	{
		for (DecimalNumberArray array: matrix)
			if (array.contains(value, approximately))
				return true;
		return false;
	}

	/**
	 * Checks if value exists in the matrix. If approximately is true, values within 0.0000001 are counted as equal.
	 */
	public boolean contains (double value, boolean approximately)	{
		for (DecimalNumberArray array: matrix)
			if (array.contains(value, approximately))
				return true;
		return false;
	}

	/** Returns the sum of all DecimalNumbers in this matrix */
	public DecimalNumber sum() {
		DecimalNumber sum = new DecimalNumber(0);

		for (DecimalNumberArray row:this)
			sum.add(row.sum());
		return sum;
	}

	public boolean matchesFieldType(FieldRestriction ft) {
		for (DecimalNumberArray dna: this.columns)
			if (!dna.matchesFieldRestriction(ft))
				return false;
		return true;
	}
	//////////////////////////////////////////////////////////////////////////////////////
	////////////////// 	Subsets, reduction, combination, clone   /////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////

	@Override
	public DecimalNumberArray vectorize(boolean byrow) {
		DecimalNumberArray array = new DecimalNumberArray(ncol*nrow);
		if (byrow) {
			for (int r = 0; r < nrow; r++)
				for (int c = 0; c < ncol; c++)
					array.set(r*ncol+c, matrix[r].get(c));
		}
		else {
			for (int c = 0; c < ncol; c++)
				for (int r = 0; r < nrow; r++)
					array.set(c*nrow+r, matrix[r].get(c));

		}
		return array;
	}

	@Override
 	public DecimalNumberMatrix clone ()
	{
		DecimalNumberArray[] newMatrix = new DecimalNumberArray[nrow];
		for (int r=0;r<nrow;r++)
			newMatrix[r] = matrix[r].clone();

		DecimalNumberMatrix clone = new DecimalNumberMatrix(newMatrix);
		if (this.getColumnNames() != null) {
			String[] cloneNames = new String[columnNames.length];
			System.arraycopy( columnNames, 0, cloneNames, 0, columnNames.length );
			clone.setColumnNames(cloneNames);
		}

		if (this.getRowNames() != null) {
			String[] cloneNames = new String[rowNames.length];
			System.arraycopy( rowNames, 0, cloneNames, 0, rowNames.length );
			clone.setRowNames(cloneNames);
		}
		return clone;
	}

	@Override
	public DecimalNumberMatrix shallowClone() {
		DecimalNumberArray[] clonedMatrix = new DecimalNumberArray[nrow];
		for (int r=0;r<nrow;r++)
			clonedMatrix[r] = matrix[r].shallowClone().toDecimalNumberArray();

		DecimalNumberMatrix clone = new DecimalNumberMatrix(clonedMatrix);
		clone.setColumnNames(columnNames);
		clone.setRowNames(rowNames);
		return clone;
	}

	@Override
	public DecimalNumberMatrix subsetRangeOfRows(int from, int to)
	{
		DecimalNumberMatrix result = new DecimalNumberMatrix(Arrays.copyOfRange(matrix, from, to));
		result.setColumnNames(columnNames);
		result.setRowNames(rowNames);
		return result;
	}

	@Override
	public DecimalNumberMatrix subsetRows(int... rowsToKeep)
	{
		DecimalNumberArray[] newMatrix = new DecimalNumberArray[rowsToKeep.length];
		for (int i = 0; i < rowsToKeep.length; i ++)
			newMatrix[i] = matrix[rowsToKeep[i]];

		DecimalNumberMatrix result = new DecimalNumberMatrix(newMatrix);
		result.setColumnNames(columnNames);
		result.setRowNames(rowNames);
		return result;
	}

	@Override
	public DecimalNumberMatrix reduce(String columnToSelect, NumberObjectArray entries, boolean removeListed, boolean approximately)	{
		int columnIndex = Helper.indexOf(columnToSelect, columnNames);
		if (columnIndex == -1) return null;

		ArrayList<DecimalNumberArray> newMatrixArrayList = new ArrayList<>();
		ArrayList<String> newRowNames = new ArrayList<>();
		if (removeListed)
			for (DecimalNumberArray array: matrix)
				for (int i = 0; i < entries.size(); i++)
					if (!array.contains(entries.get(i), approximately)) {
						newMatrixArrayList.add(array);
						newRowNames.add(rowNames[i]);
						}

		if (!removeListed)
			for (DecimalNumberArray array: matrix)
				for (int i = 0; i < entries.size(); i++)
					if (array.contains(entries.get(i), approximately)) {
						newMatrixArrayList.add(array);
						newRowNames.add(rowNames[i]);
						}

		DecimalNumberArray[] newArray = new DecimalNumberArray[newMatrixArrayList.size()];
		newArray = newMatrixArrayList.toArray(newArray);

		String[] namesArray = newRowNames.toArray(new String[newRowNames.size()]);

		DecimalNumberMatrix newMatrix = new DecimalNumberMatrix(newArray);
		newMatrix.setRowNames(namesArray);
		newMatrix.setColumnNames(columnNames);
		return newMatrix;
	}

	@Override
	public DecimalNumberMatrix rowBind(NumberObjectMatrix otherMatrix){
		if (this.ncol != otherMatrix.ncol())
			throw new IllegalArgumentException("Trying to row bind two matrices with an unequal number of columns");

		if (this.columnNames != null || otherMatrix.getColumnNames() != null)
			for (int s = 0; s < this.columnNames.length; s++)
				if (this.columnNames[s].compareTo(otherMatrix.getColumnNames()[s])!=0)
					throw new ComputationException("Trying to row bind two matrices with non-matching column names: at place " + s + " the column name of matrix 1 is \"" + this.columnNames[s] + "\" while the column name of matrix 2 is \"" + otherMatrix.getColumnNames()[s] + "\"." );


		int newNRow = this.nrow+otherMatrix.nrow();
		DecimalNumberArray[] newMatrix = Arrays.copyOfRange(this.matrix, 0, newNRow);
		System.arraycopy(otherMatrix.rowMatrix(), 0, newMatrix, this.matrix.length, otherMatrix.rowMatrix().length);
		DecimalNumberMatrix newDNM =  new DecimalNumberMatrix(newMatrix);

		// Adding col names (optional)
		if (this.columnNames != null) {
			String[] newColumnNames = this.columnNames;
			newDNM.setColumnNames(newColumnNames);
		}

		// Adding row names (optional)
		if (this.rowNames != null || otherMatrix.getRowNames()!= null) {

			// Add or create the names from the first matrix (creating "" string if no names are specified).
			String[] newRowNames;
			if (this.rowNames != null)
				newRowNames = Arrays.copyOf(this.rowNames, newMatrix.length);
			else {
				newRowNames = new String[this.nrow];
				for (int i = 0 ; i < this.nrow; i ++)
					newRowNames[i] = "";
			}

			// Add or create the names from the second matrix (creating "" string if no names are specified).
			if (otherMatrix.getRowNames() != null)
				for (int i = 0; i < otherMatrix.nrow(); i++)
					newRowNames[this.nrow + i] = otherMatrix.getRowNames()[i];
			else
				for (int i = this.nrow; i < newDNM.nrow; i++)
					newRowNames[i] ="";
			newDNM.setRowNames(newRowNames);
		}

		return newDNM;

	}

	@Override
	public DecimalNumberMatrix columnBind(NumberObjectArray... columnVectors) 	{
		if (columnVectors.length < 2)
			throw new IllegalArgumentException("Error in columnBind: trying to combine less than 2 vectors");

		int rows = columnVectors[0].size();
		for (NumberObjectArray dna: columnVectors)
			if (dna.size() != rows)
				throw new IllegalArgumentException("Error in columnBind: trying to combine vectors of unequal length.");

		for (NumberObjectArray noa: columnVectors)
			this.insertColumn(ncol(), noa);

		return this;
	}


	 /** Combines the column vectors into a single, new table. Throws an IllegalArgumentException if the vectors are of unequal length
		 * The new matrix does not have row or column names.
		 * Changes in the new matrix will result in changes in the arrays, and vice versa.
		 * @param table1
		 * @param table2
		 * @return
		 */
		public static DecimalNumberMatrix columnBind(DecimalNumberArray... columnVectors) 	{
			if (columnVectors.length < 2)
				throw new IllegalArgumentException("Error in columnBind: trying to combine less than 2 vectors");

			int rows = columnVectors[0].size();
			for (DecimalNumberArray dna: columnVectors)
				if (dna.size() != rows)
					throw new IllegalArgumentException("Error in columnBind: trying to combine vectors of unequal length.");

			DecimalNumberMatrix matrix = new DecimalNumberMatrix(rows, columnVectors.length);
			for (int r = 0; r < rows; r++)
				for (int c = 0; c < columnVectors.length; c++)
					matrix.setValueAt(r, c, columnVectors[c].get(r));

			return matrix;

		}


	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Miscellaneous 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DecimalNumberArray[] toColumnVectors() {
		DecimalNumberArray[] columnVectors = new DecimalNumberArray[ncol];
		for (int c = 0; c < ncol; c++)
		{
			DecimalNumberArray columnVector = new DecimalNumberArray(nrow);
			for (int r = 0; r < nrow; r++)
				columnVector.set(r, matrix[r].get(c));
			columnVectors[c] = columnVector;
		}
		return columnVectors;

	}

	@Override
	public boolean equals (Object other) {
		if (!(other instanceof DecimalNumberMatrix))
			return false;

		DecimalNumberMatrix otherMatrix = (DecimalNumberMatrix) other;
		if (otherMatrix.nrow != nrow)
			return false;
		if (otherMatrix.ncol != ncol)
			return false;

		for (int row = 0; row < nrow; row++)
			for (int col = 0; col < ncol; col++)
				if (!matrix[row].get(col).equals(otherMatrix.getValueAt(row, col)))
					return false;
		return true;
	}


	@Override
	public String toString(int significantDigits)	{
		return toString(significantDigits, 24, false);
	}

	@Override
	public String toString()	{
		return toString(-1, 40, false);
	}

	@Override
	public String toStringWithoutTrailingZeros() {
		return toString (-1, 24, true);
	}

	@Override
	public String toString(int significantDigits, int colwidth) {
		return toString(significantDigits, colwidth, false);
	}


	private String toString(int significantDigits, int colwidth, boolean withoutTrailingZeros)	{
		StringBuilder sb = new StringBuilder();
		sb.append("\n" + Helper.repString("=", 100) + "\n");

		// Replace empty names with [,] formats
		String[] columnNamesToUseInPrint = this.columnNames;
		if (columnNamesToUseInPrint == null) 
			columnNamesToUseInPrint  = createGenericColumnNames(ncol);
		
		String[] rowNamesToUseInPrint = this.rowNames;
		if (rowNames == null) 
			rowNamesToUseInPrint = createGenericRowNames(nrow);
		
		// print the column names, adding an empty column at the start if there are row names specified
		sb.append(Helper.repString(" ", colwidth+2)+"  ");

		for (String h:columnNamesToUseInPrint){
			sb.append(h);
			sb.append(Helper.repString(" ", colwidth - h.length()));
			sb.append("  ");
		}
		sb.append("\n");

		sb.append(Helper.repString("-", colwidth)+"  ");
		
		for (String s:columnNamesToUseInPrint) sb.append(Helper.repString("-", colwidth)+"  ");
		sb.append("\n");


		//Print the body
		// If row names are specified, print those first
		for (int r = 0; r < matrix.length; r++)
		{
			sb.append(rowNamesToUseInPrint[r] + Helper.repString(" ", colwidth - rowNamesToUseInPrint[r].length()) + "||\t");
			for (int c=0; c <ncol; c++)
			{
				String s;
				DecimalNumber entry = matrix[r].get(c);
				if (entry == null)							s = "NULL";
				else if (entry == DecimalNumber.NaN)		s = "NaN";
				else if (entry == DecimalNumber.NULL)		s = "Null";
				else if (entry == DecimalNumber.POSITIVE_INFINITY) s = "Inf";
				else if (entry == DecimalNumber.NEGATIVE_INFINITY) s = "-Inf";
				else {
					if (withoutTrailingZeros)
						s =  entry.toStringWithoutTrailingZeros();
					else
						if (significantDigits == -1)
							s = entry.toString();
						else
							s =  entry.toString(significantDigits);

					if ( matrix[r].get(c).hasRangeRestriction()) s = s + "'";
					if ( matrix[r].get(c).isImmutable()) s = s + "*";
				}


				String sSpaced = s + Helper.repString(" ", colwidth - s.length());
				sb.append(sSpaced + "  ");
			}
			if (matrix[r].isImmutable()) sb.append("\t(*)");
			sb.append("\n");

		}
		sb.append("\n" + Helper.repString("=", 100) + "\n");

		return sb.toString();

	}

	public static String[] createGenericColumnNames(int ncol) {
		String[] names = new String[ncol];
		for (int i = 0; i < ncol; i++)
			names[i] = "[ ," + i + "]";
		return names;
	}

	public static String[] createGenericRowNames(int nrow) {
		String[] names = new String[nrow];
		for (int i = 0; i < nrow; i++)
			names[i] = "[" + i + ", ]";
		return names;
	}

	@Override
	public String toRParsableString()	{
		StringBuilder sb = new StringBuilder();
		sb.append("as.data.frame(matrix(c(");
		for (int r = 0; r < this.nrow; r++)
			for (int c = 0; c < this.ncol; c++) {
				sb.append(matrix[r].get(c).toRParsableString());
				if (!(r  == (nrow-1) && c == (ncol-1)))
					sb.append(",");
			}
		sb.append("), ncol = " + ncol + ", nrow = " + nrow + ", byrow = T, dimnames = list( ");

		if (this.rowNames == null)
			sb.append("NULL");
		else {
			sb.append("c(");
			for (int s = 0; s < this.rowNames.length; s++) {
				sb.append("'"+rowNames[s]+"'");
				if (s != (rowNames.length-1))
					sb.append(",");
			}
			sb.append(")");
		}

		if (this.columnNames == null)
			sb.append(", NULL");
		else {
			sb.append(", c(");
			for (int s = 0; s < this.columnNames.length; s++) {
				sb.append("'"+columnNames[s] + "'");
				if (s != (columnNames.length-1))
					sb.append(",");
			}
			sb.append(")");
		}

		sb.append(")))");
		return sb.toString();

	}

	@Override
	public String toCSV(String delimiter)	{
		StringBuilder sb = new StringBuilder();
		sb.append(columnNames[0]);
		for (int i=1;i<columnNames.length;i++)
			sb.append(delimiter + columnNames[i]);
		sb.append("\n");
		for (int row = 0; row<this.nrow; row++)
		{
			sb.append(matrix[row].get(0));
			for (int col = 1; col < this.ncol; col++)
				sb.append(delimiter + matrix[row].get(col));
			sb.append("\n");
		}
		return sb.toString();
	}

	@Override
	public void sort(int columnToSortOn, boolean ascending) {
		if (columnToSortOn < 0 || columnToSortOn >= ncol )
			throw new IndexOutOfBoundsException();

		if (immutable)
			throw new UnsupportedOperationException("Trying to change an immutable matrix");

		final Comparator<DecimalNumberArray> comparator = new Comparator<DecimalNumberArray>() {

			@Override
			public int compare(DecimalNumberArray o1, DecimalNumberArray o2) {
				return o1.get(columnToSortOn).compareTo(o2.get(columnToSortOn));
			}
		};

		if (ascending)
			Arrays.sort(matrix, comparator);
		else
			Arrays.sort(matrix, Collections.reverseOrder(comparator));
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(matrix);
		result = prime * result + ((df == null) ? 0 : df.hashCode());
		result = prime * result + Arrays.hashCode(columnNames);
		result = prime * result + ncol;
		result = prime * result + nrow;
		return result;
	}

	@Override
	public Iterator<DecimalNumberArray> iterator() {
		return new Iterator<DecimalNumberArray>() {
			int currentIndex = 0;

			@Override
			public boolean hasNext() {
				return currentIndex < nrow && matrix[currentIndex] != null;
			}

			@Override
			public DecimalNumberArray next() {
				return matrix[currentIndex++];
			}

		};
	}


	/////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Double only analogues 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	/** <pre> DOUBLE ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED.
	 *
	 * Multiplies double[][] A (with dimensions n*m) with double[][] B (with dimensions
	 * m * p). The result is a matrix C with dimensions n*p, where the entry at row
	 * i and column j is:
	 *
	 * C(i, j) = sum ( A(i,k) * B(k,j) ) forall k in [1, m].
	 *
	 * if the number of columns in A does not match the number of rows in B (i.e.,
	 * ( dimension(A) = [n,m1], dimension(B) = [m2, p], and m1 != m2), an
	 * illegalArgumentException is thrown.
	 *
	 * This method has both input and output of form double[][]. The results from this method are
	 * NOT free of floating point issues - specifically, results cannot be trusted after
	 * the 9th decimal point or so.
	 *
	 * @param matrix1
	 * @param matrix2
	 * @return
	 */
	public static double[][] DOUBLE_matrixMultiplicationIKJ (double[][] A, double[][] B)  {
		int nrowA = A.length;
		int nrowB = B.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_matrixMultiplicationIKJ(): argument A has rows of unequal sizes.");
		int ncolB = B[0].length;
		for (int i = 0; i < B.length; i++) if (B[i].length!= ncolB) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_matrixMultiplicationIKJ(): argument B has rows of unequal sizes.");

		if (ncolA != nrowB) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_matrixMultiplicationIKJ(): trying a multiply two matrix of size n * m1 with a matrix of size m2 * p, but m1 is not equal to m2.");


		double[][] C  = new double[nrowA][ncolB];
		for (int i = 0; i < nrowA; i++)
	        for (int k = 0; k < ncolA; k++)
	            for (int j = 0; j < ncolB; j++)
	            	C[i][j] += A[i][k] * B[k][j];
		return C;
	}

	/** <pre> DOUBLE ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED (especially after 9th decimal).
	 * Creates a new double[][] where all entries are the scalar product of the values in double[][] A and the multiplicand.
	 */
	public static double[][] DOUBLE_scalarMultiplication(double[][] A, double multiplicand) {
		int nrowA = A.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_scalarMultiplication(): argument A has rows of unequal sizes.");

		double[][] C = new double[nrowA][ncolA];
		for (int r = 0; r < nrowA; r++)
			for (int c = 0; c< ncolA; c++)
				C[r][c] = A[r][c]*multiplicand;

		return C;
	}

	/** <pre> DOUBLE ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED (especially after 9th decimal).
	 * Creates a new matrix C that is the entrywise (or Hadamard) product of matrices A and B. Specifically,
	 * creates a new matrix C where
	 *
	 * C(i,j) = A(i,j) * B(i,j), for all rows i and columns j.
	 *
	 * This does not influence matrices A or B.
	 *
	 * Throws an IllegalArgumentException if the dimensions of A are unequal to the dimensions of C
	 * @param A
	 * @param B
	 * @return
	 */
	public static double[][] DOUBLE_matrixAddition(double[][]  A, double[][] B) {
		int nrowA = A.length;
		int nrowB = B.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_entrywiseMultiplication(): argument A has rows of unequal sizes.");
		int ncolB = B[0].length;
		for (int i = 0; i < B.length; i++) if (B[i].length!= ncolB) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_entrywiseMultiplication(): argument B has rows of unequal sizes.");

		if (ncolA != ncolB|| nrowA != nrowB)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_matrixAddition(): the dimensions of A do not match the dimensions of B" );

		double[][] C = new double[nrowA][ncolA];
		for (int r = 0; r < nrowA; r++)
			for (int c= 0; c< ncolA; c++)
				C[r][c] = A[r][c] + B[r][c];

		return C;
	}

	/** <pre> DOUBLE ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED (especially after 9th decimal).
	 * Creates a new matrix C that is the entrywise (or Hadamard) product of matrices A and B. Specifically,
	 * creates a new matrix C where
	 *
	 * C(i,j) = A(i,j) * B(i,j), for all rows i and columns j.
	 *
	 * This does not influence matrices A or B.
	 *
	 * Throws an IllegalArgumentException if the dimensions of A are unequal to the dimensions of C
	 * @param A
	 * @param B
	 * @return
	 */
	public static double[][] DOUBLE_entrywiseMultiplication(double[][]  A, double[][] B) {
		int nrowA = A.length;
		int nrowB = B.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_entrywiseMultiplication(): argument A has rows of unequal sizes.");
		int ncolB = B[0].length;
		for (int i = 0; i < B.length; i++) if (B[i].length!= ncolB) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_entrywiseMultiplication(): argument B has rows of unequal sizes.");

		if (ncolA != ncolB|| nrowA != nrowB)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_entrywiseMultiplication(): the dimensions of A do not match the dimensions of B" );

		double[][] C = new double[nrowA][ncolA];
		for (int r = 0; r < nrowA; r++)
			for (int c= 0; c< ncolA; c++)
				C[r][c] = A[r][c] * B[r][c];

		return C;
	}

	/** <pre> DOUBLE ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED (especially after 9th decimal).
	 * Returns a new matrix B where all entries are:
	 * B(i,j) = A(i,j) + augend.
	 *
	 * Note that this operation does not change values in A.
	 * @param A
	 * @param augend
	 */
	public static double[][] DOUBLE_scalarAddition(double[][] A, double augend) {
		int nrowA = A.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_scalarAddition(): argument A has rows of unequal sizes.");

		double[][] C = new double[nrowA][ncolA];
		for (int r = 0; r < nrowA; r++)
			for (int c = 0; c< ncolA; c++)
				C[r][c] = A[r][c]+augend;

		return C;
	}

	public static double[][] DOUBLE_unityMatrix(int nrow, int ncol) {
		double[][] unity = new double[nrow][ncol];
		for (int r = 0; r < nrow; r++)
			for (int c = 0; c < ncol; c++)
				unity[r][c] = 1;
		return unity;
	}

	public static double[][] DOUBLE_transpose(double[][] A){
		int nrowA = A.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_transpose(): argument A has rows of unequal sizes.");

		double[][] transpose = new double[ncolA][nrowA];
		for (int rC = 0; rC < ncolA; rC ++)
			for (int cC = 0; cC < nrowA; cC++)
				transpose[rC][cC] = A[cC][rC];
		return transpose;
	}

	public static double[][] DOUBLE_clone(double[][] A){
		double [][] result = new double[A.length][];
		for(int r = 0; r < A.length; r++)		{
		  double[] oldRow = A[r];
		  double[] newRow  = new double[oldRow.length];
		  System.arraycopy(oldRow, 0, newRow, 0, oldRow.length);
		  result[r] = newRow;
		}
		return result;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// 	Integer only analogues 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	/** <pre> INTEGER ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED.
	 *
	 * Multiplies int[][] A (with dimensions n*m) with int[][] B (with dimensions
	 * m * p). The result is a matrix C with dimensions n*p, where the entry at row
	 * i and column j is:
	 *
	 * C(i, j) = sum ( A(i,k) * B(k,j) ) forall k in [1, m].
	 *
	 * if the number of columns in A does not match the number of rows in B (i.e.,
	 * ( dimension(A) = [n,m1], dimension(B) = [m2, p], and m1 != m2), an
	 * illegalArgumentException is thrown.
	 *
	 *
	 * @param matrix1
	 * @param matrix2
	 * @return
	 */
	public static int[][] INTEGER_matrixMultiplicationIKJ (int[][] A, int[][] B)  {
		int nrowA = A.length;
		int nrowB = B.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_matrixMultiplicationIKJ(): argument A has rows of unequal sizes.");
		int ncolB = B[0].length;
		for (int i = 0; i < B.length; i++) if (B[i].length!= ncolB) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_matrixMultiplicationIKJ(): argument B has rows of unequal sizes.");

		if (ncolA != nrowB) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_matrixMultiplicationIKJ(): trying a multiply two matrix of size n * m1 with a matrix of size m2 * p, but m1 is not equal to m2.");


		int[][] C  = new int[nrowA][ncolB];
		for (int i = 0; i < nrowA; i++)
	        for (int k = 0; k < ncolA; k++)
	            for (int j = 0; j < ncolB; j++)
	            	C[i][j] += A[i][k] * B[k][j];
		return C;
	}

	/** <pre> INTEGER ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED (especially after 9th decimal).
	 * Creates a new int[][] where all entries are the scalar product of the values in int[][] A and the multiplicand.
	 */
	public static int[][] INTEGER_scalarMultiplication(int[][] A, int multiplicand) {
		int nrowA = A.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_scalarMultiplication(): argument A has rows of unequal sizes.");

		int[][] C = new int[nrowA][ncolA];
		for (int r = 0; r < nrowA; r++)
			for (int c = 0; c< ncolA; c++)
				C[r][c] = A[r][c]*multiplicand;

		return C;
	}

	/** <pre> INTEGER ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED (especially after 9th decimal).
	 * Creates a new matrix C that is the entrywise (or Hadamard) product of matrices A and B. Specifically,
	 * creates a new matrix C where
	 *
	 * C(i,j) = A(i,j) * B(i,j), for all rows i and columns j.
	 *
	 * This does not influence matrices A or B.
	 *
	 * Throws an IllegalArgumentException if the dimensions of A are unequal to the dimensions of C
	 * @param A
	 * @param B
	 * @return
	 */
	public static int[][] INTEGER_entrywiseMultiplication(int[][]  A, int[][] B) {
		int nrowA = A.length;
		int nrowB = B.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_entrywiseMultiplication(): argument A has rows of unequal sizes.");
		int ncolB = B[0].length;
		for (int i = 0; i < B.length; i++) if (B[i].length!= ncolB) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_entrywiseMultiplication(): argument B has rows of unequal sizes.");

		if (ncolA != ncolB|| nrowA != nrowB)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_entrywiseMultiplication(): the dimensions of A do not match the dimensions of B" );

		int[][] C = new int[nrowA][ncolA];
		for (int r = 0; r < nrowA; r++)
			for (int c= 0; c< ncolA; c++)
				C[r][c] = A[r][c] * A[r][c];

		return C;
	}

	/** <pre> INTEGER ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED (especially after 9th decimal).
	 * Returns a new matrix B where all entries are:
	 * B(i,j) = A(i,j) + augend.
	 *
	 * Note that this operation does not change values in A.
	 * @param A
	 * @param augend
	 */
	public static int[][] INTEGER_scalarAddition(int[][] A, int augend) {
		int nrowA = A.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_scalarAddition(): argument A has rows of unequal sizes.");

		int[][] C = new int[nrowA][ncolA];
		for (int r = 0; r < nrowA; r++)
			for (int c = 0; c< ncolA; c++)
				C[r][c] = A[r][c]+augend;

		return C;
	}

	/** <pre> INTEGER ONLY - DOES NOT USE DECIMALNUMBERMATRIX. RESULTS CANNOT ALWAYS BE TRUSTED (especially after 9th decimal).
	 * Creates a new matrix C that is the entrywise (or Hadamard) product of matrices A and B. Specifically,
	 * creates a new matrix C where
	 *
	 * C(i,j) = A(i,j) * B(i,j), for all rows i and columns j.
	 *
	 * This does not influence matrices A or B.
	 *
	 * Throws an IllegalArgumentException if the dimensions of A are unequal to the dimensions of C
	 * @param A
	 * @param B
	 * @return
	 */
	public static int[][] INTEGER_matrixAddition(int[][]  A, int[][] B) {
		int nrowA = A.length;
		int nrowB = B.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.INTEGER_matrixAddition(): argument A has rows of unequal sizes.");
		int ncolB = B[0].length;
		for (int i = 0; i < B.length; i++) if (B[i].length!= ncolB) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.INTEGER_matrixAddition(): argument B has rows of unequal sizes.");

		if (ncolA != ncolB|| nrowA != nrowB)
			throw new IllegalArgumentException("Exception in DecimalNumberMatrix.INTEGER_matrixAddition(): the dimensions of A do not match the dimensions of B" );

		int[][] C = new int[nrowA][ncolA];
		for (int r = 0; r < nrowA; r++)
			for (int c= 0; c< ncolA; c++)
				C[r][c] = A[r][c] + B[r][c];

		return C;
	}



	public static int[][] INTEGER_unityMatrix(int nrow, int ncol) {
		int[][] unity = new int[nrow][ncol];
		for (int r = 0; r < nrow; r++)
			for (int c = 0; c < ncol; c++)
				unity[r][c] = 1;
		return unity;
	}

	public static int[][] INTEGER_transpose(int[][] A){
		int nrowA = A.length;

		int ncolA = A[0].length;
		for (int i = 0; i < A.length; i++) if (A[i].length!= ncolA) throw new IllegalArgumentException("Exception in DecimalNumberMatrix.DOUBLE_transpose(): argument A has rows of unequal sizes.");

		int[][] transpose = new int[ncolA][nrowA];
		for (int rC = 0; rC < ncolA; rC ++)
			for (int cC = 0; cC < nrowA; cC++)
				transpose[rC][cC] = A[cC][rC];
		return transpose;
	}

	public static int[][] INTEGER_clone(int[][] A){
		int[][] result = new int[A.length][];
		for(int r = 0; r < A.length; r++)		{
		  int[] oldRow = A[r];
		  int[] newRow  = new int[oldRow.length];
		  System.arraycopy(oldRow, 0, newRow, 0, oldRow.length);
		  result[r] = newRow;
		}
		return result;
	}

	@Override
	public boolean matchesFieldRestriction(FieldRestriction ft) {
		for (DecimalNumberArray dna: this)
			if (!dna.matchesFieldRestriction(ft))
				return false;
		return true;
	}



	/** Provides a NumberObjectMatrix where the original matrix is repeated with a different value of
	 * array, for all possible array1 values. The array is repeated n times in the FIRST column For instance, if the matrix is
	 * 1 2
	 * 3 4
	 *
	 * and array = {5,6}, then the result is:
	 *  5 1 2 
	 *  5 3 4 
	 *  6 1 2 
	 *  6 3 4 
	 * */
	public static DecimalNumberMatrix expandGrid( NumberObjectArray array, NumberObjectMatrix matrix) {
		int nrow = matrix.nrow();
		int ncol = matrix.ncol();

		DecimalNumberMatrix newMatrix = new DecimalNumberMatrix(matrix.nrow()*array.size(), matrix.ncol()+1);

		for (int i = 0; i < array.size(); i ++)
			for (int row = 0 ; row < nrow; row++){
				newMatrix.setValueAt(i*nrow+row, 0, array.get(i));
				for (int col = 0; col < ncol; col++){
					newMatrix.setValueAt(i*nrow+row, col+1, matrix.getValueAt(row, col));
				}
			}
		return newMatrix;
	}


	/** Provides a NumberObjectMatrix where the original matrix is repeated with a different value of
	 * array, for all possible array1 values. The array is repeated n times in the LAST column For instance, if the matrix is
	 * 1 2
	 * 3 4
	 *
	 * and array = {5,6}, then the result is:
	 *  1 2 5
	 *  1 2 6
	 *  3 4 5
	 *  3 4 6 
	 * */
	public static DecimalNumberMatrix expandGrid(NumberObjectMatrix matrix, NumberObjectArray array) {
		int nrow = matrix.nrow();
		int ncol = matrix.ncol();
//TODO!
		DecimalNumberMatrix newMatrix = new DecimalNumberMatrix(matrix.nrow()*array.size(), matrix.ncol()+1);

		for (int r=0; r < nrow; r++)
			for (int c=0; c<ncol; c++)
				for (int a=0; a < array.size(); a++)
					newMatrix.setValueAt(r+nrow*a, c, matrix.getValueAt(r, c));
		
		for (int a=0; a < array.size(); a++)
			for (int r = 0; r < nrow; r++)
				newMatrix.setValueAt(a*newMatrix.nrow, newMatrix.ncol-1, array.get(Math.floorMod( array.size(), r)));
		
		return newMatrix;
	}

	
}
