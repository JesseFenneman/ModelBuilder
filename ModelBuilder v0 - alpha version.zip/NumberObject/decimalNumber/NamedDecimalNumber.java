package decimalNumber;

import java.math.BigDecimal;

import abstractNumberObjectsAndInterfaces.NamedNumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject;

/** A NamedDecimalNumber is a DecimalNumber object that has a name attached to it. */
public class NamedDecimalNumber extends DecimalNumber implements NamedNumberObjectSingle{

	private static final long serialVersionUID = 7090442462767752345L;
	public final String name;
	
	// Constructors that only have a name and a value
	public NamedDecimalNumber (String name, DecimalNumber value) {super(value); this.name = name;}
	public NamedDecimalNumber (String name, Number value) {super(value); this.name = name;}
	public NamedDecimalNumber (String name, BigDecimal value) {super(value); this.name = name;}
	public NamedDecimalNumber (String name, String value) {super(value); this.name = name;}
	
	// Constructors that have a name, value, and immutability
	public NamedDecimalNumber (String name, DecimalNumber value, boolean immutable) {super(value, immutable); this.name = name;}
	public NamedDecimalNumber (String name, Number value, boolean immutable) {super(value, immutable); this.name = name;}
	public NamedDecimalNumber (String name, BigDecimal value, boolean immutable) {super(value, immutable); this.name = name;}
	public NamedDecimalNumber (String name, String value, boolean immutable) {super(value, immutable); this.name = name;}

	// Constructors that have a name, value, and range (assuming mutability)
	public NamedDecimalNumber (String name, DecimalNumber value, DecimalNumber minimum, DecimalNumber maximum ) {super(value, minimum, maximum, false); this.name = name;}
	public NamedDecimalNumber (String name, Number value, Number minimum, Number maximum ) {super(value, minimum, maximum, false); this.name = name;}
	public NamedDecimalNumber (String name, BigDecimal value, BigDecimal minimum, BigDecimal maximum ) {super(value, minimum, maximum, false); this.name = name;}
	public NamedDecimalNumber (String name, String value, String minimum, String maximum ) {super(value, minimum, maximum, false); this.name = name;}
	
	// Constructors that have a name, value, range, and mutability
	public NamedDecimalNumber (String name, DecimalNumber value, DecimalNumber minimum, DecimalNumber maximum, boolean immutable ) {super(value, minimum, maximum, immutable); this.name = name;}
	public NamedDecimalNumber (String name, Number value, Number minimum, Number maximum, boolean immutable ) {super(value, minimum, maximum, immutable); this.name = name;}
	public NamedDecimalNumber (String name, BigDecimal value, BigDecimal minimum, BigDecimal maximum, boolean immutable ) {super(value, minimum, maximum, immutable); this.name = name;}
	public NamedDecimalNumber (String name, String value, String minimum, String maximum , boolean immutable) {super(value, minimum, maximum, immutable); this.name = name;}
	
	public NamedDecimalNumber clone() {
		return new NamedDecimalNumber(name, this.toBigDecimal());
	}
	@Override
	public String getName() {
		return name;
	}
	@Override
	public NumberObject toNumberObject() {
		return new DecimalNumber(this);
	}
	
}
