package decimalNumber;

import abstractNumberObjectsAndInterfaces.NamedNumberObjectMatrix;
import abstractNumberObjectsAndInterfaces.NumberObject;

/** A NamedDecimalNumberMatrix is a DecimalNumberMatrix object that has a name attached to it. */
public class NamedDecimalNumberMatrix extends DecimalNumberMatrix implements NamedNumberObjectMatrix {

	private static final long serialVersionUID = 548704898159150870L;
	public final String name;
	
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	CONSTRUCTORS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	/** Wrapper constructor*/
	public NamedDecimalNumberMatrix (String name, DecimalNumberMatrix dnm) { super(dnm, false); this.name= name;}
	
	/** Instantiate a NamedDecimalNumberMatrix from a 2 dimensional array of doubles ([rows][columns]). The nrow
	 * of the resulting NamedDecimalNumberMatrix is the number of rows in the double matrix (first index). The ncol
	 * of the resulting NamedDecimalNumberMatrix is the length of the first array in the arrays of doubles.
	 * 
	 * The doubleMatrix should have rows (first index) of equal length. If not, an IllegalArgumentException is thrown.
	 * @param matrix
	 */
	public NamedDecimalNumberMatrix (String name, double[][] doubleMatrix) { super(doubleMatrix); this.name=name;}

	/** Instantiate a NamedDecimalNumberMatrix from a 2 dimensional array of DecimalNumbers ([rows][columns]). 
	 * The decimalNumberMatrix should have rows (first index) of equal length. If not, an IllegalArgumentException is thrown.
	 * @param matrix
	 */
	public NamedDecimalNumberMatrix (String name, DecimalNumber[][] decimalNumberMatrix) {super(decimalNumberMatrix); this.name=name; }
	public NamedDecimalNumberMatrix (String name, DecimalNumberArray... rows)	{super(rows); this.name=name; }

	/**
	 * Creates a matrix containing nrow by ncol mutable NamedDecimalNumbers with value 0 and without range.
	 * @param columnNames
	 * @param nrow
	 * @param ncol
	 */
	public NamedDecimalNumberMatrix (String name, int nrow, int ncol)	{super(nrow, ncol); this.name=name; }

	/**
	 * Creates a matrix containing nrow by ncol mutable NamedDecimalNumbers with value <value>. 
	 * @param columnNames
	 * @param nrow
	 * @param ncol
	 */
	public NamedDecimalNumberMatrix (String name, int nrow, int ncol, double value)	{super(nrow, ncol, value); this.name=name; }


	/**
	 * Create a new NamedDecimalNumberMatrix with nrow rows and ncol columns from an array of DecimalNumbers. If byrow is set to true,
	 * the NamedDecimalNumbers are added per row. Otherwise, they are added per column.
	 * @param nrow
	 * @param ncol
	 * @param columnNames
	 * @param byrow
	 * @param decimalNumbers
	 */
	public NamedDecimalNumberMatrix (String name, int nrow, int ncol, boolean byrow, DecimalNumberArray array)  {super(nrow, ncol, byrow, array); this.name=name; }

	/** wraps the NamedDecimalNumberArray in a matrix that has 1 column */
	public static NamedDecimalNumberMatrix toColumnVector(String name, DecimalNumberArray vector) {
		return new NamedDecimalNumberMatrix(name, vector.size(), 1, false, vector);
	}

	/** Create a new NamedDecimalNumberMatrix with nrow rows and ncol columns from an array of DecimalNumbers. If byrow is set to true,
	 * the NamedDecimalNumbers are added per row. Otherwise, they are added per column.
	 * @param nrow
	 * @param ncol
	 * @param columnNames
	 * @param byrow
	 * @param decimalNumbers
	 */
	public NamedDecimalNumberMatrix (String name, int nrow, int ncol, boolean byrow, DecimalNumber... decimalNumbers)  {super(nrow, ncol, byrow, decimalNumbers); this.name=name; }

	/** Create a new NamedDecimalNumberMatrix with nrow rows and ncol columns from an array of DecimalNumbers. If byrow is set to true,
	 * the DecimalNumbers are added per row. Otherwise, they are added per column.
	 * @param nrow
	 * @param ncol
	 * @param columnNames
	 * @param byrow
	 * @param decimalNumbers
	 */
	public NamedDecimalNumberMatrix (String name, int nrow, int ncol, boolean byrow, double... doubleNumbers)  {super(nrow, ncol, byrow, doubleNumbers); this.name=name; }


	public static NamedDecimalNumberMatrix randomMatrix (String name, int nrow, int ncol, double min, double max, boolean integerOnly) {
		DecimalNumberArray[] rows = new DecimalNumberArray[nrow];
		for (int i = 0; i< nrow; i ++) {
			DecimalNumberArray newRow = new DecimalNumberArray(ncol);
			for (int j = 0; j < ncol; j++) {
				double value = Math.random()*(max-min) + min;
				if (integerOnly) value = Math.round(value);
				newRow.set(j, new DecimalNumber(value));
			}

			rows[i] = newRow;
		}
		return new NamedDecimalNumberMatrix(name, rows);

	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public NumberObject toNumberObject() {
		return new DecimalNumberMatrix(this, false);
	}

}
