package decimalNumber;

import java.io.Serializable;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Iterator;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectMatrix;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject.UnknownNumberObjectException;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle.VALUE_FLAG;
import doubleNumber.DoubleNumberArray;
import doubleNumber.DoubleNumberMatrix;
import helper.Helper;

/**
 * A wrapper that holds an array of DecimalNumbers, and defines several
 * often-used computations for such an array.
 */
public class DecimalNumberArray implements Serializable, Cloneable, Iterable<DecimalNumber>, NumberObjectArray{

	private static final long serialVersionUID = Helper.programmeVersion;
	public DecimalNumber[] array;
	private int length;
	private boolean immutable = false;
	
	/////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	CONSTRUCTORS 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	public DecimalNumberArray(NumberObjectSingle... numbers) { 
		this.array = new DecimalNumber[numbers.length] ;
		for (int i = 0; i < array.length; i ++)
			array[i] = numbers[i].toDecimalNumber();
		this.length = array.length; 
	}
	
	/** Shallow clone*/
	public DecimalNumberArray(DecimalNumber... numbers) { 
		this.array = new DecimalNumber[numbers.length] ;
		for (int i = 0; i < array.length; i ++)
			array[i] = numbers[i];
		this.length = array.length; 
	}
	
	/** Creates a DecimalNumberArray, consisting of mutable DecimalNumbers with the values specified and without a range limitation
	 * 
	 * @param numbers The double values to be converted to mutable DecimalNumbers
	 */
	public DecimalNumberArray(double... numbers) { 
		this.length = numbers.length;
		this.array = new DecimalNumber[length];
		for (int i = 0; i < length; i ++)
			array[i] = new DecimalNumber(numbers[i],false); }
	
	/** Creates a DecimalNumberArray, consisting of mutable DecimalNumbers with the values, range and immutability specified
	 * 
	 * @param numbers The double values to be converted to mutable DecimalNumbers
	 */
	public DecimalNumberArray(double minimum, double maximum, boolean immutable, double... numbers) { 
		this.length = numbers.length;
		this.array = new DecimalNumber[length];
		for (int i = 0; i < length; i ++)
			array[i] = new DecimalNumber(numbers[i], minimum, maximum, false); }

	/** Creates a DecimalNumberArray that contains all values between minimum and maximum that
	 * are in the set {x | minimum+nx, x < maximum}.
	 * 
	 * If the supplied minimum is larger than the maximum, the two are reversed.
	 * Thus, the stepSize always has to be positive (no fancy stuff like: an array from -2 to -10 with steps of -1; 
	 * only -10 to -2 with steps of 1 is allowed!).
	 * @return
	 */
	public DecimalNumberArray (NumberObjectSingle minimum, NumberObjectSingle maximum, NumberObjectSingle stepSize) {
		// Make sure that the minimum is smaller than the maximum. If this is not the case, flip the two around
		if (!maximum.largerThanOrEqualTo(minimum)) {
			NumberObjectSingle temp = maximum;
			maximum = minimum;
			minimum = temp;
		}
			
		// The step size has to be a positive value
		if (stepSize.smallerThan(0))
			if (!minimum.equals(maximum))
				throw new IllegalArgumentException("Trying to create a DecimalNumberArray with a non-positive step size. ");

		this.length=maximum.subtract(minimum, false).divide(stepSize).round(0, RoundingMode.DOWN).toInt(RoundingMode.HALF_EVEN)+1;
		this.array = new DecimalNumber[this.length];
		for (int i = 0; i < length; i++) 
			array[i] = minimum.add(stepSize.multiply(i, false), false).toDecimalNumber();
	}
	
	
		/** Creates a DecimalNumberArray of size n. The DecimalNumbers in this array are all non-initialized (i.e., null)
	 * 
	 * @param n
	 */
	public DecimalNumberArray(int n) {
		this.array = new DecimalNumber[n];
		this.length=n;
	}
	
	/** Copy constructor. If deepClone is true, the resulting Array is a deep clone (all objects in this array are cloned as well). Otherwise its a shallow clone (the objects in this array point to the original objects)*/
	public DecimalNumberArray (DecimalNumberArray original, boolean deepClone) {
		this.length = original.size();
		this.array = new DecimalNumber[length];
		for (int i = 0; i < length; i ++)
			if (deepClone)
				array[i] = original.get(i).toDecimalNumber().clone();
			else
				array[i] = original.get(i).toDecimalNumber().clone();
	}
		
	/** Creates an array of length length with values between min and max.*/
	public static DecimalNumberArray randomArray(int length, double min, double max, boolean integerOnly ) {
		double[] values = new double[length];
		for (int i = 0; i < length; i++) {
			values[i] = Math.random()*(max-min) + min;
			if (integerOnly) values[i] = Math.round(values[i]);
		}
		return new DecimalNumberArray(values);
	}
	
	/** Creates an array that consists of n repeats of value */
	public static DecimalNumberArray repeat(int length, Number value) {
		DecimalNumber[] array = new DecimalNumber[length];
		for (int i = 0; i < length; i++)
			array[i] = new DecimalNumber(value);
		return new DecimalNumberArray(array);
	}
	
	/** Creates an array that consists of n repeats of value */
	public static DecimalNumberArray repeat(int length, NumberObjectSingle value) {
		DecimalNumber[] array = new DecimalNumber[length];
		for (int i = 0; i < length; i++)
			array[i] = value.toDecimalNumber().clone();
		return new DecimalNumberArray(array);
	}
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// 	Static functions that create new Arrays 	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * Returns the dot product (AKA inner product) of both arrays. Formally, returns:
	 * sum( this[i] * otherArray[i] ) for all i in [0, this.length]. 
	 * 
	 * Throws a UnsupportedOperationException if the arrays are unequal in length.
	 * @param array1
	 * @param array2
	 * @return
	 */
	public static DecimalNumber dotProduct(NumberObjectArray array1, NumberObjectArray array2)   {
		if (array1.size() != array2.size())
			throw new IllegalArgumentException("Dotproduct: trying to get dot product of arrays of unequal size.");
		
		DecimalNumber sum = new DecimalNumber(0);
		for (int i = 0; i < array1.size(); i ++)
			sum.add(array1.get(i).multiply(array2.get(i), false));
		
		return sum;
	}
	
	/** Returns a unity vector (a row vector containing only 1's) of the specified length */
	public static DecimalNumberArray unityVector(int length) {
		return DecimalNumberArray.rep(1, length);
	}
	

	/**
	 * Results in an array containing the sequence from <from> (inclusive) to <to> (exclusive),
	 *  increasing with step size <step>.
	 * @param from
	 * @param to
	 * @param step
	 * @return
	 */
	public static DecimalNumberArray sequence(NumberObjectSingle from, NumberObjectSingle to, NumberObjectSingle step)  	{		
		DecimalNumber f = from.toDecimalNumber();
		DecimalNumber t = to.toDecimalNumber();
		DecimalNumber s = step.toDecimalNumber();
		
		int indices = t.subtract(f, false).divide(s, false).toInt(RoundingMode.HALF_EVEN)+1;

		DecimalNumber[] sequence = new DecimalNumber[indices];
		for (int i = 0; i < indices; i++) {
			sequence[i] = f.add(s.multiply(i, false), false).setImmutable(false);
		}

		return new DecimalNumberArray(sequence);
	}

	 /** Results in an array containing the sequence from <from> (inclusive) to <to> (exclusive),
	 *  increasing with step size <step>.
	 * @param from
	 * @param to
	 * @param step
	 * @return 
	 */
	public static DecimalNumberArray sequence(double from, double to, double step)  	{
		int indices = (int) ( (to-from)/(step)) + 1;

		DecimalNumber[] sequence = new DecimalNumber[indices];
		for (int i = 0; i < indices; i++)
			sequence[i] = new DecimalNumber(from + (step*i));

		return new DecimalNumberArray(sequence);
	}

	/**
	 * Results in an array containing n clones of the value.
	 * @param from
	 * @param to
	 * @param step
	 * @return
	 */
	public static DecimalNumberArray rep(NumberObjectSingle value, int n)	{
		DecimalNumber[] sequence = new DecimalNumber[n];
		for (int i = 0; i < n; i++)
			sequence[i] = value.toDecimalNumber().clone();

		return new DecimalNumberArray(sequence);
	}

	/**
	 * Results in an array containing n clones of the value.
	 * @param from
	 * @param to
	 * @param step
	 * @return
	 */
	public static DecimalNumberArray rep(double value, int n)	{
		DecimalNumber[] sequence = new DecimalNumber[n];
		for (int i = 0; i < n; i++)
			sequence[i] = new DecimalNumber(value);

		return new DecimalNumberArray(sequence);
	}


	/** Creates a DecimalNumberArray that contains all values that are a multiple of stepsize and fall in the range
	 * [minimum, maximum]. Specifically, all values that are in the set 
	 * 
	 * {n * stepsize | x = n*stepsize, minimum < x < maximum}.
	 * 
	 * If the supplied minimum is larger than the maximum, the two are reversed.
	 * Thus, the stepSize always has to be positive (no fancy stuff like: an array from -2 to -10 with steps of -1; 
	 * only -10 to -2 with steps of 1 is allowed!).
	 * @return
	 */
	public static DecimalNumberArray allMultiplesInRange (NumberObjectSingle minimum, NumberObjectSingle maximum, NumberObjectSingle stepSize) {
		DecimalNumber min = minimum.toDecimalNumber();
		DecimalNumber max = maximum.toDecimalNumber();
		DecimalNumber step = stepSize.toDecimalNumber();
		
		// Make sure that the minimum is smaller than the maximum. If this is not the case, flip the two around
		if (!max.largerThanOrEqualTo(min)) {
			DecimalNumber temp = max;
			max = min;
			min = temp;
		}
		// The step size has to be a positive value
		if (step.smallerThan(0))
			if (!min.equals(max))
				throw new IllegalArgumentException("Trying to create a DecimalNumberArray with a non-positive step size. ");
		
		// Compute the lowest multiple of stepsize that is still larger than minimum.
		// First, compute the lowest multiple that is smaller than the minimum
		// This value is the computed by computing the module between minimum and stepsize.
		// Because the first multiple must be larger than the minimum, we subtract the modulus
		// from the stepsize, and add the result to the minimum. Hence:
		// smallestMultiple = minimum - mod(minimum, stepsize)
		DecimalNumber smallestMultiple = min.subtract( (min.mod(step)) ) ;
		
		// This value can be lower than the minimum. If so, add one stepsize
		if (smallestMultiple.smallerThan(min))
			smallestMultiple.add(step, true);
	
		// Similarly, the largestMultiple is maximum - mod(maximum, stepsize)
		DecimalNumber largestMultiple = max.subtract(   max.mod(step)   );

		// The array is then a sequence from smallestMultiple to largestMultiple with the same stepSize:
		return new DecimalNumberArray(smallestMultiple, largestMultiple, step);
		

	}
	/////////////////////////////////////////////////////////////////////////////
	/////////////////////////// 	Transformations /////////////////////////////
	/////////////////////////////////////////////////////////////////////////////
	@Override
	public double[] toDoubleArray() {
		double[] doubleArray = new double[length];
		for (int i = 0; i < length; i ++)
			doubleArray[i] = array[i].toDouble();
		return doubleArray;
	}
	
	@Override
	public Integer[] toIntegerArray(RoundingMode rm) {
		Integer[] a = new Integer[length];
		for (int i = 0; i < length; i ++)
			a[i] = array[i].toInt(rm);
		return a;
	}
	
	@Override
	public DecimalNumberArray toDecimalNumberArray() {return this;}

	@Override
	public DoubleNumberArray toDoubleNumberArray() {
		return new DoubleNumberArray(this.array);}
	
	@Override
	public NumberObjectArray toNumberObjectArray(NumberObjectRepresentation formatToUse) {
		if (formatToUse == NumberObject.NumberObjectRepresentation.DECIMALNUMBER)
			return this.toDecimalNumberArray();
		if (formatToUse == NumberObject.NumberObjectRepresentation.DOUBLENUMBER)
			return  this.toDoubleNumberArray();
		throw new UnknownNumberObjectException();
	}
	
	
	@Override
	public NumberObjectSingle[] toArray() {
		return array;
	}
	
	@Override
	public NumberObjectSingle[] toArray(NumberObjectRepresentation formatToUse) {
		NumberObjectSingle[] a = new NumberObjectSingle[length];
		for (int i = 0; i < length; i ++)
			a[i] = array[i].toNumberObjectSingle(formatToUse);
		return a;
	}
	
	/** Provides a NumberObjectMatrix with all possible combinations of array1 and array2.
	 * For example, if array1 = {1,2,3} and array2 = {4,5,6}, then the result is a matrix with
	 * two columns:
	 * array1 			array2
	 * -------------------------
	 * 1			4
	 * 1			5
	 * 1			6
	 * 2			4
	 * 2			5
	 * 2			6
	 * 3			4
	 * 3			5
	 * 3			6
	 * */
	public static DecimalNumberMatrix expandGrid(NumberObjectArray array1, NumberObjectArray array2) {
		int n = array1.size() * array2.size();
		DecimalNumberMatrix newArray = new DecimalNumberMatrix(n, 2);
		for (int i=0; i< array1.size(); i++)
			for (int j=0; j< array2.size(); j++){
				newArray.setValueAt(i*array2.size()+j, 0, array1.get(i));
				newArray.setValueAt(i*array2.size()+j, 1, array2.get(j));
			}
		return newArray;
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////// 	Elementary operations - setters, getters, checks 	/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean isImmutable() { return this.immutable; }
	
	@Override	
	public int size() {
		return array.length;
	}

	@Override
	public DecimalNumber get(int index) { return array[index]; }
	
	@Override
	public void set(int index, NumberObjectSingle element) 	{ 
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		if (index < 0 || index> length ) throw new ArrayIndexOutOfBoundsException("Trying to set index " + index + "of an array with size " + size());

		array[index] = element.toDecimalNumber();
	}

	@Override
	public void set (int index, double element) 	{ 
		this.set(index, new DecimalNumber(element));
	}
	
	@Override
	public void setAll(double newValue){
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");

		for (int i = 0; i <array.length; i++) {
			if (array[i] == null)
				array[i] = new DecimalNumber(newValue);
			else 
				array[i].set(newValue);
		}
	}
	
	@Override
	public void setAll(NumberObjectArray newValues)   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		if (newValues.size()> length ) throw new ArrayIndexOutOfBoundsException("Trying to set all values in this array, with has size " + size() + ", to the values in another array, which has size " + newValues.size());

		for (int i = 0; i < length; i ++)
			array[i].set(newValues.get(i));
		
	}

	@Override
	public void insert(int index, NumberObjectSingle number) {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		if (index < 0 || index> length ) throw new ArrayIndexOutOfBoundsException("Trying to set index " + index + "of an array with size " + size());

		DecimalNumber[] newArray = new DecimalNumber[length+1];
		System.arraycopy(array, 0, newArray, 0, index);
		System.arraycopy(array, index, newArray, index + 1, array.length - index );
		newArray[index] = number.toDecimalNumber();
		array = newArray;
		length = array.length;
	}
	
	@Override
	public void remove(int index) {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		if (index < 0 || index> length ) throw new ArrayIndexOutOfBoundsException("Trying to set index " + index + "of an array with size " + size());


		DecimalNumber[] newArray = new DecimalNumber[array.length-1];		
		System.arraycopy(array,0,newArray,0,index);
		if (index != array.length)
			System.arraycopy(array, index+1, newArray, index, array.length-index-1);
		this.array = newArray;
		
		length = array.length;
	}
	
	@Override
	public DecimalNumberArray setImmutable(boolean immutability) {
		this.immutable = immutability;
		for(DecimalNumber dn: array)
			dn.setImmutable(immutability);
		return this;
	}
	
	@Override
	public void makeImmutable() {
		setImmutable(true);
	}
	
	@Override
	public void setImmutableArrayOnly(boolean immutability) {
		this.immutable = immutability;
	}
	
	@Override
	public void replaceAll(NumberObjectArray newArray) {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");
		this.array = newArray.toDecimalNumberArray().array;
		this.length = newArray.size();
	}
	
	@Override
	public void setAllRanges(double minimum, double maximum) {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array.");

		for (DecimalNumber dn: array) 
			dn.setRange(minimum, maximum);
	}


	/**
	 * Returns the index of the element in the array. If the element is not in the array, a -1 is returned.
	 * If the element is at multiple positions, the first position is returned.
	 * @param element
	 * @return
	 */
	public int indexOf(DecimalNumber element){
		for (int i = 0; i < length; i++)
			if (array[i].equals(element))
				return i;
		return -1;

	}

	@Override
	public int indexOf(NumberObjectSingle element){
		for (int i = 0; i < length; i++)
			if (array[i].equals(element))
				return i;
		return -1;
	}
	
	@Override
	public int indexOf(double element){
		for (int i = 0; i < length; i++)
			if (array[i].equals(element))
				return i;
		return -1;
	}

	////////////////////////////////////////////////////////////////////////////
	/////////////////// 	toString variants 	////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	@Override
	public String toString()	{
		StringBuilder sb = new StringBuilder();
		DecimalFormat df = new DecimalFormat("#." + Helper.repString("#", DecimalNumber.SCALE));
		sb.append("[");
		
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else {
				if (array[i].getFlag() == VALUE_FLAG.NaN) sb.append("NaN");
				else if (array[i].getFlag() == VALUE_FLAG.NULL) sb.append("Null");
				else if (array[i].getFlag()== VALUE_FLAG.NEGATIVE_INFINITY) sb.append("-Inf");
				else if (array[i].getFlag() == VALUE_FLAG.POSITIVE_INFINITY) sb.append("Inf");
				else
					sb.append(df.format(array[i].toDouble()));
				
				if (array[i].isImmutable()) 
					sb.append("*");
			}
			if (i != array.length-1)
				sb.append("   ");
			
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();		
	}
	
	@Override
	public String toString(int significantDigits)	{
		StringBuilder sb = new StringBuilder();
		DecimalFormat df = new DecimalFormat("#." + Helper.repString("#",significantDigits));
		sb.append("[");
		
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else {
				if (array[i].getFlag() == VALUE_FLAG.NaN) sb.append("NaN");
				else if (array[i].getFlag() == VALUE_FLAG.NULL) sb.append("Null");
				else if (array[i].getFlag()== VALUE_FLAG.NEGATIVE_INFINITY) sb.append("-Inf");
				else if (array[i].getFlag() == VALUE_FLAG.POSITIVE_INFINITY) sb.append("Inf");
				else
					sb.append(df.format(array[i].toDouble()));
				
				if (array[i].isImmutable()) 
					sb.append("*");
			}
			if (i != array.length-1)
				sb.append("   ");
			
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();		
	}
	
	
	@Override
	public String toPlainString()	{
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else
				sb.append(array[i].toPlainString());
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();
				
	}
	
	@Override
	public String toPlainString(int significantDigits)	{
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else
				sb.append(array[i].toString(significantDigits));
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();
				
	}
	
	@Override
	public String toStringWithoutTrailingZeros()	{
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else
				sb.append(" " +array[i].toStringWithoutTrailingZeros() + " ");
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();
				
	}
	
	@Override
	public String toExactString()	{
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < array.length; i ++) {
			if (array[i]==null)
				sb.append("NULL");
			else
				sb.append(array[i].toDouble());
			if (array[i].isImmutable()) 
				sb.append("*");
			if (i != array.length-1)
				sb.append("\t");
		}
		sb.append("]");
		if (immutable) sb.append("*");
		return sb.toString();
				
	}

	@Override
	public String toRParsableString ()	{
		StringBuilder sb = new StringBuilder();
		sb.append("c(");
		for (int n = 0; n<array.length; n++)
		{
			String number = array[n].toRParsableString();
			number = number.replace(",", ".");
			sb.append(number);
			if (n != array.length-1)
				sb.append(",");
		}
		sb.append(")");
		return sb.toString();
	}


	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////// 	Boolean properties of array ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean containsNull() {
		for (DecimalNumber dn: array)
			if (dn == null)
				return true;
			else if (dn.isNull())
				return true;
		return false;
	}
	
	@Override
	public boolean containsNaN() {
		for (DecimalNumber dn: array)
			if (dn.isNaN())
				return true;
		return false;
	}
	
	@Override
	public boolean containsNegativeInfinity() {
		for (DecimalNumber dn: array)
			if (dn.isNegativeInfinity())
				return true;
		return false;
	}

	@Override
	public boolean containsPositiveInfinity() {
		for (DecimalNumber dn: array)
			if (dn.isPositiveInfinity())
				return true;
		return false;
	}

	@Override
	public boolean contains(NumberObjectSingle element, boolean approximately) {
		for (DecimalNumber dn: array)
			if (dn.equals(element, approximately))
				return true;
		return false;
	}

	@Override
	public boolean contains(double element, boolean approximately) {
		for (DecimalNumber dn: array)
			if (dn.equals(element, approximately)) 
				return true;
		return false;
	}

	
	@Override
	public boolean equals(NumberObjectArray other) {
		if (length != other.size())
			return false;
		
		for (int i = 0; i < length; i++)
			if (!array[i].equals(other.get(i)))
				return false;
		return true;
	}
	
	@Override
	public boolean isProbability() {
		if (this.min().compareTo(0)==-1)
			return false;
		if (!this.sum().equals(1, true))
			return false;
		return true;
	}

	@Override
	public boolean matchesFieldRestriction(FieldRestriction ft) {
		for (DecimalNumber dn: array)
			if (!FieldRestriction.isValid(dn.toPlainString(), ft))
				return false;
		return true;
	}
		
	/////////////////////////////////////////////////////////////////////////////////////
	/////////////////// 	Operations on this array 	////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void toProbability()   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array") ;
		
		if (min().compareTo(0)==-1)
			throw new UnsupportedOperationException("Error at DecimalNumberArray.toProbability(): trying to turn an array containing negative values into a probability distribution");
		DecimalNumber sum = this.sum();
		
		// if sum ~ 0: create uniform distribution
		if (sum.equals(0, true)) {
			double uniform = 1.0/length;
			for (int i = 0 ; i < array.length; i ++)
				array[i].set(uniform);
		}
		
		else
			for (int i = 0 ; i < array.length; i ++)
				array[i] = array[i].divide(sum);
	}
	
	@Override
	public DecimalNumberArray scale(NumberObjectSingle scalar)   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array") ;
		for (int i = 0; i < length; i ++)
			array[i] = array[i].multiply(scalar);
		return this;
	}
	
	@Override
	public DecimalNumberArray scale(double scalar)   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array") ;
		for (int i = 0; i < length; i ++)
			array[i] = array[i].multiply(scalar);
		return this;
	}
	
	@Override
	public DecimalNumberArray scaleToSumToOne()   {
		if (immutable) throw new UnsupportedOperationException("Trying to change an immutable array") ;
		DecimalNumber sum = this.sum();
		if (sum.equals(0, false)) {
			DecimalNumber uniform = DecimalNumber.ONE.divide(length);
			for (DecimalNumber dn: array)
				dn.set(uniform);
			return this;
		}
		
		for (DecimalNumber dn: array)
			dn.set(dn.divide(sum));
		return this;
	}
	
	@Override
	public DecimalNumber max()	{
		DecimalNumber max = array[0];
		for (DecimalNumber n: array)
			if (n.compareTo(max)==1)
				max = n;
		return max;
	}

	@Override
	public DecimalNumber min()
	{
		DecimalNumber min = array[0];
		for (DecimalNumber n: array)
			if (n.compareTo(min)==-1)
				min = n;
		return min;
	}

	
	@Override
	public DecimalNumber sum()	{
		DecimalNumber sum = new DecimalNumber(0);
		for (DecimalNumber dn:array)
			if (!dn.equals(DecimalNumber.NEGATIVE_INFINITY) && !dn.equals(DecimalNumber.POSITIVE_INFINITY) && !dn.equals(DecimalNumber.NULL) && !dn.equals(DecimalNumber.NaN))
				sum.add(dn, true);
		return sum;
	}
	
	@Override
	public int validN() {
		int i = 0;
		for (DecimalNumber dn: array){
			if (dn != DecimalNumber.NEGATIVE_INFINITY && dn != DecimalNumber.POSITIVE_INFINITY && dn != DecimalNumber.NULL && dn != DecimalNumber.NaN && dn != null)
				i++;
		}
		return i;
	}

	@Override
	public DecimalNumber mean()   {
		return sum().divide(validN());
	}
	
	@Override
	public DecimalNumber variance()   {
		int validN = validN();
		if (validN <2)
			throw new IllegalStateException("Exception in DecimalNumberArray.variance(): trying to compute variance with less than 2 valid values (Nvalid = " + validN +". Array: " + this);
		
		DecimalNumber variance = new DecimalNumber(0, DecimalNumber.ZERO, DecimalNumber.POSITIVE_INFINITY, false);
		DecimalNumber mean = mean().setImmutable(true);

		for (DecimalNumber dn: array) 
			if (!dn.equals(DecimalNumber.NEGATIVE_INFINITY) && !dn.equals(DecimalNumber.POSITIVE_INFINITY) && !dn.equals(DecimalNumber.NULL) && !dn.equals(DecimalNumber.NaN))
				variance.add(dn.subtract(mean, false).abs().pow(2, true));
		return variance.divide(validN-1);
	}
	
	@Override
	public DecimalNumber standardDeviation()   {
		return variance().pow(0.5, true);
	}
		
	/////////////////////////////////////////////////////////////////////////////////////
	///////////////////////		Vector multiplication	/////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////

	@Override
	public DecimalNumber dotProduct(NumberObjectArray otherArray)   {
		if (this.length != otherArray.size())
			throw new IllegalArgumentException("Dotproduct: trying to get dot product of arrays of unequal size.");
		
		DecimalNumber sum = new DecimalNumber(0);
		for (int i = 0; i < length; i ++)
			sum.add(array[i].multiply(otherArray.get(i)), true);
		
		return sum;
	}
	
	
	
	/////////////////////////////////////////////////////////////////////////////////////
	////////////// 	Other operations resulting in a new array 	/////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////
	@Override
	public DecimalNumberArray clone() {
		DecimalNumber[] newArray = new DecimalNumber[length];
		for (int i = 0; i<length; i++) newArray[i] = new DecimalNumber(array[i]);
		
		DecimalNumberArray clone = new DecimalNumberArray(newArray);
		clone.setImmutable(false);
		return clone;
	}
	
	@Override
	public NumberObjectArray shallowClone() {
		DecimalNumberArray clone = new DecimalNumberArray(array);
		clone.setImmutableArrayOnly(false);
		return clone;
	}
	
	@Override
	public NumberObjectArray subset(int from, int to)	{
		return new DecimalNumberArray(Arrays.copyOfRange(array, from, to));
	}

	@Override
	public DecimalNumberArray multiply(NumberObjectArray other)   {
		if (length != other.size()) return null;
		
		DecimalNumberArray product = DecimalNumberArray.rep(0, length);
		for (int i = 0; i < product.length; i++)
			product.set(i, array[i].multiply(other.get(i), false));
		
		return product;
	}
	
	@Override
	public DecimalNumberArray concatenate(NumberObjectArray otherArray)	{
		int newLength = array.length + otherArray.size();
		DecimalNumber[] newArray = Arrays.copyOfRange(array, 0, newLength);
	
		for (int i=0; i < otherArray.size(); i++) 
			newArray[this.length+i] = otherArray.get(i).toDecimalNumber();
		return new DecimalNumberArray(newArray);
	}
	
	
	@Override
	public Iterator<DecimalNumber> iterator() {
		return new Iterator<DecimalNumber>() {
			int currentIndex = 0;
			
			@Override
			public boolean hasNext() {
				return currentIndex < length && array[currentIndex] != null;
			}

			@Override
			public DecimalNumber next() {
				return array[currentIndex++];
			}
			
		};
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(array);
		result = prime * result + (immutable ? 1231 : 1237);
		result = prime * result + length;
		return result;
	}

	


}
