package decimalNumber;

import abstractNumberObjectsAndInterfaces.NamedNumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObject;

/** A NamedDecimalNumberArray is a DecimalNumberArray object that has a name attached to it. */
public class NamedDecimalNumberArray extends DecimalNumberArray implements NamedNumberObjectArray{

	public final String name;

	/** Wrapper constructor*/
 	public NamedDecimalNumberArray (String name, DecimalNumberArray array) { super(array, false); this.name=name;	}
	
	public NamedDecimalNumberArray(String name, DecimalNumber... numbers) { super(numbers); this.name = name; }

	/** Creates a NamedDecimalNumberArray, consisting of mutable DecimalNumbers with the values specified and without a range limitation
	 * 
	 * @param numbers The double values to be converted to mutable DecimalNumbers
	 */
	public NamedDecimalNumberArray(String name, double... numbers) { super(numbers); this.name = name;  }

	/** Creates a NamedDecimalNumberArray, consisting of mutable DecimalNumbers with the values, range and immutability specified
	 * 
	 * @param numbers The double values to be converted to mutable DecimalNumbers
	 */
	public NamedDecimalNumberArray(String name, double minimum, double maximum, boolean immutable, double... numbers) { super(minimum, maximum, immutable, numbers); this.name = name; }

	
	/** Creates a NamedDecimalNumberArray of size n. The DecimalNumbers in this array are all non-initialised (i.e., null)
	 * 
	 * @param n
	 */
	public NamedDecimalNumberArray(String name, int n) { super(n); this.name = name; 	}

	/** Creates a NamedDecimalNumberArray that contains all values between minimum and maximum that
	 * are in the set {x | minimum+nx, x < maximum}
	 * @return
	 */
	public NamedDecimalNumberArray (String name, DecimalNumber minimum, DecimalNumber maximum, DecimalNumber stepSize) {super(minimum, maximum, stepSize); this.name = name; 	}
	
	
	
	/** Creates an named array of length length with values between min and max.*/
	public static NamedDecimalNumberArray randomArray(String name, int length, double min, double max, boolean integerOnly ) {
		double[] values = new double[length];
		for (int i = 0; i < length; i++) {
			values[i] = Math.random()*(max-min) + min;
			if (integerOnly) values[i] = Math.round(values[i]);
		}
		return new NamedDecimalNumberArray(name, values);
	}

	/** Creates a named array that consists of n repeats of value */
	public static NamedDecimalNumberArray repeat(String name, int length, Number value) {
		DecimalNumber[] array = new DecimalNumber[length];
		for (int i = 0; i < length; i++)
			array[i] = new DecimalNumber(value);
		return new NamedDecimalNumberArray(name, array);
	}

	/** Creates a named array that consists of n repeats of value */
	public static NamedDecimalNumberArray repeat(String name, int length, DecimalNumber value) {
		DecimalNumber[] array = new DecimalNumber[length];
		for (int i = 0; i < length; i++)
			array[i] = value.clone();
		return new NamedDecimalNumberArray(name, array);
	}


	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public NumberObject toNumberObject() {
		return new DecimalNumberArray(this, false);
	}


}
