package tests;

import org.junit.Test;

import abstractNumberObjectsAndInterfaces.NumberObject;
import attributes.AttributeField;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import helper.Helper;
import rIntegration.RFunction;
import rIntegration.RFunctionContainer;
import rIntegration.RManager;

public class RFunctionality {

	@Test
	public void bootSequence() {
		try{ 
			RManager.establishConnectionToR(); 
			Thread.sleep(2500);
			
			System.out.println("\n\n"+Helper.repString("=", 200)+ "\n");
			System.out.println("Found the following RFunctions:");
			for (RFunction rf: RManager.getAllRFunctions())
				System.out.println("\n\n------\n"+rf);
			
			System.out.println("\n\n"+Helper.repString("=", 200)+ "\n");
			System.out.println("A single-to-single test:");
			Thread.sleep(100);
			NumberObject[] testSingle = RManager.getFunction("test function single").runInR(new NumberObject[] {new DecimalNumber(2)}) ;
			for (NumberObject o: testSingle) System.out.println("result: " + o + " (class = " + o.getClass().getSimpleName() + ")");
			
			
			System.out.println("\n\n"+Helper.repString("=", 200)+ "\n");
			System.out.println("An array-to-array test:");
			Thread.sleep(100);
			NumberObject[] testArray = RManager.getFunction("test function array").runInR(new NumberObject[] {DecimalNumberArray.sequence(0, 10, 1)}) ;
			for (NumberObject o: testArray) System.out.println("result: " + o + " (class = " + o.getClass().getSimpleName() + ")");
			

			System.out.println("\n\n"+Helper.repString("=", 200)+ "\n");
			System.out.println("A matrix-to-matrix test:");
			Thread.sleep(100);
			DecimalNumberMatrix M = DecimalNumberMatrix.randomMatrix(3, 3, 0, 10, true);
			System.out.println("Random matrix:\n\n" + M);
			NumberObject[] testMatrix = RManager.getFunction("test function matrix").runInR(new NumberObject[] {M}) ;
			for (NumberObject o: testMatrix) System.out.println("result: " + o + " (class = " + o.getClass().getSimpleName() + ")");
			
			
			System.out.println("\n\n"+Helper.repString("=", 200)+ "\n");
			System.out.println("A multireturn test:");
			Thread.sleep(100);
			NumberObject[] multireturn = RManager.getFunction("test function multireturn").runInR(new NumberObject[] {M}) ;
			for (NumberObject o: multireturn) System.out.println("result: " + o + " (class = " + o.getClass().getSimpleName() + ")");
			
			System.out.println("\n\n"+Helper.repString("=", 200)+ "\n");
			System.out.println("A container test:");
			Thread.sleep(100);
			RFunctionContainer rfc = new RFunctionContainer(RManager.getFunction("Normal distribution"),
					new AttributeField("domain", new DecimalNumberArray(-1.96,-1,0,1, 1.96)),
					new AttributeField("mean", new DecimalNumber(0)),
					new AttributeField("sd", new DecimalNumber(1)));
			
			System.out.println("Result: " + (DecimalNumberArray) rfc.runInR()[0]);
		
			
			Thread.sleep(1000);
			System.out.println("Test concluded. Shutting it down.");
			RManager.closeConnection();
		} catch (Exception e) {e.printStackTrace();}


	}

}
