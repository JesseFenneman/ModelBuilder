package rIntegration;

import java.io.Serializable;
import java.util.ArrayList;

import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import abstractNumberObjectsAndInterfaces.NumberObject;
import attributes.AttributeField;
import attributes.AttributeField.IncompatibleNumberObjectTypeException;
import interfaces_abstractions.ObserverManager;
import rIntegration.RFunction.IncompleteCallException;
import start.CentralExecutive;

/** A class that holds a 'not-yet-executed' R function. Sometimes
 * its useful to set a function call in a ready-state: everything is
 * set, but we don't need it yet. Rather than already performing the call
 * (and flooding R and our memory), we can store them here for the time being.
 * This class simply contains an RFunction, and the arguments (stored in named
 * AttributeFields).
 *
 * Oh and to make sure we don't run into pesky concurrency issues, we'll make
 * a deep clone of the RFunction. */
public class RFunctionContainer implements Serializable{
	private static final long serialVersionUID = CentralExecutive.programVersion;
	
	/** An Exception that can be thrown if an argument is entered who's name does not match any of the arguments required by the RFunction*/
	@SuppressWarnings("serial")
	public static class UnknownArgumentException extends Exception { public UnknownArgumentException(String message) {     super(message);  }};
	
	
	private RFunction function;
	private ArrayList<AttributeField> arguments;

	public RFunctionContainer (RFunction function, AttributeField... arguments) throws RestrictionViolationException, UnknownArgumentException{
		this.function = new RFunction(function);
		this.arguments = new ArrayList<>();
		for (AttributeField na:arguments)
			this.arguments.add(na);
		checkArgumentValidity();
	}
	
	public RFunctionContainer (RFunction function, ArrayList<AttributeField> arguments) throws RestrictionViolationException, UnknownArgumentException{
		this.function = new RFunction(function);
		this.arguments = arguments;
		checkArgumentValidity();
	}

	/**
	 * Checks whether the loaded arguments are valid. 
	 * 
	 * Specifically, for each loaded argument in this container, this function 
	 * - searches if there is an argument in the RFunction that has that name.
	 * 		- if not, a UnknownArgumentException is thrown.
	 * - sets the FieldRestriction on the loaded argument to match the RFunction's
	 *   restriction for that argument. Might result in a RestrictionViolationException
	 **/
	private void checkArgumentValidity() throws RestrictionViolationException, UnknownArgumentException{
		for (AttributeField filledArgument : arguments){
			boolean matched = false;
			for (AttributeField requiredArgument : function.getInputFieldCopy())
				if (filledArgument.getName().equalsIgnoreCase(requiredArgument.getName())) {
					matched = true;
					filledArgument.setFieldRestriction(requiredArgument.getFieldRestriction());
				}
			if (!matched)
				throw new UnknownArgumentException("Trying to pass an argument with name '"+ filledArgument.getName() + "' to function " + function.getName()+ ". However, this function does not have an argument with that name.");
		}

	}
	/** Returns a deep clone*/
	public RFunctionContainer clone(){
		ArrayList<AttributeField> cloneArray = new ArrayList<>();
		for (AttributeField af: arguments)
			cloneArray.add(af.clone());
		
		try {
			return new RFunctionContainer(function, cloneArray);
		} catch (RestrictionViolationException | UnknownArgumentException e) {
			ObserverManager.notifyObserversOfError(e);
			return null;
		}
	}
	
	/** Adds another argument to the list. Returns false if there already is an argument
	 * with the same name. Does not overwrite this argument. Also checks whether
	 * (a) the new argument is indeed needed by the RFunction (if not, throws
	 * UnknownArgumentException), and (b) whether the new argument matches the 
	 * FieldRestriction set for that argument (if not, throws RestrictionViolationException)
	 * @throws UnknownArgumentException 
	 * @throws RestrictionViolationException */
	public boolean addArgument(AttributeField newArg) throws RestrictionViolationException, UnknownArgumentException{
		for (AttributeField af: this.arguments)
			if (af.getName().toLowerCase().matches(newArg.getName().toLowerCase()))
				return false;
		arguments.add(newArg.clone());
		checkArgumentValidity();
		return true;
		
	}
	
	/** Replaces the argument with the same name as newArg with the newArgs value. Name comparison
	 * is capital insensitive. Returns false if no name exists yet. Also checks whether
	 * (a) the new argument is indeed needed by the RFunction (if not, throws
	 * UnknownArgumentException), and (b) whether the new argument matches the 
	 * FieldRestriction set for that argument (if not, throws RestrictionViolationException)
	 * @throws RestrictionViolationException 
	 * @throws IncompatibleNumberObjectTypeException 
	 * @throws UnknownArgumentException */
	public boolean replaceArgument(AttributeField newArg) throws IncompatibleNumberObjectTypeException, RestrictionViolationException, UnknownArgumentException{
		AttributeField existingAF = null;
		for (AttributeField af: this.arguments)
			if (af.getName().toLowerCase().matches(newArg.getName().toLowerCase()))
				existingAF = af;
		if (existingAF == null)
			return false;
		existingAF.setValue(newArg.getValueCopy());
		
		checkArgumentValidity();
		return true;
		
	}
	
	/** If there is an argument with the same name as newArg, replace the value of that argument with the newArgs value. 
	 * Otherwise, add an argument with this name and value. Also checks whether
	 * (a) the new argument is indeed needed by the RFunction (if not, throws
	 * UnknownArgumentException), and (b) whether the new argument matches the 
	 * FieldRestriction set for that argument (if not, throws RestrictionViolationException)
	 * @throws UnknownArgumentException */
	public void replaceOrAddArgument(AttributeField newArg) throws IncompatibleNumberObjectTypeException, RestrictionViolationException, UnknownArgumentException{
		AttributeField existingAF = null;
		for (AttributeField af: this.arguments)
			if (af.getName().toLowerCase().matches(newArg.getName().toLowerCase()))
				existingAF = af;
		if (existingAF != null)
			existingAF.setValue(newArg.getValueCopy());
		else
			arguments.add(newArg.clone());
		
		checkArgumentValidity();

	}
	
	/** Performs a function call to R to the function stored in this container, using the
	 * arguments provided in this container. For convenience, arguments are matched by name -
	 * the order provided in this container does not matter. Throws a IncompleteCallException
	 * if there are missing arguments.
	 * @throws RestrictionViolationException
	 * @throws REXPMismatchException
	 * @throws REngineException
	 * @throws IncompatibleNumberObjectTypeException */
	public NumberObject[] runInR() throws IncompleteCallException, IncompatibleNumberObjectTypeException, REngineException, REXPMismatchException, RestrictionViolationException {
		String[] requiredArguments = function.getOrderOfArguments();
		NumberObject[] args = new NumberObject[requiredArguments.length];

		for (int i = 0; i < requiredArguments.length; i++){

			// Try to match the required name to an argument
			for (AttributeField af: arguments){
					if (af.getName().equalsIgnoreCase(requiredArguments[i])){
					args[i] = af.getValueCopy();
				}
			}

			// Is there a match? If not, we have an issue...
			if (args[i] == null)
				throw new IncompleteCallException("Cannot perform function call in R, missing following argument: " + requiredArguments[i]);

		}
		return function.runInR(args);
	}

	/** Returns an array of AttributeFields that contain the arguments that this container is loaded with.
	 * If runInR() is called, JAVA will send a function call to R with these arguments.*/
	public ArrayList<AttributeField> getLoadedArguments() {return this.arguments;}

	/** Get the function that this container will use. Note that this container's function
	 * is a deep clone of the original function - the objects will not compare directly!*/
	public RFunction getRFunction(){return function;}
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append(function.getName()+"(");
		for (int i = 0; i < arguments.size(); i++)
			if (i < arguments.size()-1)
				sb.append(arguments.get(i).getName() + "="+arguments.get(i).getValueStringWithoutTrailingZeros()+ ", ");
			else
				sb.append(arguments.get(i).getName() + "="+arguments.get(i).getValueStringWithoutTrailingZeros());
		sb.append(")");
		
		return sb.toString();
	}
	
	/** Prints the RFunctionContainer, omitting all the attribute fields that have a name matching an 
	 * entry in the omit list. Names are compared ignoring case.*/
	public String toStringOmitting(String... omit){
		StringBuilder sb = new StringBuilder();
		sb.append(function.getName()+"(");
		ArrayList<AttributeField> printList = new ArrayList<>();
		for (AttributeField af: this.arguments) {
			boolean inOmitList = false;
			for (String s: omit)
				if (af.getName().equalsIgnoreCase(s))
					inOmitList = true;
			if (!inOmitList)
				printList.add(af);
		}
		
		
		for (int i = 0; i < printList.size(); i++)
			if (i < printList.size()-1)
				sb.append(printList.get(i).getName() + "="+printList.get(i).getValueStringWithoutTrailingZeros()+ ", ");
			else
				sb.append(printList.get(i).getName() + "="+printList.get(i).getValueStringWithoutTrailingZeros());
		sb.append(")");
		
		return sb.toString();
	}
}
