package rIntegration;

/** A RParsable object has a toRParsableString() function that provides a string that RManager can use to
 * read in this object in R. That is, it should provide R readable code*/
public interface RParsable {
	
		
	/** Returns this object in a String that R can read. In R this object is stored
	 * under the name nameInR. The return is not stored in R. */
	public String toRParsableString();

}
