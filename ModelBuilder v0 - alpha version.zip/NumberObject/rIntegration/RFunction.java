package rIntegration;

import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPDouble;
import org.rosuda.REngine.REXPGenericVector;
import org.rosuda.REngine.REXPInteger;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.RList;

import abstractNumberObjectsAndInterfaces.FieldRestriction;
import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectMatrix;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import attributes.AttributeField;
import attributes.AttributeField.IncompatibleNumberObjectTypeException;
import decimalNumber.DecimalNumber;
import decimalNumber.DecimalNumberArray;
import decimalNumber.DecimalNumberMatrix;
import interfaces_abstractions.ObserverManager;
import start.CentralExecutive;
import start.Console;

public class RFunction implements Serializable {
	private static final long serialVersionUID = CentralExecutive.programVersion;

	private String name;// The name in JAVA
	private String nameInR; // How to call this function in R
	private final ArrayList<String> tags;
	private final ArrayList<AttributeField> inputs;
	private final ArrayList<AttributeField> results;

	@SuppressWarnings("serial")
	public static class IncompleteCallException extends RuntimeException { public IncompleteCallException(String message) { 	 super(message);  }};


	// If true, uses System.out.println to show all steps
	private final static boolean DEBUG_MODE = false;

	public RFunction(String pathToDotRFile) throws IOException {
		inputs = new ArrayList<>();
		results = new ArrayList<>();
		tags = new ArrayList<>();

		// Create a Scanner that reads in the file line by line, and send each line to the parseLine function.
		if (DEBUG_MODE)Console.print("Parsing .r file: : " + pathToDotRFile);
		Path p = Paths.get(pathToDotRFile);
		Scanner sc = new Scanner(p);

		while(sc.hasNextLine())
			parseLine(sc.nextLine());
		sc.close();

		// Check if there is a custom name. If not, use the function name in R as the name in JAVA
		if (name==null)
			name = nameInR;
	}

	/** Copy constructor. Sometimes making a copy is useful to avoid concurrency issues. */
	public RFunction(RFunction original){
		this.name = original.name;
		this.nameInR = original.nameInR;

		this.tags = new ArrayList<>();
		for (String s: original.tags)
			this.tags.add(s);

		this.inputs = new ArrayList<>();
		for (AttributeField af: original.inputs)
			this.inputs.add(af.clone());

		this.results = new ArrayList<>();
		for (AttributeField af: original.results)
			this.results.add(af.clone());
	}

	/** Processes a line from a .r file. A line is parsed only if it contains a "<>". Only the text after the <> is parsed. From this line a name, parameter, or return value is extracted*/
	private void parseLine(String line) {
		if (DEBUG_MODE) Console.print("Parsing line: "+line);

		// Check if the line contains something to parse. This is indicated by the line having a <> symbol
		if (!line.contains("<>")) {

			// First, Check for the function name. This is the name that R uses, and does not necessarily have to
			// be the same as the name in the name tag. In R, this is the text: [FUNCTION_NAME] = function()
			if(line.replace("\"", "\'").matches("^\\s*[a-zA-Z0-9_]+\\s*=\\s*function.*")){
				Matcher m = Pattern.compile("([a-zA-Z0-9_]+)\\s*=").matcher(line);
				m.find();
				nameInR = m.group(1);
				if (DEBUG_MODE) Console.print("\t-Parsing as FUNCTION NAME: " + nameInR);
				return;
			}

			/// If the line does not contain a <> and does not contain the function name, there is nothing to do here
			else {
				if (DEBUG_MODE) Console.print("\t No parsable code found");
				return ;
			}
		}

		// Make sure that there is, at most, one <> (or at the very least, that there is no text after all further <>'s)
		if (line.split("<>").length != 2) {
			if (DEBUG_MODE) Console.printError("\tCannot parse line: too many <>'s");
			return ;
		}
		line = line.split("<>")[1];

		// Check if the keyword "parameter" or "argument" is the start of the line (note: we start with PARAMETER because PARAMETER has a NAME field. If we first do
		// PARAMETER, and then the NAME keyword, we never have to worry whether a NAME refers to the PARAMETER NAME or the function NAME
		// Regex: any number of spaces, plus the keyword PARAMETER or ARGUMENT, plus any number of space, plus a ( plus any number of anything plus a )
		if(line.toLowerCase().matches("\\s*(parameter|argument)\\s*\\(.*\\)") || line.toLowerCase().matches("\\s*argument\\s*\\(.*\\)")){
			if (DEBUG_MODE) Console.print("\t-Parsing as PARAMETER");
			// Everything in parentheses goes to the argument parser
			Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(line);
			while(m.find())
				inputs.add(parseArguments(m.group(1), null));

		}

		// Check if the keyword "tag" or "flag" is the start of the line
		// Regex: any number of spaces, plus the keyword TAG or FLAG, plus any number of space, plus a '='
		else if(line.toLowerCase().matches("\\s*(tag|flag)\\s*=.*")){
			if (DEBUG_MODE) Console.print("\t-Parsing as TAG");
			// Everything in ''s goes to the argument parser
			Matcher m = Pattern.compile("'([^']+)'").matcher(line);
			m.find();
			String tag = m.group(1).toLowerCase();
			if (DEBUG_MODE) Console.print("\t-Found tag: |" + tag + "|");
			tags.add(tag);
		}



		// Check if the keyword "result" or "return" is the start of the line
		// Regex: any number of spaces, plus the keyword result or results, plus any number of space, plus a ( plus any number of anything plus a )
		else if(line.toLowerCase().matches("\\s*(result|return)\\s*\\(.*\\)") ){
			if (DEBUG_MODE) Console.print("\t-Parsing as RESULT");
			// Everything in parentheses goes to the argument parser
			Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(line);
			while(m.find())
				results.add(parseArguments(m.group(1), "Result"));

		}
		// Check for a name tag
		else if(line.replace("\"", "\'").toLowerCase().matches("\\s*(name|title)\\s*=\\s*('.*')")){
			Matcher m = Pattern.compile("'([^']+)'").matcher(line);
			m.find();
			this.name = m.group(1);
			if (DEBUG_MODE) Console.print("\t-Parsing as NAME: " + name);
		}

		else {
			if (DEBUG_MODE) Console.print("ERROR: Could not parse as anything. Something went wrong. Line: ||" + line + "||");
		}

	}

	/** Arguments often come in the form: function(argument1 = value1; argument2 = value2, argument3 = value3). Note that both ; and , are valid separators.
	 * This function takes a string of arguments (here the full string "argument1 = value1; argument2 = value2, argument3 = value3" and returns a
	 * GenericParameter object with the name, a number of valued and named arguments, an optional ValidInput, and an optional description.
	 *
	 * If the name String is left null, no name will be parsed. Rather, the provided string is used as a name. This is used when the argument
	 * to be parsed is a RESULT rather than a PARAMETER/ARGUMENT
	 * @param s
	 */
	private AttributeField parseArguments(String s, String name) {
		if (DEBUG_MODE) Console.print("\t-Attempting to parse: '" + s +"' into a GenericParameter object.");

		if (name == "")
			name = null;

		String argumentName = name;
		Class<? extends NumberObject> dimension = DecimalNumber.class;;
		FieldRestriction type = FieldRestriction.NO_RESTRICTIONS;
		String description= "";

		// replace all other possible separator signs with a comma:
		s=s.replace(':', ',');
		s=s.replace(";", ",");

		// Split on comma's - that will give us an array of elements to parse further
		String[] argumentElements = s.split(",");

		// Iterate over these splits, and find out the name, dimension, validinput, and notes
		for (String el: argumentElements) {
			if (DEBUG_MODE)Console.print("\t\t-Parsing element: "+el);

			// Check if there is precisely one = sign
			if (el.length() - el.replace("=", "").length() != 1) {
				if (DEBUG_MODE) Console.print("\t\tCannot parse line: more than one = sign");
				return null;
			}

			// Split on the = sign
			String lhs = el.split("=")[0].replace(" ", "").toLowerCase(); //left hand side
			String rhs = el.split("=")[1]; // right hand side

			// If the left hand side is "name":
			if (lhs.equals("name") && argumentName == null) {
				argumentName = rhs.replace(" ", "").replace("\"", "").replace("'", "");
				if (DEBUG_MODE) Console.print("\t\t\tRecognized name: " + argumentName);
			}

			// If the left hand side is "dim", "dimension", "dimensions", or "dimensionality" (I'm not picky):
			if (lhs.equals("dim") || lhs.equals("dimension")|| lhs.equals( "dimensions")|| lhs.equals( "dimensionality")) {
				String rhsClean = rhs.replace(" ", "").toLowerCase();
				rhsClean = rhsClean.replace("\"", "");
				rhsClean = rhsClean.replace("'", "");

				if (rhsClean.equals("single")||rhsClean.equals( "numeric")||rhsClean.equals("number"))
					dimension = NumberObjectSingle.class;
				else if (rhsClean.equals("array")||rhsClean.equals("vector")||rhsClean.equals("range"))
					dimension = NumberObjectArray.class;
				else if (rhsClean.equals("matrix"))
					dimension = NumberObjectMatrix.class;
				else {
					if (DEBUG_MODE)Console.printError("\t\t\tCannot parse line: recognized as dimension, but no valid dimensionality detected. Right hand side: " + rhsClean + ". Using the default single DecimalNumber");
				}

				if (DEBUG_MODE)Console.print("\t\t\tRecognized as a dimension: " + dimension);
			}

			// If the left hand side is "validInput", "inputType", "Type", "Restriction", or "Restrictions" (note that the LHS is always set to lower capitals already):
			if (lhs.equals("validinput") || lhs.equals("inputtype")||lhs.equals("type")|| lhs.equals("restriction")|| lhs.equals( "restrictions")) {
				String rhsClean = rhs.replace(" ", "").toUpperCase();
				rhsClean = rhsClean.replace("\"", "");
				rhsClean = rhsClean.replace("'", "");

				// Figure out if there is a corresponding FieldType with a name that equals the cleaned right hand side:
				try {
					type = FieldRestriction.valueOf(rhsClean);
					if (DEBUG_MODE) Console.print("\t\t\tRecognized as a type: " + type);
				} catch (Exception e) {
					if (DEBUG_MODE) Console.printError("\t\t\tCannot parse line: recognized as type, but no valid type detected. Right hand side: " + rhsClean + ". Using the default no restrictions");
				}
			}

			// If the left hand side is "description", "note", "notes", "explanation", or "text"(note that the LHS is always set to lower capitals already):
			if (lhs.equals("description") || lhs.equals("note")||lhs.equals("notes")|| lhs.equals("text")|| lhs.equals( "explanation")) {
				description = rhs.trim().replace("\"", "").replace("'", "");
				if (DEBUG_MODE)Console.print("\t\t\tRecognized as a description: " + description);
			}
		}

		AttributeField af = null;
		try {
			af = new AttributeField(argumentName, type, dimension);
			af.setDescription(description);
		} catch (RestrictionViolationException e) { ObserverManager.notifyObserversOfError(e);		}


		if (DEBUG_MODE) Console.print("\t-SUCCES: Created an argument with the following GenericParameter: " + af.getDescription() );
		return af;
	}

	/** Prints a textual description of the function, function name in R, inputs, results, and optional tags */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("A RFunction with the name '" + name + "'.");

		if (tags.size()>0){
			sb.append("\nThis function is tagged as:");
			for (String s: tags)
				sb.append(" '" + s + "'");
		}

		sb.append("\nThis function has " + inputs.size() +" arguments:");

		for (AttributeField input: inputs) {
			sb.append("\n\t-"+ input.getName() + ". An input field (a " + input.getClassRestriction().getSimpleName()+ ") that only allows " + (input.getFieldRestriction()).toString().toLowerCase().replace("_", " ")+ " values. ");
			if (input.getDescription() != null)
				if (input.getDescription() != "")
					sb.append( "Description: " + input.getDescription());
		}
		sb.append("\nAnd has " + results.size() + " results: ");
		for (AttributeField result: results) {
			sb.append("\n\t-A result (a " + result.getClassRestriction().getSimpleName() + ") that will only contain " +  (result.getFieldRestriction()).toString().toLowerCase().replace("_", " ")+ " values. ");
			if (result.getDescription() != null)
				if (result.getDescription() != "")
					sb.append( "Description: " + result.getDescription());
		}

		if (!name.equals(nameInR))
			sb.append("\n(Note: in R this function is called: \'" + nameInR + "\')");
		return sb.toString();
	}

	/** Return the name specified by the user in the .R file*/
	public String getName() {
		return this.name;
	}

	/** Returns the function name in R. This is the name that R uses to place the function call.*/
	public String getNameInR() {
		return this.nameInR;
	}

	/** Get a copy of the inputs. Useful for checking which arguments goes in which order*/
	public ArrayList<AttributeField> getInputFieldCopy(){
		ArrayList<AttributeField> inputClone = new ArrayList<>();
		for (AttributeField af: inputs) inputClone.add(af.clone());
		return inputs;
	}

	/** Get a copy of the tags.*/
	public ArrayList<String> getTagsCopy(){
		ArrayList<String> tagClone = new ArrayList<>();
		for (String s: tags) tagClone.add(s);
		return tagClone;
	}

	/** Provides an array of argument names, which has the same order as the required inputs*/
	public String[] getOrderOfArguments(){
		String[] inputNames = new String[inputs.size()];
		for (int i = 0; i< inputs.size(); i++)
			inputNames[i] = inputs.get(i).getName();
		return inputNames;

	}
	/** Execute a call in R to the function using args. Returns the result.
	 * @throws RestrictionViolationException If there is at least one input that does not match the specified dimensionality (single, vector, matrix)
	 * @throws IncompatibleNumberObjectTypeException if there is at least one input that does not match the restriction (double, probability, etc) */
	public NumberObject[] runInR(NumberObject[] args ) throws REngineException, REXPMismatchException, IncompatibleNumberObjectTypeException, RestrictionViolationException {
		// Make sure that the input is valid
		validateInput(args);

		// Make a string that we can send to R
		String functionCall = toRFunctionCall(args);

		// Execute the command via RManager, and get the result from R
		REXP result = RManager.evaluate(functionCall);

		// Parse the result
		return parseREXPToOutput(result);
	}

	/** Tests whether the classes of the args NumberObjects match the classes specified in inputs - that is, if the arguments are indeed a valid input for this function.
	 * Throws an IllegalArgumentException if the number of arguments in args does not match the number of arguments required by the function.
	 * Throws an IllegalArgumentException if the class of at least one argument does not match the class required by the function (e.g.,
	 * when using a matrix where a number is required).
	 * Throws an IllegalArgumentException if there is at least one argument that does not match the required fieldtype conditions. This sounds
	 * abstract, but it just means that if a function argument sets some restrictions, these restrictions have to be followed when calling this
	 * function. For instance, its not OK to ask for a normal distribution with a negative standard deviation.
	 * @throws RestrictionViolationException If there is at least one input that does not match the specified dimensionality (single, vector, matrix)
	 * @throws IncompatibleNumberObjectTypeException if there is at least one input that does not match the restriction (double, probability, etc) */
	private void validateInput(NumberObject[] args) throws IncompatibleNumberObjectTypeException, RestrictionViolationException {
		// Check if the number of arguments specified matches the number of arguments required
		if (args.length != inputs.size())
			throw new IllegalArgumentException("Trying to call a RFunction with " + args.length +" arguments. However, this RFunction requires exactly " + inputs.size() + " arguments. ");

		// Set all the input fields
		for (int i = 0; i < inputs.size(); i ++ )
			inputs.get(i).setValue(args[i]);

		// Check if all values in all inputs are not null
		for (AttributeField arg:inputs) {
			// Check if the field value is an actual null
			if (arg.getValueCopy()== null)
				throw new IllegalStateException("Trying to parse a RFunction to R. However, at least one field is not set. Please use setArgument() before using toRParsableString(). ");

		}
	}

	/** Returns a String that consists of a function call in R. This typically has the following form:
	 * functionNameInR(argument1 = value1, argument2=value2, ...). Note that by default the result is
	 * not stored in a variable in R*/
	private String toRFunctionCall(NumberObject[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append(this.nameInR+"(" );
		for (int i=0; i < inputs.size(); i ++) {
			AttributeField arg = inputs.get(i);
			sb.append(arg.getName() + " = " + arg.getValueCopy().toRParsableString());
			if (i < (inputs.size()-1))
				sb.append(", ");
		}
		sb.append(")");
		return sb.toString();
	}

	private NumberObject[] parseREXPToOutput(REXP result) throws REXPMismatchException {
		// If this function expects no returns, we only have to return a null object
		if (results.size() == 0)
			return null;

		//Make a list of NumberObjects in which we will store the parsed results
		NumberObject[] objects = new NumberObject[results.size()];

		// If this function expects only one return, the REXP has to be parsed to that return
		if (results.size() == 1) {

			// Figure out what the class of the result should be, 'cast' the REXP object to that class, and return that result
			if (results.get(0).getClassRestriction() == NumberObjectSingle.class)
				return new NumberObject[] { new DecimalNumber(result.asDouble())};

			if (results.get(0).getClassRestriction() == NumberObjectArray.class)
				return new NumberObject[] { new DecimalNumberArray(result.asDoubles())};

			if (results.get(0).getClassRestriction() == NumberObjectMatrix.class)
				return new NumberObject[] { RManager.REXPtoDecimalNumberMatrix(result) };

			throw new IllegalArgumentException("REXP-to-R object not supported yet");


			// If there are more returns:
		} else if (results.size() >1){
			RList list = result.asList();

			// For each element in the REXP list:
			for (int i = 0; i < list.capacity(); i++) {
				Object el = list.get(i);
				if (el.getClass() == REXPDouble.class || el.getClass() == REXPInteger.class) {// if it is either a single value or array:
					objects[i] = parseAsNumberObject(el);
				} else if (el.getClass() == REXPGenericVector.class) { //Data frame
					objects[i] = RManager.GenericVectorToDecimalNumberMatrix((REXPGenericVector) el);
				} else {
					throw new IllegalStateException("R returned something that JAVA cannot (yet) parse. ");
				}

			}
		} else {
			return null;
		}
		return objects;
	}

	/** R serve does not inform the user when something is a single value, array or matrix. Moreover, it seems to treat integers and doubles separately (at
	 * least, the casting to other objects does not go as planned. This function gives takes either a REXPInteger or REXPMatrix, and returns either
	 * a DecimalNumber (if there is only one numeric value) a DecimalNumberArray (if there is only a single array), or a DecimalNumberMatrix */
	private NumberObject parseAsNumberObject(Object el) {
		if (el.getClass() == REXPDouble.class) {
			// try to parse it as a matrix
			try {
				DecimalNumberMatrix m =  new DecimalNumberMatrix(((REXPDouble) el).asDoubleMatrix());
				return m;

				// Not a matrix? Parse it as an array:
			} catch (REXPMismatchException e) {
				DecimalNumberArray a =  new DecimalNumberArray(((REXPDouble) el).asDoubles());
				if (a.size() > 1 )
					return a;

				// Only 1 element? its a single numeric value!
				if (a.size() == 1)
					return a.get(0);

				if (a.size()< 1)
					throw new IllegalStateException("Trying to parse a REXPDouble as a numeric value. But there are no numeric elements.");
			}
		} else if (el.getClass() == REXPInteger.class) {
			// try to parse it as a matrix
			try {
				DecimalNumberMatrix m =  new DecimalNumberMatrix(((REXPInteger) el).asDoubleMatrix());
				return m;

				// Not a matrix? Parse it as an array:
			} catch (REXPMismatchException e) {
				DecimalNumberArray a =  new DecimalNumberArray(((REXPInteger) el).asDoubles());
				if (a.size() > 1 )
					return a;

				// Only 1 element? its a single numeric value!
				if (a.size() == 1)
					return a.get(0);

				if (a.size()< 1)
					throw new IllegalStateException("Trying to parse a REXPInteger as a numeric value. But there are no numeric elements.");
			}
		}

		throw new IllegalArgumentException("Can only pase REXPDouble or REXPInteger values as numeric");
	}

}
