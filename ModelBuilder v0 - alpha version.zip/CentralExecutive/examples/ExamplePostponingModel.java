package examples;

import java.util.ArrayList;

import actionElements.ActionTemplate;
import actionElements.ActionTemplatePostcondition;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateConsumeResource;
import actionElements.ActionTemplatePostcondition.PostconditionTemplatePostponeWithInterruption;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateSearch;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateTerminateEncounter;
import actionElements.ActionTemplatePrecondition;
import actionElements.ActionTemplatePrecondition.Operator;
import actionElements.ActionTemplatePreconditionResourceEncountered;
import actionElements.ActionTemplatePreconditionTimeLife;
import attributes.AttributeField;
import deathConditionElements.DeathConditionTemplate;
import decimalNumber.DecimalNumber;
import mutationElements.ObjectMutationTemplate;
import mutationElements.PhenotypeMutationTemplate;
import objectiveElements.AbstractObjectiveTemplateFactory;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.ExtrinsicObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import rIntegration.RFunction;
import rIntegration.RFunctionContainer;
import rIntegration.RManager;
import view.View;

/** Example 1; a rather weird model for testing purposes*/
public class ExamplePostponingModel extends Example{
	
	public ExamplePostponingModel() {
		this.fillWorkspace();
	}
	
	@Override
	public void fillWorkspace(){
		try{
			int maximumDelay = 5;
			int maximumAge = 20;
			
			// Create all the distributions that we'll use in this model
			RFunction normal = null;
			RFunction bernoulli = null;
			for (RFunction rf: RManager.getAllRFunctionsWithTag("DOMAINFUNCTION"))
				if (rf.getName().equalsIgnoreCase("Normal distribution integer only"))
					normal = rf;
				else if (rf.getName().equals("Bernoulli distribution"))
					bernoulli = rf;
	
			// Set maximum life time
			View.getView().workspace.setMaximumLifeTime(maximumAge);
			
			// Maximum cycle time
			View.getView().workspace.setMaximumCycleTime(maximumDelay+1);
			
			// PHENOTYPE: reserves
			AbstractObjectiveTemplateFactory factoryReserves = new AbstractObjectiveTemplateFactory();
			factoryReserves.setName("Reserves")
			.setType(PhenotypeObjectTemplate.class)
			.setRange(new DecimalNumber(0), new DecimalNumber(100), new DecimalNumber(0.1));
			View.getView().addObject(factoryReserves.build());
			
			// RESOURCE: resource
			// Create the arguments for the sampling distribution ranges
			ArrayList<AttributeField[]> argumentsForResourceDistributions = new ArrayList<>();
			// Add the minimum, maximum, and stepsize for the mean
			argumentsForResourceDistributions.add(new AttributeField[] { 
					new AttributeField("minimum", new DecimalNumber(-5)),
					new AttributeField("maximum", new DecimalNumber( 5)),
					new AttributeField("stepsize", new DecimalNumber( 10))});
			// Add the minimum, maximum, and stepsize for the sd
			argumentsForResourceDistributions.add(new AttributeField[] { 
					new AttributeField("minimum",  new DecimalNumber(0)),
					new AttributeField("maximum",  new DecimalNumber(8)),
					new AttributeField("stepsize", new DecimalNumber(8))});
			
			AbstractObjectiveTemplateFactory factoryResource = new AbstractObjectiveTemplateFactory();
			factoryResource.setName("Resource")
			.setType(ResourceObjectTemplate.class)
			.setFrequency(new DecimalNumber(1))
			.setRange(new DecimalNumber(-10), new DecimalNumber(10), new DecimalNumber(0.1))
			.setObservability(true)
			//.setMultipleSamplingDistributions(normal, argumentsForResourceDistributions);
			.setSingleSamplingDistribution(new RFunctionContainer(normal,  new AttributeField[]{ new AttributeField("mean", new DecimalNumber(0)), new AttributeField("sd", new DecimalNumber(2))}));
			View.getView().addObject(factoryResource.build());
		
			
			// INTERRUPTION
			// Create the arguments for the sampling distribution ranges
			ArrayList<AttributeField[]> argumentsForInterruptionDistributions = new ArrayList<>();
			// Add the minimum, maximum, and stepsize for the mean
			argumentsForInterruptionDistributions.add(new AttributeField[] { 
					new AttributeField("minimum", new DecimalNumber(0)),
					new AttributeField("maximum", new DecimalNumber(0.5)),
					new AttributeField("stepsize", new DecimalNumber(0.5))});
			AbstractObjectiveTemplateFactory factoryINT = new AbstractObjectiveTemplateFactory();
			factoryINT.setName("Interruption")
			.setType(InterruptionObjectTemplate.class)
			.setSingleSamplingDistribution(new RFunctionContainer(bernoulli, new AttributeField[] { new AttributeField("pr_x_equals_0", new DecimalNumber(0.9))}))
			//.setMultipleSamplingDistributions(bernoulli, argumentsForInterruptionDistributions)
			.setObservability(false);
			View.getView().addObject(factoryINT.build());


			// EXTRINSIC
			// Create the arguments for the sampling distribution ranges
			ArrayList<AttributeField[]> argumentsForExtrinsicDistributions = new ArrayList<>();
			// Add the minimum, maximum, and stepsize for the mean
			argumentsForExtrinsicDistributions.add(new AttributeField[] { 
					new AttributeField("minimum", new DecimalNumber(-2)),
					new AttributeField("maximum", new DecimalNumber( 2)),
					new AttributeField("stepsize", new DecimalNumber( 1))});
			// Add the minimum, maximum, and stepsize for the sd
			argumentsForExtrinsicDistributions.add(new AttributeField[] { 
					new AttributeField("minimum", new DecimalNumber(0)),
					new AttributeField("maximum", new DecimalNumber(4)),
					new AttributeField("stepsize", new DecimalNumber(4))});
						
			AbstractObjectiveTemplateFactory factoryEX = new AbstractObjectiveTemplateFactory();
			factoryEX.setName("Extrinsic")
			.setType(ExtrinsicObjectTemplate.class)
			.setRange(new DecimalNumber(-2), new DecimalNumber(2), new DecimalNumber(1))
			.setObservability(true)
			.setSingleSamplingDistribution(new RFunctionContainer(normal,  new AttributeField[]{ new AttributeField("mean", new DecimalNumber(0)), new AttributeField("sd", new DecimalNumber(2))}))
			//.setMultipleSamplingDistributions(normal, argumentsForExtrinsicDistributions)
			.setFrequency(new DecimalNumber(1));
			View.getView().addObject(factoryEX.build());

			// DELAYS: 1 to maximumDelay, known and constant
			AbstractObjectiveTemplateFactory factoryDLY = new AbstractObjectiveTemplateFactory();
			for (int i = 1; i <= maximumDelay; i++ ) {
				factoryDLY.setName("Delay" + i)
				.setType(DelayObjectTemplate.class)
				.setConstant(new DecimalNumber(i))
				.setFrequency(new DecimalNumber(1));
				View.getView().addObject(factoryDLY.build());
			}
			
			//// T1 Actions
			// Search
			ActionTemplate searchAction = new ActionTemplate(ActionTemplate.ActionType.BETWEEN_ENCOUNTERS, "Search");
			searchAction.addPostcondition(new PostconditionTemplateSearch());
			View.getView().workspace.addAction(searchAction);
			
		

			/////////////// T2Actions
			/// consumeSS
			ActionTemplatePrecondition resourcePresent = new ActionTemplatePreconditionResourceEncountered();
			resourcePresent.setSubject(View.getView().workspace.getObject("Resource"));
			resourcePresent.setOperator(Operator.TRUE);
			
			ActionTemplate consume = new ActionTemplate(ActionTemplate.ActionType.DURING_ENCOUNTER, "consume");
			consume.addPrecondition(resourcePresent);
			
			ActionTemplatePostcondition consumeSSPC = new PostconditionTemplateConsumeResource();
			consumeSSPC.setSubject(View.getView().workspace.getObject("Resource"));
			consumeSSPC.setQualifier(View.getView().workspace.getObject("Reserves"));
			consume.addPostcondition(consumeSSPC);
			ActionTemplatePostcondition terminate = new PostconditionTemplateTerminateEncounter();
			consume.addPostcondition(terminate);
			View.getView().workspace.addAction(consume);

			
			// All postponing actions
			for (int i = 1; i <= maximumDelay; i++ ) {
				ActionTemplate postpone = new ActionTemplate(ActionTemplate.ActionType.DURING_ENCOUNTER, "Postpone" + i);
				
				ActionTemplatePrecondition postponePreAge = ActionTemplatePrecondition.createPreconditionTemplate(
						ActionTemplatePreconditionTimeLife.class);
				postponePreAge.setOperator(Operator.SMALLER_THAN);
				postponePreAge.setTarget(maximumAge - i);
				postpone.addPrecondition(postponePreAge);
				
				ActionTemplatePostcondition postponePC = new PostconditionTemplatePostponeWithInterruption();
				postponePC.setSubject(View.getView().workspace.getObject("Delay" + i));
				postponePC.setQualifier(View.getView().workspace.getObject("Interruption"));
				postpone.addPostcondition(postponePC);
				
				ActionTemplatePostcondition consumeAfterDelay = new PostconditionTemplateConsumeResource();
				consumeAfterDelay.setSubject(View.getView().workspace.getObject("Resource"));
				consumeAfterDelay.setQualifier(View.getView().workspace.getObject("Reserves"));
				postpone.addPostcondition(consumeAfterDelay);
				
				ActionTemplatePostcondition terminate2 = new PostconditionTemplateTerminateEncounter();
				postpone.addPostcondition(terminate2);
				
				View.getView().workspace.addAction(postpone);
			}
			
			// Mutation: extrinsics affect phenotype
			PhenotypeObjectTemplate p = (PhenotypeObjectTemplate) View.getView().workspace.getObject("Reserves");
			ExtrinsicObjectTemplate e = (ExtrinsicObjectTemplate) View.getView().workspace.getObject("Extrinsic");
			PhenotypeMutationTemplate mutationTemplate = new PhenotypeMutationTemplate(p,e);
			View.getView().workspace.addPhenotypeMutation(mutationTemplate);
			
			// Mutation: each time step postponing, the resource increases linearly until it doubles after 10 time steps
			ObjectMutationTemplate resourceChange = ObjectMutationTemplate.createDoubleLinearObjectMutation(
					View.getView().workspace.getObject("Resource"), new DecimalNumber(10));
			View.getView().workspace.addObjectMutation(resourceChange);
			
			// Death: an agent dies if its reserves are 0
			DeathConditionTemplate deathTemplate = new DeathConditionTemplate((PhenotypeObjectTemplate) View.getView().workspace.getObject("Reserves"), DeathConditionTemplate.Operator.SMALLER_OR_EQUAL_THAN, new DecimalNumber(0));
			View.getView().workspace.addDeathCondition(deathTemplate);
			
			// Fitness function: identical to phenotype
			RFunction fitnessFunction = null;
			for (RFunction rf: RManager.getAllRFunctionsWithTag("FITNESSFUNCTION")) 
				if (rf.getName().equals("identity"))
					fitnessFunction = rf;
			
			PhenotypeObjectTemplate age = (PhenotypeObjectTemplate) View.getView().workspace.getObject("Age");
			PhenotypeObjectTemplate[] args = new PhenotypeObjectTemplate[]{p};
			View.getView().workspace.setUseFitnessFunctionBeforeMaximumAge(true);
			View.getView().workspace.setFitnessFunction(fitnessFunction, args);
			View.getView().workspace.setFitnessDeath(new DecimalNumber(0));
			
			//View.getView().workspace.setFitnessFunction(fitnessFunction, args);
			
		} catch (Exception e) {e.printStackTrace();}
		
	}

}
