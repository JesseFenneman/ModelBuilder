package examples;

import actionElements.ActionTemplate;
import actionElements.ActionTemplatePostcondition;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateConsumeResource;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateSearch;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateTerminateEncounter;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateWaitBetween;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateWaitDuring;
import actionElements.ActionTemplatePrecondition;
import actionElements.ActionTemplatePrecondition.Operator;
import attributes.AttributeField;
import actionElements.ActionTemplatePreconditionResourceEncountered;
import deathConditionElements.DeathConditionTemplate;
import decimalNumber.DecimalNumber;
import objectiveElements.AbstractObjectiveTemplateFactory;
import objectiveElements.CueTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.PhenotypeObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import rIntegration.RFunction;
import rIntegration.RFunctionContainer;
import rIntegration.RManager;
import view.View;

/** Example 1; a rather weird model for testing purposes*/
public class ExampleSuperSimple extends Example{
	
	public ExampleSuperSimple() {
		this.fillWorkspace();
	}
	
	@Override
	public void fillWorkspace(){
		try{
			// Create all the distributions that we'll use in this example
			RFunction normal = null;
			RFunction uniform = null;
			RFunction bernoulli = null;
			RFunction highPass = null;
			for (RFunction rf: RManager.getAllRFunctionsWithTag("DOMAINFUNCTION"))
				if (rf.getName().equalsIgnoreCase("Normal distribution"))
					normal = rf;
				else if (rf.getName().equals("Uniform distribution"))
					uniform = rf;
				else if (rf.getName().equals("Bernoulli distribution"))
					bernoulli = rf;
				else if (rf.getName().equals("High pass uniform distribution"))
					highPass = rf;
			
			// Create the cue templates
			CueTemplate cue = new CueTemplate();
			
			// Set maximum life time
			View.getView().workspace.setMaximumLifeTime(10);
			
			// Maximum cycle time
			View.getView().workspace.setMaximumCycleTime(10);
			
			// PHENOTYPE
			AbstractObjectiveTemplateFactory factoryPHN = new AbstractObjectiveTemplateFactory();
			factoryPHN.setName("PHNTP")
			.setType(PhenotypeObjectTemplate.class)
			.setRange(new DecimalNumber(0), new DecimalNumber(10), new DecimalNumber(0.1));
			View.getView().addObject(factoryPHN.build());
			
			// RESOURCES: SS
			AbstractObjectiveTemplateFactory factorySS = new AbstractObjectiveTemplateFactory();
			factorySS.setName("RSC-SS")
			.setType(ResourceObjectTemplate.class)
			.setFrequency(new DecimalNumber(1))
			.setRange(new DecimalNumber(-1), new DecimalNumber(2), new DecimalNumber(0.1))
			.setObservability(false)
			//.setCueTemplate(cue)
			.setSingleSamplingDistribution(new RFunctionContainer(uniform));
			View.getView().addObject(factorySS.build());
			
			AbstractObjectiveTemplateFactory factoryLL = new AbstractObjectiveTemplateFactory();
			factoryLL.setName("RSC-LL")
			.setType(ResourceObjectTemplate.class)
			.setFrequency(new DecimalNumber(1))
			.setConstant(new DecimalNumber(6));
			//View.getView().addObject(factoryLL.build());
			
			// INTERRUPTION
			AbstractObjectiveTemplateFactory factoryINT = new AbstractObjectiveTemplateFactory();
			factoryINT.setName("INTRPT")
			.setType(InterruptionObjectTemplate.class)
			.setSingleSamplingDistribution(new RFunctionContainer(bernoulli, new AttributeField[] { new AttributeField("pr_x_equals_0", new DecimalNumber(0.9))}))
			.setObservability(false);
			View.getView().addObject(factoryINT.build());
			
			// DELAY
		/*	AbstractObjectiveTemplateFactory factoryDLY = new AbstractObjectiveTemplateFactory();
			factoryDLY.setName("DLY")
			.setType(DelayObjectTemplate.class)
			.setRange(new DecimalNumber(1), new DecimalNumber(3), new DecimalNumber(1))
			.setObservability(true)
			.setFrequency(new DecimalNumber(1))
			.setSingleSamplingDistribution(new RFunctionContainer(uniform));
			View.getView().addObject(factoryDLY.build());*/
			
			// EXTRINSIC
			/*AbstractObjectiveTemplateFactory factoryEX = new AbstractObjectiveTemplateFactory();
			factoryEX.setName("XTRNSC")
			.setType(ExtrinsicObjectTemplate.class)
			.setRange(new DecimalNumber(-1), new DecimalNumber(1), new DecimalNumber(1))
			.setObservability(false)
			.setSingleSamplingDistribution(new RFunctionContainer(uniform))
			.setFrequency(new DecimalNumber(1));
			View.getView().addObject(factoryEX.build());*/
			
			// Update View
			View.getView().update();

			//// T1 Actions
			// Search
			ActionTemplate searchAction = new ActionTemplate(ActionTemplate.ActionType.BETWEEN_ENCOUNTERS, "Search");
			searchAction.addPostcondition(new PostconditionTemplateSearch());
			View.getView().workspace.addAction(searchAction);
			
			// Wait
			ActionTemplate waitAction = new ActionTemplate(ActionTemplate.ActionType.BETWEEN_ENCOUNTERS, "Wait");
			waitAction.addPostcondition(new PostconditionTemplateWaitBetween());
			View.getView().workspace.addAction(waitAction);
		

			/////////////// T2Actions

			// SampleSS
			ActionTemplatePrecondition resourceSSPresent = new ActionTemplatePreconditionResourceEncountered();
			resourceSSPresent.setSubject(View.getView().workspace.getObject("RSC-SS"));
			resourceSSPresent.setOperator(Operator.TRUE);
			/*
			ActionTemplatePostcondition sample = new PostconditionTemplateSample();
			sample.setSubject(View.getView().workspace.getObject("RSC-SS").getCueTemplate());
			
			ActionTemplatePostcondition payCosts = new PostconditionTemplateDecreasePhenotype();
			payCosts.setSubject(View.getView().workspace.getObject("PHNTP"));
			payCosts.setQualifier(new DecimalNumber(1));
			
			ActionTemplatePostcondition interruptSS = new PostconditionTemplateInterruptEncounter();
			interruptSS.setSubject(View.getView().workspace.getObject("INTRPT"));
			interruptSS.setQualifier(View.getView().workspace.getObject("RSC-SS"));
			
			ActionTemplate sampleSS = new ActionTemplate(ActionTemplate.ActionType.DURING_ENCOUNTER, "SampleSS");
			sampleSS.addPrecondition(resourceSSPresent);
			sampleSS.addPostcondition(sample);
			sampleSS.addPostcondition(payCosts);
			sampleSS.addPostcondition(interruptSS);
			View.getView().workspace.addAction(sampleSS);
			*/
			/// consumeSS
			ActionTemplate consumeSS = new ActionTemplate(ActionTemplate.ActionType.DURING_ENCOUNTER, "ConsumeSS");
			consumeSS.addPrecondition(resourceSSPresent);
			ActionTemplatePostcondition consumeSSPC = new PostconditionTemplateConsumeResource();
			
			consumeSSPC.setSubject(View.getView().workspace.getObject("RSC-SS"));
			consumeSSPC.setQualifier(View.getView().workspace.getObject("PHNTP"));
			consumeSS.addPostcondition(consumeSSPC);
			ActionTemplatePostcondition terminate = new PostconditionTemplateTerminateEncounter();
			consumeSS.addPostcondition(terminate);
			View.getView().workspace.addAction(consumeSS);
		
			// Wait
			ActionTemplate waitDuring = new ActionTemplate(ActionTemplate.ActionType.DURING_ENCOUNTER, "WaitDuring");
			ActionTemplatePostcondition waitPC = new PostconditionTemplateWaitDuring();
			waitDuring.addPostcondition(waitPC);
			View.getView().workspace.addAction(waitDuring);
			
			// Mutations
			PhenotypeObjectTemplate p = (PhenotypeObjectTemplate) View.getView().workspace.getObject("PHNTP");
			//ExtrinsicObjectTemplate e = (ExtrinsicObjectTemplate) View.getView().workspace.getObject("XTRNSC");
			//PhenotypeMutationTemplate mutationTemplate = new PhenotypeMutationTemplate(p,e);
			//View.getView().workspace.addPhenotypeMutation(mutationTemplate);
			
			DeathConditionTemplate deathTemplate = new DeathConditionTemplate((PhenotypeObjectTemplate) View.getView().workspace.getObject("PHNTP"), DeathConditionTemplate.Operator.SMALLER_OR_EQUAL_THAN, new DecimalNumber(0));
			View.getView().workspace.addDeathCondition(deathTemplate);
			
			
			RFunction fitnessFunction = null;
			for (RFunction rf: RManager.getAllRFunctionsWithTag("FITNESSFUNCTION")) 
				if (rf.getName().equals("identity"))
					fitnessFunction = rf;
			
			PhenotypeObjectTemplate age = (PhenotypeObjectTemplate) View.getView().workspace.getObject("Age");
			PhenotypeObjectTemplate[] args = new PhenotypeObjectTemplate[]{p};
			View.getView().workspace.setUseFitnessFunctionBeforeMaximumAge(true);
			View.getView().workspace.setFitnessFunction(fitnessFunction, args);
			View.getView().workspace.setFitnessDeath(new DecimalNumber(0));
			
			//View.getView().workspace.setFitnessFunction(fitnessFunction, args);
			
		} catch (Exception e) {e.printStackTrace();}
		
	}

}
