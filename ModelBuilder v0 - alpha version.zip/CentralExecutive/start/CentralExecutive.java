package start;

import java.util.Locale;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * The Model of the program deals with all actual computations. It contains all the Builder objects that are used when
 * the user specifies it inputs, it deals with the creating/scheduling/computation of all agent threads, and it stores
 * all data. In a very meaningful way, the Model IS the program. The only things that the model does not do is communication
 * to the user. All communication (i.e., the graphical user interface) is handled by a FrameController object, which is 
 * created in the main() function.
 */

// TODO: removing a patch (state) should remove the (patch) state in transitions, actions, and mutations

// If a resource influences a phenotype, the stepsize of the resource has to be a positive multiple of the stepsize of the phenotype
// Similarly for extrinsic events

// If a resource influence a phenotype: every value of the resource must be a multiple of the stepsize of the phenotype. 
// Similarly, extrinsic events and phenotype


// It is currently possible to change the initial vector of the base patch. However, that should not be possible.

// When changing the sampling distribution of an object, the patch state offsets do not change with it (instead, they become null).
// Fix this, either by removing all offsets when chaning the sampling distributions, or by adjusting them to the new function.

// when validating ledger: also validate all Beliefs

// What happens if an agent postpones and there is an interruption? How often is there a potential interruption?
// Give a probability-of-interruption parameter to the StateMutator?

// Order: interruption = everything else - termination

// TODO: in extrinsic object: it is now possible to set interruption to a fixed value (0,1). However, this is not possible - only probabilities are allowed.
// Correction: make the fixed step a TextField

// If no possible T2 action: go to T1

// Smart convergence: 

// Check if observable resource has value 0. If so, no change

// If domain minimum < domain maximum there is an exception!

// Make safety checks non-static

// Must be at least one action possible for every possible ActionState

public class CentralExecutive extends Application{
	public static final long programVersion = 1;
	
	@SuppressWarnings("serial")
	public static class InvalidFitnessInputException extends RuntimeException { public InvalidFitnessInputException(String message) {     super(message);  }};


	public static void main (String[] args)
	{
		// Set the number locale to US standards (decimal point, not a decimal comma)
		Locale.setDefault(new Locale("en", "US"));
		launch(); 
	
	}
	
	@Override
	public void start(Stage primaryStage)  {

	}
		
	public CentralExecutive ()	{
		Console.startConsole();
		Console.bootupSequence(this);
		
	
		
		
	}
	

	
	
	
}


