package belief;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObject.IllegalScaleException;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import decimalNumber.DecimalNumber;
import helper.Helper;
import interfaces_abstractions.ObserverManager;
import model.Model;
import start.Console;

/** A posterior belief over an object. Posterior objects are object and patch
 * specific. That is, a single posterior describes the resulting belief after
 * all possible observations (cues) for a single object (e.g., a particular
 * resource) in a specific patch state (e.g., the base state). The posterior
 * should not be accessed directly. Rather, Posteriors are created, stored, and
 * maintained by the Belief class. Let's call the specific object the 'focal
 * object', and the specific patch state the 'focal state'. Note that only resources,
 * delays, and interruptions can be focal objects - at least in this version of ModelBuilder.
 * Whether this Posterior will describe a resource, interruption, or delay, depends on how
 * it is constructed.  
 * 
 * In essence, a posterior serves a fancy linking function, that links a set of observations
 * (which cues are observed) to a set of NumberObjectSingle objects. This NumberObjectSingle
 * array is the same length as the number of possible values of the focal object.
 * Each index position i in this array corresponds to the probability that the object
 * has the i'th value after observed the specified cues. These observed cues must be of length
 * [number of cue labels of focal object], and should have only positive integers in the array.
 * 
 * Finally, Posteriors are precomputed. That is, at the start of the runtime, the model
 * will create the Belief class, which in turn creates all possible Posterior objects. Each
 * Posterior object will, upon creation, calculate all possible sets of observed cues, and 
 * create a posterior belief for each set. */
public class Posterior implements Runnable{

	//int[] does not define equals() in terms of the values that are in the array. 
	// As such, we cannot easily use it in a HashMap. This wrapper function contains
	// only an int[] array, and overrides equals() and hashCode().
	private class IntegerArrayImplementingEquals {
		public final int[] array;
		public IntegerArrayImplementingEquals(int[] array) {
			this.array = array;
		}
		@Override
		public boolean equals(Object o) {
			if (o.getClass() == IntegerArrayImplementingEquals.class)
				return Arrays.equals(array, ((IntegerArrayImplementingEquals) o).array);
			else if (o.getClass().equals(int[].class))
				return Arrays.equals(array, ((int[]) array));
			return false;
		}
		@Override 
		public int hashCode() { return Arrays.hashCode(array);}
	}
	
	private enum Mode { RESOURCE, DELAY, INTERRUPTION}
	
	private final Mode mode;
	private final Model model;
	private final int focalStateIndex;
	private final int focalObjectIndex;
	
	private final Cue cue;
	private final NumberObjectSingle [] prior;
	private final int numberOfPossibleValues;
	private final String[] cueLabels;
	
	private final HashMap< IntegerArrayImplementingEquals, NumberObjectSingle[]> cuesToPosteriorBelief; // cue set -> Pr(v| cue set), for all possible values v in object
	private final HashMap< IntegerArrayImplementingEquals, NumberObjectSingle[]> cuesToNextCue; // observed cue set -> Pr(cue label | cue set), for all possible cue labels
	
	
	protected static Posterior createPosteriorForResource(Model model, int focalStateIndex, int focalObjectIndex) {
		return new Posterior ( model, Mode.RESOURCE, focalStateIndex, focalObjectIndex);
	}
	
	protected static Posterior createPosteriorForDelay(Model model, int focalStateIndex, int focalObjectIndex) {
		return new Posterior ( model,  Mode.DELAY, focalStateIndex, focalObjectIndex);
	}
	
	protected static Posterior createPosteriorForInterruption(Model model, int focalStateIndex, int focalObjectIndex) {
		return new Posterior ( model, Mode.INTERRUPTION, focalStateIndex, focalObjectIndex);
	}
	
	private Posterior ( Model model, Mode mode, int focalStateIndex, int focalObjectIndex) {
		this.model = model;
		this.mode = mode;
		this.focalStateIndex = focalStateIndex;
		this.focalObjectIndex = focalObjectIndex;
		this.cuesToPosteriorBelief = new HashMap<>();
		this.cuesToNextCue = new HashMap<>();
		
		if (mode == Mode.RESOURCE) {
			this.cue = model.ledger.resourceCues[focalObjectIndex];
			this.prior = model.ledger.patchStates[focalStateIndex].resourceValueProbabilities[focalObjectIndex];
			this.cueLabels = model.ledger.resourceCueLabels[focalObjectIndex];
		}
		else if (mode == Mode.DELAY) {
			this.cue = model.ledger.delayCues[focalObjectIndex];
			this.prior = model.ledger.patchStates[focalStateIndex].delayValueProbabilities[focalObjectIndex];
			this.cueLabels = model.ledger.delayCueLabels[focalObjectIndex];
		}
		else {
			this.cue = model.ledger.interruptionCues[focalObjectIndex];
			this.prior = model.ledger.patchStates[focalStateIndex].interruptionValueProbabilities[focalObjectIndex];
			this.cueLabels = model.ledger.interruptionCueLabels[focalObjectIndex];
		}
		
		numberOfPossibleValues = prior.length;
	}

	public void run() {
		try {
			// Do all the required computations
			computeAllPossiblePosteriors();
		} catch (Exception e) { 
			ObserverManager.notifyObserversOfError(e);
			model.outputFileManager.writeExceptionToFile(e);}
	}
	
	/** Computes for all possible sets of cues what the posterior belief is. 
	 * Also computes, for all cue sets, the probability distribution over the
	 * next cue, given an agent's belief after observing the cue set.*/
	private void computeAllPossiblePosteriors() {
		
		// Recursively compute all possible combinations of sampled 
		//cue labels that are possible for the focal object's cue
		ArrayList<int[]> allPossibleCueSets = new ArrayList<>();
		getAllCueCombinations(allPossibleCueSets, new int[cueLabels.length], 0, 0, cue.maximumNumberOfTimesAnAgentCanSampleThisCue, cueLabels.length);
		Console.print("\t\tComputing all possible beliefs for all possible cue sets for " + mode + "["+ focalObjectIndex+ "] in patch state [" + focalStateIndex+"]. There are " + allPossibleCueSets.size() + " possible cue sets in this patch for this resource...");
		
		/* Next, for each possible set of cues we can observe, we want to 
		 compute the posterior belief over all possible values v, given that
		 we observed that cue set. Or in other words, we want to compute
		 
		 		posterior( v | D ), forall v in V
		 		
		 Where V is the set of all possible values the focalObject might have, and
		 D is the set of cues that we observed. Using Bayes theorem, we can compute
		 this posterior as:
		 
		 		post(v|D) = Pr(D|v) * Pr(v)   /    Pr(D), where
		 	
		 Pr(D|v) is the likelihood (chance of cue set given that the object has value v)
		 Pr(v) is the prior belief of v (stored in prior), and
		 Pr(D) is the probability of the cue set. This probability is equal to:
		 		
		 		Pr(D) = forall w:V, Pr(D|w) * Pr(w)
		 
		 Hence, we'll first compute Pr(D|v) for all possible values v (step 1). Next,
		 we multiple each Pr(D|v) with the prior Pr(v) for all possible values v (step 2).
		 Finally, we sum the results over all values, and devide each value with that sum 
		 (step 3) 
		 
		 */


		/*////////////// 	STEP 1: compute Pr(D|V)		///////////////
		//We can compute the likelihood Pr(D|v) forall v:V as:
		//
		//	Pr(D|v) = [number of orderings of D] * Pr(label1|v)^#label1   * Pr(label2|v)^#label2  * ... * Pr(labeln|v)^#labeln
		//
		//or in closed form:
		//
		//	Pr(D|v) = [Number of orderings] * product forall label: cueLabels: (Pr(labeln|v) ^ #labelN
		//
		// We'll tackle this poblem in three steps, 1A, 1B, and 1C
		 */
		for (int cs = 0; cs < allPossibleCueSets.size(); cs++) {	
			int[] cueSet = allPossibleCueSets.get(cs);
			
			// Provide some feedback to the user
			if (cs % 1000 == 0)
				Console.print("\t\t Computing posterior " + mode + "["+ focalObjectIndex+ "] in state [" + focalStateIndex+"]: starting with combination " + cs + " out of " + allPossibleCueSets.size() + ", "  + Math.round(((double)cs)/((double)allPossibleCueSets.size())*100) + "% done...");
			
			int numberOfCuesInCueSet = 0;
			for (int i : cueSet)
				numberOfCuesInCueSet = numberOfCuesInCueSet + i;
		
			// Step 1.A: compute how many possible orderings that would result
			// in the specified cue set:
			//
			// The total ordering (taking the fact that there are multiple values per
			// cue label) is:
			// 		nPn (or Permutation(total number = n, choosen = n) )
			//		----------------------------------------------------
			//		Product over all cue labels { #cueLabel in cueSet !} 
			//
			// Where nPn(n,r) = n!/ (n-r)! (Exception: if there are no
			// cues in the cue set (i.e., we're asking for the prior), 
			// the number of orderings is set to 1
			
			
			DecimalNumber numberOfPossibleSequences = DecimalNumber.ONE;
			if (numberOfCuesInCueSet > 1) {
				DecimalNumber numberOfOrderingsWithoutDuplicates = possiblePermutations(numberOfCuesInCueSet,numberOfCuesInCueSet);

				DecimalNumber productOfFactorials = new DecimalNumber(1);
				for (int i : cueSet)
					productOfFactorials.multiply(DecimalNumber.factorial(i), true);
				numberOfPossibleSequences = numberOfOrderingsWithoutDuplicates.divide(productOfFactorials, true);
			}
	
			// Step 1.B: Compute product forall labels: cueLabels: (Pr(labeln|V) ^ #labelN
			// This gives us the probability of seeing one sequence with of specified cue labels
			// in the cueSet, Pr(sequence|v)
			NumberObjectSingle[] probabilityOfOneSequence = new NumberObjectSingle[numberOfPossibleValues];
			
			for (int v = 0; v < numberOfPossibleValues; v++) {
				// Get the probability of each cue label given v. These are stored in the Cue's emissionProbability matrix
				NumberObjectSingle[] prCueLabelgivenV = cue.emissionProbabilities[v];

				// Multiple each entry in prCueLabelgivenV by the number of times that cue label is in the current
				// cue set (but not if the number of times the label is seen is 0 - otherwise we'd just be left
				// with a final product of 0 :) )
				probabilityOfOneSequence[v] = NumberObject.createNumber(model.howToRepresentNumbers, 1);
				for (int i = 0; i < cueSet.length; i ++) {
					//if (cueSet[i]>0) {
						NumberObjectSingle prCueLabelGivenV = prCueLabelgivenV[i];
						probabilityOfOneSequence[v].multiply( prCueLabelGivenV.pow(cueSet[i], false), true);
					//}
				}
			}
	
			// Step 1.C: combine both parts; multiply the total number of possible sequences with the
			// probability of a single sequence occurring
			NumberObjectSingle[] probabilityCuesetGivenV = new NumberObjectSingle[numberOfPossibleValues];
			for (int v = 0; v < numberOfPossibleValues; v++)
				probabilityCuesetGivenV[v] = probabilityOfOneSequence[v].multiply(numberOfPossibleSequences);

			// Step 2: multiple Pr(D|v) with Pr(v). We'll store the result in probabilityCuesetGivenV, just to avoid
			// doing some unnecessary copying
			for (int v = 0; v< prior.length; v++)
				probabilityCuesetGivenV[v].multiply(prior[v],true);
				
			// Step 3: normalize
			// Step 3.A.: compute the sum of all probabilities
			NumberObjectSingle sum = NumberObject.createNumber(model.howToRepresentNumbers, 0);
			for (int v = 0; v < probabilityCuesetGivenV.length; v++)
				sum.add(probabilityCuesetGivenV[v], true);
		
			// Due to overflow issues, the sum can actually be 0. 
			// This suggests that the user should increase the scale of the DecimalNumber.
			if (sum.equals(0, false)) 
				throw new IllegalScaleException("Value exceeds minimum value given the current " + DecimalNumber.SCALE + " digit scale. SUM: " + sum + ". Current cue set: " + Helper.arrayToString(cueSet));

			for (int v = 0; v < probabilityCuesetGivenV.length; v++)
				probabilityCuesetGivenV[v].divide(sum, true);

			// Now probabilityCuesetGivenV stores the Pr(v|D). If necessary, make sure
			// that all values sum to 1
			if (model.performSafetyChecks) {
				NumberObjectSingle testSum = NumberObject.createNumber(model.howToRepresentNumbers, 0);
				for (int v = 0; v < probabilityCuesetGivenV.length; v++) 
					testSum.add(probabilityCuesetGivenV[v], true);

				if (!testSum.equals(1,true))
					throw new IllegalStateException("Computed Pr(V|D), however, the result does not sum to 1. SUM:" + testSum + ". This error most likely results because the probability of each cue label is lower than DecimalNumber's scale. Consider increasing the DecimalNumber's scale");
			}
			
			// Make the result immutable (prevents accidental future changes)
			for (NumberObjectSingle n: probabilityCuesetGivenV)
				n.makeImmutable();
			
			// Store the resulting Pr(V|cue set) in cuesToPosteriorBelief
			cuesToPosteriorBelief.put(new IntegerArrayImplementingEquals(cueSet), probabilityCuesetGivenV);
		
			// Finally, compute the probability of the next cue having cue label cl, given its posterior belief, 
			// for all possible cue labels cl and object values v. Formally (and abusing notation somewhat), what we want to know is:
			//
			// 		Pr(next cue = cl| posterior)
			//
			// Which we can compute by computing the probability of a next cue for all possible object values v:
			//
			// 		Pr(next cue = cl| posterior) = SUM for all v:V, { Pr(next cue = cl | v, posterior) }
			//
			// This is relatively simple, using the chain rule:
			//
			//		Pr(next cue = cl | v, posterior) = Pr(next cue = cl | v) * Pr( v | posterior )
			//
			// The first term on the right hand side, Pr(next cue = cl | v)  is the cue emission probability,
			// which is already computed in the cue (and which we also use above already). The second term
			// we just computed above. 
			NumberObjectSingle[] probabilityNextCue = new NumberObjectSingle[cueSet.length];
			for (int cl = 0; cl< cueLabels.length; cl++) {
				probabilityNextCue[cl] = NumberObject.createNumber(model.howToRepresentNumbers, 0);
				
				// For each possible resource value v: (remember: probabilityCuesetGivenV now stores Pr(v|D) for all v
				for (int v = 0; v < probabilityCuesetGivenV.length; v++) {
					// Get the emission probability of the cl under the prior
					NumberObjectSingle emission = cue.emissionProbabilities[v][cl];
					
					// Get the posterior probability of v
					NumberObjectSingle posteriorProbabilityV = probabilityCuesetGivenV[v];
					
					// Multiply and add to probabilityNextCue[cl]
					probabilityNextCue[cl].add( emission.multiply(posteriorProbabilityV, false), true  );
				}
				
				// Make the result immutable
				probabilityNextCue[cl].makeImmutable();	
			}
			
			// Check if the sum of all cue label probabilities is indeed 1
			if (model.performSafetyChecks) {
				NumberObjectSingle testSum = NumberObject.createNumber(model.howToRepresentNumbers, 0);
				for (int v = 0; v < probabilityNextCue.length; v++) 
					testSum.add(probabilityNextCue[v], true);

				if (!testSum.equals(1,true))
					throw new IllegalStateException("Computed Pr(CL| Posterior, V), however, the result does not sum to 1. SUM:" + testSum + ". This error most likely results because the probability of each cue label is lower than DecimalNumber's scale. Consider increasing the DecimalNumber's scale");
			}
			
			// Store the result in 
			cuesToNextCue.put(new IntegerArrayImplementingEquals(cueSet), probabilityNextCue);
			
		}
		Console.print("\tFinished computing all possible beliefs for all possible cue sets for " + mode + "["+ focalObjectIndex+ "] in patch state [" + focalStateIndex+"]. ");
		
	}
	
	/** Recursively computes all possible combinations of cues. The results are stored in combinations*/
	private void getAllCueCombinations(
			ArrayList<int[]> combinations,
			int[] currentSequence,
			int currentDepth,
			int currentCuesAssigned, 
			int maxCues,
			int maxDepth) {
		
		// base case: if the currentDepth is the same as the maximumDepth, we have
		// a value for all possible dimensions stored in current, and we are done with this 
		// sequence. We should store this sequence in the list of all combinations found
		// thus far only if the total number of cues sampled is lower than the maximum number
		// of cues
		if (currentDepth == (maxDepth)) {
			if (currentCuesAssigned <= maxCues) {
				int[] newSequence = new int[currentSequence.length];
				for (int i = 0; i < currentSequence.length; i++)
					newSequence[i] = currentSequence[i];
				combinations.add(newSequence);
			}
			return;
		} 
		
		// Otherwise, add another set of values to the current set
		for (int i = 0; i <= (maxCues-currentCuesAssigned); i++) {
			currentSequence[currentDepth] = i;
			getAllCueCombinations(
					combinations,
					currentSequence,
					currentDepth+1,
					currentCuesAssigned+i,
					maxCues,
					maxDepth
					);
		}
		
	}
	
	
	/** Compute the total number of permutations, without repetition. It's easy to overflow even
	 * a LONG primitive type here, hence the DecimalNumber*/
	private DecimalNumber possiblePermutations(int n, int r) {
		return DecimalNumber.factorial(n).divide( DecimalNumber.factorial(n-r), true );
	}
	
	
	/** Returns the posterior probability of all values of the focal object of this posterior, 
	 * given the set of observed cues. The resulting array is of size |v| - the number of 
	 * possible values of that object. The input should be of size |cl|, the number of cue
	 * labels that the focal object's cue has.*/
	protected NumberObjectSingle[] posteriorBeliefAfterCues(int[] observedCues) {
		if (observedCues.length != cueLabels.length)
			throw new IllegalArgumentException("Trying to retrieve the posterior belief for a set of cues. However, the length of this set does not match the number of cue labels.");
		return this.cuesToPosteriorBelief.get(new IntegerArrayImplementingEquals(observedCues));
	}

	/** Returns the posterior probability of the next cue label, given that the agent has
	 * already observed the observedCues set. The resulting array is of size |cl| - the number of 
	 * cue labels that the focal object's cue has.*/
	protected NumberObjectSingle[] posteriorCueProbabilityAfterCues(int[] observedCues) {
		if (observedCues.length != cueLabels.length)
			throw new IllegalArgumentException("Trying to retrieve the posterior emission probability for a set of cues. However, the length of this set does not match the number of cue labels.");
		return this.cuesToNextCue.get(new IntegerArrayImplementingEquals(observedCues));
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cuesToNextCue == null) ? 0 : cuesToNextCue.hashCode());
		result = prime * result + ((cuesToPosteriorBelief == null) ? 0 : cuesToPosteriorBelief.hashCode());
		result = prime * result + focalObjectIndex;
		result = prime * result + focalStateIndex;
		result = prime * result + ((mode == null) ? 0 : mode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Posterior other = (Posterior) obj;
		if (cuesToNextCue == null) {
			if (other.cuesToNextCue != null) {
				return false;
			}
		} else if (!cuesToNextCue.equals(other.cuesToNextCue)) {
			return false;
		}
		if (cuesToPosteriorBelief == null) {
			if (other.cuesToPosteriorBelief != null) {
				return false;
			}
		} else if (!cuesToPosteriorBelief.equals(other.cuesToPosteriorBelief)) {
			return false;
		}
		if (focalObjectIndex != other.focalObjectIndex) {
			return false;
		}
		if (focalStateIndex != other.focalStateIndex) {
			return false;
		}
		if (mode != other.mode) {
			return false;
		}
		return true;
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		sb.append("Posterior for " + mode + "[" + focalObjectIndex+ "] in patch state [" + this.focalStateIndex + "]:");
		sb.append("\n\tPosterior beliefs: ");
		for (IntegerArrayImplementingEquals key : this.cuesToPosteriorBelief.keySet())
			sb.append("\n\t\t" + Helper.arrayToString(key.array) + "\t->\t" + Helper.arrayToString(this.cuesToPosteriorBelief.get(key)));
		
		sb.append("\n\tPosterior cue emission probability: ");
		for (IntegerArrayImplementingEquals key : this.cuesToNextCue.keySet())
			sb.append("\n\t\t" + Helper.arrayToString(key.array) + "\t->\t" + Helper.arrayToString(this.cuesToNextCue.get(key)));
		return sb.toString();
	}
}
