package belief;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import interfaces_abstractions.ObserverManager;
import model.Model;
import start.Console;
import t2states.T2ActionState;
import t2states.T2ActionStateFactory;

public class Belief {

	private final Model model;

	// A Posterior class holds all possible beliefs for a object in a patch state.
	// That is to say, for each possible combinations of cues (including the prior),
	// the posterior stores a corresponding belief over the object's value after
	// observing that set of cues in that patch.
	// Upon construction the Belief class creates all possible Posterior objects - 
	// as such, creation might take some time.
	private final Posterior[][] resourcePosteriors; // [patchState index] [resourceIndex]
	private final Posterior[][] delayPosteriors; //[patchState index] [ delayIndex ] 
	public final Posterior[][] interruptionPosteriors; // [patchState index][interruptionIndex]

	private boolean computedPosteriors; // Did we already compute posteriors?


	/** Create a Belief object, which will store all possible beliefs. Specifically, it stores, for each 
	 * possible prior in the patch state, and all possible cue sets an agent can gather, both the posterior 
	 * probability and the probability of the next cue. Upon construction this object will not yet compute
	 * all these probabilities. Rather, computeAllPosteriors() has to be called manually upon starting
	 * the run of the Model.*/
	public Belief (Model model) {
		this.model = model;
		this.computedPosteriors = false;
		// Create empty arrays for all the posteriors
		resourcePosteriors = 	 new Posterior[model.ledger.numberOfPatchStates][model.ledger.numberOfResourceTypes];
		delayPosteriors = 		 new Posterior[model.ledger.numberOfPatchStates][model.ledger.numberOfDelayTypes];
		interruptionPosteriors = new Posterior[model.ledger.numberOfPatchStates][model.ledger.numberOfInterruptionTypes];
	}

	/** Computes all possible posterior beliefs and all possible posterior cue emission probabilities.
	 * This task is computationally heavy, and might take a while. Also note: this task will be
	 * multithreaded. The thread calling this function will block until this task is completed!*/
	public void computeAllPosteriors() {
		if (computedPosteriors)
			return;

		// First, create a Posterior object for all possible cues in all possible states.
		// These posteriors do not yet compute all values yet - that is the next step
		ArrayList<Posterior> allPosteriorsToCompute = new ArrayList<>();
		for (int patchState = 0; patchState < model.ledger.numberOfPatchStates; patchState++) {
			for (int resource = 0; resource < model.ledger.numberOfResourceTypes; resource ++)
				if (model.ledger.resourceCues[resource] != null) {
					resourcePosteriors[patchState][resource] = Posterior.createPosteriorForResource(model, patchState, resource);
					allPosteriorsToCompute.add(resourcePosteriors[patchState][resource] );
				}

			for (int delay = 0; delay < model.ledger.numberOfDelayTypes; delay ++)
				if (model.ledger.delayCues[delay] != null) {
					delayPosteriors[patchState][delay] = Posterior.createPosteriorForDelay(model, patchState, delay);
					allPosteriorsToCompute.add(delayPosteriors[patchState][delay] );
				}

			for (int interruption = 0; interruption < model.ledger.numberOfInterruptionTypes; interruption ++)
				if (model.ledger.interruptionCues[interruption] != null) {
					interruptionPosteriors[patchState][interruption] = Posterior.createPosteriorForInterruption(model, patchState, interruption);
					allPosteriorsToCompute.add(interruptionPosteriors[patchState][interruption] );
				}
		}

		// Provide some feedback to the user
		Console.print("\tIdentified " + allPosteriorsToCompute.size() + " unique combinations of a patch state and a cue type that we have to compute posteriors for");

		// Create an ExecutorService to handle the multithreading
		ExecutorService es = Executors.newFixedThreadPool(model.nThreads);

		// Execute all posteriors - let them compute all possible posteriors and probability of the next cue
		for (Posterior p : allPosteriorsToCompute) 
			es.execute(p);

		// Shutdown the executor service
		es.shutdown();

		// Wait until all posteriors are done
		try {
			es.awaitTermination(100, TimeUnit.DAYS);
		} catch (InterruptedException e) {
			ObserverManager.notifyObserversOfError(e);
			model.outputFileManager.writeExceptionToFile(e);
		}

		Console.print("\tFinished computing all posteriors.");

		computedPosteriors = true;
	}


	///////////////////////////////////////////////////////////////
	/////////////////// Posteriors about RESOURCES ///////////////
	/////////////////////////////////////////////////////////////
	/** Returns the distribution of resource values of the specified resource in the specified patch state. Note
	 * that this distribution is already in the PatchState. This is just a convenience function so that we can
	 * get all the beliefs from the Belief object. */
	public NumberObjectSingle[] priorBeliefOfResource(int patchStateWhenStartingEncounter, int resourceIndex) {
		return model.ledger.patchStates[patchStateWhenStartingEncounter].resourceValueProbabilities[resourceIndex];
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible values
	 * that this resource can take. Each entry in this array is the probability of that value given
	 * that the agent has observed the set of cues.*/
	public NumberObjectSingle[] posteriorBeliefResourceAfterObservingCues( int patchStateWhenStartingEncounter, int resourceIndex, int[] observedCues ) {
		return this.resourcePosteriors[patchStateWhenStartingEncounter][resourceIndex].posteriorBeliefAfterCues(observedCues);
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible labels
	 * that the next cue of this resource can take. Each entry in this array is the probability of that label given
	 * that the agent has observed the set of cues.*/
	public NumberObjectSingle[] probabilityOfNextResourceCueAfterObservingCues( int patchStateWhenStartingEncounter, int resourceIndex, int[] observedCues ) {
		return this.resourcePosteriors[patchStateWhenStartingEncounter][resourceIndex].posteriorCueProbabilityAfterCues(observedCues);
	}

	/** Returns the distribution of resource values of the specified resource when an agent is in the specified state. Note
	 * that this distribution is already in the PatchState. This is just a convenience function so that we can
	 * get all the beliefs from the Belief object. */
	public NumberObjectSingle[] priorBeliefOfResource(T2ActionState state, int resourceIndex) {
		return model.ledger.patchStates[state.patchStateWhenStartingEncounter].resourceValueProbabilities[resourceIndex];
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible values
	 * that this resource can take. Each entry in this array is the probability of that value given
	 * the state's set of observed cues for the specified resource type.*/
	public NumberObjectSingle[] posteriorBeliefResourceAfterObservingCues(T2ActionState state, int resourceIndex) {
		return this.resourcePosteriors[state.patchStateWhenStartingEncounter][resourceIndex].posteriorBeliefAfterCues(state.resourceCueSet(resourceIndex));
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible labels
	 * that the next cue of this resource can take. Each entry in this array is the probability of that label given
	 * that the agent has observed the set of cues.*/
	public NumberObjectSingle[] probabilityOfNextResourceCueAfterObservingCues(T2ActionState state, int resourceIndex ) {
		return this.resourcePosteriors[state.patchStateWhenStartingEncounter][resourceIndex].posteriorCueProbabilityAfterCues(state.resourceCueSet(resourceIndex));
	}

	/** Returns the distribution of resource values of the specified resource when an agent is in the state specified by the factory. Note
	 * that this distribution is already in the PatchState. This is just a convenience function so that we can
	 * get all the beliefs from the Belief object. */
	public NumberObjectSingle[] priorBeliefOfResource(T2ActionStateFactory stateFactory, int resourceIndex) {
		return model.ledger.patchStates[stateFactory.patchStateWhenStartingEncounter].resourceValueProbabilities[resourceIndex];
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible values
	 * that this resource can take. Each entry in this array is the probability of that value given
	 * the (factory's resulting) state's set of observed cues for the specified resource type.*/
	public NumberObjectSingle[] posteriorBeliefResourceAfterObservingCues(T2ActionStateFactory stateFactory, int resourceIndex) {
		return this.resourcePosteriors[stateFactory.patchStateWhenStartingEncounter][resourceIndex].posteriorBeliefAfterCues(stateFactory.resourceCueSet(resourceIndex));
	}
	
	/** Returns an array of NumberObjectSingle with the size equal to the number of possible probabilities
	 * that this resource type occurs. If the resourceIndex is not observable and the agent can sample cues,
	 * then each entry in this array is the value of that resource given the (factory's resulting) state's set of observed 
	 * cues for the specified resource type. If the delayIndex is either observable, or the agent cannot
	 * sample any cues, this function returns the prior belief. 
	 * */
	public NumberObjectSingle[] getBeliefResource(T2ActionStateFactory stateFactory, int resourceIndex) {
		if (model.ledger.resourceIsObservable[resourceIndex])
			return this.priorBeliefOfResource(stateFactory.patchStateWhenStartingEncounter, resourceIndex);
		else if (model.ledger.resourceCues[resourceIndex] == null)
			return this.priorBeliefOfResource(stateFactory.patchStateWhenStartingEncounter, resourceIndex);
		else // not observable, but can sample cues
			return this.resourcePosteriors[stateFactory.patchStateWhenStartingEncounter][resourceIndex].posteriorBeliefAfterCues(stateFactory.resourceCueSet(resourceIndex));
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible labels
	 * that the next cue of this resource can take. Each entry in this array is the probability of that label given
	 * that the agent has observed the set of cues.*/
	public NumberObjectSingle[] probabilityOfNextResourceCueAfterObservingCues(T2ActionStateFactory stateFactory, int resourceIndex ) {
		return this.resourcePosteriors[stateFactory.patchStateWhenStartingEncounter][resourceIndex].posteriorCueProbabilityAfterCues(stateFactory.resourceCueSet(resourceIndex));
	}
	////////////////////////////////////////////////////////////
	/////////////////// Posteriors about DELAYS ///////////////
	//////////////////////////////////////////////////////////
	/** Returns the distribution of durations of the specified delay in the specified patch state. Note
	 * that this distribution is already in the PatchState. This is just a convenience function so that we can
	 * get all the beliefs from the Belief object. */
	public NumberObjectSingle[] priorBeliefOfDelay(int patchStateWhenStartingEncounter, int delayIndex) {
		return model.ledger.patchStates[patchStateWhenStartingEncounter].delayValueProbabilities[delayIndex];
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible durations
	 * that this delay can be. Each entry in this array is the probability of that value given
	 * that the agent has observed the set of cues.*/
	public NumberObjectSingle[] posteriorBeliefDelayAfterObservingCues( int patchStateWhenStartingEncounter, int delayIndex, int[] observedCues ) {
		return this.delayPosteriors[patchStateWhenStartingEncounter][delayIndex].posteriorBeliefAfterCues(observedCues);
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible labels
	 * that the next cue of this delay type can take. Each entry in this array is the probability of that label given
	 * that the agent has observed the set of cues.*/
	public NumberObjectSingle[] probabilityOfNextDelayCueAfterObservingCues( int patchStateWhenStartingEncounter, int delayIndex, int[] observedCues ) {
		return this.delayPosteriors[patchStateWhenStartingEncounter][delayIndex].posteriorCueProbabilityAfterCues(observedCues);
	}

	/** Returns the distribution of resource values of the specified delay type when an agent is in the specified state. Note
	 * that this distribution is already in the PatchState. This is just a convenience function so that we can
	 * get all the beliefs from the Belief object. */
	public NumberObjectSingle[] priorBeliefOfDelay(T2ActionState state, int delayIndex) {
		return model.ledger.patchStates[state.patchStateWhenStartingEncounter].delayValueProbabilities[delayIndex];
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible durations
	 * that delay type can take. Each entry in this array is the probability of that value given
	 * the state's set of observed cues for the specified delay type.*/
	public NumberObjectSingle[] posteriorBeliefDelayAfterObservingCues(T2ActionState state, int delayIndex) {
		return this.delayPosteriors[state.patchStateWhenStartingEncounter][delayIndex].posteriorBeliefAfterCues(state.delayCueSet(delayIndex));
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible labels
	 * that the next cue of this delay type can take. Each entry in this array is the probability of that label given
	 * that the agent has observed the set of cues.*/
	public NumberObjectSingle[] probabilityOfNextDelayCueAfterObservingCues(T2ActionState state, int delayIndex ) {
		return this.delayPosteriors[state.patchStateWhenStartingEncounter][delayIndex].posteriorCueProbabilityAfterCues(state.delayCueSet(delayIndex));
	}

	/** Returns the distribution of durations that the specified delay can be when an agent is in the state specified by the factory. Note
	 * that this distribution is already in the PatchState. This is just a convenience function so that we can
	 * get all the beliefs from the Belief object. */
	public NumberObjectSingle[] priorBeliefOfDelay(T2ActionStateFactory stateFactory, int delayIndex) {
		return model.ledger.patchStates[stateFactory.patchStateWhenStartingEncounter].delayValueProbabilities[delayIndex];
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible durations
	 * that this delay type can take. Each entry in this array is the probability of that value given
	 * the (factory's resulting) state's set of observed cues for the specified delay type.*/
	public NumberObjectSingle[] posteriorBeliefDelayAfterObservingCues(T2ActionStateFactory stateFactory, int delayIndex) {
		return this.delayPosteriors[stateFactory.patchStateWhenStartingEncounter][delayIndex].posteriorBeliefAfterCues(stateFactory.delayCueSet(delayIndex));
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible probabilities
	 * that this delay type occurs. If the delayIndex is not observable and the agent can sample cues,
	 * then each entry in this array is the probability of that duration given the (factory's resulting) state's set of observed 
	 * cues for the specified delay type. If the delayIndex is either observable, or the agent cannot
	 * sample any cues, this function returns the prior belief. 
	 * */
	public NumberObjectSingle[] getBeliefDelay(T2ActionStateFactory stateFactory, int delayIndex) {
		if (model.ledger.delayIsObservable[delayIndex])
			return this.priorBeliefOfDelay(stateFactory.patchStateWhenStartingEncounter, delayIndex);
		else if (model.ledger.delayCues[delayIndex] == null)
			return this.priorBeliefOfDelay(stateFactory.patchStateWhenStartingEncounter, delayIndex);
		else // not observable, but can sample cues
			return this.delayPosteriors[stateFactory.patchStateWhenStartingEncounter][delayIndex].posteriorBeliefAfterCues(stateFactory.delayCueSet(delayIndex));
	}

	
	/** Returns an array of NumberObjectSingle with the size equal to the number of possible labels
	 * that the next cue of this delay can take. Each entry in this array is the probability of that label given
	 * that the agent has observed the set of cues.*/
	public NumberObjectSingle[] probabilityOfNextDelayCueAfterObservingCues(T2ActionStateFactory stateFactory, int delayIndex ) {
		return this.delayPosteriors[stateFactory.patchStateWhenStartingEncounter][delayIndex].posteriorCueProbabilityAfterCues(stateFactory.delayCueSet(delayIndex));
	}
	///////////////////////////////////////////////////////////////////
	/////////////////// Posteriors about Interruptions ///////////////
	/////////////////////////////////////////////////////////////////
	/** Returns the distribution of durations of the specified interruption type in the specified patch state. Note
	 * that this distribution is already in the PatchState. This is just a convenience function so that we can
	 * get all the beliefs from the Belief object. The resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1)*/
	public NumberObjectSingle[] priorBeliefOfInterruption(int patchStateWhenStartingEncounter, int interruptionIndex) {
		return model.ledger.patchStates[patchStateWhenStartingEncounter].interruptionValueProbabilities[interruptionIndex];
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible probabilities
	 * that this interruption occurs. Each entry in this array is the probability of that value given
	 * that the agent has observed the set of cues. The resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1)*/
	public NumberObjectSingle[] posteriorBeliefInterruptionAfterObservingCues( int patchStateWhenStartingEncounter, int interruptionIndex, int[] observedCues ) {
		return this.interruptionPosteriors[patchStateWhenStartingEncounter][interruptionIndex].posteriorBeliefAfterCues(observedCues);
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible labels
	 * that the next cue of this interruption type can take. Each entry in this array is the probability of that label given
	 * that the agent has observed the set of cues. The resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1)*/
	public NumberObjectSingle[] probabilityOfNextInterruptionCueAfterObservingCues( int patchStateWhenStartingEncounter, int interruptionIndex, int[] observedCues ) {
		return this.interruptionPosteriors[patchStateWhenStartingEncounter][interruptionIndex].posteriorCueProbabilityAfterCues(observedCues);
	}

	/** Returns the distribution of resource values of the specified interruption type when an agent is in the specified state. Note
	 * that this distribution is already in the PatchState. This is just a convenience function so that we can
	 * get all the beliefs from the Belief object. The resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1)*/
	public NumberObjectSingle[] priorBeliefOfInterruption(T2ActionState state, int interruptionIndex) {
		return model.ledger.patchStates[state.patchStateWhenStartingEncounter].interruptionValueProbabilities[interruptionIndex];
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible probabilities
	 * that this interruption type occurs. The resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1).*/
	public NumberObjectSingle[] posteriorBeliefInterruptionAfterObservingCues(T2ActionState state, int interruptionIndex) {
		return this.interruptionPosteriors[state.patchStateWhenStartingEncounter][interruptionIndex].posteriorBeliefAfterCues(state.interruptionCueSet(interruptionIndex));
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible labels
	 * that the next cue of this interruption type can take. Each entry in this array is the probability of that label given
	 * that the agent has observed the set of cues.The resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1)*/
	public NumberObjectSingle[] probabilityOfNextInterruptionCueAfterObservingCues(T2ActionState state, int interruptionIndex ) {
		return this.interruptionPosteriors[state.patchStateWhenStartingEncounter][interruptionIndex].posteriorCueProbabilityAfterCues(state.interruptionCueSet(interruptionIndex));
	}
	
	/** Returns the distribution of probabilities of the specified interruption type when an agent is in the state specified by the factory. Note
	 * that this distribution is already in the PatchState. This is just a convenience function so that we can
	 * get all the beliefs from the Belief object. The resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1)*/
	public NumberObjectSingle[] priorBeliefOfInterruption(T2ActionStateFactory stateFactory, int interruptionIndex) {
		return model.ledger.patchStates[stateFactory.patchStateWhenStartingEncounter].interruptionValueProbabilities[interruptionIndex];
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible probabilities
	 * that this interruption type occurs. Each entry in this array is the probability of that value given
	 * the (factory's resulting) state's set of observed cues for the specified interruption type. 
	 * The resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1)*/
	public NumberObjectSingle[] posteriorBeliefInterruptionAfterObservingCues(T2ActionStateFactory stateFactory, int interruptionIndex) {
		return this.interruptionPosteriors[stateFactory.patchStateWhenStartingEncounter][interruptionIndex].posteriorBeliefAfterCues(stateFactory.interruptionCueSet(interruptionIndex));
	}

	/** Returns an array of NumberObjectSingle with the size equal to the number of possible probabilities
	 * that this interruption type occurs. If the interruptionIndex is not observable and the agent can sample cues,
	 * then, each entry in this array is the probability of that value given the (factory's resulting) state's set of observed 
	 * cues for the specified interruption type. If the interruptionIndex is either observable, or the agent cannot
	 * sample any cues, this function returns the prior belief. 
	 * 
	 * In any case, the resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1)*/
	public NumberObjectSingle[] getBeliefInterruption(T2ActionStateFactory stateFactory, int interruptionIndex) {
		if (model.ledger.interruptionIsObservable[interruptionIndex])
			return this.priorBeliefOfInterruption(stateFactory.patchStateWhenStartingEncounter, interruptionIndex);
		else if (model.ledger.interruptionCues[interruptionIndex] == null)
			return this.priorBeliefOfInterruption(stateFactory.patchStateWhenStartingEncounter, interruptionIndex);
		else // not observable, but can sample cues
			return this.interruptionPosteriors[stateFactory.patchStateWhenStartingEncounter][interruptionIndex].posteriorBeliefAfterCues(stateFactory.interruptionCueSet(interruptionIndex));
	}

	
	/** Returns an array of NumberObjectSingle with the size equal to the number of possible labels
	 * that the next cue of this interruption type can take. Each entry in this array is the probability of that label given
	 * that the agent has observed the set of cues. The resulting array contains two probabilities: the probability
	 * of an interruption NOT happening (index 0), and the probability of an interruption happening (index 1)*/
	public NumberObjectSingle[] probabilityOfNextInterruptionCueAfterObservingCues(T2ActionStateFactory stateFactory, int interruptionIndex ) {
		return this.interruptionPosteriors[stateFactory.patchStateWhenStartingEncounter][interruptionIndex].posteriorCueProbabilityAfterCues(stateFactory.interruptionCueSet(interruptionIndex));
	}

}