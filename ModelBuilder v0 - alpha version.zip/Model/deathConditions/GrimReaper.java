package deathConditions;

import model.Ledger;
import t1states.T1AbstractStateFactory;

/** The GrimReaper class has one static function, doesKill, which returns
 * true if a State matches at least 1 death condition.*/
public class GrimReaper {
	private final Ledger ledger;
	
	/** Create the GrimReaper, a class that kills states*/
	public GrimReaper (Ledger ledger) {
		this.ledger = ledger;
	}
	

	/** Returns true if at least one DeathCondition applies to the state that will result from this factory*/
	public boolean willBeCulled(T1AbstractStateFactory stateFactory) {
		for (DeathCondition dc: ledger.deathConditions)
			if (dc.applies(stateFactory)) {
				return true;
			}
		return false;	
	}

}
