package deathConditions;

import deathConditionElements.DeathConditionTemplate;
import model.LedgerFactory;
import model.Model;
import t1states.T1AbstractStateFactory;

public abstract class DeathCondition {

	/** Create the death condition that kills an agent after it reached the maximum age*/
	public static DeathConditionAge makeDeathConditionAge(Model model) {
		return new DeathConditionAge(model);
	}

	/** Create a death conditions that kills the agent if its phenotype matches some specification*/
	public static DeathConditionPhenotype makeDeathConditionPhenotype(DeathConditionTemplate template, LedgerFactory ledgerFactory) {
		// Find the phenotypeIndex
		int phenotypeIndex = -1;
		for (int i =0; i < ledgerFactory.phenotypeNames.size(); i ++)
			if (ledgerFactory.phenotypeNames.get(i).equals(template.phenotype.getName()))
				phenotypeIndex = i;
		if (phenotypeIndex == -1)
			throw new IllegalStateException("Trying to create an phenotype based death condition for a phenotype that is not registered (yet). Looking for name " + template.phenotype.getName());


		// Get the value index
		int phenotypeValueIndex = -1;
		for (int i =0; i < ledgerFactory.phenotypeValues.get(phenotypeIndex).length; i ++)
			if (ledgerFactory.phenotypeValues.get(phenotypeIndex)[i].equals(template.value))
				phenotypeValueIndex = i;
		if (phenotypeValueIndex == -1)
			throw new IllegalStateException("Trying to create an phenotype based death condition for a phenotype value that does not exist. Looking for value " + template.value.toStringWithoutTrailingZeros());

		return new DeathConditionPhenotype(phenotypeIndex, template.operator, phenotypeValueIndex);

	}

	/** Returns true if this death condition applies to the state result from this factory - i.e., the state matches the condition*/
	public abstract boolean applies( T1AbstractStateFactory stateFactory);

	public abstract String toString();
	
	@Override
	public abstract int hashCode();

	@Override
	public abstract boolean equals(Object obj) ;
}
	