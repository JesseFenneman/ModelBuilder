package deathConditions;

import deathConditionElements.DeathConditionTemplate.Operator;
import t1states.T1AbstractStateFactory;

/** Sometimes an agent dies even if it is not its time - i.e., when it hasn't reached 
 * the maximum age yet*/
public class DeathConditionPhenotype extends DeathCondition{

	private final int phenotypeIndex;
	private final Operator operator;
	private final int phenotypeValueIndex;
	
	protected DeathConditionPhenotype(int phenotypeIndex, Operator operator, int phenotypeValueIndex) {
		this.phenotypeIndex = phenotypeIndex;
		this.operator = operator;
		this.phenotypeValueIndex = phenotypeValueIndex;
	}
	
	@Override
	public boolean applies(T1AbstractStateFactory stateFactory) {
		int stateValue = stateFactory.phenotype[phenotypeIndex];
		
		switch (operator) {
		case EQUALS: 				return stateValue == phenotypeValueIndex;
		case DOES_NOT_EQUAL:		return stateValue != phenotypeValueIndex;
		case GREATER_THAN:			return stateValue > phenotypeValueIndex;
		case SMALLER_THAN:			return stateValue < phenotypeValueIndex;
		case GREATER_OR_EQUAL_THAN:	return stateValue >= phenotypeValueIndex;
		case SMALLER_OR_EQUAL_THAN:	return stateValue <= phenotypeValueIndex;
		default:					throw new IllegalStateException("Unknown operator for death condition");
		}
	}
	
	
	@Override
	public String toString() {
		return "Death condition: an agent dies when its phenotype [" + phenotypeIndex + "] is " + operator +" ["+phenotypeValueIndex+"]";
	}

	@Override
	public int hashCode() {
		int result = 1;
		result = result + ((operator == null) ? 0 : operator.hashCode());
		result = result + phenotypeIndex * 10;
		result = result + phenotypeValueIndex * 100;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		DeathConditionPhenotype other = (DeathConditionPhenotype) obj;
		if (operator != other.operator) {
			return false;
		}
		if (phenotypeIndex != other.phenotypeIndex) {
			return false;
		}
		if (phenotypeValueIndex != other.phenotypeValueIndex) {
			return false;
		}
		return true;
	}

}
