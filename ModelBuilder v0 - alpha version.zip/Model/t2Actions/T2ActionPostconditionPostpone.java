package t2Actions;

import java.util.ArrayList;
import java.util.Iterator;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectIncorrectRepresentationException;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import model.Model;
import t1states.T1MutationStateFactory;
import t2states.T2ActionStateFactory;

public class T2ActionPostconditionPostpone extends T2ActionPostcondition{
	// Which delay might we encounter?
	private final int delayIndex;

	// Which interruption will apply at any time moment? (-1 for postponing without interruptions)
	// Note that interruptions during postponing influence all resources, not just a specific one (as is the case for the interruption postcondition).
	private final int interruptionIndex;
	private final Model model;
	private final T2ActionPostconditionInterrupt interruptionEvent;

	public T2ActionPostconditionPostpone(Model model, int delayIndex, int interruptionIndex) {
		this.model = model;
		this.delayIndex = delayIndex;
		this.interruptionIndex = interruptionIndex;
		
		// create the T2ActionPostconditionInterrupt that we will use for the 
		// interruption event (if there is one)
		if (interruptionIndex >= 0)
			this.interruptionEvent = new T2ActionPostconditionInterrupt(model, interruptionIndex);
		else
			this.interruptionEvent = null;
	}

	@Override
	public String getName() {
		return "Postpone with delay [" + delayIndex + "] and interruption event [ " + interruptionEvent.getName()+ "]";
	}

	
	@Override
	public Pair<ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStates(
			ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates) {
		if (model.performSafetyChecks)
			if (currentStates.size() == 0)
				throw new IllegalArgumentException("Calling action postcondition postpone with an empty currentState list");
	
		// Create a new ArrayList to store all resulting State-probability Pairs in
		ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> successorT2ActionStates = new ArrayList<>(); // no interruption
		ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>> successorT1MutationStates = new ArrayList<>(); // interruption
		
		// First: with a probability 1-frequencyOfDelay the delay does not occur at all 
		// The frequency depends on the patch state that an agent is in. However, as this state is
		// invariant in the T2DecisionTree, we can just get it from the first sucPair.
		int locationPatchState = currentStates.get(0).element1.locationPatchState;
		NumberObjectSingle frequency = model.ledger.patchStates[locationPatchState].delayFrequencies[delayIndex];

		// With a probability of 1-Frequency: nothing happens.
		if (!frequency.equals(1)) {

			// calculate the new probability of the successorState, given that the delay does not happen
			NumberObjectSingle probabilityNoDelay = frequency.complementOfOne();

			// With that probability: nothing happens:
			for (Pair<T2ActionStateFactory, NumberObjectSingle> sucPair: currentStates)
				successorT2ActionStates.add(new Pair<T2ActionStateFactory, NumberObjectSingle>(sucPair.element1, probabilityNoDelay));
		}
		
		// Next, what happens if there is a delay?
		// If the delay is observable, we only have to get the weighted successor states for one possible delay, weighted for the probability of 
		// the agent ending up in that state, and the probability that there was a delay to begin with.
		if (model.ledger.delayIsObservable[delayIndex]) {
			// Get the duration of the delay at the start of the encounter. Again, this duration is invariant within the 
			// decision tree, and hence, is the same for all possible T2ActionStates
			int durationBeforeExtrinsic = currentStates.get(0).element1.durationIndexOfEncounteredObservableDelays[delayIndex];
			
			Pair<ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> weightedSuccessorStates = 
					this.getSuccessorStatesForDelayIndex(currentStates, frequency, durationBeforeExtrinsic, true);
			
			successorT2ActionStates = weightedSuccessorStates.element1;
			successorT1MutationStates = weightedSuccessorStates.element2;
		}
		
		// If the delay is not observable, we have to get the weighted probability for all possible delays (just as above), but
		// now weight each possible successor state also for the probability of the delay. The function getSuccessorStatesForDelayIndex
		// already takes this probability into account. So here we call this function for all possible delay durations
		else {
			for (int d = 0; d < model.ledger.delayValues[delayIndex].length; d++) {
				Pair<ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> weightedSuccessorStates = 
						this.getSuccessorStatesForDelayIndex(currentStates, frequency, d, false);
				
				successorT2ActionStates = weightedSuccessorStates.element1;
				successorT1MutationStates = weightedSuccessorStates.element2;
			}
		}
		
		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to the starting probability
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> p: successorT2ActionStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.element2, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T2ActionState successor state after postponing has a non-positive probability.");
				else
					sum.add(p.element2, true);

			for (Pair<T1MutationStateFactory, NumberObjectSingle> p: successorT1MutationStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.element2, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T1MutationState successor state after postponing has a non-positive probability.");
				else
					sum.add(p.element2, true);

			DecimalNumber target = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> pair : currentStates)
				target.add(pair.element2, true);
			if (!sum.equals(target, true))
				throw new IllegalStateException("Transition probability distribution after interruption does not sum to starting values. Sum = " + sum.toStringWithoutTrailingZeros()+ ". Starting sum: " + target.toStringWithoutTrailingZeros());
		
		}

		// Return a pair of the successorT2ActionStates and successorT1MutationStates
		return new Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
				ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>>(successorT2ActionStates, successorT1MutationStates);

	}

	/** Compute the weighted probability of each successor state, given that an agent will 
	 * postpone for a delay of length delayDurationAtStartOfEncounter. This function takes 
	 * into account additional delays due to extrinsic events increasing the Delay duration. 
	 * Moreover, the probability of each successor state is discounted with frequencyOfDelay. 
	 * Finally, if the delay is not directly observable, this function also weights the probability
	 * of each successor state with the probability that the delay will have the specified duration
	 * index.*/
	public Pair<ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStatesForDelayIndex(
			ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates, 
			NumberObjectSingle frequencyOfDelay, 
			int durationIndexBeforeExtrinsicChanges,
			boolean delayIsObservable) {
		
		// Create a new ArrayList to store all resulting State-probability Pairs in
		ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> successorT2ActionStates = new ArrayList<>(); // no interruption
		ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>> successorT1MutationStates = new ArrayList<>(); // interruption
		
		// For each current state s (in stateTransitions):
		for (Pair<T2ActionStateFactory, NumberObjectSingle> sucPair: currentStates) {
		
			// First, if the delay is observable, make sure that the duration index matches the observed index
			if (delayIsObservable)
				if (durationIndexBeforeExtrinsicChanges != sucPair.element1.durationIndexOfEncounteredObservableDelays[delayIndex])
					throw new IllegalArgumentException("Asking for a duration that is not the observed duration");
			
			// Next, the duration might have changed due to extrinsic object events. These
			// changes are deterministic (at least, in this version of the ModelBuilder).
			// Figure out what the duration of the delay is at the moment of performing
			// the action
			int indexOfDurationAfterExtrinsicEvents = model.ledger.objectMutator.getDurationOfDelayAfterTime(delayIndex, durationIndexBeforeExtrinsicChanges, sucPair.element1.timeInEncounter);
			int durationAfterExtrinsic =  model.ledger.delayValues[delayIndex][indexOfDurationAfterExtrinsicEvents];

			// Ask the T2ActionState for all successor states after postponing durationAfterExtrinsic times
			Pair<ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, 
			ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>> successorStatesAfterPostponing = sucPair.element1.origin.successorStatesAfterPostponing(durationAfterExtrinsic, interruptionEvent);

			// Multiply each probability of each successor state with the probability of this sucPair,
			// And store the result into successorT2ActionStates and successorT1MutationStates
			for (Pair<T2ActionStateFactory, NumberObjectSingle> nextActionPair : successorStatesAfterPostponing.element1) 
				successorT2ActionStates.add(new Pair<T2ActionStateFactory, NumberObjectSingle>(
						nextActionPair.element1,
						nextActionPair.element2.multiply(sucPair.element2, false).multiply(frequencyOfDelay, false)
						));
				
			for (Pair<T1MutationStateFactory, NumberObjectSingle> nextMutationPair : successorStatesAfterPostponing.element2)
				successorT1MutationStates.add(new Pair<T1MutationStateFactory, NumberObjectSingle>(
						nextMutationPair.element1,
						nextMutationPair.element2.multiply(sucPair.element2, false).multiply(frequencyOfDelay, false)
						));
			
			// If the delay is not observable, we have to multiply the probability of each successor state with the
			// probability of this particular delay duration
			// If the delay is observable, we do not have to weigh the delay for the probability of the delay having
			// this duration. However, if the delay is not observable, multiple durations are possible. As such, we have to compute,
			// for each possible T2ActionStateFactory, the probability that the delay will have this duration, and multiply
			// all possible successor state's probability with the probability of this delay
			if (!delayIsObservable) {
				NumberObjectSingle posteriorProbabilityDelay = model.beliefs.posteriorBeliefDelayAfterObservingCues(sucPair.element1, delayIndex)[durationIndexBeforeExtrinsicChanges];
				for (Pair<T2ActionStateFactory, NumberObjectSingle> actionSuc : successorT2ActionStates)
					actionSuc.element2.multiply(posteriorProbabilityDelay, true);
				for (Pair<T1MutationStateFactory, NumberObjectSingle> mutationSuc : successorT1MutationStates)
					mutationSuc.element2.multiply(posteriorProbabilityDelay, true);
			}
		}
		
		return new Pair<ArrayList<Pair<T2ActionStateFactory, NumberObjectSingle>>, ArrayList<Pair<T1MutationStateFactory, NumberObjectSingle>>>(
				successorT2ActionStates, successorT1MutationStates);
	}
	
	@Override
	public String toString() {
		if (interruptionIndex == -1)
			return "Postpone [" + delayIndex+ "](\"" + model.ledger.delayNames[delayIndex] + "\")";
		return "Postpone [" + delayIndex+ "](\"" + model.ledger.delayNames[delayIndex] + "\") with interruption [" + interruptionIndex + "](\"" + model.ledger.interruptionNames[interruptionIndex] + "\")";
	}


}
