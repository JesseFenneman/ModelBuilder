package t2Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import actionElements.ActionTemplate;
import actionElements.ActionTemplatePostcondition;
import actionElements.ActionTemplatePrecondition;
import actionInterfacesAndAbstractions.ActionPrecondition;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import helper.Helper.Triplet;
import model.LedgerFactory;
import model.Model;
import stateInterfacesAndAbstractions.Path;
import t1states.T1FitnessState;
import t1states.T1FitnessStateFactory;
import t1states.T1MutationState;
import t1states.T1MutationStateFactory;
import t2states.T2ActionState;
import t2states.T2ActionStateFactory;
import t2states.T2DecisionTree;
import t2states.T2MutationState;
import t2states.T2MutationStateFactory;

public class T2Action {

	private final Model model;
	private final ArrayList<ActionPrecondition> preconditions; 
	private final ArrayList<T2ActionPostcondition> postconditions;
	private final boolean isDelayingAction;
	
	/** Create a T2Action based on the template and the ledgerFactory. Note that this 
	 * function assumes that all resources, phenotypes, interruptions, delays, and extrinsic events
	 * are already registered in the ledgerFactory, and will not be removed or changed.*/
	public T2Action (Model model, LedgerFactory ledgerFactory, ActionTemplate template) {
		this.model = model;
		this.preconditions = new ArrayList<>();
		this.postconditions = new ArrayList<>();
		
		// Step 1: create all the preconditions
		for (ActionTemplatePrecondition preTemplate : template.getAllPreconditions())
			preconditions.add( ActionPrecondition.createPrecondition(preTemplate, ledgerFactory));
		
		// Step 2: create all the postconditions. However,
		// we want to keep the termination, postpone, interruption, consume, and other postconditions separate, as
		// they have different execution orders
		T2ActionPostcondition interruptPostcondition = null;
		T2ActionPostcondition postponePostcondition = null;
		T2ActionPostcondition consumePostcondition = null;
		T2ActionPostcondition terminatePostcondition = null;
		ArrayList<T2ActionPostcondition> otherPostcondition = new ArrayList<>();;
		
		for (ActionTemplatePostcondition postTemplate : template.getPostconditions()) {
			T2ActionPostcondition newPostcondition = T2ActionPostcondition.createT2Postcondition(model, ledgerFactory, postTemplate);
			
			 // If there is a postcondition to sample a cue, add a precondition that the agent
			 // cannot sample more that the maximum number of cues. 
			if (newPostcondition instanceof T2ActionPostconditionSampleResourceCue) {
				int resourceIndex = ((T2ActionPostconditionSampleResourceCue) newPostcondition).resourceIndex;
				int maximumNumber = ledgerFactory.resourceCues.get(resourceIndex).maximumNumberOfTimesAnAgentCanSampleThisCue;
				preconditions.add( new ActionPrecondition.ActionPreconditionHasNotReachedMaximumCuesSampledResource(resourceIndex, maximumNumber) );
			} else if (newPostcondition instanceof T2ActionPostconditionSampleDelayCue) {
				int delayIndex = ((T2ActionPostconditionSampleDelayCue) newPostcondition).delayIndex;
				int maximumNumber = ledgerFactory.delayCues.get(delayIndex).maximumNumberOfTimesAnAgentCanSampleThisCue;
				preconditions.add( new ActionPrecondition.ActionPreconditionHasNotReachedMaximumCuesSampledDelay(delayIndex, maximumNumber) );
			} else if (newPostcondition instanceof T2ActionPostconditionSampleInterruptionCue) {
				int interruptionIndex = ((T2ActionPostconditionSampleInterruptionCue) newPostcondition).interruptionIndex;
				int maximumNumber = ledgerFactory.interruptionCues.get(interruptionIndex).maximumNumberOfTimesAnAgentCanSampleThisCue;
				preconditions.add( new ActionPrecondition.ActionPreconditionHasNotReachedMaximumCuesSampledInterruption(interruptionIndex, maximumNumber) );
			}
			
			
			
			
			if (newPostcondition instanceof T2ActionPostconditionInterrupt)
				interruptPostcondition = newPostcondition;
			else if (newPostcondition instanceof T2ActionPostconditionPostpone)
				postponePostcondition = newPostcondition;
			else if (newPostcondition instanceof T2ActionPostconditionTerminateEncounter)
				terminatePostcondition = newPostcondition;
			else if (newPostcondition instanceof T2ActionPostconditionConsumeResource)
				consumePostcondition = newPostcondition;
			else
				otherPostcondition.add(newPostcondition);
		}
		
		// Step 3: create the ordered ArrayList of all T2ActionPostconditions.
		// The execution order is:
		// 1. Interrupt
		// 2. Postpone
		// 3. All other
		// 4. Consume
		// 5. Terminate
		 if (interruptPostcondition != null) postconditions.add(interruptPostcondition);
		 if (postponePostcondition != null) postconditions.add(postponePostcondition);
		 postconditions.addAll(otherPostcondition);
		 if (consumePostcondition != null) postconditions.add(consumePostcondition);
		 if (terminatePostcondition != null) postconditions.add(terminatePostcondition);
		 
		 // Check if this action is a delaying action; that is, whether there is at least one
		 // waiting or postponing postcondition
		 boolean hasDelayingPost = false;
		 if (postponePostcondition != null)
			 hasDelayingPost = true;
		 else 
			 for (T2ActionPostcondition post : this.postconditions) {
				 if (post instanceof T2ActionPostconditionWait || post instanceof T2ActionPostconditionPostpone)
					 hasDelayingPost = true;
			 } 
		this.isDelayingAction = hasDelayingPost;
	
	}
	
	/** Returns true if and only if all preconditions are met in this state*/
	public boolean isPossibleInState(T2ActionState state) {
		for (ActionPrecondition precondition: preconditions)
			if (!precondition.stateMatchesPrecondition(state))
				return false;
		return true;	
	}
	
	/** Returns true if this action this action contains a 'postpone' or 'wait' postcondition.*/
	public boolean isDelayingAction() {
		return this.isDelayingAction;
	}
	/** Execute this action in this state. This function assumes that an action is indeed
	 * possible in this ActionState, and returns a triplet of three ArrayLists containing:  
	 * 
	 * 1. Paths from this T2ActionState to all T2MutationState an agent will be in if it survives this action.
	 * These are all the T2ActionStates that an agent will end up in after executing this action, including
	 * the probability that an agent ends up in that T1MutationState. Newly created T2MutationStates are 
	 * registered at the T2StateList
	 * 
	 * 2. Path from this state to all T1MutationStates an agent will be in if it survives and this encounter
	 * is terminated (either by termination or by interruption). These resulting states are 
	 * registered in the T1StateList
	 * 
	 * 3. Paths from this state to all T1FitnessStates it will go to if this action kills the agent. Newly
	 * created states are registered at the T1StateList.
	 * */
	public Triplet < 
	ArrayList< Path<T2ActionState, T2MutationState>> ,  
	ArrayList< Path<T2ActionState, T1MutationState>>,
	ArrayList< Path<T2ActionState, T1FitnessState>>   > performAction(T2ActionState state, T2DecisionTree tree){

		if (state == null)
			throw new IllegalArgumentException("Performing action on a null state");


		// Create the array lists where we will store all temporary Action successor states
		// Note that a postconditions both takes and results in ActionStates - that way, postconditions can 
		// be stacked together. At the end we will have to change these ActionStates to either MutationStates or FitnessStates (depending on who died)
		ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>    t2CurrentActionStateFactories = new ArrayList<>();
		ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>  t1SuccessorMutationStateFactories = new ArrayList<>();

		// Add the current state as a SuccessorState with probability 1
		t2CurrentActionStateFactories.add(new Pair<T2ActionStateFactory, NumberObjectSingle>(state.toT2ActionStateFactory(), NumberObject.createNumber(model.howToRepresentNumbers, 1)));

		// Execute all postconditions. Note that the postconditions arraylist is already ordered in the correct
		// ordering (i.e., first interruption, then postpone, then other, then consume, then terminate). 
		for (T2ActionPostcondition pc : postconditions) {
			
			// Sometimes, after performing all previous PC's, there are no more T2ActionFactories left (i.e., when there is a known interruption)
			// If so, we no long have to compute successor states
			if (t2CurrentActionStateFactories.size() == 0)
				break;
			Pair < ArrayList< Pair<T2ActionStateFactory,   NumberObjectSingle>>,
			ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>>  resultingStates = pc.getSuccessorStates(t2CurrentActionStateFactories);
		
			t2CurrentActionStateFactories = resultingStates.element1;
			t1SuccessorMutationStateFactories.addAll(resultingStates.element2);

		}

		// If the model wants us to check everything: makes sure that all possible successor state probabilities sum to 1.
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> pair: t2CurrentActionStateFactories)
				if (pair.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T2 sucessor state after executing all actions has a non-positive probability.");
				else
					sum.add(pair.element2,true);

			for (Pair<T1MutationStateFactory, NumberObjectSingle> pair: t1SuccessorMutationStateFactories )
				if (pair.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to T1 sucessor mutation state after executing all actions has a non-positive probability.");
				else
					sum.add(pair.element2, true);

			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability after action does not sum to 1. Sum:" + sum.toStringWithoutTrailingZeros());
		}

		// At this point, all of the postconditions are applied. Some of the resulting T1 or T2 ActionStatesFactories will give 'birth' to dead states. 
		// Next, we'll turn these factories into actual states, by registering them at the T1StateList (for states that drop out of the encounter
		// or are dead) or a the supplied T2StateList (for T2ActionStates that stay within the encounter). We'll also store these resulting
		// states in Paths, that link a state with the probability of ending up in that state
		ArrayList< Path<T2ActionState, T2MutationState>>  	t2SuccessorMutationStatePaths = new ArrayList<>();
		ArrayList< Path<T2ActionState, T1MutationState>>  	t1SuccessorMutationStatePaths = new ArrayList<>(); 
		ArrayList< Path<T2ActionState, T1FitnessState>>  	t1SuccessorFitnessStatePaths = new ArrayList<>(); // FitnessState is a nice word for saying dead.

		// First, let's create all results from the T1SuccessorStates - that is, all states that drop out of the encounter - and sort them in dead and alive. 
		for (Pair<T1MutationStateFactory, NumberObjectSingle> pair: t1SuccessorMutationStateFactories) {

			// If dead: create a path from this T2ActionState to the corresponding T1FitnessState
			if (pair.element1.resultsInDeadState()) {
				// Create a shallow cloned fitness factory
				T1FitnessStateFactory newFitnessStateFactory = new T1FitnessStateFactory(pair.element1, false);

				// Register that fitness factory at the T1StateList. The list either returns an existing state with the same values (if one exists),
				// or creates a new state with those values. 
				T1FitnessState newFitnessState = model.getT1StateList().getFitnessState(newFitnessStateFactory );

				// Add to results
				t1SuccessorFitnessStatePaths.add( new Path<T2ActionState, T1FitnessState> (state, newFitnessState, pair.element2, model));

				// If not dead: create a Path from this T2ActionState to the corresponding T1MutationState
			} else {
				// Create a shallow cloned mutation factory
				T1MutationStateFactory newMutationStateFactory = new T1MutationStateFactory(pair.element1, false);

				// Register (if necessary) that mutation state factory at the T1StateList, which will turn it into a T1MutationState
				T1MutationState newMutationState = model.getT1StateList().getMutationState(newMutationStateFactory);

				// Add to results
				t1SuccessorMutationStatePaths.add(new Path<T2ActionState, T1MutationState> ( state, newMutationState, pair.element2, model));
			}
		}


		// Second, do the same for the T2SuccessorStates - i.e., states that do not end the encounter. Note that a dead T2SuccessorState is still a T1State
		// Thus far these states are still stores as T2ActionStateFactories. We first have to turn them into T2MutationStateFactories
		for (Pair<T2ActionStateFactory, NumberObjectSingle> pair: t2CurrentActionStateFactories) {
			T2MutationStateFactory t2MutationStateFactory = pair.element1.toT2MutationStateFactory();

			// Will this factory result in a dead state? If yes; make a T1FitnessState
			if (t2MutationStateFactory.resultsInDeadState()) {
				// Create a shallow cloned fitness factory
				T1FitnessStateFactory newFitnessStateFactory = new T1FitnessStateFactory(pair.element1, false);

				// Register (if necessary) that fitness factory at the T1StateList, which will turn it into a T1FitnessState
				T1FitnessState newFitnessState = model.getT1StateList().getFitnessState(newFitnessStateFactory );

				// Add to results
				t1SuccessorFitnessStatePaths.add( new Path<T2ActionState, T1FitnessState> (state, newFitnessState, pair.element2, model));
			} else {

				// Register (if necessary) that T2mutation state factory at the T2StateList, which will turn it into a T2MutationState
				T2MutationState newMutationState = tree.treeStateList.getMutationState(t2MutationStateFactory);

				// Add to results
				t2SuccessorMutationStatePaths.add(new Path<T2ActionState, T2MutationState> ( state, newMutationState, pair.element2,model));
			}
		}
		// If the model is strict again, do a test to see if all successor state probabilities sum to 1.
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber (0);
			for (Path<T2ActionState, T2MutationState> p : t2SuccessorMutationStatePaths)
				if (p.weight.smallerThanOrEqualTo(0, true))
					throw new IllegalStateException("After action: Transition to successor T2 mutation state factory after acting has a non-positive probability.");
				else
					sum.add(p.weight, true);

			for (Path<T2ActionState, T1MutationState> p : t1SuccessorMutationStatePaths)
				if (p.weight.smallerThanOrEqualTo(0, true))
					throw new IllegalStateException("After action: Transition to successor T1 mutation state factory after acting has a non-positive probability.");
				else
					sum.add(p.weight, true);

			for (Path<T2ActionState, T1FitnessState> p : t1SuccessorFitnessStatePaths)
				if (p.weight.smallerThanOrEqualTo(0, true))
					throw new IllegalStateException("After action: Transition to successor T1 fitness state factory after acting has a non-positive probability.");
				else
					sum.add(p.weight, true);

			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability after action binning does not sum to 1. Sum = " + sum.toStringWithoutTrailingZeros());
		}
		
		// Now we have all Paths from this T2ActionState to all possible successor state. 
		// However, we have to many paths now: there can be duplicate paths. That is, 
		// a single action can have two or more paths that result in the same outcome. 
		// This occurs often (but not only) when a state has a maximum or minimum phenotype. 
		// In that case, most actions will result in the agent reaching the bound, 
		// which then results in multiple paths to the same destination. An example might
		// clear this up. Suppose that an agent has a phenotype "A" with level 5, out of a 
		// maximum 5. It consume a resource which can only be positive. This resource has
		// 5 possible values. However, all five values result in the agent still having 
		// a phenotype of 5. As such, there will be 5 outgoing paths, all from the same state
		// to the same destination state. 

		// First, get unique paths for the T2SuccesorMutationStates
		ArrayList< Path<T2ActionState, T2MutationState>> t2SuccessorMutationStateUniquePaths = new ArrayList<>(t2SuccessorMutationStatePaths.size());
		for (Path<T2ActionState, T2MutationState> originalPath : t2SuccessorMutationStatePaths) {		
			// See if there already is a path with the same destination in t2SuccessorMutationStateUniquePaths.
			// If so, add the weight if this path to the weight of the path already in t2SuccessorMutationStateUniquePaths.
			// After that, continue with the next original path
			boolean alreadyInUnique = false;
			for (Path<T2ActionState, T2MutationState> uniquePath : t2SuccessorMutationStateUniquePaths) {

				if (uniquePath.destination == originalPath.destination) {	

					alreadyInUnique = true;
					uniquePath.weight.add(originalPath.weight, true);
					continue;
				}
			}
			// If there is not yet a path with the same destination, add this one:
			if (!alreadyInUnique) 
				t2SuccessorMutationStateUniquePaths.add(originalPath);

		}
		
		
		// Second, also met unique paths for the T1SuccesorMutationStates
		ArrayList< Path<T2ActionState, T1MutationState>> t1SuccessorMutationStateUniquePaths = new ArrayList<>(t1SuccessorMutationStatePaths.size());
		for (Path<T2ActionState, T1MutationState> originalPath : t1SuccessorMutationStatePaths) {
			boolean alreadyInUnique = false;
			for (Path<T2ActionState, T1MutationState> uniquePath : t1SuccessorMutationStateUniquePaths) {
				if (uniquePath.destination == originalPath.destination) {
					alreadyInUnique = true;
					uniquePath.weight.add(originalPath.weight, true);
					continue;
				}
			}
			if (!alreadyInUnique)
				t1SuccessorMutationStateUniquePaths.add(originalPath);

		}

		// Third and finally, do the same for the T1SuccesorFitnessStates
		ArrayList< Path<T2ActionState, T1FitnessState>> t1SuccessorFitnessStateUniquePaths = new ArrayList<>(t1SuccessorFitnessStatePaths.size());
		for (Path<T2ActionState, T1FitnessState> originalPath : t1SuccessorFitnessStatePaths) {
			boolean alreadyInUnique = false;
			for (Path<T2ActionState, T1FitnessState> uniquePath : t1SuccessorFitnessStateUniquePaths) {
				if (uniquePath.destination == originalPath.destination) {
					alreadyInUnique = true;
					uniquePath.weight.add(originalPath.weight, true);
					continue;
				}
			}
			if (!alreadyInUnique)
				t1SuccessorFitnessStateUniquePaths.add(originalPath);

		}

		// And a final check: If the model is strict again, make sure that all probabilities equal to 1
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber (0);
			for (Path<T2ActionState, T2MutationState> p : t2SuccessorMutationStateUniquePaths)
				if (p.weight.smallerThanOrEqualTo(0, true))
					throw new IllegalStateException("After action: Transition to unique successor T2 mutation state factory after acting has a non-positive probability.");
				else
					sum.add(p.weight, true);

			for (Path<T2ActionState, T1MutationState> p : t1SuccessorMutationStateUniquePaths)
				if (p.weight.smallerThanOrEqualTo(0, true))
					throw new IllegalStateException("After action: Transition to unique successor T1 mutation state factory after acting has a non-positive probability.");
				else
					sum.add(p.weight, true);

			for (Path<T2ActionState, T1FitnessState> p : t1SuccessorFitnessStateUniquePaths)
				if (p.weight.smallerThanOrEqualTo(0, true))
					throw new IllegalStateException("After action: Transition to unique successor T1 fitness state factory after acting has a non-positive probability.");
				else
					sum.add(p.weight, true);

			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability after action does not sum to 1 when making the path's unqiue (Note, they were unique beforehand!). Sum = " + sum.toStringWithoutTrailingZeros());
		}
	
		// Finally, return a triplet containing all the unique paths
		Triplet < 
		ArrayList< Path<T2ActionState, T2MutationState>> ,  
		ArrayList< Path<T2ActionState, T1MutationState>>,
		ArrayList< Path<T2ActionState, T1FitnessState>>   > result = new Triplet<>(t2SuccessorMutationStateUniquePaths,t1SuccessorMutationStateUniquePaths,t1SuccessorFitnessStateUniquePaths );
		
		// Return result
		return result;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		for (int i = 0; i < preconditions.size(); i++) {	
			sb.append(preconditions.get(i));
			if (i != (preconditions.size()-1) && preconditions.size() > 1)
				sb.append(" & ");
		}
		sb.append("}  -->  {");


		for (int i = 0; i < postconditions.size(); i++) {	
			sb.append(postconditions.get(i));
			if (i != (postconditions.size()-1) && postconditions.size() > 1)
				sb.append(" & ");
		}

		sb.append("}");
		return sb.toString();
	}
}
