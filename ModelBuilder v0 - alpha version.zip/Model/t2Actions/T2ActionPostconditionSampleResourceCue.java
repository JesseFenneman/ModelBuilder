package t2Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import abstractNumberObjectsAndInterfaces.NumberObject.NumberObjectIncorrectRepresentationException;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import model.Model;
import t1states.T1MutationStateFactory;
import t2states.T2ActionStateFactory;

public class T2ActionPostconditionSampleResourceCue extends T2ActionPostcondition {

	// Which resource do we sample a cue for?
	public final int resourceIndex;

	private final Model model;

	public T2ActionPostconditionSampleResourceCue(Model model, int resourceIndex) {
		this.model = model;
		this.resourceIndex = resourceIndex;
	}

	@Override
	public String getName() {
		return "Sample cue resource [" + resourceIndex + "]"; 
	}
	
	@Override
	public Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
    			  ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates){
		if (model.performSafetyChecks)
			if (currentStates.size() == 0)
				throw new IllegalArgumentException("Calling action postcondition sample resource with an empty currentState list");
		
		// Create a new ArrayList to store all resulting State-probability Pairs in
		ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> successorStates = new ArrayList<>();

		// For each current state s (in stateTransitions):
		for (Pair<T2ActionStateFactory, NumberObjectSingle> sucPair: currentStates) {
			
			// Figure out what the emission probability of each cue label is in this state
			// This cue emission probability depends on the agent's posterior belief, which in turn depends on what
			// cues the agent already observed. These probabilities are precomputed by the Beliefs object
			NumberObjectSingle[] cueEmissionProbabilities = model.beliefs.probabilityOfNextResourceCueAfterObservingCues(sucPair.element1, resourceIndex);

			// For each possible label the cue can have...
			for (int cl = 0; cl < cueEmissionProbabilities.length; cl++) {
		
				// No need to do anything if this cannot happen!
				if (cueEmissionProbabilities[cl].equals(0, true))
					continue;
				
				// Create a deep cloned factory with the same values
				T2ActionStateFactory factory = new T2ActionStateFactory(sucPair.element1, true);

				// Increase the cueSet: the agent now sampled one more resource cue. This cue had a label of cl
				factory.resourceCues[resourceIndex][cl]++;
				
				// Calculate the total probability that the agent sampled this cue. 
				// This probability is [probability of being in the currentState] * [probability of cue in the current state]
				NumberObjectSingle newProbability = sucPair.element2.multiply(cueEmissionProbabilities[cl], false);
				
				// Place the resulting factory in the successorState ArrayList.
				successorStates.add(new Pair<T2ActionStateFactory, NumberObjectSingle>( factory, newProbability));

			}
		}

		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to the starting probability
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> p: successorStates)
				if (!NumberObject.matchesNumberObjectRepresentation(p.element2, model.howToRepresentNumbers))
					throw new NumberObjectIncorrectRepresentationException("Incorrect number format.");
				else if (p.element2.smallerThan(0, true))
					throw new IllegalStateException("Transition to sucessor state after sampling resource cue has a non-positive probability.");
				else
					sum.add(p.element2, true);
			
			DecimalNumber target = new DecimalNumber(0);
			for (Pair<T2ActionStateFactory, NumberObjectSingle> pair : currentStates)
				target.add(pair.element2, true);
			if (!sum.equals(target, true))
				throw new IllegalStateException("Transition probability distribution after interruption does not sum to starting values. Sum = " + sum.toStringWithoutTrailingZeros()+ ". Starting sum: " + target.toStringWithoutTrailingZeros());
		
		}

		// Create a new Pair of ArrayLists. The first of which is the successorStates list. 
		// The second list is null - there are no possible T1MutationStates after this postcondition.
		return new Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
		  	              ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>>(successorStates, new ArrayList<>());	
	}

	
	@Override
	public String toString() {
		return "Sample cue on resource[" + resourceIndex + "](\"" + model.ledger.resourceNames[resourceIndex] + "\")";
	}

}