package t2Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper.Pair;
import model.Model;
import t1states.T1MutationStateFactory;
import t2states.T2ActionStateFactory;

/** Do nothing. */
public class T2ActionPostconditionWait extends T2ActionPostcondition{

	private final Model model;
	public T2ActionPostconditionWait(Model model) {
		this.model = model;
	}
	@Override
	public String getName() {
		return "Wait"; 
	}
	
	@Override
	public Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
    			  ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>> currentStates){
		if (model.performSafetyChecks)
			if (currentStates.size() == 0)
				throw new IllegalArgumentException("Calling action postcondition wait with an empty currentState list");
		
		return new Pair < ArrayList< Pair<T2ActionStateFactory, NumberObjectSingle>>,
	  			  ArrayList< Pair<T1MutationStateFactory, NumberObjectSingle>>>(currentStates, new ArrayList<>());
	}

	@Override
	public String toString() {
		return "Wait";
	} 
	
}