package actionInterfacesAndAbstractions;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import actionElements.ActionTemplatePrecondition;
import actionElements.ActionTemplatePrecondition.Operator;
import actionElements.ActionTemplatePreconditionLocation;
import actionElements.ActionTemplatePreconditionPhenotype;
import actionElements.ActionTemplatePreconditionResourceAccepted;
import actionElements.ActionTemplatePreconditionResourceEncountered;
import actionElements.ActionTemplatePreconditionTimeCycle;
import actionElements.ActionTemplatePreconditionTimeLife;
import model.Ledger;
import model.LedgerFactory;
import spatialAndTemporalElements.PatchStateTemplate;
import t1states.T1AbstractState;
import t2states.T2AbstractState;


/** A precondition is a condition that a state must fulfill before 
 * an action can be taken. It is created through the View's 
 * ActionTemplatePrecondition.
 * 
 * There are 6 possible preconditions:
 * 	- ActionPreconditionPhenotype (phenotype has to be a certain value);
 *  - ActionPreconditionLocation (location has to be a certain PATCH);
 *  - ActionPreconditionAge (age has to be a certain value)
 *  - ActionPreconditionCycleTime (the time step in an encounter has to be certain value. T2States only!)
 *  - ActionPreconditionEncounteredResource (a certain resource has to be encountered or not encountered. T2States only!)
 *  - ActionPreconditionConsumedResource (a certain resource has to be encountered or not encountered. T2States only!)
 *  */
public abstract class ActionPrecondition {

	/** Returns true if the T1State fulfills this precondition*/
	public abstract boolean stateMatchesPrecondition(T1AbstractState s);
	
	/** Returns true if the T2State fulfills this precondition*/
	public abstract boolean stateMatchesPrecondition(T2AbstractState s);
	
	public abstract String toString();

	/** Create an ActionPrecondition based on the specified Template*/
	public static ActionPrecondition createPrecondition(ActionTemplatePrecondition template, LedgerFactory ledgerFactory) {

		// Create a ActionPreconditionPhenotype
		if (template instanceof ActionTemplatePreconditionPhenotype) {
			ActionTemplatePreconditionPhenotype phenotypeTemplate = (ActionTemplatePreconditionPhenotype) template;

			// Find the phenotypeIndex
			int phenotypeIndex = -1;
			for (int i =0; i < ledgerFactory.phenotypeNames.size(); i ++)
				if (ledgerFactory.phenotypeNames.get(i).equals(phenotypeTemplate.getSubject().getName()))
					phenotypeIndex = i;
			if (phenotypeIndex == -1)
				throw new IllegalStateException("Trying to create an action precondition for a phenotype that is not registered (yet). Looking for name " + template.getSubject().getName());

			// Find the target value
			int targetIndex = -1;
			for (int i = 0; i < ledgerFactory.phenotypeValues.get(phenotypeIndex).length; i ++)
				if (ledgerFactory.phenotypeValues.get(phenotypeIndex)[i].equals((NumberObjectSingle) template.getTarget()))
					targetIndex = i;
			if (targetIndex == -1)
				throw new IllegalStateException("Trying to create an action precondition for a phenotype value that is not registered (yet). Looking for value: " + ((NumberObjectSingle) template.getTarget()).toStringWithoutTrailingZeros() );

			return new ActionPreconditionPhenotype(phenotypeIndex, template.getOperator(), targetIndex);
		}


		// Create a ActionPreconditionLocation
		if (template instanceof ActionTemplatePreconditionLocation) {
			ActionTemplatePreconditionLocation locationTemplate = (ActionTemplatePreconditionLocation) template;

			// Find the patchIndex
			int patchIndex = -1;
			for (int i =0; i < ledgerFactory.patchNames.size(); i ++)
				if (ledgerFactory.patchNames.get(i).equals( ((PatchStateTemplate) locationTemplate.getTarget()).getName()   ))
					patchIndex = i;
			if (patchIndex == -1)
				throw new IllegalStateException("Trying to create an action precondition for a location condition that is not registered (yet). Looking for patch name " 
						+ ((PatchStateTemplate) locationTemplate.getTarget()).getName());

			// Figure out if the agent has to be in the location, or not be in the location
			boolean hasToBe = false;
			if (template.getOperator() == Operator.EQUALS)
				hasToBe = true;
			else if (template.getOperator() == Operator.DOES_NOT_EQUAL)
				hasToBe = false;
			else 
				throw new IllegalStateException("Trying to create an action precondition for a location, but the operator is neither EQUALS or NOT_EQUALS.");
			return new ActionPreconditionLocation(patchIndex, hasToBe);
		}


		// Create a ActionPreconditionAge
		if (template instanceof ActionTemplatePreconditionTimeLife) {
			ActionTemplatePreconditionTimeLife ageTemplate = (ActionTemplatePreconditionTimeLife) template;

			// The target of an age-precondition is already in an integer form - no need to change anything :)
			int target = (Integer) ageTemplate.getTarget();

			// Same for the operator. Easy life is easy. 
			Operator operator = ageTemplate.getOperator();

			return new ActionPreconditionAge(operator, target);
		}


		// Create a ActionPreconditionCycleTime
		if (template instanceof ActionTemplatePreconditionTimeCycle) {
			ActionTemplatePreconditionTimeCycle cycleTimeTemplate = (ActionTemplatePreconditionTimeCycle) template;

			// The target of an cycleTime-precondition is already in an integer form - no need to change anything :)
			int target = (Integer) cycleTimeTemplate.getTarget();

			// Same for the operator. Easy life is easy. 
			Operator operator = cycleTimeTemplate.getOperator();

			return new ActionPreconditionCycleTime(operator, target);
		}


		// Create a ActionPreconditionEncounteredResource
		if (template instanceof ActionTemplatePreconditionResourceEncountered) {
			ActionTemplatePreconditionResourceEncountered resourceTemplate = (ActionTemplatePreconditionResourceEncountered) template;

			// Find the resourceIndex (subject)
			int resourceIndex = -1;
			for (int i =0; i < ledgerFactory.resourceNames.size(); i ++)
				if (ledgerFactory.resourceNames.get(i).equals( resourceTemplate.getSubject().getName()   ))
					resourceIndex = i;
			if (resourceIndex == -1)
				throw new IllegalStateException("Trying to create an action resource encountered precondition for a resource that is not registered (yet). Looking for resource name " 
						+ resourceTemplate.getSubject().getName());

			// Figure out if the agent has to have encountered, or not encountered, the resource
			boolean hasToBe = false;
			if (template.getOperator() == Operator.TRUE)
				hasToBe = true;
			else if (template.getOperator() == Operator.FALSE)
				hasToBe = false;
			else 
				throw new IllegalStateException("Trying to create an action precondition for a encountered resource, but the operator is neither TRUE or FALSE.");
			return new ActionPreconditionEncounteredResource(resourceIndex, hasToBe);
		}

		// Create a ActionPreconditionConsumedResource
		if (template instanceof ActionTemplatePreconditionResourceAccepted) {
			ActionTemplatePreconditionResourceAccepted resourceTemplate = (ActionTemplatePreconditionResourceAccepted) template;

			// Find the resourceIndex (subject)
			int resourceIndex = -1;
			for (int i =0; i < ledgerFactory.resourceNames.size(); i ++)
				if (ledgerFactory.resourceNames.get(i).equals( resourceTemplate.getSubject().getName()   ))
					resourceIndex = i;
			if (resourceIndex == -1)
				throw new IllegalStateException("Trying to create an action resource consumed precondition for a resource that is not registered (yet). Looking for resource name " 
						+ resourceTemplate.getSubject().getName());

			// Figure out if the agent has to have consumed, or not yet consumed, the resource
			boolean hasToBe = false;
			if (template.getOperator() == Operator.TRUE)
				hasToBe = true;
			else if (template.getOperator() == Operator.FALSE)
				hasToBe = false;
			else 
				throw new IllegalStateException("Trying to create an action precondition for a consumed resource, but the operator is neither TRUE or FALSE.");
			return new ActionPreconditionConsumedResource(resourceIndex, hasToBe);
		}

		throw new IllegalStateException("Trying to create a precondition of unknown type");
	}

	/** Create an ActionPrecondition based on the specified Template*/
	/*public static ActionPrecondition createPrecondition(ActionTemplatePrecondition template, Ledger ledger) {

		// Create a ActionPreconditionPhenotype
		if (template instanceof ActionTemplatePreconditionPhenotype) {
			ActionTemplatePreconditionPhenotype phenotypeTemplate = (ActionTemplatePreconditionPhenotype) template;

			// Find the phenotypeIndex
			int phenotypeIndex = ledger.getIndexOfPhenotype(phenotypeTemplate.getSubject().getName());
			
			// Find the target value
			int targetIndex = -1;
			for (int i = 0; i < ledger.phenotypeValues[phenotypeIndex].length; i ++)
				if (ledger.phenotypeValues[phenotypeIndex][i].equals((NumberObjectSingle) template.getTarget()))
					targetIndex = i;
			if (targetIndex == -1)
				throw new IllegalStateException("Trying to create an action precondition for a phenotype target value that does not exist in this model. Value: " + ((NumberObjectSingle) template.getTarget()).toStringWithoutTrailingZeros() );

			return new ActionPreconditionPhenotype(phenotypeIndex, template.getOperator(), targetIndex);
		}


		// Create a ActionPreconditionLocation
		if (template instanceof ActionTemplatePreconditionLocation) {
			ActionTemplatePreconditionLocation locationTemplate = (ActionTemplatePreconditionLocation) template;

			// Find the patchIndex
			int patchIndex = -1;
			for (int i =0; i < ledger.patchNames.length; i ++)
				if (ledger.patchNames[i].equals( ((PatchStateTemplate) locationTemplate.getTarget()).getName()   ))
					patchIndex = i;
			if (patchIndex == -1)
				throw new IllegalStateException("Trying to create an action precondition for a location condition that does not exist in this model. Looking for patch name " 
						+ ((PatchStateTemplate) locationTemplate.getTarget()).getName());

			// Figure out if the agent has to be in the location, or not be in the location
			boolean hasToBe = false;
			if (template.getOperator() == Operator.EQUALS)
				hasToBe = true;
			else if (template.getOperator() == Operator.DOES_NOT_EQUAL)
				hasToBe = false;
			else 
				throw new IllegalStateException("Trying to create an action precondition for a location, but the operator is neither EQUALS or NOT_EQUALS.");
			return new ActionPreconditionLocation(patchIndex, hasToBe);
		}


		// Create a ActionPreconditionAge
		if (template instanceof ActionTemplatePreconditionTimeLife) {
			ActionTemplatePreconditionTimeLife ageTemplate = (ActionTemplatePreconditionTimeLife) template;

			// The target of an age-precondition is already in an integer form - no need to change anything :)
			int target = (Integer) ageTemplate.getTarget();

			// Same for the operator. Easy life is easy. 
			Operator operator = ageTemplate.getOperator();

			return new ActionPreconditionAge(operator, target);
		}


		// Create a ActionPreconditionCycleTime
		if (template instanceof ActionTemplatePreconditionTimeCycle) {
			ActionTemplatePreconditionTimeCycle cycleTimeTemplate = (ActionTemplatePreconditionTimeCycle) template;

			// The target of an cycleTime-precondition is already in an integer form - no need to change anything :)
			int target = (Integer) cycleTimeTemplate.getTarget();

			// Same for the operator. Easy life is easy. 
			Operator operator = cycleTimeTemplate.getOperator();

			return new ActionPreconditionCycleTime(operator, target);
		}


		// Create a ActionPreconditionEncounteredResource
		if (template instanceof ActionTemplatePreconditionResourceEncountered) {
			ActionTemplatePreconditionResourceEncountered resourceTemplate = (ActionTemplatePreconditionResourceEncountered) template;

			// Find the resourceIndex (subject)
			int resourceIndex = ledger.getIndexOfResourceType(resourceTemplate.getSubject().getName()  );
			
			// Figure out if the agent has to have encountered, or not encountered, the resource
			boolean hasToBe = false;
			if (template.getOperator() == Operator.TRUE)
				hasToBe = true;
			else if (template.getOperator() == Operator.FALSE)
				hasToBe = false;
			else 
				throw new IllegalStateException("Trying to create an action precondition for a encountered resource, but the operator is neither TRUE or FALSE.");
			return new ActionPreconditionEncounteredResource(resourceIndex, hasToBe);
		}

		// Create a ActionPreconditionConsumedResource
		if (template instanceof ActionTemplatePreconditionResourceAccepted) {
			ActionTemplatePreconditionResourceAccepted resourceTemplate = (ActionTemplatePreconditionResourceAccepted) template;

			// Find the resourceIndex (subject)
			int resourceIndex = ledger.getIndexOfResourceType(resourceTemplate.getSubject().getName()  );

			// Figure out if the agent has to have consumed, or not yet consumed, the resource
			boolean hasToBe = false;
			if (template.getOperator() == Operator.TRUE)
				hasToBe = true;
			else if (template.getOperator() == Operator.FALSE)
				hasToBe = false;
			else 
				throw new IllegalStateException("Trying to create an action precondition for a consumed resource, but the operator is neither TRUE or FALSE.");
			return new ActionPreconditionConsumedResource(resourceIndex, hasToBe);
		}

		throw new IllegalStateException("Trying to create a precondition of unknown type");
	}*/
	
	/** A precondition that holds if the specified non-age phenotypic dimensions has some value*/
	public static class ActionPreconditionPhenotype extends ActionPrecondition {
		private final int phenotypeIndex, target;
		private final Operator operator;

		public ActionPreconditionPhenotype(int phenotypeIndex, Operator operator, int target) {
			this.phenotypeIndex = phenotypeIndex;
			this.target = target;
			this.operator = operator;
		}

		@Override
		public boolean stateMatchesPrecondition(T1AbstractState s) {
			int stateValue = s.getPhenotypeValue(phenotypeIndex);

			switch (operator) {
			case EQUALS: 				return stateValue == target;
			case DOES_NOT_EQUAL:		return stateValue != target;
			case GREATER_THAN:			return stateValue > target;
			case SMALLER_THAN:			return stateValue < target;
			case GREATER_OR_EQUAL_THAN:	return stateValue >= target;
			case SMALLER_OR_EQUAL_THAN:	return stateValue <= target;
			default:					throw new IllegalStateException("Unknown operator for phenotype precondition");
			}
		}

		@Override
		public String toString() {
			return "(Phenotype ["+phenotypeIndex+"] " + operator + " value ["+ target + "])";
		}

		
		@Override
		public boolean stateMatchesPrecondition(T2AbstractState s) {
			int stateValue = s.getPhenotypeValue(phenotypeIndex);

			switch (operator) {
			case EQUALS: 				return stateValue == target;
			case DOES_NOT_EQUAL:		return stateValue != target;
			case GREATER_THAN:			return stateValue > target;
			case SMALLER_THAN:			return stateValue < target;
			case GREATER_OR_EQUAL_THAN:	return stateValue >= target;
			case SMALLER_OR_EQUAL_THAN:	return stateValue <= target;
			default:					throw new IllegalStateException("Unknown operator for phenotype precondition");
			}
		}

	}

	/** A precondition that holds if the agent is, or is not, at a PATCH location */
	public static class ActionPreconditionLocation extends ActionPrecondition {
		private final int patchIndex;
		private final boolean hasToBe;

		/** To perform this action, an agent either has to be in a location (hasToBe==true)
		 * or not be in a location (hasToBe == false). IMPORTANT: ASKING FOR PATCH INDEX,
		 * NOT THE PATCHSTATEINDEX!*/
		public ActionPreconditionLocation(int patchIndex, boolean hasToBe) {
			this.patchIndex = patchIndex; this.hasToBe = hasToBe;
		}

		@Override
		public boolean stateMatchesPrecondition(T1AbstractState s) {
			return ( ( s.getLocationPatch() == patchIndex ) ==  hasToBe );
		}

		@Override
		public boolean stateMatchesPrecondition(T2AbstractState s) {
			return ( ( s.getLocationPatch() == patchIndex ) ==  hasToBe );
		}
		
		@Override
		public String toString() {
			if (hasToBe)
				return "(location == patch ["+patchIndex + "])";
			return "(location != patch ["+patchIndex + "])";
		}
	}

	/** A precondition that holds if the age is some value*/
	public static class ActionPreconditionAge extends ActionPrecondition {
		private final int target;
		private final Operator operator;

		public ActionPreconditionAge( Operator operator, int target) {
			this.target = target; this.operator = operator;
		}

		@Override
		public boolean stateMatchesPrecondition(T1AbstractState s) {

			int stateValue = s.getAge();

			switch (operator) {
			case EQUALS: 				return stateValue == target;
			case DOES_NOT_EQUAL:		return stateValue != target;
			case GREATER_THAN:			return stateValue > target;
			case SMALLER_THAN:			return stateValue < target;
			case GREATER_OR_EQUAL_THAN:	return stateValue >= target;
			case SMALLER_OR_EQUAL_THAN:	return stateValue <= target;
			default:					throw new IllegalStateException("Unknown operator for age precondition");
			}
		}

		@Override
		public boolean stateMatchesPrecondition(T2AbstractState s) {

			int stateValue = s.getAge();

			switch (operator) {
			case EQUALS: 				return stateValue == target;
			case DOES_NOT_EQUAL:		return stateValue != target;
			case GREATER_THAN:			return stateValue > target;
			case SMALLER_THAN:			return stateValue < target;
			case GREATER_OR_EQUAL_THAN:	return stateValue >= target;
			case SMALLER_OR_EQUAL_THAN:	return stateValue <= target;
			default:					throw new IllegalStateException("Unknown operator for age precondition");
			}
		}
		
		@Override
		public String toString() {
			return "(Age " + operator + " "+ target + ")";
		}
	}

	/** A precondition that holds if the time in the cycle is some value. Note:
	 * throws an IllegalStateException if the state is not a T2 state.*/
	public static class ActionPreconditionCycleTime extends ActionPrecondition {
		private final int target;
		private final Operator operator;

		public ActionPreconditionCycleTime( Operator operator, int target) {
			this.target = target; this.operator = operator;
		}

		@Override
		public String toString() {
			return "(Cycle time " + operator + " "+ target + ")";
		}

		@Override
		public boolean stateMatchesPrecondition(T1AbstractState s) {return false;	}

		@Override
		public boolean stateMatchesPrecondition(T2AbstractState s) {
			

			int stateValue = s.timeInEncounter;

			switch (operator) {
			case EQUALS: 				return stateValue == target;
			case DOES_NOT_EQUAL:		return stateValue != target;
			case GREATER_THAN:			return stateValue > target;
			case SMALLER_THAN:			return stateValue < target;
			case GREATER_OR_EQUAL_THAN:	return stateValue >= target;
			case SMALLER_OR_EQUAL_THAN:	return stateValue <= target;
			default:					throw new IllegalStateException("Unknown operator for age precondition");
			}
		}
	}

	/** A precondition that holds if an agent has encountered (hasToBe==true) or did not
	 * encounter (hasToBe==false) the specified resource. Note:
	 * throws an IllegalStateException if the state is not a T2 state.*/
	public static class ActionPreconditionEncounteredResource extends ActionPrecondition {
		private final int resourceIndex;
		private final boolean hasToBe;

		/** To perform this action, an agent either has to have encountered a resource of type (hasToBe==true)
		 * or not have encountered that resource (hasToBe == false). */
		public ActionPreconditionEncounteredResource(int resourceIndex, boolean hasToBe) {
			this.resourceIndex = resourceIndex; this.hasToBe = hasToBe; 
		}

		@Override
		public boolean stateMatchesPrecondition(T1AbstractState s) {	return false; }

		@Override
		public boolean stateMatchesPrecondition(T2AbstractState s) {	
			return ( s.hasEncounteredResourceType(resourceIndex) ==  hasToBe );
		}
		
		@Override
		public String toString() {
			if (hasToBe)
				return "(encountered resource ["+resourceIndex + "])";
			return "(not encountered resource ["+resourceIndex+ "])";
		}
	}

	/** A precondition that holds if an agent has consumed (hasToBe==true) or did not
	 * yet consume (hasToBe==false) the specified resource. Note:
	 * throws an IllegalStateException if the state is not a T2 state.*/
	public static class ActionPreconditionConsumedResource extends ActionPrecondition {
		private final int resourceIndex;
		private final boolean hasToBe;

		/** To perform this action, an agent either has to have encountered a resource of type (hasToBe==true)
		 * or not have encountered that resource (hasToBe == false). */
		public ActionPreconditionConsumedResource(int resourceIndex, boolean hasToBe) {
			this.resourceIndex = resourceIndex; this.hasToBe = hasToBe; 
		}

		@Override
		public boolean stateMatchesPrecondition(T1AbstractState s) {	return false;	}

		@Override
		public boolean stateMatchesPrecondition(T2AbstractState s) {
			return ( s.hasConsumedResourceType(resourceIndex) ==  hasToBe );
		}
		
		@Override
		public String toString() {
			if (hasToBe)
				return "(consumed resource ["+resourceIndex + "])";
			return "(not consumed resource ["+resourceIndex+ "])";
		}

	}
	
	/** A precondition that holds if an agent has sampled less then the maximum number of cues it can 
	 * sample for this resource */
	public static class ActionPreconditionHasNotReachedMaximumCuesSampledResource extends ActionPrecondition {
		private final int resourceIndex;
		private final int maximumNumber;

		public ActionPreconditionHasNotReachedMaximumCuesSampledResource(int resourceIndex, int maximumNumberOfCues) {
			this.resourceIndex = resourceIndex; this.maximumNumber = maximumNumberOfCues;		}

		@Override
		public boolean stateMatchesPrecondition(T1AbstractState s) {	return false;	}

		@Override
		public boolean stateMatchesPrecondition(T2AbstractState s) {
			int total = 0;
			for (int i : s.resourceCueSet(resourceIndex))
				total += i;
			
			return ( total < maximumNumber);
		}
		
		@Override
		public String toString() {
			return "(samples less than " + maximumNumber + " cues on resource ["+resourceIndex+ "])";
		}
	}
	
	/** A precondition that holds if an agent has sampled less then the maximum number of cues it can 
	 * sample for this delay */
	public static class ActionPreconditionHasNotReachedMaximumCuesSampledDelay extends ActionPrecondition {
		private final int delayIndex;
		private final int maximumNumber;

		public ActionPreconditionHasNotReachedMaximumCuesSampledDelay (int delayIndex, int maximumNumberOfCues) {
			this.delayIndex = delayIndex; this.maximumNumber = maximumNumberOfCues;		}

		@Override
		public boolean stateMatchesPrecondition(T1AbstractState s) {	return false;	}

		@Override
		public boolean stateMatchesPrecondition(T2AbstractState s) {
			int total = 0;
			for (int i : s.delayCueSet(delayIndex))
				total += i;
			
			return ( total < maximumNumber);
		}
		
		@Override
		public String toString() {
			return "(samples less than " + maximumNumber + " cues on delay ["+delayIndex+ "])";
		}
	}
	
	/** A precondition that holds if an agent has sampled less then the maximum number of cues it can 
	 * sample for this interruption */
	public static class ActionPreconditionHasNotReachedMaximumCuesSampledInterruption extends ActionPrecondition {
		private final int interruptionIndex;
		private final int maximumNumber;

		public ActionPreconditionHasNotReachedMaximumCuesSampledInterruption (int interruptionIndex, int maximumNumberOfCues) {
			this.interruptionIndex = interruptionIndex; this.maximumNumber = maximumNumberOfCues;		}

		@Override
		public boolean stateMatchesPrecondition(T1AbstractState s) {	return false;	}

		@Override
		public boolean stateMatchesPrecondition(T2AbstractState s) {
			int total = 0;
			for (int i : s.interruptionCueSet(interruptionIndex))
				total += i;
			
			return ( total < maximumNumber);
		}
		
		@Override
		public String toString() {
			return "(samples less than " + maximumNumber + " cues on interruption ["+interruptionIndex+ "])";
		}
	}
}
