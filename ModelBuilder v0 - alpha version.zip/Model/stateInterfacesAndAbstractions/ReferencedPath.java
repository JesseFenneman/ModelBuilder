package stateInterfacesAndAbstractions;

import java.io.Serializable;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper;
import model.Model;
import t1states.T1AbstractStateReference;
import t2states.T2AbstractState;

/** A ReferencedPath is a Path where the destination is not yet a State, but rather, 
 * a reference to a State. ReferencedPaths can only be used between T2AbstractStates (origin)
 * and T1AbstractStateReferences (destination). */
public class ReferencedPath <O extends T2AbstractState, D extends T1AbstractStateReference> implements Serializable  {
	private static final long serialVersionUID = Helper.programmeVersion;
	
	public final O origin;
	public final D destination;
	public final NumberObjectSingle weight;
	
	public final String annotation;
	
	public ReferencedPath (O origin, D destination, NumberObjectSingle weight, String annotation, Model model) {
		this.origin = origin;
		this.destination = destination;
		this.weight = weight;
		this.annotation = annotation;
		
		if (model.performSafetyChecks)
			if (weight.smallerThan(0, true))
				throw new IllegalStateException("Created path with a weight smaller than 0");
			else if (weight.largerThan(1, true))
				throw new IllegalStateException("Created path with a weight larger than 1");
			else if (weight.equals(0))
				throw new IllegalStateException("Created path with 0 probability");
	}
	
	
	
	
}
