package stateInterfacesAndAbstractions;

/** <pre>
 * An State is the fundamental unit of this program. Specifically, it describes the state
 * of an agent. (It's called an State because the agent can take an action in this state -
 * in contrast to a MutationState, where 'nature' changes the state of the agent)
 * 
 * An STATE consists of:
 * A. an agent's age;
 * B. an agent's location;
 * C. how long it has been since an agent has visited a patch
 * E. what state each patch was in when an agent last visited that patch
 * F. an agent's phenotype (which consists of one field for each non-age phenoptypic dimension); 
 * G. an agent's experience (which consists of one field for each unique combination of {object type, patch state, and object value};
 * H. during a resource encounter, the number of cues it has sampled in that encounter (one field for all possible cue label of a resource, delay, or interruption); and
 * I. whether an agent is current in an encounter, or between encounters.
 * 
 * The set of all possible states grows exponentially with age phenotypic dimension, patch states, resource types, and cues.
 * Moreover, many states are functionally identical. For instance, if an agent is not in an encounter, all states that vary
 * on the number of cues sampled are functionally identical (i.e., they are state aliasses). Moreover, during an encounter
 * an agent's experiences never change.  
 * 
 * We can reduce complexity substantially
 * by splitting the number of states in two sets: T1 (tier 1) states and T2 (tier 2) states. 
 * 
 * T1 states are the states an agent can be in between encounters. 
 * T2 (tier two) states are states an agent can be in during an encounter. 
 * 
 * The advantage is that for T1 states we do not have to keep track of points E and F. 
 * 
 * All values in a state are integer values. What these integer values actually
 * means (e.g., what is a resource value of '4'?) is stored in the Ledger. Typically, however,
 * we do not need to use actual values (e.g., "2.3"), but rather, we can use the integer
 * representation of this value (e.g., 4). See the explanation above the Ledger class for a 
 * more in-depth explanation.
 * 
 * In a T1 states an agent can move between patches, search for resources, and generally perform all kinds
 * of pre-specified between-encounter actions. However, because there is no encounter, we do not have
 * to keep track of cues in these states.  Hence, there are four main components to a T1 state:
 * 
 * 1. An agent's age. Stored as an integer. 
 * 
 * 2. An agent's location. Specifically, an integer value that signifies in what patch-state 
 * an agent currently is. The ledger holds the conversion from the index position to a patch-state name.
 * However, in practise you rarely need to know the actual name. 
 * 
 * 3. A phenotype. Specifically, an array of size n that contains only integer values. N is the
 * number of non-age phenotypic dimensions in the model. For instance, if an agent has a 'health'
 * and a 'children' phenotypic dimension, the phenotype is an array of 2 integers. The order of the
 * phenotypic dimensions is stored in the ledger. The integers refer 
 * to an actual value in the Ledger. The order of the phenotypes in this array is also stored in the Ledger.
 * 
 * 4. A set of experiences. Specifically, a 3 dimensional array of integers, where:
 * 		- the first dimension corresponds to a a resource type;
 * 		- the second dimension corresponds to a patch state; and
 * 		- the third dimension corresponds to a value.
 * For instance, suppose an agent has seen 5 times a resource 'resourceA' with a value of '3.25' in patch 'base'.
 * After consulting the ledger, we know that 'resourceA' corresponds to an index position of 2; '3.25' is stored
 * at position 25, and the base patch is stored at index position 1. The experience array at location [2][28][1]
 * is then an integer of value 5. Note that an agent only has to keep track of its experiences for the 
 * objects that are not fixed, and where the distribution is not known (or in other words, where the user explicitly
 * specified that the distribution has to be learned from experience).
 */
public interface State {

	
	// All the attributes that are unique to this state.
	/** Returns the age of the agent in this state.*/
	public abstract int getAge();
	
	/** Returns the integer stored at the i'th phenotype. What the i'th phenotype is,
	 * or what value the resulting integer represents can be found by using the Ledger's
	 * getNameOfPhenotypeIndex(int index). */
	public abstract int getPhenotypeValue(int phenotypeIndex);
	
	/** Returns the integer representing the current location (patch state). What PatchState 
	 * this integer refers to can be found in the Ledger (by using getNameOfPatchState())*/
	public abstract int getLocationPatchState();
	
	/** Returns the integer representing the current location (patch). What Patch 
	 * this integer refers to can be found in the Ledger (by using getNameOfPatch())*/
	public abstract int getLocationPatch();
	
	/** Returns the number of time steps that have passed since an agent in this State visited 
	 * the patch index. Which patch this index refers to is specified in the Ledger. */
	public abstract int timeStepsSinceLastVisit (int patchIndex);
	
	// NOT IMPLEMENTED YET 
	/** Returns the index of the state the patch was in when an agent in this State visited
	 * the specified patch Returns -1 if the agent never visited the state yet.*/
	//public abstract int patchStateDuringLastVisit (int patchIndex);
	/** Returns the number of times an agent in this state has seen a resource with that value in that patch state.*/
	//public abstract int getResourceExperiences(int patchStateIndex, int resourceIndex, int valueIndex);
	
	/** Returns the number of times an agent in this state has seen a resource with that value in that patch state.*/
	//public abstract int getExtrinsicExperiences(int patchStateIndex, int extrinsicIndex, int valueIndex);
	
	/** Returns the number of times an agent in this state has seen a resource with that value in that patch state.*/
	//public abstract int getDelayExperiences(int patchStateIndex, int delayIndex, int valueIndex);
	
	/** Returns the number of times an agent in this state has seen a resource with that value in that patch state.*/
	//public abstract int getInterruptionExperiences(int patchStateIndex, int interruptionIndex, int valueIndex);
	
	public String getName();
	
}
