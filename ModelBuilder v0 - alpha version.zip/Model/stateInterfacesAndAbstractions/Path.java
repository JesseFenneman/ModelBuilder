package stateInterfacesAndAbstractions;

import java.io.Serializable;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper;
import model.Model;

/** A path is a connection between two states, the origin (O) and the destination (D). Each
 * path is weighted with a NumberObjectSingle, which represents the probability that an agent
 * in state O goes over this path to D. There is also an additional StringBuilder, called Labels,
 * that can be used to add annotations to this path (e.g., what kind of action or mutation results
 * in this path)*/
public class Path <O extends State, D extends State> implements Serializable {
	
	private static final long serialVersionUID = Helper.programmeVersion;
	
	public final O origin;
	public final D destination;
	public final NumberObjectSingle weight;
	
	public final String annotation;
	
	public Path (O origin, D destination, NumberObjectSingle weight, String annotation, Model model) {
		this.origin = origin;
		this.destination = destination;
		this.weight = weight;
		this.annotation = annotation;
		
		if (model.performSafetyChecks)
			if (weight.smallerThan(0, true))
				throw new IllegalStateException("Created path with a weight smaller than 0");
			else if (weight.largerThan(1, true))
				throw new IllegalStateException("Created path with a weight larger than 1");
			else if (weight.equals(0))
				throw new IllegalStateException("Created path with 0 probability");
	}
	
	public Path (O origin, D destination, NumberObjectSingle weight, Model model) {
		this (origin, destination, weight, "", model);
	}
	
	/** Only print the destination and probability. Used for printing the T1StateList*/
	public String toDestinationString() {
		return destination.getName()+" (p=" + weight.toStringWithoutTrailingZeros()+")";
		
	}
	
	/** Only print the destination and probability. Used for printing the T1StateList. Probabilities are expressed in numberOfDigits significant digits.*/
	public String toDestinationString(int numberOfDigits) {
		return destination.getName()+" (p=" + weight.toString(numberOfDigits)+")";
		
	}
	
	
	/** Only print the destination, probability, and annotation. Used for printing the T1StateList*/
	public String toDestinationStringIncludingAnnotation() {
		return destination.getName()+" (p=" + weight.toStringWithoutTrailingZeros()+", \"" + annotation+ "\")";
		
	}
	
	/** Only print the destination, probability, and annotation. Used for printing the T1StateList. Probabilities are expressed in numberOfDigits significant digits.*/
	public String toDestinationStringIncludingAnnotation(int numberOfDigits) {
		return destination.getName()+" (p=" + weight.toString(numberOfDigits)+", \"" + annotation+ "\")";
		
	}
	
	/** Only print the Origin and probability. Used for printing the T1StateList*/
	public String toOriginString() {
		return origin.getName()+" (p=" + weight.toStringWithoutTrailingZeros()+")";
		
	}
}
