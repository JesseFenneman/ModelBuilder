package t1states;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper;
import helper.Helper.Pair;
import stateInterfacesAndAbstractions.Path;

/** A State BETWEEN ENCOUNTERS where an agent will experience all mutations.
 * A MutationState is a State where an agent does not take any action. 
 * Each ActionState is followed by a MutationState, and each MutationState
 * is followed by either a DeathState, or any number of (0+) of ActionStates.
 * 
 * In essence, a MutationState is a pass-through state, where the Mutations
 * are applied in between actions.*/
public class T1MutationState extends T1AbstractState {

	private static final long serialVersionUID = Helper.programmeVersion;
	
	/** All Outgoing connections to action states*/
	public final ArrayList<Path<T1MutationState, T1ActionState>> successorT1ActionStates; 
	
	/** All Outgoing connections to fitness states*/
	public final ArrayList<Path<T1MutationState, T1FitnessState>> successorT1FitnessStates; 
	
	protected T1MutationState(T1AbstractStateFactory factory, int stateNumber) {
		super(factory, factory.model.performSafetyChecks);
		if (getModel().performSafetyChecks)
			if (factory.resultsInDeadState())
				throw new IllegalStateException("Creating a dead T1MutationState");


		this.successorT1ActionStates = new ArrayList<>();
		this.successorT1FitnessStates = new ArrayList<>();
		this.setID( stateNumber);
		this.setName("T1M-" +this.getID()+"-" + age+"-"+ locationPatchState);
	}
	
	///////////////////////////////////////////////////////////////////////
	//////////////////////// Tree building functions /////////////////////
	/////////////////////////////////////////////////////////////////////
	
	

	/** Tells this MutationState to compute all possible Paths that link this state to a successor state.
	 * Specifically, it asks the StateMutator to apply all mutations to this state. This function has to be executed before any
	 * call to getSuccessorStates. */
	@Override
	public void doForwardsPass() {
		if (wentThroughForwardsPass)
			return;
		
		// Get the StateMutator to mutate this state, which results in a Pair of ArrayLists containing the resulting
		// T1ActionStates and T1FitnessStates
		Pair < 
		ArrayList< Path<T1MutationState, T1ActionState>>,  
		ArrayList< Path<T1MutationState, T1FitnessState>>   > resultingPaths = getModel().ledger.stateMutator.mutateT1State(this);
		
		this.successorT1ActionStates.addAll(resultingPaths.element1);
		this.successorT1FitnessStates.addAll(resultingPaths.element2);
		
		// If the Model wants us to, perform a safety check to make sure that the origin in all new Paths is indeed this state
		if (getModel().performSafetyChecks) {
			for (Path<T1MutationState, T1ActionState> path : resultingPaths.element1)
				if (path.origin != this)
					throw new IllegalStateException("Created a successor state Path for a T1MutationState where the origin in the Path is not this state");
			for (Path<T1MutationState, T1FitnessState> path : resultingPaths.element2)
				if (path.origin != this)
					throw new IllegalStateException("Created a successor state Path for a T1MutationState where the origin in the Path is not this state");
		}
		
		// This node is now expanded
		wentThroughForwardsPass = true;
		
	}
	
	/** Returns all Paths between this state and a successor state after taking the action, 
	 * and the agent is still alive.
	 * 
	 * Any call to this function must be preceded by a call to computeSuccessorStates().*/
	public ArrayList<Path<T1MutationState, T1ActionState>> getSuccessorT1ActionPaths() {return successorT1ActionStates;}
	
	/** Returns all Paths between this state and a successor state after taking the action, 
	 * and the agent is dead.
	 * 
	 * Any call to this function must be preceded by a call to computeSuccessorStates().*/
	public ArrayList<Path<T1MutationState, T1FitnessState>> getSuccessorT1FitnessPaths() {return successorT1FitnessStates;}
	
	/** Returns an ArrayList of all T1 states an agent can be in after all mutations are applied.*/
	public ArrayList<T1AbstractState> getSuccessorT1States(){
		ArrayList<T1AbstractState> result = new ArrayList<>();
		for (Path<T1MutationState,   T1ActionState> path : this.successorT1ActionStates)
			result.add(path.destination);
		for (Path<T1MutationState,   T1FitnessState> path : this.successorT1FitnessStates)
			result.add(path.destination);
		return result;
	}
	
	/** Returns an ArrayList of all T1ActionStates an agent can be in after all mutations are applied.*/
	public ArrayList<T1ActionState> getSuccessorT1ActionStates(){
		ArrayList<T1ActionState> result = new ArrayList<>();
		for (Path<T1MutationState,   T1ActionState> path : this.successorT1ActionStates)
			result.add(path.destination);
		return result;
	}

	/** Computes the expected fitness of entering this T1MutationState. Specifically, 
	 * its computes the expected fitness, the expected age until death, the expected 
	 * phenotype, and the expected future T1 and T2 actions it will take.
	 * 
	 * The expected fitness is calculated as:
	 * 		[ SUM over all successor T1FitnessStates fs: fitness(fs) * Pr(fs|s) ] +
	 * 		[ SUM over all successor T2ActionStates  T2as: fitness(T2as) * Pr(T2as|s) ] +
	 * 		[ SUM over all successor T2ActionStates  T1as: fitness(T1as) * Pr(T1as|s) ] 
	 *
	 * Where s is the current state, and Pr(x|s) is the transition probability of 
	 * going to x from s.
	 * 
	 * The expected age and phenotypes are similarly computed as the expected fitness.
	 * 
	 * Note that the expect number of future actions is defined as:
	 * 	 	expectedNumberOfFutureT2ActionsInThisTree = SUM over all successor T2 action states: 
	 * 				expectedFutureT2Actions(state) + immediateAction(state)
	 * 		expectedFutureT2Actions = SUM over all successor T1 + T2 action states: 
	 * 				expectedFutureT2Actions(state) + immediateAction(state)
	 * 		expectedFutureT1Actions = [SUM over all successor action states T1 + T2 states:
	 * 				expectedFutureT2Actions(state) + immediateAction(state)]
	 * 	
	 * */
	@Override
	public void doBackwardsPass(boolean printToConsole) {
		// Keep track of both the weighted sum (which is the fitness), and, for testing purposes, the totalProbability.
		NumberObjectSingle totalProbability = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		
		// Create a temporary storage for all the expected fields, and set all values to 0
		NumberObjectSingle tempExpectedFitness = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle tempExpectedAge = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle tempExpectedTimeDelay = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		
		NumberObjectSingle[] tempExpectedPhenotype = new NumberObjectSingle[getModel().ledger.numberOfNonAgePhenotypicDimensions];
		for (int i = 0; i < getModel().ledger.numberOfNonAgePhenotypicDimensions; i++) tempExpectedPhenotype[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT1Actions = new NumberObjectSingle[getModel().ledger.numberOfT1Actions];
		for (int i = 0; i < getModel().ledger.numberOfT1Actions; i++) tempExpectedNumberOfFutureT1Actions[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT2Actions = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];
		for (int i = 0; i < getModel().ledger.numberOfT2Actions; i++) tempExpectedNumberOfFutureT2Actions[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);
	
		// First, for each possible T1Fitness state s' that result from this mutation state:
		// multiply the expectedFitness of s' with the probability of going to s',
		// and add the result to this state's expectedFitness field.
		// Do the same for actions and phenotypes. (Don't have to do it for future actions,
		// as there never are any future actions of T1FitnessStates)
		for (Path<T1MutationState,   T1FitnessState> path : successorT1FitnessStates) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);

			tempExpectedFitness.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
			tempExpectedAge    .add(path.weight.multiply( path.destination.getExpectedAge(),     false), true);
			tempExpectedTimeDelay .add(path.weight.multiply( path.destination.getExpectedTotalTimeStepsInDelay(),     false), true);
			
			for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
				tempExpectedPhenotype[p].add(path.weight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
		}

		// Second, so the same for all possible T1ActionStates. However, now we also have to keep track of
		// all possible future T1 and T2 actions that an agent will take in its lifetime from this moment on.
		// Note: this includes the action that an agent will take in that action state as well.
		for (Path<T1MutationState,   T1ActionState> path : successorT1ActionStates) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);

			// Here we do things a little bit different for expectedNumberOfFutureT1Actions....
			// First, do all the other fields
			tempExpectedFitness.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
			tempExpectedAge    .add(path.weight.multiply( path.destination.getExpectedAge(),     false), true);
			tempExpectedTimeDelay .add(path.weight.multiply( path.destination.getExpectedTotalTimeStepsInDelay(),     false), true);
			
			for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
				tempExpectedPhenotype[p]                 .add(path.weight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
			
			// The following T1ActionState cannot take any immediate T2 actions.
			// As such, the expected future T2 actions of this T1MutationState is the weighted
			// average over all successor T1 ActionStates's number of future T2 actions.
			for (int t2a = 0 ; t2a < this.getModel().ledger.numberOfT2Actions; t2a ++)
				tempExpectedNumberOfFutureT2Actions[t2a] .add(path.weight.multiply( path.destination.getFutureTimesItPerformsT2Action(t2a), false), true);
		
			// However, the next state will take a T1Action. As such, the number of future T1Actions of this 
			// T1MutationState is the weighted average of the action that successor state will take, plus all
			// T1 actions will follow after the successor state.
			for (int t1a = 0 ; t1a < this.getModel().ledger.numberOfT1Actions; t1a ++) {
				// Add all the future actions of the next state (i.e., the actions that an agent will take after that T1ActionState)
				tempExpectedNumberOfFutureT1Actions[t1a].add(path.weight.multiply( path.destination.getFutureTimesItPerformsT1Action(t1a), false), true);
			
				// Add the action taken in the next state as well
				tempExpectedNumberOfFutureT1Actions[t1a].add(path.weight.multiply( path.destination.getProbabilityOfImmediateAction(t1a), false), true);
			}
		}

		if (getModel().performSafetyChecks)
			if (!totalProbability.equals(1, true))
				throw new IllegalStateException("T1Mutation state after backwards pass: sum of all paths did not equal 1. Total sum = " + totalProbability.toStringWithoutTrailingZeros());

		// Make all the expected... fields immutable
		this.setExpectedFitness(tempExpectedFitness);
		this.setExpectedAge(tempExpectedAge);
		this.setExpectedTotalTimeStepsInDelay(tempExpectedTimeDelay);
		this.setExpectedPhenotype(tempExpectedPhenotype);
		this.setExpectedNumberOfFutureT1Actions(tempExpectedNumberOfFutureT1Actions);
		this.setExpectedNumberOfFutureT2Actions(tempExpectedNumberOfFutureT2Actions);
		
		// And that concludes the backwards pass
		if (getModel().performSafetyChecks)
			this.checkIfBackwardsFieldsAreValid();
		this.wentThroughBackwardsPass = true;
	}

	/** Create an MutationStateFactory preset with the same values as in this MutationState*/
	public T1MutationStateFactory toT1MutationStateFactory() {
		return new T1MutationStateFactory(this);
	}

	///////////////////////////////////////////////////////////////
	//////////////////////// Other functions /////////////////////
	/////////////////////////////////////////////////////////////
	
	@Override
	public int hashCode() {
		return T1AbstractState.generateHash(this);
	}
	
	/** A T1MutationStateFactory and T1MutationStates are equal if they have the same phenotype, and past experiences with the patch. The
	 * age and current location do not matter - we will states in separate hashmaps for each age and location. */
	public boolean equals(T1MutationStateFactory other) {
		if (other == null)	return false;
		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p]) 
				return false;
		
		for (int s = 0; s < this.lastVisitToPatch.length; s++)
			if (other.lastVisitToPatch[s] != this.lastVisitToPatch[s]) 
				return false;
			else if (other.patchStateOfLastVisit[s] != this.patchStateOfLastVisit[s])
				return false;
		
		return true;
	}
	
	/** A T1MutationStateFactory and T1MutationStates are equal if they have the same phenotype, and past experiences with the patch. The
	 * age and current location do not matter - we will states in separate hashmaps for each age and location. */
	public boolean equals(T1MutationState other) {
		if (other == null)	return false;
		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p]) 
				return false;
		
		for (int s = 0; s < this.lastVisitToPatch.length; s++)
			if (other.lastVisitToPatch[s] != this.lastVisitToPatch[s]) 
				return false;
			else if (other.patchStateOfLastVisit[s] != this.patchStateOfLastVisit[s])
				return false;
		
		return true;
	}
	
	@Override 
	public boolean equals(Object o) {
		if (o == null)
			return false;
		
		if (o.getClass() == T1MutationState.class)
			return (equals((T1MutationState) o));
		if (o.getClass() == T1MutationStateFactory.class)
			return (equals((T1MutationStateFactory) o));
		return false;
	}
	
	/** When loading T2DecisionTrees to disk, we need to connect the decision tree back 
	 * to the rest of the model. To make this process easier, each T1AbstractState can be transformed to a
	 * T1StateReference, which can be stored in dependently from this T1AbstractState. The
	 * T1StateList can then use this reference to retrieve this T1AbstractState. */
	public T1MutationStateReference toT1StateReference() {
		return new T1MutationStateReference (this.getName(), this.age, this.locationPatchState);
	}
	
}
