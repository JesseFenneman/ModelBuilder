package t1states;

import java.io.Serializable;

import helper.Helper;

/** If the user wants, the program will save all T2DecisionTree's to disk between the forwards and 
 * backwards pass. This substantially saves on RAM costs, but also increases the algorithms runtime. 
 * However, after loading a T2DecisionTree from disk, we need to 'reconnect' it to the rest of the model.
 * Sometimes this reconnecting is easy; for instance, we can declared fields like the Model transient, and
 * replace it after loading. Other times it is harder. For instance, T2States might connect to a specific 
 * T1AbstractState. To make this connection possible, the T2AbstractState class keeps a reference (i.e., a name)
 * for which T1AbstractState it connects to. This name can then be used by the T1StateList to look up the 
 * corresponding T1Abstract State. To make this process more efficient, we also want to know in which CannonicalStateMap
 * the T1StateList should search (i.e., age, location, and type; action, mutation, or fitness). This information is all
 * stored in a T1StateReference. */
public abstract class T1AbstractStateReference implements Serializable {
	private static final long serialVersionUID = Helper.programmeVersion;
	
	public final String name;
	public final int age;
	public final int patchStateLocation;
	
	protected T1AbstractStateReference(String name, int age, int patchStateLocation) {
		this.name = name;
		this.age = age;
		this.patchStateLocation = patchStateLocation;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		T1AbstractStateReference other = (T1AbstractStateReference) obj;
	
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
	
		return true;
	}
}
