package t1states;

/** All fields in a State are final. This makes it annoying to
 * create a state s' that is almost identical to a state s. To 
 * make such almost-cloning easier, a StateFactory has the same
 * fields as the corresponding State type, but all fields are 
 * non-final. After changing this Factory, a new State can be 
 * easily constructed using build().*/
public class T1ActionStateFactory extends T1AbstractStateFactory {

	public T1ActionStateFactory(T1AbstractState s) {
		super(s);
	}
	/** Clone all fields in the existing T1StateFactory to create a new T1StateFactory. 
	 * Fields can be copied by reference (deepClone == false) or by value (deepClone == true)*/
	public T1ActionStateFactory(T1AbstractStateFactory f, boolean deepClone) {
		super(f, deepClone);
	}

	/** Create a ActionState based on this Factory*/
	protected T1ActionState buildT1ActionState(int stateNumber) {
		return new T1ActionState(this, stateNumber);
	}

	/** Create a shallow cloned MutationStateFactory with the same values as this StateFactory. Shallow clones the fields. */
	public T1MutationStateFactory toT1MutationStateFactory() {
		return new T1MutationStateFactory(this, false);
	}

	/** Create a shallow cloned FitnessStateFactory with the same values as this StateFactory. Shallow clones the fields. */
	public T1FitnessStateFactory toT1FitnessStateFactory() {
		return new T1FitnessStateFactory(this, false);
	}

	@Override
	public int hashCode() {
		return T1AbstractState.generateHash(this);
	}
	
	/** A T1AbstractStateFactory and T1AbstractStates are equal if they have the same phenotype, and past experiences with the patch. The
	 * age and current location do not matter - we will states in separate hashmaps for each age and location. */
	public boolean equals(T1ActionStateFactory other) {
		if (other == null)	return false;
		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p]) 
				return false;
		
		for (int s = 0; s < this.lastVisitToPatch.length; s++)
			if (other.lastVisitToPatch[s] != this.lastVisitToPatch[s]) 
				return false;
			else if (other.patchStateOfLastVisit[s] != this.patchStateOfLastVisit[s])
				return false;
		
		return true;
	}
	
	/** A T1AbstractStateFactory and T1AbstractStates are equal if they have the same phenotype, and past experiences with the patch. The
	 * age and current location do not matter - we will states in separate hashmaps for each age and location. */
	public boolean equals(T1ActionState other) {
		if (other == null)	return false;
		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p]) 
				return false;
		
		for (int s = 0; s < this.lastVisitToPatch.length; s++)
			if (other.lastVisitToPatch[s] != this.lastVisitToPatch[s]) 
				return false;
			else if (other.patchStateOfLastVisit[s] != this.patchStateOfLastVisit[s])
				return false;
		
		return true;
	}
	
	@Override 
	public boolean equals(Object o) {
		if (o == null)
			return false;
		
		if (o.getClass() == T1ActionState.class)
			return (equals((T1ActionState) o));
		if (o.getClass() == T1ActionStateFactory.class)
			return (equals((T1ActionStateFactory) o));
		return false;
	}

	public String toString() {
		return super.toString("T1ActionStateFactory");
	}
	
	
}
