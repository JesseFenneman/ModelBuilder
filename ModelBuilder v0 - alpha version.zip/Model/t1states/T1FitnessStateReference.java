package t1states;

public class T1FitnessStateReference extends T1AbstractStateReference {

	protected T1FitnessStateReference(String name, int age) {
		super(name, age,-1);
	}

}
