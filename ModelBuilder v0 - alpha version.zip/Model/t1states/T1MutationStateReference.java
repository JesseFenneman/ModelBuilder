package t1states;

public class T1MutationStateReference extends T1AbstractStateReference {

	protected T1MutationStateReference(String name, int age, int patchStateLocation) {
		super(name, age, patchStateLocation);
	}

}
