package t1states;

import java.util.concurrent.Callable;

import interfaces_abstractions.ObserverManager;

/** The T1MutationStateExpander is used during the FORWARD pass of the 
 * T1 decision tree. It takes a T1MutationState s and computes
 * the the resulting T1ActionStates after all mutations are applied. 
 * 
 * This is a relatively simple task. However, there might be many different
 * T1MutationStates that have to be expanded at the same time. As such, it
 * is often faster to use multi-threading to expand all T1MutationStates (mostly
 * because we are using multi-threading anyway for the T1ActionStates). In
 * contrast to the T1ActionStateExpander, a T1MutationStateExpander does not
 * provide any feedback to the console. 
 * */
public class T1MutationStateExpander implements Callable<Void> {

	private final T1MutationState state;
	
	public T1MutationStateExpander(T1MutationState s) {
		this.state = s;
	}
	
	@Override
	public Void call() throws Exception {
		try {
		// Compute all the successor states. Yes, that's it; nothing else to do here
		state.doForwardsPass();
		} catch (Exception e) {
			ObserverManager.notifyObserversOfError(e);
			state.getModel().outputFileManager.writeExceptionToFile(e);
		}
		return null;
	}



}
