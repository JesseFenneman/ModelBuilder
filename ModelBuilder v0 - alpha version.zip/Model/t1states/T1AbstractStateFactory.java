package t1states;

import helper.Helper;
import model.Model;
/** States have many fields, which makes it annoying to 
 * create them via a usual constructor. Especially so if we
 * want to create a new state that is based on a previous state
 * but has one difference (e.g., if only the age increases).
 * Hence this Factory pattern; this factory can be passed to a state
 * during construction.*/
public class T1AbstractStateFactory {
	public final Model model;

	public int age;
	public int locationPatchState;
	public int locationPatch;
	public int[] lastVisitToPatch; // [location]
	public int[] patchStateOfLastVisit; // patch
	public int[] phenotype;
	
	public int[][][] resourceExperiences; 		
	public int[][][] extrinsicExperiences; 		
	public int[][][] interruptionExperiences;   
	public int[][][] delayExperiences; 		

	
	/** Construct a factory with all fields null or -1.  */
	public T1AbstractStateFactory(Model model) {
		this.model = model;
		age = -1;
		locationPatchState = -1;
		locationPatch = -1;
		lastVisitToPatch = null;
		patchStateOfLastVisit = null;
		phenotype= null;
		resourceExperiences = null;
		extrinsicExperiences = null;
		delayExperiences = null;
		interruptionExperiences = null;
	}
	
	/** Clone all fields in the existing T1StateFactory to create a new T1StateFactory. 
	 * Fields can be copied by reference (deepClone == false) or by value (deepClone == true)*/
	public T1AbstractStateFactory (T1AbstractStateFactory factory, boolean deepClone) {
		model = factory.model;
		age = factory.age;
		
		// Copy primitives
		locationPatchState = factory.locationPatchState;
		locationPatch = factory.locationPatch;
		
		if (!deepClone) {
			// Copy by reference
			lastVisitToPatch = factory.lastVisitToPatch;
			patchStateOfLastVisit = factory.patchStateOfLastVisit;
			phenotype = factory.phenotype;
			resourceExperiences = factory.resourceExperiences;
			extrinsicExperiences = factory.extrinsicExperiences;
			interruptionExperiences = factory.interruptionExperiences;
			delayExperiences = factory.delayExperiences;	
		} else {
			// Deepclone all arrays
			if (factory.lastVisitToPatch==null)
				lastVisitToPatch = null;
			else {
				lastVisitToPatch = new int[factory.lastVisitToPatch.length];
				System.arraycopy(factory.lastVisitToPatch, 0, lastVisitToPatch, 0, factory.lastVisitToPatch.length);
			}
			if (factory.patchStateOfLastVisit == null)
				patchStateOfLastVisit = null;
			else{
				patchStateOfLastVisit = new int[factory.patchStateOfLastVisit.length];
				System.arraycopy(factory.patchStateOfLastVisit, 0, patchStateOfLastVisit, 0, factory.patchStateOfLastVisit.length);
			}

			if (factory.phenotype == null)
				phenotype = null;
			else {
				phenotype = new int[factory.phenotype.length];
				System.arraycopy(factory.phenotype, 0, phenotype, 0, factory.phenotype.length);
			}

			// Copy experiences- NOT IMPLEMENTED YET 
			/*
			resourceExperiences = new int[factory.resourceExperiences.length][][];
			extrinsicExperiences = new int[factory.extrinsicExperiences.length][][];
			interruptionExperiences = new int[factory.interruptionExperiences.length][][];
			delayExperiences = new int[factory.delayExperiences.length][][];
			
			for (int patch = 0; patch < resourceExperiences.length; patch++) {
				
				for (int resource = 0; resource < resourceExperiences[patch].length; resource++)
					System.arraycopy(factory.resourceExperiences[patch][resource], 		0, resourceExperiences[patch][resource], 		0, factory.resourceExperiences[patch][resource].length);
				
				for (int extrinsic = 0; extrinsic < extrinsicExperiences[patch].length; extrinsic++)
					System.arraycopy(factory.extrinsicExperiences[patch][extrinsic], 	0, extrinsicExperiences[patch][extrinsic], 	0, factory.extrinsicExperiences[patch][extrinsic].length);
				
				for (int interruption = 0; interruption < interruptionExperiences[patch].length; interruption++)
					System.arraycopy(factory.interruptionExperiences[patch][interruption], 	0, interruptionExperiences[patch][interruption],	0, factory.interruptionExperiences[patch][interruption].length);
				
				for (int delay = 0; delay < delayExperiences[patch].length; delay ++)
					System.arraycopy(factory.delayExperiences[patch][delay], 		0, delayExperiences[patch][delay], 		0, factory.delayExperiences[patch][delay].length);
			}*/
		}
	}
	
	/** Set all fields in the factory to match the specified T1State (all fields are deep clones). */
	public T1AbstractStateFactory (T1AbstractState s) {
		model = s.getModel();
		age = s.age;
		locationPatchState = s.locationPatchState;
		locationPatch = s.locationPatch;
		
		lastVisitToPatch = new int[s.lastVisitToPatch.length];
		System.arraycopy(s.lastVisitToPatch, 0, lastVisitToPatch, 0, s.lastVisitToPatch.length);
		
		patchStateOfLastVisit = new int[s.patchStateOfLastVisit.length];
		System.arraycopy(s.patchStateOfLastVisit, 0, patchStateOfLastVisit, 0, s.patchStateOfLastVisit.length);
		
		phenotype = new int[s.phenotype.length];
		System.arraycopy(s.phenotype, 0, phenotype, 0, s.phenotype.length);
		
		// Copy experiences - not implemented yet
		/*resourceExperiences = new int[s.resourceExperiences.length][][];
		extrinsicExperiences = new int[s.extrinsicExperiences.length][][];
		interruptionExperiences = new int[s.interruptionExperiences.length][][];
		delayExperiences = new int[s.delayExperiences.length][][];
		
		for (int patch = 0; patch < resourceExperiences.length; patch++) {
			
			for (int resource = 0; resource < resourceExperiences[patch].length; resource++)
				System.arraycopy(s.resourceExperiences[patch][resource], 		0, resourceExperiences[patch][resource], 		0, s.resourceExperiences[patch][resource].length);
			
			for (int extrinsic = 0; extrinsic < extrinsicExperiences[patch].length; extrinsic++)
				System.arraycopy(s.extrinsicExperiences[patch][extrinsic], 	0, extrinsicExperiences[patch][extrinsic], 	0, s.extrinsicExperiences[patch][extrinsic].length);
			
			for (int interruption = 0; interruption < interruptionExperiences[patch].length; interruption++)
				System.arraycopy(s.interruptionExperiences[patch][interruption], 	0, interruptionExperiences[patch][interruption],	0, s.interruptionExperiences[patch][interruption].length);
			
			for (int delay = 0; delay < delayExperiences[patch].length; delay ++)
				System.arraycopy(s.delayExperiences[patch][delay], 		0, delayExperiences[patch][delay], 		0, s.delayExperiences[patch][delay].length);
		}
		*/
		
	}

	/** Set the age. Returns this.*/
	public T1AbstractStateFactory setAge(int age) { this.age = age; return this;}
	
	/** Increments the age with one. Returns this.*/
	public T1AbstractStateFactory incrementAge() { this.age++; return this;}
	
	/** Set the patch state location. Returns this.*/
	public T1AbstractStateFactory setLocation(int locationPatch, int locationPatchState) { 
		this.locationPatch = locationPatch; this.locationPatchState = locationPatchState; return this;
		}
	
	/** Set the time steps since last visit to patchIndex. Returns this.*/
	public T1AbstractStateFactory setTimeSinceLastVisit(int patchIndex, int timeSteps) { lastVisitToPatch[patchIndex] = timeSteps; return this;}
	
	/** Set the time steps since last visit to patchIndex to 0. Returns this.*/
	public T1AbstractStateFactory resetTimeSinceLastVisit(int patchIndex) { lastVisitToPatch[patchIndex] = 0; return this;}

	/** Initialized the time steps since last visit array, and sets the value for all patches to -1. 
	 * Also initializes the last-seen state for each patches to an array of -1's.
	 * Returns this.*/
	public T1AbstractStateFactory initializePatchHistory() { 
		this.lastVisitToPatch = new int[model.ledger.numberOfPatches];
		this.patchStateOfLastVisit = new int[model.ledger.numberOfPatches];
		for (int patchIndex = 0; patchIndex < model.ledger.numberOfPatches; patchIndex++) {
			lastVisitToPatch[patchIndex] = -1; 
			patchStateOfLastVisit[patchIndex] = -1;
		}

		return this;
	}

	
	/** Increments the time steps since last visit to all patches an agent is currently not in with 1.
	 * Note: patches where the last time is of value -1 are never visited yet. Hence, these values are
	 * not changed. Returns this.*/
	public T1AbstractStateFactory incrementTimeSinceLastVisitAllPatches() { 
		for (int i = 0; i < lastVisitToPatch.length; i++)
			if (this.locationPatch != i)
				if (lastVisitToPatch[i] != -1)
					lastVisitToPatch[i]++; 
		return this;
	}

	/** Set the last observed patch state of the patchIndex to the patchStateIndex. Returns this.*/
	public T1AbstractStateFactory setPatchStateInLastVisit( int patchIndex, int patchStateIndex) {
		this.patchStateOfLastVisit[patchIndex] = patchStateIndex;
		return this;
	}
	
	/** Initializes all the phenotype arrays, and set each phenotype to the specified value. Returns this.*/
	public T1AbstractStateFactory initializePhenotype(int... phenotypeIndices) {
		this.phenotype = new int[model.ledger.numberOfNonAgePhenotypicDimensions];
		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++)
			phenotype[i] = phenotypeIndices[i];
		return this;
	}
	/** Change the valueIndex of the phenotypeIndex with the specified numbers. This function
	 * makes sure that the valueIndex can never be smaller than 0 or larger than the maximum value.
	 * Returns this.*/
	public T1AbstractStateFactory changePhenotypeByIndexAmounts(int phenotypeIndex, int indexAmount) {
		this.phenotype[phenotypeIndex] = phenotype[phenotypeIndex] + indexAmount;
		if (phenotype[phenotypeIndex] < 0)
			phenotype[phenotypeIndex] = 0;
		if (phenotype[phenotypeIndex] >= model.ledger.phenotypeValues[phenotypeIndex].length)
			phenotype[phenotypeIndex] = model.ledger.phenotypeValues[phenotypeIndex].length-1;
		return this;
	}
	
	/** Returns true if the state that comes out of the factory, with the present factory settings, matches at least one DeathCondition */
	public boolean resultsInDeadState() {
		return model.ledger.grimReaper.willBeCulled(this);
	}
	
	/** Returns true only if all fields have been initialised.*/
	public boolean isComplete() {
		if (age ==-1)						return false;
		if (locationPatchState == -1)		return false;
		if (locationPatch == -1)			return false;
		if (lastVisitToPatch==null)			return false;
		if (patchStateOfLastVisit==null)	return false;
		if (phenotype==null)				return false;
		//if (resourceExperiences==null)		return false;
		//if (extrinsicExperiences==null)		return false;
		//if (delayExperiences==null)			return false;
		//if (interruptionExperiences==null)	return false;
		return true;
	}
	
	/** Some states will never be reachable. Here are the exclusion criteria:
	 * 		- A state with age n cannot have more than n experiences.
	 * 		- A state with age n cannot have more than n patch visits
	 * 		- Maybe: deterministic patches? Impossible walk routes?
	 */
	public boolean resultsInReachableState() {
		// TODO
		return true;
	}

	public String toString(String header) {
		StringBuilder sb = new StringBuilder(header);
		sb.append("\nAge: " + this.age);
		sb.append("\nPhenotype: " + Helper.arrayToString(this.phenotype));
		sb.append("\nLocation: [p" + this.locationPatch +",s" + this.locationPatchState + "]");
		sb.append("\nLast visits: " + Helper.arrayToString(this.lastVisitToPatch));
		sb.append("\nLast States: " + Helper.arrayToString(this.patchStateOfLastVisit));
		return sb.toString();
	}
	
	@Override
	public int hashCode() {
		return T1AbstractState.generateHash(this);
	}
}
