package t1states;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**In the background, the T1StateList uses a HashMap to find a canonical 
/* element of a set. Rather than having to specify this specifically, here
/* is a more intuitive wrapper. Specifically, this Map keeps track
 * of all existing T1FitnessStates, for all ages and locations.
 * 
 * (Note: an agent's fitness only depends on its phenotype - not on its 
 * location (at least, not in this version of ModelBuilder). Hence, we
 * do not need to create separate fitness states for all 
 * locations.
 */
public class CanonicalT1FitnessStateMap {
	
	private final Map<T1FitnessState, T1FitnessState> fitnessStates;
	private final boolean keepTrackOfReferences;
	private final Map<String, T1FitnessState> fitnessStateNameToFitnessState;
	
	public CanonicalT1FitnessStateMap (boolean keepTrackOfReferences) {
		this.fitnessStates = new HashMap<>();
		this.keepTrackOfReferences = keepTrackOfReferences;
		if (this.keepTrackOfReferences)
			this.fitnessStateNameToFitnessState = new HashMap<>();
		else
			this.fitnessStateNameToFitnessState = null;
	}
	
	/** Either get the canonical value, or add this FitnessState as the canonical value*/
	public T1FitnessState getFitnessState(T1FitnessState state) {	
		T1FitnessState result = fitnessStates.get(state);
		
		if (result == null) {
			// No canonical in map: add this state as the canonical
			fitnessStates.put(state, state);
			
			if (this.keepTrackOfReferences)
				this.fitnessStateNameToFitnessState.put(state.getName(), state);
			
			return state;
		}
		return result;
	}
	
	
	/** Either get the canonical value, or add this T1FitnessStateFactory as the canonical value*/
	public T1FitnessState getFitnessState(T1FitnessStateFactory stateFactory) {	

		synchronized (this) {
			@SuppressWarnings("unlikely-arg-type")
			T1FitnessState result = fitnessStates.get(stateFactory);

			if (result == null) {
				// No canonical in map: add this state as the canonical
				T1FitnessState newState = stateFactory.buildT1FitnessState( fitnessStates.keySet().size());
				fitnessStates.put(newState, newState);


				if (this.keepTrackOfReferences)
					this.fitnessStateNameToFitnessState.put(newState.getName(), newState);

				return newState;
			}
			return result;
		}
	}
	
	/** Returns all T1FitnessStates in this map*/
	public Set<T1FitnessState> getAllFitnessStates() {
		return fitnessStates.keySet();
	}
	
	/** Returns the number of FitnessStates registered in this map*/
	public int numberOfT1FitnessStates() {
		return fitnessStates.size();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fitnessStates == null) ? 0 : fitnessStates.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		CanonicalT1FitnessStateMap other = (CanonicalT1FitnessStateMap) obj;
		
		if (fitnessStates == null) {
			if (other.fitnessStates != null) {
				return false;
			}
		} else if (!fitnessStates.equals(other.fitnessStates)) {
			return false;
		}
		return true;
	}
	
	
	
	/** Returns the T1FitnessState that this reference points to. */
	public T1FitnessState toFitnessState(T1FitnessStateReference reference) {
		return this.fitnessStateNameToFitnessState.get(reference.name);
	}
	
	

	
	
}