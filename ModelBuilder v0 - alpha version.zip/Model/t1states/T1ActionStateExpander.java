package t1states;

import java.util.concurrent.Callable;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper.Pair;
import interfaces_abstractions.ObserverManager;
import model.Model;
import start.Console;
import t2states.T2DecisionTree;
import t2states.T2MutationStateFactory;

/** The T1ActionStateExpander is used during the FORWARD pass of the 
 * T1 decision tree. It takes a T1ActionState s and computes
 * the consequences of all possible actions. Or more specifically,
 * it computes which states an agent will be in if it takes an action
 * a in the state s, for all possible actions in a. This class should be
 * used in a multithreaded section of the Model to compute the forwards pass
 * of the T1 decision tree.
 *  
 * This includes searching actions. As such, running the T1ActionStateExpander
 * also creates a T2DecisionTree and reduces that tree. This makes running the 
 * expander computationally expensive and long-lasting.
 * 
 * Finally, if the user wants to save the T2DecisionTree's to disk to save up
 * the RAM space, this function also called the OutputFileManager to store the T2DecisionTree's
 * (and subsequently removes the T2DecisionTree).
 * 
 * The call function returns a 0 if all went well, and a positive integer otherwise.
 * */
public class T1ActionStateExpander implements Callable<Integer> {

	private final T1ActionState state;
	private final Model model;
	private final boolean printToConsole;
	public T1ActionStateExpander(Model model, T1ActionState s, boolean printToConsole) {
		this.state = s;
		this.model = model;
		this.printToConsole = printToConsole;
	}
	
	
	@Override
	public Integer call() throws Exception {
		//Console.print("\t\tExpanding T1ActionState: " + state.getName() );
		
		// Compute all the successor states
		// Note: this creates T2MutationStateFactories, but does not yet
		// grow these factories out into tree's... that's something we'll
		// do next
		try {
			state.findPossibleActions();
			state.doForwardsPass();
		} catch (Exception e) { 
			ObserverManager.notifyObserversOfError(e);
			model.outputFileManager.writeExceptionToFile(e);
			return 2;
		}


		// Grow the tree: For all search actions:
		try {
			for (int a = 0; a < state.getModel().ledger.t1Actions.length; a++) {
				if (state.getModel().ledger.t1Actions[a].isSearchAction()) {

					int treeNumber = 0; // Used to give them trees a name
					if (printToConsole)
						Console.print("\t\t\tIn " + state.getName()  + ", action '" + model.ledger.t1ActionNames[a] + "' will result in " + state.successorT2MutationStateFactories.get(a).size() + " T2 decision trees...");
					
					// For each possible T2MutationFactory that is a successor state of that search action:
					for (Pair<T2MutationStateFactory, NumberObjectSingle> pair : state.successorT2MutationStateFactories.get(a)) {

						// Grow the tree and provide some feedback
						T2DecisionTree tree = new T2DecisionTree(model, pair.element1, state, treeNumber++);
						
						if (printToConsole)
							Console.print("\t\t\t" + Thread.currentThread().getName() + " is expanding " + state.getName()+ ", and now starts growing tree '" + tree.name + "', with root: " + tree.briefDescriptionOfRoot() + "..." );

						tree.executeForwardPass(printToConsole);

						// If we do not have to save the T2DecisionTrees to disk first: add the tree to the state
						if (!model.saveT2TreesToFile)
							state.registerT2DecisionTree(tree, a, pair.element2);
						// otherwise, store the tree and give the T2DecisionTree a reference
						else {
							model.outputFileManager.storeT2DecisionTree(tree);
							state.storeT2DecisionTree(tree.name, a, pair.element2);
						}

						if (printToConsole)
							Console.print("\t\t\t'" + tree.name + "' now has a foward pass. In total there are " + tree.treeStateList.numberOfActionStates() + " T2 action states and " + tree.treeStateList.numberOfMutationStates() + " T2 mutation states in this tree"  );
					}
					if (printToConsole)
						Console.print("\t\t\tDone expanding all T2 decision trees in " + state.getName() + ".");
				}
			}
		} catch (Exception e) {
			ObserverManager.notifyObserversOfError(e);
			model.outputFileManager.writeExceptionToFile(e);
			return 1;}

		return 0;
	}



}
