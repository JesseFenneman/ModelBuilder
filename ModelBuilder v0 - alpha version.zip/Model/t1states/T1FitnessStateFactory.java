package t1states;
/** All fields in a State are final. This makes it annoying to
 * create a state s' that is almost identical to a state s. To 
 * make such almost-cloning easier, a StateFactory has the same
 * fields as the corresponding State type, but all fields are 
 * non-final. After changing this Factory, a new State can be 
 * easily constructed using build().*/
public class T1FitnessStateFactory extends T1AbstractStateFactory{

	public T1FitnessStateFactory(T1AbstractState s) {
		super(s);
	}
	
	/** Clone all fields in the existing T1StateFactory to create a new T1StateFactory. 
	 * Fields can be copied by reference (deepClone == false) or by value (deepClone == true)*/
	public T1FitnessStateFactory(T1AbstractStateFactory f, boolean deepClone) {
		super(f, deepClone);
	}
	
	/** Create a FitnessState based on this Factory*/
	protected T1FitnessState buildT1FitnessState(int stateNumber) {
		return new T1FitnessState(this, stateNumber);
	}

	/** A T1FitnessStateFactory and T1FitnessStates are equal if they have the same phenotype - the rest doesn't matter after they die*/
	public boolean equals(T1FitnessState other) {
		if (other == null) {
			return false;
		}

		if (other.age != this.age)
			return false;

		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p])
				return false;
		return true;

	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj.getClass() == T1FitnessState.class)
			return this.equals((T1FitnessState) obj);
		return super.equals(obj);
	}
	
	@Override
	public int hashCode() {
		return T1AbstractState.generateHash(this);
	}


}
