package t1states;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import helper.Helper.Triplet;
import stateInterfacesAndAbstractions.Path;
import t2states.T2DecisionTree;
import t2states.T2MutationState;
import t2states.T2MutationStateFactory;

/** A state BETWEEN ENCOUNTERS where an agent has to pick an action*/
public class T1ActionState extends T1AbstractState {
	/** Should we remove the T2DecisionTrees after we no longer need them? Should be true,
	 * unless debugging.*/
	public static final boolean REMOVE_T2DECISIONTREE_AFTER_USE = false;
	
	/** which actions are allowed in this state? Ordered by the Ledger's array of T1Actions*/
	private final boolean[] possibleActions; 
	
	/** All Outgoing connections that do not result in death or an encounter, one for ArrayList each action
	 Note: this is an ArrayList of size |a|, where a is the number of actions that are registered in the Ledger
	 Each possible action has its own ArrayList of Paths.*/
	public final ArrayList< ArrayList< Path<T1ActionState,   T1MutationState>>> successorT1MutationStates; 
	
	 /** All Outgoing connections where an agent dies, one for ArrayList each action
	 Note: this is an ArrayList of size |a|, where a is the number of actions that are registered in the Ledger
	 Each possible action has its own ArrayList of Paths. */
	public final ArrayList< ArrayList< Path<T1ActionState,   T1FitnessState>>> successorT1FitnessStates; 
	
	 /**All OUTGOING connections that result in the start of a new encounter. Note that in contrast to T1Fitness and T1Mutation
	 states, the successor T2 states are not in a State format yet - they only exist as T2MutationStateFactories. The reason
	 for this is that only T2StateLists can convert a T2MutationStateFactory to a T2MutationState. And this T2StateFactory 
	 is created upon growing a T2 tree from this T2MutationStateFactory (all T2 elements are self-contained), which we'll do later.
	 For now, we'll just keep these states in a T2MutationStateFactory format. Note that we also have to keep track of the probability
	 that we end up from this T1ActionState in that T2MutationState (the NumberObjectSingle in the Pair).
	 Note: this is an ArrayList of size |a|, where a is the number of actions that are registered in the Ledger
	 Each possible action has its own ArrayList of Paths.*/
	public final ArrayList<ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>   >> successorT2MutationStateFactories; 
	
	/** And of course, the full tree's that result from the search actions in this state.
	 These tree are stored in an ArrayList (for each action) that contains an ArrayList
	 (for each possible T2 starting state when performing that action) that contain a
	 Pair that combines a T2DecisionTree with the probability that an agent ends up in
	 that tree, given it has taken the specific action*/
	public final ArrayList<ArrayList<Pair<T2DecisionTree, NumberObjectSingle>>> resultingT2DecisionTrees;

	/** If the user wills it so, we'll store a T2DecisionTree to disk
	 * in between the forwards and the backwards pass. In that case, we cannot
	 * immediately store the T2DecisionTree in resultingT2DecisionTrees. However, 
	 * we do have to keep track of a T2DecisionTree's name (to reload it from file
	 * later on), the action that resulted in this tree, and the probability of ending
	 * up in this tree given the action. The StoredT2DecisionTree keeps all this information.*/
	public class StoredT2DecisionTree{
		public final String treeName;
		public final int actionThatResultedInTree;
		public final NumberObjectSingle probabilityOfTreeGivenAction;
		public StoredT2DecisionTree(String treeName, int actionThatResultedInTree, NumberObjectSingle probabilityOfTreeGivenAction) {
			this.treeName = treeName;
			this.actionThatResultedInTree = actionThatResultedInTree;
			this.probabilityOfTreeGivenAction = probabilityOfTreeGivenAction;
		}
	}
	private final ArrayList<StoredT2DecisionTree> storedButNotYetRegisteredT2DecisionTrees;
	
	
	/* Variables computed during the backwards pass*/
	/** E[Fitness|a]*/
	private NumberObjectSingle[] expectedFitnessGivenAction; 
	
	/** The probability for each action that an agent will take this T1ActionState. */
	protected NumberObjectSingle[] probabilityOfImmediateT1Action;
	
	/** The number of times that an agent will take each T2Action in the encounter that immediately
	 * follows this T1ActionState. Can be all 0's if there is no encounter immediately following this
	 * state (i.e., no sampling decision is the best decision)*/
	protected NumberObjectSingle[] expectedNumberOfImmediateTreeT2Actions;
	
	/** Does this action maximize fitness? Note: initialized to all false.*/
	protected boolean[] isBestAction;
	
	/** Specifically added for the postponing models:
	 * How long does an agent expects to delay in this T2DecisionTree, 
	 * given that there are interruptions, and given that 
	 * it follows the optimal policy?
	 * One value for each possible action. */
	private NumberObjectSingle expectedImmediateTimestepsInDelay;
	
	
	protected T1ActionState(T1ActionStateFactory factory, int stateNumber) {
		super(factory, factory.model.performSafetyChecks);

		if (getModel().performSafetyChecks)
			if (factory.resultsInDeadState())
				throw new IllegalStateException("Creating a dead T1ActionState");

		// Create an array of boolean that will tell us which actions are possible in this state
		// Note: these actions are ordered by the Ledger's ordering of T1Actions
		this.possibleActions = new boolean[getModel().ledger.numberOfT1Actions];
			
		// Create the arraylists of arraylists for the successor states,
		// and create for each action an empty ArrayList that contains the Paths from this state
		// to the successor state
		this.successorT1MutationStates = new ArrayList<>(getModel().ledger.numberOfT1Actions);
		this.successorT1FitnessStates = new ArrayList<>(getModel().ledger.numberOfT1Actions);
		this.successorT2MutationStateFactories = new ArrayList<>(getModel().ledger.numberOfT1Actions);
		resultingT2DecisionTrees = new ArrayList<>(getModel().ledger.numberOfT1Actions);
		
		for (int a = 0; a < getModel().ledger.numberOfT1Actions; a++) {
			successorT1MutationStates.add(new ArrayList<Path<T1ActionState,  T1MutationState>>());
			successorT1FitnessStates.add(new ArrayList<Path<T1ActionState,   T1FitnessState>>());
			successorT2MutationStateFactories.add(new ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>());
			resultingT2DecisionTrees.add(new ArrayList<>());
		}
		
		// Set the name
		this.setID(stateNumber);
		this.setName("T1A-" +this.getID()+"-" + age+"-"+ locationPatchState);
		
		// If we store the T2DecisionTrees do disk in between the forwards and backwards pass,
		// create an ArrayList to keep a reference to those trees.
		if (getModel().saveT2TreesToFile)
			storedButNotYetRegisteredT2DecisionTrees = new ArrayList<>();
		else
			storedButNotYetRegisteredT2DecisionTrees = null;
		
	}

	///////////////////////////////////////////////////////////////////////
	//////////////////////// Tree building functions /////////////////////
	/////////////////////////////////////////////////////////////////////
	
	
	/** Tells this ActionState to compute which Actions are possible in this state. This function
	 * has to be executed before any call to getTransitionsToSuccessorStates or computeSuccessorStates*/
	public void findPossibleActions() {
		for (int a = 0; a < possibleActions.length; a++)
			if (getModel().ledger.t1Actions[a].isPossibleInState(this))
				possibleActions[a] = true;
			else
				possibleActions[a] = false;
	}

	/** Returns an array of booleans, one for each possible T1 action. Each boolean
	 * indicates if the action is possible in this T1ActionState*/
	public boolean[] isPossibleAction(){
		return possibleActions;
	}
	
	/** Returns an ArrayList of indices, one for each action that is possible in this state*/
	public ArrayList<Integer> getPossibleActions(){
		if (this.possibleActions == null)
			return null;
		
		ArrayList<Integer> actions = new ArrayList<>();
		for (int i = 0; i < possibleActions.length; i++)
			if (possibleActions[i])
				actions.add(i);
		return actions;
	}
	
	/** Expands this T1ActionState by computing what states the agent will be in after taking action a,
	 * for all possible actions a. */
	@Override
	public void doForwardsPass() {
		// Return if the node is already expanded
		if (wentThroughForwardsPass)
			return;
		
		// First, compute the consequences of the non-search actions
		this.computeNonSearchActionSuccessorStates();
		
		// Second, compute the consequences of the search actions
		this.computeSeachActionSuccessorStates();
		
		wentThroughForwardsPass = true;
	}
	
	/** Tells this ActionState to compute all Paths that link this state to a T1 successor states,
	 * for all actions possible in this ActionState. This function explicitly does not execute 
	 * any search actions, and hence, will never result in T2MutationStates. That is, it excludes
	 * all actions that might result in a new resource encounter.*/
	private void computeNonSearchActionSuccessorStates() {
	
		// For each possible action that an agent can take in this state...
		for (int a = 0; a < possibleActions.length; a++) {
			if (!possibleActions[a])
				continue;

			// ... find what states result from taking this action.
			// As a reminder: taking an action in a T1 state can result in one of three outcomes:
			// 		1. A T1MutationState if the agent does not encounter a resource and does not die
			//		2. A T2MutationState if the agent does encounter a resource but does not die
			//		3. A T1FitnessState  if the agent dies.
			// In this function we explicitly exclude all search actions - actions that might result in a
			// new resource encounter. Hence, we know for sure that the second entry here is null.
			if (!getModel().ledger.t1Actions[a].isSearchAction()) {
				Triplet < 
				ArrayList< Path<T1ActionState, T1MutationState>> ,  
				ArrayList< Path<T1ActionState,T1FitnessState>>,
				ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>   > resultingPaths = getModel().ledger.t1Actions[a].performAction(this);

				this.successorT1MutationStates.set(a, resultingPaths.a);
				this.successorT1FitnessStates.set(a, resultingPaths.b);

				// If the Model wants us to, perform a safety check to make sure that the origin in all new Paths is indeed this state
				if (getModel().performSafetyChecks) {
					for (Path<T1ActionState, T1MutationState> path : resultingPaths.a)
						if (path.origin != this)
							throw new IllegalStateException("Created a successor state Path for a T1ActionState where the origin in the Path is not this state");
					for (Path<T1ActionState, T1FitnessState> path : resultingPaths.b)
						if (path.origin != this)
							throw new IllegalStateException("Created a successor state Path for a T1ActionState where the origin in the Path is not this state");
				}
			}

		}
		
	}

	/** Tells this ActionState to compute all Paths that link this state to all T1 or T2 successor states,
	 * for all actions possible in this ActionState. This function explicitly ONLY executes search actions, 
	 * ignoring all non-search actions. That is, it executes actions that might result in new resource encounters.
	 * T2States are found in (and if necessary, registered in) the supplied T2StateList.
	 * 
	 * Note, search actions should only be computed after non-search actions have already been computed. Doing
	 * it in the reverse order results in an illegal state exception.*/
	private void computeSeachActionSuccessorStates() {
		
		// For each possible action that an agent can take in this state...
		for (int a = 0; a < possibleActions.length; a++) {
			
			// ... find what states result from taking this action.
			// As a reminder: taking an action in a T1 state can result in one of three outcomes:
			// 		1. A T1MutationState if the agent does not encounter a resource and does not die;
			//		2. A T1FitnessState  if the agent dies;
			//		2. A T2MutationStateFactory if the agent does encounter a resource but does not die
			if (getModel().ledger.t1Actions[a].isSearchAction()) {
				Triplet < 
				ArrayList< Path<T1ActionState, T1MutationState>> ,  
				ArrayList< Path<T1ActionState,T1FitnessState>>,
				ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>   >> resultingPaths = getModel().ledger.t1Actions[a].performAction(this);
				
				this.successorT1MutationStates.set(a, resultingPaths.a);
				this.successorT1FitnessStates.set(a, resultingPaths.b);
				this.successorT2MutationStateFactories.set(a, resultingPaths.c);
				
				// If the Model wants us to, perform a safety check to make sure that the origin in all new Paths is indeed this state
				if (getModel().performSafetyChecks) {
					// Check if all the T1 paths make sense
					for (Path<T1ActionState, T1MutationState> path : resultingPaths.a)
						if (path.origin != this)
							throw new IllegalStateException("Created a successor state Path for a T1ActionState where the origin in the Path is not this state");
					for (Path<T1ActionState, T1FitnessState> path : resultingPaths.b)
						if (path.origin != this)
							throw new IllegalStateException("Created a successor state Path for a T1ActionState where the origin in the Path is not this state");
					
					// Check if the probabilities for the T2States make sense: they should all be within [0,1]. They do not have to sum to 1, as there might be 
					// a probability that an agent dies before it goes to the T2MutationState
					for ( Pair<T2MutationStateFactory, NumberObjectSingle>  pair : resultingPaths.c)
						if (pair.element2.smallerThan(0, true))
							throw new IllegalStateException("Probability of going from a T1ActionState to a T2MutationState(Factory) is lower than 0.");
						else if (pair.element2.largerThan(1, true)) 
							throw new IllegalStateException("Probability of going from a T1ActionState to a T2MutationState(Factory) is higher than 1.");
				}
				
			}
		}
		
	}
	

	
	/** Returns all Paths between this state and a successor state after taking the action, 
	 * and the agent is still alive.
	 * 
	 * Any call to this function must be preceded by a call to findPossibleActions() and computeSuccessorStates().
	 * The action integer refers to the place of the action in the Ledger's T1Action array.*/
	public ArrayList<Path<T1ActionState, T1MutationState>> getSuccessorT1MutationPaths(int action) {return successorT1MutationStates.get(action);}
	
	/** Returns all Paths between this state and a successor state after taking the action, 
	 * and the agent is dead. 
	 * 
	 * Any call to this function must be preceded by a call to findPossibleActions() and computeSuccessorStates().
	 * The action integer refers to the place of the action in the Ledger's T1Action array.*/
	public ArrayList<Path<T1ActionState, T1FitnessState>> getSuccessorT1FitnessPaths(int action) {return successorT1FitnessStates.get(action);}

	/** After all actions are performed, the T1ActionState is left with three elements. The first is an ArrayList (of size |T1 actions in 
	 * Ledger|) that contains an ArrayList of paths to T1MutationStates. These are the successor paths for a non-dead agent after taking
	 * an action a. The second is similar, an ArrayList of size |actions| that contains an ArrayList of paths to T1FitnessStates. These
	 * are the successor paths for agents that die. The third item is an ArrayList of size |actions|, where each element in that ArrayList
	 * is an ArrayList of Pairs that combine a T2MutationStateFactory with the probability of ending up in that T2MutationStateFactory, given
	 * that the agent performs action a. This third element can then be used to grow a T2 decision tree. This function returns that ArrayList
	 * of for the specified action. */
	public ArrayList<Pair<T2MutationStateFactory, NumberObjectSingle> > getSuccessorT2MutationPaths(int action) {return successorT2MutationStateFactories.get(action);}

	/** Returns an ArrayList of all T1 Mutation states an agent can be in after executing the specified action,
	 * for all possible action that agent can take. This function is used to create the frontier in the model.*/
	public ArrayList<T1MutationState> getT1AllMutationSuccessorStates(){
		ArrayList<T1MutationState> result = new ArrayList<>();
		for (int a = 0; a < this.possibleActions.length; a++)
			for (Path<T1ActionState,   T1MutationState> path : this.successorT1MutationStates.get(a))
				result.add(path.destination);
		return result;
	}
	
	/** Returns an ArrayList of all T1 states an agent can be in after executing the specified action.*/
	public ArrayList<T1AbstractState> getT1SuccessorStates(int action){
		ArrayList<T1AbstractState> result = new ArrayList<>();
		for (Path<T1ActionState,   T1MutationState> path : this.successorT1MutationStates.get(action))
			result.add(path.destination);
		for (Path<T1ActionState,   T1FitnessState> path : this.successorT1FitnessStates.get(action))
			result.add(path.destination);
		return result;
	}
	
	/** Create an ActionStateFactory preset with the same values as in this ActionState*/
	public T1ActionStateFactory toT1ActionStateFactory() {return new T1ActionStateFactory(this);}

	/** Register the T2DecisionTree as a possible consequence of performing the action in this state. 
	 * The NumberObjectSingle object represent the probability the agent will end up in this state. 
	 * Note: this function should NOT be used if we first store the tree to disk. In those cases, use
	 * registerStoredT2DecisionTree instead.*/
	public void registerT2DecisionTree(T2DecisionTree tree, int action, NumberObjectSingle probability) {
		// Check if there already is an ArrayList at index [action]. If not, make an empty one
		if (this.resultingT2DecisionTrees.get(action) == null)
			this.resultingT2DecisionTrees.set(action, new ArrayList<>());
		
		// Add the T2DecisionTree to the ArrayList for this action
		this.resultingT2DecisionTrees.get(action).add(new Pair<>(tree, probability));
	}
	
	/** Stores the name of a T2DecisionTree, the action that results in that tree, and the probability
	 * of the agent ending up in that tree given the action. This information is used during the backwards pass
	 * to load the T2DecisionTree from disk. */
	public void storeT2DecisionTree(String treeName, int action, NumberObjectSingle probability) {
		this.storedButNotYetRegisteredT2DecisionTrees.add(new StoredT2DecisionTree(treeName, action, probability));
	}
	
	/** Returns a list of StoredT2DecisionTrees that have to be loaded from disk before 
	 * the backwards pass is called.*/
	public ArrayList<StoredT2DecisionTree> getAllStoredTrees(){
		return this.storedButNotYetRegisteredT2DecisionTrees;
	}
	
	/** Compute what action results in what fitness, what the best action is, and what the fitness of this state is.
	 * In other words: go through the backwards pass.*/
	@Override
	public void doBackwardsPass(boolean printToConsole) {
		if (!this.wentThroughForwardsPass)
			throw new IllegalStateException("Pushing a T1ActionState through a backwards pass, but this state has not been through a forwards pass yet.");

		// Step 1: compute the expected fitness for all actions
		this.expectedFitnessGivenAction = new NumberObjectSingle[getModel().ledger.numberOfT1Actions];
		
		for (int action = 0; action < getModel().ledger.numberOfT1Actions; action++)
			this.expectedFitnessGivenAction[action] = computeFitnessForAction(action, printToConsole);

		// Step 2: make expected fitness value immutable
		for (int action = 0; action < getModel().ledger.numberOfT1Actions; action++)
			this.expectedFitnessGivenAction[action].makeImmutable();

		// Step 3: figure out which action (or actions when there are ties) has the highest fitness,
		// and what that expected fitness is
		ArrayList<Integer> bestActionsSoFar = new ArrayList<>();
		bestActionsSoFar.add(0);
		NumberObjectSingle bestFitnessSoFar = this.expectedFitnessGivenAction[0];
		if (getModel().ledger.numberOfT1Actions> 1)
			for (int action = 1; action < getModel().ledger.numberOfT1Actions; action++) 
				if (this.expectedFitnessGivenAction[action].largerThanOrEqualTo(bestFitnessSoFar)) {
					if (!expectedFitnessGivenAction[action].equals(bestFitnessSoFar, true)) 
						bestActionsSoFar.clear();
					bestFitnessSoFar = this.expectedFitnessGivenAction[action];
					bestActionsSoFar.add(action);
			}

		// Step 4: Set the probability of immediate T1 actions,
		// and remove all the now-no-longer-used successor state arrays for the actions
		// that are not a best action
		this.isBestAction = new boolean[getModel().ledger.numberOfT1Actions]; 
		NumberObjectSingle[] tempProbabilityOfImmediateT1Action = new NumberObjectSingle[getModel().ledger.numberOfT1Actions];

		if (bestActionsSoFar.size() == 0)
			throw new IllegalStateException("T1ActionState does not have a best action");
		for (int a = 0; a < bestActionsSoFar.size(); a++)
			isBestAction[a] = true; // Note: it was all false beforehand

		//Compute the probability of taking an action from bestActions (this is a probability
		// of 1 if there is only 1 best action, and 1/|bestActions| if there are ties)
		// Additionally, remove the successor states for all actions that are not best actions
		NumberObjectSingle probabilityOfAction = NumberObject.createNumber(getModel().howToRepresentNumbers, 1).divide(bestActionsSoFar.size());
		for (int a = 0 ; a< getModel().ledger.numberOfT1Actions; a++)
			if (!isBestAction[a]) {
				successorT1MutationStates.set(a, null);
				successorT1FitnessStates.set(a, null);
				successorT2MutationStateFactories.set(a, null);
				resultingT2DecisionTrees.set(a, null);
				tempProbabilityOfImmediateT1Action[a]  = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
			} else {
				tempProbabilityOfImmediateT1Action[a] = probabilityOfAction;	
			}
		this.setProbabilityOfImmediateT1Actions(tempProbabilityOfImmediateT1Action);
		
		// Step 5: Set all the 'expected...' fields
		// Except for the expectedFitness, which we already computed above
		this.setExpectedFitness(bestFitnessSoFar);
		this.setExpectedFields(isBestAction);
		
		// Step 6: Remove all decision tree's; we do not need them anymore, and they just take up space
		if (REMOVE_T2DECISIONTREE_AFTER_USE) {
				this.resultingT2DecisionTrees.clear();
				successorT2MutationStateFactories.clear();
		}
		
		if (getModel().performSafetyChecks)
			this.checkIfBackwardsFieldsAreValid();
		this.wentThroughBackwardsPass = true;
	}



	/** Compute the expected fitness for the specified action. The expected fitness of an action is defined as:
	 * 
	 * [ SUM over all successor T1FitnessStates fs: fitness(fs) * Pr(fs|s,a) ] +
	 * [ SUM over all successor T1MutationStates  T1ms: fitness(T1ms) * Pr(T1ms|s,a) ] +
	 * [ SUM over all possible resultingT2DecisionTrees tree: fitness(root(tree)) * Pr(T1as|s,a) ] 
	 * 
	 * Where s is the current state, Pr(x|s) is the transition probability of 
	 * going to x from s, and a is the current action. Note that to find the fitness of the root of
	 * a T2DecisionTree, we have to make the T2DecisionTree also go through a backwards pass.
	 * */
	private NumberObjectSingle computeFitnessForAction(int action, boolean printToConsole) {
		// Keep track of both the weighted sum (which is the fitness), and, for testing purposes, the totalProbability.
		NumberObjectSingle totalProbability = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle weightedSum = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);

		for (Path<T1ActionState,   T1FitnessState> path : successorT1FitnessStates.get(action)) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);
			weightedSum.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
		}

		for (Path<T1ActionState,   T1MutationState> path : successorT1MutationStates.get(action)) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);
			weightedSum.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
		}

		// If this is a search action, also include the expected fitness of the root nodes of all possible
		// T2Decision Trees. To get this fitness we have to make the T2DecisionTree go through a backwards pass.
		if (getModel().ledger.t1Actions[action].isSearchAction()) {
			for (Pair<T2DecisionTree, NumberObjectSingle> treeProbabilityPairAfterAction : this.resultingT2DecisionTrees.get(action)) {
				T2DecisionTree tree = treeProbabilityPairAfterAction.element1;
				tree.executeBackwardsPass(printToConsole);

				if (getModel().performSafetyChecks)
					totalProbability.add(treeProbabilityPairAfterAction.element2, true);
				weightedSum.add(treeProbabilityPairAfterAction.element2.multiply( tree.root.getExpectedFitness(), false), true);
			}
		}
		if (getModel().performSafetyChecks)
			if (!totalProbability.equals(1, true))
				throw new IllegalStateException("T2Mutation state after backwards pass: sum of all paths did not equal 1. Total sum = " + totalProbability.toStringWithoutTrailingZeros());

		return weightedSum;
	}

	/** Set the expectedAge, expectedPhenotype[], expectedT1Actions[], and expectedT2Actions[]
	 * during the backwards pass. 
	 * Specifically:
	 *  Go over all possible successor states from taking a best action a*,
	 *		For each successor state resulting from a*:
	 *		Multiply the expected age, phenotype, and expected number of future actions from that successor state with
	 *			the probability of going to that successor given that an agent takes a*;
	 *		Multiply the result with probabilityOfAction;
	 *		Add that result to the expectedAge, expectedPhenotype, and expectedNumberOfFutureActions respectively;
	 *		
	 * (Note: we already know the expected fitness. Computing the other fields is actually
	 * really similar to when we computed the fitness) */
	private void setExpectedFields(boolean[] isBestAction) {

		// Create a temporary storage for all the expected fields, and set all values to 0
		NumberObjectSingle tempExpectedAge = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle tempExpectedImmediateTimestepsInDelay= NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle tempExpectedTotalTimestepsInDelay = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
	
		NumberObjectSingle[] tempExpectedPhenotype = new NumberObjectSingle[getModel().ledger.numberOfNonAgePhenotypicDimensions];
		for (int i = 0; i < getModel().ledger.numberOfNonAgePhenotypicDimensions; i++) tempExpectedPhenotype[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT1Actions = new NumberObjectSingle[getModel().ledger.numberOfT1Actions];
		for (int i = 0; i < getModel().ledger.numberOfT1Actions; i++) tempExpectedNumberOfFutureT1Actions[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT2Actions = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];
		for (int i = 0; i < getModel().ledger.numberOfT2Actions; i++) tempExpectedNumberOfFutureT2Actions[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);
	
		NumberObjectSingle[] tempExpectedNumberOfImmediateTreeT2Actions = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];
		for (int i = 0; i < getModel().ledger.numberOfT2Actions; i++) tempExpectedNumberOfImmediateTreeT2Actions[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);
		
		// Keep track of both the weighted sum (which is the fitness), and, for testing purposes, the totalProbability.
		NumberObjectSingle totalProbability = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);

		for (int a = 0; a < getModel().ledger.numberOfT1Actions; a++)
			if (isBestAction[a]) {

				// First, for each possible T1Fitness state s' that result from this mutation state:
				// multiply the expectedFitness of s' with the probability of going to s',
				// and add the result to this state's expectedFitness field.
				// Do the same for actions and phenotypes. (Don't have to do it for future actions,
				// as there never are any future actions of T1FitnessStates)
				for (Path<T1ActionState,   T1FitnessState> path : successorT1FitnessStates.get(a)) {
					NumberObjectSingle correctedWeight = path.weight.multiply(probabilityOfImmediateT1Action[a], false);
					if (getModel().performSafetyChecks)
						totalProbability.add(correctedWeight, true);

					tempExpectedAge.add(correctedWeight.multiply( path.destination.getExpectedAge(),     false), true);
					
					// If this is a waiting action, increase the immediate delaying by the weight of this path.
					// Also, increase the lifetime (or total) delaying by the weight of this path, and the weighted
					// expected future delay of the successor state (Note, the latter is 0 for fitness states, and
					// can therefore be ignored)
					NumberObjectSingle weightedImmediateTimeSteps = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
					if (getModel().ledger.t1Actions[a].isWaitingAction()) {
						weightedImmediateTimeSteps = correctedWeight.multiply( path.destination.getAge() - age ,false);
						tempExpectedImmediateTimestepsInDelay.add(weightedImmediateTimeSteps, true);
					}
					tempExpectedTotalTimestepsInDelay.add(weightedImmediateTimeSteps, true);
						
					for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
						tempExpectedPhenotype[p].add(correctedWeight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
				}

				// Second, so the same for all possible T1MutationStates. However, now we also have to keep track of
				// all possible future T1 and T2 actions that an agent will take in its lifetime from this moment on.
				for (Path<T1ActionState,   T1MutationState> path : successorT1MutationStates.get(a)) {
					NumberObjectSingle correctedWeight = path.weight.multiply(probabilityOfImmediateT1Action[a], false);
					if (getModel().performSafetyChecks)
						totalProbability.add(correctedWeight, true);

					tempExpectedAge.add(correctedWeight.multiply( path.destination.getExpectedAge(),     false), true);
					
					// If this is a waiting action, increase the immediate delaying by the weight of this path.
					// In addition, increase the lifetime (or total) delaying by the weight of this path, and the weighted
					// expected future delay of the successor state
					NumberObjectSingle weightedImmediateTimeSteps = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
					if (getModel().ledger.t1Actions[a].isWaitingAction()) {
						weightedImmediateTimeSteps = correctedWeight.multiply( path.destination.getAge() - age ,false);
						tempExpectedImmediateTimestepsInDelay.add(weightedImmediateTimeSteps, true);
					}
					tempExpectedTotalTimestepsInDelay.add(weightedImmediateTimeSteps, true);
					tempExpectedTotalTimestepsInDelay.add(correctedWeight.multiply(path.destination.getExpectedTotalTimeStepsInDelay(), false), true);
					
			
					for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
						tempExpectedPhenotype[p]                 .add(correctedWeight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
					
					for (int t1a = 0 ; t1a < this.getModel().ledger.numberOfT1Actions; t1a ++)
						tempExpectedNumberOfFutureT1Actions[t1a] .add(correctedWeight.multiply( path.destination.getFutureTimesItPerformsT1Action(t1a), false), true);
					for (int t2a = 0 ; t2a < this.getModel().ledger.numberOfT2Actions; t2a ++)
						tempExpectedNumberOfFutureT2Actions[t2a] .add(correctedWeight.multiply( path.destination.getFutureTimesItPerformsT2Action(t2a), false), true);

				}

				// Third and finally, consider all possible decision tree's.
				// (But only if this is an search action, otherwise there will not be any T2DecisionTree's)
				// Here we do the same thing as for the T1MutationState, but we will also keep track of what actions
				// an agent will take in the immediately following tree.
				if (getModel().ledger.t1Actions[a].isSearchAction()) {
					for (Pair<T2DecisionTree, NumberObjectSingle> treePair : resultingT2DecisionTrees.get(a)) {
						// The corrected weight is the probability of taking this action, and the probability of ending up in that particular tree
						NumberObjectSingle correctedWeight = treePair.element2.multiply(probabilityOfImmediateT1Action[a], false);
						
						if (getModel().performSafetyChecks)
							totalProbability.add(correctedWeight, true);
						
						T2MutationState root = treePair.element1.root;

						tempExpectedAge.add(correctedWeight.multiply( root.getExpectedAge(),     false), true);
						
						// If this is a waiting action, increase the immediate delaying by the weight of this path.
						// Also, increase the lifetime (or total) delaying by the weight of this path, and the weighted
						// expected future delay of the successor state
						NumberObjectSingle weightedImmediateTimeSteps = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
						if (getModel().ledger.t1Actions[a].isWaitingAction()) {
							weightedImmediateTimeSteps = correctedWeight.multiply( root.getAge() - age ,false);
							tempExpectedImmediateTimestepsInDelay.add(weightedImmediateTimeSteps, true);
						}
						tempExpectedTotalTimestepsInDelay.add(weightedImmediateTimeSteps, true);
						tempExpectedTotalTimestepsInDelay.add(correctedWeight.multiply(root.getExpectedTotalTimeStepsInDelay(), false), true);
						
						
						for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
							tempExpectedPhenotype[p].add(correctedWeight.multiply(root.getExpectedPhenotype(p),     false), true);

						// The future actions are still the same - just look at what the root node of the tree
						// will do in the future (it's a MutationState, not an ActionState, so there is no immediate
						// action of that state to keep track of).
						for (int t1a = 0 ; t1a < this.getModel().ledger.numberOfT1Actions; t1a ++)
							tempExpectedNumberOfFutureT1Actions[t1a] .add(correctedWeight.multiply( root.getFutureTimesItPerformsT1Action(t1a), false), true);
						for (int t2a = 0 ; t2a < this.getModel().ledger.numberOfT2Actions; t2a ++)
							tempExpectedNumberOfFutureT2Actions[t2a] .add(correctedWeight.multiply( root.getFutureTimesItPerformsT2Action(t2a), false), true);
						
						// However, we also want to keep track of the number of times it performs each T2 action in the subsequent tree alone
						for (int t2a = 0 ; t2a < this.getModel().ledger.numberOfT2Actions; t2a ++) 
							tempExpectedNumberOfImmediateTreeT2Actions[t2a] .add(correctedWeight.multiply(root.getFutureTimesItPerformsT2ActionInThisTree(t2a), false), true);
					}
				}
			}
		
		// Store all the temp fields to the state
		this.setExpectedAge(tempExpectedAge);
		this.setExpectedTotalTimeStepsInDelay(tempExpectedTotalTimestepsInDelay);
		this.expectedImmediateTimestepsInDelay = tempExpectedImmediateTimestepsInDelay;
		this.setExpectedPhenotype(tempExpectedPhenotype);
		this.setExpectedNumberOfFutureT1Actions(tempExpectedNumberOfFutureT1Actions);
		this.setExpectedNumberOfImmediateTreeT2Actions(tempExpectedNumberOfImmediateTreeT2Actions);
		this.setExpectedNumberOfFutureT2Actions(tempExpectedNumberOfFutureT2Actions);


	}

	/** Returns a clone of the expected fitness of taking the action when in this state. The integer
	 * for each action can be found in the Ledger. Throws an IllegalStateException if the
	 * T1AbstractState did not yet go through the backwards phase.*/
	public NumberObjectSingle getExpectedFitnessOfAction(int action) {
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the fitness of an action in a T1 state that has not gone through the backwards pass yet.");

		return this.expectedFitnessGivenAction[action].clone();
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////// Outcome setters (used during backwards pass) /////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////
	/** Set the expected number of immediate T1 Actions by cloning the input. Note that the
	 * input must be a probability distribution (i.e., all values must sum up to 1, and should all
	 * be non-negative). Also makes all expected action NumberObjectSingle objects immutable.
	 * Throws an IllegalStateException if there already is an expected number of future actions for that index.
	 * */
	public void setProbabilityOfImmediateT1Actions( NumberObjectSingle[] newProbabilityDistribution) {
		// If the model wants us to be careful: 
		// check if the dimension's input matches the number of T1 actions in the ledger
		if (newProbabilityDistribution.length != getModel().ledger.numberOfT1Actions)
			throw new IllegalArgumentException("Setting probability of immediate T1 Actions for T1ActionState. However, the number of action in the input ("
					+ newProbabilityDistribution.length + ") does not match the number of T1 actions in the ledger (" + getModel().ledger.numberOfT1Actions+ ").");

		// check if the sum of all probabilities for all successor states does indeed sum to 1
		if (getModel().performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (NumberObjectSingle p : newProbabilityDistribution)
				if (p.smallerThan(0, true))
					throw new IllegalStateException("Negative probability of immediate T1 action.");
				else
					sum.add(p, true);
			if (!sum.equals(1, true))
				throw new IllegalStateException("Non-sum-to-1 probability distribution immediate T1 actions. Sum = " + sum);
		}


		if (this.probabilityOfImmediateT1Action != null)
			throw new IllegalStateException("Setting a non-null expected number of immediate T1 actions ");
		
		this.probabilityOfImmediateT1Action = newProbabilityDistribution;
		for (int a = 0; a < probabilityOfImmediateT1Action.length; a++)
			probabilityOfImmediateT1Action[a].makeImmutable();
	}
	
	/** Set the number of T2 Actions an agent expects to take in the T2DecisionTree immediately following this
	 * T1ActionState. Clones the input. Also makes all expected action NumberObjectSingle objects immutable. */
	public void setExpectedNumberOfImmediateTreeT2Actions( NumberObjectSingle[] newExpectedNumber) {
		// If the model wants us to be careful: 
		// check if the dimension's input matches the number of T1 actions in the ledger
		if (newExpectedNumber.length != getModel().ledger.numberOfT2Actions)
			throw new IllegalArgumentException("Setting probability of immediate tree T2 Actions for T1ActionState. However, the number of action in the input ("
					+ newExpectedNumber.length + ") does not match the number of T2 actions in the ledger (" + getModel().ledger.numberOfT2Actions+ ").");
				
		// TODO; check maximum cycle time

		if (this.expectedNumberOfImmediateTreeT2Actions != null)
			throw new IllegalStateException("Setting a non-null expected number of immediate T2 actions ");
		
		this.expectedNumberOfImmediateTreeT2Actions = newExpectedNumber;
		for (int a = 0; a < expectedNumberOfImmediateTreeT2Actions.length; a++)
			expectedNumberOfImmediateTreeT2Actions[a].makeImmutable();
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////////////
 	//////////////////////// Outcome getters (known after backwards pass) /////////////////////
 	//////////////////////////////////////////////////////////////////////////////////////////
	/** Returns a deep cloned array of booleans containing a true at each T1Action index that
	 * is a best action in this T1ActionState */
	public boolean[] getBestActions(){
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the best actions a T1 state that has not gone through the backwards pass yet.");

		boolean[] clone = new boolean[getModel().ledger.numberOfT1Actions];
		System.arraycopy(this.isBestAction, 0, clone, 0, getModel().ledger.numberOfT1Actions);
		
		return clone;
		
	}
	
	/** Returns a reference to probability that an agent will take the specified action as the next action. */
	public NumberObjectSingle getProbabilityOfImmediateAction(int action){
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the probability of an action in a T1 state that has not gone through the backwards pass yet.");

		return this.probabilityOfImmediateT1Action[action].clone();
	}

	/** Returns the expected fitness of taking this action. */
	public NumberObjectSingle getExpectedFitnessGivenAction(int a) {
		return this.expectedFitnessGivenAction[a];
	}
	
	/** Returns a clone of the expected immediate number of times steps an agent will spend
	 * delaying (by waiting), given the best action.
	 * Throws an IllegalStateException if the
	 * T1AbstractState did not yet go through the backwards phase.*/
	public NumberObjectSingle getExpectedImmediateTimestepsInDelay() {
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for the fitness of an action in a T1 state that has not gone through the backwards pass yet.");

		return this.expectedImmediateTimestepsInDelay.clone();
	}
	/** Returns a reference to the number times an agent will take the specified T2 action in the decision tree
	 * that immediately starts after this T1 action. Returns null if there is no search action in the best actions.*/
	public NumberObjectSingle getExpectedNumberOfImmediateTreeT2Actions(int t2Action) {
		// Check if at least one action is possible in this state, a best action in this state, and is search action
		boolean atLeastOne = false;
		for (int a = 0; a < getModel().ledger.numberOfT1Actions; a++) {
			if (this.possibleActions[a] && this.isBestAction[a] && getModel().ledger.t1Actions[a].isSearchAction())
				atLeastOne = true;
		}
		
		if (!atLeastOne)
			return null;
		
		return this.expectedNumberOfImmediateTreeT2Actions[t2Action];
	}
	///////////////////////////////////////////////////////////////
	//////////////////////// Other functions /////////////////////
	/////////////////////////////////////////////////////////////
	
	@Override
	public int hashCode() {
		return T1AbstractState.generateHash(this);
	}
	
	/** A T1AbstractStateFactory and T1AbstractStates are equal if they have the same phenotype, and past experiences with the patch. The
	 * age and current location do not matter - we will states in separate hashmaps for each age and location. */
	public boolean equals(T1ActionStateFactory other) {
		if (other == null)	return false;
		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p]) 
				return false;	
		for (int s = 0; s < this.lastVisitToPatch.length; s++) 

			if (other.lastVisitToPatch[s] != this.lastVisitToPatch[s]) {
				return false;
			}
			
			else if (other.patchStateOfLastVisit[s] != this.patchStateOfLastVisit[s]) {
				return false;
				
			}
		
		return true;
	}
	
	/** A T1AbstractStateFactory and T1AbstractStates are equal if they have the same phenotype, and past experiences with the patch. The
	 * age and current location do not matter - we will states in separate hashmaps for each age and location. */
	public boolean equals(T1ActionState other) {
		if (other == null)	return false;
		for (int p = 0; p < phenotype.length; p++)
			if (other.phenotype[p] != this.phenotype[p]) 
				return false;
		
		for (int s = 0; s < this.lastVisitToPatch.length; s++)
			if (other.lastVisitToPatch[s] != this.lastVisitToPatch[s]) 
				return false;
			else if (other.patchStateOfLastVisit[s] != this.patchStateOfLastVisit[s])
				return false;
		
		return true;
	}
	
	@Override 
	public boolean equals(Object o) {
		if (o == null)
			return false;
		
		if (o.getClass() == T1ActionState.class)
			return (equals((T1ActionState) o));
		if (o.getClass() == T1ActionStateFactory.class)
			return (equals((T1ActionStateFactory) o));
		return false;
	}

	
	/** When loading T2DecisionTrees to disk, we need to connect the decision tree back 
	 * to the rest of the model. To make this process easier, each T1AbstractState can be transformed to a
	 * T1StateReference, which can be stored in dependently from this T1AbstractState. The
	 * T1StateList can then use this reference to retrieve this T1AbstractState. */
	public T1ActionStateReference toT1StateReference() {
		return new T1ActionStateReference (this.getName(), this.age, this.locationPatchState);
	}
	
}
