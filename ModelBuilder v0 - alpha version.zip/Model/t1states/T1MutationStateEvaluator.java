package t1states;

import java.util.concurrent.Callable;

import helper.Helper;
import interfaces_abstractions.ObserverManager;

/** The T1MutationStateEvaluator is used during the BACKWARDS pass of the 
 * T1 decision tree. It takes a T1MutationState s and computes
 * the expected fitness of entering s. This expected fitness is the weighted sum
 * of the expected fitness of all future states s' that might result from going 
 * to s; weighted for the probability of ending up in s'. The T1MutationState's
 * computeFitness() function handles implementation details. This class is just
 * a wrapper to use during multi-threading.
 * */
public class T1MutationStateEvaluator implements Callable<Void> {

	private final T1MutationState state;
	private final boolean printToConsole;
	
	public T1MutationStateEvaluator(T1MutationState s, boolean printToConsole) {
		this.state = s;
		this.printToConsole = printToConsole;
	}

	@Override
	public Void call() throws Exception {
		try {
			state.doBackwardsPass(printToConsole);
		} catch (Exception e) {
			e.printStackTrace();
			ObserverManager.notifyObserversOfError(e);
			state.getModel().outputFileManager.writeExceptionToFile(e);
		}
		return null;
	}



}
