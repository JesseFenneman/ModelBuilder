package patch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectMatrix;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper.Pair;
import model.Ledger;
import model.LedgerFactory;
import model.Model;
import spatialAndTemporalElements.BasePatch;
import spatialAndTemporalElements.PatchStateTemplate;
import spatialAndTemporalElements.PatchTemplate;
import t1states.T1ActionState;
import t1states.T1ActionStateFactory;
import view.Workspace;

/** In the actual model, most of the times we use the PatchState for computation.
 * However, if we want to travel from one patch to another, we have to know which
 * states belong together in the same patch, and what the probability is that
 * a patch is in a state. The Patch class stores this information.
 * 
 * In addition, the Patch is responsible for creating the PatchStates*/
public class Patch {
	
	private final String name;
	private final Model model;
	private final NumberObjectSingle[]     initialDistribution; // [probability distribution over states at time 0]
	private final NumberObjectSingle[][]   stateTransitionProbabilities; // [state][state']
	private final HashMap<Integer, Integer> ledgerPatchStateIndexToTransitionProbabilityIndex; //[patch state in ledger] -> [which row/column belongs to that state?]
	private final NumberObjectMatrix stateTransitionProbabilitiesStoredInANumberObjectMatrix;
	public final int indexInLedger;
	
	// What is the global (ledger) integer of each state?
	// That is stored in ledgerIndicesOfStatesInThisPatch. Note these indexes refer to the
	// index position in the ledger's list that contains all possible states (i.e., a list that
	// contains the states of all patches). 
	public final int[] ledgerIndicesOfStatesInThisPatch; 
	
	// However, to compute the stateTransitionProbabilities we also need to know the transmission 
	// probability of states within this patch. That is, we need to know which entry in the 
	// stateTransitionProbabilities refers to which global state. 
	
	public Patch(PatchTemplate template, Model model, LedgerFactory ledgerFactory, Workspace workspace){
		this.name = template.getName();
		this.model = model;
		ledgerPatchStateIndexToTransitionProbabilityIndex = new HashMap<>();
		
		// First, this patch registers itself in the ledgerFactory
		synchronized (ledgerFactory) {
			if (ledgerFactory.patchNames.size() != ledgerFactory.patches.size())
				throw new IllegalStateException("There is an unequal number of patches and patch names in the factory ledger before registering a new patch. ");

			ledgerFactory.patches.add(this);
			ledgerFactory.patchNames.add(name);

			if (ledgerFactory.patchNames.size() != ledgerFactory.patches.size())
				throw new IllegalStateException("There is an unequal number of patches and patch names in the factory ledger after registering a new patch. ");

			indexInLedger = ledgerFactory.patches.size() -1;
			
			if (template == BasePatch.get())
				ledgerFactory.basePatchIndex = indexInLedger;
		}
		
		// Create all the patch states of this patch. Note that the patch states will register themselves in the
		// ledgerFactory
		// First, get all the PatchStateTemplates, in the order of appearance in the PatchTemplate's PatchStateMutationTemplate
		ArrayList<PatchState> statesInThisPatch = new ArrayList<>();
		for(PatchStateTemplate stateTemplate : template.getMutations().getOrderedPatchStates()) 
			statesInThisPatch.add(new PatchState(indexInLedger, stateTemplate, model, ledgerFactory, workspace));
		
		// Store all the indices of the newly created patch states in this patch, also store in ledgerPatchStateIndexToTransitionProbabilityIndex
		ledgerIndicesOfStatesInThisPatch = new int[statesInThisPatch.size()];
		for (int i = 0; i < statesInThisPatch.size(); i++) {
			ledgerPatchStateIndexToTransitionProbabilityIndex.put(statesInThisPatch.get(i).ledgerIndexOfPatchState, i);
			ledgerIndicesOfStatesInThisPatch[i] = statesInThisPatch.get(i).ledgerIndexOfPatchState;
		}

		// Set the state transition probabilities. Because we used the PatchTemplate's PatchStateMutationTemplate to get the order of the states,
		// we can directly use the PatchStateMutationTemplate to get the transitionProbbabilities.
		this.stateTransitionProbabilitiesStoredInANumberObjectMatrix = template.getMutations().toDecimalNumberMatrix().toNumberObjectMatrix(model.howToRepresentNumbers);
		this.stateTransitionProbabilities = stateTransitionProbabilitiesStoredInANumberObjectMatrix.to2DNumberObjectSingleMatrix(model.howToRepresentNumbers);
		
		
		// And finally, set the initial distribution of patch states at time 0
		this.initialDistribution = new NumberObjectSingle[ledgerIndicesOfStatesInThisPatch.length];
		for (int i = 0; i < template.getMutations().getOrderedPatchStates().size(); i ++)
			initialDistribution[i] = template.getStartingProbability(template.getMutations().getOrderedPatchStates().get(i)).clone().toNumberObjectSingle(model.howToRepresentNumbers);

	}

	
	
	/** Deep clone constructor*/
	public Patch (Patch original) {
		this.name = original.name;
		this.model = original.model;
		this.ledgerPatchStateIndexToTransitionProbabilityIndex = new HashMap<>();
		for (int key : original.ledgerPatchStateIndexToTransitionProbabilityIndex.keySet())
			this.ledgerPatchStateIndexToTransitionProbabilityIndex.put(key, original.ledgerPatchStateIndexToTransitionProbabilityIndex.get(key));
		
		this.initialDistribution = new NumberObjectSingle[original.initialDistribution.length];
		for (int i = 0; i < initialDistribution.length; i++)
			initialDistribution[i] = original.initialDistribution[i].clone();
		
		stateTransitionProbabilities	= new NumberObjectSingle[original.stateTransitionProbabilities.length][];
		for (int i = 0; i < stateTransitionProbabilities.length; i++) {
			stateTransitionProbabilities[i] = new NumberObjectSingle[original.stateTransitionProbabilities[i].length];
			for (int j = 0; j < stateTransitionProbabilities[i].length; j++) 
				stateTransitionProbabilities[i][j] = original.stateTransitionProbabilities[i][j].clone();
		}
		
		stateTransitionProbabilitiesStoredInANumberObjectMatrix = NumberObject.createMatrix(model.howToRepresentNumbers, stateTransitionProbabilities);
		
		this.indexInLedger = original.indexInLedger;
		
		ledgerIndicesOfStatesInThisPatch = new int[original.ledgerIndicesOfStatesInThisPatch.length];
		for (int i = 0; i < ledgerIndicesOfStatesInThisPatch.length; i++)
			ledgerIndicesOfStatesInThisPatch[i] = original.ledgerIndicesOfStatesInThisPatch[i];
		
		this.makeImmutable();
	}
	
	/** Returns an ArrayList of Pairs. Each Pair contains an Integer and a NumberObjectSingle. The integer refers to a
	 * possible state that the patch can be in after one mutation, given that it is currently in currentPatchState.  
	 * In essence, this corresponds to a single row in the transitionProbability matrix. */
	public ArrayList <Pair<Integer, NumberObjectSingle>> getTransitionProbabilityFromPatchState(int currentPatchState){
		ArrayList<Pair<Integer, NumberObjectSingle>> transitionProbabilities = new ArrayList<>();
		
		NumberObjectSingle[] probabilities = stateTransitionProbabilities[ this.ledgerPatchStateIndexToTransitionProbabilityIndex.get(currentPatchState)];
		for (int i =0; i< ledgerIndicesOfStatesInThisPatch.length; i++)
			transitionProbabilities.add(new Pair<Integer, NumberObjectSingle>(ledgerIndicesOfStatesInThisPatch[i], probabilities[i]));
		
		return transitionProbabilities;
		
	}
	
	/** Patch can change in state over time. When an agent is in a patch, it can see what the state
	 * of the patch is. However, after it leaves, the patch can change again, and its state becomes 
	 * uncertain once again. This function computes the probability that the patch is in each state,
	 * given that the agent has observed the patch some time ago.
	 * 
	 * Specifically, this function gives the probability distribution over each PatchState this patch 
	 * can be in after the agent has last observed the patch to be in state [patchWasInPatchStateWhenLastVisit]
	 *  when it visited that patch [timeStepsSinceLastVisit] time steps ago. The probabilities are ordered by 
	 *  ledgerIndicesOfStatesInThisPatch. Thus, the first NumberObjectSingle returned corresponds to the probability
	 *  that the patch is in state ledgerIndicesOfStatesInThisPatch[0].
	 *  
	 *  Note: if an agent has never been to this state yet, timeStepsSinceLastVisit should be -1.*/
	public NumberObjectSingle[] probabilityDistributionAfterObservation (int timeStepsSinceLastVisit, int patchWasInPatchStateWhenLastVisit) {
		// First, determine the 'initial state' vector, 
		// This vector has the following values:
		//    - if the state has not been visited (timeStepsSinceLastVisit == -1): use the patches original distribution
		//    - if the state has been visited: this vector has a 1 for the patchWasInPatchStateWhenLastVisit, and 0 otherwise
		NumberObjectMatrix initialVector = NumberObject.createMatrix(model.howToRepresentNumbers, 1, ledgerIndicesOfStatesInThisPatch.length);
		for (int i = 0; i < ledgerIndicesOfStatesInThisPatch.length; i++)
			if (timeStepsSinceLastVisit >= 0 ) { // already visted before
				if (ledgerIndicesOfStatesInThisPatch[i] == patchWasInPatchStateWhenLastVisit)
					initialVector.setValueAt(0, i, 1);
				else
					initialVector.setValueAt(0, i, 0);
			} else { // not visited before
				initialVector.setValueAt(0, i, this.initialDistribution[i]);
			}

		// Second, compute the transition probabilities. That is,
		// For each time the agent was not in the patch, multiply 
		// transitionProbabilities with the initialVector
		NumberObjectMatrix resultsVec = initialVector.clone();
		for (int i = 0; i < timeStepsSinceLastVisit; i++) {
			resultsVec = resultsVec.matrixMultiplication(stateTransitionProbabilitiesStoredInANumberObjectMatrix);
		}
		NumberObjectArray probability = resultsVec.getRow(0);
		
		if (!probability.isProbability())
			throw new IllegalStateException("The probability distribution of patch [" + indexInLedger + "] after seeing it in state [" + patchWasInPatchStateWhenLastVisit + "] " + timeStepsSinceLastVisit + " ago is not a probability distribution. Distribution: " + probability.toStringWithoutTrailingZeros());
		return probability.toArray();
	}

	/** Patches can change in state over time. When an agent is in a patch, it can see what the state
	 * of the patch is. However, after it leaves, the patch can change again, and its state becomes 
	 * uncertain once again. This function computes the probability that the patch is in each state,
	 * given that the agent has observed the patch some time ago.
	 * 
	 * Both the time steps since an agent was in this patch and the state of this patch at the last visit
	 * are stored in a T1State object. Hence, we can directly compute the probabilities of each PatchState.
	 * 
	 * The probabilities are ordered by ledgerIndicesOfStatesInThisPatch. Thus, the first NumberObjectSingle 
	 * returned corresponds to the probability that the patch is in state ledgerIndicesOfStatesInThisPatch[0] */
	public NumberObjectSingle[] getProbabilityDistributionPatchStateBasedOnT1State (T1ActionState state) {
		int timeStepsSinceLastVisit = state.timeStepsSinceLastVisit(indexInLedger);
		int patchWasInPatchStateWhenLastVisit = state.patchStateDuringLastVisit(indexInLedger);
		return this.probabilityDistributionAfterObservation(timeStepsSinceLastVisit, patchWasInPatchStateWhenLastVisit);
	}

	/** Patches can change in state over time. When an agent is in a patch, it can see what the state
	 * of the patch is. However, after it leaves, the patch can change again, and its state becomes 
	 * uncertain once again. This function computes the probability that the patch is in each state,
	 * given that the agent has observed the patch some time ago.
	 * 
	 * Both the time steps since an agent was in this patch and the state of this patch at the last visit
	 * are stored in a T1StateFactory object. Hence, we can directly compute the probabilities of each PatchState.
	 * 
	 * The probabilities are ordered by ledgerIndicesOfStatesInThisPatch. Thus, the first NumberObjectSingle 
	 * returned corresponds to the probability that the patch is in state ledgerIndicesOfStatesInThisPatch[0] */
	public NumberObjectSingle[] getProbabilityDistributionPatchStateBasedOnT1State (T1ActionStateFactory factory) {
		int timeStepsSinceLastVisit = factory.lastVisitToPatch[indexInLedger];
		int patchWasInPatchStateWhenLastVisit = factory.patchStateOfLastVisit[indexInLedger];
		return this.probabilityDistributionAfterObservation(timeStepsSinceLastVisit, patchWasInPatchStateWhenLastVisit);
	}
	
	/** Set all NumberObjects's in this Patch to immutable, preventing accidental future changes*/
	public void makeImmutable() {
		for (NumberObjectSingle n : initialDistribution)
			n.makeImmutable();
		for (int i = 0; i < stateTransitionProbabilities.length; i++)
			for (NumberObjectSingle n: stateTransitionProbabilities[i])
				n.makeImmutable();
		stateTransitionProbabilitiesStoredInANumberObjectMatrix.makeImmutable();
	}
	public String toString(LedgerFactory ledgerFactory) {
		StringBuilder sb = new StringBuilder("Patch ["+this.indexInLedger+ "], containing state(s): ");
		
		for (int s : ledgerIndicesOfStatesInThisPatch)
			sb.append("\n\n"+ledgerFactory.patchStates.get(s));
		
		sb.append("\nThe states in patch [" + indexInLedger +"] have the following transition probabilities:\n" + stateTransitionProbabilitiesStoredInANumberObjectMatrix.toStringWithoutTrailingZeros() );
		sb.append("Where the rows and column correspond to the following patch state indices in the ledger: (");
		for (int i = 0; i < ledgerIndicesOfStatesInThisPatch.length; i++)
			sb.append("   row ["+i+"] -> state ["+ ledgerIndicesOfStatesInThisPatch[i] + "]");
		sb.append(")");
		sb.append("\nAt time 0 the distribution over states is: " + NumberObject.createArray(model.howToRepresentNumbers,initialDistribution).toStringWithoutTrailingZeros());
		
		return sb.toString();
	}
	
	public String toString(Ledger ledger) {
		StringBuilder sb = new StringBuilder("Patch ["+this.indexInLedger+ "], containing state(s): ");
		
		for (int s : ledgerIndicesOfStatesInThisPatch)
			sb.append("\n\n"+ledger.patchStates[s]);
		
		sb.append("\nThe states in patch [" + indexInLedger +"] have the following transition probabilities:\n" + stateTransitionProbabilitiesStoredInANumberObjectMatrix.toStringWithoutTrailingZeros() );
		sb.append("Where the rows and column correspond to the following patch state indices in the ledger: (");
		for (int i = 0; i < ledgerIndicesOfStatesInThisPatch.length; i++)
			sb.append("   row ["+i+"] -> state ["+ ledgerIndicesOfStatesInThisPatch[i] + "]");
		sb.append(")");
		sb.append("\nAt time 0 the distribution over states is: " + NumberObject.createArray(model.howToRepresentNumbers,initialDistribution).toStringWithoutTrailingZeros());
		
		return sb.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + indexInLedger;
		result = prime * result + Arrays.hashCode(initialDistribution);
		result = prime * result + Arrays.deepHashCode(stateTransitionProbabilities);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Patch other = (Patch) obj;
		if (indexInLedger != other.indexInLedger) {
			return false;
		}
		if (!Arrays.equals(initialDistribution, other.initialDistribution)) {
			return false;
		}
		if (!Arrays.deepEquals(stateTransitionProbabilities, other.stateTransitionProbabilities)) {
			return false;
		}
		return true;
	}
}
