package patch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectArray;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import decimalNumber.DecimalNumber;
import helper.Helper;
import interfaces_abstractions.ObserverManager;
import model.LedgerFactory;
import model.Model;
import objectiveElements.AbstractObjectiveTemplate;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.ExtrinsicObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import rIntegration.RFunctionContainer;
import spatialAndTemporalElements.BasePatch;
import spatialAndTemporalElements.BaseState;
import spatialAndTemporalElements.BeliefOffset;
import spatialAndTemporalElements.PatchStateTemplate;
import start.Console;
import view.Workspace;

public class PatchState {

	private final Model model;

	// Resource creation 
	public final NumberObjectSingle[][] resourceValueProbabilities; // [resource index][value index] probability
	public final NumberObjectSingle[]   resourceFrequencies; //[resource index] frequency
	
	/** How many values can a resource actually have (i.e., not including the resource values with a probability of 0)*/
	public final int[] numberOfNonZeroProbabilityResourceValues;
	
	// When searching in this PatchState, an agent might find any combination of resources, depending on the
	// frequency of these resources in this patch. For instance, suppose that there are two resource types, A and B.
	// A has a frequency of 0.9, B a frequency of 0.5. The probability distribution when searching then is:
	// 		[A, B}  		-> 0.9*0.5 = 0.45
	// 		[A, not B]		-> 0.9*(1-0.5) = 0.45
	//		[not A, B]		-> (1-0.9)*0.5 = 0.05
	//		[not A, not B]	-> (1-0.9)*(1-0.5) = 0.05
	// Rather than computing this distribution every time an agent samples in this patch state, these values
	// are precomputed when initializing a PatchState.
	private final HashMap<ArrayList<Boolean>, NumberObjectSingle> probabilityDistributionResourcesWhenSearching;
	private final HashMap<ArrayList<Boolean>, NumberObjectSingle> probabilityDistributionResourcesWhenSearchingExcludingImpossible; // Same, but all combinations with a probability of 0 are excluded.
	
	// Delay creation 
	public final NumberObjectSingle[][] delayValueProbabilities; // [delay index][value index] probability
	public final NumberObjectSingle[]   delayFrequencies; //[delay index] frequency

	/** How many duration can a delay actually have (i.e., not including the delay durations with a probability of 0)*/
	public final int[] numberOfNonZeroProbabilityDelayDurations;
	
	// Interruption creation 
	public final NumberObjectSingle[][] interruptionValueProbabilities; // [interruption index][ {false, true} ] probability
	/** How many duration can an interruption actually have (i.e., either 2 if interruptions can be both 0 and 1, or 1 otherwise)*/
	public final int[] numberOfNonZeroProbabilityInterruptions;
	
	// Extrinsic creation 
	public final NumberObjectSingle[][] extrinsicValueProbabilities; // [extrinsic index][value index] probability
	public final NumberObjectSingle[]   extrinsicFrequencies; //[extrinsic index] frequency

	/** How many values can an extrinsic event actually have (i.e., not including the extrinsic event values with a probability of 0)*/
	public final int[] numberOfNonZeroProbabilityExtrinsicValues;
	
	
	// The patch and patch state indices in the ledger
	public final int ledgerIndexOfPatch, ledgerIndexOfPatchState;

	/** Create a new PatchState based on the supplied PatchStateTemplate. This patch state registers itself in the
	 * ledgerFactory */
	public PatchState(int indexOfPatchInLedger, PatchStateTemplate template, Model model, LedgerFactory ledgerFactory, Workspace workspace){
		this.model = model;

		// First, the patch state registers itself in the ledgerFactory
		ledgerIndexOfPatch = indexOfPatchInLedger;

		synchronized (ledgerFactory) {
			if (ledgerFactory.patchStateNames.size() != ledgerFactory.patchStates.size())
				throw new IllegalStateException("There is an unequal number of patch states and patch state names in the factory ledger before creating a new patch state. ");

			ledgerFactory.patchStates.add(this);
			ledgerFactory.patchStateNames.add(template.getName());
			this.ledgerIndexOfPatchState = ledgerFactory.patchStateNames.size() -1;

			if (ledgerFactory.patchStateNames.size() != ledgerFactory.patchStates.size())
				throw new IllegalStateException("There is an unequal number of patch states and patch state names in the factory ledger after creating a new patch state. ");
			if (template.getPatch() == BasePatch.get() && template == BaseState.get())
				ledgerFactory.baseStateIndex = ledgerIndexOfPatchState;
		}

		// Create the resource arrays 
		resourceValueProbabilities = new NumberObjectSingle[ledgerFactory.resourceNames.size()][];
		resourceFrequencies = new NumberObjectSingle[ledgerFactory.resourceNames.size()];
		numberOfNonZeroProbabilityResourceValues = new int[ledgerFactory.resourceNames.size()];
		
		// Create the interruption arrays 
		interruptionValueProbabilities = new NumberObjectSingle[ledgerFactory.interruptionNames.size()][];
		//interruptionFrequencies = new DecimalNumber[ledgerFactory.interruptionNames.size()];
		numberOfNonZeroProbabilityInterruptions = new int[ledgerFactory.interruptionNames.size()];
		
		// Create the delay arrays 
		delayValueProbabilities = new NumberObjectSingle[ledgerFactory.delayNames.size()][];
		delayFrequencies = new NumberObjectSingle[ledgerFactory.delayNames.size()];
		numberOfNonZeroProbabilityDelayDurations = new int[ledgerFactory.delayNames.size()];
		
		// Create the extrinsic arrays 
		extrinsicValueProbabilities = new NumberObjectSingle[ledgerFactory.extrinsicNames.size()][];
		extrinsicFrequencies = new NumberObjectSingle[ledgerFactory.extrinsicNames.size()];
		numberOfNonZeroProbabilityExtrinsicValues = new int[ledgerFactory.extrinsicNames.size()];
		

		// populate the arrays
		for (String resourceName : ledgerFactory.resourceNames) 
			populateObjectArrays( template,  ledgerFactory,  workspace, resourceName, ledgerFactory.resourceNames, resourceValueProbabilities,numberOfNonZeroProbabilityResourceValues, resourceFrequencies);
		for (String delayName : ledgerFactory.delayNames) 
			populateObjectArrays( template,  ledgerFactory,  workspace, delayName, ledgerFactory.delayNames, delayValueProbabilities,numberOfNonZeroProbabilityDelayDurations, delayFrequencies);
		for (String interruptionName : ledgerFactory.interruptionNames) 
			populateObjectArrays( template,  ledgerFactory,  workspace, interruptionName, ledgerFactory.interruptionNames, interruptionValueProbabilities,numberOfNonZeroProbabilityInterruptions, null);
		for (String extrinsicName : ledgerFactory.extrinsicNames) 
			populateObjectArrays( template,  ledgerFactory,  workspace, extrinsicName, ledgerFactory.extrinsicNames, extrinsicValueProbabilities, numberOfNonZeroProbabilityExtrinsicValues,extrinsicFrequencies);

		// Note if there are learn-by-experience belief offsets
		registerResourceBeliefOffsets(template, ledgerFactory, workspace);
		registerExtrinsicBeliefOffsets(template, ledgerFactory, workspace);
		registerDelayBeliefOffsets(template, ledgerFactory, workspace);
		registerInterruptionBeliefOffsets(template, ledgerFactory, workspace);

		// Create a HashMap that maps an arraylist of booleans with size |r| to a probability distribution, where 
		// r is the number of reource types. In essence, this array list contains the outcome of searching:
		// when searching, which resources (a combination of true's and/or false's) will an agent encounter,
		// and with what probability?
		probabilityDistributionResourcesWhenSearching = new HashMap<>();
		probabilityDistributionResourcesWhenSearchingExcludingImpossible = new HashMap<>();
		
		// Step 1: figure out what resources are found after searching.
		// The probability of findings a resource of type r depends on the frequency of
		// that resource. Note that if there are |r| resource types, there are |r|^2 combinations
		// of encountered resources. Each have their own probability. Here we compute first all possible combinations
		// of encountered resources, and the probability of that combination. We'll store that in a HashMap that
		// links the combination to the probability
		
		// Using recursion, find all permutations (yeah, above I called them combinations, but they really are permutations)
		ArrayList<ArrayList<Boolean>> possibleValues = new ArrayList<>();
		ArrayList<Boolean> trueFalseList = new ArrayList<Boolean>();
		trueFalseList.add(true);
		trueFalseList.add(false);
		for (int r = 0; r < ledgerFactory.resourceNames.size(); r++)
			possibleValues.add(trueFalseList);
		ArrayList<ArrayList<Boolean>> possiblePermutations = Helper.getAllPermutations(possibleValues);

		// Compute for each possible permutation the probability of encountering the set of resources, and add to the HashMap
		for (ArrayList<Boolean> permutation: possiblePermutations) {
			NumberObjectSingle probability = NumberObject.createNumber(model.howToRepresentNumbers, 1);
			for (int r = 0; r < permutation.size(); r++)
				if (permutation.get(r)) probability.multiply(resourceFrequencies[r], true);
				else probability.multiply(resourceFrequencies[r].complementOfOne(), true);
			probabilityDistributionResourcesWhenSearching.put(permutation, probability);
			if (!probability.equals(0))
				probabilityDistributionResourcesWhenSearchingExcludingImpossible.put(permutation, probability);
		}
		
		// If the model wants us to be careful: run a test
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (ArrayList<Boolean> entry : probabilityDistributionResourcesWhenSearching.keySet())
				if (probabilityDistributionResourcesWhenSearching.get(entry).smallerThan(0, true))
					throw new IllegalStateException("At least one set of encountered resources has a non-positive probability.");
				else
					sum.add(probabilityDistributionResourcesWhenSearching.get(entry), true);
			if (!sum.equals(1, true))
				throw new IllegalStateException("Total probability of all possible encountered resources does not sum to 1. Sum = " + sum.toStringWithoutTrailingZeros());
		}

	}

	/** Deep clone constructor */
	public PatchState(PatchState original) {
		this.model = original.model;
		this.probabilityDistributionResourcesWhenSearching = original.probabilityDistributionResourcesWhenSearching;
		this.probabilityDistributionResourcesWhenSearchingExcludingImpossible = original.probabilityDistributionResourcesWhenSearchingExcludingImpossible;
		resourceValueProbabilities	= new NumberObjectSingle[original.resourceValueProbabilities.length][];
		for (int i = 0; i < resourceValueProbabilities.length; i++) {
			if (original.resourceValueProbabilities[i] != null) {
				resourceValueProbabilities[i] = new NumberObjectSingle[original.resourceValueProbabilities[i].length];
				for (int j = 0; j < resourceValueProbabilities[i].length; j++) 
					resourceValueProbabilities[i][j] = original.resourceValueProbabilities[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone(); 
			}
		}
		numberOfNonZeroProbabilityResourceValues = new int[original.numberOfNonZeroProbabilityResourceValues.length];
		for (int i = 0; i < numberOfNonZeroProbabilityResourceValues.length; i++ )
			numberOfNonZeroProbabilityResourceValues[i] = original.numberOfNonZeroProbabilityResourceValues[i];
		
		resourceFrequencies = new NumberObjectSingle[original.resourceFrequencies.length];
		for (int i = 0; i < resourceFrequencies.length; i++ )
			resourceFrequencies[i] = original.resourceFrequencies[i].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		
		
		delayValueProbabilities	= new NumberObjectSingle[original.delayValueProbabilities.length][];
		for (int i = 0; i < delayValueProbabilities.length; i++) {
			delayValueProbabilities[i] = new NumberObjectSingle[original.delayValueProbabilities[i].length];
			for (int j = 0; j < delayValueProbabilities[i].length; j++) 
				delayValueProbabilities[i][j] = original.delayValueProbabilities[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		}
		numberOfNonZeroProbabilityDelayDurations = new int[original.numberOfNonZeroProbabilityDelayDurations.length];
		for (int i = 0; i < numberOfNonZeroProbabilityDelayDurations.length; i++ )
			numberOfNonZeroProbabilityDelayDurations[i] = original.numberOfNonZeroProbabilityDelayDurations[i];
		delayFrequencies = new NumberObjectSingle[original.delayFrequencies.length];
		for (int i = 0; i < delayFrequencies.length; i++ )
			delayFrequencies[i] = original.delayFrequencies[i].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		
		
		interruptionValueProbabilities	= new NumberObjectSingle[original.interruptionValueProbabilities.length][];
		for (int i = 0; i < interruptionValueProbabilities.length; i++) {
			interruptionValueProbabilities[i] = new NumberObjectSingle[original.interruptionValueProbabilities[i].length];
			for (int j = 0; j < interruptionValueProbabilities[i].length; j++) 
				interruptionValueProbabilities[i][j] = original.interruptionValueProbabilities[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		}
		numberOfNonZeroProbabilityInterruptions = new int[original.numberOfNonZeroProbabilityInterruptions.length];
		for (int i = 0; i < numberOfNonZeroProbabilityInterruptions.length; i++ )
			numberOfNonZeroProbabilityInterruptions[i] = original.numberOfNonZeroProbabilityInterruptions[i];
		
		extrinsicValueProbabilities	= new NumberObjectSingle[original.extrinsicValueProbabilities.length][];
		for (int i = 0; i < extrinsicValueProbabilities.length; i++) {
			extrinsicValueProbabilities[i] = new NumberObjectSingle[original.extrinsicValueProbabilities[i].length];
			for (int j = 0; j < extrinsicValueProbabilities[i].length; j++) 
				extrinsicValueProbabilities[i][j] = original.extrinsicValueProbabilities[i][j].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		}
		numberOfNonZeroProbabilityExtrinsicValues = new int[original.numberOfNonZeroProbabilityExtrinsicValues.length];
		for (int i = 0; i < numberOfNonZeroProbabilityExtrinsicValues.length; i++ )
			numberOfNonZeroProbabilityExtrinsicValues[i] = original.numberOfNonZeroProbabilityExtrinsicValues[i];
		
		extrinsicFrequencies = new NumberObjectSingle[original.extrinsicFrequencies.length];
		for (int i = 0; i < extrinsicFrequencies.length; i++ )
			extrinsicFrequencies[i] = original.extrinsicFrequencies[i].toNumberObjectSingle(model.howToRepresentNumbers).clone();
		
		this.ledgerIndexOfPatch = original.ledgerIndexOfPatch;
		this.ledgerIndexOfPatchState = original.ledgerIndexOfPatchState;
		
		this.makeImmutable();
	}
	
	/** Computes the probability of all the values of the object and that objects frequency in this patch (i.e., with the 
	 * patch specific offsets applied), and stores the results in the supplied array (and array of arrays) */
	private void populateObjectArrays(PatchStateTemplate template, 
			LedgerFactory ledgerFactory,
			Workspace workspace, 
			String objectName, 
			ArrayList<String> arrayListOfNameInLedger, 
			NumberObjectSingle[][] probabilityArrayToUse, 
			int[] nonZeroProbabilityCountToUse,
			NumberObjectSingle[] frequencyArrayToUse) {
		try {
			// Get the AbstractObjectiveTemplate from the workspace
			AbstractObjectiveTemplate objectTemplate = workspace.getObject(objectName);

			// Get the index of this object in the Ledger
			int indexOfObject = -1;
			for (int i = 0; i < arrayListOfNameInLedger.size(); i++)
				if (arrayListOfNameInLedger.get(i).equals(objectName))
					indexOfObject = i;
			if (indexOfObject == -1)
				throw new IllegalStateException("Trying to create a probability distribution for object '" + objectName + "'. However, no such object in registered in the ledger yet" );

			// Is the object constant? If so, we only have to register the frequency (if its not an interruption) and a single probability
			if (objectTemplate.isConstant()) {
				probabilityArrayToUse[indexOfObject] = new NumberObjectSingle[] { NumberObject.createNumber(model.howToRepresentNumbers, 1)}; // constants have a single possible value, that occurs with probability 1.
				nonZeroProbabilityCountToUse[indexOfObject] = 1;
				if (!(objectTemplate instanceof InterruptionObjectTemplate))
					frequencyArrayToUse[indexOfObject] = objectTemplate.getFrequency().clone();
				return;
			}


			// If the object is not constant: get the sampling distribution for this object
			RFunctionContainer samplingDistribution = objectTemplate.getAllSamplingDistributions().get(model.whichSamplingDistributionToUse(objectTemplate));
			NumberObjectSingle frequency = null;

			// Reminder: interruptions do not have frequencies!
			if (!(objectTemplate instanceof InterruptionObjectTemplate))
				frequency = objectTemplate.getFrequency().clone().toNumberObjectSingle(model.howToRepresentNumbers);

			// Is there an offset for this object?
			// If so, change the samplingDistribution and frequency accordingly
			if (template.hasFrequencyOffsetFor(objectTemplate)) 
				frequency = template.getOffsettedObject(objectTemplate).getOffsettedFrequency().clone().toNumberObjectSingle(model.howToRepresentNumbers);
			if (template.hasValueOffsetFor(objectTemplate))
				samplingDistribution = template.getOffsettedObject(objectTemplate).getOffsettedValueDistribution(samplingDistribution);

			// Based on the sampling distribution, create the probability distribution of all values
			NumberObjectArray probabilityDistribution = ((NumberObjectArray) samplingDistribution.runInR()[0]).toNumberObjectArray(model.howToRepresentNumbers);
			if (!probabilityDistribution.isProbability())
				throw new IllegalStateException("The distribution of object '" + objectName + "' in patch state '" + template.getName() + "' is not a probability distribution: it does not sum to 1 or there is a negative entry. "
						+ "The distribution is: " + probabilityDistribution.toStringWithoutTrailingZeros() + ". Sum = " + probabilityDistribution.sum().toStringWithoutTrailingZeros() );

			// Count the number of non-zero probabilities
			NumberObjectSingle[] array = (NumberObjectSingle[]) probabilityDistribution.toArray();
			int nonZero = 0;
			for (NumberObjectSingle n:array)
				if (!n.equals(0))
					nonZero += 1;
			
			// Store in the supplied arrays. Note, again, that interruptions do not have frequencies!
			probabilityArrayToUse[indexOfObject] = array;
			nonZeroProbabilityCountToUse[indexOfObject] = nonZero;
			if (!(objectTemplate instanceof InterruptionObjectTemplate))
				frequencyArrayToUse[indexOfObject] = frequency;


		} catch (Exception e) { 
			ObserverManager.notifyObserversOfError(e);
			model.outputFileManager.writeExceptionToFile(e);
		}

	}

	/** Fills the experience and belief related ArrayLists in the LedgerFactory for all resources.  */
	private void registerResourceBeliefOffsets(PatchStateTemplate template, LedgerFactory ledgerFactory,Workspace workspace) {
		//Yes, it's a lot of copy-and-paste work. Yes, it's nasty. But it works. And I really couldn't be bothered to do this in a smart way.

		// Register beliefs for all resource objects
		for (int i = 0; i < ledgerFactory.resourceNames.size(); i ++ ) {

			//Get the name of the resource
			String resourceName = ledgerFactory.resourceNames.get(i);
			ResourceObjectTemplate resourceTemplate = (ResourceObjectTemplate) workspace.getObject(resourceName);

			// Does the agent learn by experience for this object in this patchState?
			// That is, is there A) a belief offset, and B) is this BeliefOffset learned?
			boolean learnByExperience = false;
			if (template.containsOffsetFor(resourceTemplate.getBelief()))
				learnByExperience = template.getOffsettedBelief(resourceTemplate.getBelief()).isLearned();

			// Exception: learnByExperience is true even without a belief offset if this is the BaseState 
			if (template == BaseState.get() && resourceTemplate.getBelief()!=null)
				if (!resourceTemplate.getBelief().isKnownDistribution())
					learnByExperience = true;

			// Make sure that ledgerFactory.resourceLearnByExperienceInPatchState (which is initialized already by the model)
			// has at least n indices, where n is the index of this patchState
			while (ledgerFactory.resourceLearnByExperienceInPatchState.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.resourceLearnByExperienceInPatchState.get(i).add(null);

			// At the location ledgerIndexOfPatchState: store learnByExperience
			ledgerFactory.resourceLearnByExperienceInPatchState.get(i).set(ledgerIndexOfPatchState, learnByExperience);

			//Make sure that there are enough indices in resourceStartingExperiences to add the prior experiences for this patch state
			while (ledgerFactory.resourceStartingExperiences.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.resourceStartingExperiences.get(i).add(null);

			// if we have to learn by experience, we also have to store the prior experiences in the LedgerFactory
			if (!learnByExperience)
				return;

			// Create a new ArrayList
			ledgerFactory.resourceStartingExperiences.get(i).set(ledgerIndexOfPatchState, new ArrayList<>());

			// Next, if this is the base state: just add the 'normal' (non-offsetted) prior observations
			if (template == BaseState.get()) {
				NumberObjectSingle[] resourceValues = ledgerFactory.resourceValues.get(i);
				for (int v = 0; v < resourceValues.length; v++)
					ledgerFactory.resourceStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
							resourceTemplate.getBelief().getObservedCount(ledgerFactory.resourceValues.get(i)[v].toDecimalNumber()));
				return;
			}

			// If not the base state: get the state specific offset
			BeliefOffset offset = template.getOffsettedBelief(resourceTemplate.getBelief());

			// Feed all possible object values in the LedgerFactory for this object into the offset, and store the result 
			for (int v = 0; v < ledgerFactory.resourceValues.get(i).length; v++)
				ledgerFactory.resourceStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
						offset.getPatchSpecificObservations(ledgerFactory.resourceValues.get(i)[v].toDecimalNumber()));
		}
	}

	/** Fills the experience and belief related ArrayLists in the LedgerFactory for all extrinsic events.  */
	private void registerExtrinsicBeliefOffsets(PatchStateTemplate template, LedgerFactory ledgerFactory,Workspace workspace) {
		// Register beliefs for all extrinsic objects
		for (int i = 0; i < ledgerFactory.extrinsicNames.size(); i ++ ) {

			//Get the name of the extrinsic event
			String extrinsicName = ledgerFactory.extrinsicNames.get(i);
			ExtrinsicObjectTemplate extrinsicTemplate = (ExtrinsicObjectTemplate) workspace.getObject(extrinsicName);

			// Does the agent learn by experience for this object in this patchState?
			// That is, is there A) a belief offset, and B) is this BeliefOffset learned?
			boolean learnByExperience = false;
			if (template.containsOffsetFor(extrinsicTemplate.getBelief()))
				learnByExperience = template.getOffsettedBelief(extrinsicTemplate.getBelief()).isLearned();

			// Exception: learnByExperience is true even without a belief offset if this is the BaseState 
			if (template == BaseState.get() && extrinsicTemplate.getBelief()!=null)
				if (!extrinsicTemplate.getBelief().isKnownDistribution())
					learnByExperience = true;

			// Make sure that ledgerFactory.extrinsicLearnByExperienceInPatchState (which is initialized already by the model)
			// has at least n indices, where n is the index of this patchState
			while (ledgerFactory.extrinsicLearnByExperienceInPatchState.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.extrinsicLearnByExperienceInPatchState.get(i).add(null);

			// At the location ledgerIndexOfPatchState: store learnByExperience
			ledgerFactory.extrinsicLearnByExperienceInPatchState.get(i).set(ledgerIndexOfPatchState, learnByExperience);

			// Make sure that there are enough indices in extrinsicStartingExperiences to add the prior experiences for this patch state
			while (ledgerFactory.extrinsicStartingExperiences.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.extrinsicStartingExperiences.get(i).add(null);

			// if we have to learn by experience, we also have to store the prior experiences in the LedgerFactory
			if (!learnByExperience)
				return;

			// Create a new ArrayList
			ledgerFactory.extrinsicStartingExperiences.get(i).set(ledgerIndexOfPatchState, new ArrayList<>());

			// Next, if this is the base state: just add the 'normal' (non-offsetted) prior observations
			if (template == BaseState.get()) {
				NumberObjectSingle[] extrinsicValues = ledgerFactory.extrinsicValues.get(i);
				for (int v = 0; v < extrinsicValues.length; v++)
					ledgerFactory.extrinsicStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
							extrinsicTemplate.getBelief().getObservedCount(ledgerFactory.extrinsicValues.get(i)[v].toDecimalNumber()));
				return;
			}

			// If not the base state: get the state specific offset
			BeliefOffset offset = template.getOffsettedBelief(extrinsicTemplate.getBelief());

			// Feed all possible object values in the LedgerFactory for this object into the offset, and store the result 
			for (int v = 0; v < ledgerFactory.extrinsicValues.get(i).length; v++)
				ledgerFactory.extrinsicStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
						offset.getPatchSpecificObservations(ledgerFactory.extrinsicValues.get(i)[v].toDecimalNumber()));
		}
	}


	/** Fills the experience and belief related ArrayLists in the LedgerFactory for all delays.  */
	private void registerDelayBeliefOffsets(PatchStateTemplate template, LedgerFactory ledgerFactory,Workspace workspace) {

		// Register beliefs for all delay objects
		for (int i = 0; i < ledgerFactory.delayNames.size(); i ++ ) {

			//Get the name of the delay
			String delayName = ledgerFactory.delayNames.get(i);
			DelayObjectTemplate delayTemplate = (DelayObjectTemplate) workspace.getObject(delayName);

			// Does the agent learn by experience for this object in this patchState?
			// That is, is there A) a belief offset, and B) is this BeliefOffset learned?
			boolean learnByExperience = false;
			if (template.containsOffsetFor(delayTemplate.getBelief()))
				learnByExperience = template.getOffsettedBelief(delayTemplate.getBelief()).isLearned();

			// Exception: learnByExperience is true even without a belief offset if this is the BaseState 
			if (template == BaseState.get() && delayTemplate.getBelief()!=null)
				if (!delayTemplate.getBelief().isKnownDistribution())
					learnByExperience = true;

			// Make sure that ledgerFactory.delayLearnByExperienceInPatchState (which is initialized already by the model)
			// has at least n indices, where n is the index of this patchState
			while (ledgerFactory.delayLearnByExperienceInPatchState.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.delayLearnByExperienceInPatchState.get(i).add(null);

			// At the location ledgerIndexOfPatchState: store learnByExperience
			ledgerFactory.delayLearnByExperienceInPatchState.get(i).set(ledgerIndexOfPatchState, learnByExperience);

			// Make sure that there are enough indices in delayStartingExperiences to add the prior experiences for this patch state 
			while (ledgerFactory.delayStartingExperiences.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.delayStartingExperiences.get(i).add(null);

			// if we have to learn by experience, we also have to store the prior experiences in the LedgerFactory
			if (!learnByExperience)
				return;

			// Create a new ArrayList
			ledgerFactory.delayStartingExperiences.get(i).set(ledgerIndexOfPatchState, new ArrayList<>());

			// Next, if this is the base state: just add the 'normal' (non-offsetted) prior observations
			if (template == BaseState.get()) {
				Integer[] delayValues = ledgerFactory.delayValues.get(i);
				for (int v = 0; v < delayValues.length; v++)
					ledgerFactory.delayStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
							delayTemplate.getBelief().getObservedCount( new DecimalNumber(ledgerFactory.delayValues.get(i)[v])));
				return;
			}

			// If not the base state: get the state specific offset
			BeliefOffset offset = template.getOffsettedBelief(delayTemplate.getBelief());

			// Feed all possible object values in the LedgerFactory for this object into the offset, and store the result 
			for (int v = 0; v < ledgerFactory.delayValues.get(i).length; v++)
				ledgerFactory.delayStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
						offset.getPatchSpecificObservations(new DecimalNumber(ledgerFactory.delayValues.get(i)[v])));
		}

	}


	/** Fills the experience and belief related ArrayLists in the LedgerFactory for all interruptions.  */
	private void registerInterruptionBeliefOffsets(PatchStateTemplate template, LedgerFactory ledgerFactory,Workspace workspace) {
		// Register beliefs for all interruption objects
		for (int i = 0; i < ledgerFactory.interruptionNames.size(); i ++ ) {

			//Get the name of the interruption
			String interruptionName = ledgerFactory.interruptionNames.get(i);
			InterruptionObjectTemplate interruptionTemplate = (InterruptionObjectTemplate) workspace.getObject(interruptionName);

			// Does the agent learn by experience for this object in this patchState?
			// That is, is there A) a belief offset, and B) is this BeliefOffset learned?
			boolean learnByExperience = false;
			if (template.containsOffsetFor(interruptionTemplate.getBelief()))
				learnByExperience = template.getOffsettedBelief(interruptionTemplate.getBelief()).isLearned();

			// Exception: learnByExperience is true even without a belief offset if this is the BaseState 
			if (template == BaseState.get() && interruptionTemplate.getBelief()!=null)
				if (!interruptionTemplate.getBelief().isKnownDistribution())
					learnByExperience = true;

			// Make sure that ledgerFactory.interruptionLearnByExperienceInPatchState (which is initialized already by the model)
			// has at least n indices, where n is the index of this patchState
			while (ledgerFactory.interruptionLearnByExperienceInPatchState.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.interruptionLearnByExperienceInPatchState.get(i).add(null);

			// At the location ledgerIndexOfPatchState: store learnByExperience
			ledgerFactory.interruptionLearnByExperienceInPatchState.get(i).set(ledgerIndexOfPatchState, learnByExperience);

			// Make sure that there are enough indices in interruptionStartingExperiences to add the prior experiences for this patch state
			while (ledgerFactory.interruptionStartingExperiences.get(i).size() <= this.ledgerIndexOfPatchState)
				ledgerFactory.interruptionStartingExperiences.get(i).add(null);

			
			// if we have to learn by experience, we also have to store the prior experiences in the LedgerFactory
			if (!learnByExperience)
				return;

			// Create a new ArrayList
			ledgerFactory.interruptionStartingExperiences.get(i).set(ledgerIndexOfPatchState, new ArrayList<>());

			// Next, if this is the base state: just add the 'normal' (non-offsetted) prior observations
			Integer[] interruptionValues = new Integer[] {0, 1};
			if (template == BaseState.get()) {
				for (int v = 0; v < interruptionValues.length; v++)
					ledgerFactory.interruptionStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
							interruptionTemplate.getBelief().getObservedCount(new DecimalNumber( interruptionValues[v])));
				return;
			}

			// If not the base state: get the state specific offset
			BeliefOffset offset = template.getOffsettedBelief(interruptionTemplate.getBelief());

			// Feed all possible object values in the LedgerFactory for this object into the offset, and store the result 
			for (int v = 0; v < interruptionValues.length; v++)
				ledgerFactory.interruptionStartingExperiences.get(i).get(this.ledgerIndexOfPatchState).add(v, 
						offset.getPatchSpecificObservations(new DecimalNumber (interruptionValues[v])));
		}
	}

	/** When searching in this PatchState, an agent might find any combination of resources, depending on the
	 * frequency of these resources in this patch. For instance, suppose that there are two resource types, A and B.
	 * A has a frequency of 0.9, B a frequency of 0.5. The probability distribution when searching then is:
	 * 		[A, B}  		-> 0.9*0.5 = 0.45
	 * 		[A, not B]		-> 0.9*(1-0.5) = 0.45
	 *		[not A, B]		-> (1-0.9)*0.5 = 0.05
	 *		[not A, not B]	-> (1-0.9)*(1-0.5) = 0.05
	 * Rather than computing this distribution every time an agent samples in this patch state, these values
	 * are precomputed when initializing a PatchState.
	 * 
	 * This function returns a HashMap that links an ArrayList of booleans (representing which resources
	 * are found when searching) to the probability of encountering that specific set of resources, for all
	 * possible combinations of resources that might be encountered when searching.
	 * 
	 */
	public HashMap<ArrayList<Boolean>, NumberObjectSingle> getProbabilityDistributionResourcesWhenSearching (){
		return this.probabilityDistributionResourcesWhenSearching;
	}

	/** When searching in this PatchState, an agent might find any combination of resources, depending on the
	 * frequency of these resources in this patch. For instance, suppose that there are two resource types, A and B.
	 * A has a frequency of 0.9, B a frequency of 0.5. The probability distribution when searching then is:
	 * 		[A, B}  		-> 0.9*0.5 = 0.45
	 * 		[A, not B]		-> 0.9*(1-0.5) = 0.45
	 *		[not A, B]		-> (1-0.9)*0.5 = 0.05
	 *		[not A, not B]	-> (1-0.9)*(1-0.5) = 0.05
	 * Rather than computing this distribution every time an agent samples in this patch state, these values
	 * are precomputed when initializing a PatchState.
	 * 
	 * This function returns a HashMap that links an ArrayList of booleans (representing which resources
	 * are found when searching) to the probability of encountering that specific set of resources, for all
	 * possible combinations of resources that might be encountered when searching. Note that all combinations
	 * that are impossible (i.e., have a probability of 0) are excluded.
	 * 
	 */
	public HashMap<ArrayList<Boolean>, NumberObjectSingle> getProbabilityDistributionResourcesWhenSearchingExcludingImpossible (){
		return this.probabilityDistributionResourcesWhenSearchingExcludingImpossible;
	}
	
	/** When searching in this PatchState, an agent might find any combination of resources, depending on the
	 * frequency of these resources in this patch. For instance, suppose that there are two resource types, A and B.
	 * A has a frequency of 0.9, B a frequency of 0.5. The probability distribution when searching then is:
	 * 		[A, B}  		-> 0.9*0.5 = 0.45
	 * 		[A, not B]		-> 0.9*(1-0.5) = 0.45
	 *		[not A, B]		-> (1-0.9)*0.5 = 0.05
	 *		[not A, not B]	-> (1-0.9)*(1-0.5) = 0.05
	 * Rather than computing this distribution every time an agent samples in this patch state, these values
	 * are precomputed when initializing a PatchState.
	 * 
	 * This function returns the probability of a single set of encountered resources (e.g., "A, not B")
	 * 
	 */
	public NumberObjectSingle getProbabilityDistributionResourcesWhenSearching (ArrayList<Boolean> encounteredResources){
		return this.probabilityDistributionResourcesWhenSearching.get(encounteredResources);
	}
	
	/** Set all NumberObjects's in this Patch to immutable, preventing accidental future changes*/
	public void makeImmutable() {
		for (int i = 0; i < resourceValueProbabilities.length ; i++)
			for (int j = 0; j < resourceValueProbabilities[i].length; j++)
				resourceValueProbabilities[i][j].makeImmutable();
		for (int i = 0; i < resourceFrequencies.length ; i++)
			resourceFrequencies[i].makeImmutable();
		
		for (int i = 0; i < delayValueProbabilities.length ; i++)
			for (int j = 0; j < delayValueProbabilities[i].length; j++)
				delayValueProbabilities[i][j].makeImmutable();
		for (int i = 0; i < delayFrequencies.length ; i++)
			delayFrequencies[i].makeImmutable();
		
		for (int i = 0; i < interruptionValueProbabilities.length ; i++)
			for (int j = 0; j < interruptionValueProbabilities[i].length; j++)
				interruptionValueProbabilities[i][j].makeImmutable();
		
		for (int i = 0; i < extrinsicValueProbabilities.length ; i++)
			for (int j = 0; j < extrinsicValueProbabilities[i].length; j++)
				extrinsicValueProbabilities[i][j].makeImmutable();
		for (int i = 0; i < extrinsicFrequencies.length ; i++)
			extrinsicFrequencies[i].makeImmutable();
		
	}
	public String toString() {
		StringBuilder sb = new StringBuilder("Patch [" + ledgerIndexOfPatch + "], state [" + ledgerIndexOfPatchState + "]");

		sb.append("\n-Resources \n\tProbabilities:");
		for (int i = 0; i < resourceValueProbabilities.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(resourceValueProbabilities[i]));
		sb.append("\n\tFrequencies:");
		for (int i = 0; i < resourceFrequencies.length; i++)
			sb.append("\n\t["+i+"]:\t" + resourceFrequencies[i].toStringWithoutTrailingZeros());
		sb.append("\n\tResource encounter probabilities:");
		for (ArrayList<Boolean> set : probabilityDistributionResourcesWhenSearching.keySet())
			sb.append("\n\t["+Helper.arrayListToString(set)+"], with probability " + probabilityDistributionResourcesWhenSearching.get(set).toStringWithoutTrailingZeros());


		
		sb.append("\n\n-Delays \n\tProbabilities:");
		for (int i = 0; i < delayValueProbabilities.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(delayValueProbabilities[i]));
		sb.append("\n\tFrequencies:");
		for (int i = 0; i < delayFrequencies.length; i++)
			sb.append("\n\t["+i+"]:\t" + delayFrequencies[i].toStringWithoutTrailingZeros());

		sb.append("\n\n-Interruptions \n\tProbabilities:");
		for (int i = 0; i < interruptionValueProbabilities.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(interruptionValueProbabilities[i]));

		sb.append("\n\n-Extrinsic events \n\tProbabilities:");
		for (int i = 0; i < extrinsicValueProbabilities.length; i ++) 
			sb.append("\n\t[" + i + "]:\t" + Helper.arrayToString(extrinsicValueProbabilities[i]));
		sb.append("\n\tFrequencies:");
		for (int i = 0; i < extrinsicFrequencies.length; i++)
			sb.append("\n\t["+i+"]:\t" + extrinsicFrequencies[i].toStringWithoutTrailingZeros());

		return sb.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(delayFrequencies);
		result = prime * result + Arrays.deepHashCode(delayValueProbabilities);
		result = prime * result + Arrays.hashCode(extrinsicFrequencies);
		result = prime * result + Arrays.deepHashCode(extrinsicValueProbabilities);
		result = prime * result + Arrays.deepHashCode(interruptionValueProbabilities);
		result = prime * result + ledgerIndexOfPatch;
		result = prime * result + Arrays.hashCode(resourceFrequencies);
		result = prime * result + Arrays.deepHashCode(resourceValueProbabilities);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		PatchState other = (PatchState) obj;
		if (!Arrays.equals(delayFrequencies, other.delayFrequencies)) {
			return false;
		}
		if (!Arrays.deepEquals(delayValueProbabilities, other.delayValueProbabilities)) {
			return false;
		}
		if (!Arrays.equals(extrinsicFrequencies, other.extrinsicFrequencies)) {
			return false;
		}
		if (!Arrays.deepEquals(extrinsicValueProbabilities, other.extrinsicValueProbabilities)) {
			return false;
		}
		if (!Arrays.deepEquals(interruptionValueProbabilities, other.interruptionValueProbabilities)) {
			return false;
		}
		if (ledgerIndexOfPatch != other.ledgerIndexOfPatch) {
			return false;
		}
		if (!Arrays.equals(resourceFrequencies, other.resourceFrequencies)) {
			return false;
		}
		if (!Arrays.deepEquals(resourceValueProbabilities, other.resourceValueProbabilities)) {
			return false;
		}
		if (!probabilityDistributionResourcesWhenSearching.equals(other.getProbabilityDistributionResourcesWhenSearching()))
			return false;
		return true;
	}
}
