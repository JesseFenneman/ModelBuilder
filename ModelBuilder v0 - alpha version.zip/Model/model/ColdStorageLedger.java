package model;

import start.Console;

/** During runtime, many objects need to access the Ledger class. After construction, there 
 * should never, ever, be a change to anything in a Ledger. However, it would be 
 * rather slow to set all fields in the Ledger to be private, and have getters that make
 * copies of everything. So instead, here is a less-safe-but-safe-enough solution: a safe!
 * 
 *  Or rather, a ColdStorageLedger takes a Ledger, and makes deep copies of all fields. This
 *  ColdStorageLedger should be accessible only by the model - without anything have any 
 *  access to it whatsoever. After the model is done doing its modeling things, we can then
 *  compare whether its current ledger still matches the cold storage ledger. Even if all fields
 *  are identical, we can never be sure that there were no changes - changes could have 
 *  balanced each other out. However, we are at least a bit more certain that no changes have occurred. */
class ColdStorageLedger {

	private final Ledger coldStorageLedger;
	
	public ColdStorageLedger(LedgerFactory ledgerFactory, Model model) {
		this.coldStorageLedger = new Ledger(ledgerFactory,model);
	}
	
	/** The cold storage contains a copy of the ledger. At the start of the model's run
	 * the copy stored here is identical to the copy used throughout. This function compares
	 * the two versions, and returns whether they are still equal. Throws IllegalStateException
	 * if the two version do not match.*/
	public void validateVersions(Ledger ledger) {
		boolean equals = this.coldStorageLedger.equals(ledger);
		Console.print("Validating ledger integrity. Hash of stored version = (" + coldStorageLedger.hashCode() + ") hash of current version = (" +  ledger.hashCode() + "). Deep equals: " + equals);
		if (!equals)
			throw new IllegalStateException("Ledger validation failure! Results cannot be trusted.");
	}
}
