package model;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import belief.Cue;
import deathConditions.DeathCondition;
import helper.Helper;
import mutations.Mutation;
import mutations.ObjectMutator;
import patch.Patch;
import patch.PatchState;
import rIntegration.RFunctionContainer;
import t1Actions.T1Action;
import t2Actions.T2Action;

/** In the Ledger class all fields are final (that way, there are no
 * accidental overwrites). However, making a single constructor for the 
 * Ledger that contains all information in the Ledger is tedious, and
 * does little to help understanding. To make construction easier, the 
 * LedgerFactory is an object in which all fields can be placed. The factory
 * is then passed to the Ledger's constructor, which will finalize everything.*/
public class LedgerFactory {

	// Phenotype ArrayLists
	public final ArrayList<String> phenotypeNames;
	public final ArrayList<NumberObjectSingle[]> phenotypeValues;
	public final ArrayList<NumberObjectSingle> phenotypeStepsize;
	
	// Resource related ArrayLists
	public final ArrayList<String> resourceNames;
	public final ArrayList<NumberObjectSingle[]> resourceValues;
	public final ArrayList<NumberObjectSingle> resourceStepsize;
	public final ArrayList<Cue> resourceCues;
	public final ArrayList<String[]> resourceCueLabels;

	// Extrinsic related ArrayLists
	public final ArrayList<String> extrinsicNames;
	public final ArrayList<NumberObjectSingle[]> extrinsicValues;
	public final ArrayList<NumberObjectSingle> extrinsicStepsize;
	
	// Interruption related ArrayLists
	public final ArrayList<String> interruptionNames;
	public final ArrayList<Cue> interruptionCues;
	public final ArrayList<String[]> interruptionCueLabels;

	// Delay related ArrayLists
	public final ArrayList<String> delayNames;
	public final ArrayList<Integer[]> delayValues;
	public final ArrayList<Integer> delayStepsize;
	public final ArrayList<Cue> delayCues;
	public final ArrayList<String[]> delayCueLabels;



	// Patch related ArrayLists
	public final ArrayList<Patch> patches;
	public final ArrayList<String> patchNames;
	public final ArrayList<PatchState> patchStates;
	public final ArrayList<String> patchStateNames;
	public       int basePatchIndex;
	public       int baseStateIndex;

	public  	 Boolean[][] canMoveFromPatchToPatch; // can move From A to B
	public       Boolean[][] patchIsAccessibleFrom; // accessible: can move From B to A
	
	// Experience related ArrayLists
	public final ArrayList<Boolean> resourceIsObservable; // [resourceIndex]
	public final ArrayList<Boolean> resourceAtLeastOnePatchStateWhereLearnByExperience; // [resourceIndex]
	public final ArrayList<ArrayList<Boolean>> resourceLearnByExperienceInPatchState; // [resourceIndex][patchStateIndex]
	public final ArrayList<ArrayList<ArrayList<Integer>>> resourceStartingExperiences; // [resourceIndex][patchStateIndex][resource value] -> count
	
	public final ArrayList<Boolean> extrinsicIsObservable; // [extrinsicIndex]
	public final ArrayList<Boolean> extrinsicAtLeastOnePatchStateWhereLearnByExperience; // [extrinsic]
	public final ArrayList<ArrayList<Boolean>> extrinsicLearnByExperienceInPatchState; // [extrinsic][patchStateIndex]
	public final ArrayList<ArrayList<ArrayList<Integer>>> extrinsicStartingExperiences; // [resourceIndex][patchStateIndex][resource value] -> count
	
	public final ArrayList<Boolean> interruptionIsObservable; // [interruptionIndex]
	public final ArrayList<Boolean> interruptionAtLeastOnePatchStateWhereLearnByExperience; // [interruption]
	public final ArrayList<ArrayList<Boolean>> interruptionLearnByExperienceInPatchState; // [interruption][patchStateIndex]
	public final ArrayList<ArrayList<ArrayList<Integer>>> interruptionStartingExperiences; // [resourceIndex][patchStateIndex][resource value] -> count
	
	public final ArrayList<Boolean> delayIsObservable; // [delayIndex]
	public final ArrayList<Boolean> delayAtLeastOnePatchStateWhereLearnByExperience; // [delay]
	public final ArrayList<ArrayList<Boolean>> delayLearnByExperienceInPatchState; // [delay][patchStateIndex]
	public final ArrayList<ArrayList<ArrayList<Integer>>> delayStartingExperiences; // [resourceIndex][patchStateIndex][resource value] -> count
	
	// Action related ArrayLists
	public ArrayList<T1Action> t1Actions; // between encounters
	public ArrayList<String> t1ActionNames; // between encounters
	public ArrayList<T2Action> t2Actions; // during encounters
	public ArrayList<String> t2ActionNames; // during encounters

	// Mutation & Death related arrays
	public final ArrayList<Mutation> mutations;
	public final ArrayList<DeathCondition> deathConditions;
	public ObjectMutator objectMutator; // The class that deals with all mutations in resources, delays, and interruptions. Does not deal with ageing, phenotype changes, or patch state changes - that's what the stateMutator will do, which the Ledger creates.
	
	// Fields we use for writing the results to disk
	public final ArrayList<RFunctionContainer> resourceFunctionContainers;
	public final ArrayList<RFunctionContainer> delayFunctionContainers;
	public final ArrayList<RFunctionContainer> interruptionFunctionContainers;
	public final ArrayList<RFunctionContainer> extrinsicFunctionContainers;
	
	public LedgerFactory(Model model) {
		phenotypeNames = new ArrayList<>();
		phenotypeValues = new ArrayList<>();
		phenotypeStepsize = new ArrayList<>();
		
		// Resource related ArrayLists
		resourceNames = new ArrayList<>();
		resourceValues= new ArrayList<>();
		resourceStepsize = new ArrayList<>();
		resourceCues= new ArrayList<>();
		resourceCueLabels= new ArrayList<>();

		// Extrinsic related ArrayLists
		extrinsicNames= new ArrayList<>();
		extrinsicValues= new ArrayList<>();
		extrinsicStepsize = new ArrayList<>();

		// Interruption related ArrayLists
		interruptionNames= new ArrayList<>();
		interruptionCues= new ArrayList<>();
		interruptionCueLabels= new ArrayList<>();

		// Delay related ArrayLists
		delayNames= new ArrayList<>();
		delayValues = new ArrayList<>();
		delayStepsize = new ArrayList<>();
		delayCues= new ArrayList<>();
		delayCueLabels= new ArrayList<>();

		// Patch related ArrayLists
		patches= new ArrayList<>();
		patchNames= new ArrayList<>();
		patchStates= new ArrayList<>();
		patchStateNames= new ArrayList<>();
		this.basePatchIndex = -1;
		this.baseStateIndex = -1;

		// Action related ArrayLists
		t1Actions= new ArrayList<>();
		t1ActionNames= new ArrayList<>();
		t2Actions= new ArrayList<>();
		t2ActionNames= new ArrayList<>();
		
		// Mutation & Death related ArrayLists
		mutations = new ArrayList<>();
		deathConditions = new ArrayList<>();
		
		// Experience related ArrayLists
		resourceIsObservable = new ArrayList<>();
		resourceAtLeastOnePatchStateWhereLearnByExperience = new ArrayList<>();
		resourceLearnByExperienceInPatchState= new ArrayList<>();
		resourceStartingExperiences = new ArrayList<>();
		
		extrinsicIsObservable = new ArrayList<>();
		extrinsicAtLeastOnePatchStateWhereLearnByExperience= new ArrayList<>();
		extrinsicLearnByExperienceInPatchState= new ArrayList<>();
		extrinsicStartingExperiences = new ArrayList<>();
		
		interruptionIsObservable = new ArrayList<>();
		interruptionAtLeastOnePatchStateWhereLearnByExperience= new ArrayList<>();
		interruptionLearnByExperienceInPatchState= new ArrayList<>();
		interruptionStartingExperiences = new ArrayList<>();
		
		delayIsObservable = new ArrayList<>();
		delayAtLeastOnePatchStateWhereLearnByExperience= new ArrayList<>();
		delayLearnByExperienceInPatchState= new ArrayList<>();
		delayStartingExperiences = new ArrayList<>();
		
		resourceFunctionContainers = new ArrayList<>();
		delayFunctionContainers = new ArrayList<>();
		interruptionFunctionContainers = new ArrayList<>();
		extrinsicFunctionContainers = new ArrayList<>();
		

	}
	
	/** <pre> Returns the index position of the named non-age phenotype. During runtime, we do not 
	 * use the name of a phenotype. Rather, we use integer values that represents each 
	 * phenotype. An agent's phenotype is represented with an n dimensional array,
	 * where n is the number of non-age phenotypic dimensions in this model. This array 
	 * contains integer values, which represent the 'integerized' values of these dimensions. 
	 * 
	 * An example might be useful. Suppose that in our model there are two non-age 
	 * phenotypic dimensions, 'health' and 'number of children'. The 'health' dimension 
	 * has values that are multiples of 0.5, running from -1 to 5. The 'number of 
	 * children' dimension has integer values, from 0 to 7. In this model we represent 
	 * an agent's phenotypic state with two integer values, corresponding to 'health' 
	 * and 'number of children', respectively. For instance, an agent might have a 
	 * phenotype of [2,5]. This means that an agent's health is the second value in 
	 * the range of possible health values. In this case a health of index 0=-1; 
	 * index 1=-0.5; index 2=0, so a health of 0. Similarly, its number of children 
	 * is the 5th possible value of all possible number of children. In this case 
	 * index 0=0 children; index 1=1 child; ..., index 5 = 5 children.
	 * 
	 * Using this manner of storing values speeds ups performance, and increases
	 * accuracy (always nice if we can eat our cake and have it too). However, 
	 * it does mean we need to figure out which phenotype is at which index position. 
	 * That's what this function does: given a name, it returns the index position in 
	 * the n dimensional array of integers.
	 * 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfPhenotype(String phenotypeName){
		for (int i = 0; i < phenotypeNames.size(); i++)
			if (phenotypeNames.get(i).equals(phenotypeName))
				return i;
		throw new IllegalArgumentException("Phenotype of name \"" + phenotypeName + "\" is not yet registered in this ledger.");
	}
	
	/** <pre> Returns the index position of the named resource type. During runtime, we do not 
	 * use the name of a resource type. Rather, we use integer values that represents each 
	 * resource type. 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfResourceType(String resourceName){
		for (int i = 0; i < resourceNames.size(); i++)
			if (resourceNames.get(i).equals(resourceName))
				return i;
		throw new IllegalArgumentException("Resource type \"" + resourceName + "\" is not yet registered in this ledger.");
	}
	

	/** <pre> Returns the index position of the named delay type. During runtime, we do not 
	 * use the name of a delay type. Rather, we use integer values that represents each 
	 * delay type. 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfDelayType(String delayName){
		for (int i = 0; i < delayNames.size(); i++)
			if (delayNames.get(i).equals(delayName))
				return i;
		throw new IllegalArgumentException("Delay type \"" + delayName + "\" is not yet registered in this ledger.");
	}

	/** <pre> Returns the index position of the named interruption type. During runtime, we do not 
	 * use the name of a interruption type. Rather, we use integer values that represents each 
	 * interruption type. 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfInterruptionType(String interruptionName){
		for (int i = 0; i < interruptionNames.size(); i++)
			if (interruptionNames.get(i).equals(interruptionName))
				return i;
		throw new IllegalArgumentException("Interruption type \"" + interruptionName + "\" is not yet registered in this ledger.");
	}
	
	/** <pre> Returns the index position of the named extrinsic event type. During runtime, we do not 
	 * use the name of a extrinsic event type. Rather, we use integer values that represents each 
	 * extrinsic event type. 
	 * Throws an illegalArgumentException if the name is not registered in the Ledger.*/
	public int getIndexOfExtrinsicType(String extrinsicName){
		for (int i = 0; i < extrinsicNames.size(); i++)
			if (extrinsicNames.get(i).equals(extrinsicName))
				return i;
		throw new IllegalArgumentException("Extrinsic event type \"" + extrinsicName + "\" is not yet registered in this ledger.");
	}
	

	public String toString() {
		StringBuilder sb = new StringBuilder("A Ledger factory, with the following fields:");

		sb.append("\n\n\n\n\n----------------------------------------------");
		sb.append("\n------------------ Objects -------------------");
		sb.append("\n----------------------------------------------");

		sb.append("\n\n---------- Non-age phenotypes ----------");
		sb.append("\nNames:   \n\t" + Helper.arrayListToString(phenotypeNames));
		sb.append("\nValues:");
		if (phenotypeValues.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < phenotypeValues.size(); i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayToString(phenotypeValues.get(i)));
		sb.append("\nStep size:");
		for (int i = 0; i < phenotypeStepsize.size(); i ++)
			sb.append("\n\t[" + i + "]: " + phenotypeStepsize.get(i).toStringWithoutTrailingZeros());



		sb.append("\n\n\n\n---------- Resources ----------");
		sb.append("\nNames:  \n\t" + Helper.arrayListToString(resourceNames));

		sb.append("\nValues:");
		if (resourceValues.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceValues.size(); i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayToString(resourceValues.get(i)));

		sb.append("\nStep size:");
		for (int i = 0; i < resourceStepsize.size(); i ++)
			sb.append("\n\t[" + i + "]: " + resourceStepsize.get(i).toStringWithoutTrailingZeros());

		
		sb.append("\nResource cue labels:");
		if (resourceValues.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceValues.size(); i ++)
			if (resourceCueLabels.get(i) != null)
				sb.append("\n\t[" + i + "]: " + Helper.arrayToString(resourceCueLabels.get(i)));
			else 
				sb.append("\n\t[" + i + "]: null" );

		sb.append("\nResource cues:");
		for (int i = 0; i < resourceNames.size(); i++)
			sb.append("\n\t[" + i + "]: " + resourceCues.get(i));



		sb.append("\n\n\n\n---------- Interruptions ----------");
		sb.append("\nNames:  \n\t" + Helper.arrayListToString(interruptionNames));

		sb.append("\nInterruption cue labels:");
		if (interruptionNames.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < interruptionNames.size(); i ++)
			if (interruptionCueLabels.get(i) != null)
				sb.append("\n\t[" + i + "]: " + Helper.arrayToString(interruptionCueLabels.get(i)));
			else 
				sb.append("\n\t[" + i + "]: null" );

		sb.append("\nInterruption cues:");
		for (int i = 0; i < interruptionNames.size(); i++)
			sb.append("\n\t[" + i + "]: " + interruptionCues.get(i));




		sb.append("\n\n\n\n---------- Delays ----------");
		sb.append("\nNames:  \n\t" + Helper.arrayListToString(delayNames));
		
		sb.append("\nValues:");
		if (delayValues.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < delayValues.size(); i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayToString(delayValues.get(i)));

		sb.append("\nStep size:");
		for (int i = 0; i < delayStepsize.size(); i ++)
			sb.append("\n\t[" + i + "]: " + delayStepsize.get(i));

		sb.append("\nDelay cue labels:");
		if (delayNames.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < delayNames.size(); i ++)
			if (delayCueLabels.get(i) != null)
				sb.append("\n\t[" + i + "]: " + Helper.arrayToString(delayCueLabels.get(i)));
			else 
				sb.append("\n\t[" + i + "]: null" );

		sb.append("\nDelay cues:");
		for (int i = 0; i < delayNames.size(); i++)
			sb.append("\n\t[" + i + "]: " + delayCues.get(i));



		sb.append("\n\n\n\n---------- Extrinsic events----------");
		sb.append("\nNames:   \n\t" + Helper.arrayListToString(extrinsicNames));
		sb.append("\nValues:");
		if (extrinsicValues.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < extrinsicValues.size(); i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayToString(extrinsicValues.get(i)));

		sb.append("\nStep size:");
		for (int i = 0; i < extrinsicStepsize.size(); i ++)
			sb.append("\n\t[" + i + "]: " + extrinsicStepsize.get(i).toStringWithoutTrailingZeros());


		sb.append("\n\n\n\n\n\n\n----------------------------------------------");
		sb.append("\n---------- Patches and patch states ----------");
		sb.append("\n----------------------------------------------");
		sb.append("\nThis model contains " + patches.size() + " patch(es):");
		for (int i = 0; i < patchNames.size(); i++)
			sb.append("\n\t[" + i + "]: " + patchNames.get(i));

		sb.append("\n\nTraversability matrix: is it possible to go from [row] to [column]?\n" + Helper.matrix2DToString(this.canMoveFromPatchToPatch));
		sb.append("\n\nAccessibility matrix:  can you reach [row] from [column] (inverse of above)?\n" + Helper.matrix2DToString(this.patchIsAccessibleFrom));
		
		sb.append("\nCombined over these patches, there are " + patchStates.size() + " state(s):");
		for (int i = 0; i < patchStateNames.size(); i++)
			sb.append("\n\t[" + i + "]: " + patchStateNames.get(i) + "  (in patch [" + patchStates.get(i).ledgerIndexOfPatch + "])");

		sb.append("\n\nPatches and patch states have the following order and offsets:");
		for (int i = 0; i < patches.size(); i++)
			sb.append("\n\n\n" + patches.get(i).toString(this));

		
		
		sb.append("\n\n\n\n\n\n\n----------------------------------------------");
		sb.append("\n--------- Experiences and beliefs -----------");
		sb.append("\n----------------------------------------------");
		sb.append("\n---------- Resources ----------");
		sb.append("\nDirectly observable?");
		if (resourceIsObservable.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceIsObservable.size(); i ++)
			sb.append("\n\t[" + i + "]: " + resourceIsObservable.get(i));
		
		sb.append("\nAt least one patch state where agent learns by experience?");
		if (resourceAtLeastOnePatchStateWhereLearnByExperience.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceAtLeastOnePatchStateWhereLearnByExperience.size(); i ++)
			sb.append("\n\t[" + i + "]: " + resourceAtLeastOnePatchStateWhereLearnByExperience.get(i));
		
		sb.append("\nWhich patch state where agent learns by experience?");
		if (resourceAtLeastOnePatchStateWhereLearnByExperience.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceAtLeastOnePatchStateWhereLearnByExperience.size(); i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayListToString(resourceLearnByExperienceInPatchState.get(i)));
		
		sb.append("\nPrior experience at start?");
		if (resourceStartingExperiences.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < resourceStartingExperiences.size(); i ++) {
			sb.append("\n\tResource [" + i + "] with name '" + resourceNames.get(i) +"': " );
			for (int j = 0; j < resourceStartingExperiences.get(i).size(); j++)
				if (resourceStartingExperiences.get(i).get(j) == null)
					sb.append("\n\t\tPatchState [" + j +"]:  null");
				else
					sb.append("\n\t\tPatchState [" + j +"]:  " + Helper.arrayListToString(resourceStartingExperiences.get(i).get(j)));
		}
		
		
		
		
		sb.append("\n\n---------- Delays ----------");
		sb.append("\nDirectly observable?");
		if (delayIsObservable.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < delayIsObservable.size(); i ++)
			sb.append("\n\t[" + i + "]: " + delayIsObservable.get(i));
		
		sb.append("\nAt least one patch state where agent learns by experience?");
		if (delayAtLeastOnePatchStateWhereLearnByExperience.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < delayAtLeastOnePatchStateWhereLearnByExperience.size(); i ++)
			sb.append("\n\t[" + i + "]: " + delayAtLeastOnePatchStateWhereLearnByExperience.get(i));
		
		sb.append("\nWhich patch state where agent learns by experience?");
		if (delayAtLeastOnePatchStateWhereLearnByExperience.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < delayAtLeastOnePatchStateWhereLearnByExperience.size(); i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayListToString(delayLearnByExperienceInPatchState.get(i)));
		
		sb.append("\nPrior experience at start?");
		if (delayStartingExperiences.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < delayStartingExperiences.size(); i ++) {
			sb.append("\n\tDelay [" + i + "] with name '" + delayNames.get(i) +"': " );
			for (int j = 0; j < delayStartingExperiences.get(i).size(); j++)
				if (delayStartingExperiences.get(i).get(j) == null)
					sb.append("\n\t\tPatchState [" + j +"]:  null");
				else
					sb.append("\n\t\tPatchState [" + j +"]:  " + Helper.arrayListToString(delayStartingExperiences.get(i).get(j)));
		}
		
		
		sb.append("\n\n---------- Interruptions ----------");
		sb.append("\nDirectly observable?");
		if (interruptionIsObservable.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < interruptionIsObservable.size(); i ++)
			sb.append("\n\t[" + i + "]: " + interruptionIsObservable.get(i));
		
		sb.append("\nAt least one patch state where agent learns by experience?");
		if (interruptionAtLeastOnePatchStateWhereLearnByExperience.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < interruptionAtLeastOnePatchStateWhereLearnByExperience.size(); i ++)
			sb.append("\n\t[" + i + "]: " + interruptionAtLeastOnePatchStateWhereLearnByExperience.get(i));
		
		sb.append("\nWhich patch state where agent learns by experience?");
		if (interruptionAtLeastOnePatchStateWhereLearnByExperience.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < interruptionAtLeastOnePatchStateWhereLearnByExperience.size(); i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayListToString(interruptionLearnByExperienceInPatchState.get(i)));
		
		sb.append("\nPrior experience at start?");
		if (interruptionStartingExperiences.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < interruptionStartingExperiences.size(); i ++) {
			sb.append("\n\tInterruption [" + i + "] with name '" + interruptionNames.get(i) +"': " );
			for (int j = 0; j < interruptionStartingExperiences.get(i).size(); j++)
				if (interruptionStartingExperiences.get(i).get(j) == null)
					sb.append("\n\t\tPatchState [" + j +"]:  null");
				else
					sb.append("\n\t\tPatchState [" + j +"]:  " + Helper.arrayListToString(interruptionStartingExperiences.get(i).get(j)));
		}
		
		
		
		sb.append("\n\n---------- Extrinsic events ----------");
		sb.append("\nDirectly observable?");
		if (extrinsicIsObservable.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < extrinsicIsObservable.size(); i ++)
			sb.append("\n\t[" + i + "]: " + extrinsicIsObservable.get(i));
		
		sb.append("\nAt least one patch state where agent learns by experience?");
		if (extrinsicAtLeastOnePatchStateWhereLearnByExperience.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < extrinsicAtLeastOnePatchStateWhereLearnByExperience.size(); i ++)
			sb.append("\n\t[" + i + "]: " + extrinsicAtLeastOnePatchStateWhereLearnByExperience.get(i));
		
		sb.append("\nWhich patch state where agent learns by experience?");
		if (extrinsicAtLeastOnePatchStateWhereLearnByExperience.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < extrinsicAtLeastOnePatchStateWhereLearnByExperience.size(); i ++)
			sb.append("\n\t[" + i + "]: " + Helper.arrayListToString(extrinsicLearnByExperienceInPatchState.get(i)));
		
		sb.append("\nPrior experience at start?");
		if (extrinsicStartingExperiences.size() == 0) sb.append("\n\t[]");
		for (int i = 0; i < extrinsicStartingExperiences.size(); i ++) {
			sb.append("\n\tExtrinsic [" + i + "] with name '" + extrinsicNames.get(i) +"': " );
			for (int j = 0; j < extrinsicStartingExperiences.get(i).size(); j++)
				if (extrinsicStartingExperiences.get(i).get(j) == null)
					sb.append("\n\t\tPatchState [" + j +"]:  null");
				else
					sb.append("\n\t\tPatchState [" + j +"]:  " + Helper.arrayListToString(extrinsicStartingExperiences.get(i).get(j)));
		}
		
		
		sb.append("\n\n\n\n\n\n\n----------------------------------------------");
		sb.append("\n---------- Actions and mutations ------------");
		sb.append("\n----------------------------------------------");
		sb.append("\n---------- T1 Actions (between encounters) ----------");
		for (int i = 0; i < this.t1Actions.size(); i++)
			sb.append("\n\t["+i+"] \t'" + this.t1ActionNames.get(i) +"': \t"+ t1Actions.get(i));
			
		sb.append("\n\n---------- T2 Actions (durng encounters) ----------");
		for (int i = 0; i < this.t2Actions.size(); i++)
			sb.append("\n\t["+i+"] \t'" + this.t2ActionNames.get(i) +"': \t"+ t2Actions.get(i));;
		
		sb.append("\n\n---------- Phenotype Mutations ----------");
		for (int i = 0; i < this.mutations.size(); i++)
			sb.append("\n\t["+i+"] \t" + this.mutations.get(i));
		
		sb.append("\n\n---------- Object Mutator  ----------");
		sb.append(this.objectMutator);
		
		sb.append("\n\n---------- Death conditions ----------");
		for (int i = 0; i < this.deathConditions.size(); i++)
			sb.append("\n\t["+i+"] \t" + this.deathConditions.get(i));
		
		
		sb.append("\n\n\n\n\n\n\n----------------------------------------------");
		sb.append("\n------------ Prior experiences --------------");
		sb.append("\n----------------------------------------------");
		sb.append("\n---------- Resources ----------");
		for (int r = 0; r < this.resourceNames.size(); r++) {
			sb.append("\nResource ["+r+"] '" + resourceNames.get(r) + "':");
			sb.append("'\n\tObservable?               " + resourceIsObservable.get(r));
			sb.append("\n\t>1 patch from experience? " + resourceAtLeastOnePatchStateWhereLearnByExperience.get(r));
			if (resourceAtLeastOnePatchStateWhereLearnByExperience.get(r)) {
				sb.append("\n\tHas prior experiences in patch:");
				for (int p = 0; p < this.patchStates.size();p++) {
					sb.append("\n\t\t[" + p + "]: " + resourceLearnByExperienceInPatchState.get(r).get(p));
					if (resourceLearnByExperienceInPatchState.get(r).get(p)) {
						sb.append(", namely: " );
						for (int v = 0; v < resourceStartingExperiences.get(r).get(p).size(); v++)
							sb.append("\n\t\t\t["+v+"] -> "+resourceStartingExperiences.get(r).get(p).get(v));
					}
				}
			}
		}
		
		sb.append("\n\n---------- Interruptions ----------");
		for (int i = 0; i < this.interruptionNames.size(); i++) {
			sb.append("\nInterruption ["+i+"] '" + interruptionNames.get(i) + "':");
			sb.append("'\n\tObservable?               " + interruptionIsObservable.get(i));
			sb.append("\n\t>1 patch from experience? " + interruptionAtLeastOnePatchStateWhereLearnByExperience.get(i));
			if (interruptionAtLeastOnePatchStateWhereLearnByExperience.get(i)) {
				sb.append("\n\tHas prior experiences in patch:");
				for (int p = 0; p < this.patchStates.size();p++) {
					sb.append("\n\t\t[" + p + "]: " + interruptionLearnByExperienceInPatchState.get(i).get(p));
					if (interruptionLearnByExperienceInPatchState.get(i).get(p)) {
						sb.append(", namely: " );
						for (int v = 0; v < interruptionStartingExperiences.get(i).get(p).size(); v++)
							sb.append("\n\t\t\t["+v+"] -> "+interruptionStartingExperiences.get(i).get(p).get(v));
					}
				}
			}
		}
		
		sb.append("\n\n---------- Delays ----------");
		for (int i = 0; i < this.delayNames.size(); i++) {
			sb.append("\nDelay ["+i+"] '" + delayNames.get(i) + "':");
			sb.append("'\n\tObservable?               " + delayIsObservable.get(i));
			sb.append("\n\t>1 patch from experience? " + delayAtLeastOnePatchStateWhereLearnByExperience.get(i));
			if (delayAtLeastOnePatchStateWhereLearnByExperience.get(i)) {
				sb.append("\n\tHas prior experiences in patch:");
				for (int p = 0; p < this.patchStates.size();p++) {
					sb.append("\n\t\t[" + p + "]: " + delayLearnByExperienceInPatchState.get(i).get(p));
					if (delayLearnByExperienceInPatchState.get(i).get(p)) {
						sb.append(", namely: " );
						for (int v = 0; v < delayStartingExperiences.get(i).get(p).size(); v++)
							sb.append("\n\t\t\t["+v+"] -> "+delayStartingExperiences.get(i).get(p).get(v));
					}
				}
			}
		}
		
		sb.append("\n\n---------- Extrinsic ----------");
		for (int i = 0; i < this.extrinsicNames.size(); i++) {
			sb.append("\nExtrinsic ["+i+"] '" + extrinsicNames.get(i) + "':");
			sb.append("'\n\tObservable?               " + extrinsicIsObservable.get(i));
			sb.append("\n\t>1 patch from experience? " + extrinsicAtLeastOnePatchStateWhereLearnByExperience.get(i));
			if (extrinsicAtLeastOnePatchStateWhereLearnByExperience.get(i)) {
				sb.append("\n\tHas prior experiences in patch:");
				for (int p = 0; p < this.patchStates.size();p++) {
					sb.append("\n\t\t[" + p + "]: " + extrinsicLearnByExperienceInPatchState.get(i).get(p));
					if (extrinsicLearnByExperienceInPatchState.get(i).get(p)) {
						sb.append(", namely: " );
						for (int v = 0; v < extrinsicStartingExperiences.get(i).get(p).size(); v++)
							sb.append("\n\t\t\t["+v+"] -> "+extrinsicStartingExperiences.get(i).get(p).get(v));
					}
				}
			}
		}
		
		return sb.toString();
	}

}
