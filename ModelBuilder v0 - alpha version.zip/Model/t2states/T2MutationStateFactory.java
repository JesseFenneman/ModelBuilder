package t2states;

import helper.Helper;
import model.Model;
import t1states.T1ActionStateFactory;

public class T2MutationStateFactory extends T2AbstractStateFactory{

	/** Create a StateFactory with the same fields as the State*/
	public T2MutationStateFactory(T2AbstractState s) {
		super(s);
	}
	
	/** Clone all fields in the existing T2StateFactory to create a new T2StateFactory. 
	 * Fields can be copied by reference (deepClone == false) or by value (deepClone == true)*/
	public T2MutationStateFactory(T2AbstractStateFactory f, boolean deepClone) {
		super(f, deepClone);
	}
	
	/** Clone all fields in the existing T1StateFactory to create a new T2MutationStateFactory. 
	 * All T1 state values are deep cloned from the T1ActionStateFactory.
	 * The new MutationStateFactory has 0 cues sampled for all possible cue values,
	 * All values for the T2 state variables are set to either 0 or false. The index for the
	 * encountered delays, resources, and interruptions are set to -1. */
	public T2MutationStateFactory(Model model, T1ActionStateFactory f) {
		// Create a T2MutationStateFactory with all fields null
		super(model);

		this.age = f.age;
		this.locationPatch = f.locationPatch;
		this.locationPatchState = f.locationPatchState;
		
		
		// Deepclone all T1 arrays
		if (f.lastVisitToPatch==null)
			lastVisitToPatch = null;
		else {
			lastVisitToPatch = new int[f.lastVisitToPatch.length];
			System.arraycopy(f.lastVisitToPatch, 0, lastVisitToPatch, 0, f.lastVisitToPatch.length);
		}
		if (f.patchStateOfLastVisit == null)
			patchStateOfLastVisit = null;
		else{
			patchStateOfLastVisit = new int[f.patchStateOfLastVisit.length];
			System.arraycopy(f.patchStateOfLastVisit, 0, patchStateOfLastVisit, 0, f.patchStateOfLastVisit.length);
		}

		if (f.phenotype == null)
			phenotype = null;
		else {
			phenotype = new int[f.phenotype.length];
			System.arraycopy(f.phenotype, 0, phenotype, 0, f.phenotype.length);
		}
		
		// Set all T2 State variables
		timeInEncounter = 0;
		consumedResourceType = new boolean[model.ledger.numberOfResourceTypes];
		for (int r = 0; r < consumedResourceType.length; r++) 
			consumedResourceType[r] = false;
			
		// Set all possible cues that an agent can sample to 0
		resourceCues = new int[model.ledger.numberOfResourceTypes][]; 	
		for (int r = 0; r< resourceCues.length; r++) {
			if (model.ledger.resourceCues[r] != null) {
				resourceCues[r] = new int[model.ledger.resourceCueLabels[r].length];
				for (int cl = 0; cl < resourceCues[r].length; cl++)
					resourceCues[r][cl] = 0;
			}
		}
		delayCues = new int[model.ledger.numberOfDelayTypes][];
		for (int d = 0; d < delayCues.length; d++) {
			if (model.ledger.delayCues[d] != null) {
				delayCues[d] = new int[model.ledger.delayCueLabels[d].length];
				for (int cl = 0; cl < delayCues[d].length; cl++)
					delayCues[d][cl] = 0;
			}
		}
		interruptionCues = new int[model.ledger.numberOfInterruptionTypes][];
		for (int i = 0; i < interruptionCues.length; i++) {
			if (model.ledger.interruptionCues[i] != null) {
				interruptionCues[i] = new int[model.ledger.interruptionCueLabels[i].length];
				for (int cl = 0; cl < interruptionCues[i].length; cl++)
					interruptionCues[i][cl] = 0;
			}
		}
		
		// T2 invariants
		patchStateWhenStartingEncounter = this.locationPatchState;
		this.encounteredResourceType = new boolean[model.ledger.numberOfResourceTypes];
		valueIndexOfEncounteredObservableResources = new int[model.ledger.numberOfResourceTypes];
		for (int r = 0; r < encounteredResourceType.length; r++) {
			encounteredResourceType[r] = false;
			valueIndexOfEncounteredObservableResources[r] = -1;
		}
		
		durationIndexOfEncounteredObservableDelays = new int[model.ledger.numberOfDelayTypes];
		for (int d = 0; d < durationIndexOfEncounteredObservableDelays.length; d++) durationIndexOfEncounteredObservableDelays[d]=-1;
		
		willEncounteredObservableInterruptions = new boolean[model.ledger.numberOfInterruptionTypes];
		for (int i = 0; i < willEncounteredObservableInterruptions.length; i++)
			willEncounteredObservableInterruptions[i]=false;
		

	}


	/** Create a MutationState based on this Factory. */
	protected T2MutationState buildT2MutationState(T2DecisionTree tree) {
		return new T2MutationState(this, tree);
	}

	/** Stop the encounter: create a T1MutationStateFactory that represent the state that
	 * an agent will end up with if it stops the encounter in the state represented by the
	 * present factory. Note: this using shallow cloning*/
	public T1ActionStateFactory toT1ActionStateFactory() {
		return new T1ActionStateFactory(this, false);
	}
	
	/** Check if the factory is set up in a way that the resulting T2MutationState can be used as the 
	 * root node (starting state) of a T2DecisionTree. This function does NOT return true or false,
	 * but rather, throws a specific Exception to indicate why it cannot be used as a starting state.*/
	public void checkIfValidStartingState () {	
		// First, check if this is indeed a valid starting state.
		if (this.age < 0 || age>  model.maximumAge)
			throw new IllegalStateException("Trying to create a T2 starting state that has an invalid age " + age);
		
		if (this.timeInEncounter != 0)
			throw new IllegalStateException("Trying to create a T2 starting state that has already spend some time in an encounter. Time spend: " + timeInEncounter);
		
		for (int i = 0; i < this.resourceCues.length; i ++)
			if (resourceCues[i] != null)
				for (int c = 0; c < resourceCues[i].length; c++)
					if (resourceCues[i][c] != 0)
						throw new IllegalStateException("Trying to create a T2 starting state that has some observed resource cues. Specifically, for resource [" + i + "] and cue label [" +c+"] it observed "+ resourceCues[i][c]+" cues");
		
		for (int i = 0; i < this.delayCues.length; i ++)
			if (delayCues[i] != null)
				for (int c = 0; c < delayCues[i].length; c++)
					if (delayCues[i][c] != 0)
						throw new IllegalStateException("Trying to create a T2 starting state that has some observed delay cues. Specifically, for delay [" + i + "] and cue label [" +c+"] it observed "+ delayCues[i][c]+" cues");
	
		for (int i = 0; i < this.interruptionCues.length; i ++)
			if (interruptionCues[i] != null)
				for (int c = 0; c < interruptionCues[i].length; c++)
					if (interruptionCues[i][c] != 0)
						throw new IllegalStateException("Trying to create a T2 starting state that has some observed interruption cues. Specifically, for interruption [" + i + "] and cue label [" +c+"] it observed "+ interruptionCues[i][c]+" cues");
	
		boolean atLeastOneResourceEncountered = false;
		for (boolean b: this.encounteredResourceType)
			if (b) atLeastOneResourceEncountered = true;
		if (!atLeastOneResourceEncountered)
			throw new IllegalStateException("Trying to create a T2 starting state that has not encountered any resources");
		
		boolean atLeastOneResourceConsumed = false;
		for (boolean b: this.consumedResourceType)
			if (b) atLeastOneResourceConsumed = true;
		if (atLeastOneResourceConsumed)
			throw new IllegalStateException("Trying to create a T2 starting state that has already consumed a resource");
		
		if (this.resultsInDeadState())
			throw new IllegalStateException("Trying to create a T2 starting state that is dead at the start. Phenotype: " + Helper.arrayToString(this.phenotype));
		
		if (patchStateWhenStartingEncounter != this.locationPatchState)
			throw new IllegalStateException("Trying to create a T2 starting state that is not at the starting location. Current state: " + this.locationPatchState + ". Reported starting state: " + patchStateWhenStartingEncounter);
		
		for (int v = 0; v < valueIndexOfEncounteredObservableResources.length; v ++)
			if (this.encounteredResourceType[v] && model.ledger.resourceIsObservable[v])
				if (this.valueIndexOfEncounteredObservableResources[v] == -1 || this.valueIndexOfEncounteredObservableResources[v] >= model.ledger.resourceValues[v].length)
					throw new IllegalStateException("Trying to create a T2 starting state for an observed resource. However, the resource value is not possible. Resource [" + v + "] has value ["+this.valueIndexOfEncounteredObservableResources[v] +"]"  );
				
		
		for (int d = 0; d < durationIndexOfEncounteredObservableDelays.length; d ++)
			if (model.ledger.delayIsObservable[d]&& model.ledger.delayIsObservable[d])
				if (durationIndexOfEncounteredObservableDelays[d] == -1 || durationIndexOfEncounteredObservableDelays[d] >= model.ledger.delayValues[d].length)
					throw new IllegalStateException("Trying to create a T2 starting state. However, the delay duration of directly observable delay ["+d+"] value is not possible: current duration: ["+this.durationIndexOfEncounteredObservableDelays[d] +"]"  );
	}

	
	/** Create a shallow cloned ActionStateFactory with the same values as this StateFactory. */
	public T2ActionStateFactory toT2ActionStateFactory() {
		return new T2ActionStateFactory(this, false);
	}

	@Override
	public int hashCode() {
		return T2AbstractState.generateHash(this);
	}
	
	@Override
	public boolean equals(Object o) {
		return super.equals(o);
	}
	
	public String toString() {
		return super.toString("T2MutationStateFactory");
	}
}
