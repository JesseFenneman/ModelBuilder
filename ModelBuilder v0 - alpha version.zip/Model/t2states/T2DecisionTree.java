package t2states;

import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

import helper.Helper;
import model.Model;
import start.Console;
import staticManagers.ExternalFileManager.AssociatedFileExtention;
import staticManagers.ExternalFileManager.FILE_TYPE;
import t1states.T1ActionState;
import view.View.SaveT2Mode;

/** This class handles the construction and reducing of T2DecisionTrees. */
public class T2DecisionTree implements AssociatedFileExtention {
	
	private static final long serialVersionUID = Helper.programmeVersion;
	
	public final T2StateList treeStateList;
	public final T2MutationState root;
	private transient T1ActionState t1Origin;
	private transient Model model;
	public final String name;
	
	/** This number is used by the OutputFileManager as a safety check to make sure
	 * that the correct T2DecisionTree is loaded from disk.*/
	public final int randomCheckNumber;
	
	/** Initialize, but not yet build, a T2DecisionTree. The treeNumber is used for debugging purposes, and can be safely ignored (it's used
	 * to give the tree a name)*/
	public T2DecisionTree (Model model, T2MutationStateFactory startingFactory, T1ActionState origin, int treeNumber) {
		this.model = model;
		this.t1Origin = origin;
		this.treeStateList = new T2StateList(model, this);
		
		// Create the root node from the supplied factory
		// First, check if the supplied factory can indeed be used as a root node
		// This function will throws an Exception if that is not the case
		startingFactory.checkIfValidStartingState();
		this.root = treeStateList.getMutationState(startingFactory);
		
		// For debugging and saving-to-disk purposes, we'll give this tree a name
		this.name = origin.getName() + "-- Tree-"+ treeNumber;
		
		// And a random number. When writing a T2DecisionTree to disk, the OutputFileManager
		// stores this random number. After reloading a T2DecisionTree from disk, the number is
		// check to make sure that the correct tree is retrieved.
		this.randomCheckNumber = ThreadLocalRandom.current().nextInt();
	
	}
	
	/** Returns the T1ActionState that resulted in this decision tree*/
	public T1ActionState getT1Origin() {
		return this.t1Origin;
	}
	
	/** Perform a forward pass. 
	 * Starting from the first T2MutationStates at timeInCycle=0, iteratively build the T2Decision tree.
	 * 
	 * The forward pass of a T2DecisionTree continues until an agent has had n time steps in this encounter, where n is
	 * the maximum number of time steps during an encounter, or if the frontier is empty (see below). As with the
	 * T1States, each time step has two phases: an action phase (where the agent acts), followed by  a mutation phase 
	 * (where nature forces its will on the agent). There are three types of states an agent can be in during this encounter
	 * 		1) a T2 action state (i.e., a set of state variables, and an agent can immediately act), 
	 * 		2) a T2 mutation state (i.e., a set of state variables, but before an agent can act again, it first has to go 
	 * 			through the mutations), and 
	 * 		3) a T1 fitness state (a nice way of saying the agent is dead ).
	 * Note that an agent starts a T2DecisionTree in a Mutation phase - it is the mutation phase that immediately follows
	 * after successfully executing a T1 Search action.
	 * 
	 * The algorithm for growing this tree is somewhat simple. Here is the pseudo-code:
	 * 1. Expand the root: compute all T2ActionState's that result from the mutations in the T2MutationState that is the root of this tree.
	 * 2. From t: 1 to [maximumNumberOfStepsInEncounter]:
	 * 3. 		Get all T2ActionStates at time step t
	 * 4.		Expand all non-expanded action states: this creates new MutationStates at time t (and if an agent postpones, at time t+x, where x can be any number)
	 * 				(Expanding here means to compute the consequences of all actions)
	 * 5.		Get all T2MutationStates at time step t
	 * 6.		Expand all non-expanded mutation states: this creates new ActionStates at time t+1
	 * 				(Expanding here means to compute the consequences of all possible mutation)
	 * 	
	 * 
	 * */
	public void executeForwardPass(boolean printToConsole) {
		// Step 0. Some feedback to the console
		if (printToConsole)
			Console.print("\t\t\tThe root of tree " + name + " has the following properties: " + this.briefDescriptionOfRoot());
		
		// Step 1. Expanding the root.
		// The root is already in the T2StateList of this tree. Mutate this state
		root.doForwardsPass(this);
		
		// Step 2. start the loop
		for (int t = 0; t < model.maximumStepsInEncounter; t++) {
			if (printToConsole)
				Console.print("\t\t\t - (FOR) "+ Thread.currentThread().getName() + " working on tree " + name + " is starting cycle step time " + t + ". There will be " + model.maximumStepsInEncounter + " cycles maximally, although there might be less.");
					
			// Step 3. Get all action states in the tree at time t
			Set<T2ActionState> actionStates = treeStateList.getAllActionStates(t);
			
			// Step 4. Expand all unexpanded action nodes. This computes the consequences of all possible actions in each T2ActionState,
			// and also adds new T2MutationStates to the tree
			for (T2ActionState as : actionStates)
				if (!as.wentThroughForwardsPass()) {
					as.doForwardsPass(this);
				}
			
			// Step 5. Get all mutation states in the tree at time t
			Set<T2MutationState> mutationStates = treeStateList.getAllMutationStates(t);
			
			// Step 6. Expand all unexpanded mutation nodes. This computes the effect of each mutation and adds new T2ActionStates to the tree.
			for (T2MutationState ms: mutationStates) {
				if (!ms.wentThroughForwardsPass())
					ms.doForwardsPass(this);
			}
			
		}
		
		// Print information for user
		if (printToConsole)
			Console.print("\t\tTree from root " + t1Origin.getName() +" finished forward pass. This T2DecisionTree contains " + this.treeStateList.numberOfActionStates() + " action state and " + treeStateList.numberOfMutationStates() + " mutation states."  );
		
		//Console.print(treeStateList.toString());
	}

	/** Perform a backwards pass.
	 * Starting from the last T2 Mutation nodes in this tree, iteratively work backwards through
	 * T2MutationState nodes and T2ActionStateNodes, and compute the expected fitness of each node.
	 * Performs a backward pass for this T2 decision tree. This backward pass computes
	 * 
	 * After the backwards pass, each T2ActionState 'knows' what the best action (or actions, in case
	 * of ties) is for an agent to take when it is in this T2 decision tree.
	 * 
	 * The algorithm for growing this tree is somewhat simple, and mirrors the forward pass. Here is the pseudo-code:
	 * 1. From t: maximumNumberOfStepsInEncounter to 0:
	 * 2.		Get all T2MutationStates at time step t
	 * 3.		Compute the expected fitness of this state. 
	 * 			This expected fitness is the average expected fitness of all successor states,  weighted by the probability of that successor.
	 * 4. 		Get all T2ActionStates at time step t
	 * 5.		For all T2ActionStates:
	 * 6.			For all action possible in this state, compute the expected fitness of that action
	 *  				This expected fitness is the average expected fitness of all successor states,  weighted by the probability of that successor.
	 * 7. 			Set bestActions; a list of integers representing the action (or actions, in case of tie) with the highest expected fitness
	 * 8.			Set fitness: the expected fitness of the best action.
	 * 
	 * After the backwards pass, the expected fitness of ending up in this tree is equal to the expected fitness of the root node.
	 * Note: steps 6, 7, and 8 are implemented by the T2ActionState.
	 * 
	 * Note: in order for this state to work, all possible T1 states that an agent might end up in must
	 * have their expected fitness already computed. */
	public void executeBackwardsPass(boolean printToConsole) {

		// Step 1. start the loop
		for (int t =  (model.maximumStepsInEncounter-1); t>= 0; t--) {
			if (printToConsole)
				Console.print("\t\t\t - (BACK) "+ Thread.currentThread().getName() + " working on tree " + name + " is starting cycle step time " + t + "...");

			// Step 2. Get all mutation states in the tree at time t
			Set<T2MutationState> mutationStates = treeStateList.getAllMutationStates(t);

			// Step 3.
			for (T2MutationState ms: mutationStates) {
				if (!ms.wentThroughBackwardsPass())
					ms.doBackwardsPass(printToConsole);
			}
			
			// Step 4. Get all action states in the tree at time t
			Set<T2ActionState> actionStates = treeStateList.getAllActionStates(t);

			// Step 5 (and 6, 7, and 8). 
			// and also adds new T2MutationStates to the tree
			for (T2ActionState as : actionStates)
				if (!as.wentThroughBackwardsPass()) 
					as.doBackwardsPass(printToConsole);
		}

		// Print information for user
		if (printToConsole)
			Console.print("\t\tTree" + this.name+" finished backwards pass."  );
		
		// And, if required, save the T2DecisionTree results to disk
		if (model.saveT2OutputMode == SaveT2Mode.ALL || ( model.saveT2OutputMode == SaveT2Mode.T0_ONLY && this.root.getAge() == 0))
			model.outputFileManager.writeResults(this, ";", model.saveResultPerAge);
	}

	
	/** Provide a one sentence description of the root node of the tree (phenotype, which observable objects it encounters)*/
	public String briefDescriptionOfRoot() {
		StringBuilder sb = new StringBuilder();
		sb.append("||| Age: " + root.getAge() + " || Phenotype: " + Helper.arrayToString(root.getPhenotypeArray()));
		for (int r = 0; r < model.ledger.numberOfResourceTypes; r++)
			if (model.ledger.resourceIsObservable[r] && root.encounteredResourceType[r] && model.ledger.resourceValues[r].length>1)
				sb.append(" || " + model.ledger.resourceNames[r] + ": " + root.valueIndexOfEncounteredObservableResources[r]);
		
		for (int d = 0; d < model.ledger.numberOfDelayTypes; d++)
			if (model.ledger.delayIsObservable[d] && model.ledger.delayValues[d].length>1)
				sb.append(" || " + model.ledger.delayNames[d] + ": " + root.durationIndexOfEncounteredObservableDelays[d]);
		
		for (int i = 0; i < model.ledger.numberOfInterruptionTypes; i++)
			if (model.ledger.interruptionIsObservable[i] )
				sb.append(" || " + model.ledger.interruptionNames[i] + ": " + root.willEncounteredObservableInterruptions[i]);
		
		sb.append("|||");
		
		
		return sb.toString();
	}

	/** After storing to and reloading from disk, the transient fields in this T2DecisionTree
	 * and in all transient fields in the non-transient objects in the T2DecisionTree have to 
	 * be reset. This resetting is called reinflation.  */
	public void reinflate(Model model, T1ActionState t1Origin) {
		if (!model.saveT2TreesToFile)
			throw new IllegalStateException("Trying to reset transient fields in a T2DecisionTree, but this tree should have never been written to disk in the first place.");
		
		// Reset all transient fields in this T2DecisionTree object
		this.model = model;
		this.t1Origin = t1Origin;
		
		// Reset all transient fields in all objects contained in this T2DecisionTree
		this.treeStateList.reinflate(model);
	}
	
	@Override
	public FILE_TYPE getFileType() {
		return FILE_TYPE.T2_DECISION_TREE;
	}

}
