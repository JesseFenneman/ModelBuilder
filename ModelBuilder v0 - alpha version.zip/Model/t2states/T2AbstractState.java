package t2states;

import java.util.Arrays;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import decimalNumber.DecimalNumber;
import helper.Helper;
import model.Model;
import t1states.T1AbstractState;
import t1states.T1AbstractStateFactory;

/** A T2AbstractState is a during-encounter state. It has all the properties
 * and functionality of a T1State (hence, the inheritance), with some extras.
 * Each T2AbstractState has the following fields above a T1State:
 * -	An integer, timeInCycle, keeping track of the number of time steps spend in this encounter
 * -	An array of booleans, hasEncounteredResource, that lists for each possible resource type
 * 			whether that type is encountered
 * - 	An array of booleans, hasConsumedResource, that lists for each possible resource type 
 * 			whether that type is already consumed during this encounter.
 * - 	An array of arrays of integers, resourceCues, indicating for each resource type and
 * 			each possible cue label, how many cues of that label the agent has observed during this
 * 			encounter.
 * - 	The same as above for delays and interruptions*/
public abstract class T2AbstractState extends T1AbstractState  {
	
	private static final long serialVersionUID = Helper.programmeVersion;
	
	// State variables.
	// These variables change over the course of a decision tree, from one state to the next.
	public final int timeInEncounter;
	protected final boolean[] consumedResourceType;
	
	/** Dimensions are [resourceIndex][cueLabel]*/
	protected final int[][] resourceCues; 		
	/** Dimensions are [delayIndex][cueLabel]*/
	protected final int[][] delayCues;	 		
	/** Dimensions are [interruptionIndex][cueLabel]*/
	protected final int[][] interruptionCues; 	
	
	// Variables that are invariant in a decision tree (i.e., they are effectively constant)
	/** The state of the patch when the agent started the encounter */
	public final int patchStateWhenStartingEncounter;
	/** Which resource types did the agent encounter? */
	protected final boolean[] encounteredResourceType;
	/** What the the value of the encountered resource, given that the resource is directly observable? */
	protected final int[] valueIndexOfEncounteredObservableResources; 		
	/**  What the the value of the encountered delay, given that the delay is directly observable? */
	protected final int[] durationIndexOfEncounteredObservableDelays; 
	/** Will an interruption occur, given that the interruption is directly observable? */
	protected final boolean[] willEncounteredObservableInterruptions; 
	
	/** The decision tree to which this T2 state belongs */
	//public final T2DecisionTree	t2DecisionTree;
	
	// Fields computed after the backwards pass
	/** How often does an agent expect to take each T2Action while it stays in this tree, after this
	 * moment forward? (Note: if this state is a T2ActionState, this field does not count the action
	 * taking immediately in that state */
	private NumberObjectSingle[] expectedNumberOfFutureT2ActionsInThisTree; 
	
	
	
	/** Build a T1AbstractState based on the factory. Note, this building uses a shallow clone of all factory fields*/
 	public T2AbstractState(T2AbstractStateFactory factory, T2DecisionTree decisionTree, boolean checkValidity) {
 		super(factory, false);
 		
 		// State variables
 		this.timeInEncounter = factory.timeInEncounter;
 		this.consumedResourceType = factory.consumedResourceType;
 		this.resourceCues = factory.resourceCues;
 		this.delayCues = factory.delayCues;
 		this.interruptionCues = factory.interruptionCues;
 		
 		// Invariants
 		this.encounteredResourceType = factory.encounteredResourceType;
 		this.patchStateWhenStartingEncounter = factory.patchStateWhenStartingEncounter;
 		this.valueIndexOfEncounteredObservableResources = factory.valueIndexOfEncounteredObservableResources;
 		this.durationIndexOfEncounteredObservableDelays = factory.durationIndexOfEncounteredObservableDelays;
 		this.willEncounteredObservableInterruptions = factory.willEncounteredObservableInterruptions;
 		//this.t2DecisionTree = decisionTree;
 		
 		if (checkValidity)
 			this.checkValidity();
	}
 	
	/** Check whether all fields are valid, and throw an IllegalStateException if a field has a clearly impossible state (e.g., negative age)*/
	@Override
 	public void checkValidity() {
		super.checkValidity();
		
		// State variables
		if (this.timeInEncounter < 0)
			throw new IllegalStateException("Created a T2AbstractState with a negative time spend in an encounter. Time steps = " + timeInEncounter);
		if (this.timeInEncounter > getModel().maximumStepsInEncounter)
			throw new IllegalStateException("Created a T2AbstractState with a number of time steps in an encounter that is higher than the maximum encounter time. Time steps = " +timeInEncounter+ ". Maximum = " + getModel().maximumStepsInEncounter);
		
		if (consumedResourceType.length != getModel().ledger.numberOfResourceTypes)
			throw new IllegalStateException("Created a T2AbstractState that has consumed more or less resource types then there are resource types in the model. Consumed resources: " +Helper.arrayToString(consumedResourceType)+ ". Number of resources = " + getModel().ledger.numberOfResourceTypes);
		
		if (resourceCues.length != getModel().ledger.numberOfResourceTypes)
			throw new IllegalStateException("Created a T2AbstractState that keeps track of resource cues for more or less resource types in the model. Resource cues length: " + resourceCues.length+ ". Number of resources = " + getModel().ledger.numberOfResourceTypes);
		for (int r = 0; r < resourceCues.length; r++) {
			if (resourceCues[r] != null) {
				if (getModel().ledger.resourceIsObservable[r])
					throw new IllegalStateException("Created a T2AbstractState with that keeps track of resource cues for an observable resource type. Resource type index = " + r );
				if (resourceCues[r].length != getModel().ledger.resourceCueLabels[r].length)
					throw new IllegalStateException("Created a T2AbstractState that keeps track of an incorrect number of resource cues labels. Resource type index = " + r + ". Number of labels it keeps track of: " + resourceCues[r].length + ". Cue labels for that resource: " + getModel().ledger.resourceCueLabels[r].length);
				for (int cl = 0; cl < resourceCues[r].length; cl++)
					if (resourceCues[r][cl] < 0)
						throw new IllegalStateException("Created a T2AbstractState that has seen a negative number of cue labels. Resource type index = " + r + ". Cue label index: " + cl + ". Observations: " + resourceCues[r][cl]);
					else if (resourceCues[r][cl] > getModel().ledger.resourceCues[r].maximumNumberOfTimesAnAgentCanSampleThisCue)
						throw new IllegalStateException("Created a T2AbstractState that has more cue labels that it possibly could have. Resource type index = " + r + ". Cue label index: " + cl + ". Observations: " + resourceCues[r][cl] + ". Maximum: " + getModel().ledger.resourceCues[r].maximumNumberOfTimesAnAgentCanSampleThisCue);
			} else {
				if (getModel().ledger.resourceCues[r] != null)
					throw new IllegalStateException("Created a T2AbstractState that does not have any cues for a resource type, although the ledger does say there should be cues. Resource index = " +r);	
			}
		}
	
		if (delayCues.length != getModel().ledger.numberOfDelayTypes)
			throw new IllegalStateException("Created a T2AbstractState that keeps track of delay cues for more or less delay types in the model. Delay cues length: " + delayCues.length+ ". Number of delays = " + getModel().ledger.numberOfDelayTypes);
		for (int d = 0; d < delayCues.length; d++) {
			if (delayCues[d] != null) {
				if (getModel().ledger.delayIsObservable[d])
					throw new IllegalStateException("Created a T2AbstractState with that keeps track of delay cues for an observable delay type. Delay type index = " + d );
				if (delayCues[d].length != getModel().ledger.delayCueLabels[d].length)
					throw new IllegalStateException("Created a T2AbstractState that keeps track of an incorrect number of delay cues labels. Delay type index = " + d + ". Number of labels it keeps track of: " + delayCues[d].length + ". Cue labels for that delay: " + getModel().ledger.delayCueLabels[d].length);
				for (int cl = 0; cl < delayCues[d].length; cl++)
					if (delayCues[d][cl] < 0)
						throw new IllegalStateException("Created a T2AbstractState that has seen a negative number of cue labels. Delay type index = " + d + ". Cue label index: " + cl + ". Observations: " + delayCues[d][cl]);
					else if (delayCues[d][cl] > getModel().ledger.delayCues[d].maximumNumberOfTimesAnAgentCanSampleThisCue)
						throw new IllegalStateException("Created a T2AbstractState that has more cue labels that it possibly could have. Delay type index = " + d + ". Cue label index: " + cl + ". Observations: " + delayCues[d][cl] + ". Maximum: " + getModel().ledger.delayCues[d].maximumNumberOfTimesAnAgentCanSampleThisCue);
			} else {
				if (getModel().ledger.delayCues[d] != null)
					throw new IllegalStateException("Created a T2AbstractState that does not have any cues for a delay type, although the ledger does say there should be cues. Delay index = " +d);	
			}
		}
		
		if (interruptionCues.length != getModel().ledger.numberOfInterruptionTypes)
			throw new IllegalStateException("Created a T2AbstractState that keeps track of interruption cues for more or less interruption types in the model. Interruption cues length: " + interruptionCues.length+ ". Number of interruption types = " + getModel().ledger.numberOfInterruptionTypes);
		for (int i  = 0; i < interruptionCues.length; i++) {
			if (interruptionCues[i] != null) {
				if (getModel().ledger.interruptionIsObservable[i])
					throw new IllegalStateException("Created a T2AbstractState with that keeps track of interruption cues for an observable interruption type. Interruption type index = " + i );
				if (interruptionCues[i].length != getModel().ledger.interruptionCueLabels[i].length)
					throw new IllegalStateException("Created a T2AbstractState that keeps track of an incorrect number of interruption cues labels. Interruption type index = " + i + ". Number of labels it keeps track of: " + interruptionCues[i].length + ". Cue labels for that interruption: " + getModel().ledger.interruptionCueLabels[i].length);
				for (int cl = 0; cl < interruptionCues[i].length; cl++)
					if (interruptionCues[i][cl] < 0)
						throw new IllegalStateException("Created a T2AbstractState that has seen a negative number of cue labels. Interruption type index = " + i + ". Cue label index: " + cl + ". Observations: " + interruptionCues[i][cl]);
					else if (interruptionCues[i][cl] > getModel().ledger.interruptionCues[i].maximumNumberOfTimesAnAgentCanSampleThisCue)
						throw new IllegalStateException("Created a T2AbstractState that has more cue labels that it possibly could have. Interruption type index = " + i  + ". Cue label index: " + cl + ". Observations: " + interruptionCues[i][cl] + ". Maximum: " + getModel().ledger.interruptionCues[i].maximumNumberOfTimesAnAgentCanSampleThisCue);
			} else {
				if (getModel().ledger.interruptionCues[i] != null)
					throw new IllegalStateException("Created a T2AbstractState that does not have any cues for a interruptiontype, although the ledger does say there should be cues. Interruption index = " +i);	
			}
		}
		
		// Invariants
		if (this.patchStateWhenStartingEncounter < 0)
			throw new IllegalStateException("Created a T2AbstractState with a negative starting patch state location. Patch state = " + patchStateWhenStartingEncounter);
		if (this.patchStateWhenStartingEncounter >= getModel().ledger.patchStates.length)
			throw new IllegalStateException("Created a T2AbstractState with an impossibly high starting patch state location. Patch state = " + patchStateWhenStartingEncounter);
		
		if (encounteredResourceType.length != getModel().ledger.numberOfResourceTypes)
			throw new IllegalStateException("Created a T2AbstractState that has encountered more or less resource types then there are resource types in the model. Encountered resources: " +Helper.arrayToString(encounteredResourceType)+ ". Number of resources = " + getModel().ledger.numberOfResourceTypes);
		boolean oneTrue = false;
		for (boolean b : encounteredResourceType)
			if (b) oneTrue = true;
		if (!oneTrue)
			throw new IllegalStateException("Created a T2AbstractState that has not encountered any resource types. ");
			
		if (valueIndexOfEncounteredObservableResources.length != getModel().ledger.numberOfResourceTypes)
			throw new IllegalStateException("Created a T2AbstractState that keeps track of resource values for types that do not exist, or its does not keep track of enough of them. Resources it keeps track of = " + valueIndexOfEncounteredObservableResources.length + ". Number of resource types in ledger: " + getModel().ledger.numberOfResourceTypes);
		for (int r = 0; r < getModel().ledger.numberOfResourceTypes; r++)
			if (getModel().ledger.resourceIsObservable[r]) {
				if (valueIndexOfEncounteredObservableResources[r] < 0)
					throw new IllegalStateException("Created a T2AbstractState that does not know an unobservable resource. Resource type index = " + r + ". Observed: " + valueIndexOfEncounteredObservableResources[r]);
				if (valueIndexOfEncounteredObservableResources[r] >= getModel().ledger.resourceValues[r].length)
					throw new IllegalStateException("Created a T2AbstractState that has encountered an observable resource with an impossible value. Resource type index = " + r + ". Observed: " + valueIndexOfEncounteredObservableResources[r]+  ". Maximum: " + getModel().ledger.resourceValues[r].length);
			} else 
				if (valueIndexOfEncounteredObservableResources[r] >= 0)
					throw new IllegalStateException("Created a T2AbstractState that knows an unobservable resource. Resource type index = " + r + ". Observed: " + valueIndexOfEncounteredObservableResources[r]);
				
		if (durationIndexOfEncounteredObservableDelays.length != getModel().ledger.numberOfDelayTypes)
			throw new IllegalStateException("Created a T2AbstractState that keeps track of delay values for types that do not exist, or its does not keep track of enough of them. Delays it keeps track of = " + durationIndexOfEncounteredObservableDelays.length + ". Number of delay types in ledger: " + getModel().ledger.numberOfDelayTypes);
		for (int d = 0; d < getModel().ledger.numberOfDelayTypes; d++)
			if (getModel().ledger.delayIsObservable[d]) {
				if (durationIndexOfEncounteredObservableDelays[d] < 0)
					throw new IllegalStateException("Created a T2AbstractState that does not know an unobservable delay. Delay type index = " + d + ". Observed: " + durationIndexOfEncounteredObservableDelays[d]);
				if (durationIndexOfEncounteredObservableDelays[d] >= getModel().ledger.delayValues[d].length)
					throw new IllegalStateException("Created a T2AbstractState that has encountered an observable delay with an impossible value. Delay type index = " + d + ". Observed: " + durationIndexOfEncounteredObservableDelays[d]+  ". Maximum: " + getModel().ledger.delayValues[d].length);
			} else 
				if (durationIndexOfEncounteredObservableDelays[d] >= 0)
					throw new IllegalStateException("Created a T2AbstractState that knows an unobservable delay. Delay type index = " + d + ". Observed: " + durationIndexOfEncounteredObservableDelays[d]);
				
		if (willEncounteredObservableInterruptions.length != getModel().ledger.numberOfInterruptionTypes)
			throw new IllegalStateException("Created a T2AbstractState that keeps track of interruption type values for types that do not exist, or its does not keep track of enough of them. Interruptions it keeps track of = " + willEncounteredObservableInterruptions.length + ". Number of interruption types in ledger: " + getModel().ledger.numberOfInterruptionTypes);
		for (int i = 0; i < getModel().ledger.numberOfInterruptionTypes; i++)
			if (!getModel().ledger.interruptionIsObservable[i] && this.willEncounteredObservableInterruptions[i]) 
				throw new IllegalStateException("Created a T2AbstractState that knows it will encounter an unobservable interruption. Interruption type index = " + i);
	
		//if (this.t2DecisionTree == null)
		//	throw new IllegalStateException("Created a T2AbstractState outside of a T2DecisionTree");
		
	}
	
 	/////////////////////////////////////////////////////////////////////////////////////
 	//////////////////////// State getters (known at construction) /////////////////////
 	///////////////////////////////////////////////////////////////////////////////////
	
 	/** Returns the number of time steps an agent has been in the present encounter. */
	public int getTimeInCycle() { return this.timeInEncounter; }
	
	/** Returns true if the agent has encountered a resource of that type during the present encounter, and false otherwise.*/
	public boolean hasEncounteredResourceType(int resourceIndex) { return this.encounteredResourceType[resourceIndex]; }
	
	/** Returns true if the agent has consumed a resource of that type during the present encounter, and false otherwise.*/
	public boolean hasConsumedResourceType(int resourceIndex) { return this.consumedResourceType[resourceIndex]; }
	
	/** Returns how many cues with that cue label and for that resource the agent has observed during the current encounter. */
	public int numberOfObservedResourceCues(int resourceIndex, int cueLabelIndex) { return this.resourceCues[resourceIndex][cueLabelIndex];}
	
	/** Returns the set of cues that an agent has observed about the specified resource. The result is an array of integers of length |cl|,
	 * the total number of cue labels a cue for that resource type can have. */
	public int[] resourceCueSet(int resourceIndex) { return this.resourceCues[resourceIndex];}
	
	/** Returns the value of the delayIndex' delay the agent encountered in this tree.*/
	public int getDurationIndexOfEncounteredObservableDelays(int delayIndex) {return durationIndexOfEncounteredObservableDelays[delayIndex];}
	
	/** Returns how many cues with that cue label and for that delay the agent has observed during the current encounter. */
	public int numberOfObservedDelayCues(int delayIndex, int cueLabelIndex) { return this.delayCues[delayIndex][cueLabelIndex];}
	
	/** Returns the set of cues that an agent has observed about the specified delay type. The result is an array of integers of length |cl|,
	 * the total number of cue labels a cue for that delay type can have. */
	public int[] delayCueSet(int delayIndex) { return this.delayCues[delayIndex];}
	
	/** Returns how many cues with that cue label and for that interruption type the agent has observed during the current encounter. */
	public int numberOfObservedInterruptionCues(int interruptionIndex, int cueLabelIndex) { return this.interruptionCues[interruptionIndex][cueLabelIndex];}
	
	/** Returns the set of cues that an agent has observed about the specified interruption type. The result is an array of integers of length |cl|,
	 * the total number of cue labels a cue for that interruption type can have. */
	public int[] interruptionCueSet(int interruptionIndex) { return this.interruptionCues[interruptionIndex];}

	///////////////////////////////////////////////////////////////////////
	//////////////////////// Tree building functions /////////////////////
	/////////////////////////////////////////////////////////////////////
	/** Terminate the encounter: return either the T1ActionStateFactory (if alive) or a T1FitnessStateFactory (if dead) where an agent 
	 * 'pops back up' in the T1 (between encounter) dimension. */
	public abstract T1AbstractStateFactory toT1EquivalentFactory() ;
	 
	@Override
	public void doForwardsPass() {
		throw new IllegalArgumentException("Cannot make a T2Abstract state go through a backwards pass without a T2DecisionTree.");
	}
	
	/** Perform a backwards pass on this T2AbstractState */
	public abstract void doForwardsPass(T2DecisionTree tree) ;
	////////////////////////////////////////////////////////////////////////////////////////////
 	//////////////////////// Outcome setters (used during backwards pass) /////////////////////
 	//////////////////////////////////////////////////////////////////////////////////////////
	/** Set the expected number of future T2 Actions by cloning the input.
	 * The length of the input must match the number of T2 actions in the Ledger. This
	 * function also makes all expected action NumberObjectSingle objects immutable.
	 * Throws an IllegalStateException if there already is an expected number of future actions for that index. 
	 * Has to be set after the expected age has been set. */
	public void setExpectedNumberOfFutureT2ActionsInThisTree(NumberObjectSingle[] newExpectedTimes) {
		if (getModel().performSafetyChecks) {
			}

		if (this.expectedNumberOfFutureT2ActionsInThisTree != null)
			throw new IllegalStateException("Setting a non-null expected number of future T2 actions in this tree");
		
		this.expectedNumberOfFutureT2ActionsInThisTree = newExpectedTimes;
		for (int a = 0; a < expectedNumberOfFutureT2ActionsInThisTree.length; a++)
			expectedNumberOfFutureT2ActionsInThisTree[a].makeImmutable();
	}
	
	/** Check if the expectedAge, expectedPhenotype, expectedNumberOfFutureT1Actions, and expctedNumberOfFutureT2Actions are
	 * all valid after the backwards pass.*/
	@Override
	protected void checkIfBackwardsFieldsAreValid() {
		super.checkIfBackwardsFieldsAreValid();

		// Check if the expectedNumberOfFutureT2ActionsInThisTree has exactly one entry for each possible action
		if (expectedNumberOfFutureT2ActionsInThisTree.length != getModel().ledger.numberOfT2Actions)
			throw new IllegalArgumentException("Setting expected number of future T2 Actions in this tree for T1AbstractState. However, the number of action in the input ("
					+ expectedNumberOfFutureT2ActionsInThisTree.length + ") does not match the number of T2 actions in this tree in this tree in the ledger (" + getModel().ledger.numberOfT2Actions+ ").");

		// Check if all the values in the newExpectedTimes are permissible
		DecimalNumber sum = new DecimalNumber(0);
		for (int a = 0; a < expectedNumberOfFutureT2ActionsInThisTree.length; a++)
			if (expectedNumberOfFutureT2ActionsInThisTree[a].largerThan(getModel().maximumAge, true))
				throw new IllegalArgumentException("Setting expected number of future T1 actions above maximum age. Expected: " + expectedNumberOfFutureT2ActionsInThisTree[a].toStringWithoutTrailingZeros());
			else if (expectedNumberOfFutureT2ActionsInThisTree[a].smallerThan(0, true))
				throw new IllegalArgumentException("Setting expected number of future T1 actions below 0. Expected: " + expectedNumberOfFutureT2ActionsInThisTree[a].toStringWithoutTrailingZeros());
			else
				sum.add(expectedNumberOfFutureT2ActionsInThisTree[a], true);

		// TODO: FIX THIS!
		/*
		if (!sum.equals(this.getExpectedAge().subtract(this.age+1, false), true)) // The -1 is because the last state is always a fitness state
			throw new IllegalStateException("In the future an agent expects to take " + sum.toStringWithoutTrailingZeros() + " T2 actions in this tree. However, it only expects to live for another " +
					this.getExpectedAge().subtract(this.age+1, false).toStringWithoutTrailingZeros() + " number of time steps (current age = "
					+ this.age + ", expected age = " + this.getExpectedAge().toStringWithoutTrailingZeros() + ", and there is one final FitnessState)");
*/
		
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////
 	//////////////////////// Outcome getters (known after backwards pass) /////////////////////
 	//////////////////////////////////////////////////////////////////////////////////////////
	/** Returns a clone of the number of times an agent expects to take the specified action while still in the
	 * same decision tree (i.e., not over the rest of its life)*/
	public NumberObjectSingle getFutureTimesItPerformsT2ActionInThisTree(int action) {
		if (!this.wentThroughBackwardsPass)
			throw new IllegalStateException("Asking for expected number of future actions in this tree for a state that has not gone through the backwards pass yet. Name = " + this.getName());
		return this.expectedNumberOfFutureT2ActionsInThisTree[action].clone();
	}
	
	
	///////////////////////////////////////////////////////////////
	//////////////////////// Other functions /////////////////////
	/////////////////////////////////////////////////////////////
	/** Create a hash for the specified T2ActionState or T2MutationState. It is specified in this function so that in the future it is easy
	 * to change the hashes for states and state factories in similar ways. A hash is computed on state variables only - the variables
	 * that change from state to state within a decision tree. However, it does not uses all state variables: the time in cycle is not used, 
	 * (as we store states for each time separately). All invariants (decision tree, what resources are encountered, and patchStateWhenStartingEncounter,
	 * are all ignored).*/
	public static int generateHash( T2AbstractState o) {
		final int prime = 3;
		int result = 1;
		result = prime * result + o.age;
		result = prime * result + Arrays.hashCode(o.phenotype);
		result = prime * result + Arrays.hashCode(o.consumedResourceType);
		result = prime * result + Arrays.deepHashCode(o.delayCues);
		result = prime * result + Arrays.deepHashCode(o.interruptionCues);
		result = prime * result + Arrays.deepHashCode(o.resourceCues);
		return result;
	}
	
	/** Create a hash for the specified T2ActionStateFactory or T2MutationStateFactory. It is specified in this function so that in the future it is easy
	 * to change the hashes for states and state factories in similar ways.  A hash is computed on state variables only - the variables
	 * that change from state to state within a decision tree. However, it does not uses all state variables: the time in cycle is not used, 
	 * (as we store states for each time separately). All invariants (decision tree, what resources are encountered, and patchStateWhenStartingEncounter,
	 * are all ignored). */
	public static int generateHash( T2AbstractStateFactory o) {
		final int prime = 3;
		int result = 1;
		result = prime * result + o.age;
		result = prime * result + Arrays.hashCode(o.phenotype);
		result = prime * result + Arrays.hashCode(o.consumedResourceType);
		result = prime * result + Arrays.deepHashCode(o.delayCues);
		result = prime * result + Arrays.deepHashCode(o.interruptionCues);
		result = prime * result + Arrays.deepHashCode(o.resourceCues);
		return result;
	}
	
	@Override
	public int hashCode() {
		return T2AbstractState.generateHash(this);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) 
			return true;
		
		if (obj == null) 
			return false;
		
		if (obj instanceof T2AbstractState) 
			return this.equals((T2AbstractState) obj);
		
		if (obj instanceof T2AbstractStateFactory)
			return this.equals((T2AbstractStateFactory) obj);
		
		return false;
	}

	/** Returns true if the factory's output (i.e., the state resulting from
	 * the build() function) will match the current state. NOTE: there is no
	 * check for whether this is an ActionStateFactory or a MutationStateFactory!
	 * It is possible for an ActionStateFactory to match a MutationStateFactory.
	 * 
	 * An state(factory) is the same as a state if all state variables are equal -
	 * the invariant variables that remain constant throughout the decision tree are ignored.
	 * The state variables are an agent's 
	 * 		- Age
	 * 		- Phenotypic dimensions
	 * 		- Time spend in this encounter
	 * 		- Sampled cues (resource, delays, interruptions)
	 * 		- Consumed resource*/
	public boolean equals (T2AbstractStateFactory factory) {
		if (factory == null)
			return false;
		if (factory.age != this.age)
			return false;
		
		if (!Arrays.equals(factory.phenotype, phenotype))
			return false;
		
		if (factory.timeInEncounter != timeInEncounter)
			return false;
	
		if (!Arrays.equals(consumedResourceType, factory.consumedResourceType)) {
			return false;
		}
		
		if (!Arrays.deepEquals(resourceCues, factory.resourceCues)) {
			return false;
		}
		
		if (!Arrays.deepEquals(delayCues, factory.delayCues)) {
			return false;
		}
		
		if (!Arrays.deepEquals(interruptionCues, factory.interruptionCues)) {
			return false;
		}
		
		return true;
	}
	
	/** Returns true if the other state matches the current state. NOTE: there is no
	 * check for whether this is an ActionState or a MutationState!
	 * It is possible for an ActionState to match a MutationState.
	 * 
	 * An state(factory) is the same as a state if all state variables are equal -
	 * the invariant variables that remain constant throughout the decision tree are ignored.
	 * The state variables are an agent's 
	 * 		- Age
	 * 		- Phenotypic dimensions
	 * 		- Time spend in this encounter
	 * 		- Sampled cues (resource, delays, interruptions)
	 * 		- Consumed resource*/
	public boolean equals(T2AbstractState other) {
		if (other == null)
			return false;
		if (other.age != this.age)
			return false;
		
		if (!Arrays.equals(other.phenotype, phenotype))
			return false;
		
		if (other.timeInEncounter != timeInEncounter)
			return false;
	
		if (!Arrays.equals(consumedResourceType, other.consumedResourceType)) {
			return false;
		}
		
		if (!Arrays.deepEquals(resourceCues, other.resourceCues)) {
			return false;
		}
		
		if (!Arrays.deepEquals(delayCues, other.delayCues)) {
			return false;
		}
		
		if (!Arrays.deepEquals(interruptionCues, other.interruptionCues)) {
			return false;
		}
		
		return true;
	}
	
	/** Sometimes we want to store a whole T2DecisionTree to disk in between the forwards and backwards passes.
	 * Doing so increases runtime, but also severely decreases the RAM usage of the program. However, after
	 * loading a T2DecisionTree from disk, we need to 'reconnect' it with the rest of the model. This is done
	 * by 'reinflating' the T2DecisionTree - that is, resetting all transient fields. For a T2AbstractState, this
	 * reinflation means that we have to connect all the T1AbstractStateReferences (in the successors) to actual
	 * T1AbstractStates. */
	public abstract void reinflate(Model model);
	
	public String toString(String header) {
		StringBuilder sb = new StringBuilder(header + ": " + this.getName());
		sb.append("\n\t-------- State variables --------");
		sb.append("\n\tAge: " + this.age);
		sb.append("\n\tTime step: " + this.timeInEncounter);
		sb.append("\n\tPhenotype: " + Helper.arrayToString(this.phenotype));
		sb.append("\n\tEncountered resources: " + Helper.arrayToString(this.encounteredResourceType));
		sb.append("\n\tConsumed    resources: " + Helper.arrayToString(this.consumedResourceType));
		sb.append("\n\tSampled RESOURCE cues: " + Helper.arrayToString(this.resourceCues));
		sb.append("\n\tSampled DELAY cues: " + Helper.arrayToString(this.delayCues));
		sb.append("\n\tSampled INTERRUPTION cues: " + Helper.arrayToString(this.interruptionCues));
		sb.append("\n\n\t---------- Invariants ----------");
		sb.append("\n\tCurrent location: [p" + this.locationPatch +",s" + this.locationPatchState + "]");
		sb.append("\n\tPatch state at start encounter: " + this.patchStateWhenStartingEncounter);
		sb.append("\n\tLast visits: " + Helper.arrayToString(this.lastVisitToPatch));
		sb.append("\n\tLast States: " + Helper.arrayToString(this.patchStateOfLastVisit));
		sb.append("\n\tEncountered observable RESOURCE: " + Helper.arrayToString(this.valueIndexOfEncounteredObservableResources));
		sb.append("\n\tEncountered observable DELAY: " + Helper.arrayToString(this.durationIndexOfEncounteredObservableDelays));
		sb.append("\n\tEncountered observable INTERRUPTION: " + Helper.arrayToString(this.willEncounteredObservableInterruptions));
		
		return sb.toString();
	}
	

}