package t2states;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Set;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper;
import model.Model;
import stateInterfacesAndAbstractions.Path;
import t1states.T1AbstractState;
import t1states.T1ActionState;
import t1states.T1FitnessState;
import t1states.T1MutationState;

public class T2StateList implements Serializable {
	private static final long serialVersionUID = Helper.programmeVersion;


	// There are [timeInCycle] separate Concurrent HashMaps to store states in.
	// These states take a 
	private final CanonicalT2StateMap[] maps; 
	private final int maximumTimeInEncounter;
	public transient Model model;
	public final int numberOfDigits = 4;

	protected T2StateList (Model model, T2DecisionTree tree) {
		// figure out what the maximum number of cycles is during the encounter
		this.maximumTimeInEncounter = model.maximumStepsInEncounter;
		this.model = model;

		this.maps = new CanonicalT2StateMap[maximumTimeInEncounter];
		for (int t= 0; t < maximumTimeInEncounter; t++)
			maps[t] = new CanonicalT2StateMap(tree);
	}

	/** After loading a T2DecisionTree to disk and loading it back for the backwards pass, we
	 * need to reset the reference to the model. This function should only be called by the
	 * T2DecisionTree to which this T2StateList belongs.*/
	protected void reinflate(Model model) {
		this.model = model;

		for (CanonicalT2StateMap map: maps)
			map.reinflate(model);
	}


	/** If there is already a T2ActionState with the same values at the argument state, this function
	 * returns a reference to the existing T2ActionState. If no such state exists yet, this function
	 * adds the argument state to the List, and returns the argument state. */
	public T2ActionState getActionState(T2ActionState actionState) {
		return maps[actionState.timeInEncounter].getActionState(actionState);
	}


	/** If there is already a T2ActionState with the same values at the argument stateFactory, this function
	 * returns a reference to the existing T2ActionState. If no such state exists yet, this function
	 * creates a new state from the factory, adds this new state to the Map, and returns the new state.
	 * */
	public T2ActionState getActionState(T2ActionStateFactory stateFactory) {
		return maps[stateFactory.timeInEncounter].getActionState( stateFactory);
	}

	/** Returns an unordered set of all action states registered at time t in the encounter */
	public Set<T2ActionState> getAllActionStates(int t){
		return maps[t].getAllActionStates();
	}

	/** Returns an ArrayList of all action states registered in this T2DecisionTree */
	public ArrayList<T2ActionState> getAllActionStates(){
		ArrayList<T2ActionState> allStates = new ArrayList<>();
		for (CanonicalT2StateMap map: maps )
			allStates.addAll(map.getAllActionStates());
		return allStates;
	}

	
	/** If there is already a T2MutationState with the same values at the argument state, this function
	 * returns a reference to the existing T2MutationState. If no such state exists yet, this function
	 * adds the argument state to the List, and returns the argument state. */
	public T2MutationState getMutationState(T2MutationState mutationState) {
		return maps[mutationState.timeInEncounter].getMutationState(mutationState);
	}


	/** If there is already a T2MutationState with the same values at the argument stateFactory, this function
	 * returns a reference to the existing T2MutationState. If no such state exists yet, this function
	 * creates a new state from the factory, adds this new state to the Map, and returns the new state.
	 * */
	public T2MutationState getMutationState(T2MutationStateFactory stateFactory) {
		return maps[stateFactory.timeInEncounter].getMutationState( stateFactory);
	}

	/** Returns an unordered set of all mutation states registered at time t in the encounter */
	public Set<T2MutationState> getAllMutationStates(int t){
		return maps[t].getAllMutationStates();
	}

	/** Returns an ArrayList of all mutation states registered in this T2DecisionTree */
	public ArrayList<T2MutationState> getAllMutationStates(){
		ArrayList<T2MutationState> allStates = new ArrayList<>();
		for (CanonicalT2StateMap map: maps )
			allStates.addAll(map.getAllMutationStates());
		return allStates;
	}


	/** Returns the number of action states registered for this time step in this 
	 * StateList thus far. This does not have to be the total, final number of states. */
	public int numberOfActionStates(int timeInCycle) {
		return maps[timeInCycle].numberOfT2ActionStates();
	}

	/** Returns the number of action states registered for this time step in this 
	 * StateList thus far. This does not have to be the total, final number of states. */
	public long numberOfActionStates() {
		long sum = 0;
		for (int i = 0; i < maps.length; i ++)
			sum += maps[i].numberOfT2ActionStates();
		return sum;
	}

	/** Returns the number of mutation states registered for this time step in this 
	 * StateList thus far. This does not have to be the total, final number of states. */
	public int numberOfMutationStates(int timeInCycle) {
		return maps[timeInCycle].numberOfT2MutationStates();
	}

	/** Returns the number of mutation states registered for this time step in this 
	 * StateList thus far. This does not have to be the total, final number of states. */
	public long numberOfMutationStates() {
		long sum = 0;
		for (int i = 0; i < maps.length; i ++)
			sum += maps[i].numberOfT2MutationStates();
		return sum;
	}

	///////////////////////////////////////////////////////////////////////
	//////////////////////// ToString for debugging //////////////////////
	/////////////////////////////////////////////////////////////////////

	@Override

	/** Creates a textual overview of all the states in this StateList. First
	 * a table with all states in a single line is printed. Next, each states is
	 * given a full description.*/
	public String toString() {
		StringBuilder sb = new StringBuilder("T2StateList:\n\n");

		// Find the number of characters in the longest string
		int columnWidth = 25;
		for (String s : model.ledger.phenotypeNames)
			if (s.length() > columnWidth) columnWidth = s.length();
		int columns = 
				1 + // Name
				1 + // Type
				1 + // Age
				1 + // TimeStep
				model.ledger.numberOfNonAgePhenotypicDimensions+
				model.ledger.numberOfResourceTypes + // Number of resource cues (each entry prints an array for cue labels)
				model.ledger.numberOfDelayTypes + // Number of delay cues (each entry prints an array for cue labels)
				model.ledger.numberOfInterruptionTypes + // Number of interruption cues (each entry prints an array for cue labels)
				1 + // encountered resources
				1 + // consumed resources
				1 + //observed resource values 
				1 + //observed delay values 
				1 +// observed interruption types
				1 + // Possible Actions
				model.ledger.numberOfT2Actions + //(backwards pass) Fitness for each action. Empty for mutation states
				1 + // (backwards pass) best action(s). Empty for mutation states
				1 + // (backwards pass) Expected fitness
				1+ // Expected age
				model.ledger.numberOfNonAgePhenotypicDimensions +
				model.ledger.numberOfT2Actions +		// E[#Immediate T2 1].  Empty for MutationStates
				model.ledger.numberOfT2Actions +		// E[#Future T2 in this tree 1]
				model.ledger.numberOfT2Actions + 		// E{#Future T2]
				model.ledger.numberOfT1Actions + 		// E[#Future T1]
				1 +	// #Ancestors
				1 + // #Successors
				1; // successors


		// For time step, print the states (ordered by current location)
		for (int time = 0; time < this.maximumTimeInEncounter; time ++) {
			if (this.maps[time].numberOfT2States() > 0) {
				sb.append("\n\nTime step: " + time+ " (" + maps[time].numberOfT2States()+" states):\n" + createColumnHeader(columnWidth, columns) );
				sb.append(printActionAndMutationStates(time, columnWidth, columns));
			}
		}

		return sb.toString();
	}

	private String createColumnHeader(int columnWidth, int columns ) {
		StringBuilder sb = new StringBuilder();

		// Print the following column headers: name, type, age, location, phenotype1, ..., phenotypeN, Last visit to patch [patch1], Last seen state of patch [p], ... Last visit to patch [patchN], Last seen state of patch [N]

		// Column headers:
		// Name,
		// type
		// age
		// time step in cycle
		// phenotype1, ..., phenotypeN
		// ResourceCue1: {cl, ..., cl}
		// ..
		// ResourceCueN: {}

		// (same for delay and interruption cues)

		// Consumed resource: {TF, TF, TF}
		// Encountered resources
		// Observed resource: {resource1, ... resourceN}
		// Observed delay:
		// Observed interruption
		// Possible actions
		// Fitness of action [action 1, ..., action n]. Empty for mutation states
		// Best action(s). Empty for mutation states
		// Expected fitness
		// Expected age 
		// Expected phenotypes {phenotype1, ..., phenotypeN}
		// Expected immediate T2 actions {action1, ..., actionN}
		// Expected future T2 actions in this tree {action1, ..., actionN}
		// Expected future T2 actions {action1, ..., actionN}
		// Expected future T1 actions in this tree {action1, ..., actionN}
		// #Ancestors
		// #Successors
		// Successors
		String name = "Name";
		String nameSpaced = name + Helper.repString(" ", columnWidth - name.length()) + "| ";
		sb.append(nameSpaced);

		String type= "Type";
		String typeSpaced = type + Helper.repString(" ", columnWidth - type.length()) + "| ";
		sb.append(typeSpaced);

		String age = "Age";
		String ageSpaced = age + Helper.repString(" ", columnWidth - age.length()) + "| ";
		sb.append(ageSpaced);

		String time = "Time step";
		String timeSpaced = time  + Helper.repString(" ", columnWidth - time .length()) + "| ";
		sb.append(timeSpaced);

		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s = model.ledger.phenotypeNames[i];
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		for (int i = 0; i < model.ledger.numberOfResourceTypes; i++) {
			String s = "Cues" + model.ledger.resourceNames[i];
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		for (int i = 0; i < model.ledger.numberOfDelayTypes; i++) {
			String s = "Cues" + model.ledger.delayNames[i];
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}


		for (int i = 0; i < model.ledger.numberOfInterruptionTypes; i++) {
			String s = "Cues" + model.ledger.interruptionNames[i];
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		String cons = "Consumed resources";
		String consSpaced = cons+ Helper.repString(" ", columnWidth - cons.length()) + "| ";
		sb.append(consSpaced);

		String enc = "Encountered resources";
		String encSpaced = enc+ Helper.repString(" ", columnWidth - enc.length()) + "| ";
		sb.append(encSpaced);

		String obsr = "observed resources";
		String obsrSpaced = obsr+ Helper.repString(" ", columnWidth - obsr.length()) + "| ";
		sb.append(obsrSpaced);

		String obsd = "observed delay";
		String obsdSpaced = obsd+ Helper.repString(" ", columnWidth - obsd.length()) + "| ";
		sb.append(obsdSpaced);

		String obsi = "observed interruptions";
		String obsiSpaced = obsi+ Helper.repString(" ", columnWidth - obsi.length()) + "| ";
		sb.append(obsiSpaced);

		String action = "Possible actions";
		String actionSpaced = action + Helper.repString(" ", columnWidth - action.length()) + "| ";
		sb.append(actionSpaced);

		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s = "E[Fitness|" + model.ledger.t2ActionNames[i] + "]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		String bestAction = "Best actions";
		String bestActionSpaced = bestAction + Helper.repString(" ", columnWidth - bestAction.length()) + "| ";
		sb.append(bestActionSpaced);

		String fitness = "E[Fitness]";
		String fitnessSpaced = fitness + Helper.repString(" ", columnWidth - fitness.length()) + "| ";
		sb.append(fitnessSpaced);

		String expectedAge = "E[Age]";
		String expectedAgeSpaced = expectedAge+ Helper.repString(" ", columnWidth - expectedAge.length()) + "| ";
		sb.append(expectedAgeSpaced);

		// Expected phenotype
		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s = "E[" + model.ledger.phenotypeNames[i] + "]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		// Immediate T2
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s = "E[" + model.ledger.t2ActionNames[i] + "|now]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}


		// T2 in this tree
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s = "E[#" + model.ledger.t2ActionNames[i] + "|tree]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		// Future lifetime T2
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s = "E[#" + model.ledger.t2ActionNames[i] + "|life]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		// Future T1
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s = "E[#" + model.ledger.t2ActionNames[i] + "|life]";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}



		String nAnc = "#Ancestors";
		String nAncSpaced = nAnc + Helper.repString(" ", columnWidth - nAnc.length()) + "| ";
		sb.append(nAncSpaced);

		String nSuc = "#Successors";
		String nSucSpaced = nSuc + Helper.repString(" ", columnWidth - nSuc.length()) + "| ";
		sb.append(nSucSpaced);

		String destination = "Successors";
		sb.append(destination);

		// Print the line under the column names
		sb.append("\n");
		for (int i = 0; i < columns; i++)
			sb.append(Helper.repString("-", columnWidth)  + "| ");
		return sb.toString();
	}

	private String printActionAndMutationStates(int timeStep, int columnWidth, int columns) {
		CanonicalT2StateMap currentMap = maps[timeStep];
		StringBuilder sb = new StringBuilder();

		// Get all the states
		ArrayList<T2ActionState> unsortedActions = new ArrayList<>();
		ArrayList<T2MutationState> unsortedMutatons = new ArrayList<>();


		unsortedActions.addAll(currentMap.getAllActionStates());
		unsortedMutatons.addAll(currentMap.getAllMutationStates());

		// Create a Comparator
		Comparator<T2AbstractState> comparator = new Comparator<T2AbstractState>() {

			@Override
			public int compare(T2AbstractState o1, T2AbstractState o2) {
				// First: sort on ID number
				if (o1.getID()< o2.getID())
					return -1;
				else if (o1.getID() > o2.getID())
					return 1;
				return 0;
			}
		};

		// Order the states by name
		Collections.sort(unsortedActions, comparator);
		Collections.sort(unsortedMutatons, comparator);


		for (T2ActionState actionState: unsortedActions)
			sb.append(printIndividualActionOrMutationState(actionState, "Action", columnWidth));

		for (T2MutationState mutationState: unsortedMutatons)
			sb.append(printIndividualActionOrMutationState(mutationState, "<<Mutation>>", columnWidth));


		return sb.toString();
	}

	private String printIndividualActionOrMutationState(T2AbstractState state, String type, int columnWidth){
		StringBuilder sb = new StringBuilder("\n");

		// Column headers:
		// Name,
		// type
		// age
		// time step in cycle
		// phenotype1, ..., phenotypeN
		// ResourceCue1: {cl, ..., cl}
		// ..
		// ResourceCueN: {}

		// (same for delay and interruption cues)

		// Consumed resource: {TF, TF, TF}
		// Encountered resources
		// Observed resource: {resource1, ... resourceN}
		// Observed delay:
		// Observed interruption
		// Possible actions
		// Fitness of action [action 1, ..., action n]. Empty for mutation states
		// Best action(s). Empty for mutation states
		// Expected fitness
		// Expected age 
		// Expected phenotypes {phenotype1, ..., phenotypeN}
		// Expected immediate T2 actions {action1, ..., actionN}
		// Expected future T2 actions in this tree {action1, ..., actionN}
		// Expected future T2 actions {action1, ..., actionN}
		// Expected future T1 actions in this tree {action1, ..., actionN}
		// #Ancestors
		// #Successors
		// Successors

		String name = state.getName();
		String nameSpaced = name + Helper.repString(" ", columnWidth - name.length()) + "| ";
		sb.append(nameSpaced);

		String typeSpaced = type + Helper.repString(" ", columnWidth - type.length()) + "| ";
		sb.append(typeSpaced);

		String age = state.getAge() +"";
		String ageSpaced = age + Helper.repString(" ", columnWidth - age.length()) + "| ";
		sb.append(ageSpaced);

		String time = state.timeInEncounter+"";
		String timeSpaced = time  + Helper.repString(" ", columnWidth - time .length()) + "| ";
		sb.append(timeSpaced);

		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s = state.getPhenotypeValue(i) + "";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		for (int i = 0; i < model.ledger.numberOfResourceTypes; i++) {
			String s = Helper.arrayToConciseString(state.resourceCues[i]);
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		for (int i = 0; i < model.ledger.numberOfDelayTypes; i++) {
			String s = Helper.arrayToConciseString(state.delayCues[i]);
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}


		for (int i = 0; i < model.ledger.numberOfInterruptionTypes; i++) {
			String s = Helper.arrayToConciseString(state.interruptionCues[i]);
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		String cons = Helper.arrayToConciseString(state.consumedResourceType); 
		String consSpaced = cons+ Helper.repString(" ", columnWidth - cons.length()) + "| ";
		sb.append(consSpaced);

		String enc = Helper.arrayToConciseString(state.encounteredResourceType);
		String encSpaced = enc+ Helper.repString(" ", columnWidth - enc.length()) + "| ";
		sb.append(encSpaced);

		String obsr = Helper.arrayToConciseString(state.valueIndexOfEncounteredObservableResources);
		String obsrSpaced = obsr+ Helper.repString(" ", columnWidth - obsr.length()) + "| ";
		sb.append(obsrSpaced);

		String obsd = Helper.arrayToConciseString(state.durationIndexOfEncounteredObservableDelays);
		String obsdSpaced = obsd+ Helper.repString(" ", columnWidth - obsd.length()) + "| ";
		sb.append(obsdSpaced);

		String obsi = Helper.arrayToConciseString(state.willEncounteredObservableInterruptions);
		String obsiSpaced = obsi+ Helper.repString(" ", columnWidth - obsi.length()) + "| ";
		sb.append(obsiSpaced);

		String action =  "";
		if (!(state instanceof T2ActionState))
			action = "-";
		else if (((T2ActionState) state).getPossibleActions() == null)
			action = "";
		else {
			ArrayList<Integer> possibleActions = ((T2ActionState) state).getPossibleActions();
			StringBuilder a = new StringBuilder();
			a.append("[");
			for (int i = 0; i < possibleActions.size(); i ++) {
				a.append(possibleActions.get(i));
				if (i != (possibleActions.size()-1) && possibleActions.size()>0)
					a.append(",");
			}
			a.append("]");
			action = a.toString();
		}


		String actionSpaced = action + Helper.repString(" ", columnWidth - action.length()) + "| ";
		sb.append(actionSpaced);


		// Fitness of actions. Empty for mutation states or action states that have not gone through a backwards pass yet
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s;
			if (state instanceof T2ActionState && state.wentThroughBackwardsPass()) //if it knows it fitness, it went through the backwards pass
				s = ((T2ActionState) state).getExpectedFitnessOfAction(i).toString(numberOfDigits);
			else if (!state.wentThroughBackwardsPass())
				s = "Not backwards yet";
			else
				s = "";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		String bestAction;
		if (state instanceof T2ActionState && state.wentThroughBackwardsPass()) {//if it knows it fitness, it went through the backwards pass
			bestAction = "";
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
				if (((T2ActionState)state).isBestAction[a])
					bestAction = bestAction + a + " ";
		}
		else if (state instanceof T2ActionState)
			bestAction = "Not backwards yet";
		else
			bestAction = "";
		String bestActionSpaced = bestAction + Helper.repString(" ", columnWidth - bestAction.length()) + "| ";
		sb.append(bestActionSpaced);

		String fitness;
		if (state.wentThroughBackwardsPass())
			fitness = state.getExpectedFitness().toString(numberOfDigits);
		else 
			fitness = "Not backwards yet";
		String fitnessSpaced = fitness + Helper.repString(" ", columnWidth - fitness.length()) + "| ";
		sb.append(fitnessSpaced);


		String expectedAge = state.getExpectedAge().toString(numberOfDigits);
		String expectedAgeSpaced = expectedAge+ Helper.repString(" ", columnWidth - expectedAge.length()) + "| ";
		sb.append(expectedAgeSpaced);


		for (int i = 0; i < model.ledger.numberOfNonAgePhenotypicDimensions; i++) {
			String s = state.getExpectedPhenotype(i).toString(numberOfDigits);
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		// Immediate T2 actions
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s;
			if (state instanceof T2ActionState)
				s = ((T2ActionState)state).probabilityOfImmediateT2Action[i].toString(numberOfDigits) + "  |T2now";
			else
				s = "";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		// Future T2 actions in this tree
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s = state.getFutureTimesItPerformsT2ActionInThisTree(i).toString(numberOfDigits) + "  |T2tree";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		// Future lifetime T2 actions
		for (int i = 0; i < model.ledger.numberOfT2Actions; i++) {
			String s = state.getFutureTimesItPerformsT2Action(i).toString(numberOfDigits) + "  |T2life";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		// Future lifetime T1 actions
		for (int i = 0; i < model.ledger.numberOfT1Actions; i++) {
			String s = state.getFutureTimesItPerformsT1Action(i).toString(numberOfDigits) + "  |T1life";
			String spaced = s + Helper.repString(" ", columnWidth - s.length()) + "| ";
			sb.append(spaced);
		}

		if (state instanceof T2ActionState) {
			T2ActionState t2as = (T2ActionState) state;

			int nT1M = 0;
			int nT1F = 0;
			int nT2M = 0;
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) {
				if (t2as.wentThroughBackwardsPass())
					if (!t2as.isBestAction[a])
						continue;
				nT1M += t2as.getSuccessorT1FitnessPaths(a).size();
				nT1F += t2as.getSuccessorT1FitnessPaths(a).size();
				nT2M += t2as.getSuccessorT2MutationPaths(a).size();
			}
			String nSuc = "1M:"  + nT1M + "|1F:" + nT1F + "|2M:" + nT2M ;
			String nSucSpaced = nSuc + Helper.repString(" ", columnWidth - nSuc.length()) + "| ";
			sb.append(nSucSpaced);
		} else {
			T2MutationState t2ms = (T2MutationState) state;


			int nT1F =  t2ms.successorT1FitnessStates.size();
			int nT2A = t2ms.successorT2ActionStates.size();
			int nT1A = t2ms.successorT1ActionStates.size();

			String nSuc ="1F:"+ nT1F + "|1A:"+ nT1A+ "|2A:" + nT2A;
			String nSucSpaced = nSuc + Helper.repString(" ", columnWidth - nSuc.length()) + "| ";
			sb.append(nSucSpaced);
		}



		String connections = "";
		if (state instanceof T2ActionState) {
			T2ActionState s = (T2ActionState)state;
			if (!s.wentThroughForwardsPass())
				connections = "Not expanded yet";
			else {
				StringBuilder actionBuilder = new StringBuilder();
				for (int a = 0; a < s.getPossibleActions().size(); a++) {
					if (s.wentThroughBackwardsPass())
						if (!s.isBestAction[a])
							continue;
					actionBuilder.append("{" + model.ledger.t2ActionNames[s.getPossibleActions().get(a)] + "| ");
					for (Path<T2ActionState, T2MutationState> p : s.getSuccessorT2MutationPaths(s.getPossibleActions().get(a)))
						actionBuilder.append(p.toDestinationString(numberOfDigits) + ";");
					for (Path<T2ActionState, T1MutationState> p : s.getSuccessorT1MutationPaths(s.getPossibleActions().get(a)))
						actionBuilder.append(p.toDestinationString(numberOfDigits) + ";");
					for (Path<T2ActionState, T1FitnessState> p : s.getSuccessorT1FitnessPaths(s.getPossibleActions().get(a)))
						actionBuilder.append(p.toDestinationString(numberOfDigits) + ";");
					actionBuilder.append("}\t");
				}
				connections = actionBuilder.toString();
			}
		} else if (state instanceof T2MutationState) {
			T2MutationState s = (T2MutationState) state;
			if (!s.wentThroughForwardsPass())
				connections = "Not mutated yet";
			else
			{
				StringBuilder mutationBuilder = new StringBuilder();
				for (Path<T2MutationState, T2ActionState> p : s.getSuccessorT2ActionPaths())
					mutationBuilder.append(p.toDestinationStringIncludingAnnotation(numberOfDigits) + "; \t");
				for (Path<T2MutationState, T1FitnessState> p : s.getSuccessorT1FitnessPaths())
					mutationBuilder.append(p.toDestinationStringIncludingAnnotation(numberOfDigits) + "; \t");
				connections = mutationBuilder.toString();
			}

		}
		sb.append(connections);

		return sb.toString();
	}


	///////////////////////////////////////////////////////////////////////
	//////////////////////// ToString for results ////////////////////////
	/////////////////////////////////////////////////////////////////////
	/** Get a list of all variable names that are to be stored. This list
	 * is used to create the column headers, and should mirror perfectly 
	 * the order in actionOrMutationStateToEntry().*/
	private ArrayList<String> getStateSpecificVariableNames() {
		ArrayList<String> variableNames = new ArrayList<>();

		////// First, all state identifiers
		// 1. Name
		variableNames.add("Name");
		// 2. Type
		variableNames.add("Type");
		// 3. Age
		variableNames.add("Age");
		// 3a. Time step
		variableNames.add("Time_Step");
		// 4. Location (patch)
		variableNames.add("LocationPatch");
		// 5. Location (patch state)
		variableNames.add("LocationPatchState");
		// 5a. Location when starting encounter (patch state)
		variableNames.add("LocationPatchState_starting_encounter");
		// 5b. EncounteredResource type
		for (int r = 0; r < model.ledger.numberOfResourceTypes; r++)
			variableNames.add("Encountered_" + model.ledger.resourceNames[r]);
		// 5c. Value Encountered Resource
		for (int r = 0; r < model.ledger.numberOfResourceTypes; r++)
			variableNames.add("Value_Encountered_" + model.ledger.resourceNames[r]);
		// 5d. Duration Encountered Delay
		for (int d = 0; d < model.ledger.numberOfDelayTypes; d++)
			variableNames.add("Duration_Encountered_" + model.ledger.delayNames[d]);
		// 5e. Will Encounter Interruption
		for (int i = 0; i < model.ledger.numberOfInterruptionTypes; i++)
			variableNames.add("Will_Encounter_Interruption_" + model.ledger.interruptionNames[i]);

		// 6. Phenotypes (in original metric)
		for (int p = 0; p < model.ledger.numberOfNonAgePhenotypicDimensions; p++)
			variableNames.add(model.ledger.phenotypeNames[p]);
		// 7. Last visit/last patch combinations
		for (int patch = 0; patch < model.ledger.numberOfPatches; patch++) {
			variableNames.add("LastVisitPatch_"+ model.ledger.patchNames[patch] );
			variableNames.add("LastStatePatch_"+ model.ledger.patchNames[patch] );
		}
		// 8. Possible action? For each T2 action: is this action possible? (TRUE/FALSE)
		// (Print 'NULL' for T2MutationStates)
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			variableNames.add("T2ActionPossible_" + model.ledger.t2ActionNames[a] );

		// 8a. Resource cues
		for (int r = 0; r < model.ledger.numberOfResourceTypes; r++)
			if (model.ledger.resourceCues[r] != null)
				for (int cl = 0; cl < model.ledger.resourceCueLabels[r].length; cl++)
					variableNames.add("Cue_"+ model.ledger.resourceNames[r] + "_" + model.ledger.resourceCueLabels[r][cl]);
		// 8b. Delay cues
		for (int d = 0; d < model.ledger.numberOfDelayTypes; d++)
			if (model.ledger.delayCues[d] != null)
				for (int cl = 0; cl < model.ledger.delayCueLabels[d].length; cl++)
					variableNames.add("Cue_"+ model.ledger.delayNames[d] + "_" + model.ledger.delayCueLabels[d][cl]);
		// 8c. Interruption cues
		for (int i = 0; i < model.ledger.numberOfInterruptionTypes; i++)
			if (model.ledger.interruptionCues[i] != null)
				for (int cl = 0; cl < model.ledger.interruptionCueLabels[i].length; cl++)
					variableNames.add("Cue_"+ model.ledger.interruptionNames[i] + "_" + model.ledger.interruptionCueLabels[i][cl]);
		
		///// Second, all the variables we computed in the backwards pass
		// 9. Expected fitness of each T2 action (print 'NULL' for T1MutationStates)
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			variableNames.add("ExpectedFitnessT2Action_" + model.ledger.t2ActionNames[a] );

		// 10. Best action? For each T2 action: is this action a best action? (TRUE/FALSE)
		// (Print 'NULL' for T2MutationStates)
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			variableNames.add("IsBestAction_" + model.ledger.t2ActionNames[a] );
		// 11. Expected fitness state
		variableNames.add("ExpectedFitnessState");
		// 12. Expected age
		variableNames.add("ExpectedAge");
		// 12a. Expected immediate time steps spend waiting/postponing
		variableNames.add("ExpectedImmediateDelay");
		// 12b. Expected future time steps waiting/postponing
		variableNames.add("ExpectedTotalDelay");
		// 13. Expected phenotypes (in original metric)
		for (int p = 0; p < model.ledger.numberOfNonAgePhenotypicDimensions; p++)
			variableNames.add("Expected" + Helper.capitalize(model.ledger.phenotypeNames[p]));

		// 14. Expected number of future T1 actions, one for each T1 action
		for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
			variableNames.add("ExpectedFutureNumber_" + model.ledger.t1ActionNames[a] );


		// 15. Expected number of immediate T2 actions, one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			variableNames.add("ExpectedImmediateNumber_" + model.ledger.t2ActionNames[a] );

		// 16. Expected number of future T2 actions, one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			variableNames.add("ExpectedFutureNumber_" + model.ledger.t2ActionNames[a] );

		// 17. Expected number of total T2 actions (Future + immediate), one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			variableNames.add("ExpectedTotalNumber_" + model.ledger.t2ActionNames[a] );

		return variableNames;
	}

	/** Takes as input a String containing all model-invariant variable names separated by
	 * the delimiter. These are the variables that are fixed within a model (i.e., the
	 * sampling distributions of all non-phenotype objects). It appends to this the variable names
	 * that are state-specific (e.g., the expected age, etc). The resulting string does 
	 * NOT end with a delimiter, but rather, with a field called "FINALENDINGFIELD" to provide
	 * a check that all fields have been written correctly.*/
	private String appendColumnHeaders(String fixedColumnHeaders, ArrayList<String> stateSpecificVariableNames, String delimiter) {
		StringBuilder sb = new StringBuilder(fixedColumnHeaders);
		for (String columnName : stateSpecificVariableNames)
			sb.append(columnName + delimiter);
		sb.append("FINALENDINGFIELD");
		return sb.toString();
	}

	/** Convert one T2Action or one T2MutationState to a list of Strings that
	 * represents the state. Used to create the final results file. 
	 * 
	 * The variables used should mirror the order in getStateSpecificVariableNames()! */
	private ArrayList<String> actionOrMutationStateToArrayListOfFields(T2AbstractState state){
		// Get all fields into strings, without delimiters yet
		ArrayList<String> fields = new ArrayList<>();;

		////// First, all state identifiers
		// 1. Name
		fields.add(state.getName());
		// 2. Type
		if (state instanceof T2ActionState)
			fields.add("Action");
		else if (state instanceof T2MutationState)
			fields.add("Mutation");
		else 
			throw new IllegalStateException("T2State is neither action, mutation, or fitness.");
		// 3. Age
		fields.add(""+state.getAge());
		// 3a. Time step
		fields.add(""+ state.getTimeInCycle());
		// 4. Location (patch)
		fields.add(""+state.getLocationPatch());
		// 5. Location (patch state)
		fields.add(""+state.getLocationPatchState());
		// 5a. Location when starting encounter (patch state)
		fields.add(""+state.patchStateWhenStartingEncounter);
		// 5b. EncounteredResource type
		for (int r = 0; r < model.ledger.numberOfResourceTypes; r++)
			fields.add(""+state.encounteredResourceType[r]);
		// 5c. Value Encountered Resource
		for (int r = 0; r < model.ledger.numberOfResourceTypes; r++)
			if (state.valueIndexOfEncounteredObservableResources[r] == -1) // i.e., is not observable
				fields.add("NOT_OBSERVABLE");
			else
				fields.add("" +model.ledger.getValueOfResource(r, state.valueIndexOfEncounteredObservableResources[r]).toPlainString());
		// 5d. Duration Encountered Delay
		for (int d = 0; d < model.ledger.numberOfDelayTypes; d++)
			if (state.durationIndexOfEncounteredObservableDelays[d] == -1) // i.e., is not observable
				fields.add("NOT_OBSERVABLE");
			else
				fields.add("" +model.ledger.getValueOfDelay(d, state.durationIndexOfEncounteredObservableDelays[d]));
		// 5e. Will Encounter Interruption
		for (int i = 0; i < model.ledger.numberOfInterruptionTypes; i++)
			fields.add("" + state.willEncounteredObservableInterruptions[i]);

		// 6. Phenotypes (in original metric)
		for (int p = 0; p < model.ledger.numberOfNonAgePhenotypicDimensions; p++)
			fields.add(model.ledger.getValueOfPhenotype(p, state.getPhenotypeValue(p)).toPlainString());
		// 7. Last visit/last patch combinations
		for (int patch = 0; patch < model.ledger.numberOfPatches; patch++) {
			fields.add(""+state.timeStepsSinceLastVisit(patch));
			fields.add(""+state.patchStateDuringLastVisit(patch));
		}
		// 8. Possible action? For each T2 action: is this action possible? (TRUE/FALSE)
		// (Print 'NULL' for T2MutationStates)
		if (state instanceof T2MutationState)
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("NULL");
		else if (state instanceof T2ActionState) {
			boolean[] isPossible = ((T2ActionState)state).possibleActions;
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("" + isPossible[a]);
		}
		else 
			throw new IllegalStateException("T2State is neither action, mutation, or fitness.");


		// 8a. Resource cues
		for (int r = 0; r < model.ledger.numberOfResourceTypes; r++)
			if (model.ledger.resourceCues[r] != null)
				for (int cl = 0; cl < model.ledger.resourceCueLabels[r].length; cl++)
					fields.add("" + state.resourceCues[r][cl]);
		// 8b. Delay cues
		for (int d = 0; d < model.ledger.numberOfDelayTypes; d++)
			if (model.ledger.delayCues[d] != null)
				for (int cl = 0; cl < model.ledger.delayCueLabels[d].length; cl++)
					fields.add("" + state.delayCues[d][cl]);
		// 8c. Interruption cues
		for (int i = 0; i < model.ledger.numberOfInterruptionTypes; i++)
			if (model.ledger.interruptionCues[i] != null)
				for (int cl = 0; cl < model.ledger.interruptionCueLabels[i].length; cl++)
					fields.add("" + state.interruptionCues[i][cl]);
		
		
		///// Second, all the variables we computed in the backwards pass
		// 9. Expected fitness of each T2 action (print 'NULL' for T1MutationStates)
		if (state instanceof T2MutationState)
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("NULL");
		else if (state instanceof T2ActionState) {
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("" + ((T2ActionState)state).getExpectedFitnessOfAction(a).toPlainString());
		}
		else 
			throw new IllegalStateException("T2State is neither action, mutation, or fitness.");

		// 10. Best action? For each T2 action: is this action a best action? (TRUE/FALSE)
		// (Print 'NULL' for T2MutationStates)
		if (state instanceof T2MutationState)
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("NULL");
		else if (state instanceof T2ActionState) {
			boolean[] isBest = ((T2ActionState)state).isBestAction;
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("" + isBest[a]);
		}
		else 
			throw new IllegalStateException("T2State is neither action, mutation, or fitness.");

		// 11. Expected fitness state
		fields.add(state.getExpectedFitness().toPlainString());
		// 12. Expected age
		fields.add(state.getExpectedAge().toPlainString());
		
		// 12a. Expected immediate time steps spend waiting/postponing
		if (state instanceof T2MutationState)
			fields.add("NULL");
		else if (state instanceof T2ActionState) {
			fields.add(""+((T2ActionState)state).getExpectedImmediateTimestepsInDelay());
		}
		else 
			throw new IllegalStateException("T2State is neither action, mutation, or fitness."); 
			
		// 12b. Expected future time steps waiting/postponing
		fields.add("" + state.getExpectedTotalTimeStepsInDelay());
		
		// 13. Expected phenotypes (in original metric)
		for (int p = 0; p < model.ledger.numberOfNonAgePhenotypicDimensions; p++)
			fields.add(model.ledger.phenotypeExpectedLedgerIndexToOriginalMetric(p, state.getExpectedPhenotype(p)).toPlainString());

		
		// 14. Expected number of future T1 actions, one for each T1 action
		for (int a = 0; a < model.ledger.numberOfT1Actions; a++)
			fields.add(state.getFutureTimesItPerformsT1Action(a).toPlainString());

	

		// 16. Expected number of immediate T2 actions, one for each T2 action
		if (state instanceof T2MutationState)
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("NULL");
		else if (state instanceof T2ActionState) {
			for (int a = 0; a < model.ledger.numberOfT2Actions; a++) 
				fields.add("" + ((T2ActionState)state).probabilityOfImmediateT2Action[a].toPlainString());
		}
		else 
			throw new IllegalStateException("T2State is neither action, mutation, or fitness.");


		// 17. Expected number of future T2 actions, one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			fields.add(state.getFutureTimesItPerformsT2Action(a).toPlainString());

		// 18. Expected number of total T2 actions (Future + immediate), one for each T2 action
		for (int a = 0; a < model.ledger.numberOfT2Actions; a++)
			fields.add(state.getFutureTimesItPerformsT2Action(a).toPlainString());

		return fields;
	}

	/** Writes one T2ActionState or one T2MutationState as an entry in the final 
	 * results file. Specifically, it appends all the requires fields of the T1State
	 * to the fixedVariables (which contain all model-invariant values), which are
	 * separated by the delimiter. The fixedVariables should already end with a delimiter.
	 * Each entry ends with a 'FULLSTOP' to make sure that all fields are written.
	 */
	private String actionOrMutationStateToEntry (T2AbstractState state, String fixedVariables, String delimiter, ArrayList<String> columnHeaders) {
		if (!state.wentThroughBackwardsPass()) 
			throw new IllegalArgumentException("Cannot write results for a state that has not gone through the backwards pass yet.");

		// Create an ArrayList of Strings based on this state
		ArrayList<String> fieldStrings = this.actionOrMutationStateToArrayListOfFields(state);

		// Check if the number of fields in the state matches the number of column headers 
		if (fieldStrings.size() != columnHeaders.size()) {
			StringBuilder headers = new StringBuilder();
			for (String s: columnHeaders)
				headers.append(s + "\n");
			StringBuilder fields = new StringBuilder();
			for (String s: fieldStrings)
				fields.append(s + "\n");
			throw new IllegalArgumentException("Fields size does not match column header size. Number of fields: " + fieldStrings.size() + ", number of column headers: "+ columnHeaders.size()
			+ ". Headers:\n" + headers + "\n\n\nFields:\n" + fields.toString() );
		}

		// Append each field to fixedVariables, using a delimiter in between (fixedVariables already ends with one, so we do not 
		// have to append a delimiter here first)
		StringBuilder sb = new StringBuilder(fixedVariables);
		for (String field : fieldStrings)
			sb.append(field + delimiter);

		// End with a FULLSTOP
		sb.append("FULLSTOP");
		return sb.toString();
	}

	/** Creates a String that represents the results for all time steps. The model invariant
	 * variables are used as prefixes for the column names and the entries.*/
	public String toResultsStringForAllTimeSteps(String modelInvariantColumnNames, 
			String modelInvariantValues,
			String delimiter) {
		StringBuilder results = new StringBuilder();
		// First, get a list of all variables names (i.e., state specific variables)
		// that we have to append to the model invariants
		ArrayList<String> stateSpecificVariableNames = this.getStateSpecificVariableNames();

		// Append the state specific variable names to the model invariant variable names
		String header = this.appendColumnHeaders(modelInvariantColumnNames, stateSpecificVariableNames, delimiter);

		// Add the header to the results, and include a newLine at the end
		results.append(header + "\n");

		// Next for each T1ActionState with this age, append it to the results, and add a newline at the end
		for (int timeStep = 0; timeStep < model.maximumStepsInEncounter; timeStep++) {
			for (T2ActionState as : this.maps[timeStep].getAllActionStates()) {
				results.append(this.actionOrMutationStateToEntry(as, modelInvariantValues, delimiter, stateSpecificVariableNames));
				results.append("\n");
			}

			// Do the same for the T1MutationStates
			for (T2MutationState ms : this.maps[timeStep].getAllMutationStates()) {
				results.append(this.actionOrMutationStateToEntry(ms, modelInvariantValues, delimiter, stateSpecificVariableNames));
				results.append("\n");
			}
		}

		// Return the results
		return results.toString();
	}

}
