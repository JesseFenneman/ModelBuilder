package t2states;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper;
import helper.Helper.Triplet;
import model.Model;
import stateInterfacesAndAbstractions.Path;
import stateInterfacesAndAbstractions.ReferencedPath;
import t1states.T1AbstractStateFactory;
import t1states.T1ActionState;
import t1states.T1ActionStateReference;
import t1states.T1FitnessState;
import t1states.T1FitnessStateReference;
import t1states.T1MutationStateFactory;

/** A DURING encounter state where natures takes its turn.*/
public class T2MutationState extends T2AbstractState {
	private static final long serialVersionUID = Helper.programmeVersion;
	
	// From a T2MutationState the agent can go to either: 
	// 		a T2ActionState (if it remains within the encounter)
	//		a T1FitnessState (if it dies)
	public final ArrayList< Path<T2MutationState,   T2ActionState>> successorT2ActionStates; // All outgoing connections that do not result in death or the end of an encounter
	public final ArrayList< Path<T2MutationState,   T1FitnessState>> successorT1FitnessStates; // All outgoing connections that result in death
	public final ArrayList< Path<T2MutationState,   T1ActionState>> successorT1ActionStates; // All outgoing connections that end the encounter.

	/* Note that sometimes we want to store the T2DecisionTree to disk in between the forwards and backwards pass.
	 * However, in that case we need to reconnect all T2AbstractStates to the rest of the model. Specifically, we need
	 * to know what T1 successor states we need to reconnect. Rather than storing the successorT1FitnessStates and
	 * successorT1ActionStates directly after the forwards pass, we first store references to those state. Then, when
	 * reinflating the T2DecisionTree for the backwards pass, we can figure out to which T1AbstractStates these references
	 * point.*/
	public final ArrayList< ReferencedPath<T2MutationState,   T1FitnessStateReference>> referencePathToSuccessorT1FitnessStates; 
	public final ArrayList< ReferencedPath<T2MutationState,   T1ActionStateReference>> referencePathToSuccessorT1ActionStates; 
	
	
	protected T2MutationState(T2MutationStateFactory factory, T2DecisionTree tree) {
		super(factory, tree, factory.model.performSafetyChecks);
	
		if (getModel().performSafetyChecks)
			if (factory.resultsInDeadState())
				throw new IllegalStateException("Creating a dead T2MutationState");

		// Create ArrayLists for the successor states,
		this.successorT2ActionStates = new ArrayList<>();
		this.successorT1FitnessStates = new ArrayList<>();
		this.successorT1ActionStates = new ArrayList<>();

		// If we need to store this T2MutationState to disk in between the forwards and backwards pass:
		// also create the referencedPaths
		if (getModel().saveT2TreesToFile) {
			this.referencePathToSuccessorT1ActionStates = new ArrayList<>();
			this.referencePathToSuccessorT1FitnessStates = new ArrayList<>();

		} else {
			this.referencePathToSuccessorT1ActionStates = null;
			this.referencePathToSuccessorT1FitnessStates = null;
		}

		// Set the name
		//this.setID(this.t2DecisionTree.treeStateList.numberOfMutationStates(this.timeInEncounter));
		this.setName("T2M-" +this.getID()+"-" + timeInEncounter+"-"+ locationPatchState);


	}


	///////////////////////////////////////////////////////////////////////
	//////////////////////// Tree building functions /////////////////////
	/////////////////////////////////////////////////////////////////////
	
	/** Create an MutationStateFactory preset with the same values as in this MutationState*/
	public T2MutationStateFactory toT2MutationStateFactory() {return new T2MutationStateFactory(this);}

	@Override
	public T1AbstractStateFactory toT1EquivalentFactory() {
		return new T1MutationStateFactory(this);
	}

	/** Tells this MutationState to compute all possible successor
	 * states that follow after all mutations have been applied. The new 
	 * T2ActionStates are automatically registered in the T2DecisionTree's
	 * T2StateList. This State is also added as an ancestor state in 
	 * all of its successor states. */
	@Override
	public void doForwardsPass(T2DecisionTree tree) {
		if (wentThroughForwardsPass)
			return;

		// Get the StateMutator to mutate this state, which results in a Pair of ArrayLists containing the resulting
		// T1ActionStates and T1FitnessStates
		Triplet < 
		ArrayList< Path<T2MutationState, T2ActionState>>,  
		ArrayList< Path<T2MutationState, T1FitnessState>>,
		ArrayList< Path<T2MutationState, T1ActionState>>>  resultingPaths = getModel().ledger.stateMutator.mutateT2MutationState(this, tree);

		// If the Model wants us to, perform a safety check to make sure that the origin in all new Paths is indeed this state
		if (getModel().performSafetyChecks) {
			for (Path<T2MutationState, T2ActionState> path : resultingPaths.a)
				if (path.origin != this)
					throw new IllegalStateException("Created a successor state Path for a T2MutationState where the origin in the Path is not this state");
			for (Path<T2MutationState, T1FitnessState> path : resultingPaths.b)
				if (path.origin != this)
					throw new IllegalStateException("Created a successor state Path for a T2MutationState where the origin in the Path is not this state");
			for (Path<T2MutationState, T1ActionState> path : resultingPaths.c)
				if (path.origin != this)
					throw new IllegalStateException("Created a successor state Path for a T2MutationState where the origin in the Path is not this state");
			if (resultingPaths.a.size() + resultingPaths.b.size()+ resultingPaths.c.size() == 0)
				throw new IllegalStateException("Created a T2MutationState without any successors.");
		}
				

		// Where do we store the paths to the successor states?
		// If we do not store the T2DecisionTree to disk between the forwards and backwards pass, we can 
		// immediately set the successor states
		if (!getModel().saveT2TreesToFile) {
			this.successorT2ActionStates.addAll(resultingPaths.a);
			this.successorT1FitnessStates.addAll(resultingPaths.b);
			this.successorT1ActionStates.addAll(resultingPaths.c);
		} 
		// Otherwise, we'll just store a reference to the state. Later on, after we loaded the T2DecisionTree from disk and
		// are reinflating it, we'll change these referencedPaths to actual paths
		else {
			this.successorT2ActionStates.addAll(resultingPaths.a);
			// Create referencedPaths for each path to a T1ActionState
			for ( Path<T2MutationState, T1ActionState> path : resultingPaths.c)
				referencePathToSuccessorT1ActionStates.add(new ReferencedPath<T2MutationState, T1ActionStateReference>(
						path.origin,
						path.destination.toT1StateReference(),
						path.weight,
						path.annotation,
						getModel()));
			
			// Create referencedPaths for each path to a T1FitnessState
			for ( Path<T2MutationState, T1FitnessState> path : resultingPaths.b)
				referencePathToSuccessorT1FitnessStates.add(new ReferencedPath<T2MutationState, T1FitnessStateReference>(
						path.origin,
						path.destination.toT1StateReference(),
						path.weight,
						path.annotation,
						getModel()));

		}
		
		// This node is now expanded
		this.wentThroughForwardsPass= true;
		
	}

	/** Returns all Paths between this state and a successor action state after all mutations have had their consequences,
	 * and the agent is still alive.
	 * 
	 * Any call to this function must be preceded by a call to findPossibleActions() and computeSuccessorStates().
	 * The action integer refers to the place of the action in the Ledger's T2Action array.*/
	public ArrayList<Path<T2MutationState, T2ActionState>> getSuccessorT2ActionPaths() {return successorT2ActionStates;}

	/** Returns all Paths between this state and a successor state after all mutations have had their consequences,
	 * and the agent is dead.
	 * 
	 * Any call to this function must be preceded by a call to findPossibleActions() and computeSuccessorStates().
	 * The action integer refers to the place of the action in the Ledger's T2Action array.*/
	public ArrayList<Path<T2MutationState, T1FitnessState>> getSuccessorT1FitnessPaths() {return successorT1FitnessStates;}

	/** Returns an ArrayList of all T2Action states an agent can be in after this mutation phase. This function is 
	 * used to create the frontier in the T2DecisionTree.*/
	public ArrayList<T2ActionState> getT2AllActionSuccessorStates(){
		ArrayList<T2ActionState> result = new ArrayList<>();

		for (Path<T2MutationState,   T2ActionState> path : this.successorT2ActionStates)
			result.add(path.destination);
		return result;
	}

	/** Computes the expected fitness of entering this T2MutationState. Specifically, 
	 * its computes the expected fitness, the expected age until death, the expected 
	 * phenotype, the expected future T2 actions it will take in this tree, and the 
	 * expected future T1 and T2 actions it will take in the rest of its life.
	 * 
	 * The expected fitness is calculated as:
	 * 		[ SUM over all successor T1FitnessStates fs: fitness(fs) * Pr(fs|s) ] +
	 * 		[ SUM over all successor T2ActionStates  T2as: fitness(T2as) * Pr(T2as|s) ] +
	 * 		[ SUM over all successor T2ActionStates  T1as: fitness(T1as) * Pr(T1as|s) ] 
	 *
	 * Where s is the current state, and Pr(x|s) is the transition probability of 
	 * going to x from s.
	 * 
	 * The expected age and phenotypes are similarly computed as the expected fitness.
	 * 
	 * Note that the expect number of future actions is defined as:
	 * 	 	expectedNumberOfFutureT2ActionsInThisTree = SUM over all successor T2 action states: 
	 * 				expectedFutureT2Actions(state) + immediateAction(state)
	 * 		expectedFutureT2Actions = SUM over all successor T1 + T2 action states: 
	 * 				expectedFutureT2Actions(state) + immediateAction(state)
	 * 		expectedFutureT1Actions = [SUM over all successor action states T1 + T2 states:
	 * 				expectedFutureT2Actions(state) + immediateAction(state)]
	 * 	
	 * */
	@Override
	public void doBackwardsPass(boolean printToConsole) {

		// Keep track of both the weighted sum (which is the fitness), and, for testing purposes, the totalProbability.
		NumberObjectSingle totalProbability = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);

		// Create a temporary storage for all the expected fields, and set all values to 0
		NumberObjectSingle tempExpectedFitness = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle tempExpectedAge = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		NumberObjectSingle tempExpectedTimeDelay = NumberObject.createNumber(getModel().howToRepresentNumbers, 0);
		
		NumberObjectSingle[] tempExpectedPhenotype = new NumberObjectSingle[getModel().ledger.numberOfNonAgePhenotypicDimensions];
		for (int i = 0; i < getModel().ledger.numberOfNonAgePhenotypicDimensions; i++) tempExpectedPhenotype[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT1Actions = new NumberObjectSingle[getModel().ledger.numberOfT1Actions];
		for (int i = 0; i < getModel().ledger.numberOfT1Actions; i++) tempExpectedNumberOfFutureT1Actions[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT2Actions = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];
		for (int i = 0; i < getModel().ledger.numberOfT2Actions; i++) tempExpectedNumberOfFutureT2Actions[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);

		NumberObjectSingle[] tempExpectedNumberOfFutureT2ActionsInThisTree = new NumberObjectSingle[getModel().ledger.numberOfT2Actions];
		for (int i = 0; i < getModel().ledger.numberOfT2Actions; i++) tempExpectedNumberOfFutureT2ActionsInThisTree[i] = NumberObject.createNumber(getModel().howToRepresentNumbers,0);


		// First, for each possible T1Fitness state s' that result from this mutation state:
		// multiply the expectedFitness of s' with the probability of going to s',
		// and add the result to this state's expectedFitness field.
		// Do the same for actions and phenotypes. (Don't have to do it for future actions,
		// as there never are any future actions of T1FitnessStates)
		for (Path<T2MutationState,   T1FitnessState> path : successorT1FitnessStates) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);

			tempExpectedFitness.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
			tempExpectedAge    .add(path.weight.multiply( path.destination.getExpectedAge(),     false), true);
			tempExpectedTimeDelay .add(path.weight.multiply( path.destination.getExpectedTotalTimeStepsInDelay(),     false), true);
			
			for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
				tempExpectedPhenotype[p] .add(path.weight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
		}

		// Second, so the same for all possible T1ActionStates. However, now we also have to keep track of
		// all possible future T1 and T2 actions that an agent will take in its lifetime from this moment on.
		// Note: this includes the action that an agent will take in that action state as well.
		for (Path<T2MutationState,   T1ActionState> path : successorT1ActionStates) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);

			tempExpectedFitness.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
			tempExpectedAge    .add(path.weight.multiply( path.destination.getExpectedAge(),     false), true);
			tempExpectedTimeDelay    .add(path.weight.multiply( path.destination.getExpectedTotalTimeStepsInDelay(),     false), true);
			
			for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
				tempExpectedPhenotype[p].add(path.weight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
			
			for (int t1a = 0 ; t1a < this.getModel().ledger.numberOfT1Actions; t1a ++) {
				// Add all the future actions of the next state (i.e., the actions that an agent will take after that T1ActionState)
				tempExpectedNumberOfFutureT1Actions[t1a].add(path.weight.multiply( path.destination.getFutureTimesItPerformsT1Action(t1a), false), true);
			
				// Add the action taken in the next state as well
				tempExpectedNumberOfFutureT1Actions[t1a].add(path.weight.multiply( path.destination.getProbabilityOfImmediateAction(t1a), false), true);
			}
			
			// And, finally, add all T2Actions an agent expects to take when it is in the successor T1ActionState
			for (int t2a = 0 ; t2a < this.getModel().ledger.numberOfT2Actions; t2a ++)
				tempExpectedNumberOfFutureT2Actions[t2a].add(path.weight.multiply( path.destination.getFutureTimesItPerformsT2Action(t2a), false), true);
		}

		// Third and finally, do the same for all possible T2ActionStates. This is roughly the same as for T1ActionStates,
		// with two exceptions. First, the action immediately taken in the successor state is a T2Action, not a T1Action. And second,
		// we also have to keep track of how often each T2Action is taken in the future while still in the tree (not during the rest
		// of the lifetime)
		for (Path<T2MutationState,   T2ActionState> path : successorT2ActionStates) {
			if (getModel().performSafetyChecks)
				totalProbability.add(path.weight, true);

			tempExpectedFitness.add(path.weight.multiply( path.destination.getExpectedFitness(), false), true);
			tempExpectedAge    .add(path.weight.multiply( path.destination.getExpectedAge(),     false), true);
			tempExpectedTimeDelay    .add(path.weight.multiply( path.destination.getExpectedTotalTimeStepsInDelay(),     false), true);
			
			for (int p = 0 ; p < this.getModel().ledger.numberOfNonAgePhenotypicDimensions; p ++)
				tempExpectedPhenotype[p]                 .add(path.weight.multiply( path.destination.getExpectedPhenotype(p),     false), true);
			for (int t1a = 0 ; t1a < this.getModel().ledger.numberOfT1Actions; t1a ++)
				tempExpectedNumberOfFutureT1Actions[t1a] .add(path.weight.multiply( path.destination.getFutureTimesItPerformsT1Action(t1a), false), true);
			
			for (int t2a = 0 ; t2a < this.getModel().ledger.numberOfT2Actions; t2a ++) {
				// First, add the number of T2 actions that an agent will IN THIS TREE from this moment onwards
				// (i.e., include both the number of times an agent will take an action immediately in the next state,
				// as well as the number of times an agent will take that action in every state in this tree after next state)
				tempExpectedNumberOfFutureT2ActionsInThisTree[t2a] .add(path.weight.multiply( path.destination.getFutureTimesItPerformsT2ActionInThisTree(t2a), false), true);
				tempExpectedNumberOfFutureT2ActionsInThisTree[t2a] .add(path.weight.multiply( path.destination.getProbabilityOfImmediateAction(t2a), false), true);
				
				// Similar for the lifetime T2 actions
				tempExpectedNumberOfFutureT2Actions[t2a] .add(path.weight.multiply( path.destination.getFutureTimesItPerformsT2Action(t2a), false), true);
				tempExpectedNumberOfFutureT2Actions[t2a] .add(path.weight.multiply( path.destination.getProbabilityOfImmediateAction(t2a), false), true);
				
			}
		}

		if (getModel().performSafetyChecks)
			if (!totalProbability.equals(1, true))
				throw new IllegalStateException("T2Mutation state after backwards pass: sum of all paths did not equal 1. "
						+ "\nTotal sum = " + totalProbability.toStringWithoutTrailingZeros() 
						+ "\nThis state: " + this+ 
						". \nT1F successors: " + successorT1FitnessStates.size() +
						". \nT1A successors: " + successorT1ActionStates.size() +
						". \nT2A successors: " + successorT2ActionStates.size());


		// Set the expected fields
		this.setExpectedFitness(tempExpectedFitness);
		this.setExpectedAge(tempExpectedAge);
		this.setExpectedTotalTimeStepsInDelay(tempExpectedTimeDelay);
		this.setExpectedPhenotype(tempExpectedPhenotype);
		this.setExpectedNumberOfFutureT1Actions(tempExpectedNumberOfFutureT1Actions);
		this.setExpectedNumberOfFutureT2Actions(tempExpectedNumberOfFutureT2Actions);
		this.setExpectedNumberOfFutureT2ActionsInThisTree(tempExpectedNumberOfFutureT2ActionsInThisTree);
		

		// And that concludes the backwards pass
		if (getModel().performSafetyChecks)
			this.checkIfBackwardsFieldsAreValid();
		this.wentThroughBackwardsPass = true;

	}


	///////////////////////////////////////////////////////////////
	//////////////////////// Other functions /////////////////////
	/////////////////////////////////////////////////////////////
	
	@Override
	public int hashCode() {
		return T2AbstractState.generateHash(this);
	}


	public String toString() {
		return super.toString("T2MutationState");
	}


	@Override
	public void reinflate(Model model) {
		this.setModel(model);
		// After loading a T2DecisionTree from disk, we need to connect all the references to T1AbstractStates
		// to the T1AbstractStates in the model. Specifically, after the forwards pass we stored ReferencedPaths
		// to successor states, rather than actual Paths. Here we change these ReferencePaths to actual paths.

		// Make sure that all successor states are empty
		if (model.performSafetyChecks) {
			if (this.successorT1ActionStates.size() != 0)
				throw new IllegalStateException("Trying to inflate a T2MutationState that already has T1ActionState successor states");
			if (this.successorT1FitnessStates.size() != 0)
				throw new IllegalStateException("Trying to inflate a T2MutationState that already has T1FitnessState successor states");
		}
		
		// Turn all T1FitnessStateReferences to actual references
		for (ReferencedPath<T2MutationState,   T1FitnessStateReference> refPath : this.referencePathToSuccessorT1FitnessStates) {
			successorT1FitnessStates.add(new Path<T2MutationState, T1FitnessState>(
					refPath.origin,
					model.getT1StateList().toT1FitnessState(refPath.destination),
					refPath.weight,
					refPath.annotation,
					model));
		}

		// Turn all T1ActionStateReferences to actual references
		for (ReferencedPath<T2MutationState,   T1ActionStateReference> refPath : this.referencePathToSuccessorT1ActionStates) {
			successorT1ActionStates.add(new Path<T2MutationState, T1ActionState>(
					refPath.origin,
					model.getT1StateList().toT1ActionState(refPath.destination),
					refPath.weight,
					refPath.annotation,
					model));
		}
		
		// Check if there is at least one successor state
		if (successorT1ActionStates.size() + successorT1FitnessStates.size() + this.successorT2ActionStates.size() ==0)
			throw new IllegalArgumentException("Loaded a state from disk that does not have any successor states.");
		
		this.referencePathToSuccessorT1ActionStates.clear();
		this.referencePathToSuccessorT1FitnessStates.clear();
	}
	
}
