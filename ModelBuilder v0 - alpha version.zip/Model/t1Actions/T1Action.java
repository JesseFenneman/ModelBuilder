package t1Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import actionElements.ActionTemplate;
import actionElements.ActionTemplatePostcondition;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateMovePatch;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateSearch;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateWaitBetween;
import actionElements.ActionTemplatePrecondition;
import actionInterfacesAndAbstractions.ActionPrecondition;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import helper.Helper.Triplet;
import model.Ledger;
import model.LedgerFactory;
import model.Model;
import stateInterfacesAndAbstractions.Path;
import t1states.T1ActionState;
import t1states.T1ActionStateFactory;
import t1states.T1FitnessState;
import t1states.T1FitnessStateFactory;
import t1states.T1MutationState;
import t1states.T1MutationStateFactory;
import t2states.T2MutationStateFactory;


/** A T1Action is an action that an agent can take between encounters.*/
public class T1Action {

	private final Model model;
	private final ArrayList<ActionTemplatePostcondition> postconditionTemplates;
	private final int optionalPatchIndex;
	
	private final ArrayList<ActionPrecondition> preconditions; 
	private final ArrayList<T1ActionPostcondition> postconditions;
	private boolean isComplete; // Did we already set the postconditions?
	private final boolean isSearchAction;
	private final boolean isWaitingAction;
	
	/** Create an action where no postcondition is to move to another patch*/
	public T1Action (ActionTemplate template, LedgerFactory ledgerFactory, Model model) {
		this (template, ledgerFactory, model, -1);
	}
	
	/** Create an action where the postcondition includes a move to the specified patchIndex
	 * If the patchIndex is negative, this action is treated as if there is no MOVE action.
	 * 
	 * Note that this function assumes that all resources, phenotypes, interruptions, delays, and extrinsic events
	 * are already registered in the ledgerFactory, and will not be removed or changed.*/
	public T1Action (ActionTemplate template, LedgerFactory ledgerFactory, Model model, int patchIndex) {
		this.model = model;
		this.isComplete = false;
		this.optionalPatchIndex = patchIndex;

		this.preconditions = new ArrayList<>();
		this.postconditions = new ArrayList<>();

		// Is this a search or waiting action?
		boolean isSearch = false;
		boolean isWait = false;
		for (ActionTemplatePostcondition post : template.getPostconditions())
			if (post.getClass() == PostconditionTemplateSearch.class)
				isSearch = true;
			else if (post.getClass() == PostconditionTemplateWaitBetween.class)
				isWait = true;
		this.isSearchAction=isSearch;
		this.isWaitingAction = isWait;

		// Add all the preconditions
		for (ActionTemplatePrecondition preTemplate : template.getAllPreconditions())
			preconditions.add( ActionPrecondition.createPrecondition(preTemplate, ledgerFactory));

		// Store all the postconditions in their template form for now - once the Ledger is done, we'll create them
		postconditionTemplates = new ArrayList<>();
		postconditionTemplates.addAll(template.getPostconditions());

		// If the patchIndex is not a negative number, then this action is to MOVE
		if (patchIndex >= 0) {
			// First, trust but verify: check if there is indeed a action postcondition for moving
			boolean hasMovePost = false;
			for (ActionTemplatePostcondition post : template.getPostconditions())
				if (post.getClass() == PostconditionTemplateMovePatch.class)
					hasMovePost = true;
			if (!hasMovePost)
				throw new IllegalStateException("When constructing a T1 action, using a MOVE_TO_PATCH constructor for a non-move action");
			
			// Something interesting: an action can be executed only if ALL preconditions are true
			// We want to be able to execute a move_to_destination action if an agent is currently
			// in a patch where it is possible to move to the destination. How do we express this
			// restriction in preconditions? We cannot at something like (current patch == x OR current patch == y),
			// as there are no preconditions that are true if X OR Y is true. However, we can 
			// add a precondition that an agent is NOT in a patch that does NOT have access to the destination!
			Boolean[] canRearchDestinationPatchFromOtherPatch = ledgerFactory.patchIsAccessibleFrom[patchIndex];
			for (int i = 0; i < ledgerFactory.patches.size(); i++) 
				if (!canRearchDestinationPatchFromOtherPatch[i])
					preconditions.add(new ActionPrecondition.ActionPreconditionLocation(i, false));
		}

	}


	/** Returns true if and only if all preconditions are met in this state*/
	public boolean isPossibleInState(T1ActionState state) {
		for (ActionPrecondition precondition: preconditions)
			if (!precondition.stateMatchesPrecondition(state))
				return false;
		return true;	
	}

	/** Returns true iff at least one postcondition is a 'search' action - that is,
	 * if taking this action will result in T2 states */
	public boolean isSearchAction() {
		return isSearchAction;
	}
	/** Returns true iff at least one postcondition is a 'wait' action  */
	public boolean isWaitingAction() {
		return isWaitingAction;
	}

	/** Execute this action in this action state. This function assumes that an action is indeed
	 * possible in this ActionState, and returns a triplet of three ArrayLists containing:  
	 * 
	 * 1. Paths from this state to all T1MutationStates an agent will be in if it survives this action.
	 * These are all the T1States that an agent will end up in after executing this action, including
	 * the probability that an agent ends up in that T1MutationState. Newly created T1 states are 
	 * registered at the T1StateList.
	 * 
	 * 2. Paths from this state to all T1FitnessStates it will go to if this action kills the agent. Newly
	 * created states are registered at the T1StateList.
	 * 
	 * 3. Pairs of T2MutationStateFactories and probabilities. The T2MutationStatesFactories represent all
	 * states an agent will be in if it survives and successfully encounters a resource. Note that each
	 * T2MutationStateFactory created this way will be the root node of a T2DecisionTree. This resulting tree
	 * keeps track of its own States, and hence, will have its own way of turning a T2MutationStateFactory into
	 * a T2MutationState. */
	public Triplet < 
	ArrayList< Path<T1ActionState, T1MutationState>> ,  
	ArrayList< Path<T1ActionState,T1FitnessState>>   ,
	ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>> performAction(T1ActionState state){

		// Step 1. Create the array lists where we will store all temporary T1ActionStateFactories in that will
		// 'give birth' to T1Mutation or T1FitnessStates states later on. 
		// Note that a postconditions both takes and results in ActionStates - that way, postconditions can 
		// be stacked together. At the end we will have to change these ActionStates to either MutationStates or FitnessStates (depending on who died)
		ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>   t1SuccessorActionStateFactories = new ArrayList<>();
		ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>> t2SuccessorMutationStateFactories = new ArrayList<>();

		// Step 2. Add the current state as a SuccessorState with probability 1
		t1SuccessorActionStateFactories.add(new Pair<T1ActionStateFactory, NumberObjectSingle>(state.toT1ActionStateFactory(), NumberObject.createNumber(model.howToRepresentNumbers, 1)));

		// Step 3. Execute all postconditions. Note that some postconditions have to be executed last.
		// Specifically, all search actions (or other future actions that might result in T2ActionStates)
		// have to be executed last. For now, we'll save these postconditions in executeAsLast;
		ArrayList<T1ActionPostcondition> executeAsLast = new ArrayList<>();
		for (T1ActionPostcondition pc : postconditions) 
			if (pc.canResultInT2States()) 
				executeAsLast.add(pc);
			else {
				// Get all T1 successor states after this PC
				Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
				ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>>  resultingStates = pc.getSuccessorStates(t1SuccessorActionStateFactories);
				t1SuccessorActionStateFactories = resultingStates.element1;
			}

		// Execute all saved post conditions
		for (T1ActionPostcondition pc : executeAsLast) {
			Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
			       ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>>  resultingStates = pc.getSuccessorStates(t1SuccessorActionStateFactories);
			t1SuccessorActionStateFactories = resultingStates.element1;
			t2SuccessorMutationStateFactories  = resultingStates.element2;
		}

		// If the model wants us to check everything: makes sure that all possible successor state probabilities sum to 1.
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T1ActionStateFactory, NumberObjectSingle> pair: t1SuccessorActionStateFactories)
				if (pair.element2.smallerThan(0))
					throw new IllegalStateException("Transition to T1 sucessor state after executing all actions has a non-positive probability.");
				else
					sum.add(pair.element2,true);

			for (Pair<T2MutationStateFactory, NumberObjectSingle> pair: t2SuccessorMutationStateFactories )
				if (pair.element2.smallerThan(0))
					throw new IllegalStateException("Transition to T2 sucessor mutation state after executing all actions has a non-positive probability.");
				else
					sum.add(pair.element2, true);

			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability after action does not sum to 1. Sum:" + sum.toStringWithoutTrailingZeros());
		}

		// Step 4. Turn the T1ActionStateFactories to T1MutationStates or T1FitnessState, and link a path from this T1ActionState to those resulting
		// states. At the point, all of the postconditions are applied. Some of the resulting ActionStates are no longer alive.
		// We have to sort out which states are dead and which are alive, and register them at the T1StateList
		ArrayList< Path<T1ActionState, T1MutationState>>  	pathsToT1MutationStates = new ArrayList<>();
		ArrayList< Path<T1ActionState, T1FitnessState>>  	pathsToT1FitnessStates  = new ArrayList<>(); 

		// Step 4a. First, let's create all results from the T1SuccessorStates, and sort them in dead and alive. 
		// We'll also create some paths that link the original state to the new state
		for (Pair<T1ActionStateFactory, NumberObjectSingle> pair: t1SuccessorActionStateFactories) {
			if (pair.element1.resultsInDeadState()) {

				// Create a shallow cloned fitness factory
				T1FitnessStateFactory newFitnessStateFactory = new T1FitnessStateFactory(pair.element1, false);

				// Register (if necessary) that fitness factory at the T1StateList, which will turn it into a T1FitnessState
				T1FitnessState newFitnessState = model.getT1StateList().getFitnessState(newFitnessStateFactory );

				// Add to results
				pathsToT1FitnessStates.add( new Path<T1ActionState, T1FitnessState> (state, newFitnessState, pair.element2, model));
			} else {

				// Create a shallow cloned mutation factory
				T1MutationStateFactory newMutationStateFactory = new T1MutationStateFactory(pair.element1, false);

				// Register (if necessary) that mutation state factory at the T1StateList, which will turn it into a T1MutationState
				T1MutationState newMutationState = model.getT1StateList().getMutationState(newMutationStateFactory);

				// Add to results
				pathsToT1MutationStates.add(new Path<T1ActionState, T1MutationState> ( state, newMutationState, pair.element2, model));
			}
		}


		// Step 4b. Store the resulting T2MutationStateFactories (i.e., the start of new encounters) and their probabilities in separate 
		// Pairs. Note that a T2MutationStateFactory will be used as a root to grown a new T2DecisionTree from. This T2DecisionTree 
		// will maintain its own T2StateList. Hence, we cannot convert the factory to a state just yet - unless, of course, that
		// T2MutationStateFactory will result in a dead state. 
		ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>> notDeadT2SuccessorMutationStateFactories = new ArrayList<>();
		
		for (Pair<T2MutationStateFactory, NumberObjectSingle> pair: t2SuccessorMutationStateFactories) {
			if (pair.element1.resultsInDeadState()) {
				// Create a shallow cloned fitness factory
				T1FitnessStateFactory newFitnessStateFactory = new T1FitnessStateFactory(pair.element1, false);

				// Register (if necessary) that fitness factory at the T1StateList, which will turn it into a T1FitnessState
				T1FitnessState newFitnessState = model.getT1StateList().getFitnessState(newFitnessStateFactory );

				// Add to results
				pathsToT1FitnessStates.add( new Path<T1ActionState, T1FitnessState> (state, newFitnessState, pair.element2, model));
				
			} else {
				// Add to results
				notDeadT2SuccessorMutationStateFactories.add(pair);
			}
		}

		// If the model is strict again, do a test to see if all successor state probabilities sum to 1.
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber (0);
			for (Path<T1ActionState, T1MutationState> p : pathsToT1MutationStates)
				if (p.weight.smallerThan(0))
					throw new IllegalStateException("After action: Transition to successor T1 mutation sucessor state after acting has a non-positive probability.");
				else
					sum.add(p.weight, true);

			for (Path<T1ActionState, T1FitnessState> p : pathsToT1FitnessStates)
				if (p.weight.smallerThanOrEqualTo(0))
					throw new IllegalStateException("After action: Transition to successor T1 fitness sucessor state after acting has a non-positive probability.");
				else
					sum.add(p.weight, true);

			for (Pair<T2MutationStateFactory, NumberObjectSingle> p : notDeadT2SuccessorMutationStateFactories)
				if (p.element2.smallerThanOrEqualTo(0))
					throw new IllegalStateException("After action: Transition to successor T2 mutation state after acting has a non-positive probability. P = " + p.element2);
				else
					sum.add(p.element2, true);

			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability after action does not sum to 1. Sum = " + sum.toStringWithoutTrailingZeros());
		}

		// Create and return the Triplet of results
		Triplet < 
		ArrayList< Path<T1ActionState, T1MutationState>> ,  
		ArrayList< Path<T1ActionState, T1FitnessState>>,
		ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>   > result = new Triplet<>(pathsToT1MutationStates,pathsToT1FitnessStates,notDeadT2SuccessorMutationStateFactories );

		// Return result
		return result;
	}

	/** After ledger construction: create the postconditions */
	public void setPostconditions(Ledger ledger) {

		if (isComplete)
			return;
		for (ActionTemplatePostcondition postTemplate : this.postconditionTemplates) {
			if (postTemplate.getClass() != PostconditionTemplateMovePatch.class) 
				postconditions.add(T1ActionPostcondition.createT1Postcondition(postTemplate, ledger));
			
			else 
				postconditions.add(T1ActionPostcondition.createT1Postcondition(postTemplate, ledger, optionalPatchIndex));
			
		}
		this.isComplete = true;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		for (int i = 0; i < preconditions.size(); i++) {	
			sb.append(preconditions.get(i));
			if (i != (preconditions.size()-1) && preconditions.size() > 1)
				sb.append(" & ");
		}
		sb.append("}  -->  {");

		if (isComplete) {
			for (int i = 0; i < postconditions.size(); i++) {	
				sb.append(postconditions.get(i));
				if (i != (postconditions.size()-1) && postconditions.size() > 1)
					sb.append(" & ");
			}
		} else {
			sb.append("INCOMPLETE");
		}
		sb.append("}");
		return sb.toString();
	}
}
