package t1Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import decimalNumber.DecimalNumber;
import helper.Helper;
import helper.Helper.Pair;
import model.Ledger;
import model.Model;
import t1states.T1ActionStateFactory;
import t2states.T2MutationStateFactory;


/** Moving to a specific patch. Note: this postcondition assumes that an agent is
 * in a patch p, from which the destination patch p' is accessible. Hence, when
 * creating an action with this postcondition, you MUST add a precondition that an 
 * agent is in a patch p that has direct access to p'. Note that during the action
 * phase the age does not yet increase - this is only done during the mutation phase. */
public class T1ActionPostconditionMoveToPatch extends T1ActionPostcondition{
	private final Ledger ledger;
	private final int patchIndex;
	private final Model model;
	protected T1ActionPostconditionMoveToPatch(Model model, Ledger ledger, int patchIndex) {
		this.model = model;
		this.ledger = ledger;
		this.patchIndex = patchIndex;
	}

	@Override
	public Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
    			  ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> currentStates){
		// Create a new ArrayList to store all resulting states in
		ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> successorStates = new ArrayList<>();

		// For each current state s:
		for (Pair<T1ActionStateFactory, NumberObjectSingle> pair: currentStates) {

			// Create a deep cloned factory
			T1ActionStateFactory factoryOriginal = new T1ActionStateFactory(pair.element1, true);
			
			// Figure out which states the new patch p' can be in:
			int[] possibleFuturePatchStates = ledger.patches[patchIndex].ledgerIndicesOfStatesInThisPatch;

			// Figure out what the probabilities of these states in the new patch are
			NumberObjectSingle[] probabilityOfFuturePatchState = ledger.patches[patchIndex].getProbabilityDistributionPatchStateBasedOnT1State(factoryOriginal);

			// If the model says we need to add safety checks: make sure that the probabilities provides do indeed sum to 1
			if (model.performSafetyChecks) {
				if (!NumberObject.createArray(ledger.model.howToRepresentNumbers, probabilityOfFuturePatchState).isProbability())
					throw new IllegalStateException("Probabilities of future states do not sum to 1 or contain negative values. States: " + 
							Helper.arrayToString(possibleFuturePatchStates) + ". Probabilities: " + probabilityOfFuturePatchState);

				// Also, Check if lengths of both arrays match
				if (possibleFuturePatchStates.length != probabilityOfFuturePatchState.length)
					throw new IllegalStateException("Lengths of future state list and probabilities of those states dont match. States: " + 
							Helper.arrayToString(possibleFuturePatchStates) + ". Probabilities: " + probabilityOfFuturePatchState);
			}

			// Create a new successor state for all possible patch states, compute the probability
			// that an agent will end up in that state, and store 
			for (int i = 0; i < possibleFuturePatchStates.length; i++) {
				NumberObjectSingle newProbability = pair.element2.multiply(probabilityOfFuturePatchState[i], false);
				if (probabilityOfFuturePatchState[i].equals(0))
					continue;

				// Create a deep cloned factory that will hold the new state (i.e., the state with the updated location)
				T1ActionStateFactory factorySuccessor = new T1ActionStateFactory(factoryOriginal, true);

				// If we have to be very secure, test if the patchStateIndex actually belongs to the patchState
				if (model.performSafetyChecks)
					if (ledger.patchStateIndexToPatchIndex[possibleFuturePatchStates[i]] != patchIndex)
						throw new IllegalStateException("Patch state [" + possibleFuturePatchStates[i] +"] does not belong in patch [" + patchIndex +"]!");

				// Set the new location in the state, and make sure that the agent now observed the patch to be in that state
				factorySuccessor.setLocation(patchIndex, possibleFuturePatchStates[i])
				.resetTimeSinceLastVisit(patchIndex)
				.setPatchStateInLastVisit(patchIndex, possibleFuturePatchStates[i]);

				// Get the corresponding T1State belonging to the factory, and store in the successorStates
				successorStates.add(new Pair<T1ActionStateFactory, NumberObjectSingle>(factorySuccessor, newProbability));
			}
		}
		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to 1
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Pair<T1ActionStateFactory, NumberObjectSingle> pair: successorStates)
				if (pair.element2.smallerThan(0))
					throw new IllegalStateException("Transition to sucessor state after moving has a non-positive probability.");
				else
					sum.add(pair.element2, true);
			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability distribution does not sum to 1.");
		}

		// Create a new Pair of ArrayLists. The first of which is the successorStates list. 
		// The second list is null - there are no possible T2MutationStates after this postcondition.
		return new Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
  			  ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>>(successorStates, null);
	}

	@Override
	public String toString() {
		return "Move to patch ["+patchIndex+"]";
	}

	@Override
	public boolean canResultInT2States() {
		// TODO Auto-generated method stub
		return false;
	}



}