package t1Actions;

import java.math.RoundingMode;
import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import actionElements.ActionTemplatePostcondition;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateDecreasePhenotype;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateIncreasePhenotype;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateMovePatch;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateSearch;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateSetPhenotype;
import actionElements.ActionTemplatePostcondition.PostconditionTemplateWaitBetween;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import model.Ledger;
import objectiveElements.PhenotypeObjectTemplate;
import t1states.T1ActionStateFactory;
import t2states.T2MutationStateFactory;

/** An T1ActionPostcondition describes the consequences of an action
 * that is possible in a T1State - that is, an action that is possible
 * BETWEEN encounters.
 * 
 * More specifically, it returns a HashMap<State, NumberObjectSingle>
 * that contains which States s' an agent will be in (with the specified
 * probability of ending up in s'), given that it takes an action in its
 * current state. There are 5 different postconditions:
 * 
 * Search (results in T2States)
 * Move to a specific patch (requires a precondition that the patch is accessible)
 * Wait (do nothing)
 * Set phenotype to value
 * Change phenotype by amount (can be both increase or decrease)
 * 
 *  Note: all postconditions check whether a resulting successor state
 *  already exists in the Ledger's T1StateList.  */
public abstract class T1ActionPostcondition {

	
	/** Create a postcondition based on the specified template. Note that in order to create
	 * a MOVE TO PATCH postcondition from a MOVE template, we need additional information: we 
	 * need to know which patch to move to. Using this function to create a MOVE postcondition
	 * results in an IllegalArgumentException - you should use createT1Postcondition(template, ledger, patchIndex) instead! */
	public static T1ActionPostcondition createT1Postcondition (ActionTemplatePostcondition template, Ledger ledger){
		if (!ActionTemplatePostcondition.canUseBetweenEncounters(template.getClass()))
			throw new IllegalArgumentException("Trying to create a T1ActionPostcondition from a non-between-encounter template.");
		
		
		if (template.getClass() == PostconditionTemplateMovePatch.class)
			throw new IllegalStateException("Creating a MOVE postcondition without knowing where to move to.");
		
		if (template.getClass() == PostconditionTemplateSearch.class) {
			return new T1ActionPostconditionSearch(ledger);
		}
		
		if (template.getClass() == PostconditionTemplateWaitBetween.class) {
			return new T1ActionPostconditionWait();
		}
		
		if (template.getClass() == PostconditionTemplateSetPhenotype.class) {
			// Figure out what the phenotype index in the Ledger is
			int phenotypeIndex = ledger.getIndexOfPhenotype( ((PhenotypeObjectTemplate) template.getSubject()).getName()  );
			
			// Figure out what the index position of the new value is
			int valueIndex = ledger.getIndexOfPhenotypeValue(phenotypeIndex, ((DecimalNumber) template.getQualifier()).toNumberObjectSingle(ledger.model.howToRepresentNumbers));
			
			return new T1ActionPostconditionSetPhenotype(ledger, phenotypeIndex, valueIndex);
		}
		
		if (template.getClass() == PostconditionTemplateIncreasePhenotype.class || template.getClass() == PostconditionTemplateDecreasePhenotype.class) {
			// Figure out what the phenotype index in the Ledger is
			int phenotypeIndex = ledger.getIndexOfPhenotype( ((PhenotypeObjectTemplate) template.getSubject()).getName()  );
			
			// Figure out how many index positions the phenotype should increase or decrease
			// Number of index positions = [Value stored in template] / [step size of that phenotype]
			int indexPositionsToIncrease = ((DecimalNumber) template.getQualifier()).divide( ledger.phenotypeStepsize[phenotypeIndex], false).toInt(RoundingMode.UNNECESSARY);
			if (template.getClass() == PostconditionTemplateDecreasePhenotype.class)
				indexPositionsToIncrease=-1*indexPositionsToIncrease;
			
			return new T1ActionPostconditionChangePhenotype(ledger.model, phenotypeIndex, indexPositionsToIncrease);
		}
		
		throw new IllegalStateException("Trying to create action postcondition, but encountered an unknown template type");
		
	}
	
	/** Create a postcondition based on the specified template. Note that in order to create
	 * a MOVE TO PATCH postcondition from a MOVE template, we need additional information: we 
	 * need to know which patch to move to. Hence the optional third argument of this function call.
	 * IMPORTANT: this function assumes that there is a precondition that the patchIndex is accessible
	 * from the current state. This assumption is not always true - unless it is added as a precondition
	 * to the action. Adding this precondition has to be done manually, as it is not part of any ActionTemplatePrecondition. */
	public static T1ActionPostcondition createT1Postcondition (ActionTemplatePostcondition template, Ledger ledger, int patchIndex){
		if (!ActionTemplatePostcondition.canUseBetweenEncounters(template.getClass()))
			throw new IllegalArgumentException("Trying to create a T1ActionPostcondition from a non-between-encounter template.");
		
		if (template.getClass() != PostconditionTemplateMovePatch.class)
			return createT1Postcondition(template, ledger);
		return new T1ActionPostconditionMoveToPatch(ledger.model, ledger, patchIndex);
		
	}
	
	/** Returns true if and only if this postcondition can result in T2 states (i.e., if this is a search action)*/
	public abstract boolean canResultInT2States();
	
	/** 
	 * Each postcondition results in two ArrayLists: 
	 * The first ArrayList contains pairs of successor T1ActionStateFactories and the probability that
	 * an agent will end up in the state created by that factory after executing an action. These 
	 * factories represent all possible action consequences in which the agent does NOT encounter a 
	 * resource. Note: the T1Action itself checks whether these factories give birth to dead states,
	 * and if so, turn the successor T1ActionStateFactory into a T1FitnessStateFactory. The 
	 * T1ActionPostcondition does not have to worry about this.
	 * 
	 * The second ArrayList contains pairs of successor T2MutationStateFactories and the probability that
	 * and agent will end up in the state created by that factory after executing the action. These represent
	 * all possible futures in which an agent both searched and found at least one resource. Just as with
	 * the other ArrayList, the T1Action will check if these T2MutationStates give birth to a dead state. The
	 * T1ActionPostcondition does not have to do this checking itself. Note that only search postconditions
	 * can result in T2MutationStateFactories. This postcondition should be executed as the LAST postcondition.
	 * 
	 * The input currentState is a list similar to the first ArrayList - an ArrayList of paired T1ActionStateFactories
	 * and the probability of that T1ActionStateFactory. Note that, by definition, an action can only be taken in an
	 * ActionState. 
	 * 
	 * You might wonder two things: first, why does the input contain an array of multiple ActionStates, 
	 * rather than a single state, as an action applies to only one state. The reason for this is that Actions 
	 * can have multiple postconditions, which all have to be applied 'at the same time'. 
	 * Suppose that there are 2 Postconditions. After taking an action, first the first postcondition
	 * is applied. This postcondition might result in more than one possible successor states. If so,
	 * the second postcondition has to be applied to all possible states that result from the first
	 * postcondition. Note, these factories have not yet turned into states, and are not registered in the 
	 * T1StateList yet!
	 * 
	 * Second, why does the return contain an arrayList of T1ActionStates, and not T1MutationStates? The answer to that
	 * is similar to the answer above: the output of one postcondition might still have to go through
	 * another postcondition. Hence, we'll leave it to the Action itself to switch an ActionState to a
	 * MutationState.
	 *  */
	public abstract Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
	                       ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> currentStates);

	public abstract String toString();

	
}
