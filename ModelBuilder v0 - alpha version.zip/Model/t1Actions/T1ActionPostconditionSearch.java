package t1Actions;

import java.util.ArrayList;
import java.util.HashMap;

import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import model.Ledger;
import patch.PatchState;
import t1states.T1ActionStateFactory;
import t2states.T2MutationStateFactory;

/** Search for a resource. If a resource is found (which occurs with that resource's frequency
 * in the current patch state of an agent, then the agent moves from a T1State (between encounters) 
 * to a T2State (during an encounter). If no resource is found, the consequence is the same
 * as if an agent waited. 
 * 
 * WARNING: THIS POSTCONDITION RESULTS IN T2 STATES, AND SHOULD ALWAYS BE THE LAST POSTCONDITION 
 * TO BE EXECUTED*/
public class T1ActionPostconditionSearch extends T1ActionPostcondition{

	private final Ledger ledger;
	
	public T1ActionPostconditionSearch (Ledger ledger) {
		this.ledger = ledger;
		
	}
	
	@Override
	public boolean canResultInT2States() {return true;}

	@Override
	public Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
	              ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> currentStates){
		
		// Create the objects where we store the return values in
		ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> resultingT1ActionStateFactories = new ArrayList<>();
		ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>> resultingT2MutationStateFactories = new ArrayList<>();

		for (Pair<T1ActionStateFactory, NumberObjectSingle> currentPair : currentStates) {
			
			// Step 0: figure out the current patch state of the T1ActionStateFactory
			PatchState currentPatchState = ledger.patchStates[currentPair.element1.locationPatchState];
			
			// Step 1: figure out what resources are found after searching.
			// This information is stored in the PatchState. Specifically, in the form of
			// a HashMap that links an ArrayList of Booleans (representing which resources are encountered), 
			// to a probability of encountering that set of resources.
			HashMap<ArrayList<Boolean>, NumberObjectSingle> encounteredResources = currentPatchState.getProbabilityDistributionResourcesWhenSearchingExcludingImpossible();

			// Step 2: return the ActionStateFactory in case that no resource is found 
			// (note: if there is at least one resources type that has a frequency of 1, there will not be an
			// allFalse entry)
			ArrayList<Boolean> allFalse = new ArrayList<>();
			for (int r = 0; r < ledger.numberOfResourceTypes; r++)
				allFalse.add(false);
			NumberObjectSingle probabilityOfAllFalse = encounteredResources.get(allFalse); // can be null!
			if (probabilityOfAllFalse != null)
				resultingT1ActionStateFactories.add(new Pair<>(currentPair.element1, currentPair.element2.multiply(probabilityOfAllFalse ))); 
			encounteredResources.remove(allFalse);
			
			// Step 3: For all other combinations of encounteredResources: 
			// 		a. Create a template T2MutationStateFactory that we will keep cloning
			// 		b. For all observable (and encountered) resources, delays, and interruptions: clone factory for all possible observed value.
			// 		c. Multiply probability of observation with probability of resource encountered combinations, and with the probability of the current state pair
			for (ArrayList<Boolean> onePossibleCombinationOfEncounteredResource: encounteredResources.keySet()) {
				
				// Step 3a.
				T2MutationStateFactory mutationStateFactoryTemplate = new T2MutationStateFactory(ledger.model, currentPair.element1);
				
				// Set the encountered resources 
				for (int r = 0; r <onePossibleCombinationOfEncounteredResource.size() ; r++)
					mutationStateFactoryTemplate.encounteredResourceType[r] = onePossibleCombinationOfEncounteredResource.get(r);
				
				// 3b. Next, figure out how many possible combinations of observable resources, observable delays, and observable interruptions there are
				int totalCombinations = 1;
				for (int r = 0; r < ledger.numberOfResourceTypes; r++)
					if (ledger.resourceIsObservable[r] && onePossibleCombinationOfEncounteredResource.get(r)) 
						totalCombinations = totalCombinations * currentPatchState.numberOfNonZeroProbabilityResourceValues[r];

				for (int d = 0; d < ledger.numberOfDelayTypes; d++)
					if (ledger.delayIsObservable[d])
						totalCombinations = totalCombinations * currentPatchState.numberOfNonZeroProbabilityDelayDurations[d];
				for (int i = 0; i < ledger.numberOfInterruptionTypes; i++)
					if (ledger.interruptionIsObservable[i])
						totalCombinations = totalCombinations * currentPatchState.numberOfNonZeroProbabilityInterruptions[i];


				// Create a HashMap that will store all possible T2MutationStateFactory templates and their probabilities
				HashMap<T2MutationStateFactory, NumberObjectSingle> allFactories = new HashMap<T2MutationStateFactory, NumberObjectSingle>(totalCombinations);

				// Next, we'll iterate over all observable and encountered resources, observable delays, and observable interruptions.
				// Each time, we'll keep a storage of possible MutationStateFactories and their probability. For each observable
				// object, and each possible value of that object, we'll clone all stored factories, set the objects value to that value,
				// and place it back in the store. That way, we should end up with all possible combinations of observable objects.
				
				// First, add the template in the allFactories HashMap
				allFactories.put(mutationStateFactoryTemplate, NumberObject.createNumber(ledger.model.howToRepresentNumbers, 1));
				
				// For each possible observable resource...
				for (int r = 0; r < ledger.numberOfResourceTypes; r++) 
					if (ledger.resourceIsObservable[r] && onePossibleCombinationOfEncounteredResource.get(r)) {
						
						// ... create a temporary storage for MutationStateFactories and their probabilities
						HashMap<T2MutationStateFactory, NumberObjectSingle> tempStorage = new HashMap<T2MutationStateFactory, NumberObjectSingle>();

						// ... then, for each possible value that that resource might take...
						for (int v = 0; v < ledger.resourceValues[r].length; v++) {
							// ... for each factory in allFactories: clone the factory and set the value of resource r to value index v, and add to tempStorage
							// Note: also multiply the probability of the entry with the probability of the resource value.
							for (T2MutationStateFactory fac : allFactories.keySet()) {
								NumberObjectSingle newProbability = allFactories.get(fac).multiply(currentPatchState.resourceValueProbabilities[r][v], false);
								if (newProbability.largerThan(0)) {
									T2MutationStateFactory clone = new T2MutationStateFactory(fac, true);
									clone.valueIndexOfEncounteredObservableResources[r] = v;

									tempStorage.put(clone, newProbability);
								}
							}
						}
						
						// If all went OK, then tempStorage now contains a different mutationFactory for each possible combination of this resource value, and
						// already-iterated-over resources. We now remove all elements in allFactories, and replace them with the tempStorage
						allFactories.clear();
						allFactories.putAll(tempStorage);
					}
				
				// Samesies for all possible observable delays
				for (int d = 0; d < ledger.numberOfDelayTypes; d++) 
					if (ledger.delayIsObservable[d] ) {
						HashMap<T2MutationStateFactory, NumberObjectSingle> tempStorage = new HashMap<T2MutationStateFactory, NumberObjectSingle>();

						for (int duration = 0; duration < ledger.delayValues[d].length; duration++) {
							for (T2MutationStateFactory fac : allFactories.keySet()) {
								NumberObjectSingle newProbability = allFactories.get(fac).multiply(currentPatchState.delayValueProbabilities[d][duration], false);
								T2MutationStateFactory clone = new T2MutationStateFactory(fac, true);
								clone.durationIndexOfEncounteredObservableDelays[d] = duration;
								tempStorage.put(clone, newProbability);
							}
						}
						allFactories.clear();
						allFactories.putAll(tempStorage);
					}
				
				// Slightly different for all possible observable interruptions - as we only have to consider true and false here
				for (int i = 0; i < ledger.numberOfInterruptionTypes; i++) 
					if (ledger.interruptionIsObservable[i] ) {
						HashMap<T2MutationStateFactory, NumberObjectSingle> tempStorage = new HashMap<T2MutationStateFactory, NumberObjectSingle>();

							for (T2MutationStateFactory fac : allFactories.keySet()) {
								// Add all FALSE (index position 0)
								NumberObjectSingle probabilityFalse = allFactories.get(fac).multiply(currentPatchState.interruptionValueProbabilities[i][0], false);
								T2MutationStateFactory cloneFalse = new T2MutationStateFactory(fac, true);
								cloneFalse.willEncounteredObservableInterruptions[i] = false;
								tempStorage.put(cloneFalse, probabilityFalse);
								
								// Add all TRUE (index position 1)
								NumberObjectSingle probabilityTrue = allFactories.get(fac).multiply(currentPatchState.interruptionValueProbabilities[i][1], false);
								T2MutationStateFactory cloneTrue= new T2MutationStateFactory(fac, true);
								cloneTrue.willEncounteredObservableInterruptions[i] = true;
								tempStorage.put(cloneTrue, probabilityTrue);
							}
						// If all went OK, then tempStorage now contains a different mutationFactory for each possible combination of this resource value, and
						// already-iterated-over resources. We now remove all elements in allFactories, and replace them with the tempStorage
						allFactories.clear();
						allFactories.putAll(tempStorage);
					}
				
				// Step 3c. Finally, then, we have all possible T2MutationStateFactories for this set of encountered resources, and their probabilities.
				// But we're not done yet!
				// First, if the Model wants us to do a check, see if all probabilities for these T2MutationStateFactories sum up to 1
				// Also check if we did indeed end up with totalCombinations combinations in allFactories
				if (ledger.model.performSafetyChecks) {
					if (allFactories.size() != totalCombinations)
						throw new IllegalStateException("The number of combinations of T2MutationStateFactories is not the expected value. Expected: " + totalCombinations + ". Observed: " + allFactories.size());
					DecimalNumber sum = new DecimalNumber(0);
					for (T2MutationStateFactory fac : allFactories.keySet())
						if (allFactories.get(fac).smallerThan(0))
							throw new IllegalStateException("At least one T2MutationStateFactory after search has a non-positive probability.");
						else
							sum.add(allFactories.get(fac), true);
					if (!sum.equals(1, true))
						throw new IllegalStateException("Total probability of all possible T2MutationStateFactories after search does not sum to 1.");
				}
				
				// Next, add all factories in allFactories to resultingT2MutationStateFactories. However, the probability of 
				// going from the T1ActionState where we search to the T2MutationStateFactory is not the same as the probability
				// stored in allFactories. We first have to multiple the probability in allFactories with the probability of the
				// set of encounteredResources, and then with the probability of ending up in the currentPair
				for (T2MutationStateFactory fac : allFactories.keySet()) {
					NumberObjectSingle finalProbability = allFactories.get(fac).multiply(encounteredResources.get(onePossibleCombinationOfEncounteredResource), true).multiply(currentPair.element2, true);
					resultingT2MutationStateFactories.add(new Pair<>(fac, finalProbability));
				}
			}
		}
		

		// Return
		return new Pair<>(resultingT1ActionStateFactories, resultingT2MutationStateFactories);
	}


	

	@Override
	public String toString() {
		return "Searching...";				
	}

	
	

}


