package t1Actions;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import helper.Helper.Pair;
import t1states.T1ActionStateFactory;
import t2states.T2MutationStateFactory;

/** Tell an agent to do nothing for one time step. Note that during the action
 * phase the age does not yet increase - this is only done during the mutation phase.
 * As such, this is an 'empty' action. */
public class T1ActionPostconditionWait extends T1ActionPostcondition{
	public T1ActionPostconditionWait() {}

	@Override
	public Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
    			  ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>> getSuccessorStates( ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>> currentStates){
		
		return new Pair < ArrayList< Pair<T1ActionStateFactory, NumberObjectSingle>>,
  			  ArrayList< Pair<T2MutationStateFactory, NumberObjectSingle>>>(currentStates, null);
	}

	@Override
	public String toString() {
		return "Wait";
	}

	@Override
	public boolean canResultInT2States() {return false;}


}

