package mutations;

import java.math.RoundingMode;
import java.util.HashMap;

import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;

import abstractNumberObjectsAndInterfaces.FieldRestriction.RestrictionViolationException;
import abstractNumberObjectsAndInterfaces.NumberObject;
import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import attributes.AttributeField;
import attributes.AttributeField.IncompatibleNumberObjectTypeException;
import decimalNumber.DecimalNumber;
import interfaces_abstractions.ObserverManager;
import model.LedgerFactory;
import model.Model;
import mutationElements.ObjectMutationTemplate;
import mutationElements.ObjectMutationTemplate.Type;
import objectiveElements.DelayObjectTemplate;
import objectiveElements.InterruptionObjectTemplate;
import objectiveElements.ResourceObjectTemplate;
import rIntegration.RFunction.IncompleteCallException;
import rIntegration.RFunctionContainer;
import rIntegration.RFunctionContainer.UnknownArgumentException;

/** After the start of an encounter, there can be extrinsic events that deterministically
 * change the the value of resources, the duration of delays, or the probability of
 * an interruption. These extrinsic events can either change the value or duration with
 * a fixed step size (i.e., each time step the resource might increase with 1 step, and the 
 * duration decrease with 1 step). Alternatively, changes can be in percentages: each time
 * step the resource increases with x percent, the duration decreases with x percent, or the 
 * interruption probability increases with z percent. Note that interruption cannot change with
 * fixed step sizes, only with percentages.
 * 
 * Note that these changes are deterministic. This restriction makes computation much, much easier.
 * If they are deterministic, and agent does not have to keep track of possible changes when
 * sampling cues. That is, it only samples cues about the value, duration, or probability at
 * the start of an encounter. It does not have to consider whether a cue indicates a change of 
 * state. 
 * 
 * This can be made clearer with an example. Suppose an agent starts an encounter by
 * encountering resource A. This resource in the patch state of the agent can either have a value of
 * 1 (with probability 0.5) or a value of 2 (likewise, a probability of 0.5). At time two, the agent
 * sampled 2 times 1 cue. Both cues had a label "CL". The probability of a cue with label CL is
 * 0.25 if the resource had a starting value of 1. The probability of CL was 0.75 if the resource
 * had a value of 2 at the start of the encounter. After updating, the agent now has a posterior belief
 * of (0.1, 0.9) for starting resource value (1,2). Furthermore, it knows that each time in the encounter,
 * the resource value increases with 1 point. Hence, at time 2, when it consumes, it expects the
 * resource to have a value of 1+2 with probability 0.1, and a value of 2+2 with a probability of 0.9.
 * 
 * IMPORTANT: this implies that the emission probability of a cue does not depend on the current value 
 * of a resource - only on the probability at the start of the encounter. The second cue with label CL
 * is not any more likely than the first cue with label CL, even though the current value of the 
 * resource has increased. This is a limitation in the current version of the ModelBuilder software,
 * and might be relaxed later on. 
 * 
 * Anyways, a (the) ObjectMutator object computes the actual value of a resource, delay, or 
 * interruption after the extrinsic events are applied to those objects. It does not deal
 * with the extrinsic events that affect an agent's phenotype, ageing, or changes the state of 
 * patches. 
 * */
public class ObjectMutator {
	
	private final int[][][] resourceMutations; // [resourceIndex] [ time since start encounter ] [value index at start of encounter]  ->  value index after time 
	private final int[][][] delayMutations; //    [delayIndex]    [ time since start encounter ] [value index at start of encounter] [ time since start encounter ] ->  value index after time 
	private final InterruptionHashMap[][] interruptionMutations; // HashMap[interruptionIndex][time in cycle]:   
	
	private String[] resourceMutationNotes; // Something to print to give an indication what this is doing. Debus purposes mostly.
	private String[] delayMutationNotes; // Something to print to give an indication what this is doing. Debus purposes mostly.
	private String[] interruptionMutationNotes; // Something to print to give an indication what this is doing. Debus purposes mostly.
	
	public ObjectMutator(int numberOfResourceTypes, int numberOfDelayTypes, int numberOfInterruptionTypes, int maximumTimeInCycle ){
		this.resourceMutations = new int[numberOfResourceTypes][maximumTimeInCycle][];
		this.delayMutations = new int[numberOfDelayTypes][maximumTimeInCycle][];
		this.interruptionMutations = new InterruptionHashMap[numberOfInterruptionTypes][maximumTimeInCycle];
		
		this.resourceMutationNotes = new String[numberOfResourceTypes];
		this.delayMutationNotes = new String[numberOfDelayTypes];
		this.interruptionMutationNotes = new String[numberOfInterruptionTypes];
	}
	
	/** Registers a possible extrinsic change in a resource, delay, or interruption based on the ObjectMutationTemplate
	 * @throws REXPMismatchException 
	 * @throws REngineException 
	 * @throws UnknownArgumentException 
	 * @throws RestrictionViolationException 
	 * @throws IncompatibleNumberObjectTypeException 
	 * @throws IncompleteCallException */
	public void registerObjectMutation(Model model, LedgerFactory ledgerFactory, ObjectMutationTemplate template)  {
		try {
			if (template.object instanceof ResourceObjectTemplate)
				this.addResourceMutation(model, ledgerFactory, template);
			else if (template.object instanceof DelayObjectTemplate)
				this.addDelayMutation(model, ledgerFactory, template);
			else if (template.object instanceof InterruptionObjectTemplate)
				this.addInterruptionMutation(model, ledgerFactory, template);
			else
				throw new IllegalArgumentException("Trying to create an extrinsic object change event for an object of type " + template.object.getClass().getSimpleName());	
		} catch (Exception e) {
			ObserverManager.notifyObserversOfError(e);
		}
	}
	
	/** Register an ObjectMutationTemplate, where a resource changes in value each time step.
	 * @throws RestrictionViolationException 
	 * @throws UnknownArgumentException 
	 * @throws REXPMismatchException 
	 * @throws REngineException 
	 * @throws IncompatibleNumberObjectTypeException 
	 * @throws IncompleteCallException */
	private void addResourceMutation(Model model, LedgerFactory ledgerFactory, ObjectMutationTemplate template ) throws RestrictionViolationException, UnknownArgumentException, IncompleteCallException, IncompatibleNumberObjectTypeException, REngineException, REXPMismatchException {
		// Find the index of the resource
		int resourceIndex =-1;
		for (int i = 0; i < ledgerFactory.resourceNames.size(); i++)
			if (ledgerFactory.resourceNames.get(i).equals(template.object.getName()))
				resourceIndex = i;
		if (resourceIndex == -1)
			throw new IllegalArgumentException("Resource type with name " + template.object.getName() + " is not registered in the ledger factory (yet).");

		// Create some notes
		this.resourceMutationNotes[resourceIndex] = "Type: " + template.type+ ". Value: " + template.value + ". RFunction: " + template.rFunction;
		
		// Ask the ledgerFactory what values are possible for this resource
		NumberObjectSingle[] possibleValues = ledgerFactory.resourceValues.get(resourceIndex);
		
		// Create an integer array in resourceMutations for all [resourceIndex][time step]
		for (int t = 0; t < model.maximumStepsInEncounter; t++) {
			
			// Create an integer array in resourceMutations at [resourceIndex][time step]
			resourceMutations[resourceIndex][t] = new int[possibleValues.length];
			
			// Is the change fixed? If so, then we only have to shift the array values with n positions,
			// where n is the number of step sizes the change will be.
			if (template.type == ObjectMutationTemplate.Type.CONSTANT) {
				// How many step sizes is the change?
				int stepSizeChange = template.value.divide(ledgerFactory.resourceStepsize.get(resourceIndex), false).toInt(RoundingMode.UNNECESSARY);
				
				// Change all the array position. Specifically, the index position of the new resource value is the index position at the start
				// of the encounter + stepSizeChange (which can be negative). Make sure that the array is within bounds
				for (int valueIndex = 0;  valueIndex < possibleValues.length; valueIndex++) {
					int newValueIndex = valueIndex + stepSizeChange*t;
					if (newValueIndex < 0)
						newValueIndex = 0;
					else if (newValueIndex > possibleValues.length-1)
						newValueIndex = possibleValues.length-1;
					resourceMutations[resourceIndex][t][valueIndex] = newValueIndex;
				}
			}
			
			// Is the change a percentage point of the starting value?
			else if (template.type == ObjectMutationTemplate.Type.PERCENTAGE) {
				// If so, we have to find the NumberObjectSingle value at each valueIndex,
				// 	and multiple that value with the increase in percentage. Note that
				// percentages are cumulative: if x is the percentage growth, the 
				// value after n time steps is:
				//  valueNew = valueOld * (1+percentage)^t
				
				// First, compute the growth rate
				NumberObjectSingle growthRate = NumberObject.createNumber(model.howToRepresentNumbers, 1);
				growthRate.add(template.value.divide(100, false),true).pow(t, true);
	
				for (int valueIndex = 0;  valueIndex < possibleValues.length; valueIndex++) {

					// Compute new value
					NumberObjectSingle newValue = possibleValues[valueIndex].multiply(growthRate, false);
						
					// Compute the difference between the new value and the old value
					NumberObjectSingle difference = newValue.subtract(possibleValues[valueIndex], true);
			
					// Round the difference to nearest step size
					NumberObjectSingle nearestStepSize = difference.roundToNearest(ledgerFactory.resourceStepsize.get(resourceIndex), RoundingMode.HALF_UP, false);
				
					// How many step sizes is that?
					int stepSizesShift = nearestStepSize.divide(ledgerFactory.resourceStepsize.get(resourceIndex), true).toInt(RoundingMode.UNNECESSARY);
			
					// Compute newValueIndex, which is the old index position + the shift in the index position
					int newValueIndex = valueIndex + stepSizesShift;
					
					// Make sure that newValueIndex is in bounds, and store
					if (newValueIndex < 0)
						newValueIndex = 0;
					else if (newValueIndex > possibleValues.length-1)
						newValueIndex = possibleValues.length-1;
				
					resourceMutations[resourceIndex][t][valueIndex] = newValueIndex;
				}
			}
			
			// Should it grow linearly until it doubles at a certain time?
			else if (template.type == ObjectMutationTemplate.Type.DOUBLE_LINEAR) {
				
				for (int valueIndex = 0;  valueIndex < possibleValues.length; valueIndex++) {
				// First, what is the growth rate? 
				// The growth rate depends on the number of time steps it takes before the resource doubles 
				NumberObjectSingle timeStepsToDouble = template.value;
				
				// Each time step the resource with value RV should increase with RV/timeStepsToDouble (this works for both positive and negative values)
				NumberObjectSingle valueChangeEachTimeStep = possibleValues[valueIndex].divide(timeStepsToDouble, false);
				
				// Multiple that change with the number of time steps
				NumberObjectSingle valueChange = valueChangeEachTimeStep.multiply(t, true);
				
				// Round to nearest step size
				NumberObjectSingle nearestStepSize = valueChange.roundToNearest(ledgerFactory.resourceStepsize.get(resourceIndex), RoundingMode.HALF_UP, false);
				
				// How many step sizes is that?
				int stepSizesShift = nearestStepSize.divide(ledgerFactory.resourceStepsize.get(resourceIndex), true).toInt(RoundingMode.UNNECESSARY);
				
				// Compute newValueIndex
				int newValueIndex = valueIndex + stepSizesShift;
				
				// Make sure that newValueIndex is in bounds, and store
				if (newValueIndex < 0)
					newValueIndex = 0;
				else if (newValueIndex > possibleValues.length-1)
					newValueIndex = possibleValues.length-1;
				
				resourceMutations[resourceIndex][t][valueIndex] = newValueIndex;
				}
			}
			
			// Or finally, should we use an RFunction?
			else if (template.type == ObjectMutationTemplate.Type.RFUNCTION) {
				// An OBJECTMUTATION RFunction for a resource has five required parameters:
				// 1. The value at the start of the encounter
				// 2. The number of time steps since the start
				// 3. The minimum value of the object
				// 4. The maximum value of the object
				// 5. The increment or stepsize of the object's value
				// We'll have to create attributeFields for all of these parameters
				// However, only the first parameter, the valueParameter, changes over object values
				AttributeField timeParameter = new AttributeField("time", NumberObject.createNumber(model.howToRepresentNumbers,t));
				AttributeField minimumValueParameter = new AttributeField("minimumValue", template.object.getDomainMinimum());
				AttributeField maximumValueParameter = new AttributeField("maximumValue", template.object.getDomainMaximum());
				AttributeField stepsizeValueParameter = new AttributeField("stepsizeValue", template.object.getDomainStepSize());
				
				// Build a RFunctionContainer based on the RFunction. We'll store the RFunctionContainer an all
				// AttributeFields in here, and changes only the value parameter between object values
				RFunctionContainer rfc = new RFunctionContainer(template.rFunction , timeParameter, minimumValueParameter, maximumValueParameter, stepsizeValueParameter);
				
				for (int valueIndex = 0;  valueIndex < possibleValues.length; valueIndex++) {
					// Set the value parameter
					rfc.replaceOrAddArgument(new AttributeField("value", possibleValues[valueIndex]));
					
					// Run in R
					NumberObjectSingle newValue = (NumberObjectSingle) rfc.runInR()[0];
					
					// Round to nearest step size
					NumberObjectSingle nearestStepSize = newValue.roundToNearest(ledgerFactory.resourceStepsize.get(resourceIndex), RoundingMode.HALF_UP, false);
					
					// How many step sizes is that?
					int stepSizesShift = nearestStepSize.divide(ledgerFactory.resourceStepsize.get(resourceIndex), true).toInt(RoundingMode.UNNECESSARY);
					
					// Compute newValueIndex
					int newValueIndex = valueIndex + stepSizesShift;
					
					// Make sure that newValueIndex is in bounds, and store
					if (newValueIndex < 0)
						newValueIndex = 0;
					else if (newValueIndex > possibleValues.length-1)
						newValueIndex = possibleValues.length-1;
					
					resourceMutations[resourceIndex][t][valueIndex] = newValueIndex;	
				}
			} else 
				throw new IllegalStateException("Unkown bject mutation template type.");
		}
	}
	
	/** Register an ObjectMutationTemplate, where a delay changes in duration each time step.
	 * @throws UnknownArgumentException 
	 * @throws RestrictionViolationException 
	 * @throws IncompatibleNumberObjectTypeException 
	 * @throws REXPMismatchException 
	 * @throws REngineException 
	 * @throws IncompleteCallException */
	private void addDelayMutation(Model model, LedgerFactory ledgerFactory, ObjectMutationTemplate template ) throws IncompatibleNumberObjectTypeException, RestrictionViolationException, UnknownArgumentException, IncompleteCallException, REngineException, REXPMismatchException {
		// Find the index of the delay
		int delayIndex =-1;
		for (int i = 0; i < ledgerFactory.delayNames.size(); i++)
			if (ledgerFactory.delayNames.get(i).equals(template.object.getName()))
				delayIndex = i;
		if (delayIndex == -1)
			throw new IllegalArgumentException("Delay type with name " + template.object.getName() + " is not registered in the ledger factory (yet).");

		// Create some notes
		this.delayMutationNotes[delayIndex] = "Type: " + template.type+ ". Value: " + template.value.toStringWithoutTrailingZeros() + ". RFunction: " + template.rFunction;


		// Ask the ledgerFactory what values are possible for this delay
		Integer[] possibleDurations = ledgerFactory.delayValues.get(delayIndex);
		
		// Create an integer array in resourceMutations for all [resourceIndex][time step]
		for (int t = 0; t < model.maximumStepsInEncounter; t++) {
			
			// Create an integer array in delayMutations at [delayIndex][time step]
			delayMutations[delayIndex][t] = new int[possibleDurations.length];
			
			// Is the change fixed? If so, then we only have to shift the array values with n positions,
			// where n is the number of step sizes the change will be.
			if (template.type== ObjectMutationTemplate.Type.CONSTANT) {
				// How many step sizes is the change?
				int stepSizeChange = template.value.divide(ledgerFactory.delayStepsize.get(delayIndex), false).toInt(RoundingMode.UNNECESSARY);
				
				// Change all the array positition. Specifically, the index position of the new delay duration is the index position at the start
				// of the encounter + stepSizeChange (which can be negative). Make sure that the array is within bounds
				for (int valueIndex = 0;  valueIndex < possibleDurations.length; valueIndex++) {
					int newValueIndex = valueIndex + stepSizeChange;
					if (newValueIndex < 0)
						newValueIndex = 0;
					else if (newValueIndex > possibleDurations.length-1)
						newValueIndex = possibleDurations.length-1;
					delayMutations[delayIndex][t][valueIndex] = newValueIndex;
				}
			}
			
			else if (template.type == ObjectMutationTemplate.Type.PERCENTAGE) {
				// If so, we have to find the NumberObjectSingle value at each valueIndex,
				// 	and multiple that value with the increase in percentage. Note that
				//  percentages are cumulative: if x is the percentage growth, the 
				//  delay after n time steps is:
				//  dlayNew = delayOld * (1+percentage)^t
				
				// First, compute the growth rate
				NumberObjectSingle growthRate = NumberObject.createNumber(model.howToRepresentNumbers, 1);
				growthRate.add(template.value.divide(100, false),true).pow(t, true);
	
				for (int durationIndex = 0;  durationIndex < possibleDurations.length; durationIndex++) {

					// Compute the new duration
					NumberObjectSingle newDuration = NumberObject.createNumber(model.howToRepresentNumbers, possibleDurations[durationIndex]).multiply(growthRate, false);
						
					// Compute the difference between the new duration and the old duration
					NumberObjectSingle difference = newDuration.subtract(possibleDurations[durationIndex], true);
			
					// Round the difference to nearest step size
					NumberObjectSingle nearestStepSize = difference.roundToNearest(NumberObject.createNumber(model.howToRepresentNumbers, ledgerFactory.delayStepsize.get(delayIndex)), RoundingMode.HALF_UP, false);
				
					// How many step sizes is that?
					int stepSizesShift = nearestStepSize.divide(ledgerFactory.delayStepsize.get(delayIndex), true).toInt(RoundingMode.UNNECESSARY);
			
					// Compute newDurationIndex, which is the old index position + the shift in the index position
					int newDurationIndex = durationIndex + stepSizesShift;
					
					// Make sure that newValueIndex is in bounds, and store
					if (newDurationIndex < 0)
						newDurationIndex = 0;
					else if (newDurationIndex > possibleDurations.length-1)
						newDurationIndex = possibleDurations.length-1;
				
					delayMutations[delayIndex][t][durationIndex] = newDurationIndex;
				}
			}	
			
			// Should it grow linearly until it doubles at a certain time?
			else if (template.type == ObjectMutationTemplate.Type.DOUBLE_LINEAR) {
				
				for (int valueIndex = 0;  valueIndex < possibleDurations.length; valueIndex++) {
				// First, what is the growth rate? 
				// The growth rate depends on the number of time steps it takes before the duration doubles 
				NumberObjectSingle timeStepsToDouble = template.value;
				
				// Each time step the duration with value D should increase with D/timeStepsToDouble (this works for both positive and negative values)
				NumberObjectSingle valueChangeEachTimeStep = NumberObject.createNumber(model.howToRepresentNumbers, possibleDurations[valueIndex]).divide(timeStepsToDouble, true);
				
				// Multiple that change with the number of time steps
				NumberObjectSingle valueChange = valueChangeEachTimeStep.multiply(t, true);
			
				// Round to nearest step size
				NumberObjectSingle nearestStepSize = valueChange.roundToNearest( NumberObject.createNumber(model.howToRepresentNumbers,ledgerFactory.delayStepsize.get(delayIndex)), RoundingMode.HALF_UP, false);
				
				// How many step sizes is that?
				int stepSizesShift = nearestStepSize.divide(ledgerFactory.delayStepsize.get(delayIndex), true).toInt(RoundingMode.UNNECESSARY);
				
				// Compute newValueIndex
				int newValueIndex = valueIndex + stepSizesShift;
				
				// Make sure that newValueIndex is in bounds, and store
				if (newValueIndex < 0)
					newValueIndex = 0;
				else if (newValueIndex > possibleDurations.length-1)
					newValueIndex = possibleDurations.length-1;
				
				delayMutations[delayIndex][t][valueIndex] = newValueIndex;
				}
			}
			
			// Or finally, should we use an RFunction?
			else if (template.type == ObjectMutationTemplate.Type.RFUNCTION) {
				// An OBJECTMUTATION RFunction for a delay has five required parameters:
				// 1. The value at the start of the encounter
				// 2. The number of time steps since the start
				// 3. The minimum value of the object
				// 4. The maximum value of the object
				// 5. The increment or stepsize of the object's value 
				// We'll have to create attributeFields for all of these parameters
				// However, only the first parameter, the valueParameter, changes over object values
				AttributeField timeParameter = new AttributeField("time", NumberObject.createNumber(model.howToRepresentNumbers,t));
				AttributeField minimumValueParameter = new AttributeField("minimumValue", template.object.getDomainMinimum());
				AttributeField maximumValueParameter = new AttributeField("maximumValue", template.object.getDomainMaximum());
				AttributeField stepsizeValueParameter = new AttributeField("stepsizeValue", template.object.getDomainStepSize());
				
				// Build a RFunctionContainer based on the RFunction. We'll store the RFunctionContainer an all
				// AttributeFields in here, and changes only the value parameter between object values
				RFunctionContainer rfc = new RFunctionContainer(template.rFunction , timeParameter, minimumValueParameter, maximumValueParameter, stepsizeValueParameter)
						;
				for (int valueIndex = 0;  valueIndex < possibleDurations.length; valueIndex++) {
					// Set the value parameter
					rfc.replaceOrAddArgument(new AttributeField("value",  NumberObject.createNumber(model.howToRepresentNumbers,possibleDurations[valueIndex])));
					
					// Run in R
					NumberObjectSingle newValue = (NumberObjectSingle) rfc.runInR()[0];
					
					// Round to nearest step size
					NumberObjectSingle nearestStepSize = newValue.roundToNearest( NumberObject.createNumber(model.howToRepresentNumbers,ledgerFactory.delayStepsize.get(delayIndex)), RoundingMode.HALF_UP, false);
					
					// How many step sizes is that?
					int stepSizesShift = nearestStepSize.divide(ledgerFactory.delayStepsize.get(delayIndex), true).toInt(RoundingMode.UNNECESSARY);
					
					// Compute newValueIndex
					int newValueIndex = valueIndex + stepSizesShift;
					
					// Make sure that newValueIndex is in bounds, and store
					if (newValueIndex < 0)
						newValueIndex = 0;
					else if (newValueIndex > possibleDurations.length-1)
						newValueIndex = possibleDurations.length-1;
					
					delayMutations[delayIndex][t][valueIndex] = newValueIndex;	
				}
			} else 
				throw new IllegalStateException("Unkown bject mutation template type.");
		}
	}

	/** Register an ObjectMutationTemplate, where an interruption changes in probability each time step. Note, in contrast to 
	 * resources and delays, interruptions are not precomputed. However, each time a probability-of-interruption-after-time is computed,
	 * the map between the starting probability and the probability after x units of time is stored in a HashMap. */
	private void addInterruptionMutation(Model model, LedgerFactory ledgerFactory, ObjectMutationTemplate template) {
		// Find the index of the interruption
		int interruptionIndex =-1;
		for (int i = 0; i < ledgerFactory.interruptionNames.size(); i++)
			if (ledgerFactory.interruptionNames.get(i).equals(template.object.getName()))
				interruptionIndex = i;
		if (interruptionIndex == -1)
			throw new IllegalArgumentException("Interruption type with name " + template.object.getName() + " is not registered in the ledger factory (yet).");

		// Create some notes
		this.interruptionMutationNotes[interruptionIndex] = "Type: " + template.type+ ". Value: " + template.value.toStringWithoutTrailingZeros() + ". RFunction: " + template.rFunction;


		this.interruptionMutations[interruptionIndex] = new InterruptionHashMap[model.maximumStepsInEncounter];
		for (int t = 0; t < model.maximumStepsInEncounter; t++)
			this.interruptionMutations[interruptionIndex][t] = new InterruptionHashMap( template, model, ledgerFactory, t);
	}
	
	
	/** If there is no extrinsic event that changes the resource value, this function returns valueIndexWhenStartingEncounter.
	 * However, if there are extrinsic events that determinstically change the resource value, either by fixed increments or in percentage increments,
	 * this function returns the index of the value of the resource after timeStepsInEncounter. */
	public int getValueOfResourceAfterTime(int resourceIndex, int valueIndexWhenStartingEncounter, int timeStepsInEncounter) {
		// Check if there is an extrinsic event registered - i.e., if resourceMutations[resourceIndex] is not null
		// If it is, return the resourceIndex at the start of the encounter (the resource value could not have changed in between then and now)
		// (Side note: the resourceMutations always has a an array at all indices. But these arrays can be null)
		if (resourceMutations[resourceIndex][timeStepsInEncounter] == null)
			return valueIndexWhenStartingEncounter;
		
		// Otherwise, retrieve the new valueIndex from resourceMutations for this interruption and for this time
		return resourceMutations[resourceIndex][timeStepsInEncounter][valueIndexWhenStartingEncounter];
	}
	
	/** If there is no extrinsic event that changes the delay duration, this function returns valueIndexWhenStartingEncounter.
	 * However, if there are extrinsic events that determinstically change the duration of the delay, either by fixed increments or in percentage increments,
	 * this function returns the index of the value of the delay after timeStepsInEncounter. */
	public int getDurationOfDelayAfterTime(int delayIndex, int valueIndexWhenStartingEncounter, int timeStepsInEncounter) {
		// Check if there is an extrinsic event registered - i.e., if delayMutations[delayIndex] is not null
		// If it is, return the delayIndex at the start of the encounter (the delay duration could not have changed in between then and now)
		// (Side note: the delayMutations always has a an array at all indices. But these arrays can be null)
		if (delayMutations[delayIndex][timeStepsInEncounter] == null)
			return valueIndexWhenStartingEncounter;
		
		// Otherwise, retrieve the new valueIndex from resourceMutations for this interruption and for this time
		return delayMutations[delayIndex][timeStepsInEncounter][valueIndexWhenStartingEncounter];
	}
	
	/** If there is no extrinsic event that changes the interruption probability, this function returns interruptionProbabilityAtStartEncounter.
	 * However, if there are extrinsic events that determinstically change the interruption, either by fixed increments or in percentage increments,
	 * this function returns the probability of the interruption after timeStepsInEncounter. */
	public NumberObjectSingle getProbabilityOfInterruptionAfterTime(int interruptionIndex, NumberObjectSingle interruptionProbabilityAtStartEncounter, int timeStepsInEncounter) {
		// Check if there is an extrinsic event registered - i.e., if interruptionMutations[interruptionIndex][timeStepsInEncounter]  is not null.
		// If it is, return the interruptionProbability at the start of the encounter (it could not have changed in between then and now)
		// (Side note: the interruptionMutations always has a an array at all indices. But these arrays can be null)
		if (interruptionMutations[interruptionIndex][timeStepsInEncounter] == null)
			return interruptionProbabilityAtStartEncounter;
		
	
		// Otherwise, retrieve the new probability from the InterruptionHashMap for this interruption and for this time
		try {
			return interruptionMutations[interruptionIndex][timeStepsInEncounter].getProbabilityAfterTime(interruptionProbabilityAtStartEncounter);
		} catch (IncompatibleNumberObjectTypeException | IncompleteCallException | RestrictionViolationException
				| UnknownArgumentException | REngineException | REXPMismatchException e) {
			ObserverManager.notifyObserversOfError(e);
			throw new IllegalStateException("Stopped after R error");
		}
		
	}
	
	
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("\nChanges in RESOURCE value during encounter:");
		for (int r = 0; r < resourceMutations.length; r++) {
			sb.append("\n\tResource ["+r+"]:");
			if (resourceMutations[r][0] == null) sb.append("\tNo mutation for this resource");
			else {
				for (int t = 0; t < resourceMutations[r].length; t++) {
					sb.append("\n\t\tAfter " + t + " time steps: ");
					for (int v = 0; v < resourceMutations[r][t].length;v++)
							sb.append("\n\t\t\t"+v + "\t->\t"+resourceMutations[r][t][v]);
				}
				sb.append("\n(Notes: " + resourceMutationNotes[r] + ")");
			}
		}
		
		sb.append("\n\nChanges in DELAY durations during encounter:");
		for (int d = 0; d < delayMutations.length; d++) {
			sb.append("\n\tDelay["+d+"]:");
			if (delayMutations[d][0] == null) sb.append("\tNo mutation for this delay");
			else {
				for (int t = 0; t < delayMutations[d].length; t++) {
					sb.append("\n\t\tAfter " + t + " time steps: ");
					for (int v = 0; v < delayMutations[d][t].length;v++)
							sb.append("\n\t\t\t"+v + "\t->\t"+delayMutations[d][t][v]);
				}
				sb.append("\n(Notes: " + delayMutationNotes[d]+ ")");
			}
		}
		
		sb.append("\n\nChanges in INTERRUPTION probability during encounter:");
		for (int i = 0; i < interruptionMutations.length; i++) {
			sb.append("\n\tInterruption ["+i+"]:");
			if (this.interruptionMutationNotes[i] == null) sb.append("\tNo mutation for this interruption");
			else sb.append("There is a mutation set for this interruption. However, interruption mutations are computed lazily. Here are some notes: " + interruptionMutationNotes[i]);
		}
		return sb.toString();
	}

	// An interruptionHashMap is essentially a Map that takes the current estimate that an agent has about
	// the probability of an interruption at the start of the encounter, and provides the probability
	// of an interruption after t moments of time. However, in contrast to resource values and delay
	// durations, interruption probabilities do not come in nice step sizes; rather, every probability
	// is possible - or rather, many probabilities are possible, considering all possible priors and
	// all possible cue sets. Hence, rather than precomputing all possible values, we have to compute
	// the probability of an interruption for all cue set, for all prior, and for all states...
	//
	// ... or do we? In the end, what we want to know is, given that the interruption occurs with a probability
	// p at the start of the encounter, how likely is it after t time steps during the encounter? If we know
	// the starting probability, we really do not care about the cue sets or states anymore. Hence, here is a 
	// slightly better solution than always computing it on the fly: we store all results. Hence, the first
	// time we ask for the probability p' given p and t, we compute it. Afterwards, we store it somewhere, and
	// the next time we need it, we do not have to compute it anymore. Specifically, we store the result in a HashMap,
	// that maps the best estimate of the probability at time 0, and maps it to the probability after t times. We create
	// separate HashMaps for all possible times steps t.
	// These HashMaps do:   p(interruption) at start encounter] -> [p(interruption after n cycles] (there
	// should be unique InterruptionHashMaps for each interruption type and each time in cycle.
	private class InterruptionHashMap {
		
		private final HashMap<NumberObjectSingle, NumberObjectSingle> map;
		private final Model model;
		// does the interruption increase with x percent point (e.g., 10% increase means:  p=0.1 to p=0.2 to p=0.3), or
		// is the change relative to the value? (e.g. 10% increase means: p=0.1 to p=0.11 to p=0,121), or increase
		// linearly until it doubles, or is given by some RFunction?
		private ObjectMutationTemplate.Type type;
		
		private final NumberObjectSingle changeValue;
		private final RFunctionContainer objectMutationRFunctionContainer;
		
		// Each InterruptionMap contains mappings for one particular time step
		private final int timeStepsInEncounter;
		
		public InterruptionHashMap(ObjectMutationTemplate template, Model model, LedgerFactory ledgerFactory, int timeStepsInEncounter) {
			try {
				this.map = new HashMap<>();
				this.model = model;
				this.timeStepsInEncounter = timeStepsInEncounter;
				this.type = template.type;

				if (type == Type.CONSTANT || type == Type.PERCENTAGE || type == Type.DOUBLE_LINEAR) {
					changeValue = template.value.toNumberObjectSingle(model.howToRepresentNumbers);
					objectMutationRFunctionContainer = null;
				}
				else if (type == Type.RFUNCTION) {
					changeValue = null;
					// An OBJECTMUTATION RFunction for an interruption has four required parameters:
					// 1. The value at the start of the encounter
					// 2. The number of time steps since the start
					// 3. The minimum value of the object
					// 4. The maximum value of the object

					// The template specifies an RFunction. To avoid unnecessary computations, we'll create
					// a RFunctionContainer that comes preloaded with arguments 2 to 4
					AttributeField timeParameter = new AttributeField("time", NumberObject.createNumber(model.howToRepresentNumbers,timeStepsInEncounter));
					AttributeField minimumValueParameter = new AttributeField("minimumValue", new DecimalNumber(0));
					AttributeField maximumValueParameter = new AttributeField("maximumValue", template.object.getDomainMaximum());

					// Build a RFunctionContainer based on the RFunction. We'll store the RFunctionContainer an all
					// AttributeFields in here, and changes only the value parameter between object values
					objectMutationRFunctionContainer = new RFunctionContainer(template.rFunction , timeParameter, minimumValueParameter, maximumValueParameter);
				} else
					throw new IllegalStateException("Type not recognized: "+ type);
			} catch (Exception e) { ObserverManager.notifyObserversOfError(e); throw new IllegalStateException("Stopped after R error");}

		}
		
		/** Returns the new probability of the interruption, given the probability of the interruption at
		 * the start of the encounter, and the number of times this extrinsic event has changed this 
		 * probability. The number of times is set when creating the InterruptionHasMap. 
		 *  Retrieves precomputed values if possible, and stores newly computed values if
		 * no such value exists yet.
		 * @throws REXPMismatchException 
		 * @throws REngineException 
		 * @throws UnknownArgumentException 
		 * @throws RestrictionViolationException 
		 * @throws IncompleteCallException 
		 * @throws IncompatibleNumberObjectTypeException */
		public NumberObjectSingle getProbabilityAfterTime(NumberObjectSingle startingValue) throws IncompatibleNumberObjectTypeException, IncompleteCallException, RestrictionViolationException, UnknownArgumentException, REngineException, REXPMismatchException {
			NumberObjectSingle result = map.get(startingValue);
			if (result != null)
				return result;
			
			result = computeProbabilityAfterTime(startingValue );
			map.put(startingValue, result);
			return result;
		}
		
		/** Given a probability of the interruption at the start of the encounter, 
		 * compute the probability after t time steps in the present encounter. The new value is
		 * set to be immutable. 
		 * @throws UnknownArgumentException 
		 * @throws RestrictionViolationException 
		 * @throws IncompatibleNumberObjectTypeException 
		 * @throws REXPMismatchException 
		 * @throws REngineException 
		 * @throws IncompleteCallException */
		private NumberObjectSingle computeProbabilityAfterTime (NumberObjectSingle startingValue) throws IncompatibleNumberObjectTypeException, RestrictionViolationException, UnknownArgumentException, IncompleteCallException, REngineException, REXPMismatchException {
			 
			// In case the value changes with a CONSTANT increase 
			if (type == Type.CONSTANT) {
				// Calculate how many percentage points we have to increase the probability
				NumberObjectSingle increase = changeValue.multiply(timeStepsInEncounter, false);
				
				// Add increase to the startingValue (store the result in increase to save on computations)
				increase.add(startingValue, true);
				
				// Make sure that the new value (now stored in increase) is between 0 and 1
				// Make sure that the new value is between 0 and 1
				if (increase.smallerThan(0))
					increase.set(0);
				else if (increase.largerThan(1))
					increase.set(1);
				
				// Make immutable and return.
				increase.makeImmutable();
				return increase;
				

			} else if (type == Type.PERCENTAGE){	
				// If each time step the probability increases by a PERCENTAGE
				// If so: compute the cumulative growth rate:
				NumberObjectSingle growthRate = NumberObject.createNumber(model.howToRepresentNumbers, 1);
				growthRate.add(changeValue.divide(100, false),true).pow(timeStepsInEncounter, true);
				
				// The new value = oldValue * growthRate (store it in growthRate)
				growthRate.multiply(startingValue, true);
				
				// Make sure that the new value is between 0 and 1
				if (growthRate.smallerThan(0))
					growthRate.set(0);
				else if (growthRate.largerThan(1))
					growthRate.set(1);
				
				// Make immutable and return.
				growthRate.makeImmutable();
				return growthRate;
				
			} else if (type == Type.DOUBLE_LINEAR){	
				// We have to double the probability every changeValue time steps
				// That means that the fixed growth is probability(start)/changeValue
				NumberObjectSingle increasePerTimeStep = startingValue.divide(changeValue, false);
				
				// Calculate how many percentage points we have to increase the probability
				NumberObjectSingle increaseTotal = increasePerTimeStep.multiply(timeStepsInEncounter, false);
				
				// Add increase to the startingValue (store the result in increase to save on computations)
				increaseTotal.add(startingValue, true);
				
				// Make sure that the new value (now stored in increase) is between 0 and 1
				// Make sure that the new value is between 0 and 1
				if (increaseTotal.smallerThan(0))
					increaseTotal.set(0);
				else if (increaseTotal.largerThan(1))
					increaseTotal.set(1);
				
				// Make immutable and return.
				increaseTotal.makeImmutable();
				return increaseTotal;
			
			} else if (type == Type.RFUNCTION){	
				// We have already pre-loaded the RFunctionContainer when creating the InterruptionHashMap. Here we only have
				// to feed the starting probability of the interruption into the container, and let R deal with it all
				AttributeField valueAttribute = new AttributeField("value", startingValue);
				objectMutationRFunctionContainer.replaceOrAddArgument(valueAttribute);
				
				return (NumberObjectSingle) objectMutationRFunctionContainer.runInR()[0];
			} else
				throw new IllegalStateException("Type not recognized: "+ type);
			
		}
		
	}

}
