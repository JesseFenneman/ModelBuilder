package mutations;

import java.util.ArrayList;

import abstractNumberObjectsAndInterfaces.NumberObjectSingle;
import decimalNumber.DecimalNumber;
import helper.Helper.Pair;
import helper.Helper.Triplet;
import model.Ledger;
import model.Model;
import patch.Patch;
import t1states.T1MutationStateFactory;
import t2states.T2MutationStateFactory;

/** Increases the last-seen-patch-count for all patches the state is current not in*/
public class MutationPatchStateChange  extends Mutation{
	private Ledger ledger;
	private final Model model;
	protected MutationPatchStateChange(Model model) {
		this.model = model;
	}
	
	protected void setLedger (Ledger ledger) {
		this.ledger = ledger;
	}
	@Override
	public ArrayList<Triplet<T1MutationStateFactory, NumberObjectSingle, String>> getT1SuccessorStates(
		   ArrayList<Triplet<T1MutationStateFactory, NumberObjectSingle, String>> currentStates) {
		
		// Create a new ArrayList to store all resulting states in
		ArrayList< Triplet<T1MutationStateFactory, NumberObjectSingle, String> > successorStates = new ArrayList<>();

		for (Triplet<T1MutationStateFactory, NumberObjectSingle, String> originalTriplet : currentStates) {
			// Get the current patch
			Patch currentPatch = ledger.patches[originalTriplet.a.locationPatch];
			
			// Ask the Patch for an ArrayList of Pairs, which pair a future patchStateIndex to a probability that the
			// patch will transition from the current patchstate to that patchstate.
			int currentState = originalTriplet.a.locationPatchState;
			ArrayList< Pair < Integer, NumberObjectSingle>> probabilityNextPatchState = currentPatch.getTransitionProbabilityFromPatchState(currentState);
			
			// For each possible future patch state:
			for (Pair<Integer, NumberObjectSingle> futurePatchStatePair : probabilityNextPatchState) {
				if (futurePatchStatePair.element2.equals(0))
					continue;
				
				// Create a deep cloned factory that will hold the new state (i.e., the state with the updated location)
				T1MutationStateFactory factorySuccessor = new T1MutationStateFactory(originalTriplet.a, true);

				// If we have to be very secure, test if the patchStateIndex actually belongs to the patchState
				if (model.performSafetyChecks) {
					if (ledger.patchStateIndexToPatchIndex[futurePatchStatePair.element1] != currentPatch.indexInLedger)
						throw new IllegalStateException("Patch state [" + futurePatchStatePair.element1 +"] does not belong in patch [" + currentPatch.indexInLedger +"]!");
				}
					
				// Set the new location in the state, and make sure that the agent now observed the patch to be in that state
				factorySuccessor.setLocation(currentPatch.indexInLedger, futurePatchStatePair.element1)
				.resetTimeSinceLastVisit(currentPatch.indexInLedger)
				.setPatchStateInLastVisit(currentPatch.indexInLedger, futurePatchStatePair.element1);

				// Compute the new probability: the probability that the patch will be in that state, multiplied by the probability that the
				// agent ended up in this currentState
				NumberObjectSingle newProbability = originalTriplet.b.multiply(futurePatchStatePair.element2, false);
				
				if (model.performSafetyChecks)
					if (newProbability.equals(0))
						throw new IllegalStateException("Created path with 0 probability after mutation patch state change. " + originalTriplet.b);
				
				// Create an annotation
				String annotation = originalTriplet.c;
				if (!annotation.isEmpty())
					annotation = annotation + " + ";
				annotation = annotation + "Patch [" + currentPatch.indexInLedger + "]: [" + currentState + "] to [" + futurePatchStatePair.element1+"]";
				
				// Get the corresponding T1State belonging to the factory, and store in the successorStates
				successorStates.add(new Triplet<>(factorySuccessor, newProbability, annotation));	
			}
		}
		
		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to 1
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Triplet<T1MutationStateFactory, NumberObjectSingle, String> suc: successorStates)
				if (suc.b.smallerThan(0, true))
					throw new IllegalStateException("Transition to sucessor state after patch state mutation has a non-positive probability.");
				else
					sum.add(suc.b, true);
			if (!sum.equals(1, true))
				throw new IllegalStateException("Transition probability distribution after patch state mutation does not sum to 1. Sum="+ sum);
		}
		return  successorStates;
	}

	@Override
	public ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> getT2SuccessorStates(
			ArrayList<Triplet<T2MutationStateFactory, NumberObjectSingle, String>> currentStates) {

		// Create a new ArrayList to store all resulting states in
		ArrayList< Triplet<T2MutationStateFactory, NumberObjectSingle, String> > successorStates = new ArrayList<>();

		for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> originalTriplet : currentStates) {
			// Get the current patch
			Patch currentPatch = ledger.patches[originalTriplet.a.locationPatch];

			// Ask the Patch for an ArrayList of Pairs, which pair a future patchStateIndex to a probability that the
			// patch will transition from the current patchstate to that patchstate.
			int currentState = originalTriplet.a.locationPatchState;
			ArrayList< Pair < Integer, NumberObjectSingle>> probabilityNextPatchState = currentPatch.getTransitionProbabilityFromPatchState(currentState);

			// For each possible future patch state:
			for (Pair<Integer, NumberObjectSingle> futurePatchStatePair : probabilityNextPatchState) {
				if (futurePatchStatePair.element2.equals(0))
					continue;

				// Create a deep cloned factory that will hold the new state (i.e., the state with the updated location)
				T2MutationStateFactory factorySuccessor = new T2MutationStateFactory(originalTriplet.a, true);

				// If we have to be very secure, test if the patchStateIndex actually belongs to the patchState
				if (model.performSafetyChecks) {
					if (ledger.patchStateIndexToPatchIndex[futurePatchStatePair.element1] != currentPatch.indexInLedger)
						throw new IllegalStateException("Patch state [" + futurePatchStatePair.element1 +"] does not belong in patch [" + currentPatch.indexInLedger +"]!");
				}

				// Set the new location in the state, and make sure that the agent now observed the patch to be in that state
				factorySuccessor.setLocation(currentPatch.indexInLedger, futurePatchStatePair.element1)
				.resetTimeSinceLastVisit(currentPatch.indexInLedger)
				.setPatchStateInLastVisit(currentPatch.indexInLedger, futurePatchStatePair.element1);

				// Compute the new probability: the probability that the patch will be in that state, multiplied by the probability that the
				// agent ended up in this currentState
				NumberObjectSingle newProbability = originalTriplet.b.multiply(futurePatchStatePair.element2, false);

				if (model.performSafetyChecks)
					if (newProbability.equals(0))
						throw new IllegalStateException("Created path with 0 probability after mutation patch state change. " + originalTriplet.b);

				// Create an annotation
				String annotation = originalTriplet.c;
				if (!annotation.isEmpty())
					annotation = annotation + " + ";
				annotation = annotation + "Patch [" + currentPatch.indexInLedger + "]: [" + currentState + "] to [" + futurePatchStatePair.element1+"]";

				// Get the corresponding T1State belonging to the factory, and store in the successorStates
				successorStates.add(new Triplet<>(factorySuccessor, newProbability, annotation));	
			}
		}

		// If the model wants us to be careful: check if the sum of all probabilities for all successor states does indeed sum to 1
		if (model.performSafetyChecks) {
			DecimalNumber sum = new DecimalNumber(0);
			for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> suc: successorStates)
				if (suc.b.smallerThan(0, true))
					throw new IllegalStateException("Transition to sucessor state after patch state mutation has a non-positive probability.");
				else
					sum.add(suc.b, true);
			
			// Figure out what the sum should be: the summed probability of all currentState entries
			DecimalNumber target = new DecimalNumber(0);
			for (Triplet<T2MutationStateFactory, NumberObjectSingle, String> pair : currentStates)
				target.add(pair.b, true);
			
			if (!sum.equals(target, true))
				throw new IllegalStateException("Transition probability distribution after patch state mutation does not sum to initial sum. Sum after = "+ sum + ". Sum before: "+ target.toStringWithoutTrailingZeros());
		}
		return  successorStates;
	}



	@Override
	public String toString() {
		return "Patches change state";
	}
	@Override
	public int hashCode() {
		return 1;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		return true;
	}

}
